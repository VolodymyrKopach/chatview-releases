#!/usr/bin/env python3
"""Detached background AGENT worker for the «Процеси» panel (Phase 2, owner decision 2026-07-10).

Spawned DETACHED by /api/agent-spawn (own session + process group) so it survives the
main turn, a new message, and even a Logopsis restart. It runs ONE `claude -p <task>`
in its own --session-id + pgid, mirrors run_claude_stream's stream-json parse, and
writes per-agent state to disk:

  channels/<ch>/agents/<id>/status.json     live status (state,pid,pgid,progress,lastStep…)
  channels/<ch>/agents/<id>/progress.jsonl  append-only step/text stream
  channels/<ch>/agents/<id>/output.md       final result (written on done)

On done it auto-posts output as a card to the channel and emits an agent/done event so
the panel + feed reflect the result. Reattach/orphan-reconcile lives in server.py (it
scans status.json); this worker just runs one agent to completion.

Usage:  python agent_worker.py <channel> <agentId>
The spawn spec (task,label,model,sid) is read from the pre-written status.json.
Set AGENT_CLAUDE_BIN to override the claude binary (used by the cheap plumbing test).
"""
import os
import sys
import json
import time
import uuid
import tempfile
import subprocess
from datetime import datetime

import runner  # safe to import: runner guards its worker loop behind __main__
import jobs    # реєстр процесів + гейти на вбивство/спавн
import batch_publish  # S5 (specs/agent-batch-summary): спроба підсумку пачки
import plan_autopatch  # A3 (specs/plan-autosync): крок плану під агента -> без моделі
import plan_store as ps  # G4 (specs/plan-safety-gates): читання плану для ephemeral-прибирання

# ДЗЕРКАЛЕННЯ ІМЕН ЗМІННИХ СЕРЕДОВИЩА (CHATVIEW_* <-> LOGOPSIS_*). Стоїть вище за
# будь-яке читання середовища у цьому файлі: у власника лишились запущені служби,
# launchd-агенти і .command-файли зі старими іменами, і вони мусять і далі працювати.
# Контракт і причини: brand_env.py.
import brand_env  # noqa: F401


def _agent_dir(channel, agent_id):
    return os.path.join(runner.CHANNELS_DIR, channel, 'agents', agent_id)


def _now():
    return datetime.now().isoformat()


def _close_jobs(channel, agent_id, claude_job, state):
    """Зняти з реєстру обидва job-и агента: його claude і сам воркер.

    Свій jobId читаємо зі status.json НАПРИКІНЦІ, а не на старті: сервер
    дописує його вже після спавну, тож на старті файл його ще не має."""
    try:
        if claude_job:
            jobs.finish(claude_job.get('jobId'), state)
    except Exception:
        pass
    try:
        own = _read_status(channel, agent_id).get('jobId')
        if own:
            jobs.finish(own, state)
    except Exception:
        pass


def _read_status(channel, agent_id):
    try:
        return json.load(open(os.path.join(_agent_dir(channel, agent_id), 'status.json'),
                              encoding='utf-8')) or {}
    except Exception:
        return {}


def _write_status(channel, agent_id, patch):
    """Merge patch into status.json atomically (never raises)."""
    try:
        d = _agent_dir(channel, agent_id)
        os.makedirs(d, exist_ok=True)
        p = os.path.join(d, 'status.json')
        cur = _read_status(channel, agent_id)
        cur.update(patch)
        cur['updatedAt'] = _now()
        tmp = p + '.tmp'
        with open(tmp, 'w', encoding='utf-8') as f:
            json.dump(cur, f, ensure_ascii=False, indent=2)
        os.replace(tmp, p)
        return cur
    except Exception as e:
        runner.log(f'agent {agent_id}: status write failed: {e}')
        return {}


def _progress(channel, agent_id, rec):
    try:
        d = _agent_dir(channel, agent_id)
        os.makedirs(d, exist_ok=True)
        rec = dict(rec)
        rec.setdefault('ts', _now())
        with open(os.path.join(d, 'progress.jsonl'), 'a', encoding='utf-8') as f:
            f.write(json.dumps(rec, ensure_ascii=False) + '\n')
    except Exception:
        pass


def _post_card(channel, widgets, from_name, tag='agent'):
    """Append a result card to the channel so the agent's output shows up like any
    other bubble.

    Preferred path is render-message.cjs (the same one the hooks use: it also
    lazily registers a brand-new channel as a tab and can voice the card). A packaged
    desktop ships neither that script nor a guaranteed node, so it degrades to
    runner.append_message — literally the function the runner writes its own bubbles
    with. Without this fallback a detached agent finished silently in the desktop:
    the work was done, the result never reached the chat."""
    script = os.path.join(runner.DIR, 'render-message.cjs')
    node = runner._resolve_node()
    if os.path.exists(script) and os.path.isabs(node) and os.path.exists(node):
        tmp = None
        try:
            fd, tmp = tempfile.mkstemp(suffix='.json')
            os.close(fd)
            with open(tmp, 'w', encoding='utf-8') as f:
                json.dump(widgets, f, ensure_ascii=False)
            r = subprocess.run([node, script, tmp, from_name, tag, channel],
                               cwd=runner.DIR, timeout=25,
                               stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
            if r.returncode == 0:
                return
            runner.log(f'agent: render-message exited {r.returncode}, writing card directly')
        except Exception as e:
            runner.log(f'agent: post card via node failed: {e}, writing card directly')
        finally:
            if tmp:
                try:
                    os.remove(tmp)
                except OSError:
                    pass
    try:
        runner.append_message(channel, widgets, from_name, tag)
    except Exception as e:
        runner.log(f'agent: post card failed: {e}')


def _result_widgets(label, out, lang):
    """Фінальний текст агента у віджети, тією ж функцією, що й основний потік чату.

    Було: увесь вивід їхав ОДНИМ text-віджетом, тож навіть бездоганні ```chatui```
    блоки приїжджали в канал сирим JSON, а таблиця стіною тексту. Заголовок тепер
    окремий віджет і не зʼїдає вивід. ```plan``` вирізаємо: план каналу не агентова
    справа, і показувати його як текст теж не треба. Будь-яка поломка деградує у той
    самий один text-віджет, що був раніше, тобто гірше не стає ніколи.

    Заголовок і заглушка мовно залежні (specs/i18n-interface, К18): раніше тут стояв
    голий український рядок, і англійський інтерфейс бачив картку завершеного агента
    з украЇнським підписом усередині, попри обрану мову.

    `lang`, а НЕ `channel` (латання оберту 3, Ревізор 3: «ламає навмисно»). Було:
    цей заголовок читав current_lang(channel) У МОМЕНТ ЗАВЕРШЕННЯ ходу, а тіло
    `out` уже несло мову, запечену в промпт агента на СТАРТІ (agent_task_with_
    contract). Перемикання мови ПОСЕРЕД ходу агента (живо відтворено: заголовок
    англійською, тіло українською в одній картці) означало, що дві половини
    картки могли розійтись по мові. `lang` тепер той самий знімок, зафіксований
    ОДИН раз на старті run(), що й бачив сам двигун — картка або цілком стара
    мова, або цілком нова, ніколи мішанка."""
    head = {'type': 'header', 'title': runner._lang_text({'uk': f'🤖 {label} · агент завершив',
                                                            'en': f'🤖 {label} · agent finished'}, lang)}
    empty = {'type': 'text', 'text': runner._lang_text({'uk': '(агент завершив без тексту)',
                                                         'en': '(agent finished with no text)'}, lang)}
    body = (out or '').strip()
    if not body:
        return [head, empty]
    try:
        clean, _plan = runner.extract_plan_block(body)
        clean = (clean or '').strip()
    except Exception as e:
        runner.log(f'agent: plan strip failed ({e}), keeping raw output')
        clean = body
    # Вивід був самим лише планом: показувати нема чого, але й вивалювати план
    # у стрічку текстом теж не можна.
    if not clean:
        return [head, empty]
    try:
        widgets = runner.reply_to_widgets(clean)
    except Exception as e:
        runner.log(f'agent: reply_to_widgets failed ({e}), degrading to plain text')
        widgets = None
    return [head] + (widgets or [{'type': 'text', 'text': clean}])


def _truncated_widgets(label, last_step, partial, rc, lang):
    """Картка обриву. Свій вигляд, а не позичений у помилки, бо це інша подія.

    Помилка це «двигун сказав, що хід невдалий»: причина відома і її можна написати.
    Обрив це «двигун замовк на пів-кроці»: відомо лише ДЕ обірвало і що код виходу
    такий. Показувати друге як перше означало б вигадати причину, а показувати як
    успіх (те, що було) означало б сховати подію взагалі."""
    head = {'type': 'header',
            'title': runner._lang_text({'uk': f'🔴 {label} · агента обірвало',
                                        'en': f'🔴 {label} · agent was cut off'}, lang)}
    why = {'type': 'callout', 'variant': 'danger',
           'title': runner._lang_text({'uk': 'Хід не дійшов до кінця',
                                       'en': 'The run never finished'}, lang),
           'text': runner._lang_text(
               {'uk': 'Двигун не віддав фінальну подію, тобто роботу обірвано посеред '
                      'кроку. Результату немає, і те, що нижче, це проза між викликами '
                      'інструментів, а не звіт. Задачу треба переставити.',
                'en': 'The engine never sent its final event, so the run was cut off '
                      'mid-step. There is no result: what follows is the prose between '
                      'tool calls, not a report. The task has to be re-run.'}, lang)}
    facts = {'type': 'key-values', 'items': [
        {'k': runner._lang_text({'uk': 'Обірвало на кроці', 'en': 'Cut off at step'}, lang),
         'v': (last_step or '?')[:140], 'color': 'red'},
        {'k': runner._lang_text({'uk': 'Код виходу', 'en': 'Exit code'}, lang),
         'v': str(rc), 'color': 'yellow'},
        {'k': runner._lang_text({'uk': 'Устиг написати', 'en': 'Wrote before the cut'}, lang),
         'v': f'{len(partial or "")} B', 'color': 'slate'}]}
    out = [head, why, facts]
    if partial:
        out.append({'type': 'text', 'detail': True,
                    'title': runner._lang_text({'uk': 'Що агент устиг написати до обриву',
                                                'en': 'What the agent wrote before it broke off'}, lang),
                    'text': partial})
    out.append({'type': 'conclusion', 'tone': 'red',
                'text': runner._lang_text({'uk': 'Агента обірвало, результату немає.',
                                           'en': 'The agent was cut off, there is no result.'}, lang)})
    return out


def _summary_from(widgets, fallback):
    """Рядок для панелі «Процеси»: перша ЗМІСТОВНА проза, а не сирий JSON.

    Раніше сюди летіли перші 220 символів фінального тексту. Щойно агент почав
    відповідати віджетами, у панелі опинявся шматок JSON-блоку."""
    for w in widgets:
        if w.get('type') == 'text':
            t = (w.get('text') or '').strip()
            if t:
                return t[:220]
    for w in widgets:
        for key in ('text', 'title'):
            t = (w.get(key) or '').strip() if isinstance(w.get(key), str) else ''
            if t:
                return t[:220]
    return (fallback or '')[:220]


def _try_batch_summary(channel, agent_id):
    """S5 (specs/agent-batch-summary, К1/К2): спроба опублікувати підсумок пачки ПІСЛЯ
    того, як власний запис агента вже ліг на диск у термінальному стані, і ПІСЛЯ власної
    картки — виклик тут єдина спільна точка для КОЖНОГО шляху _run_impl() до
    термінального стану (порожня задача, провал спавну, зовнішній стоп, помилка ходу,
    успіх), а не копія виклику в пʼятьох місцях. Саме тому підсумок не зникає разом із
    тим шляхом, яким саме останній агент пачки дійшов до кінця: провал чи стоп лишають
    підсумок так само, як і успіх (К2). Жоден виняток звідси не сміє завалити воркер:
    агент, який упав через підсумок, гірший за відсутній підсумок."""
    try:
        record = _read_status(channel, agent_id)
        agents_dir = os.path.join(runner.CHANNELS_DIR, channel, 'agents')
        batch_publish.try_publish_batch_summary(
            runner.CHANNELS_DIR, channel, agents_dir, record, _post_card, log=runner.log)
    except Exception as e:
        runner.log(f'agent {agent_id}: batch summary attempt failed: {e}')


# specs/plan-autosync/spec.md, А3, К1/К2: done -> звʼязаний крок плану закривається;
# усе інше цей воркер сам колись напише в status.json (error, stopped, обрив без
# результату claude) -> крок блокується з короткою причиною. 'truncated' тут це і є
# "обрив, без термінального результату claude", яким специка описує сироту: справжня
# орфан-реконсиляція мертвого процесу (коли сам воркер вже не живий, щоб дописати щось
# узагалі) лежить у server.py, поза скоупом А3, і туди цей хук дотягнутись не може.
# Нота йде В ПЛАН, тобто прямо людині на екран, тому мова тут не наша, а її
# (specs/i18n-interface, К4/К20). Носій той самий, що всюди в беку: пара
# {'uk': ..., 'en': ...} лишається біля місця вживання, а мову за каналом підбирає
# `runner._bt` у момент запису.
#
# ЧОМУ ПАРИ, А НЕ СЛОВНИК. Ключі тут це СТАНИ АГЕНТА, а не поля віджета, але один
# з них зветься `error`, тобто рівно так, як зветься видиме поле картки. Сканер
# видимого тексту (backend_text_scan) читає AST і за іменем ключа відрізнити стан
# від поля не може, тому словник `{'error': ...}` з кирилицею всередині він чесно
# рахує витоком. Вибір був між глушником у сканері і формою запису тут; глушник
# коштував би дірки на кожен майбутній справжній `error`, тому таблиця лишається
# впорядкованим переліком пар, а сканер лишається без винятків.
_PLAN_BLOCK_REASON = (
    ('error', {'uk': 'агент завершився з помилкою',
               'en': 'the agent finished with an error'}),
    ('stopped', {'uk': 'агента зупинено вручну',
                 'en': 'the agent was stopped by hand'}),
    ('truncated', {'uk': 'агента обірвало, результату немає',
                   'en': 'the agent was cut off, there is no result'}),
)


def _plan_block_note(state, channel):
    """Нота для заблокованого кроку плану цією мовою, або None для стану,
    який блокуванням не є."""
    for name, chunks in _PLAN_BLOCK_REASON:
        if name == state:
            return runner._bt(chunks, channel)
    return None


def _try_plan_autopatch(channel, agent_id):
    """Останній виклик у `run()`: якщо під цього агента заведено крок плану з id
    "agent:<agentId>", позначити його без участі моделі (К1, К2). Немає такого кроку —
    plan_autopatch сам мовчки нічого не робить (К3), тут це не помилка. Жоден виняток
    звідси не сміє завалити воркер (К8): агент, який упав через оновлення плану, гірший
    за неоновлений план."""
    try:
        state = _read_status(channel, agent_id).get('state')
        step_id = f'agent:{agent_id}'
        if state == 'done':
            plan_autopatch.mark_step(channel, step_id, 'done')
        else:
            note = _plan_block_note(state, channel)
            if note:
                plan_autopatch.mark_step(channel, step_id, 'blocked', note=note)
    except Exception as e:
        runner.log(f'agent {agent_id}: plan autopatch failed: {e}')


# G4 (specs/plan-safety-gates/spec.md, plan.md, критерій К6): автоприбирання ефемерних
# кроків, вимкнене на завершення саме того агента, на чий id ознака вказує. Формат
# `ephemeral` задокументовано в plan_autopatch.py поруч із форматом `closeOn` (та сама
# причина, що й у G5/plan_autosync_tick.py для `push`/`spec-closed`: логіка, специфічна
# для СВОГО місця вмикання, не тягнеться в `_CLOSE_TYPES`, лише документується поруч).
_EPHEMERAL_KEY = 'ephemeral'
_EPHEMERAL_TYPE_AGENT = 'agent'


def _ephemeral_marker_agent(step):
    """agentId, якого називає ознака `ephemeral` кроку, або None коли ознаки нема
    зовсім, чи вона неправильної форми — дзеркалить власне правило
    plan_autopatch._close_condition «відсутнє/зіпсоване це завжди НЕ умова»: крок
    ефемерний лише за явною, справною декларацією, ніколи за здогадкою з тексту."""
    if not isinstance(step, dict):
        return None
    marker = step.get(_EPHEMERAL_KEY)
    if not isinstance(marker, dict):
        return None
    if str(marker.get('type') or '').strip().lower() != _EPHEMERAL_TYPE_AGENT:
        return None
    agent = str(marker.get('agent') or '').strip()
    return agent or None


def _try_plan_ephemeral_cleanup(channel, agent_id):
    """К6: кожен крок, чия ознака `ephemeral` називає саме цього agent_id, прибирається
    з плану тепер, коли прогін цього агента завершився — НЕЗАЛЕЖНО від того, встиг він
    закритись (`done`) чи ні. Виклик іде ОСТАННІМ у `run()`, тобто рівно на кожному
    термінальному шляху (done/error/stopped/truncated однаково: ефемерний крок це
    риштування під прогін, а не його результат, тому невдача прогону не привід лишати
    риштування).

    Раніше (Д2, work/plan-autosync/c6/DEFEKTY.md) done-крок свідомо НЕ займали, бо
    plan_autopatch.mark_step на done-кроці мовчки нічого не пише — правило замороженого
    done з plan_store.merge_plan спрацьовує для БУДЬ-ЯКОГО патча, `dropped` включно.
    Наслідок був парадоксальний: сміття лишалось саме після УСПІШНИХ демонстрацій —
    рівно того сценарію, заради якого ознаку й ввели. Тому done-крок тепер іде окремим,
    вужчим шляхом (plan_autopatch.drop_ephemeral_done_step, див. коментар над ним), що
    НЕ йде через merge_plan узагалі; активний крок і далі йде звичним mark_step(...,
    DROPPED) — там усе працювало правильно й до цього фіксу.

    Зіставлення рівно за явним `id` кроку (те саме правило, що вже застосовує
    plan_autopatch.mark_step): ознака, що називає ІНШОГО агента, чи ефемерний крок без
    `id`, лишаються де були — тут ніщо не вгадує намір з тексту кроку. Ковтає будь-який
    виняток (той самий стиль, що в _try_plan_autopatch): зламаний plan.json чи невдалий
    запис відкладає прибирання до наступної нагоди, і не сміє завалити воркер, чия власна
    картка вже опублікована."""
    try:
        plan = ps.read_plan(channel)
        for step in ps.collect_steps(plan):
            if _ephemeral_marker_agent(step) != agent_id:
                continue
            step_id = str(step.get('id') or '').strip()
            if not step_id:
                continue
            if str(step.get('state') or '').strip().lower() == ps.DONE:
                plan_autopatch.drop_ephemeral_done_step(channel, step_id)
            else:
                plan_autopatch.mark_step(channel, step_id, ps.DROPPED)
    except Exception as e:
        runner.log(f'agent {agent_id}: plan ephemeral cleanup failed: {e}')


def run(channel, agent_id):
    """Тонка обгортка над _run_impl: `finally` гарантує, що спроба підсумку пачки,
    автопатчу плану і прибирання ефемерних кроків відбудуться РІВНО ОДИН раз на кожен
    запуск воркера, вже ПІСЛЯ того, як _run_impl дописав термінальний стан і власну
    картку (усі його return роблять це ДО виходу). Автопатч плану і прибирання йдуть
    ОСТАННІМИ (specs/plan-autosync/spec.md, А3; specs/plan-safety-gates/spec.md, G4):
    вони найменш критичні з чотирьох, тому не сміють затримати чи заблокувати нічого
    перед собою."""
    try:
        _run_impl(channel, agent_id)
    finally:
        _try_batch_summary(channel, agent_id)
        _try_plan_autopatch(channel, agent_id)
        _try_plan_ephemeral_cleanup(channel, agent_id)


# ── Двигун ходу і запасна модель ────────────────────────────────────────────
# specs/agent-model-fallback/spec.md, сабтаск S4.
#
# Донедавна цей воркер умів рівно один двигун: збирав `claude -p …` і слова `agy`
# не знав узагалі. Тут зʼявляється друга гілка і РІВНО ОДНЕ перемикання на запасну
# модель, бо фоновий агент, що вмирає карткою «ліміт вичерпано» при живому другому
# двигуні поруч, це втрачена ніч роботи.
#
# Вибір приїжджає ГОТОВИМ у status.json (ключ 'modelChoice', його пише сервер):
#   {'primary': {'engine','tier','id'}, 'fallback': {…}|None,
#    'switched': bool, 'reason': str|None, 'usable': bool}
# Ключа нема означає «поводься рівно як до цієї правки» (К10), тому весь новий код
# висить на наявності цього запису, а гілка Клода лишилась дослівно тим самим
# списком аргументів, що й був.
#
# Для 'claude' поле 'id' навмисно порожнє: повний id пінить runner._resolve_model_args,
# і другого власника цього знання бути не повинно, туди йде рівень. Для 'antigravity'
# id ставить сервер через agy_models.resolve_tiers; не поставив, добираємо
# runner.agy_model_for, тобто ТОЮ САМОЮ функцією, а не власною мапою рівнів. Саме
# другу мапу спека називає окремим ризиком: вона протухає на першому ж випуску двигуна.
_ENGINE_CLAUDE = 'claude'
_ENGINE_AGY = 'antigravity'
# Основна плюс рівно одна запасна, третього запуску не буває НІКОЛИ (К6). Нічний
# агент на циклі перезапусків спалив би до ранку квоту ОБОХ двигунів.
_MAX_MODEL_ATTEMPTS = 2
# Стеля ходу для agy. Клод у цьому воркері її не має взагалі, але `agy -p` без
# --print-timeout бере власний короткий дефолт, а фонова задача живе годинами.
# Беремо ту саму абсолютну стелю, якою runner страхує канальний хід від зациклення.
_AGY_AGENT_TIMEOUT = int(os.environ.get('CHAT_AGY_AGENT_TIMEOUT',
                                        str(getattr(runner, 'TURN_TIMEOUT', 3600))))


def _model_choice(spec):
    """'modelChoice' зі спеки агента, або None коли ключа нема (К10)."""
    choice = (spec or {}).get('modelChoice')
    return choice if isinstance(choice, dict) else None


def _engine_entry(entry):
    """Нормалізований запис вибору {'engine','tier','id'}, або None.

    None на будь-яку кривизну (не словник, невідомий двигун), бо здогадуватись тут
    нема з чого: покалічений запис мусить впасти на теперішню поведінку, а не на
    вгаданий двигун."""
    if not isinstance(entry, dict):
        return None
    engine = str(entry.get('engine') or '').strip().lower()
    if engine not in (_ENGINE_CLAUDE, _ENGINE_AGY):
        return None
    tier = str(entry.get('tier') or '').strip() or None
    mid = entry.get('id')
    mid = mid.strip() if isinstance(mid, str) and mid.strip() else None
    return {'engine': engine, 'tier': tier, 'id': mid}


def _claude_bin():
    return os.environ.get('AGENT_CLAUDE_BIN', runner.CLAUDE_BIN)


def _engine_ready(engine):
    """Чи стоїть бінарник двигуна на ЦІЙ машині.

    Це НЕ друга перевірка готовності: трьохстан yes|no|unknown рахує сервер, і
    дублювати його заборонено спекою. Це остання чесна умова саме СПАВНУ, рівно та
    сама, яку ставить runner.run_agy_stream перед своїм Popen. Без неї агент з
    непідключеним agy впав би «No such file» замість того, щоб поїхати на запасній
    (К5)."""
    if engine == _ENGINE_AGY:
        return bool(runner.AGY_BIN)
    binary = _claude_bin()
    # Абсолютний шлях можна перевірити чесно; голе імʼя команди резолвить PATH уже
    # сам Popen, і вгадувати за нього ми не беремось.
    return (not os.path.isabs(binary)) or os.path.exists(binary)


def _agy_log_path(channel, agent_id):
    """Власний лог CLI цього АГЕНТА, а не канальний (runner.agy_log_path).

    Канальний спорожнюється перед КОЖНИМ ходом чату, тож фоновий агент і жива
    розмова затирали б причину збою одне одному, а причина 403 лежить тільки там:
    stderr у цьому випадку порожній, а стрім каже лише «terminated due to error»."""
    return os.path.join(_agent_dir(channel, agent_id), 'agy.log')


def _agy_log_reset(channel, agent_id):
    """Спорожнити лог перед ходом і віддати шлях, '' коли не вийшло.

    '' навмисно: тоді прапорець --log-file просто не додається і хід їде без нього,
    бо збій запису лога не сміє коштувати ходу."""
    path = _agy_log_path(channel, agent_id)
    try:
        os.makedirs(os.path.dirname(path), exist_ok=True)
        with open(path, 'w', encoding='utf-8'):
            pass
        return path
    except Exception as e:
        runner.log(f'agent {agent_id}: agy log reset failed: {e}')
        return ''


def _agy_cause(channel, status, result_error, step_errors, err_tail, log_file):
    """Одна стрічка причини збою agy з УСІХ джерел ходу плюс дочитаний лог CLI.

    Дзеркалить runner._agy_failure_cause і існує окремо рівно через ОДНУ
    відмінність: лог у агента власний, а не канальний. Склейка потрібна тому, що
    жодне джерело поодинці причини не несе: result.error каже лише «терміновано»,
    крок error_message приходить порожній, stderr порожній, а рядок з кодом лежить
    тільки в лозі."""
    parts = []
    for p in [result_error] + list(step_errors or []) + [err_tail]:
        p = ' '.join((p or '').split())
        if p and p not in parts:
            parts.append(p)
    if (status or '').upper() == 'ERROR' and not parts:
        parts.append(runner.AGY_ERROR_STEP_NOTE)
    # Лог дочитуємо РІВНО тоді, коли явної причини нема: код у ньому є завжди, але
    # читати файл на кожному ході нам ні до чого.
    if log_file and not runner.AGY_LOG_CODE_RE.search('; '.join(parts)):
        extra = runner.agy_log_cause(channel, path=log_file)
        if extra and extra not in parts:
            parts.append(extra)
    return '; '.join(parts)


def _claude_cmd(ctx, model_name):
    """Теперішня гілка, слово в слово.

    Тут свідомо не змінилось НІЧОГО, і саме це стереже К10: без 'modelChoice' у
    status.json команда мусить збігатись байт у байт із тією, яку будував код до цієї
    правки. Контракт віджетів клеїться на боці сервера (ctx['body']), а не в
    agent-run.cjs: так він діє для всіх способів спавну."""
    effort = ctx['effort']
    # Рівень зусиль приходить зі спеки (agent-run.cjs --effort). Haiku не має цього
    # параметра взагалі, тому для нього прапор просто не додаємо.
    if effort and 'haiku' in (model_name or '').lower():
        effort = ''
    return [ctx['claude_bin'], '-p', ctx['body'],
            *runner._resolve_model_args(model_name),
            *(['--effort', effort] if effort else []),
            '--disallowedTools', *runner.DISALLOWED_TOOLS,
            '--output-format', 'stream-json', '--verbose',
            '--include-partial-messages',
            '--session-id', ctx['sid'],
            # A detached agent has no interactive permission UI, so it must not block on
            # a prompt; it runs autonomously (still bounded by --disallowedTools).
            '--permission-mode', 'bypassPermissions']


def _agy_cmd(channel, ctx, model_id, log_file):
    """Рецепт запуску Antigravity, знятий з runner.run_agy_stream: це єдиний живий
    робочий виклик цього CLI в проєкті, і кожен його прапорець там уже обґрунтований.
    Тому список тут не «схожий», а той самий: stream-json, дозволи не питаються
    (headless не вміє питати), --add-dir це корінь проєкту (з чужим коренем двигун
    читає файли-примари зі своєї scratch-теки), --log-file єдине місце, де видно
    причину збою.

    --conversation НЕ передаємо і conversation_id НЕ зберігаємо: фоновий агент це
    ОДИН хід без продовження, і памʼять чужої розмови йому не належить."""
    cmd = [runner.AGY_BIN, '-p', ctx['body'],
           '--output-format', 'stream-json',
           '--dangerously-skip-permissions',
           '--add-dir', runner.agy_workdir(channel),
           '--print-timeout', f'{_AGY_AGENT_TIMEOUT}s']
    if log_file:
        cmd += ['--log-file', log_file]
    if model_id:
        cmd += ['--model', model_id]
    return cmd


def _step_noter(channel, agent_id, st):
    """Один спільний запис кроку для обох двигунів: рядок у progress.jsonl плюс
    жива смуга в status.json. Двигуни називають кроки по-різному, але панель
    «Процеси» має бачити одне й те саме."""
    def note(name, lbl):
        st['steps'] += 1
        last_step = (f'{name}: {lbl}' if lbl else name)[:140]
        _progress(channel, agent_id, {'phase': 'step', 'tool': name, 'step': last_step})
        _write_status(channel, agent_id, {'lastStep': last_step,
                      'progressPct': min(95, 5 + st['steps'] * 7)})
    return note


def _parse_claude_stream(channel, agent_id, proc, note, st):
    """Розбір stream-json Клода. Перенесено з _run_impl без жодної зміни поведінки."""
    text = ''
    # Помилка ходу, оголошена самим CLI у фінальній події (`result.is_error`). Раніше
    # її тут не читали взагалі: `text = ev.get('result')` брав рядок за будь-якої
    # ознаки, тож «You've hit your session limit · resets 12:20am (Europe/Kiev)»
    # ставав «виводом агента» і публікувався карткою «· агент завершив».
    result_err = ''
    # Чи прийшла ФІНАЛЬНА подія двигуна. Це і є ознака обриву, і саме вона, а не
    # довжина чи вигляд тексту: `claude -p --output-format stream-json` завершує
    # КОЖЕН доведений хід рівно однією подією `result` (успіх це чи самооголошена
    # помилка, байдуже). Тому «події не було» це твердження про ПРОТОКОЛ, а не
    # здогад про зміст, і воно не залежить ні від мови, ні від довжини відповіді.
    saw_result = False
    try:
        for line in iter(proc.stdout.readline, ''):
            # An external stop flips status→stopped; bail promptly so we don't overwrite it.
            if _read_status(channel, agent_id).get('state') == 'stopped':
                break
            line = line.strip()
            if not line:
                continue
            try:
                ev = json.loads(line)
            except Exception:
                continue
            t = ev.get('type')
            if t == 'assistant':
                for b in (ev.get('message', {}) or {}).get('content', []):
                    if b.get('type') == 'tool_use':
                        name = b.get('name', '')
                        note(name, runner._tool_label(name, b.get('input')))
            elif t == 'stream_event':
                inner = ev.get('event', {}) or {}
                if inner.get('type') == 'content_block_delta':
                    d = inner.get('delta', {}) or {}
                    if d.get('type') == 'text_delta' and d.get('text'):
                        text += d['text']
            elif t == 'result':
                saw_result = True
                if ev.get('is_error'):
                    result_err = (ev.get('result') or 'unknown error')
                else:
                    text = ev.get('result') or text
    except Exception as e:
        runner.log(f'agent {agent_id}: parse error: {e}')
    return {'text': text, 'result_err': result_err, 'saw_result': saw_result}


def _parse_agy_stream(channel, agent_id, proc, note, st):
    """Розбір стріму Antigravity. ФОРМАТ ТУТ ІНШИЙ, ніж у Клода, і саме на цьому
    найлегше тихо впасти, тому відмінності виписані поіменно (звірено на живому
    `agy 1.2.2`, сирі події збережені зондом):

    1. Тип події лежить у ключі 'event', а не 'type'. Розбирач Клода на цьому
       потоці не впав би з помилкою, він просто мовчки не побачив би НІЧОГО:
       кожна подія провалилась би повз усі гілки, агент завершився б з порожнім
       текстом і виглядав би як «відповів нічим».
    2. Кроки приходять окремими подіями 'step_update', а не блоками 'tool_use'
       всередині повідомлення асистента.
    3. Кожен крок приїжджає ДВІЧІ: 'ACTIVE', потім 'DONE'. Дедуп по 'step_index',
       інакше смуга прогресу рахувала б кожен інструмент двічі.
    4. Параметри інструмента лежать у tool_info.parameters і звуться по-своєму
       ('AbsolutePath' замість 'file_path'). Підпис будує та сама runner._tool_label:
       вона на незнайомих ключах чесно деградує в 'ключ=значення', і це краще за
       другу мапу назв, яка протухне на першому ж випуску двигуна.
    5. Фінальна подія несе ПОВНУ відповідь одним шматком у result.response. Беремо
       саме її, а не склеєний стрім: двигун ріже потік по байтах, а не по символах,
       і кирилична літера на межі двох text_delta приїжджає зіпсованою з обох боків.

    Віддає ті самі три речі, які цей воркер уже вміє писати: текст, кроки, помилку."""
    text = ''            # накопичений стрім, запасний варіант для тексту
    final_text = None    # чистий текст із події result, саме він іде в картку
    saw_result = False
    result_status = ''
    result_error = ''
    step_errors = []
    seen_steps = set()
    try:
        for line in iter(proc.stdout.readline, ''):
            if _read_status(channel, agent_id).get('state') == 'stopped':
                break
            line = line.strip()
            if not line.startswith('{'):
                continue
            try:
                ev = json.loads(line)
            except Exception:
                continue
            kind = ev.get('event')
            if kind == 'result':
                saw_result = True
                res = ev.get('result')
                if isinstance(res, dict):
                    if isinstance(res.get('response'), str) and res['response'].strip():
                        final_text = res['response']
                    if isinstance(res.get('status'), str):
                        result_status = res['status'].strip().upper()
                    if isinstance(res.get('error'), str) and res['error'].strip():
                        result_error = res['error'].strip()
                continue
            if kind != 'step_update':
                continue
            su = ev.get('step_update') or {}
            step_type = su.get('step_type')
            if step_type == 'tool':
                key = su.get('step_index')
                if key is None:
                    key = f"{su.get('tool_name')}:{len(seen_steps)}"
                if key in seen_steps:
                    continue
                seen_steps.add(key)
                name = su.get('tool_name') or 'tool'
                info = su.get('tool_info') or {}
                note(name, runner._tool_label(name, info.get('parameters')))
            elif step_type == 'agent_response':
                d = su.get('text_delta')
                if d:
                    text += d
            elif step_type == 'error_message':
                # Двигун сам каже, що хід помер. Текст тут буває порожній (у 18
                # заміряних збоях був порожній ЗАВЖДИ), тому кладемо мітку: сам
                # факт кроку це вже причина, якої нам бракувало.
                t = runner._agy_step_text(su) or runner.AGY_ERROR_STEP_NOTE
                if t not in step_errors:
                    step_errors.append(t)
    except Exception as e:
        runner.log(f'agent {agent_id}: agy parse error: {e}')
    return {'text': text, 'final_text': final_text, 'saw_result': saw_result,
            'status': result_status, 'error': result_error, 'step_errors': step_errors}


def _run_turn(channel, agent_id, ctx, entry):
    """Один хід агента на ОДНОМУ двигуні. Віддає носій результату
    (text / result_err / saw_result / rc / err_txt / stopped / spawn_error / job).

    Термінальні стани (done, error, truncated, stopped) сюди свідомо НЕ переїхали:
    вирішує їх _run_impl, один раз, уже після можливого перемикання на запасну.
    Інакше перша ж невдала спроба встигла б написати картку «ліміт вичерпано», і
    людина побачила б дві картки на один хід."""
    engine = entry['engine']
    log_file = ''
    if engine == _ENGINE_AGY:
        # Рівень -> id рахує ВИКЛЮЧНО agy_models.resolve_tier (через
        # runner.agy_model_for). Порожня видача віддає None, і тоді --model просто
        # не додається: хай двигун бере власний дефолт, це чесніше за здогад про
        # модель, якої ми в очі не бачили.
        model_name = entry['id'] or runner.agy_model_for(
            entry['tier'] or runner._agy_alias(channel, ctx['task']))
        log_file = _agy_log_reset(channel, agent_id)
        cmd = _agy_cmd(channel, ctx, model_name, log_file)
    else:
        model_name = entry['tier'] or ctx['model']
        cmd = _claude_cmd(ctx, model_name)

    env = runner._child_env(channel)
    # Маркер для agent-detach-gate.cjs. Гейт жене довгі задачі з Agent tool у
    # цей самий місток, але ВСЕРЕДИНІ detached-агента він зайвий: цей хід не
    # вмирає від нового повідомлення користувача, тож субагент тут безпечний. Без
    # маркера гейт не відрізнить detached-агента від звичайного канального ходу
    # (у обох LOGOPSIS_RUNNER=1) і зациклив би агента на самого себе.
    env['LOGOPSIS_DETACHED_AGENT'] = '1'
    kw = dict(stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True,
              bufsize=1, env=env, **runner._PROC_GROUP_KW)
    if engine == _ENGINE_AGY:
        # Без закритого stdin `agy -p` чекає на ввід і висить назавжди. Та сама
        # пастка вже зловлена в runner.run_agy_stream. Гілка Клода лишається без
        # зміни: там stdin успадкований, як і був (К10).
        kw['stdin'] = subprocess.DEVNULL
    try:
        proc = subprocess.Popen(cmd, cwd=runner.REPO_ROOT, **kw)
    except Exception as e:
        return {'spawn_error': e}

    try:
        pgid = os.getpgid(proc.pid)
    except Exception:
        pgid = proc.pid
    # Реєструємо процес двигуна окремим job: воркер сидить у своїй групі, а двигун
    # у СВОЇЙ, тож сигнал групі воркера двигун не накриє. Стоп агента бʼє обидва
    # job-и через гейт (jobs.stop), а не по голому pid з диска.
    #
    # Тип job лишається 'agent-claude' і для Antigravity теж. Це не недогляд: тип
    # входить у RESERVED_KINDS і у фронтовий фільтр службових процесів, які НЕ
    # сповіщають тостом. Новий тип проліз би повз той фільтр, і кожен агент на
    # другому двигуні закінчувався б зайвим тостом. Правду про двигун несе meta.
    engine_job = jobs.register('agent-claude', channel, proc.pid, label=ctx['label'],
                               meta={'agentId': agent_id, 'sid': ctx['sid'],
                                     'engine': engine})
    # 'model' дописуємо РЕЗОЛВНУТИЙ, а не той, що прийшов у спеці. Спавн без --model клав
    # у status.json null, і панель агентів не мала що показати, хоча модель насправді відома.
    # Пишемо саме тут, у момент справжнього старту процесу, тому бейдж у UI показує
    # те, що реально крутиться, а не те, що попросили. 'engineUsed' поруч із тією ж
    # причини: запис мусить сам казати, ЧИМ агент думав, а не лишати це здогадкою.
    _write_status(channel, agent_id, {'state': 'running', 'pid': proc.pid, 'pgid': pgid,
                                      'claudeJobId': (engine_job or {}).get('jobId'),
                                      'sid': ctx['sid'], 'startedAt': _now(),
                                      'model': model_name, 'engineUsed': engine,
                                      'progressPct': 3, 'lastStep': 'старт'})
    runner.emit_event(channel, {'kind': 'agent', 'phase': 'start', 'name': ctx['label'],
                                'agentId': agent_id, 'detail': ctx['task'][:80]})

    st = {'steps': 0}
    note = _step_noter(channel, agent_id, st)
    if engine == _ENGINE_AGY:
        parsed = _parse_agy_stream(channel, agent_id, proc, note, st)
    else:
        parsed = _parse_claude_stream(channel, agent_id, proc, note, st)

    err_txt = ''
    try:
        err_txt = (proc.stderr.read() or '').strip()
    except Exception:
        err_txt = ''
    try:
        rc = proc.wait(timeout=10)
    except Exception:
        rc = proc.returncode

    if engine == _ENGINE_AGY:
        # Підсумок з події result, стрім лише як запасний варіант. Текст переміг
        # означає успіх, навіть якщо status приїхав ERROR: так само вирішує
        # run_agy_stream, і розходитись двом гілкам одного двигуна не можна.
        text = (parsed['final_text'] if parsed['final_text'] is not None
                else parsed['text'])
        result_err = '' if (text or '').strip() else _agy_cause(
            channel, parsed['status'], parsed['error'], parsed['step_errors'],
            err_txt, log_file)
        # stderr уже ВСЕРЕДИНІ причини, тому назовні його не віддаємо: інакше той
        # самий текст приїхав би в картку двічі. А лог agy на stderr пише службовий
        # шум glog, і взятий окремо він перетворив би тихий успіх на фейкову помилку.
        err_txt = ''
        # Причина відома означає, що хід завершився ПОЯСНЕНО, тобто це помилка, а не
        # обрив. Обрив у agy це «стрім скінчився, події result нема і сказати нічого».
        saw_result = parsed['saw_result'] or bool(result_err)
    else:
        text = parsed['text']
        result_err = parsed['result_err']
        saw_result = parsed['saw_result']

    return {'text': text, 'result_err': result_err, 'saw_result': saw_result,
            'rc': rc, 'err_txt': err_txt, 'job': engine_job,
            'stopped': _read_status(channel, agent_id).get('state') == 'stopped'}


def _failure_text(turn):
    """Та сама стрічка, за якою _run_impl вирішує «хід невдалий».

    Два різні провали, один вихід. `result_err` = двигун сам сказав «цей хід
    помилковий» (сюди потрапляє вичерпаний ліміт: процес при цьому виходить штатно
    і навіть несе текст). `rc != 0` без тексту = процес впав, не дійшовши до
    фінальної події."""
    body = (turn.get('text') or '').strip()
    return turn.get('result_err') or ('' if body else (turn.get('err_txt') or (
        f'agent exited rc={turn.get("rc")}' if turn.get('rc') not in (0, None) else '')))


def _bump_attempt(channel, agent_id):
    """Підняти лічильник спроб і віддати його нове значення.

    Лічильник живе В ЗАПИСІ АГЕНТА, а не в памʼяті процесу: воркер може бути
    перезапущений (реаттач сироти після рестарту сервера), і лічильник у памʼяті
    тоді обнулився б разом зі стелею К6, тобто квота горіла б і далі."""
    try:
        n = int(_read_status(channel, agent_id).get('modelAttempts') or 0)
    except Exception:
        n = 0
    n += 1
    _write_status(channel, agent_id, {'modelAttempts': n})
    return n


# Людські назви для картки підміни (S6, К7). Двигуни лишаються власними назвами в обох
# мовах (те саме рішення, що в PROVIDER_OPTIONS фронту: "Claude"/"Antigravity" не
# перекладаються). Рівні беруть ту саму пару слів, що вже показує фронт у
# model.<tier>.label (composer.ts): друга мапа тут не суперечить спеці, бо це
# ТЕКСТ КАРТКИ КАНАЛУ, який пише бек, а не ще один резолвер моделі.
_ENGINE_LABEL = {_ENGINE_CLAUDE: 'Claude', _ENGINE_AGY: 'Antigravity'}
_TIER_LABEL = {
    'haiku': {'uk': 'Швидкий', 'en': 'Fast'},
    'sonnet': {'uk': 'Баланс', 'en': 'Balanced'},
    'opus': {'uk': 'Розумний', 'en': 'Smart'},
    'fable': {'uk': 'Геній', 'en': 'Genius'},
}
_SWITCH_REASON_TEXT = {
    'limit': {'uk': '{engine} вичерпав ліміт.', 'en': '{engine} hit its usage limit.'},
    'engine-down': {'uk': '{engine} недоступний на цій машині.',
                    'en': '{engine} is unavailable on this machine.'},
}


def _engine_tier_text(entry, lang):
    """«Розумний · Claude» / «Smart · Claude»: рівень і двигун одним рядком.

    Невідомий рівень (теоретично можливий на побитому записі) не валить картку, а
    просто показує сам двигун: мовчати про факт підміни гірше, ніж не назвати рівень."""
    engine_label = _ENGINE_LABEL.get(entry['engine'], entry['engine'])
    tier = entry.get('tier')
    pair = _TIER_LABEL.get(tier) if tier else None
    tier_label = runner._lang_text(pair, lang) if pair else tier
    return f'{tier_label} · {engine_label}' if tier_label else engine_label


def _switch_reason_text(reason, frm, lang):
    """Причина людською мовою: який двигун підвів, а не голий код 'limit'/'engine-down'."""
    tpl = _SWITCH_REASON_TEXT.get(reason) or _SWITCH_REASON_TEXT['engine-down']
    return runner._lang_text(tpl, lang).format(engine=_ENGINE_LABEL.get(frm['engine'], frm['engine']))


def _switch_widgets(label, frm, to, reason, lang):
    """Картка миттєвого сповіщення про підміну (К7).

    Носій той самий, яким агент публікує свій результат (_post_card): другого не
    заводимо. Зміст дзеркалить те, що вже лягло у status.json['modelSwitch'] у
    _record_switch, лише людською мовою замість JSON, який панель «Процеси» і так
    показує бейджем, а решта каналу не читає взагалі."""
    head = {'type': 'header',
            'title': runner._lang_text({'uk': f'🔀 {label} · підміна моделі',
                                        'en': f'🔀 {label} · model switch'}, lang)}
    why = {'type': 'callout', 'variant': 'warning',
           'title': runner._lang_text({'uk': 'Перемкнувся на запасну модель',
                                       'en': 'Switched to the fallback model'}, lang),
           'text': _switch_reason_text(reason, frm, lang)}
    kv = {'type': 'key-values', 'items': [
        {'k': runner._lang_text({'uk': 'Було', 'en': 'Was'}, lang),
         'v': _engine_tier_text(frm, lang), 'color': 'slate'},
        {'k': runner._lang_text({'uk': 'Стало', 'en': 'Now'}, lang),
         'v': _engine_tier_text(to, lang), 'color': 'yellow'}]}
    concl = {'type': 'conclusion', 'tone': 'yellow',
             'text': runner._lang_text(
                 {'uk': 'Відповідь далі йде на запасній моделі.',
                  'en': 'The rest of the answer runs on the fallback model.'}, lang)}
    return [head, why, kv, concl]


def _record_switch(channel, agent_id, frm, to, reason, label, lang):
    """Слід підміни лягає на диск ОДРАЗУ, ще до запуску запасної, і карткою в канал.

    Тихої підміни не буває: це ризик №1 усієї фічі. Людина, яка отримала відповідь
    іншої якості і не знає чому, списує її на випадковість і перестає довіряти
    агентам узагалі. Тому слід пишеться навіть тоді, коли запасна впаде за секунду,
    і картка йде в канал одразу тут же, а не десь у фіналі ходу: до фіналу може лишитись
    ще довгий хід на запасній моделі, і людина мусить дізнатись про підміну ЗАРАЗ, а не
    постфактум разом з результатом."""
    rec = {'from': {'engine': frm['engine'], 'tier': frm['tier']},
           'to': {'engine': to['engine'], 'tier': to['tier']},
           'reason': reason, 'at': _now()}
    _write_status(channel, agent_id, {'modelSwitch': rec, 'engineUsed': to['engine']})
    _progress(channel, agent_id, dict(rec, phase='model-switch'))
    runner.log(f'agent {agent_id}: model switch {frm["engine"]}/{frm["tier"]} -> '
               f'{to["engine"]}/{to["tier"]} ({reason})')
    _post_card(channel, _switch_widgets(label, frm, to, reason, lang), from_name=label, tag='agent')
    return rec


def _run_impl(channel, agent_id):
    # К18 (латання оберту 3, Ревізор 3): мова ФІКСУЄТЬСЯ тут, ОДИН раз, на самому
    # старті ходу, і несеться крізь усю функцію тією самою змінною `lang`, а не
    # перечитується per-виклик через current_lang(channel). Було: заголовок і
    # службові підписи карти читали поточну мову В МОМЕНТ ЗАВЕРШЕННЯ, а тіло, яке
    # пише сам двигун, уже отримало мову, запечену в промпт на СТАРТІ (нижче,
    # agent_task_with_contract). Перемикання мови ПОСЕРЕД ходу давало картку з
    # заголовком однією мовою і тілом іншою в тому самому повідомленні.
    lang = runner.current_lang(None)
    spec = _read_status(channel, agent_id)
    task = (spec.get('task') or '').strip()
    label = spec.get('label') or runner._lang_text({'uk': 'Агент', 'en': 'Agent'}, lang)
    # claude --session-id must be a valid UUID; the server writes one, this is the fallback.
    sid = spec.get('sid') or str(uuid.uuid4())
    if not task:
        _write_status(channel, agent_id, {'state': 'error',
                      'summary': runner._lang_text({'uk': 'порожня задача', 'en': 'empty task'}, lang)})
        return

    ctx = {'lang': lang, 'label': label, 'sid': sid, 'task': task,
           'claude_bin': _claude_bin(),
           'model': spec.get('model') or runner.channel_model(channel, task),
           'effort': (spec.get('effort') or '').strip(),
           'body': runner.agent_task_with_contract(task, lang)}

    # Вибору нема -> запис двигуна синтезуємо з теперішнього ланцюга дефолтів
    # (модель зі спеки, далі модель каналу), запасної нема, і далі все йде рівно
    # тим самим шляхом, що й до правки (К10).
    choice = _model_choice(spec)
    entry = _engine_entry((choice or {}).get('primary')) or {
        'engine': _ENGINE_CLAUDE, 'tier': ctx['model'], 'id': None}
    spare = _engine_entry((choice or {}).get('fallback')) if choice else None
    if spare and spare['engine'] == entry['engine']:
        # Запасна на ТОМУ Ж двигуні не рятує ні від ліміту, ні від мертвого CLI.
        # Пару з одного двигуна відхиляє резолвер і API, але воркер довіряти
        # чужому запису на слово не мусить: тут ціна помилки це спалена квота.
        runner.log(f'agent {agent_id}: fallback on the same engine, ignored')
        spare = None

    # К5: двигуна основної моделі на цій машині просто нема. Це не «перезапуск», а
    # вибір ПЕРЕД стартом, тому спробу він не зʼїдає. Запасну зʼїдає, отже
    # наступний ліміт уже не матиме куди перемикатись і чесно покаже картку (К8).
    if spare and not _engine_ready(entry['engine']):
        _record_switch(channel, agent_id, entry, spare, 'engine-down', label, lang)
        entry, spare = spare, None

    while True:
        attempt = _bump_attempt(channel, agent_id)
        turn = _run_turn(channel, agent_id, ctx, entry)
        if turn.get('spawn_error') is not None:
            _write_status(channel, agent_id, {'state': 'error',
                          'summary': f'spawn failed: {turn["spawn_error"]}'})
            return
        if turn['stopped']:
            break
        # К6: РІВНО ОДНЕ перемикання. Другий ліміт поспіль третього запуску не
        # робить ніколи, навіть якби запасна ще лишалась: стеля стоїть на
        # лічильнику з диска, а не на тому, що ми памʼятаємо в цьому процесі.
        if (spare and attempt < _MAX_MODEL_ATTEMPTS
                and runner._is_usage_limit_error(_failure_text(turn))):
            try:
                jobs.finish((turn.get('job') or {}).get('jobId'), 'error')
            except Exception:
                pass
            _record_switch(channel, agent_id, entry, spare, 'limit', label, lang)
            entry, spare = spare, None
            continue
        break

    engine_job = turn.get('job')
    rc = turn['rc']
    saw_result = turn['saw_result']
    err_txt = turn['err_txt']

    # If /api/agent-stop marked us stopped, leave that state as-is.
    if _read_status(channel, agent_id).get('state') == 'stopped':
        _close_jobs(channel, agent_id, engine_job, 'stopped')
        runner.emit_event(channel, {'kind': 'agent', 'phase': 'stopped', 'name': label,
                                    'agentId': agent_id})
        return

    body = (turn['text'] or '').strip()
    # ОБРИВ: потік скінчився, а фінальної події двигуна не було. Хід не дійшов до кінця,
    # і те, що лежить у `text`, це не відповідь, а проза між викликами інструментів,
    # яку встигли накопичити дельти.
    #
    # Цього стану не існувало взагалі, і саме тому обрив приїжджав як УСПІХ. Гейт нижче
    # питає `'' if body else …`, тобто непорожній текст глушив перевірку коду виходу
    # цілком. Обірваний агент майже завжди має непорожній `body` (та сама проза між
    # кроками), тож у `done` його вело рівно те поле, яке мало б виказувати обрив.
    # Живий приклад: cae550, 91 крок, 231 байт прози, обірвано на `pytest`, у панелі
    # зелений `done` зі 100 відсотками, два тести червоні, коміту нема.
    #
    # Стан окремий, а НЕ 'error': помилка це коли двигун сам сказав, що хід невдалий,
    # і тоді причина відома і її можна написати. Тут причина невідома, і вдавати, що
    # знаємо, означало б повторити ту саму брехню з іншим знаком.
    if not saw_result:
        prev = _read_status(channel, agent_id)
        last_step = prev.get('lastStep') or ''
        # Відсоток лишається тим, на якому обірвало. Сотня тут була прямою брехнею:
        # вона читається як «дійшов до кінця», а він не дійшов.
        _write_status(channel, agent_id, {
            'state': 'truncated', 'completion': 'truncated', 'sawResult': False,
            'exitCode': rc, 'endedAt': _now(),
            'progressPct': prev.get('progressPct') or 0,
            'summary': runner._lang_text(
                {'uk': f'обрив на кроці «{last_step[:80]}» (код виходу {rc})',
                 'en': f'cut off at step "{last_step[:80]}" (exit code {rc})'}, lang)[:300]})
        # Недописане лягає на диск: це доказ і єдине, що від ходу лишилось.
        try:
            with open(os.path.join(_agent_dir(channel, agent_id), 'output.md'), 'w',
                      encoding='utf-8') as f:
                f.write(body)
        except Exception:
            pass
        _progress(channel, agent_id, {'phase': 'truncated', 'exitCode': rc,
                                      'step': last_step, 'bytes': len(body)})
        _close_jobs(channel, agent_id, engine_job, 'failed')
        runner.emit_event(channel, {'kind': 'agent', 'phase': 'truncated', 'name': label,
                                    'agentId': agent_id, 'detail': last_step[:140]})
        runner.log(f'agent {agent_id}: TRUNCATED rc={rc} step={last_step!r} '
                   f'body={len(body)}B stderr={err_txt[:160]!r}')
        _post_card(channel, _truncated_widgets(label, last_step, body, rc, lang),
                   from_name=label, tag='agent')
        return
    # Двигун failed (limit / bad args / auth / overload): surface the real reason, never
    # fake "done" and never dump the CLI's raw English into the feed. Обидва провали
    # йдуть через ті самі класифікатори чату, тож формулювання про ліміт у стрічці
    # одне, звідки б він не прилетів. Сюди ж приходить і той ліміт, після якого
    # запасної вже не лишилось (К8): поведінка тут не змінилась ні на слово.
    fail_err = _failure_text(turn)
    if fail_err:
        try:
            msg = runner.classify_failure(fail_err, False, channel)['text']
        except Exception:
            msg = runner._lang_text({'uk': 'Агент не довіз результат',
                                      'en': 'Agent did not deliver a result'}, lang)
        _write_status(channel, agent_id, {'state': 'error', 'progressPct': 100,
                      'completion': 'error', 'sawResult': saw_result, 'exitCode': rc,
                      'summary': msg[:300], 'endedAt': _now()})
        _close_jobs(channel, agent_id, engine_job, 'error')
        runner.emit_event(channel, {'kind': 'agent', 'phase': 'error', 'name': label,
                                    'agentId': agent_id, 'detail': msg[:300]})
        runner.log(f'agent {agent_id}: failed ({msg}) raw={fail_err[:120]!r}')
        cards = runner.agent_failure_widgets(label, fail_err, channel)
        # Ліміт може вдарити ПОСЕРЕД ходу, і тоді агент устиг щось написати. Викидати
        # це разом із помилкою = втратити готову роботу мовчки, тому недописане їде
        # окремим блоком під карткою, підписане як недописане.
        if body:
            # `body` тут це недописаний вивід ДВИГУНА: він уже несе мову, запечену
            # на старті (як і в _result_widgets), тому підпис до нього бере ту саму
            # заморожену `lang`, а не поточну current_lang(channel).
            cards.append({'type': 'text', 'detail': True,
                          'title': runner._lang_text(
                              {'uk': 'Що агент устиг написати до обриву',
                               'en': 'What the agent wrote before it broke off'}, lang),
                          'text': body})
        _post_card(channel, cards, from_name=label, tag='agent')
        return

    out = body or runner._lang_text({'uk': '(агент завершив без тексту)',
                                      'en': '(agent finished with no text)'}, lang)
    try:
        with open(os.path.join(_agent_dir(channel, agent_id), 'output.md'), 'w',
                  encoding='utf-8') as f:
            f.write(out)
    except Exception:
        pass
    widgets = _result_widgets(label, out, lang)
    # `sawResult`/`exitCode` пишемо і тут, щоб запис сам казав, ЧОМУ він done, а не
    # лишав це знанням у голові читача. Без цієї пари «done» і «обірвало» на диску
    # виглядали однаково, і відрізнити їх постфактум було нічим.
    _write_status(channel, agent_id, {'state': 'done', 'progressPct': 100,
                                      'completion': 'result', 'sawResult': True,
                                      'exitCode': rc,
                                      'summary': _summary_from(widgets, out),
                                      'endedAt': _now()})
    _close_jobs(channel, agent_id, engine_job, 'done')
    runner.emit_event(channel, {'kind': 'agent', 'phase': 'done', 'name': label,
                                'agentId': agent_id})
    # Заголовок окремим віджетом, а НЕ сирим HTML і не title поверх усього виводу:
    # V2 свідомо екранує розмітку (див. widgets/Text.tsx), а вивід тепер розібраний
    # на віджети, тож йому потрібна своя шапка, а не обгортка.
    _post_card(channel, widgets, from_name=label, tag='agent')


if __name__ == '__main__':
    if len(sys.argv) < 3:
        sys.stderr.write('usage: agent_worker.py <channel> <agentId>\n')
        sys.exit(2)
    run(sys.argv[1], sys.argv[2])
