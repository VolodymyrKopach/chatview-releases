import{b as r}from"./graph-DW8b2anh.js";var e=4;function a(o){return r(o,e)}export{a as c};
