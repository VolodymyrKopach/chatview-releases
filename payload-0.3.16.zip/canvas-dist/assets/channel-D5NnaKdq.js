import{aq as o,ar as n}from"./mermaid.core-SOfM48cj.js";const t=(r,a)=>o.lang.round(n.parse(r)[a]);export{t as c};
