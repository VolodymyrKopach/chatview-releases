#!/usr/bin/env python3
"""Хмарний синк Логопсісу (specs/logopsis-cloud-sync-sharing/spec.md, S2-S4).

ЩО ЦЕ. Диск лишається головним (local-first, розділ 6.1 спеки): усі писарі
(render-message.cjs, set-plan.cjs, хуки, агенти) і далі пишуть файли як писали.
Цей модуль ПОРУЧ дзеркалить три корені (chat-канали, стан гаджетів, дані канви) у
Supabase Storage bucket `homes` + реєстр `public.items`, від імені залогіненого
користувача (anon-ключ + його access-токен, тобто через RLS, БЕЗ service_role —
той самий контракт, що auth_store.py вже тримає для сесії).

ОДИН ФОНОВИЙ ТІК робить і push (локальне -> хмара), і pull (хмара -> локальне) за той
самий прохід, мірруючи `plan_autosync_tick.start_background_loop`: даемон-потік,
`tick()` ловить УСЕ і ніколи не кидає далі (К7 — синк не має права покласти сервер чи
завадити роботі з диска, коли мережі чи логіну нема).

БІЛИЙ СПИСОК, НЕ ЧОРНИЙ (спека, розділ 6.3 і ризики). `is_syncable_file` починається
з дозволених текстових розширень і стелі розміру; `keys.json`, `session.json`,
`.env*` виключені явним іменем НЕЗАЛЕЖНО від того, де вони лежать — навіть якщо
корінь синку колись розшириться, ці імена не поїдуть.

КОНФЛІКТИ (К8). Маніфест (`cloud-sync-state.json`, поруч із session.json під
LOGOPSIS_HOME, той самий gitignore-патерн `tools/viz/chat/*.json`) памʼятає хеш
кожного вже відданого в хмару файлу. На pull: якщо локальний вміст відрізняється від
хмарного І локальний хеш НЕ дорівнює тому, що ми самі востаннє відправили — це
справжній конфлікт (обидві машини змінили одне й те саме між синками), і програшна
версія лишається поруч як `<файл>.conflict-<epoch>`, а не зникає. Чат-файли повідомлень
(`NNNN.json`) це окремий, суворіший випадок: вони append-only (ризики спеки,
«чати тільки дописуються»), тому колізія номера НЕ перетирає, а перенумеровує вхідний
файл на перший вільний номер.
"""

import hashlib
import json
import os
import re
import sys
import threading
import time
from urllib.parse import quote

try:
    import requests
except ImportError:
    # Розданий бінарник requests не везе (заміряно на 0.3.14), а server.py імпортує цей
    # модуль на рівні модуля: без гарди старий застосунок після автооновлення не стартує.
    # Там синк вимкнений: tick() нижче пропускає прохід, хендлери шерингу віддають ok:false.
    requests = None

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import auth_store  # noqa: E402
import home_spread  # noqa: E402

# ─────────────────────────── конфіг ───────────────────────────

# Anon-ключ ПУБЛІЧНИЙ за задумом (config.ts у chatview: «доступ ріже RLS, а не
# секретність цього рядка»), тому дефолт хардкоджений тут так само, як
# LOCAL_SUPABASE_URL хардкоджений у фронті. Оточення (тести, локальний supabase
# start) перебиває обома змінними.
SUPABASE_URL = (os.environ.get('SUPABASE_URL') or 'https://dovtsykwjdjowmbhfhma.supabase.co').rstrip('/')
SUPABASE_ANON_KEY = os.environ.get('SUPABASE_ANON_KEY') or (
    'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImRvdnRzeWt3'
    'amRqb3dtYmhmaG1hIiwicm9sZSI6ImFub24iLCJpYXQiOjE3ODg4ODgxNzMsImV4cCI6MjEwNDQ2NDE3M30'
    '.35OXIgarMJIxdLdxMSfpwXgmPbseUEeAnQ69Qj5D8Fo'
)
BUCKET = 'homes'

TICK_INTERVAL_SECONDS = 20
# Файл мусить лишатись незмінним стільки секунд, перш ніж push його забирає: інакше
# синк ловить файл ПІД ЧАС запису (writer ще не дописав JSON) і вантажить биту половину.
DEBOUNCE_SECONDS = 3
HTTP_TIMEOUT = 20

# Білий список (спека 6.3): текстові розширення, до порогу розміру.
TEXT_EXTENSIONS = {'.json', '.jsonl', '.md', '.txt', '.html', '.htm', '.csv', '.yaml', '.yml'}
MAX_SYNC_BYTES = 2 * 1024 * 1024

# Секрети — заборонені за ІМЕНЕМ, незалежно від розширення чи кореня (ризики спеки:
# «синк підхопить секрети», тест на це — tests/unit/test_cloud_sync.py).
_DENY_BASENAMES = {'keys.json', 'session.json', 'user-settings.json'}


def _is_secret_or_denied(basename):
    if basename in _DENY_BASENAMES:
        return True
    if basename.startswith('.env'):
        return True
    return False


def is_syncable_file(path):
    """Чи пускаємо ЦЕЙ файл у хмару. Білий список спершу, заборона іменем — завжди
    останнім і безумовним словом, навіть якщо колись розширять список розширень."""
    base = os.path.basename(path)
    if _is_secret_or_denied(base):
        return False
    ext = os.path.splitext(base)[1].lower()
    if ext not in TEXT_EXTENSIONS:
        return False
    try:
        size = os.path.getsize(path)
    except OSError:
        return False
    if size > MAX_SYNC_BYTES:
        return False
    return True


_MIME_BY_EXT = {
    '.json': 'application/json', '.jsonl': 'application/x-ndjson', '.md': 'text/markdown',
    '.txt': 'text/plain', '.html': 'text/html', '.htm': 'text/html', '.csv': 'text/csv',
    '.yaml': 'application/yaml', '.yml': 'application/yaml',
}


def _content_type(path):
    return _MIME_BY_EXT.get(os.path.splitext(path)[1].lower(), 'application/octet-stream')


def _sha1_file(path):
    h = hashlib.sha1()
    with open(path, 'rb') as f:
        for chunk in iter(lambda: f.read(1 << 16), b''):
            h.update(chunk)
    return h.hexdigest()


def _sha1_bytes(data):
    return hashlib.sha1(data).hexdigest()


# ─────────────────────────── ідентифікація коренів (специфіка Logopsis) ───────────────
# Ідентична розвилка дев-репо/пакована збірка, що вже тримає home_spread.py: у пакованій
# збірці `home` це LOGOPSIS_HOME, у дев-репо `home` це tools/viz/chat, і корені рахуються
# від нього. Модуль сам нічого не вигадує, лише читає ці функції.

def _chat_root(home):
    return os.path.join(home, 'channels')


def _gadget_root(home):
    return home_spread.gadget_state_root(home=home)


def _canvas_root(home):
    return home_spread.canvas_root(home=home)


# Канва: єдиний спільний tldraw-документ (`canvas-state.json`, 2.2 МБ), НЕ по файлу на
# сторінку — усі сторінки лежать в ОДНОМУ store всередині нього (заміряно 2026-09-23:
# 24 сторінки, 1443 shape в одному JSON). `canvas-tombstones.json` (журнал видалень)
# їде поруч тим самим item_id, бо це той самий машинно-локальний стан. РЕШТА
# `tools/canvas-cmd/data/*.json` (858 файлів) уже ЖИВЕ в git (перевірено:
# `git check-ignore` каже НІ на випадковий файл з цієї теки), тобто вже подорожує між
# машинами через репозиторій — синкати її вдруге тут значило б дублювати чужий канал
# доставки без потреби.
CANVAS_ITEM_ID = 'main'
_CANVAS_FILES = ('canvas-state.json', 'canvas-tombstones.json')

_CHAT_ROOT_ITEM_ID = '_root'   # channels/index.json — реєстр, не окремий чат
_CHAT_ROOT_FILES = ('index.json',)

_MSG_FILE_RE = re.compile(r'^(\d{4,})\.json$')


def _discover_items(home):
    """(kind, item_id, item_root) для кожної речі, яку МОЖЕ мати сенс синкати.

    Директорія-кандидат, що починається з `_`/`.`, пропускається: це службові теки
    (`_media` — 1260 МБ медіа, яке й так відсіє білий список розширень, але прохід
    по 30k файлів заради нуля результату шкодить часу першого заливу)."""
    out = []
    chat_root = _chat_root(home)
    if os.path.isdir(chat_root):
        if os.path.isfile(os.path.join(chat_root, 'index.json')):
            out.append(('chat', _CHAT_ROOT_ITEM_ID, chat_root))
        for name in sorted(os.listdir(chat_root)):
            if name.startswith('_') or name.startswith('.'):
                continue
            full = os.path.join(chat_root, name)
            if os.path.isdir(full):
                out.append(('chat', name, full))
    gadget_root = _gadget_root(home)
    if os.path.isdir(gadget_root):
        for name in sorted(os.listdir(gadget_root)):
            if name.startswith('_') or name.startswith('.'):
                continue
            full = os.path.join(gadget_root, name)
            if os.path.isdir(full):
                out.append(('gadget', name, full))
    canvas_root = _canvas_root(home)
    if os.path.isdir(canvas_root) and any(
            os.path.isfile(os.path.join(canvas_root, f)) for f in _CANVAS_FILES):
        out.append(('canvas', CANVAS_ITEM_ID, canvas_root))
    return out


def _item_root(home, kind, item_id):
    if kind == 'chat':
        return _chat_root(home) if item_id == _CHAT_ROOT_ITEM_ID else os.path.join(_chat_root(home), item_id)
    if kind == 'gadget':
        return os.path.join(_gadget_root(home), item_id)
    if kind == 'canvas':
        return _canvas_root(home)
    raise ValueError('невідомий kind: %r' % (kind,))


def _gadget_code_dir(home, item_id):
    """Тека КОДУ гаджета (`apps/<id>/manifest.json`, `view.html`, ...), окремо від
    стану (`apps/_state/<id>/`, це `_item_root`/`_gadget_root`). Розділ 7 спеки:
    «гаджет їде разом з кодом», інакше отримувач має стан без чим його відкрити."""
    import entities
    return entities.path_for('gadget', item_id, home=home)


def _walk_prefixed(root, prefix):
    if not os.path.isdir(root):
        return
    for dirpath, dirnames, filenames in os.walk(root):
        dirnames[:] = [d for d in dirnames if not d.startswith('.')]
        for fn in filenames:
            full = os.path.join(dirpath, fn)
            rel = os.path.relpath(full, root).replace(os.sep, '/')
            yield prefix + rel, full


def _iter_item_files(kind, item_id, item_root, home=None):
    """(relpath, fullpath) кандидатів усередині ОДНІЄЇ речі. Не фільтрує білим
    списком — це робить викликач (`is_syncable_file`), тут лише «де шукати».

    Гаджет — єдиний kind з ДВОМА фізичними коренями (код + стан): relpath несе
    префікс `code/`/`state/`, щоб push/pull знали, куди саме писати на диску."""
    if kind == 'chat' and item_id == _CHAT_ROOT_ITEM_ID:
        for name in _CHAT_ROOT_FILES:
            p = os.path.join(item_root, name)
            if os.path.isfile(p):
                yield name, p
        return
    if kind == 'canvas':
        for name in _CANVAS_FILES:
            p = os.path.join(item_root, name)
            if os.path.isfile(p):
                yield name, p
        return
    if kind == 'gadget':
        if home is not None:
            yield from _walk_prefixed(_gadget_code_dir(home, item_id), 'code/')
        yield from _walk_prefixed(item_root, 'state/')
        return
    yield from _walk_prefixed(item_root, '')


# ─────────────────────────── маніфест (resumable, ризик спеки) ───────────────────────────

def _manifest_path(home):
    # `tools/viz/chat/*.json` — уже широке правило .gitignore (те саме, що ховає
    # session.json поруч), нового рядка не треба.
    return os.path.join(home, 'cloud-sync-state.json')


def _load_manifest(home, owner_id):
    path = _manifest_path(home)
    try:
        with open(path, encoding='utf-8') as f:
            data = json.load(f)
    except Exception:
        data = {}
    if not isinstance(data, dict) or data.get('owner_id') != owner_id:
        # Зміна власника на цій машині (інший логін) або перший запуск: чистий старт,
        # а не змішування чужих хешів під однією текою.
        data = {'owner_id': owner_id, 'uploaded': {}, 'items': {}}
    data.setdefault('uploaded', {})
    data.setdefault('items', {})
    return data


def _save_manifest(home, manifest):
    path = _manifest_path(home)
    tmp = '%s.%d.%d.tmp' % (path, os.getpid(), threading.get_ident())
    try:
        with open(tmp, 'w', encoding='utf-8') as f:
            json.dump(manifest, f, ensure_ascii=False, indent=2)
            f.flush()
            os.fsync(f.fileno())
        os.replace(tmp, path)
    except Exception:
        try:
            os.remove(tmp)
        except Exception:
            pass
        raise


# ─────────────────────────── токен (переживає протухання, К7) ───────────────────────────

def get_valid_token(home, log=None):
    """(access_token, user_id) поточної сесії, оновлений якщо протух. (None, None),
    якщо не залогінений АБО мережі нема — обидва випадки це «пропустити цей тік», а
    не виняток: К7 забороняє синку валити щось через відсутність мережі/логіну."""
    session = auth_store.read_session(home)
    if not session:
        return None, None
    exp = session.get('expires_at')
    now = time.time()
    if exp and (exp - now) > 60:
        return session['access_token'], session['user_id']
    try:
        r = requests.post(
            SUPABASE_URL + '/auth/v1/token', params={'grant_type': 'refresh_token'},
            json={'refresh_token': session['refresh_token']},
            headers={'apikey': SUPABASE_ANON_KEY}, timeout=HTTP_TIMEOUT)
        r.raise_for_status()
        data = r.json()
        new_session = {
            'user_id': (data.get('user') or {}).get('id') or session['user_id'],
            'email': (data.get('user') or {}).get('email'),
            'access_token': data['access_token'],
            'refresh_token': data['refresh_token'],
            'expires_at': int(now) + int(data.get('expires_in') or 3600),
            'saved_at': int(now * 1000),
        }
        # Записуємо назад у ТОЙ САМИЙ session.json, який читає фронт: інакше наступний
        # рефреш фронта прийде зі старим (уже використаним, ротованим) refresh_token
        # і Supabase його відхилить — живий вхід зламав би саме цей фоновий синк.
        auth_store.write_session(home, new_session)
        return new_session['access_token'], new_session['user_id']
    except Exception as e:
        if log:
            log('cloud_sync: token refresh failed (offline?): %s' % e)
        return None, None


def _headers(token):
    return {'apikey': SUPABASE_ANON_KEY, 'Authorization': 'Bearer ' + token}


# ─────────────────────────── Storage HTTP ───────────────────────────

def _object_url(path):
    return '%s/storage/v1/object/%s/%s' % (SUPABASE_URL, BUCKET, quote(path, safe='/'))


def upload_object(token, path, local_file, log=None):
    try:
        with open(local_file, 'rb') as f:
            data = f.read()
        r = requests.post(
            _object_url(path), data=data,
            headers={**_headers(token), 'Content-Type': _content_type(local_file), 'x-upsert': 'true'},
            timeout=HTTP_TIMEOUT)
        if r.status_code >= 300:
            if log:
                log('cloud_sync: upload %s -> HTTP %s %s' % (path, r.status_code, r.text[:200]))
            return False
        return True
    except Exception as e:
        if log:
            log('cloud_sync: upload %s failed: %s' % (path, e))
        return False


def download_object(token, path, log=None):
    try:
        r = requests.get(_object_url(path), headers=_headers(token), timeout=HTTP_TIMEOUT)
        if r.status_code >= 300:
            if log:
                log('cloud_sync: download %s -> HTTP %s' % (path, r.status_code))
            return None
        return r.content
    except Exception as e:
        if log:
            log('cloud_sync: download %s failed: %s' % (path, e))
        return None


def list_objects_recursive(token, prefix, log=None, _depth=0):
    """Файли (не «теки») під `prefix`, рекурсивно. Storage `list` віддає лише один
    рівень (папка = запис без `id`), тому теки обходимо самі; глибина обмежена (6) —
    захист від випадкового циклу, реальна вкладеність тут 1-2 рівні."""
    if _depth > 6:
        return []
    out = []
    offset = 0
    limit = 100
    while True:
        try:
            r = requests.post(
                '%s/storage/v1/object/list/%s' % (SUPABASE_URL, BUCKET),
                json={'prefix': prefix, 'limit': limit, 'offset': offset,
                      'sortBy': {'column': 'name', 'order': 'asc'}},
                headers={**_headers(token), 'Content-Type': 'application/json'},
                timeout=HTTP_TIMEOUT)
            r.raise_for_status()
            page = r.json()
        except Exception as e:
            if log:
                log('cloud_sync: list %s failed: %s' % (prefix, e))
            return out
        if not page:
            break
        for entry in page:
            name = entry.get('name')
            if not name:
                continue
            full = prefix.rstrip('/') + '/' + name
            if entry.get('id') is None and entry.get('metadata') is None:
                out.extend(list_objects_recursive(token, full, log=log, _depth=_depth + 1))
            else:
                out.append({'path': full, 'updated_at': entry.get('updated_at'),
                             'size': (entry.get('metadata') or {}).get('size')})
        if len(page) < limit:
            break
        offset += limit
    return out


# ─────────────────────────── items (PostgREST) ───────────────────────────

def upsert_item(token, owner_id, kind, item_id, title=None, log=None):
    try:
        r = requests.post(
            SUPABASE_URL + '/rest/v1/items',
            params={'on_conflict': 'owner_id,kind,item_id'},
            json=[{'owner_id': owner_id, 'kind': kind, 'item_id': item_id,
                   'title': title or item_id, 'updated_at': _iso_now()}],
            headers={**_headers(token), 'Content-Type': 'application/json',
                     'Prefer': 'resolution=merge-duplicates,return=minimal'},
            timeout=HTTP_TIMEOUT)
        if r.status_code >= 300:
            if log:
                log('cloud_sync: upsert item %s/%s -> HTTP %s %s' % (kind, item_id, r.status_code, r.text[:200]))
            return False
        return True
    except Exception as e:
        if log:
            log('cloud_sync: upsert item %s/%s failed: %s' % (kind, item_id, e))
        return False


def list_my_items(token, log=None):
    """Рядки items, видимі МЕНІ (RLS: свої + розшарені мені), без розпублікованих
    (`deleted_at`) — розділ 7 спеки: тамбстоун не тягнемо назад на диск."""
    try:
        r = requests.get(SUPABASE_URL + '/rest/v1/items',
                          params={'select': '*', 'deleted_at': 'is.null'},
                          headers=_headers(token), timeout=HTTP_TIMEOUT)
        r.raise_for_status()
        return r.json()
    except Exception as e:
        if log:
            log('cloud_sync: list items failed: %s' % e)
        return []


def list_published_owned_items(token, owner_id, log=None):
    """Речі, які Я вже опублікував(-ла) (маю живий рядок items, не тамбстоун).
    Розділ 7 спеки — це і є вибірка для push: рядок items тут зʼявляється ЛИШЕ
    через `share_item` (перше «Поділитись»), тому приватна річ без жодного
    натискання цієї кнопки сюди ніколи не потрапляє (К0)."""
    try:
        r = requests.get(
            SUPABASE_URL + '/rest/v1/items',
            params={'owner_id': 'eq.%s' % owner_id, 'deleted_at': 'is.null', 'select': '*'},
            headers=_headers(token), timeout=HTTP_TIMEOUT)
        r.raise_for_status()
        return r.json()
    except Exception as e:
        if log:
            log('cloud_sync: list published items failed: %s' % e)
        return []


def _get_item_row(token, owner_id, kind, item_id, log=None):
    try:
        r = requests.get(
            SUPABASE_URL + '/rest/v1/items',
            params={'owner_id': 'eq.%s' % owner_id, 'kind': 'eq.%s' % kind,
                    'item_id': 'eq.%s' % item_id, 'select': '*'},
            headers=_headers(token), timeout=HTTP_TIMEOUT)
        r.raise_for_status()
        rows = r.json()
        return rows[0] if rows else None
    except Exception as e:
        if log:
            log('cloud_sync: get item row failed: %s' % e)
        return None


def _iso_now():
    return time.strftime('%Y-%m-%dT%H:%M:%S.000Z', time.gmtime())


# ─────────────────────────── шеринг (розділ 7 спеки: «Поділитись» публікує) ───────────────

def share_item(token, owner_id, kind, item_id, grantee_email, role, home=None, log=None):
    """«Поділитись»: перше натискання ПУБЛІКУЄ річ — заводить рядок items (якщо
    його ще нема) і рядок shares, і одразу штовхає пуш САМЕ цієї речі окремим
    потоком (не чекаючи фонового тіка до 20с). Далі річ живе в звичайному
    фоновому синку (К1), бо вона тепер є у `list_published_owned_items`."""
    grantee_email = (grantee_email or '').strip().lower()
    if not grantee_email or role not in ('view', 'edit'):
        return False
    if not upsert_item(token, owner_id, kind, item_id, log=log):
        return False
    row = _get_item_row(token, owner_id, kind, item_id, log=log)
    if not row:
        return False
    try:
        r = requests.post(
            SUPABASE_URL + '/rest/v1/shares',
            params={'on_conflict': 'item_id,grantee_email'},
            json=[{'item_id': row['id'], 'grantee_email': grantee_email, 'role': role}],
            headers={**_headers(token), 'Content-Type': 'application/json',
                     'Prefer': 'resolution=merge-duplicates,return=minimal'},
            timeout=HTTP_TIMEOUT)
        if r.status_code >= 300:
            if log:
                log('cloud_sync: share %s/%s -> %s HTTP %s %s' % (
                    kind, item_id, grantee_email, r.status_code, r.text[:200]))
            return False
    except Exception as e:
        if log:
            log('cloud_sync: share failed: %s' % e)
        return False
    if home:
        threading.Thread(
            target=push_once,
            kwargs={'home': home, 'token': token, 'owner_id': owner_id, 'log': log,
                    'published': [{'kind': kind, 'item_id': item_id}]},
            daemon=True, name='cloud-sync-share-push').start()
    return True


def list_shares(token, owner_id, kind, item_id, log=None):
    row = _get_item_row(token, owner_id, kind, item_id, log=log)
    if not row:
        return []
    try:
        r = requests.get(SUPABASE_URL + '/rest/v1/shares',
                          params={'item_id': 'eq.%s' % row['id'], 'select': '*'},
                          headers=_headers(token), timeout=HTTP_TIMEOUT)
        r.raise_for_status()
        return r.json()
    except Exception as e:
        if log:
            log('cloud_sync: list shares failed: %s' % e)
        return []


def list_shared_with_me(token, owner_id, log=None):
    """Речі, розшарені МЕНІ (не мій owner_id серед видимого через RLS)."""
    rows = list_my_items(token, log=log)
    return [row for row in rows if row.get('owner_id') != owner_id]


def revoke_share(token, owner_id, kind, item_id, grantee_email, log=None):
    """Забрати доступ. Коли це був ОСТАННІЙ рядок shares цієї речі — розпублікувати
    (розділ 7 спеки): прибрати обʼєкти зі Storage і позначити items.deleted_at.
    Локальний оригінал власника на диску НЕ чіпається (лише хмара)."""
    grantee_email = (grantee_email or '').strip().lower()
    row = _get_item_row(token, owner_id, kind, item_id, log=log)
    if not row:
        return False
    try:
        r = requests.delete(
            SUPABASE_URL + '/rest/v1/shares',
            params={'item_id': 'eq.%s' % row['id'], 'grantee_email': 'eq.%s' % grantee_email},
            headers=_headers(token), timeout=HTTP_TIMEOUT)
        if r.status_code >= 300:
            if log:
                log('cloud_sync: revoke %s/%s -> HTTP %s' % (kind, item_id, r.status_code))
            return False
    except Exception as e:
        if log:
            log('cloud_sync: revoke failed: %s' % e)
        return False
    if not list_shares(token, owner_id, kind, item_id, log=log):
        _unpublish_item(token, owner_id, row['id'], kind, item_id, log=log)
    return True


def _unpublish_item(token, owner_id, items_row_id, kind, item_id, log=None):
    prefix = '%s/%s/%s' % (owner_id, kind, item_id)
    objects = list_objects_recursive(token, prefix, log=log)
    paths = [o['path'] for o in objects]
    if paths:
        try:
            requests.delete(SUPABASE_URL + '/storage/v1/object/' + BUCKET,
                             json={'prefixes': paths}, headers=_headers(token), timeout=HTTP_TIMEOUT)
        except Exception as e:
            if log:
                log('cloud_sync: unpublish storage delete failed: %s' % e)
    try:
        requests.patch(
            SUPABASE_URL + '/rest/v1/items', params={'id': 'eq.%s' % items_row_id},
            json={'deleted_at': _iso_now()},
            headers={**_headers(token), 'Content-Type': 'application/json', 'Prefer': 'return=minimal'},
            timeout=HTTP_TIMEOUT)
    except Exception as e:
        if log:
            log('cloud_sync: unpublish items patch failed: %s' % e)


# ─────────────────────────── push (локальне -> хмара) ───────────────────────────

def push_once(home, token, owner_id, log=None, stats=None, published=None):
    """Пуш ЛИШЕ речей, уже опублікованих через «Поділитись» (розділ 7 спеки, К0):
    приватне без рядка `items` синку не бачить і на диск хмари не їде. Вибірка —
    `list_published_owned_items` (живий запит), або підставлена напряму викликачем
    (`share_item` для миттєвого штовху ОДНІЄЇ речі; тести — без мережі)."""
    stats = stats if stats is not None else {'files': 0, 'bytes': 0, 'items': 0}
    manifest = _load_manifest(home, owner_id)
    now = time.time()
    rows = published if published is not None else list_published_owned_items(token, owner_id, log=log)
    for row in rows:
        kind, item_id = row.get('kind'), row.get('item_id')
        item_root = _item_root(home, kind, item_id)
        touched = False
        for relpath, full in _iter_item_files(kind, item_id, item_root, home=home):
            if not is_syncable_file(full):
                continue
            try:
                st = os.stat(full)
            except OSError:
                continue
            key = '%s/%s/%s' % (kind, item_id, relpath)
            cached = manifest['uploaded'].get(key)
            if cached and cached.get('mtime') == st.st_mtime and cached.get('size') == st.st_size:
                continue
            if (now - st.st_mtime) < DEBOUNCE_SECONDS:
                continue  # щойно змінився: дати писарю дописати, спробувати наступний тік
            h = _sha1_file(full)
            if cached and cached.get('hash') == h:
                manifest['uploaded'][key] = {**cached, 'mtime': st.st_mtime, 'size': st.st_size}
                continue
            obj_path = '%s/%s/%s/%s' % (owner_id, kind, item_id, relpath)
            if upload_object(token, obj_path, full, log=log):
                manifest['uploaded'][key] = {'hash': h, 'size': st.st_size, 'mtime': st.st_mtime,
                                              'uploaded_at': now}
                touched = True
                stats['files'] += 1
                stats['bytes'] += st.st_size
        if touched:
            if upsert_item(token, owner_id, kind, item_id, log=log):
                manifest['items'].setdefault('%s/%s' % (kind, item_id), {})['pushed_at'] = now
                stats['items'] += 1
    _save_manifest(home, manifest)
    return stats


# ─────────────────────────── pull (хмара -> локальне) ───────────────────────────

def _next_free_message_number(dirpath):
    best = 0
    try:
        for name in os.listdir(dirpath):
            m = _MSG_FILE_RE.match(name)
            if m:
                best = max(best, int(m.group(1)))
    except OSError:
        pass
    width = max(4, len(str(best + 1)))
    return str(best + 1).zfill(width) + '.json'


def _write_bytes_atomic(path, data):
    os.makedirs(os.path.dirname(path), exist_ok=True)
    tmp = '%s.%d.%d.tmp' % (path, os.getpid(), threading.get_ident())
    with open(tmp, 'wb') as f:
        f.write(data)
        f.flush()
        os.fsync(f.fileno())
    os.replace(tmp, path)


def _apply_downloaded_file(kind, item_root, relpath, content, remote_updated_iso, manifest, key, log=None):
    """Один файл з хмари -> диск, із конфліктним розгалуженням (К8).

    Чат-повідомлення (NNNN.json) НІКОЛИ не перетираються: колізія номера
    перенумеровується на перший вільний слот (append-only, ризики спеки)."""
    local_path = os.path.join(item_root, relpath)
    remote_hash = _sha1_bytes(content)
    is_msg_file = kind == 'chat' and '/' not in relpath and _MSG_FILE_RE.match(relpath)

    if not os.path.exists(local_path):
        _write_bytes_atomic(local_path, content)
        manifest['uploaded'][key] = {'hash': remote_hash, 'size': len(content),
                                      'mtime': os.path.getmtime(local_path), 'uploaded_at': time.time()}
        return 'downloaded'

    local_hash = _sha1_file(local_path)
    if local_hash == remote_hash:
        return 'same'

    if is_msg_file:
        new_name = _next_free_message_number(item_root)
        _write_bytes_atomic(os.path.join(item_root, new_name), content)
        if log:
            log('cloud_sync: колізія номера %s -> перенумеровано в %s' % (relpath, new_name))
        return 'renumbered:' + new_name

    cached = manifest['uploaded'].get(key)
    ts = int(time.time())
    if cached and cached.get('hash') == local_hash:
        # Локальне не змінювалось відтоді, як МИ його востаннє відправили — хмара
        # просто новіша, безпечно перетерти без конфліктної копії.
        _write_bytes_atomic(local_path, content)
        manifest['uploaded'][key] = {'hash': remote_hash, 'size': len(content),
                                      'mtime': os.path.getmtime(local_path), 'uploaded_at': time.time()}
        return 'overwritten'

    # Справжній конфлікт: обидві сторони змінили незалежно. Пізніша стає основною.
    local_mtime = os.path.getmtime(local_path)
    remote_mtime = _parse_iso(remote_updated_iso) or time.time()
    if remote_mtime >= local_mtime:
        conflict_path = '%s.conflict-%d' % (local_path, ts)
        os.replace(local_path, conflict_path)
        _write_bytes_atomic(local_path, content)
        manifest['uploaded'][key] = {'hash': remote_hash, 'size': len(content),
                                      'mtime': os.path.getmtime(local_path), 'uploaded_at': time.time()}
        return 'conflict:remote-won'
    else:
        conflict_path = '%s.conflict-%d' % (local_path, ts)
        _write_bytes_atomic(conflict_path, content)
        return 'conflict:local-won'


def _parse_iso(s):
    if not s:
        return None
    try:
        s2 = s.replace('Z', '+00:00')
        if '.' in s2:
            head, rest = s2.split('.', 1)
            if '+' in rest:
                frac, tz = rest.split('+', 1)
                tz = '+' + tz
            else:
                frac, tz = rest, ''
            s2 = head + '.' + frac[:6].ljust(6, '0') + tz
        from datetime import datetime
        return datetime.fromisoformat(s2).timestamp()
    except Exception:
        return None


def pull_once(home, token, log=None, stats=None):
    stats = stats if stats is not None else {'files': 0, 'items': 0, 'conflicts': 0}
    rows = list_my_items(token, log=log)
    if not rows:
        return stats
    session = auth_store.read_session(home) or {}
    manifest = _load_manifest(home, session.get('user_id') or 'unknown')
    for row in rows:
        kind, item_id = row.get('kind'), row.get('item_id')
        owner_id = row.get('owner_id')
        cloud_updated = row.get('updated_at')
        ikey = '%s/%s' % (kind, item_id)
        if manifest['items'].get(ikey, {}).get('pulled_cloud_updated_at') == cloud_updated:
            continue
        item_root = _item_root(home, kind, item_id)
        os.makedirs(item_root, exist_ok=True)
        code_root = None
        if kind == 'gadget':
            code_root = _gadget_code_dir(home, item_id)
            os.makedirs(code_root, exist_ok=True)
        prefix = '%s/%s/%s' % (owner_id, kind, item_id)
        objects = list_objects_recursive(token, prefix, log=log)
        for obj in objects:
            relpath = obj['path'][len(prefix):].lstrip('/')
            content = download_object(token, obj['path'], log=log)
            if content is None:
                continue
            fkey = '%s/%s' % (ikey, relpath)
            if kind == 'gadget':
                # Гаджет має ДВА фізичні корені (код+стан, розділ 7 спеки) під
                # ОДНИМ items-рядком: relpath несе префікс, що вирішує, куди писати.
                if relpath.startswith('code/'):
                    target_root, sub_rel = code_root, relpath[len('code/'):]
                elif relpath.startswith('state/'):
                    target_root, sub_rel = item_root, relpath[len('state/'):]
                else:
                    continue  # незнайомий префікс: захисно пропускаємо, не гадаємо
            else:
                target_root, sub_rel = item_root, relpath
            outcome = _apply_downloaded_file(kind, target_root, sub_rel, content,
                                              obj.get('updated_at'), manifest, fkey, log=log)
            if outcome:
                stats['files'] += 1
            if outcome and outcome.startswith('conflict'):
                stats['conflicts'] += 1
        manifest['items'].setdefault(ikey, {})['pulled_cloud_updated_at'] = cloud_updated
        stats['items'] += 1
    _save_manifest(home, manifest)
    return stats


# ─────────────────────────── тік і фоновий цикл ───────────────────────────

def tick(home=None, log=None):
    """Один прохід: push, потім pull. Ловить УСЕ (К7): відсутність логіну чи мережі
    ніколи не має права зупинити застосунок чи навіть просто спливти у консоль
    незрозумілим трейсом."""
    home = home or os.environ.get('LOGOPSIS_HOME') or os.path.dirname(os.path.abspath(__file__))
    if requests is None:
        return {'skipped': 'requests-not-bundled'}
    try:
        token, uid = get_valid_token(home, log=log)
        if not token or not uid:
            return {'skipped': 'not-logged-in-or-offline'}
        push_stats = push_once(home, token, uid, log=log)
        pull_stats = pull_once(home, token, log=log)
        return {'push': push_stats, 'pull': pull_stats}
    except Exception as e:
        if log:
            log('cloud_sync: tick failed: %s' % e)
        return {'error': str(e)}


def start_background_loop(home=None, interval=None, log=None):
    """Даемон-потік, той самий патерн, що `plan_autosync_tick.start_background_loop`:
    fire-and-forget, server.py кличе рівно раз при старті."""
    step = TICK_INTERVAL_SECONDS if interval is None else interval

    def _loop():
        while True:
            tick(home=home, log=log)
            time.sleep(step)

    thread = threading.Thread(target=_loop, daemon=True, name='cloud-sync-tick')
    thread.start()
    return thread


def trigger_pull_now(home=None, log=None):
    """Одноразовий негайний тік ПІСЛЯ логіну (К2: «коли користувач логіниться...»),
    а не чекати до 20с наступного фонового проходу. Свій потік, не блокує відповідь
    HTTP на /api/auth-session."""
    threading.Thread(target=tick, kwargs={'home': home, 'log': log},
                      daemon=True, name='cloud-sync-login-pull').start()
