#!/usr/bin/env python3
"""Two-way Chat View runner.

Polls per-channel prompt queues written by server.py's POST /api/send, runs a
headless Claude Code session per channel (one channel = one claude session id =
one /resume-able conversation visible in VSCode history), and writes the
assistant reply back into the same channel as a widget bubble.

Storage contract (shared with server.py, no DB):
  channels/<id>/session-id        one-line UUID bound to this conversation
  channels/<id>/queue/NNNN.json   {text, session_id, user_msg_id, qid, attachments,
                                  runtime: {model, effort}, ts}
                                  `runtime` = знімок налаштувань НА МОМЕНТ ВІДПРАВКИ
                                  (server.py _runtime_snapshot / server.cjs
                                  runtimeSnapshot). Модель і зусилля це властивість
                                  МЕСЕДЖА, а не каналу: хід виконується тим, що було
                                  чинним, коли меседж поставили в чергу, тож зміна
                                  налаштувань діє лише на наступні відправки.
                                  Ключа може не бути (файл, створений до цієї правки):
                                  тоді беруться поточні файли каналу, див. job_runtime.
  channels/<id>/busy              presence = runner is working on this channel
  channels/<id>/live.json         transient live turn state (steps + streaming
                                  text); written during a turn, deleted at the
                                  end. The front end polls /api/channel-state and
                                  renders it as the "live progress" panel.
  channels/<id>/NNNN.json         message bubble (widget array)
  channels/<id>/index.json        message metadata index
                                  Запис ВІДПОВІДІ додатково несе
                                  `replyTo: {id, snippet}` — якір на бульбашку
                                  користувача, з якої хід стартував. id береться
                                  з `user_msg_id` файлу черги (те саме джерело,
                                  що в mark_turn_failed), snippet це початок
                                  тексту тієї бульбашки. Ключа НЕМА у старій
                                  історії, у службових ходах і в картках агентів,
                                  і це нормальний стан: UI малює як раніше.
                                  Див. specs/message-reply-anchor/spec.md.

Stage 3 (transparency): the turn runs with `--output-format stream-json
--verbose --include-partial-messages`. The runner parses the event stream line
by line and continuously rewrites live.json so the user sees, in near real time:
  - tool-use steps ("Bash: git status", "Read: runner.py", агент Тарас…)
  - the assistant text accumulating as it is generated
The final `result` event carries the same usage/total_cost_usd as the old json
mode, so the cost/context meter is unchanged. When the turn ends, one final
markdown text bubble is appended (exactly as before) and live.json is removed.

Fallback: set CHAT_RUNNER_STREAM=0 to use the old single-shot `--output-format
json` path (no live progress, but identical final bubble). Used if stream-json
ever regresses.

Concurrency: one worker thread per channel that has queued work. Different
channels run in parallel; prompts within one channel are serialized (a session
cannot be resumed concurrently). A per-channel lock file guards reentry.
"""
import json
import os
import re
import sys
import time
import glob
import shutil
import subprocess
import threading
import uuid

# ДЗЕРКАЛЕННЯ ІМЕН ЗМІННИХ СЕРЕДОВИЩА (CHATVIEW_* <-> LOGOPSIS_*). Стоїть вище за
# будь-яке читання середовища у цьому файлі: у власника лишились запущені служби,
# launchd-агенти і .command-файли зі старими іменами, і вони мусять і далі працювати.
# Контракт і причини: brand_env.py.
import brand_env  # noqa: F401

# ---- Force UTF-8 mode (CRITICAL on Windows) --------------------------------
# On Windows the default locale is often a legacy code page (e.g. cp1251), which
# breaks Cyrillic two ways in this runner:
#   1) subprocess(text=True) decodes claude's UTF-8 stdout as cp1251 -> the reply
#      text is double-mangled before we write it back to the bubble.
#   2) open()/json.load() default to the code page, so re-reading an existing
#      index.json (already UTF-8 on disk) corrupts every Cyrillic field we then
#      rewrite (e.g. from='Я' -> 'РЇ').
# PEP 540 UTF-8 mode fixes ALL of it at once (locale.getpreferredencoding,
# open() default, AND subprocess text decoding -> utf-8). We re-exec ourselves
# once with PYTHONUTF8=1 if it is not already active, so the runner is correct no
# matter how it was launched (Git Bash / cmd / a fresh clone) — no env var to
# remember. No-op on POSIX (already utf-8) and after the first re-exec.
if sys.platform == 'win32' and sys.flags.utf8_mode == 0 and os.environ.get('PYTHONUTF8') != '1':
    os.environ['PYTHONUTF8'] = '1'
    os.execv(sys.executable, [sys.executable, '-X', 'utf8', os.path.abspath(__file__)] + sys.argv[1:])

# Cross-platform "own process group" for spawned claude, so /api/stop can kill the
# whole tree (claude + children). POSIX: start_new_session=True; Windows:
# CREATE_NEW_PROCESS_GROUP. This OS quirk lives in ONE place — the platform layer
# (chatview_platform.Platform). Відсутній модуль (частковий чекаут, стара збірка)
# лишає runner імпортовним: PLATFORM стає None, а не другою копією правди.
try:
    import chatview_platform as _cvp
    PLATFORM = _cvp.Platform.current()
except Exception:
    _cvp = None
    PLATFORM = None
# Фолбек порожній НАВМИСНО. Власна копія гілок («win32 -> creationflags, інакше
# start_new_session») збігалась з платформою рівно доти, доки платформу не правили:
# роздвоєна істина розʼїжджається тихо. Без платформи дитина просто лишається в
# нашій групі, і це чесна деградація, а не друга версія правди.
_PROC_GROUP_KW = PLATFORM.process_group_kwargs() if PLATFORM is not None else {}


def _safe_pgid(pid):
    """pgid для killpg або None, якщо група спільна. Канон у
    chatview_platform.safe_pgid, тут обгортка з інлайн-запасом.

    Сигнал групі дозволений лише коли pid САМ лідер своєї групи. Дитина, яку
    спавнили без start_new_session, сидить у групі раннера, і killpg по ній
    убивав би сам раннер разом з усіма каналами."""
    if _cvp is not None:
        try:
            return _cvp.safe_pgid(pid)
        except Exception:
            pass
    if not hasattr(os, 'getpgid'):
        return None
    try:
        pid = int(pid)
        if pid <= 1:
            return None
        pgid = os.getpgid(pid)
    except (TypeError, ValueError, OSError):
        return None
    if pgid != pid or pgid == os.getpgrp():
        return None
    return pgid


def _child_env(channel):
    """Env for a headless `claude -p` turn the runner spawns to SERVE a channel.

    LOGOPSIS_RUNNER=1 tells the SessionStart hook this is the engine answering an
    EXISTING channel, NOT a brand-new interactive tab — so it must NOT reserve a
    new cc-* channel (that was the "writing in one chat spawns a new chat" bug:
    the rotated/forked session id was never in .cc-sessions.json, so the hook kept
    minting phantom tabs and the reply landed there).
    LOGOPSIS_CHANNEL pins the exact channel this turn serves, so the UserPromptSubmit
    hook binds any card/plan write to the RIGHT existing channel instead of guessing
    by session id."""
    e = os.environ.copy()
    e['LOGOPSIS_RUNNER'] = '1'
    e['LOGOPSIS_CHANNEL'] = channel
    # STRIP the PARENT Claude Code session context. When the runner is launched from
    # inside a live `claude` session (a dev terminal, OR a desktop app opened from such
    # a shell), os.environ carries CLAUDE_CODE_SESSION_ID + friends. The spawned engine
    # `claude` would inherit them and try to ATTACH/RESUME the PARENT's live session ->
    # two processes on one session -> deadlock -> the turn hangs forever (busy never
    # clears). This was the desktop turn-hang. A fresh engine turn must own its OWN
    # session (runner passes --session-id/--resume explicitly), so we drop every
    # parent-session marker here. ANTHROPIC_*/CLAUDE_BIN auth is left intact so the
    # child still authenticates.
    for _k in ('CLAUDE_CODE_SESSION_ID', 'CLAUDECODE', 'CLAUDE_CODE_ENTRYPOINT',
               'CLAUDE_CODE_CHILD_SESSION', 'CLAUDE_CODE_EXECPATH', 'CLAUDE_CODE_SSE_PORT',
               'CLAUDE_AGENT_SDK_VERSION', 'AI_AGENT', 'CLAUDE_EFFORT'):
        e.pop(_k, None)
    # Backfill USER/LOGNAME/PATH when the app was started without them (launchd,
    # a Finder-launched .app, a frozen build). macOS looks the login token up in
    # the Keychain BY ACCOUNT NAME, so a missing $USER makes an authenticated
    # machine look signed out and every turn fail on auth. See claude_env().
    if _cvp is not None:
        try:
            e = _cvp.Platform.current().claude_env(e)
        except Exception:
            pass
    return e


from datetime import datetime

# LOGOPSIS_HOME: desktop build sets this to the per-user writable home so data lives
# outside the app (survives delete/update). Absent (dev/live) -> identical behavior.
_CV_HOME = os.environ.get('LOGOPSIS_HOME')
DIR = _CV_HOME or os.path.dirname(os.path.abspath(__file__))
CHANNELS_DIR = os.path.join(DIR, 'channels')
# Мова інтерфейсу (specs/lang-channel-to-backend). Стан ЗАСТОСУНКУ, не каналу: один
# вибір людини діє однаково в усіх табах, тому файл лежить поруч з keys.json просто
# під LOGOPSIS_HOME, а не під channels/<id>/ (розділ 1 спеки).
LANG_FILE = os.path.join(DIR, 'lang')
AVAILABLE_LANGS = ('en', 'uk')
DEFAULT_LANG = 'en'   # мусить збігатись з BASE_LANG у logopsis/src/i18n/registry.ts (К6)
# repo root = cwd for claude, so it inherits CLAUDE.md / MCP / skills / agents / memory.
# In the desktop app there is no shared-knowledge repo: claude runs in the home itself.
REPO_ROOT = DIR if _CV_HOME else os.path.abspath(os.path.join(DIR, '..', '..', '..'))

# Кімната каналу (фаза 2, specs/agent-room): розбір списку учасників спільний з
# server.py. Імпортувати сам server.py звідси не можна (той при імпорті підіймає
# порт), тому спільним є маленький чистий модуль, а не один із двох процесів.
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import agent_room  # noqa: E402
# Шар правил ЗАСТОСУНКУ (specs/chatview-rules-layer). Той самий чистий модуль читає
# і server.py: сервер створює файл на старті, раннер читає його на кожному ході.
import rules_store  # noqa: E402
# Адаптер діалектів віджетів (specs/widget-dialect-adapter). Чистий модуль без IO:
# перекладає чужі імена полів у канонічну схему ДО воріт рендерабельності.
import widget_dialects  # noqa: E402
# Реєстр класів даних (specs/user-data-architecture). Звідси береться ЄДИНА
# відповідь на питання «де дім»: `data_root()` для файлів дому і `path_for()` для
# класів сутностей. Модуль чистий (лише stdlib), тому імпорт тут нічого не піднімає.
import entities  # noqa: E402
# Довіра до сертифікатів ЦІЄЇ машини (specs/tls-system-trust). Раннер це ОКРЕМИЙ процес,
# тож середовища сервера він не успадковує і мусить зібрати набір собі сам. Заразом це
# кладе NODE_EXTRA_CA_CERTS у середовище, з якого стартує claude CLI.
import tls_trust  # noqa: E402
# Мапа «наш рівень -> модель Antigravity». ОДНА на весь проєкт: цей модуль читає і
# server.py, щоб віддати ту саму мапу в UI. Псевдонім бо в цьому файлі вже є функція
# з іменем agy_models.
import agy_models as agy_models_lib  # noqa: E402
# Биття серця раннера (specs/stale-runner-eats-prompts). Той самий чистий модуль читає
# server.py: раннер ЗАЯВЛЯЄ, що вміє писати бульбашку промпту, сервер цю заяву перевіряє
# перед тим, як покласти промпт у чергу. Причина в шапці модуля.
import runner_pulse  # noqa: E402
# Телеметрія продукту (specs/telemetry-events). Раннер це ОКРЕМИЙ процес від server.py,
# тому має власний екземпляр Telemetry (той самий `DIR`, той самий telemetry.json на
# диску), а не переносить чужий. Білий список подій і властивостей лишається закритий
# у telemetry.py, тут лише виклики .track() у вже названих точках (S5, S7).
import telemetry  # noqa: E402

tls_trust.install(DIR)

# Відбиток коду, який РЕАЛЬНО крутиться в цьому процесі. Знімається один раз, на старті:
# Python вантажить модуль у памʼять на старті, тож правка runner.py на диску цей процес
# не змінює, і читати диск щоразу означало б показувати серверу чужий код.
RUNNER_CODE_FP = runner_pulse.code_fingerprint(os.path.abspath(__file__))
RUNNER_STARTED = datetime.now().astimezone().isoformat()

try:
    from media_normalize import normalize_widgets as _normalize_widgets
except Exception:          # module missing -> posting a card must still work
    _normalize_widgets = None


def normalize_media(widgets):
    """Make every media src in a card fetchable by the browser before we persist it.

    A filesystem path or a repo-relative path 404s over http and fails SILENTLY, so
    a screenshot proof would just render as nothing. Copying the real file into
    assets/media/ (or flagging it as missing) turns that into either a working image
    or a visible error. Best effort: never let this block the message."""
    if _normalize_widgets is None:
        return widgets
    try:
        _normalize_widgets(widgets, DIR, REPO_ROOT)
    except Exception:
        pass
    return widgets


def atomic_write_json(path, obj, indent=2):
    """Write JSON atomically so a concurrent reader (the browser poller) always
    sees either the old complete file or the new one, never a truncated half.

    The plain `json.dump(obj, open(path, 'w'))` truncates the file to 0 bytes
    and THEN streams the new content. A poll() that fetches index.json during
    that window parses garbage, throws, and the UI flashes "connecting". Writing
    to a temp file + os.replace (atomic rename on POSIX) closes that race.

    The tmp name carries pid + thread id so two concurrent writers of the same
    target (e.g. the server's threaded handler) never share a temp path."""
    tmp = f'{path}.tmp.{os.getpid()}.{threading.get_ident()}'
    with open(tmp, 'w', encoding='utf-8') as f:
        json.dump(obj, f, ensure_ascii=False, indent=indent)
        f.flush()
        os.fsync(f.fileno())
    os.replace(tmp, path)

# ---- Chat View system override (highest priority) --------------------------
# The runner spawns claude with cwd=REPO_ROOT so it inherits this repo's
# CLAUDE.md (the orchestrator config). That config HARD-tells the assistant to
# post every reply into a chat-view channel (ai-workflow) via render-message.sh
# and leave only a pointer line in the conversation. Inside this web chat that
# is exactly wrong: the user typed in the composer and the reply is rendered
# directly as a bubble in THIS chat. So the assistant must NOT re-post anywhere.
# We inject this override via --append-system-prompt (verified flag on
# v2.1.169) to neutralize those CLAUDE.md rules for chat-view turns only.
# No em-dash in this string by request (uses periods/commas instead).
#
# Контракт віджетів (WIDGET_SYNTAX / WIDGET_ANSWER_SHAPE / WIDGET_JSON_RULE /
# WIDGET_CATALOG) свідомо винесений з цього рядка окремими шматками. Раніше він жив
# ТІЛЬКИ тут, тобто його бачив лише канальний хід; detached-агент стартує як
# `claude -p` з голою задачею і фізично не знав, що віджети існують, тому і повертав
# стіну тексту. Тепер з тих самих шматків збирається і чатовий системний промпт, і
# компактна преамбула агента (AGENT_WIDGET_PREAMBLE). Порядок склейки нижче дає
# байт-у-байт той самий CHAT_SYSTEM_OVERRIDE, що був до виносу.
#
# ТЕКСТ САМИХ ПРАВИЛ ТУТ БІЛЬШЕ НЕ ЛЕЖИТЬ (specs/chatview-rules-layer). Три прозові
# блоки (цей, рамка агента, рамка капелюха) переїхали у файл rules.md під
# LOGOPSIS_HOME, який людина редагує через екран налаштувань. Переїзд був побайтовим:
# у коді лишився тільки КЛЕЙ склейки (нумерація пунктів і переноси), бо він належить
# порядку промпту, а не змісту правила. Дві копії правди тут коштували б дорого:
# одну оновили б, другу ні, і розійшлись би вони мовчки.
def _chat_head():
    return rules_store.section(DIR, 'chat') + '\n'

# ---- Мовно залежні шматки промпту (specs/engine-reply-language, К7, К9) ----
# ОДНЕ місце для всіх шести шматків, які змінює Ф1. Ключів мало, тому це не
# привід будувати повний шар локалізації беку (той механізм і його заміри це Ф4).
# Фолбек на 'en', коли для мови немає перекладу (К9), той самий принцип, що у
# фронтовому logopsis/src/i18n/translate.ts.
def _lang_text(chunks, lang):
    return chunks.get(lang) or chunks['en']


# ---- Тексти беку, видимі людині (specs/i18n-interface, Ф4, К4/К20) ----------
# Картки помилок, ліміти, відмови, підказки. Носій той самий, що завела Ф1 для
# шматків промпту (_lang_text), тут лише зручна обгортка над ним + current_lang:
# {'uk': ..., 'en': ...} лишається прямо біля місця вживання, як і в Ф1, замість
# окремого каталогу ключів (рішення розділу «Ф4» specs/i18n-interface/spec.md).
# channel=None означає «мова застосунку зараз», не мова конкретного каналу: для
# інфраструктурних карток (помилка OpenAI, Tailscale, git) немає ходу в черзі, з
# яким можна було б розійтись у часі, тому тут це не спрощення, а точна поведінка.
def _bt(chunks, channel=None):
    return _lang_text(chunks, current_lang(channel))


# Як фізично видати віджет. Спільне для чату і для агента.
# У прикладі свідомо НЕ verdict (рішення власника, 2026-08-05). Це перший конкретний віджет,
# який модель бачить у кожному ході, і поруч стоїть «VERDICT FIRST» з ANSWER
# SHAPE, де слово означає «спершу суть», а не тип віджета. Разом вони читались як
# «канонічна відповідь починається з картки verdict», тому вирок їхав на побутові
# питання. Приклад тепер показує звичайну пару stat-grid плюс conclusion.
#
# Приклад мовно залежний (К3, К12), а не «нейтральний»: заглушка типу
# "label":"X" губить навчальну силу прикладу і робить помилку симетричною, а не
# усуває її (розділ 1 спеки engine-reply-language).
_WIDGET_SYNTAX_EXAMPLE = {
    'uk': '[ {"type":"stat-grid","cards":[{"value":"3","label":"тижні","color":"green"}]}, '
          '{"type":"conclusion","text":"Головна теза.","tone":"green"} ]',
    'en': '[ {"type":"stat-grid","cards":[{"value":"3","label":"weeks","color":"green"}]}, '
          '{"type":"conclusion","text":"Main thesis.","tone":"green"} ]',
}


def _widget_syntax(lang):
    return (
        'STRUCTURE your reply with inline widget blocks. Your reply is parsed '
        'into rich cards, not shown as a plain wall of markdown. To emit a widget, '
        'write a fenced code block whose info-string is exactly chatui. Inside it '
        'put EITHER a JSON array of widget objects OR a single widget object. Each '
        'object needs a "type" field. You may use several chatui blocks in one '
        'reply, interleaved with normal markdown prose for connective explanation. '
        'Example shape (literal triple backticks):\n'
        '```chatui\n'
        + _lang_text(_WIDGET_SYNTAX_EXAMPLE, lang) + '\n'
        '```\n'
    )

# Сюжет відповіді і густина. Це те, що відрізняє картку від стіни тексту.
WIDGET_ANSWER_SHAPE = (
    'ANSWER SHAPE (the contract for every substantive reply, in this order):\n'
    '  a. VERDICT FIRST. The opening line or widget IS the answer. No build-up, '
    'no restating the question, no "let me explain". The user must be able to '
    'stop after the first screen and still have the answer.\n'
    '  b. THEN THE REASON, IN PROSE. Real paragraphs carrying causality: what '
    'you found, why it leads to that verdict, what would change it, what you '
    'are unsure about. Two to five paragraphs here is NORMAL and expected. A '
    'bullet list cannot hold a "because" or an "otherwise"; only prose can. '
    'Never compress a causal chain into bullets and never drop the reasoning to '
    'look tidy. If you checked something and it changed your mind, say so.\n'
    '  c. THEN THE DETAIL. Evidence, numbers, comparisons, code, file paths, '
    'verification traces. Structure belongs in widgets, not in paragraphs.\n'
    '  d. ALWAYS END with a conclusion widget: one bold thesis, scannable in a '
    'glance.\n'
    'Prose and widgets are partners, not rivals. Widgets carry STRUCTURE '
    '(comparison, metrics, verdict, timeline, funnel, quotes, decision, '
    'status). Prose carries CAUSALITY. Reach for a widget the moment content '
    'has structure; reach for prose the moment something needs a "because". A '
    'paragraph that only restates the widget above it is noise, cut it. A '
    'paragraph that explains why the widget looks like that has earned its '
    'place. The test is not length, it is whether every sentence is '
    'load-bearing.\n'
    'TABLES: use the `table` or `comparison-matrix` widget, that is the one that '
    'actually looks like a table in the feed. A markdown pipe table no longer '
    'lands as broken text (the renderer parses a header row plus a --- separator '
    'row), but it keeps plain prose styling, so do not reach for it when the '
    'content is a real comparison.\n'
    'DENSITY. The reader has two levels, Balanced (default) and Detailed, and '
    'YOU NEVER SEE WHICH ONE IS ACTIVE. Always generate the same one complete '
    'answer; the level only controls what starts collapsed. Mark supporting '
    'detail with "detail": true on the widget object: long code, diffs, raw '
    'logs, file enumerations, verification traces, exhaustive option lists. '
    'NEVER mark the verdict, the causal prose or the conclusion as detail. Do '
    'not write "as you can see below" about a block you marked as detail, since '
    'it may be collapsed. (The toggle itself ships later; the flag is harmless '
    'until then, so start marking now.)\n'
    'The user is an ENTJ who scans diagonally: lead with the punchline, colour '
    'via widget tone, make every sentence carry weight. For a trivial one-line '
    'answer a single plain sentence is fine, no widget needed. A reply with no '
    'chatui block still renders fine (as one text bubble), so widgets are an '
    'upgrade, not a syntax you can break.\n'
)

# Валідність JSON: поламаний блок тихо падає у текст, тобто картка втрачена.
WIDGET_JSON_RULE = (
    'JSON must be VALID (double quotes, no trailing commas, no comments). A '
    'broken block silently falls back to plain text, so the card is lost. Do '
    'NOT mention the chatui mechanism to the user and do NOT describe the JSON; '
    'just emit it. '
)

# Далі суто чатове: заборона pointer-рядка і декларація плану. Агента це не стосується
# (у нього нема свого табу і плану каналу він не веде).
# Приклади заборонених формулювань мовно залежні (К4): модель бачить приклад тією ж
# мовою, якою мусить відповідати, інакше приклад тягне відповідь у чужу мову.
_CHAT_POINTER_EXAMPLES = {
    'uk': 'no "виклав у таб", no "дивись вкладку", no trailing "X" / "посилання вкладку", '
          'no "posted to tab X", no "I posted it to channel X"',
    'en': 'no "posted to tab X", no "see tab X", no trailing "X" / "channel link", '
          'no "I posted it to channel X"',
}


def _chat_pointer_ban(lang):
    return (
        'NEVER add a pointer / hand-off line: '
        + _lang_text(_CHAT_POINTER_EXAMPLES, lang) + '. '
        'The user is ALREADY in this chat tab, so a '
        '"go look at tab X" pointer is meaningless here. Reply directly, end of '
        'message is your conclusion widget.\n'
    )

_CHAT_PLAN_ITEM = (
    '5. PLAN SIDEBAR (declarative, keep it LIVE). For any task with 3 or more '
    'steps, include in your reply ONE fenced code block whose info-string is '
    'exactly plan, containing a JSON object shaped like: '
    '{"goal":"...","steps":[{"text":"...","state":"done|progress|pending|'
    'blocked","id":"...","origin":"ordered|proposed","orderProof":"...",'
    '"goal":"...","substeps":["..."],"result":"...","note":"...",'
    '"closeOn":{"type":"commit|tests","match":"..."}}]}. '
    'Only text and state are required per step; goal, substeps, result, note, id, '
    'origin, orderProof and closeOn are optional, EXCEPT id becomes REQUIRED the '
    'instant you spawn a background agent to work on that step: set it to '
    'exactly agent:<agentId>, using the id string that spawn call returned, '
    'e.g. "id":"agent:a1b2c3". That is what lets the step close itself '
    'automatically the moment the agent finishes, with zero further action '
    'from you, and it is also the only thing that survives a later rewording '
    'of the step\'s text. closeOn is entirely OPTIONAL and does the same '
    'self-closing trick for two other events: set "closeOn":{"type":"commit",'
    '"match":"..."} when the step is finished by one specific commit landing, '
    'or "closeOn":{"type":"tests","match":"..."} when it is finished by one '
    'specific test run coming back green. "match" is the exact substring the '
    'automatic sync checks for: in the new commit\'s message for "commit", in '
    'the test-run command for "tests". Set closeOn ONLY on a step that really '
    'is closed by that one event, never as a default: leave it off every '
    'other step, where nothing but you or an agent id moves the step. '
    '"origin" is OPTIONAL with an inverted default: omit it and the step is '
    '"proposed", a suggestion you are floating that stays visible on the '
    'sidebar but is NEVER counted in the plan\'s progress. Set '
    '"origin":"ordered" ONLY when the human said this step outright or you '
    'are certain they meant it, and the instant you do, "orderProof" becomes '
    'REQUIRED on that same ordered step: the exact verbatim substring of the '
    'human\'s own message that ordered it, quoted character for character, '
    'never paraphrased or invented. The system checks that substring against '
    'the real messages of this channel; an invented quote or a missing '
    'orderProof on an "origin":"ordered" step is silently downgraded back to '
    'proposed, so it drops out of progress just like any other unproven '
    'guess. A step that is a technically-required piece of an '
    'already-ordered step can skip its own orderProof by setting '
    '"inheritOrderedFrom":"<parent step id>" '
    'instead, naming that parent step\'s own id; the parent must itself '
    'resolve to ordered (its own flag, or an ordered step already stored) or '
    'the child stays proposed too. The '
    'block is MERGED into the stored plan, it never replaces it: a step already '
    'marked done is frozen history (it cannot be '
    'removed, reworded or reverted to pending), steps you leave out simply stay as '
    'they are, and the only way to delete a mistaken step is to send it with '
    '"state":"dropped" (which works on non-done steps only). So declare the goal '
    'plus the ACTIVE steps plus whatever you are marking done this turn; repeating '
    'finished steps verbatim is harmless, but REWORDING one creates a duplicate '
    'instead of editing it, unless it carries an id. The system reads that block, '
    'persists it to this channel\'s plan sidebar automatically, and strips it from '
    'your visible reply. You still NEVER run set-plan or any script: you only '
    'DECLARE the data, the system does the writing. Refresh the plan block on each '
    'substantive turn (mark steps done / progress / blocked, add new steps as they '
    'appear). The plan block is SEPARATE from chatui widgets, is never shown as a '
    'chat bubble, and a malformed or missing block simply leaves the current plan '
    'unchanged. Example (literal triple backticks):\n'
    '```plan\n'
    '{"goal":"Fix login bug","steps":[{"text":"Reproduce","state":"done",'
    '"origin":"ordered","orderProof":"fix the login bug"},'
    '{"text":"Patch handler","state":"progress","id":"agent:a1b2c3"},'
    '{"text":"Commit the fix","state":"pending","closeOn":{"type":"commit",'
    '"match":"fix(login)"}},{"text":"Add test","state":"pending","closeOn":'
    '{"type":"tests","match":"test_login.py"}},'
    '{"text":"Add rate limiting too","state":"pending"}]}\n'
    '```\n'
)

# Два приклади всередині каталогу мовно залежні (К4, розділ 1 спеки
# engine-reply-language, пункти 5 і 6): назви колонок comparison-matrix і мертві
# чіпи ALWAYS-ANSWER RULE. Решта каталогу це англомовний опис синтаксису типів,
# він не залежить від мови відповіді.
_COMPARISON_MATRIX_EXAMPLE = {
    'uk': '"Ми" / "Конкурент"). The row-label column comes from `rows` and is drawn '
          'automatically; do NOT add a leading entry like "Критерій" or "Параметр" to '
          'cols for it, that duplicates the label column and shifts every data cell '
          'one column to the left.\n',
    'en': '"Us" / "Competitor"). The row-label column comes from `rows` and is drawn '
          'automatically; do NOT add a leading entry like "Criterion" or "Parameter" to '
          'cols for it, that duplicates the label column and shifts every data cell '
          'one column to the left.\n',
}
_DEAD_CHIP_EXAMPLES = {
    'uk': '«на сьогодні досить», «лишаємо як є», «нова задача», «стоп»',
    'en': '"that is enough for now", "leave it as is", "new task", "stop"',
}
_MULTI_CHOICE_EXAMPLE = {
    'uk': '"Варіант А: ...", "Варіант Б: ..."',
    'en': '"Option A: ...", "Option B: ..."',
}


# Повний каталог типів. Важкий (близько 9 КБ), тому в преамбулу агента він НЕ їде:
# там короткий список плюс вказівник на реєстр, агент дочитає сам за потреби.
def _widget_catalog(lang):
    return (
    'WIDGET CHEAT-SHEET (type id, when to use, REQUIRED fields; optional in '
    'parentheses). Source of truth is index.html renderers.\n'
    'header: title banner at the top of a structured reply. req: title. '
    '(subtitle)\n'
    'text: plain markdown prose between widgets. req: text (markdown string).\n'
    # Правило про зірочки досі жило ЛИШЕ у преамбулі детач-агентів
    # (AGENT_WIDGET_PREAMBLE), тому в чаті обидва двигуни спокійно писали
    # **тезу** і зірочки приїжджали в панель буквально. Перенесено сюди, у
    # спільний каталог, бо панель однакова для всіх, хто його читає.
    'conclusion: full-width tinted summary panel, the scan-line takeaway. Its '
    'text is PLAIN: the panel bolds it itself, so do NOT wrap it in ** or the '
    'asterisks show up literally. ALWAYS '
    'last in a substantive reply. req: text (one bold thesis). (tone: '
    'green|red|yellow|neutral, points: array of short strings)\n'
    # Скоуп звужено свідомо (рішення власника, 2026-08-05): опис без заборони робив verdict
    # дефолтною обгорткою будь-якої «впевненої» відповіді, бо це єдиний тип, що
    # дає готове «теза + колір + відсоток». Живий доказ: побутове порівняння двох
    # щоденників приїхало як {"verdict":"GO","confidence":95}. Негативний приклад
    # лишається В ОПИСІ: модель має бачити межу, а не лише визначення.
    'verdict: a real GO / PIVOT / KILL call, and ONLY that. Use it when there are '
    'actual stakes AND a real alternative being rejected: a business decision, a '
    'debate, an idea validation, a stress-test. It is NOT a generic "confident '
    'answer" wrapper: never use it for factual questions, product or tool '
    'comparisons, recommendations, topic summaries, status reports or how-to '
    'answers. Wrong on purpose: {"type":"verdict","subject":"Which edition of a '
    'paper planner to buy","verdict":"GO","confidence":95} on a question with no '
    'risk, no money and nothing being killed. When nothing is at stake, the '
    'takeaway belongs in conclusion, the numbers in stat-grid, the options in '
    'comparison-matrix or decision. req: subject (string), '
    'verdict (GO|PIVOT|KILL), confidence (0..100 number). (killSignals: '
    '[{severity:"🔴|🟡|🟢", text, probability}], pivot:{from,to,rationale}, '
    'breakEven:{months,capital}, successConditions:[string], killerQuestion)\n'
    'stat-grid: 2 to 6 key metrics as big-number cards. req: cards '
    '[{value, label, (emoji), (color: green|red|yellow|blue|slate)}]. '
    '(title, subtitle, cols)\n'
    'heatmap: numeric scores 0..5 in a grid (rows x cols). req: cols [string], '
    'rows [string], values [[number|null]] (one inner array per row). '
    '(title, subtitle, note)\n'
    'comparison-matrix: textual feature/status comparison across options. req: '
    'cols [{name, (sub), (highlight:true)}], rows [string], cells [[{text, '
    '(status: yes|no|partial|unknown|warning), (note)}]] (one row array per '
    'row). (title, subtitle, note) '
    'cols lists ONLY the data columns (one per option being compared, e.g. '
    + _lang_text(_COMPARISON_MATRIX_EXAMPLE, lang) +
    'quadrant: position items in a 2D space. req: points [{x:0..100, y:0..100, '
    'label, (us:true)}]. (title, xAxisLeft, xAxisRight, yAxisTop, yAxisBottom, '
    'note)\n'
    'decision: choose between options with criteria. req: options [{label, '
    '(subtitle), (criteria:[{name, value, (good:true|bad:true)}]), '
    '(killed:true), (note)}]. (question, context, recommended: index of best '
    'option, killerQuestion)\n'
    'journey-map: customer / sales / onboarding flow with emotion curve. req: '
    'stages [{name, action, (icon), (emotion: -2..2), (duration), (win), '
    '(pain), (dropOffRisk:{severity:critical|high|med|low, reason})}]. '
    '(title, subtitle, note)\n'
    'funnel: conversion stages with drop-off. req: stages [{name, count '
    '(number), (label), (conversion: number percent), (note), (flag: '
    'critical-drop|improvement|blocker)}]. (title, subtitle, baseLabel, note)\n'
    'quote-wall: synthesis of user / customer quotes grouped by theme. req: '
    'groups [{theme, quotes:[{text, (author), (source), (highlight: substring '
    'to bold)}], (icon), (color: red|yellow|blue|green|slate)}]. '
    '(title, subtitle, synthesis, note)\n'
    'timeline: roadmap / milestones / sprint. req: milestones [{name, date, '
    '(status: done|in-progress|planned|blocked|killed), (description), (owner), '
    '(impact: high|medium|low), (dependency)}]. (title, subtitle, '
    'axis:{label}, note)\n'
    'callout: a single highlighted note (tip / warning / insight). req: text. '
    '(title, variant: info|tip|success|warning|danger|insight, icon)\n'
    'table: small generic table. req: columns [string], rows [[cell]] where a '
    'cell is a string or {text, (bold:true), (status: yes|no|partial|good|bad|'
    'warn)}. (title, subtitle, note)\n'
    'key-values: compact label/value pairs (specs, params). req: items [{k, v, '
    '(color: green|red|yellow|blue|slate)}]. (title, cols: number)\n'
    'badge-row: a row of small status pills. req: badges [string OR {label, '
    '(icon), (color: green|red|yellow|blue|violet|slate)}]. (title)\n'
    'checklist: done / pending / blocked items. req: items [string OR {text, '
    '(state: done|no|pending|progress|warning), (note)}]. (title)\n'
    'bar-chart: compare magnitudes as horizontal bars. req: bars [{label, value '
    '(number), (display: string), (color: green|red|yellow|blue|violet|slate)}]'
    '. (title, subtitle, note)\n'
    'line-chart: trends over time (line / area, multi-series). req: series '
    '[{label, (color), data:[number...]}]. (xLabels:[string], area:bool, title, '
    'subtitle, note)\n'
    'pie-chart: proportions of a whole. req: slices [{label, value (number), '
    '(color)}]. (donut:bool, title, subtitle, note)\n'
    'code-block: code with a header (filename/lang) + copy button (auto-escaped). '
    'req: code (string). (lang, filename, title, subtitle, note)\n'
    'diff: code changes across files, one collapsed row per file (path + +N/-M '
    'counts), expands to the unified patch on click. Use this instead of '
    'code-block when reporting a code change, especially across 2+ files: a '
    'wall-of-text patch in code-block is unreadable, this lets the user open only '
    'the file they care about. req: files [{path, patch, (additions), '
    '(deletions), (open:bool)}]. (title, subtitle, note)\n'
    'accordion: collapsible sections for long content / FAQ / details. req: items '
    '[{title, body (markdown), (open:bool)}]. (title, subtitle, note)\n'
    'progress: a metric toward a goal as % bars. req: bars [{label, value (0-100), '
    '(display), (color), (goal: 0-100 marker)}]. (title, subtitle, note)\n'
    'suggestions: clickable next-action chips (click sends immediately). req: '
    'chips [string OR {label, (prompt), (icon)}]. (title, note)\n'
    # Межа зменшена з трьох до двох за заміром 7 серпня 2026 по всій живій історії
    # (spec chips-rebuild, К1-К4). Числа, які тут же і стоять у тексті правила, це не
    # прикраса: без них модель читає обмеження як смак і торгується з ним. 1261 пара
    # «показані чіпи -> відповідь», 434 влучання, тобто на ПОВІДОМЛЕННЯ третина, а на
    # ЧІП близько дванадцяти відсотків. Показуючи три, ми механічно робимо два з них
    # промахом. Позиція вирішує сильніше за формулювання: 279 / 96 / 65 натискань по
    # слотах. Категорія виходу за весь час: 176 пропозицій, 9 натискань.
    # Замір повторюється командою `node scripts/chips-report.cjs`.
    'ALWAYS-ANSWER RULE (owner, hard): whenever your reply asks the user to CHOOSE '
    'between options, you MUST end it with a `suggestions` widget listing those '
    'options as tap-to-send chips, MAX 2 (never more). This lets the user tap an '
    'answer instead of typing. Two slots, not three, because the whole history was '
    'measured: the FIRST chip took 279 clicks, the second 96, the third 65, so the '
    'third slot was mostly noise. Order is a RANKED BET, not an even menu of '
    'variants: put the single next action you are most confident about first, and '
    'only then the runner-up. If you are not confident in a second one, ship one '
    'chip or none at all: padding the set with a guess costs a real miss, and a '
    'reply with no chips is perfectly fine. NEVER offer an exit chip, meaning '
    'anything that ends the session or freezes the work: '
    + _lang_text(_DEAD_CHIP_EXAMPLES, lang) +
    '. Out of 176 such chips he pressed 9, '
    'and he can always type it himself. If you literally ask a multiple-choice '
    'question in prose, phrase the options as '
    + _lang_text(_MULTI_CHOICE_EXAMPLE, lang) +
    ' (still cap 2) so the answer buttons are unmistakable. A yes/no question '
    'still gets a 2-chip suggestions widget. Do not skip this when offering a '
    'choice.\n'
    'form: collect input inline; submit packs the values into the composer. req: '
    'fields [{label, (type: text|email|number|textarea|select), (placeholder), '
    '(options:[string]), (required:bool)}]. (submitLabel, title, subtitle, note)\n'
    'buttons: action / link buttons; a click opens the URL in a new browser tab. '
    'req: buttons [{label, (url), (icon), (variant: primary|secondary|video|ghost'
    '|link)}]. (title, subtitle, note)\n'
    'sources: cited sources list; each title links out (new tab). req: sources '
    '[{title, (url), (snippet), (source)}]. (title, subtitle, note)\n'
    'reasoning: collapsible thinking panel for chain-of-thought. req: steps '
    '[string] OR body (markdown). (summary, open:bool, title, note)\n'
    'prose: structured rich text (headings, lead, quotes, lists) as ONE block. '
    'req: blocks [string OR {t:"h2"|"h3"|"lead"|"p", text} OR {t:"quote", text, '
    '(author)} OR {t:"ul"|"ol", items:[string]}]. (title). NOTE: blocks render '
    'as plain text, inline **bold** / `code` / links do NOT work inside them. '
    'For the causal "because" paragraphs use ordinary markdown prose between '
    'widgets instead, which does support inline formatting.\n'
    'image: a single picture, inline, opens in a lightbox. req: src. '
    '(title, caption, maxWidth)\n'
    'gallery: several pictures in a grid. req: images [{src, (caption)}]. '
    '(title, subtitle, note)\n'
    'audio: playable audio with an optional transcript. Every voice answer goes '
    'here; never play sound yourself. req: src. (title, transcript)\n'
    'video: inline video player. req: src. (title, caption, poster, duration, '
    'inline:bool)\n'
    'file: a downloadable / previewable file card. req: name. '
    '(content, mime, title, subtitle, note)\n'
    'divider: a thin visual break between sections of a long reply. (label)\n'
    '\n'
    'ENVELOPE: any widget also accepts "title", "subtitle", "note", "tag" where '
    'that widget documents them, plus "detail": true (see DENSITY above).\n'
    )

# Речення «Reply in X» мовно залежне (пункт 1 розділу 1 спеки engine-reply-language).
# Решта тексту це опис інструментів, той самий незалежно від мови відповіді.
#
# Заборона довгого тире (К15, i18n-interface): до латання оберту 2 ("Ревізор 1:
# заміри машиною") ця секція взагалі не згадувала тире, тому К15 для ЖИВОГО чату
# (на відміну від agent_widget_preamble, де _AGENT_CATALOG_TAIL вже це робив) не
# мала жодного коду-рівневого підкріплення: заборона трималась ЛИШЕ на глобальному
# ~/.claude/CLAUDE.md, безумовно для будь-якої мови. Той самий принцип, що і в
# _AGENT_CATALOG_TAIL: для 'uk' явно забороняємо, для 'en' явно знімаємо.
_CHAT_TAIL_INSTRUCTION = {
    'uk': 'Reply in Ukrainian (the user is Ukrainian) unless asked otherwise. NO '
          'em-dash anywhere in your output (use a period, a comma or a colon); '
          'this is a hard house rule.',
    'en': 'Reply in English (the selected interface language) unless asked '
          'otherwise. The em-dash ban is a Ukrainian house rule and does NOT '
          'apply in English: use an em-dash freely wherever it helps the sentence.',
}


def _chat_tail(lang):
    return (
        'You MAY read files, run shell commands, use MCP tools, and launch '
        'background agents (in parallel when the work is independent) whenever the '
        'task benefits from it. Agents are launched ONLY through the detached '
        'bridge `node scripts/agent-run.cjs`; the harness Agent/Task tool is '
        'disabled by a PreToolUse hook in this project. '
        'Your FINAL answer must be your inline reply (prose '
        'plus chatui widget blocks). '
        + _lang_text(_CHAT_TAIL_INSTRUCTION, lang) + '\n'
        'Keep replies concise and on-point.'
    )

# Повний контракт одним шматком: синтаксис плюс сюжет плюс валідність плюс каталог.
# Тримається тут як єдине джерело правди для будь-кого, хто вчить модель нашій мові.
#
# Ревізія 2026-08-26 (specs/i18n-interface, К12): коментар нижче раніше називав
# фіксацію на 'uk' СВІДОМИМ рішенням «Antigravity поза скоупом Ф1». Це рішення
# постало ДО того, як Ф1 (engine-reply-language) взагалі закрила чат і фонових
# агентів Клода мовно залежним контрактом, тобто «поза скоупом» означало не
# «так і має бути назавжди», а «ще не дійшли руки». Приклад віджета важить для
# моделі більше за інструкцію (specs/i18n-interface, розділ 1), тож лишити його
# українським означало б, що агент на agy в англійському інтерфейсі однаково
# бачить `"label":"тижні"` і зісковзує в кирилицю. Тому `WIDGET_CONTRACT`
# лишається тут як БУВ (заморожений на 'uk', саме на нього досі звіряється
# байтовий знімок test_rules_layer.py::test_assembled_prompt_bytes_unchanged і
# бар-доступ старих тестів AGY_FIRST_TURN_PREFIX), а живий виклик агента
# (`run_agy_stream`) тепер будує контракт лямбдою lang через
# `agy_first_turn_prefix(lang)` нижче, а не через цю заморожену константу.
WIDGET_CONTRACT = _widget_syntax('uk') + WIDGET_ANSWER_SHAPE + WIDGET_JSON_RULE + _widget_catalog('uk')

# Склейка канального промпту. Нумерація пунктів (3., 4.) додається ТУТ, бо всередині
# спільних шматків вона не має сенсу: у преамбулі агента свій порядок.
#
# Стало функцією, бо голова тепер читається з файлу, а файл людина міняє посеред
# роботи (К5: правка діє з наступного ходу, без перезбірки і без перезапуску
# сервера). Модульна константа означала б, що правка доїжджає тільки після
# рестарту, тобто рівно те, від чого ця задача і рятує. Читання дешеве: один
# невеликий файл на хід.
#
# lang мовно залежні шматки (specs/engine-reply-language, К1, К2, К7): дефолт
# DEFAULT_LANG зберігає бар-виклик `runner.CHAT_SYSTEM_OVERRIDE` (без каналу, як у
# тестах і в AGY-непричетному коді) чинним, а живий хід передає current_lang(channel).
def chat_system_override(lang=DEFAULT_LANG):
    return (
        _chat_head()
        + '3. ' + _widget_syntax(lang)
        + WIDGET_ANSWER_SHAPE
        + '4. ' + WIDGET_JSON_RULE
        + _chat_pointer_ban(lang)
        + _CHAT_PLAN_ITEM
        + '\n'
        + _widget_catalog(lang)
        + '\n'
        + _chat_tail(lang)
    )

# ---- Widget contract for DETACHED agents -----------------------------------
# Рамка інша, ніж у чату: агент не є чатом і нікому не відповідає наживо. Його
# ФІНАЛЬНИЙ текст сервер розбирає тією ж reply_to_widgets і кладе карткою в канал,
# тому він пише прозу плюс ```chatui``` блоки і НЕ смикає render-message.cjs сам.
# Каталог свідомо короткий: повні 44 типи роздули б кожен агентський промпт, а
# реєстр агент дочитає сам, якщо йому треба екзотика.
# Текст рамки живе у секції `agent` файлу правил; тут лишився номер пункту, за яким
# одразу йде спільний WIDGET_SYNTAX.
def _agent_frame():
    return rules_store.section(DIR, 'agent') + '\n2. '

# Останній рядок мовно залежний удвічі (специфіка Ф1+Ф2 разом, розділ 1 обох спек):
# «Write in X» це пункт 2 з шести місць engine-reply-language, а заборона довгого
# тире це К15 парасольки (i18n-interface) — правило УКРАЇНСЬКОЇ типографіки
# замовника, тому для будь-якої іншої мови воно просто ЗНІМАЄТЬСЯ, а не
# перекладається: довге тире в англійському тексті нормальне і носій його чекає.
_AGENT_CATALOG_TAIL = {
    'uk': 'Write in Ukrainian. NO em-dash anywhere in your output (use a period, a '
          'comma or a colon); this is a hard house rule.\n',
    'en': 'Write in English.\n',
}


def _agent_catalog_short(lang):
    return (
        'WIDGETS YOU WILL ACTUALLY NEED IN A REPORT (full registry with all 44 '
        'types: logopsis/src/widgets/registry.tsx, read it if you need an exotic '
        'one):\n'
        'text: markdown prose between widgets. req: text. Markdown pipe tables DO '
        'render (header row plus a --- separator row), so a quick table inside prose '
        'is fine; for a real comparison prefer the table widget.\n'
        'table: columns [string], rows [[cell]] where a cell is a string or {text, '
        '(bold:true), (status: yes|no|partial|good|bad|warn)}. (title, subtitle, note)\n'
        'key-values: items [{k, v, (color: green|red|yellow|blue|slate)}]. (title, cols)\n'
        'checklist: items [string OR {text, (state: done|no|pending|progress|'
        'warning), (note)}]. (title)\n'
        'stat-grid: cards [{value, label, (emoji), (color)}]. (title, subtitle, cols)\n'
        'code-block: code (string). (lang, filename, title). Mark it "detail": true.\n'
        'callout: text. (title, variant: info|tip|success|warning|danger|insight, icon)\n'
        'image: src. (title, caption). Screenshots go inline as a widget, never as a '
        'file path in prose.\n'
        'conclusion: text (one bold thesis). (tone: green|red|yellow|neutral, points). '
        'ALWAYS the last widget. Its text is PLAIN, the widget bolds it itself: do not '
        'wrap it in ** or the asterisks show up literally.\n'
        'ENVELOPE: any widget also accepts "title", "subtitle", "note", plus '
        '"detail": true for supporting evidence.\n'
        # Той самий обмежувач, що і в повному каталозі: агент його там не бачить (у
        # преамбулу їде лише короткий список), тому без цього рядка фон і живий чат
        # трактували verdict по-різному.
        'NOT in this list on purpose: `verdict`. It is reserved for a real GO / '
        'PIVOT / KILL call with actual stakes and a real alternative being rejected '
        '(business decision, debate, idea validation, stress-test). A finished '
        'report, a status update or a technical answer ends with conclusion, never '
        'with verdict.\n'
        + _lang_text(_AGENT_CATALOG_TAIL, lang)
    )


def agent_widget_preamble(lang=DEFAULT_LANG):
    return (
        _agent_frame()
        + _widget_syntax(lang)
        + WIDGET_ANSWER_SHAPE
        + '3. ' + WIDGET_JSON_RULE + '\n'
        + _agent_catalog_short(lang)
    )


# Старі імена лишились читабельними як атрибути модуля (PEP 562). Це не друга копія
# тексту, а той самий виклик функції: у коді нема жодного літерала правил, а
# `runner.CHAT_SYSTEM_OVERRIDE` у тестах і в engine_sdk далі означає «зібрати зараз».
# Без цього довелось би або лишити стале значення часу імпорту (і правка правил
# доїжджала б лише після рестарту), або переписувати чужі виклики без потреби.
_LAZY = {
    'CHAT_SYSTEM_OVERRIDE': chat_system_override,
    'AGENT_WIDGET_PREAMBLE': agent_widget_preamble,
    '_CHAT_HEAD': _chat_head,
    '_AGENT_FRAME': _agent_frame,
    # WIDGET_SYNTAX був літералом до Ф1, тепер функція від мови; бар-доступ
    # лишається публічним іменем модуля через той самий PEP 562 механізм,
    # заморожений на 'uk' (як і решта бар-доступів у цьому словнику).
    'WIDGET_SYNTAX': lambda: _widget_syntax('uk'),
    # AGY_FIRST_TURN_PREFIX був літералом до К12 (i18n-interface), тепер функція
    # від мови; той самий трюк, заморожений на 'uk' для старих тестів, що читають
    # runner.AGY_FIRST_TURN_PREFIX як голий рядок (test_agy_engine.py,
    # test_chips_rule.py). Живий виклик у run_agy_stream мову НЕ заморожує.
    'AGY_FIRST_TURN_PREFIX': lambda: agy_first_turn_prefix('uk'),
    # AGY_TURN_REMINDER був літералом до Д4, тепер функція від мови; той самий
    # трюк, заморожений на 'uk' для test_agy_turn_reminder_fields.py, що читає
    # runner.AGY_TURN_REMINDER як голий рядок.
    'AGY_TURN_REMINDER': lambda: agy_turn_reminder('uk'),
}


def __getattr__(name):
    build = _LAZY.get(name)
    if build is not None:
        return build()
    raise AttributeError('module %r has no attribute %r' % (__name__, name))


def agent_task_with_contract(task, lang=None):
    """Приклеїти контракт віджетів до задачі detached-агента.

    Клеїться на боці сервера (agent_worker), а не в agent-run.cjs, щоб контракт
    діяв для ВСІХ способів спавну, а не лише для одного скрипта. Порожня задача
    лишається порожньою: її відсіює перевірка вище за течією.

    Мова звіту (specs/engine-reply-language, К6/К18): detached-агент не має свого
    знімка ходу (він не є повідомленням у черзі), тому current_lang(None) відразу
    падає на глобальний файл мови, тим самим правилом, що й живий чат.

    `lang` опційний (латання оберту 3, Ревізор 3): agent_worker.run() фіксує мову
    ОДИН раз на старті ходу і передає її сюди явно, щоб та сама мова, яку побачив
    двигун у власному промпті, лягла і в підпис завершеної картки. Без параметра
    (старі виклики, тести) поведінка не змінилась: current_lang(None) читається
    тут же, як і раніше."""
    task = (task or '').strip()
    if not task:
        return task
    if lang is None:
        lang = current_lang(None)
    return f'{agent_widget_preamble(lang)}\n\n---\n\nTASK:\n{task}'

def _resolve_claude_bin():
    """Path to the `claude` CLI this runner drives.

    The search itself lives in ONE place — chatview_platform.Platform.find_claude()
    (CLAUDE_BIN env -> PATH -> per-OS install dirs -> npm global -> login shell).
    It used to be duplicated here with a richer candidate list than the platform
    layer had, so the engine could drive claude while the onboarding card, reading
    the poorer list, insisted it was not installed. One list now, one answer.

    If nothing is found we still return the legacy default path so the existing
    FATAL startup check logs a clear "set CLAUDE_BIN" line instead of failing
    opaquely on a non-existent binary."""
    if _cvp is not None:
        try:
            found = _cvp.Platform.current().find_claude()
            if found:
                return found
        except Exception:
            pass
    # Inline fallback: partial checkout / old bundle without the platform module.
    env = os.environ.get('CLAUDE_BIN')
    if env and os.path.isfile(env) and os.access(env, os.X_OK):
        return env
    if sys.platform == 'win32':
        for c in (shutil.which('claude.exe'),
                  os.path.expanduser('~/.local/bin/claude.exe'),
                  shutil.which('claude')):
            if c and os.path.isfile(c):
                return c
    found = shutil.which('claude')
    if found:
        return found
    return os.path.expanduser('~/.local/bin/claude')


CLAUDE_BIN = _resolve_claude_bin()


def _resolve_agy_bin():
    """Знайти CLI Antigravity (`agy`). which() ПЕРШИМ: він уже покриває будь-який
    префікс встановлення (brew, curl-інсталер, apt, кастомна тека, Windows), і лише
    коли він промахнувся (launchd віддає обрізаний PATH), пробуємо кілька відомих
    місць. Жоден із цих шляхів не є єдиним хардкодом. '' = не встановлено."""
    found = shutil.which('agy') or shutil.which('agy.exe')
    if found:
        return found
    home = os.path.expanduser('~')
    for c in ('/opt/homebrew/bin/agy', '/usr/local/bin/agy', '/usr/bin/agy',
              os.path.join(home, '.local/bin/agy'), os.path.join(home, 'bin/agy'),
              os.path.join(os.environ.get('LOCALAPPDATA',
                                          os.path.join(home, 'AppData', 'Local')),
                           'agy', 'bin', 'agy.exe')):
        try:
            if os.path.isfile(c) and os.access(c, os.X_OK):
                return c
        except Exception:
            pass
    return ''


AGY_BIN = _resolve_agy_bin()

# Мапа «наш рівень -> модель Antigravity» тут БІЛЬШЕ НЕ ЖИВЕ. Вона переїхала в
# agy_models.py і стала правилом (виробник + клас + глибина) замість списку версійних
# id. Причина переїзду в шапці того модуля: копія мапи стояла ще й у фронті, формат
# видачі CLI змінився на `id<TAB>Назва`, і обидві копії почали мовчки промахуватись.
_agy_models_cache = {'at': 0.0, 'list': []}
AGY_MODELS_TTL = 300


def agy_models(force=False):
    """Живий список id моделей Antigravity (`agy models`) з TTL-кешем.

    Розбір віддано agy_models.parse_models: воно знімає людську назву після таба і
    відкидає заголовок «Fetching available models...». Раніше розбір стояв тут своїм
    фільтром «рядок без пробілів», і після зміни формату він викидав УСІ рядки, тобто
    список завжди приїжджав порожнім. Порожній список = CLI нема, не залогінений або
    вичерпана квота."""
    now = time.time()
    if not force and _agy_models_cache['list'] and now - _agy_models_cache['at'] < AGY_MODELS_TTL:
        return _agy_models_cache['list']
    if not AGY_BIN:
        return []
    try:
        r = subprocess.run([AGY_BIN, 'models'], capture_output=True, text=True, timeout=25)
        ids = agy_models_lib.model_ids((r.stdout or '').splitlines())
    except Exception as e:
        log(f'agy models failed: {e}')
        return _agy_models_cache['list']
    if ids:
        _agy_models_cache.update({'at': now, 'list': ids})
    return ids


def agy_model_for(alias, available=None):
    """Аліас (haiku|sonnet|opus|fable) -> реальний id моделі Antigravity.

    Уся логіка вибору в agy_models.resolve_tier. Порожня видача віддає None, і тоді
    прапорець --model просто не додається: хай двигун бере власний дефолт, це чесніше
    за здогад про модель, якої ми в очі не бачили."""
    ids = agy_models() if available is None else available
    return agy_models_lib.resolve_tier(alias, ids)['id']


def agy_choice(channel):
    """Вибір родини і глибини для ходу цього каналу (specs/agy-model-family-depth, К9):
    знімок МЕСЕДЖА першим, файл channels/<id>/agy-model запасним шляхом. None = вибору нема."""
    snap = job_runtime(channel)
    if 'agyModel' in snap:
        return snap['agyModel']
    if not channel:
        return None
    return agy_models_lib.read_choice(os.path.join(CHANNELS_DIR, channel))


def agy_model_for_channel(channel, prompt=None, available=None):
    """ЄДИНА відповідь на «яка модель Antigravity у цього каналу» (К4, К6, К10).
    Читають її і хід каналу, і збирач гаджетів, щоб обидва їхали на одній моделі.

    -> {'id', 'source': 'family'|'tier'}; на шляху родини ще 'label', 'fallback', 'reason'.
    Родина + глибина перемагають, лише коли рівень, записаний разом із ними, досі
    збігається з моделлю каналу: інакше `model` переписав інший шлях (V1, API) уже
    після вибору, і новіший вибір там, а не в agy-model. Будь-яка причина відмови від
    родини лишає рівно один рядок у лозі. Шлях рівня йде через agy_model_for, як і до
    цієї правки: список моделей тягнеться лише тоді, коли він справді потрібен."""
    choice = agy_choice(channel)
    if choice:
        model = str(channel_model(channel, prompt) or 'sonnet')
        if choice.get('tier') != model:
            why = (f'рівень у agy-model ({choice.get("tier")}) не збігається з model '
                   f'({model})')
        else:
            ids = agy_models() if available is None else available
            got = agy_models_lib.resolve_family(choice['family'], choice['depth'], ids)
            if got:
                return {'id': got['id'], 'label': got['label'], 'source': 'family',
                        'fallback': got['fallback'], 'reason': got['reason']}
            why = f'родини {choice["family"]} у видачі agy нема'
        log(f'{channel}: agy-model пропущено, {why}; їдемо рівнем')
    return {'id': agy_model_for(_agy_alias(channel, prompt), available), 'source': 'tier'}


# GLOBAL DEFAULT MODEL — single source of truth (env CHAT_RUNNER_MODEL).
# server.py reads the same env for the UI display, so both agree. Value is an
# ALIAS (sonnet/opus/haiku), never a pinned version — the CLI resolves the alias
# to the newest release, so this never goes stale. Per-channel override lives in
# channels/<id>/model (see channel_model) and always beats this global default.
MODEL = os.environ.get('CHAT_RUNNER_MODEL', 'sonnet')   # дефолт sonnet (дешевше за opus ~5x)
# acceptEdits is fine for MVP: cwd = shared-knowledge (notes/tools), not prod code.
# Risk: claude can edit files / run Bash autonomously in the repo. Stage 4 lets
# the user flip a channel to "plan" (read-only proposing) per channel via
# channels/<id>/permission (see channel_permission).
PERMISSION_MODE = os.environ.get('CHAT_RUNNER_PERMISSION', 'acceptEdits')

# ---- Stage 4: per-channel model + permission mode --------------------------
# Valid CLI aliases for --model (full IDs also accepted). Verified on v2.1.169:
#   claude --help -> --model accepts 'opus' | 'sonnet' | 'haiku' or full names.
# We keep bare aliases (never go stale): on CLI >= 2.1.201 each family alias
# (sonnet/opus/haiku) resolves to the newest release of that family. No pinning
# needed; aliases auto-track newest.
MODEL_ALIASES = {'opus', 'sonnet', 'haiku', 'fable'}   # 'auto' прибрано (рішення власника, 2026-07-07):
# людські лейбли Швидкий/Баланс/Розумний/Геній = haiku/sonnet/opus/fable, без фейк-авто.
# Fable (Геній, флагман — вищий за Opus, НЕ швидкий тір) додано 2026-07-12, наймінг
# виправлено того ж дня після звірки з офіц. доками Anthropic (власник правильно засумнівався
# в первинному «Блискавка»/найшвидший — усе було навпаки). Станом на CLI 2.1.278 (перевірено
# 2026-09-20) аліас 'fable' УЖЕ нативний і сам резолвиться в найновіший реліз родини.
# Стале значення каналу 'auto' більше не проходить перевірку → падає на дефолт (sonnet).
# Родина -> конкретна модель більше НЕ пінається тут руками (specs/claude-model-catalog-auto).
# Ручний пін протухав з кожним релізом і розходився з фронтом. Тепер значення для --model
# береться з каталогу того самого CLI (claude_models.py, get_server_info()['models']),
# а без каталогу хід їде на голому аліасі родини: CLI сам розгорне його в найновіший реліз.
import claude_models as claude_models_lib  # noqa: E402
CLAUDE_MODELS_CACHE = os.path.join(DIR, 'claude-models.json')


def claude_catalog():
    """Один на процес кеш каталогу моделей Клода для CLAUDE_BIN (не вбудованого CLI SDK)."""
    return claude_models_lib.catalog_for(CLAUDE_BIN, CLAUDE_MODELS_CACHE, log=log)


def _claude_families():
    """Каталог {родина: запис} без блокування ходу, або None (тоді голі аліаси).
    LOGOPSIS_CLAUDE_CATALOG=off вимикає його: тести не мають смикати живий CLI у фоні
    і писати кеш, від якого залежатиме порядок інших тестів (tests/conftest.py)."""
    if os.environ.get('LOGOPSIS_CLAUDE_CATALOG') == 'off':
        return None
    return claude_catalog().get(block=False)


# Verified choices for --permission-mode on v2.1.169:
#   acceptEdits | auto | bypassPermissions | default | dontAsk | plan
# We expose only the two safe extremes to the UI: acceptEdits (auto-write) and
# plan (research + propose, never writes). Guard against anything unexpected.
PERMISSION_MODES = {'acceptEdits', 'auto', 'bypassPermissions',
                    'default', 'dontAsk', 'plan'}


_AUTO_HARD = ('debug', 'дебаг', 'рефактор', 'refactor', 'implement', 'реаліз',
              'код', 'code', 'помилк', 'error', 'bug', 'баг', 'архітектур',
              'architect', 'fix', 'пофікс', 'build', 'збери', 'міграц', 'migrat',
              'sql', 'regex', 'алгоритм', 'optimi', 'оптиміз', 'deploy', 'деплой')


# ── Знімок рантайму меседжа, що виконується (рішення власника, 2026-08-06) ──
# Модель і зусилля тепер властивість МЕСЕДЖА: сервер знімає їх у момент відправки
# і кладе у файл черги (ключ `runtime`). Тут вони живуть рівно на час свого ходу.
#
# Ключ = канал, і цього досить: на канал є РІВНО ОДИН робочий тред (див. poll_once
# + _active), тобто два ходи одного каналу ніколи не йдуть одночасно. Тред-локал
# натомість не підійшов би: движок SDK читає зусилля вже з іншого треду.
#
# Порожній словник = «знімка нема» (старий файл черги, створений до цієї правки,
# або службовий хід на кшталт стиснення контексту). Тоді всі читачі падають назад
# на файли каналу, тобто на стару поведінку, і НЕ падають з помилкою.
_job_runtime = {}
_job_runtime_lock = threading.Lock()


def set_job_runtime(channel, job):
    """Запамʼятати знімок рантайму цього елемента черги на час його ходу.

    Приймає ВЕСЬ job, а не готовий словник: битий/старий/чужий тип у полі
    `runtime` тут же перетворюється на «знімка нема», і жоден читач нижче про це
    вже не думає."""
    snap = job.get('runtime') if isinstance(job, dict) else None
    if not isinstance(snap, dict):
        snap = {}
    clean = {}
    model = snap.get('model')
    if isinstance(model, str) and model.strip():
        clean['model'] = model.strip()
    effort = snap.get('effort')
    if isinstance(effort, str) and effort.strip():
        clean['effort'] = effort.strip().lower()
    # Мова інтерфейсу, чинна на момент відправки (specs/lang-channel-to-backend,
    # К3/К4). Той самий фільтр, що model/effort: невалідний тип чи порожнє поле
    # означає «знімка нема», і current_lang() лікує це запасним шляхом сама.
    lang = snap.get('lang')
    if isinstance(lang, str) and lang.strip():
        clean['lang'] = lang.strip().lower()
    # Учасник кімнати, якому адресоване саме це повідомлення (фаза 2). Сервер
    # ухвалив рішення на момент відправки; тут ми його ВИКОНУЄМО, а не
    # переобираємо. Поля нема = кімнати нема, і все працює як фаза 1.
    speaker = snap.get('speaker')
    if isinstance(speaker, str) and speaker.strip():
        clean['speaker'] = speaker.strip()
    # Родина і глибина Antigravity на момент відправки (specs/agy-model-family-depth,
    # К9). Той самий чистильник, що читає файл каналу: битий вибір = знімка нема.
    agy_choice_snap = agy_models_lib.clean_choice(snap.get('agyModel'))
    if agy_choice_snap:
        clean['agyModel'] = agy_choice_snap
    with _job_runtime_lock:
        _job_runtime[channel] = clean
    return clean


def clear_job_runtime(channel):
    """Хід скінчився: знімок більше не діє (наступний прийде зі своїм)."""
    with _job_runtime_lock:
        _job_runtime.pop(channel, None)


def job_runtime(channel):
    """Знімок поточного меседжа: {} коли його нема (запасний шлях на файли каналу)."""
    with _job_runtime_lock:
        return dict(_job_runtime.get(channel) or {})


def job_effort(channel):
    """Рівень зусиль зі знімка меседжа, або None. Читає engine_sdk через deps."""
    return job_runtime(channel).get('effort') or None


def _auto_model(prompt):
    """Pick a model by turn complexity (used when a channel's model == 'auto').
    Short/simple -> haiku (cheap+fast); hard/long -> opus; otherwise sonnet."""
    p = (prompt or '').lower()
    n = len(prompt or '')
    if n > 1500 or any(k in p for k in _AUTO_HARD):
        return 'opus'
    if n < 240:
        return 'haiku'
    return 'sonnet'


def channel_model(channel, prompt=None):
    """Model for the turn being run: the MESSAGE's snapshot first, then the
    per-channel file (channels/<id>/model), then the global default. Accepts a bare
    alias (opus/sonnet/haiku/fable) or a full model id. A global default of 'auto'
    is resolved per turn from the prompt complexity (see _auto_model).

    Знімок стоїть ПЕРШИМ навмисне: інакше меседж, відправлений під Сонетом і
    підхоплений уже після перемикання на Опус, поїхав би Опусом. Файл каналу
    лишається запасним шляхом для старих елементів черги і для службових ходів
    (стиснення контексту), у яких свого знімка нема."""
    if channel in _model_safe_retry:
        return 'sonnet'          # one-shot safe fallback after a model/CLI error
    v = MODEL
    snap = job_runtime(channel).get('model')
    if snap and (snap in MODEL_ALIASES or snap.startswith('claude-')):
        v = snap
    else:
        # Знімка нема (старий елемент черги, службовий хід) або в ньому лежить
        # значення, яке більше не проходить перевірку (напр. застаріле 'auto'):
        # обидва випадки лікуються однаково, файлом каналу, як було до правки.
        try:
            p = os.path.join(CHANNELS_DIR, channel, 'model')
            if os.path.exists(p):
                val = open(p).read().strip()
                if val and (val in MODEL_ALIASES or val.startswith('claude-')):
                    v = val
        except Exception as e:
            log(f'{channel}: model read failed: {e}')
    if v == 'auto':
        v = _auto_model(prompt)          # 'auto' -> a family alias (opus/sonnet/haiku)
    # Return the alias as-is (opus/sonnet/haiku) or a full model id the user typed.
    # CLI aliases auto-track the newest release, so no remap needed.
    return v


def current_lang(channel):
    """Мова інтерфейсу для ходу, який виконується в цьому каналі
    (specs/lang-channel-to-backend, розділ 6: ЄДИНИЙ публічний спосіб дізнатись
    мову, К8). Порядок джерел той самий, що в channel_model: знімок МЕСЕДЖА стоїть
    першим, інакше меседж, надісланий англійською і підхоплений з черги вже після
    перемикання на українську, поїхав би українською (К3/К4).

    На відміну від моделі мова НЕ файл каналу: вона стан ЗАСТОСУНКУ (розділ 1
    спеки), тому запасний шлях це один глобальний файл LANG_FILE у LOGOPSIS_HOME
    (К5), а не channels/<id>/lang. Невідомий чи битий код, порожній чи відсутній
    файл: усе це сміття лікується однаково, DEFAULT_LANG (К6, К7), ніколи винятком.

    МЕЖА СКОУПУ Ф0: ця функція нікуди не викликається, крім тестів. Перший
    реальний споживач зʼявиться у Ф1 зі своєю спекою."""
    snap = job_runtime(channel).get('lang')
    if snap in AVAILABLE_LANGS:
        return snap
    try:
        if os.path.exists(LANG_FILE):
            val = open(LANG_FILE, encoding='utf-8').read().strip()
            if val in AVAILABLE_LANGS:
                return val
    except Exception as e:
        log(f'{channel}: lang read failed: {e}')
    return DEFAULT_LANG


def _resolve_model_args(model):
    """Build the ['--model', ...] CLI args for a chosen family. Never returns an
    empty/worst default.
      - Family alias -> the model the CLI's own catalog names for it (claude_models).
      - No catalog / family missing / safe retry -> the bare family alias (CLI resolves).
      - Full id -> passed through untouched."""
    fam = model if model in claude_models_lib.FAMILIES else None
    if fam is not None:
        if _FORCE_BARE['on']:
            # safe one-shot retry after a model/CLI error: plain alias only.
            return ['--model', fam]
        try:
            families = _claude_families()
        except Exception as e:
            log(f'claude catalog read failed: {e}')
            families = None
        return ['--model', claude_models_lib.model_arg(fam, families)]
    # A full model id (subscription full name or a provider inference-profile id):
    # trust the user/config, do not remap.
    if model and model.startswith(('claude-', 'us.', 'eu.', 'apac.', 'anthropic.')):
        return ['--model', model]
    return ['--model', 'sonnet']   # sane default, never worst


def channel_permission(channel):
    """Per-channel permission mode (channels/<id>/permission). Falls back to the
    global default (acceptEdits). Only known CLI modes are honored."""
    try:
        p = os.path.join(CHANNELS_DIR, channel, 'permission')
        if os.path.exists(p):
            v = open(p).read().strip()
            if v in PERMISSION_MODES:
                return v
    except Exception as e:
        log(f'{channel}: permission read failed: {e}')
    return PERMISSION_MODE
POLL_SECONDS = float(os.environ.get('CHAT_RUNNER_POLL', '1.5'))
# Turn guard. IMPORTANT: idle no longer aborts. A silent turn keeps running.
#   IDLE_TIMEOUT  — NOT a killer anymore. After this many seconds of total silence
#                   from claude (no token, no tool step) the runner only flips the
#                   live panel into a calm "still working" signal (longRunning) so
#                   the UI can show "велика задача, ще працюю". The turn is NEVER
#                   killed for being quiet; the user's Стоп button is the control.
#   TURN_TIMEOUT  — the ONLY automatic killer: an absolute backstop for a runaway
#                   agentic LOOP that emits forever. Generous (1h) so it never kills
#                   a normal task; it only catches a pathological infinite loop, and
#                   even then it keeps whatever partial streamed (calm message).
# History: an earlier TURN_TIMEOUT=600 wall-clock, then a 180s IDLE auto-abort, both
# silently killed legit long turns and surfaced the scary "took too long / press again"
# bubble. That auto-kill is gone for good; long/silent work just keeps running.
IDLE_TIMEOUT = int(os.environ.get('CHAT_RUNNER_IDLE_TIMEOUT', '180'))
TURN_TIMEOUT = int(os.environ.get('CHAT_RUNNER_TIMEOUT', '3600'))
# Full Claude Code power EXCEPT the two tools that genuinely cannot work in a
# fire-and-forget headless turn: AskUserQuestion and ExitPlanMode both BLOCK
# waiting for a human reply that never comes, hanging the turn until timeout.
# Everything else (Bash, Edit, Write, Task subagents, Read, Grep, Web) stays, so
# the chat matches native Claude Code for any task it just goes and does. The
# only thing it cannot do vs native is ask you mid-turn / interactive approval.
# Override via CHAT_RUNNER_DISALLOW (space-separated).
DISALLOWED_TOOLS = os.environ.get(
    'CHAT_RUNNER_DISALLOW',
    'AskUserQuestion ExitPlanMode'
).split()
# Stage 3: stream-json by default (live tool steps + streaming text). Set
# CHAT_RUNNER_STREAM=0 to fall back to the old single-shot json mode.
STREAM_MODE = os.environ.get('CHAT_RUNNER_STREAM', '1') not in ('0', 'false', 'no')

# Stage A (warm session): keep ONE persistent `claude` (stream-json IN+OUT) alive
# per channel and feed each turn via stdin, instead of cold-spawning `claude -p`
# every message. Verified A/B: cold ~7.6s/turn (spawn+MCP load every time) vs warm
# ~2.2s/turn steady-state, ~5.4s saved per follow-up. DEFAULT now; the proven cold
# path stays a one-flag emergency fallback:
#   CHAT_RUNNER_WARM=0  -> revert to cold-spawn per turn.
WARM_MODE = os.environ.get('CHAT_RUNNER_WARM', '1') not in ('0', 'false', 'no')

# Phase 1 (SDK engine): route turns through claude-agent-sdk (engine_sdk.py)
# instead of the cold/stream/warm `claude -p` parsers. ON by default since
# 2026-06-24 (Phase 1 verified: test channel PASS, parity confirmed). Warm stays
# the automatic per-turn FALLBACK if the SDK import or transport fails, so a bad
# SDK turn can never break the chat. Disable globally with CHAT_RUNNER_SDK=0
# (revert). The SDK gives native context compaction and correct per-message usage,
# which is what kills the 218%/581% meter blow-ups and the auto-compact-every-message bug.
SDK_MODE = os.environ.get('CHAT_RUNNER_SDK', '1') not in ('0', 'false', 'no', 'off')
_warm = {}                 # channel -> {'proc','sid','stderr'(deque)}
_warm_lock = threading.Lock()   # guards _warm dict + spawn (NOT the turn itself;
                                 # per-channel turns are already serialized by the
                                 # single worker thread per channel)


def _terminate_proc_group(proc):
    """Best-effort tear down a warm claude and its child subprocesses (MCP
    servers), then a direct proc.kill() belt-and-suspenders. Never raises.

    Дерево валить ПЛАТФОРМА, а не killpg тут. На POSIX вона робить те саме, що
    робилось інлайном (гарда safe_pgid -> killpg, а для неізольованої дитини ще
    й `pkill -P` по прямих дітях). На Windows інлайн-версія була порожньою: там
    немає getpgid, тож `_safe_pgid` завжди віддавав None, гілка killpg не бралась
    зовсім, і лишався голий `proc.kill()`, який вбиває ЛИШЕ батька. MCP-сервери і
    ноди під теплим claude ставали сиротами при кожному рециклі. У платформі для
    цього вже написаний `taskkill /F /T`."""
    import time as _time
    if PLATFORM is not None:
        try:
            PLATFORM.kill_process_tree(proc.pid)
        except Exception:
            pass
    for _ in range(5):                       # ~0.5s grace: дати дереву осісти
        if proc.poll() is not None:
            break
        _time.sleep(0.1)
    try:
        proc.kill()
    except Exception:
        pass


def recycle_channel(channel):
    """Tier 1 engine recycle: evict this channel's warm claude so the NEXT turn
    cold-respawns a FRESH process that re-reads .mcp.json / skills / CLAUDE.md,
    while --resume (via _resume_or_seed_args) restores conversation context from
    the session .jsonl. Returns True if a live engine was evicted, False if there
    was nothing to recycle. Raises ValueError on a bad channel id. Thread-safe:
    grabs _warm_lock to pop, then terminates OUTSIDE the lock (kill may sleep).

    Also drops the frozen project map (see _project_map) and the frozen tone section
    (see _tone_section): a recycle means the prompt cache is being rebuilt anyway, so
    re-reading the ecosystem and the freshly learned tone profile here is free. That
    makes «хард рефреш» the deliberate way to refresh both. Runs BEFORE the early
    return so it happens even when there was no live engine to evict."""
    if not channel or '/' in channel or '..' in channel:
        raise ValueError('bad channel')
    for _stale in (project_map_path(channel), tone_snapshot_path(channel)):
        try:
            os.unlink(_stale)
        except Exception:
            pass
    with _warm_lock:
        e = _warm.pop(channel, None)
    if not e:
        return False
    proc = e.get('proc')
    if proc is None:
        return False
    _terminate_proc_group(proc)
    return True

# Phase B — in-UI tool-permission gate. DEFAULT ON (parity with the VS Code
# extension: approve before Bash/Edit/Write/MultiEdit/mcp__* run). The warm spawn
# injects a PreToolUse hook (hooks/perm-gate.cjs) that shows an Allow/Deny card in
# Logopsis. "Allow for session" remembers a tool so it stops asking. Verified 18/18.
#   CHAT_RUNNER_PERMUI=0  -> disable the gate (back to auto-accept).
PERMUI_MODE = os.environ.get('CHAT_RUNNER_PERMUI', '1') not in ('0', 'false', 'no')
PERM_HOOK = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'hooks', 'perm-gate.cjs')
PERM_PORT = os.environ.get('CHAT_PERM_PORT') or os.environ.get('VIZ_CHAT_PORT', '5555')
PERM_MATCHER = 'Bash|Edit|Write|MultiEdit|NotebookEdit|mcp__.*'

def _resolve_node():
    """Absolute path to a `node` binary. CRITICAL under launchd: the service PATH
    often lacks nvm/homebrew, so a bare `node` in the hook command silently fails
    (a failed PreToolUse hook is non-blocking -> the tool runs UNGATED). Resolve an
    absolute node so the gate hook always executes."""
    for d in (os.environ.get('PATH', '') or '').split(os.pathsep):
        if d:
            c = os.path.join(d, 'node')
            if os.path.exists(c):
                return c
    cands = sorted(glob.glob(os.path.expanduser('~/.nvm/versions/node/*/bin/node')), reverse=True)
    cands += ['/opt/homebrew/bin/node', '/usr/local/bin/node', '/usr/bin/node']
    for c in cands:
        if os.path.exists(c):
            return c
    return 'node'

NODE_BIN = os.environ.get('CHAT_PERM_NODE') or _resolve_node()

# Detached-agent bridge. The harness Agent/Task tool runs a subagent INSIDE the turn,
# so it dies with the turn: no code, no commit, no report. hooks/agent-bridge-router.cjs
# denies that tool and hands the model the agent-run.cjs command instead. It shipped in
# the bundle from day one but NOTHING registered it, so a packaged app kept losing agents
# exactly the way the repo did before the gate existed (owner decision, 2026-08-05).
#   CHAT_RUNNER_AGENTBRIDGE=0  -> do not register it (harness Agent tool works as-is).
AGENT_BRIDGE_MODE = os.environ.get('CHAT_RUNNER_AGENTBRIDGE', '1') not in ('0', 'false', 'no')
AGENT_BRIDGE_HOOK = os.path.join(os.path.dirname(os.path.abspath(__file__)),
                                 'hooks', 'agent-bridge-router.cjs')
AGENT_BRIDGE_MATCHER = 'Task|Agent'


def _perm_settings_arg():
    """--settings JSON-string that ADDS our PreToolUse hooks (merges with the project's
    existing hooks; the approval hook gets a high timeout so it can wait for a human
    click, the router answers instantly). Uses an ABSOLUTE node path so the hooks run
    even under a stripped launchd PATH. Returns None when both are disabled.

    ORDER MATTERS, and only in one direction: the router must never be registered on a
    build where /api/agent-spawn is broken, because then the harness tool is denied AND
    the bridge fails, i.e. no agents at all instead of dying ones."""
    pre = []
    if PERMUI_MODE:
        pre.append({'matcher': PERM_MATCHER, 'hooks': [
            {'type': 'command', 'command': f'"{NODE_BIN}" "{PERM_HOOK}"', 'timeout': 3600}]})
    if AGENT_BRIDGE_MODE and os.path.exists(AGENT_BRIDGE_HOOK):
        pre.append({'matcher': AGENT_BRIDGE_MATCHER, 'hooks': [
            {'type': 'command', 'command': f'"{NODE_BIN}" "{AGENT_BRIDGE_HOOK}"',
             'timeout': 20}]})
    return json.dumps({'hooks': {'PreToolUse': pre}}) if pre else None

# Internal err marker returned when a turn was intentionally killed by /api/stop.
# process_channel recognizes it and exits quietly (no error bubble), since the
# server already cleared queue/busy/live/pid and (optionally) wrote a "stopped"
# bubble itself.
STOP_SENTINEL = '__stopped__'

# Internal err marker for an IDLE abort (claude went silent for IDLE_TIMEOUT).
# Carries the silence duration so process_channel can render the partial output
# that streamed before the turn wedged, plus a small "stopped after N s" note,
# instead of throwing away the work behind a generic timeout error bubble. The
# suffix is the integer seconds of dead air.
IDLE_SENTINEL_PREFIX = '__idle__:'


def idle_sentinel(seconds):
    return f'{IDLE_SENTINEL_PREFIX}{int(seconds)}'


def parse_idle_sentinel(err):
    """If `err` is an idle-abort sentinel, return the silence seconds (int),
    else None. Lets process_channel branch without string-matching elsewhere."""
    if isinstance(err, str) and err.startswith(IDLE_SENTINEL_PREFIX):
        try:
            return int(err[len(IDLE_SENTINEL_PREFIX):])
        except ValueError:
            return 0
    return None

# ---- Error classification + session healing ----------------------------------

# Patterns that indicate a policy or AUP-level rejection from the Claude API.
# These are permanent for the current session (the context triggered a block),
# so we rotate the session-id so the next message starts fresh.
_POLICY_PATTERNS = [
    'usage policy',
    'usage_policy',
    'unable to respond to this request',
    'violate',
    'violates',
    'aup',
]


def _is_policy_error(err: str) -> bool:
    """True when the error string looks like a Usage Policy / AUP rejection."""
    if not err:
        return False
    low = err.lower()
    return any(p in low for p in _POLICY_PATTERNS)


def rotate_session_id(channel: str) -> str:
    """Generate a fresh UUID, write it to channels/<id>/session-id, and return
    it. The next turn will start a brand-new Claude session instead of resuming
    the poisoned one. Called on policy/AUP errors and on context compaction."""
    new_sid = str(uuid.uuid4())
    sid_path = os.path.join(CHANNELS_DIR, channel, 'session-id')
    try:
        with open(sid_path, 'w') as f:
            f.write(new_sid)
        log(f'{channel}: session rotated -> {new_sid[:8]}')
    except Exception as e:
        log(f'{channel}: session rotate write failed: {e}')
    return new_sid


# ---- Context auto-compaction --------------------------------------------------
# When a channel's running context (contextPct in usage.json) crosses this
# threshold, the next user turn is preceded by a compaction: summarize the whole
# conversation in one claude turn, rotate to a fresh session id, and seed the
# next REAL prompt with that summary as a preamble. The new session then starts
# tiny (summary + question) instead of carrying the whole bloated transcript,
# which is what burned $22 and tripped the Usage Policy size guard.
#
# contextPct in usage.json is a PERCENT (0..100), so 0.80 threshold == 80%.
# Raised 0.35 -> 0.80 on 2026-06-22: warm-session (Stage A, stream-json stdin,
# prompt caching) removed the original $22 / Usage-Policy reason for compacting
# early, so we now let context grow close to native auto-compact (~83%) before
# our own controlled summarize+rotate kicks in. Override via CHAT_COMPACT_THRESHOLD.
# The value later sat at 0.50 and is restored to 0.80 on 2026-08-23: a single
# file-reading agy turn can eat a large share of the window at once, so a
# half-window gate fired every few turns (16 dividers over 80 messages in chat-215).
COMPACT_THRESHOLD = float(os.environ.get('CHAT_COMPACT_THRESHOLD', '0.80'))

# Prompt used to ask the model to summarize its own conversation before we rotate
# the session. No em-dash by request (uses periods/commas/colons instead).
#
# Форма списана з CHECKPOINT самого Antigravity (reference/agy-own-context-memory.md).
# Двигун у своєму чекпойнті не просить «підсумуй», він ДИКТУЄ секції, і саме тому
# його підсумок переживає ротацію краще за наш. Тут раніше стояв один вільний абзац
# «стисло підсумуй, структуруй коротко по пунктах», тобто структуру щоразу обирала
# модель: на одному ході виходив список фактів зі шляхами, на іншому переказ подій
# без жодного шляху, без жодного числа і без того, ЧОГО просив користувач. Ротація
# після такого підсумку губила не обсяг, а сам предмет розмови.
#
# Стеля 6000 символів стоїть тому, що це не артефакт для читання, а преамбула:
# seed_prompt_with_summary підклеює її до СПРАВЖНЬОГО промпта на першому ході після
# кожного стиснення. Кирилиця токенізується приблизно по 2.5-3 символи на токен,
# тобто 6000 символів це десь 2000-2400 токенів, 1.2% вікна Клода на 200k і 0.24%
# вікна gemini на 1M. Сам сід через це ніколи не стає причиною наступного стиснення.
# Знизу межа теж робоча: 6000 це близько 1000 символів на секцію, чого вистачає на
# два десятки пронумерованих запитів плюс шляхи і хеші дослівно.
# МОВА ПІДСУМКУ (Д6). Джерело мови тут ЗМІСТ розмови, а не інтерфейс, і причин
# для цього дві, обидві важать більше за симетрію з рештою беку.
#
# Перша: підсумок це конденсат уже сказаного. Він переносить цитати, назви гілок,
# формулювання запитів людини «її формулюваннями» (секція друга). Мова інтерфейсу
# змусила б модель ПЕРЕКЛАСТИ все це, а переклад ідентифікаторів і дослівних
# запитів це рівно та втрата, проти якої і писалась уся форма вище.
#
# Друга: seed_prompt_with_summary клеїть цей текст ПЕРЕД справжнім промптом
# людини, тобто підсумок стає найближчим до розмови контекстом наступного ходу.
# Українськомовний підсумок над англійською розмовою це той самий failure mode,
# що вже ловили на капелюсі персони і на нагадуванні agy: другий шар б'є перший.
# Тут він ще підступніший, бо мову диктує не інструкція, а сам текст поруч.
#
# Мову НЕ читаємо через current_lang свідомо: усі три виклики (agy-стрім і дві
# гілки Клода) віддають цей рядок двигунові, який ЩОЙНО прочитав усю розмову,
# тому він визначає мову точніше за стан застосунку, і жодної проводки для цього
# не треба. Заголовки теж ідуть мовою розмови: аркуш з українськими заголовками
# і англійським тілом був би документом з двох мов, а це гірше за обидві.
COMPACT_SUMMARY_PROMPT = (
    'Підсумуй усю цю розмову для самого себе: наступний хід почнеться з чистого '
    'аркуша, і цей підсумок буде єдиним, що ти памʼятаєш. Пиши фактами, а не '
    'переказом подій. Ідентифікатори (шляхи файлів, імена функцій, назви гілок, '
    'хеші комітів, порти, заміряні числа) переноси ДОСЛІВНО, не переформульовуй і '
    'не скорочуй їх. Не додавай нічого, чого не було в розмові.\n\n'
    'Обовʼязкова структура, рівно ці шість заголовків і рівно в цьому порядку:\n\n'
    '# Ціль користувача\n'
    'Чого користувач зрештою домагається в цьому каналі. Одне або два речення.\n\n'
    '# Запити користувача в хронологічному порядку\n'
    'Пронумерований список того, що просив САМ користувач, його формулюваннями. '
    'Це список його запитів, а не переказ виконаної тобою роботи.\n\n'
    '# Поточний стан\n'
    'Що зроблено, що в роботі, що закомічено, що зламано або відкладено.\n\n'
    '# Відкриті питання і рішення, що чекають на користувача\n'
    'Те, без чого не можна рухатись далі, і що саме має вирішити користувач.\n\n'
    '# Домовленості і заборони\n'
    'Обмеження, які поставив користувач, і те, що прямо відкинуто як варіант.\n\n'
    '# Важливі шляхи, імена, числа\n'
    'Шляхи файлів, гілки, хеші, порти, назви каналів, заміряні значення. Дослівно.\n\n'
    'Порожню секцію не викидай, постав під нею «нема». Пиши ТІЄЮ МОВОЮ, якою '
    'велась сама розмова, а не мовою цієї інструкції: шість заголовків вище '
    'переклади тією ж мовою, їхній порядок і зміст лишаються ті самі. До 6000 '
    'символів разом із заголовками. Без вступів, без висновків, без коду, без '
    'довгих тире, тільки сам підсумок.'
)


def usage_path(channel):
    return os.path.join(CHANNELS_DIR, channel, 'usage.json')


# Роздільний облік контексту по двигунах (specs/agy-compaction, К7).
#
# Лічильник контексту жив ОДИН на канал, і в нього писав кожен двигун: Клод через
# write_usage у process_channel, agy тим самим викликом, бо run_agy_stream віддає
# сумісний `data`. Відсотки при цьому міряні проти РІЗНИХ вікон (agy рахує gemini
# проти 1M, Клод проти вікна своєї моделі), тож на каналі, де двигун колись
# зміниться, гейт стиснення читав би суміш двох різних шкал.
#
# Форма файлу: числа кожного двигуна лежать у `byProvider[<двигун>]`, а верхній
# рівень лишається ДЗЕРКАЛОМ того двигуна, який ходив останнім. Дзеркало це не
# надлишок, а сумісність: сервер віддає usage.json як є (server.py:8114), і ряд
# «Контекст чату» в поповері читає саме верхній рівень. Гроші (cumulativeCostUsd)
# у розділення НЕ йдуть: це гроші каналу, а не двигуна.
USAGE_CONTEXT_FIELDS = ('lastTurnInput', 'lastTurnCacheRead', 'lastTurnCacheCreate',
                        'lastTurnContext', 'lastTurnOutput', 'contextWindow',
                        'contextPct', 'activeModel', 'ts')


def read_context_pct(channel, provider=None):
    """Running contextPct (0..100) ОДНОГО двигуна каналу, або None коли в нього ще
    нема жодного ходу (новій сесії нема чого стискати).

    provider=None означає «двигун, який веде канал зараз» (channel_provider).

    Старий формат (без byProvider) читається як лічильник ТОГО двигуна, який
    записаний у файлі `provider` каналу, а за відсутності файлу як клодівський:
    саме він ці числа й писав. Для будь-якого іншого двигуна старий файл віддає
    None, бо приписати йому чуже число означало б збрехати гейту."""
    try:
        p = usage_path(channel)
        if not os.path.exists(p):
            return None
        data = json.load(open(p))
        prov = provider or channel_provider(channel)
        by = data.get('byProvider')
        if isinstance(by, dict):
            slot = by.get(prov)
            if not isinstance(slot, dict):
                return None
            v = slot.get('contextPct')
            return float(v) if v is not None else None
        if prov != channel_provider(channel):
            return None
        v = data.get('contextPct')
        return float(v) if v is not None else None
    except Exception as e:
        log(f'{channel}: contextPct read failed: {e}')
        return None


def reset_context_pct(channel, provider=None):
    """After a rotate+compact the old usage.json still reports the big context.
    Zero out the context fields so the meter (and the auto-compact gate) reflect
    the fresh, tiny session immediately. The next real turn overwrites this with
    the true numbers via write_usage.

    Обнуляємо і слот двигуна, і дзеркало верхнього рівня. Дзеркало тому, що
    стиснення завжди веде двигун САМОГО каналу, тобто той, чиї числа зараз і
    стоять нагорі; лишити їх великими означало б показати людині повний метр
    одразу після стиснення."""
    try:
        p = usage_path(channel)
        data = {}
        if os.path.exists(p):
            try:
                data = json.load(open(p)) or {}
            except Exception:
                data = {}
        data['lastTurnContext'] = 0
        data['lastTurnInput'] = 0
        data['lastTurnCacheRead'] = 0
        data['lastTurnCacheCreate'] = 0
        data['contextPct'] = 0
        data['compactedAt'] = datetime.now().isoformat()
        prov = provider or channel_provider(channel)
        by = data.get('byProvider')
        if not isinstance(by, dict):
            by = {}
        slot = by.get(prov)
        slot = dict(slot) if isinstance(slot, dict) else {}
        slot['lastTurnContext'] = 0
        slot['lastTurnInput'] = 0
        slot['lastTurnCacheRead'] = 0
        slot['lastTurnCacheCreate'] = 0
        slot['contextPct'] = 0
        by[prov] = slot
        data['byProvider'] = by
        atomic_write_json(p, data)
    except Exception as e:
        log(f'{channel}: contextPct reset failed: {e}')


def pending_summary_path(channel):
    return os.path.join(CHANNELS_DIR, channel, 'pending-summary')


def read_pending_summary(channel):
    """Return a queued compaction summary (and delete the marker) so the next
    real prompt can carry it as a preamble. Returns '' when none waits."""
    try:
        p = pending_summary_path(channel)
        if not os.path.exists(p):
            return ''
        s = open(p, encoding='utf-8').read().strip()
        try:
            os.remove(p)
        except OSError:
            pass
        return s
    except Exception as e:
        log(f'{channel}: pending-summary read failed: {e}')
        return ''


def write_pending_summary(channel, summary):
    try:
        p = pending_summary_path(channel)
        os.makedirs(os.path.dirname(p), exist_ok=True)
        with open(p, 'w', encoding='utf-8') as f:
            f.write(summary)
    except Exception as e:
        log(f'{channel}: pending-summary write failed: {e}')


def autocompact_enabled(channel):
    """Per-channel auto-compact toggle (channels/<id>/autocompact = 1|0).
    Default ON when the file is absent."""
    try:
        p = os.path.join(CHANNELS_DIR, channel, 'autocompact')
        if not os.path.exists(p):
            return True
        return open(p).read().strip() not in ('0', 'false', 'no', 'off')
    except Exception:
        return True


def compact_request_path(channel):
    return os.path.join(CHANNELS_DIR, channel, 'compact-request')


def recycle_request_path(channel):
    """Marker dropped by server.py's POST /api/engine-restart ("хард рефреш"). When
    present, poll_once() evicts this channel's warm engine (recycle_channel) so the
    NEXT turn cold-respawns fresh. Consumed even with an empty queue (parity with the
    compact marker)."""
    return os.path.join(CHANNELS_DIR, channel, 'recycle')


# Заборона «привітатись із підсумком». Списано з CHECKPOINT самого Antigravity
# (reference/agy-own-context-memory.md), де останнім абзацом стоїть пряме
# «DO NOT ACKNOWLEDGE THIS CHECKPOINT MESSAGE». У нас такого не було зовсім, і
# перший хід після стиснення регулярно починався з «бачу підсумок попередньої
# частини розмови», хоча користувач у цей момент питав про щось інше. Для нього
# стиснення це внутрішня механіка раннера, а не подія, яку треба обговорювати.
COMPACT_SILENCE_NOTE = (
    'Цей підсумок службовий. Користуйся ним мовчки: не переказуй його, не '
    'посилайся на нього і не згадуй ані сам підсумок, ані те, що розмову '
    'стискали. Відповідай одразу на [Нове повідомлення], так ніби памʼятаєш усе '
    'сам.'
)


def compaction_transcript_hint(channel):
    """Рядок «повний журнал розмови лежить ось тут» для сідової преамбули, або ''
    коли теки каналу на диску нема.

    Це друга половина того, що має CHECKPOINT двигуна і чого не мали ми: підсумок
    завжди щось відкидає, тому поруч із ним має стояти адреса нестисненого
    оригіналу. Двигун МОЖЕ його прочитати: agy стартує з cwd = REPO_ROOT і з
    --add-dir REPO_ROOT (блок «РІШЕННЯ ПРО ДОСТУП» і прапорці в run_agy_stream),
    Клод так само ходить у корені проєкту. Тобто вказівник робочий, а не
    декоративний.

    Сам журнал у промпт НЕ кладеться: сенс стиснення саме в тому, щоб його там не
    було. Кладеться лише шлях.

    Теку перевіряємо тут, у момент сіду, а не при імпорті: впевнено неправильний
    шлях гірший за відсутній, бо модель піде його читати, отримає порожньо і
    зробить висновок, що історії не існує."""
    try:
        d = os.path.join(CHANNELS_DIR, channel)
        if not os.path.isdir(d):
            return ''
        return (
            'Повна нестиснена розмова лежить на диску, у теці '
            f'{d} (по одному файлу NNNN.json на кожне повідомлення, у '
            'хронологічному порядку). Зазирай туди тільки коли потрібна деталь, '
            'якої нема в підсумку.'
        )
    except Exception:
        return ''


def seed_prompt_with_summary(channel, prompt):
    """If a compaction summary is pending for this channel, prepend it to the
    user prompt so the first turn of the fresh session carries the prior context.
    Always returns the (possibly augmented) prompt.

    Маркери [Підсумок попередньої частини цього чату] і [Нове повідомлення] це
    контракт (specs/agy-compaction, К2), перейменовувати їх не можна. Між ними
    додано дві речі з чекпойнта двигуна: адреса повного журналу і заборона цей
    підсумок згадувати."""
    summary = read_pending_summary(channel)
    if not summary:
        return prompt
    log(f'{channel}: seeding next prompt with compaction summary ({len(summary)} chars)')
    head = f'[Підсумок попередньої частини цього чату]\n{summary}'
    extra = [x for x in (compaction_transcript_hint(channel), COMPACT_SILENCE_NOTE) if x]
    if extra:
        head += '\n\n' + '\n\n'.join(extra)
    return (
        f'{head}\n\n'
        '[Нове повідомлення]\n'
        f'{prompt}'
    )


def rotate_agy_conversation(channel):
    """Ротація нитки Antigravity: очищення channels/<id>/agy_conversation.

    Це повний аналог rotate_session_id, просто на іншому боці. Памʼять agy живе
    не в нас, а в conversation_id на боці двигуна, і продовження розмови це
    прапорець --conversation (runner.py: run_agy_stream). Порожній файл означає
    ПЕРШИЙ хід: тоді до промпта підклеюється преамбула AGY_FIRST_TURN_PREFIX, а
    двигун заводить свіжу розмову і сам віддає її новий id. Тобто нам нема чого
    генерувати, досить перестати посилатись на стару нитку."""
    p = agy_conversation_path(channel)
    try:
        with open(p, 'w', encoding='utf-8') as f:
            f.write('')
        log(f'{channel}: agy conversation rotated (thread cleared)')
        return True
    except Exception as e:
        log(f'{channel}: agy conversation rotate failed: {e}')
        return False


def compact_channel_agy(channel, reason='auto'):
    """Стиснення каналу, чий двигун Antigravity, силами САМОГО Antigravity.

    Дзеркало клодівської гілки, крок у крок: підсумувати поточну нитку звичайним
    ходом двигуна, ротувати нитку, покласти підсумок у pending-summary (його
    підмішує в наступний промпт seed_prompt_with_summary, який стоїть вище
    розвилки двигунів і тому працює для обох), обнулити лічильник контексту саме
    цього двигуна.

    Повертає True лише коли підсумок реально приїхав. Порядок кроків не
    косметичний: підсумковий хід іде В ТУ САМУ розмову, яку стискає, тож нитку
    можна чіпати ТІЛЬКИ після того, як підсумок уже в руках. Провалився хід або
    приїхав порожній: не чіпаємо нічого, чат лишається робочим зі старою ниткою.
    """
    conv_p = agy_conversation_path(channel)
    conv = ''
    try:
        if os.path.exists(conv_p):
            conv = open(conv_p).read().strip()
    except Exception:
        conv = ''
    if not conv:
        # Рівно те саме, що перевірка jsonl у клодівській гілці: розмови на боці
        # двигуна ще нема, стискати нічого.
        log(f'{channel}: compact skipped, no agy conversation yet')
        return False

    log(f'{channel}: compacting context ({reason}) via agy conv={conv[:8]}')
    write_live(channel, {'active': True, 'phase': 'thinking',
                         'steps': [{'icon': '♻️', 'tool': _bt({'uk': 'Стискаю контекст',
                                                                'en': 'Compacting context'}, channel),
                                    'label': _bt({'uk': 'підсумовую розмову',
                                                  'en': 'summarizing the conversation'}, channel),
                                    'done': False}],
                         'text': ''})
    summary, data, err = run_agy_stream(COMPACT_SUMMARY_PROMPT, channel)
    clear_pid(channel)
    clear_live(channel)
    if err or not summary or not summary.strip():
        log(f'{channel}: agy compact summary failed/empty (err={err!r}); '
            f'keeping the old conversation')
        return False

    # Гроші ходу стиснення падають у канал, контекст ходу НЕ падає: рівно та сама
    # причина, що й у клодівській гілці (reset_context_pct нижче обнуляє метр, і
    # повернений туди контекст переозброїв би гейт на кожному наступному ході).
    write_usage(channel, data, cost_only=True, kind='compact')

    rotate_agy_conversation(channel)
    write_pending_summary(channel, summary.strip())
    reset_context_pct(channel, provider='antigravity')
    log(f'{channel}: agy compact done, summary {len(summary)} chars, thread rotated')
    return True


def compact_channel(channel, reason='auto', provider=None):
    """Compact a channel's context: summarize the current session, rotate to a
    fresh session id, and stash the summary so the NEXT real prompt seeds it.

    Returns True on success (rotated + summary stashed), False when nothing was
    done (no session yet, empty/failed summary). On False we keep the old
    session untouched: better to keep working than to break the chat.

    Стискає ЗАВЖДИ той двигун, який веде канал (specs/agy-compaction). Тіло нижче
    це клодівська гілка; канал Antigravity іде в compact_channel_agy, бо в нього
    інша нитка (conversation_id на боці двигуна замість нашого session-id) і чужа
    квота. provider передається згори там, де його вже прочитали, щоб не читати
    файл двічі за хід.
    """
    if (provider or channel_provider(channel)) == 'antigravity':
        return compact_channel_agy(channel, reason=reason)
    sid_path = os.path.join(CHANNELS_DIR, channel, 'session-id')
    if not os.path.exists(sid_path):
        log(f'{channel}: compact skipped, no session-id yet')
        return False
    session_id = open(sid_path).read().strip()
    if not session_id:
        log(f'{channel}: compact skipped, empty session-id')
        return False
    # Nothing to compact if the session was never actually run (no saved jsonl).
    if not session_jsonl_exists(session_id):
        log(f'{channel}: compact skipped, session never ran (no jsonl)')
        return False

    log(f'{channel}: compacting context ({reason}) sid={session_id[:8]}')
    # Surface a transient live state so the user sees something is happening during
    # the summary turn (it can take a few seconds on a huge context).
    write_live(channel, {'active': True, 'phase': 'thinking',
                         'steps': [{'icon': '♻️', 'tool': _bt({'uk': 'Стискаю контекст',
                                                                'en': 'Compacting context'}, channel),
                                    'label': _bt({'uk': 'підсумовую розмову',
                                                  'en': 'summarizing the conversation'}, channel),
                                    'done': False}],
                         'text': ''})
    # Summarize the existing session (resume, NOT a new session id).
    if STREAM_MODE:
        summary, data, err = run_claude_stream(COMPACT_SUMMARY_PROMPT, session_id, channel)
    else:
        summary, data, err = run_claude(COMPACT_SUMMARY_PROMPT, session_id, channel)
    clear_pid(channel)
    clear_live(channel)
    if err or not summary or not summary.strip():
        log(f'{channel}: compact summary failed/empty (err={err!r}); keeping old session')
        return False

    # Bill the compaction turn BEFORE the rotate/reset below. This is the most
    # expensive turn a channel ever runs (the whole accumulated context goes to
    # the model), and it used to be invisible: the meter counted only normal
    # turns, so cumulativeCostUsd systematically under-reported the channel.
    # cost_only=True is not an optimization but a requirement: reset_context_pct
    # zeroes the context two lines below, and writing this turn's context back
    # would re-arm the auto-compact gate and compact every following message.
    # Best-effort by construction (write_usage swallows its own failures): money
    # matters, a working chat matters more.
    write_usage(channel, data, cost_only=True, kind='compact')

    # Rotate to a fresh session and stash the summary for the next real prompt.
    rotate_session_id(channel)
    write_pending_summary(channel, summary.strip())
    reset_context_pct(channel, provider='claude')
    log(f'{channel}: compact done, summary {len(summary)} chars, session rotated')
    return True


def _is_transient_error(err: str) -> bool:
    """True for server-side hiccups that a simple retry usually clears (NOT a
    timeout, NOT a policy block, NOT a context-too-big)."""
    if not err:
        return False
    low = err.lower()
    return any(p in low for p in (
        'overloaded', '529', 'rate limit', 'temporarily limiting',
        ' 503', ' 502', ' 500', 'service unavailable', 'connection reset',
        'stdout closed',  # warm process died mid-turn — respawn fixes it
        # Network blips where the CLI subprocess could not reach / lost the API.
        # These used to fall through to the scary "Не вдалось обробити цей хід"
        # bubble with no retry; they are just as transient as a 529 overload.
        'unable to connect', 'connection refused', 'econnrefused',
        'econnreset', 'etimedout', 'enetunreach', 'socket hang up',
    ))


# Скільки разів хід Antigravity їде разом із першою спробою, і на скільки секунд
# росте пауза між ними. Три спроби це стеля зі спеки: у вікні відмов падає ~2 з 3
# зондів, тож три спроби ловлять більшість, а четверта вже платить за надію.
AGY_MAX_ATTEMPTS = 3
AGY_RETRY_BACKOFF = 4

# 403 у ЖИВОМУ вигляді, дослівно з лога CLI (2026-08-19):
#   'pre-invocation hook: context summarization: generating user intent:
#    PERMISSION_DENIED (code 403): The caller does not have permission'
_AGY_403_RE = re.compile(r'permission[_ ]?denied|\b(?:code\s*)?403\b', re.I)


def _is_agy_transient_error(err: str) -> bool:
    """True для 403 / PERMISSION_DENIED від Google, тобто відмови, яку лікує
    простий повтор.

    Свідомо ОКРЕМА функція, а не кілька нових слів у _is_transient_error. Той
    класифікатор спільний для обох двигунів, і слово 'permission' у ньому
    навчило б Клода повторювати БУДЬ-ЯКУ відмову доступу, тобто палити ліміт на
    безнадійних спробах. Тут 403 тимчасовий рівно тому, що на боці Google він
    приходить вікнами по 15-20 хвилин і минає сам: заміряно 11 збоїв з 16 зондів
    усередині вікна проти 25 чистих викликів поспіль поза ним."""
    if not err:
        return False
    return bool(_AGY_403_RE.search(err))


def _agy_should_retry(provider, err, attempt) -> bool:
    """Чи повторювати цей впалий хід через тимчасову відмову Antigravity.

    Провайдер у підписі не для краси: він і є той запобіжник, який тримає гілку
    Клода недоторканою. Канал не на Antigravity сюди навіть не заходить, тож
    його класифікація і його лічильник спроб лишились байт у байт як були."""
    return bool(err and err != STOP_SENTINEL and provider == 'antigravity'
                and attempt <= AGY_MAX_ATTEMPTS - 1
                and _is_agy_transient_error(err))


def _is_usage_limit_error(err: str) -> bool:
    """True for a real Claude usage/credit CAP: subscription 5h/weekly limit or
    API quota/credit exhaustion. Unlike a transient overload, retrying does NOT
    help: the user must wait for the reset, switch to a cheaper model, or top up.
    Checked BEFORE _is_transient_error so a hard cap isn't mislabeled 'overload'."""
    if not err:
        return False
    low = err.lower()
    return any(p in low for p in (
        # Claude CLI subscription caps (the real wording, confirmed from logs):
        #   "You've hit your session limit · resets 7:20pm (Europe/Kiev)"
        'session limit', 'hit your', 'usage limit reached', 'usage limit',
        'limit reached', 'limit will reset', 'reset at', ' resets ',
        # API credit / quota exhaustion:
        'credit balance is too low', 'insufficient credit', 'out of credits',
        'exceeded your current quota', 'quota exceeded', 'billing',
        'weekly limit', 'daily limit', 'plan limit', 'upgrade your plan',
    ))


# Pull a reset time out of either wording: "reset at 3pm" / "resets 7:20pm (Kiev)".
_LIMIT_RESET_RE = re.compile(r'reset(?:s| at| on)?\s+([^.\n;]+)', re.I)


def _extract_limit_reset(err: str):
    """Best-effort: pull a human reset time out of the CLI's limit message
    (e.g. '...your limit will reset at 3pm (UTC)'). None if not present."""
    if not err:
        return None
    m = _LIMIT_RESET_RE.search(err)
    if not m:
        return None
    val = m.group(1).strip().rstrip('.,;')[:60].strip()
    return val or None


# --- Людський час скидання ліміту --------------------------------------------
# _extract_limit_reset віддає рівно те, що написав CLI: «12:20am (Europe/Kiev)».
# Це англійський формат і технічна назва зони, тобто половина того, на що людина
# скаржився («чому це показано так»). Тут той самий рядок перекладається у
# звичний 24-годинний вигляд українською. Це ФОРМАТУВАННЯ поверх наявного
# розпізнавання, а не друге розпізнавання: вхід у нього тільки з _extract_limit_reset.
_RESET_TIME_RE = re.compile(r'\b(\d{1,2})(?::(\d{2}))?\s*(am|pm)\b', re.I)
_RESET_TZ_RE = re.compile(r'\(([^)]+)\)')
_MONTHS_UK = {
    'jan': 'січня', 'feb': 'лютого', 'mar': 'березня', 'apr': 'квітня',
    'may': 'травня', 'jun': 'червня', 'jul': 'липня', 'aug': 'серпня',
    'sep': 'вересня', 'oct': 'жовтня', 'nov': 'листопада', 'dec': 'грудня',
}
_RESET_DATE_RE = re.compile(
    r'\b(' + '|'.join(_MONTHS_UK) + r')[a-z]*\.?\s+(\d{1,2})\b', re.I)


_MONTHS_EN = {k: k.capitalize() for k in _MONTHS_UK}


def humanize_limit_reset(val: str, lang='uk'):
    """'12:20am (Europe/Kiev)' -> 'о 00:20 за київським часом' (uk) або
    '00:20 Kyiv time' (en). 'Aug 2 at 6am (Europe/Kiev)' -> '2 серпня о 06:00
    за київським часом' (uk) або 'Aug 2 at 06:00 Kyiv time' (en).

    lang='uk' лишається дефолтом і байт-у-байт тим самим виходом, що був до
    Ф4 (specs/i18n-interface): це формат для CLI-рядка, а не dict-поле
    видимого віджета, тому К4-сканер його не бачить, але картка ліміту таки
    показує людині цей рядок, тож він теж мовно залежний (channel/lang іде
    з виклику, той самий носій, що й для решти Ф4).

    Нічого не вигадує: чого не впізнала, те лишає як є (гірше за оригінал не стане)."""
    if not val:
        return None
    out = val.strip()
    months = _MONTHS_UK if lang == 'uk' else _MONTHS_EN

    tz_suffix = ''
    mtz = _RESET_TZ_RE.search(out)
    if mtz:
        tz = mtz.group(1).strip()
        low_tz = tz.lower()
        if 'kiev' in low_tz or 'kyiv' in low_tz:
            tz_suffix = ' за київським часом' if lang == 'uk' else ' Kyiv time'
        else:
            tz_suffix = f' ({tz})'
        out = _RESET_TZ_RE.sub('', out).strip()

    def _t(m):
        hour = int(m.group(1)) % 12
        if m.group(3).lower() == 'pm':
            hour += 12
        return f'{hour:02d}:{int(m.group(2) or 0):02d}'

    had_time = bool(_RESET_TIME_RE.search(out))
    out = _RESET_TIME_RE.sub(_t, out)
    if lang == 'uk':
        # «Aug 2» -> «2 серпня»: українська йде день-місяць.
        out = _RESET_DATE_RE.sub(
            lambda m: f'{int(m.group(2))} {months[m.group(1)[:3].lower()]}', out)
        # «2 серпня at 06:00» -> «2 серпня о 06:00»
        out = re.sub(r'\bat\b', 'о', out, flags=re.I)
    else:
        # «Aug 2» лишається «Aug 2»: англійська йде місяць-день, як у джерела.
        out = _RESET_DATE_RE.sub(
            lambda m: f'{months[m.group(1)[:3].lower()]} {int(m.group(2))}', out)
    out = re.sub(r'\s{2,}', ' ', out).strip().rstrip(',')
    if not out:
        return (tz_suffix.strip() or None)
    if had_time and re.fullmatch(r'\d{2}:\d{2}', out):
        out = f'о {out}' if lang == 'uk' else f'at {out}'
    return f'{out}{tz_suffix}'


def limit_widgets(reset, channel=None):
    """ОДНА картка про вичерпаний ліміт для всіх шляхів (звичайний хід і агент).

    Раніше формулювання жило тільки в friendly_error_bubble, а шлях агента до нього
    не доходив узагалі, тож у стрічку приїжджав сирий англійський рядок CLI. Тепер
    текст один і той самий, звідки б ліміт не прилетів.

    Перемикання двигуна/моделі тут свідомо НЕ пропонується: чат прибитий до одного
    двигуна (рішення власника, 2026-08-03), а порада, якої не можна виконати, це шум."""
    when = humanize_limit_reset(reset, current_lang(channel))
    text = _bt({'uk': 'Ліміт Claude на цьому акаунті вичерпано, тому хід не пройшов. '
                       'Це не поломка чату і не завеликий контекст.',
                'en': 'The Claude limit on this account is used up, so the turn did '
                      "not go through. It is not a chat bug and not too big a context."},
               channel)
    if when:
        text += _bt({'uk': f' Ліміт оновиться {when}.',
                     'en': f' The limit resets {when}.'}, channel)
    text += _bt({'uk': ' Тиснути ще раз зараз сенсу нема: до оновлення відповіді не буде. '
                        'Лиши задачу в чаті і повернись, коли ліміт відновиться.',
                 'en': ' Pressing again right now has no point: there will be no reply '
                       'until it resets. Leave the task in the chat and come back once '
                       'the limit is restored.'}, channel)
    # icon ставимо явно: без нього варіант warning домалює свій ⚠️ поруч із 🔋 у
    # заголовку, тобто дві іконки на одну картку.
    return [{'type': 'callout', 'variant': 'warning', 'icon': '🔋',
             'title': _bt({'uk': 'Ліміт Claude вичерпано', 'en': 'Claude limit used up'}, channel),
             'text': text}]


# One-shot self-heal for model/CLI errors: when a turn fails because the chosen model
# is unavailable on THIS machine (no account access, or the Claude Code CLI is too old
# to know the alias / the --fallback-model flag), retry ONCE with a bare, always-valid
# default and no fancy flags. _FORCE_BARE flips _resolve_model_args into that safe shape;
# _model_safe_retry guarantees at most one such retry per turn (no infinite loop).
_FORCE_BARE = {'on': False}
_model_safe_retry = set()


def _is_model_error(err: str) -> bool:
    """CLI/model resolution failures: unknown/unavailable model, or an old CLI that
    doesn't understand a model alias or the --fallback-model flag we pass."""
    if not err:
        return False
    low = err.lower()
    return any(p in low for p in (
        'model not found', 'model_not_found', 'unknown model', 'invalid model',
        'not a valid model', 'model is not available', 'no such model',
        'does not support the model', 'unsupported model', 'model not available',
        # 'No capacity available for model <X> on the server' від Google: модель
        # існує, але зараз її нема під цей акаунт, тобто лікується тим самим
        # фолбеком на безпечну модель, а не повтором тієї самої.
        'no capacity available',
        # old CLI rejecting a newer flag/option we pass:
        'unknown option', 'unknown argument', 'unexpected argument',
        'unrecognized option', 'no such option', '--fallback-model',
        "invalid value for '--model'", 'invalid value for --model',
    ))


# Зіткнення ідентифікатора сесії. Спливає, коли ми піднімаємо сесію примусово
# (--session-id / SDK session_id), бо збереженого .jsonl ще не видно, а CLI цей
# id уже тримає. Класика такого стану це холодний респавн після зміни моделі:
# старий процес помер, не встигнувши дописати свій .jsonl (див. _encode_project_dir).
# Раніше рядок не підпадав під жоден предикат і доїжджав до людини найгіршою з усіх
# карток, «не вдалось обробити цей хід… якщо повторюється: новий чат», тобто
# порадою викинути розмову через технічну дрібницю.
def _is_session_collision_error(err: str) -> bool:
    """True для «Session ID <uuid> is already in use» та його варіацій."""
    if not err:
        return False
    low = err.lower()
    if 'session' not in low:
        return False
    return any(p in low for p in (
        'already in use', 'already exists', 'in use by another',
        'session id is taken',
    ))


def _is_auth_error(err: str) -> bool:
    """Claude Code not logged in / auth expired on this machine."""
    if not err:
        return False
    low = err.lower()
    return any(p in low for p in (
        'not logged in', 'please log in', 'please run /login', 'run /login',
        'unauthorized', ' 401', 'authentication failed', 'invalid api key',
        'no api key', 'oauth', 'expired token', 'session expired', 'claude login',
    ))


def _is_not_installed_error(err: str) -> bool:
    """The `claude` binary could not be spawned (not installed / wrong path)."""
    if not err:
        return False
    low = err.lower()
    return any(p in low for p in (
        'spawn failed', 'no such file or directory', 'errno 2',
        'command not found', 'is not recognized as', 'cannot find the path',
        'filenotfounderror', 'claude binary not found',
    ))


# Хід завершився штатно, але тексту в ньому не було. Це НЕ помилка движка (err
# порожній), тому окремого рядка помилки для нього не існує: несемо сентинел, щоб
# порожній хід їхав тим самим конвеєром провалу (classify_failure -> mark_turn_failed
# -> кнопка «Надіслати знову»), що й будь-який інший обірваний хід.
EMPTY_REPLY_SENTINEL = '__logopsis_empty_reply__'


def friendly_error_bubble(err: str, rotated: bool, channel: str = None) -> list:
    """Return a chat widget with a calm, HONEST, actionable message tailored to
    the actual failure. Never blames "context too big" unless the context meter
    actually says so. The raw technical error stays in the runner log only."""
    low = (err or '').lower()
    ctx_pct = None
    if channel:
        try:
            ctx_pct = read_context_pct(channel)
        except Exception:
            ctx_pct = None
    big_ctx = ctx_pct is not None and ctx_pct >= 90

    if err == EMPTY_REPLY_SENTINEL:
        # Хід дійшов до кінця, але тексту не приніс. Раніше на це місце падало
        # «Готово ✓», тобто провал був замаскований під успіх. Кажемо як є.
        # danger, а не warning: мітка на бабблі для цього провалу вже червона
        # (tone='error'), і жовта картка поруч читалась би як інша подія.
        return [{'type': 'callout', 'variant': 'danger', 'icon': '📭',
                 'title': _bt({'uk': 'Відповідь не прийшла', 'en': 'No reply came back'}, channel),
                 'text': _bt({
                     'uk': 'Хід завершився, але жодного тексту у відповіді не було. '
                           'Найчастіше це порожня відповідь двигуна, обірваний на '
                           'пів дорозі хід або вичерпаний ліміт. Роботи не втрачено: '
                           'тисни «Надіслати знову» на своєму повідомленні вище, '
                           'і той самий запит поїде ще раз.',
                     'en': 'The turn finished, but the reply had no text at all. Usually '
                           'that means an empty reply from the engine, a turn cut off '
                           'midway, or a used-up limit. Nothing is lost: press "Resend" '
                           'on your message above and the same request goes again.',
                 }, channel)}]
    if rotated:
        msg = _bt({'uk': 'Цей запит не пройшов модерацію, тому я почав для цього чату нову '
                          'сесію. Переформулюй і спробуй ще раз.',
                   'en': 'This request did not pass moderation, so I started a new '
                         'session for this chat. Rephrase it and try again.'}, channel)
    elif 'prompt is too long' in low or 'too long' in low or '413' in low:
        msg = _bt({'uk': 'Повідомлення (з контекстом) завелике для одного запиту. '
                          'Тисни «Новий чат» (+ вгорі) або скороти запит.',
                   'en': 'The message (with context) is too big for one request. Press '
                         '"New chat" (+ up top) or shorten the request.'}, channel)
    elif 'timeout' in low:
        # Reached ONLY by the absolute 1h runaway-loop backstop (TURN_TIMEOUT) or
        # the single-shot fallback's hard cap. The old IDLE auto-abort (which used
        # to land here and print the scary "took too long / press again" bubble)
        # is GONE: a long/silent turn is no longer killed, it just keeps running
        # under the Стоп button. So this branch is now a rare, calm safety-net that
        # keeps whatever partial streamed. No "press again" wording.
        if big_ctx:
            msg = _bt({'uk': f'Цей чат став завеликий (контекст ~{int(ctx_pct)}%), '
                              f'зупинив на запобіжнику. Ось що встиг. Для нового — «Новий чат» (+ вгорі).',
                       'en': f'This chat got too big (context ~{int(ctx_pct)}%), stopped '
                             f'on the safety net. Here is what it got done. For a fresh '
                             f'start: "New chat" (+ up top).'}, channel)
        else:
            msg = _bt({'uk': 'Це тривало дуже довго, зупинив на запобіжнику. Ось що встиг.',
                       'en': 'This took too long, stopped on the safety net. Here is what '
                             'it got done.'}, channel)
    elif _is_usage_limit_error(err):
        return limit_widgets(_extract_limit_reset(err), channel)
    elif _is_transient_error(err):
        msg = _bt({'uk': 'Сервери Anthropic зараз перевантажені (тимчасово, це не твій '
                          'ліміт). Натисни ще раз за хвилинку, зазвичай минає.',
                   'en': 'Anthropic servers are overloaded right now (temporary, not '
                         'your limit). Press again in a minute, it usually clears up.'},
                  channel)
    elif _is_not_installed_error(err):
        return [{'type': 'callout', 'variant': 'danger',
                 'title': _bt({'uk': '🔌 Claude Code не знайдено',
                               'en': '🔌 Claude Code not found'}, channel),
                 'text': _bt({
                     'uk': 'Claude Code не встановлено (або не в PATH) на цьому '
                           'компʼютері. Встанови: `npm i -g @anthropic-ai/claude-code` '
                           'чи claude.ai/download, залогінься (`claude` у терміналі), '
                           'і перезапусти Logopsis.',
                     'en': 'Claude Code is not installed (or not on PATH) on this '
                           'computer. Install it: `npm i -g @anthropic-ai/claude-code` '
                           'or claude.ai/download, log in (`claude` in a terminal), '
                           'then restart Logopsis.',
                 }, channel)}]
    elif _is_auth_error(err):
        return [{'type': 'callout', 'variant': 'warning',
                 'title': _bt({'uk': '🔑 Потрібен вхід у Claude Code',
                               'en': '🔑 Claude Code sign-in needed'}, channel),
                 'text': _bt({
                     'uk': 'Claude Code не залогінений на цьому компʼютері. Відкрий '
                           'термінал, запусти `claude`, увійди, потім повтори запит тут.',
                     'en': 'Claude Code is not logged in on this computer. Open a '
                           'terminal, run `claude`, sign in, then repeat the request here.',
                 }, channel)}]
    elif _is_model_error(err):
        return [{'type': 'callout', 'variant': 'warning',
                 'title': _bt({'uk': '🧠 Модель недоступна', 'en': '🧠 Model unavailable'}, channel),
                 'text': _bt({
                     'uk': 'Обрана модель недоступна на цьому компʼютері (немає доступу '
                           'до неї, або Claude Code застарілий). Я вже пробував безпечну '
                           'модель. Якщо не допомогло: перемкни модель (⚙ зліва) або '
                           'онови Claude Code до останньої версії (Relaunch to update).',
                     'en': 'The chosen model is unavailable on this computer (no access '
                           'to it, or Claude Code is outdated). I already tried a safe '
                           'model. If that did not help: switch the model (⚙ on the left) '
                           'or update Claude Code to the latest version (Relaunch to update).',
                 }, channel)}]
    else:
        msg = _bt({'uk': 'Не вдалось обробити цей хід. Спробуй ще раз; якщо повторюється: '
                          '«Новий чат» (+ вгорі).',
                   'en': 'Could not process this turn. Try again; if it keeps happening: '
                         '"New chat" (+ up top).'}, channel)
    return [{'type': 'text', 'text': f'⚠️ {msg}'}]


def agent_failure_widgets(label: str, err: str, channel: str = None) -> list:
    """Картка «фоновий агент не довіз результат» тими самими словами, що й чат.

    Дірка, крізь яку сирий англійський рядок CLI доїжджав до стрічки, була саме тут:
    agent_worker брав `result.result` НЕЗАЛЕЖНО від `result.is_error`, тож текст
    ліміту ставав «виводом агента» і публікувався карткою «· агент завершив». Ніякого
    другого розпізнавання не додано: цей шлях просто заведено у наявне
    (friendly_error_bubble -> _is_usage_limit_error -> limit_widgets)."""
    head = {'type': 'header', 'title': _bt({'uk': f'🤖 {label} · агент не завершив',
                                             'en': f'🤖 {label} · agent did not finish'}, channel)}
    try:
        body = friendly_error_bubble(err, False, channel)
    except Exception:
        body = [{'type': 'text', 'text': _bt({'uk': '⚠️ Агент не довіз результат.',
                                               'en': '⚠️ The agent did not deliver a result.'}, channel)}]
    return [head] + body


# ---- Failed-turn mark (машиночитний стан провалу для стрічки) ---------------
# friendly_error_bubble вище дає ПОЯСНЕННЯ окремою карткою Клода. Але сам хід у
# стрічці досі виглядав нормальним: промпт людини стояв так, ніби відповідь ось-ось
# прийде. Тому паралельно з карткою ми кладемо короткий машиночитний вирок на сам
# баббл користувача (index.json -> item['failed']), рівно як це вже робить
# _mark_messages_stopped зі Стопом. UI малює з нього мітку + кнопку «Надіслати
# знову»; повний текст помилки, як і раніше, лишається тільки в лозі ранера.
#
# tone: 'limit' -> жовтий (це не поломка, це вичерпаний ресурс), решта -> червоний.

def classify_failure(err: str, rotated: bool, channel: str = None) -> dict:
    """Один рядок людською мовою + код причини для мітки на бабблі користувача.

    Дзеркалить гілки friendly_error_bubble (ті самі предикати, той самий порядок),
    але повертає СТИСЛУ мітку, а не картку-пояснення: у стрічці має бути видно
    «цей хід помер і чому», без стіни тексту."""
    low = (err or '').lower()
    ctx_pct = None
    if channel:
        try:
            ctx_pct = read_context_pct(channel)
        except Exception:
            ctx_pct = None

    if err == EMPTY_REPLY_SENTINEL:
        return {'reason': 'empty', 'tone': 'error',
                'text': _bt({'uk': 'Відповідь не прийшла: хід завершився без тексту',
                             'en': 'No reply came back: the turn finished without text'}, channel)}
    if rotated:
        return {'reason': 'policy', 'tone': 'error',
                'text': _bt({'uk': 'Запит не пройшов модерацію, сесію чату перезапущено',
                             'en': 'The request failed moderation, the chat session was restarted'}, channel)}
    if 'prompt is too long' in low or 'too long' in low or '413' in low:
        return {'reason': 'context', 'tone': 'error',
                'text': _bt({'uk': 'Запит разом із контекстом завеликий для одного ходу',
                             'en': 'The request plus context is too big for one turn'}, channel)}
    if 'timeout' in low:
        if ctx_pct is not None and ctx_pct >= 90:
            return {'reason': 'timeout', 'tone': 'error',
                    'text': _bt({'uk': f'Таймаут: чат став завеликий (контекст ~{int(ctx_pct)}%)',
                                 'en': f'Timeout: the chat got too big (context ~{int(ctx_pct)}%)'}, channel)}
        return {'reason': 'timeout', 'tone': 'error',
                'text': _bt({'uk': 'Таймаут: хід тривав задовго, зупинено на запобіжнику',
                             'en': 'Timeout: the turn ran too long, stopped on the safety net'}, channel)}
    if _is_usage_limit_error(err):
        reset = _extract_limit_reset(err)
        when = humanize_limit_reset(reset, current_lang(channel))
        return {'reason': 'limit', 'tone': 'limit', 'resetAt': when or reset,
                'text': (_bt({'uk': f'Ліміт Claude вичерпано, оновиться {when}',
                              'en': f'Claude limit used up, resets {when}'}, channel) if when
                         else _bt({'uk': 'Ліміт Claude вичерпано',
                                   'en': 'Claude limit used up'}, channel))}
    if _is_not_installed_error(err):
        return {'reason': 'not-installed', 'tone': 'error',
                'text': _bt({'uk': 'Claude Code не знайдено на цьому компʼютері',
                             'en': 'Claude Code not found on this computer'}, channel)}
    if _is_auth_error(err):
        return {'reason': 'auth', 'tone': 'error',
                'text': _bt({'uk': 'Claude Code не залогінений на цьому компʼютері',
                             'en': 'Claude Code is not logged in on this computer'}, channel)}
    if _is_model_error(err):
        return {'reason': 'model', 'tone': 'error',
                'text': _bt({'uk': 'Помилка моделі: обрана модель недоступна',
                             'en': 'Model error: the chosen model is unavailable'}, channel)}
    if _is_transient_error(err):
        return {'reason': 'overload', 'tone': 'error',
                'text': _bt({'uk': 'Сервери Anthropic перевантажені, хід не пройшов',
                             'en': 'Anthropic servers are overloaded, the turn did not go through'}, channel)}
    return {'reason': 'unknown', 'tone': 'error',
            'text': _bt({'uk': 'Хід обірвано: не вдалось його обробити',
                         'en': 'Turn aborted: could not process it'}, channel)}


def _plural_steps(n, lang='uk'):
    if lang != 'uk':
        return 'step' if abs(int(n)) == 1 else 'steps'
    n = abs(int(n))
    if n % 10 == 1 and n % 100 != 11:
        return 'крок'
    if 2 <= n % 10 <= 4 and not 12 <= n % 100 <= 14:
        return 'кроки'
    return 'кроків'


def _steps_digest(steps, limit=4, lang='uk'):
    """«🤖 Task × 4, 🔧 Bash × 2» з кроків живої смуги: чим саме хід був зайнятий.

    Порядок за першою появою інструмента, бо рівно в такому порядку людина бачила їх
    у смузі прогресу. Понад limit різних інструментів згортаємо в «та ще N», щоб
    нота лишалась однорядковою і не перетворилась на лог."""
    order, count, icon = [], {}, {}
    for s in steps or []:
        name = (s or {}).get('tool') or ''
        if not name:
            continue
        if name not in count:
            order.append(name)
            icon[name] = (s or {}).get('icon') or '🔹'
        count[name] = count.get(name, 0) + 1
    if not order:
        return ''
    head = order[:limit]
    parts = [f'{icon[n]} {n}' + (f' × {count[n]}' if count[n] > 1 else '')
             for n in head]
    if len(order) > len(head):
        rest = len(order) - len(head)
        parts.append(f'та ще {rest}' if lang == 'uk' else f'and {rest} more')
    return ', '.join(parts)


def silent_work_bubble(steps, channel=None) -> list:
    """Нота про хід, який ВІДПРАЦЮВАВ інструментами і не написав фінального тексту.

    Третій випадок порожнього тексту, якого гілка рішення раніше не знала (канал
    chat-173, повідомлення 0057-0061). Хід запускав агентів, завершувався мовчки, і
    чат малював червону картку «Відповідь не прийшла» з кнопкою «Надіслати знову».
    Кнопка на такому ході НЕ безпечна: вона жене ту саму роботу вдруге, а там був
    запуск чотирьох агентів на 48 файлів.

    Тому тут ні картки провалу, ні мітки, ні кнопки повтору: спокійна нота, з якої
    видно, що хід відпрацював і чим саме. variant='info', а не 'warning': тривожити
    нема чим, робота зроблена."""
    lang = current_lang(channel)
    total = len([s for s in (steps or []) if (s or {}).get('tool')])
    digest = _steps_digest(steps, lang=lang)
    if lang == 'uk':
        body = f'Фінального тексту не було, але хід відпрацював: {total} {_plural_steps(total, lang)} інструментами'
        body += f' ({digest}). ' if digest else '. '
        body += 'Повторювати запит не треба, інакше та сама робота піде вдруге.'
    else:
        body = f'There was no final text, but the turn worked: {total} {_plural_steps(total, lang)} with tools'
        body += f' ({digest}). ' if digest else '. '
        body += 'No need to repeat the request, or the same work runs twice.'
    return [{'type': 'callout', 'variant': 'info', 'icon': '🔧',
             'title': _bt({'uk': 'Хід відпрацював без підсумку',
                           'en': 'The turn worked but left no summary'}, channel),
             'text': body}]


def _index_lock(channel):
    """Той самий .append.lock, що бере server.py: index.json має рівно одного
    письменника за раз.

    Лок бере ПЛАТФОРМА: fcntl.flock на POSIX, msvcrt.locking на Windows. Старий
    no-op фолбек «на Windows писати нікому паралельно» був неправдою: у ту саму
    теку пише ще й render-message.cjs, тож без локу там тиха колізія id, а не
    спокій."""
    import contextlib
    ch_dir = os.path.join(CHANNELS_DIR, channel)
    os.makedirs(ch_dir, exist_ok=True)
    lock_file = os.path.join(ch_dir, '.append.lock')

    @contextlib.contextmanager
    def _held():
        if PLATFORM is None:
            yield
            return
        with open(lock_file, 'w') as lf:
            with PLATFORM.file_lock(lf):
                yield

    return _held()


def failed_job_path(channel, msg_id):
    return os.path.join(CHANNELS_DIR, channel, 'failed', f'{int(msg_id)}.json')


def mark_turn_failed(channel, msg_id, failure, job=None):
    """Позначити баббл користувача як «хід провалився» + відкласти сам промпт,
    щоб кнопка «Надіслати знову» переслала ТЕ САМЕ, а не переказ.

    Відкладаємо ВЕСЬ job (текст із уже вшитою цитатою-контекстом і вмістом
    текстових вкладень + список attachments), бо саме він доїхав до движка. Якщо
    зібрати промпт наново з баббла, повтор поїде іншим текстом — це вже не
    «надіслати знову». session_id свідомо не зберігаємо: на повторі беремо
    актуальний, бо між провалом і кліком сесію могли прокрутити (компакція).

    Best-effort: провал мітки не має ламати сам хід (картка-пояснення вже є)."""
    if msg_id is None:
        return False
    try:
        if job is not None:
            p = failed_job_path(channel, msg_id)
            os.makedirs(os.path.dirname(p), exist_ok=True)
            atomic_write_json(p, {'text': job.get('text', ''),
                                  'attachments': job.get('attachments') or [],
                                  'user_msg_id': int(msg_id)})
    except Exception as e:
        log(f'{channel}: failed-job stash error: {e}')
    try:
        idx_path = channel_index_path(channel)
        if not os.path.exists(idx_path):
            return False
        rec = dict(failure)
        rec['at'] = datetime.now().strftime('%H:%M:%S')
        rec['retryable'] = os.path.exists(failed_job_path(channel, msg_id))
        with _index_lock(channel):
            with open(idx_path, encoding='utf-8') as f:
                items = json.load(f) or []
            if not isinstance(items, list):
                return False
            hit = False
            for it in items:
                if isinstance(it, dict) and it.get('id') == int(msg_id):
                    it['failed'] = rec
                    hit = True
            if hit:
                atomic_write_json(idx_path, items)
        return hit
    except Exception as e:
        log(f'{channel}: failed-mark error: {e}')
        return False


_active = {}            # channel -> True while a worker thread is running
_active_lock = threading.Lock()


# Logging lives here, not in a shell redirect: `cmd /c ... >> runner.out.log`
# fails to even start the runner when anything else holds the file open.
_LOG_PATH = os.environ.get('LOGOPSIS_RUNNER_LOG') or os.path.join(DIR, 'runner.out.log')
_log_lock = threading.Lock()


def log(*a):
    line = f'[runner {datetime.now().strftime("%H:%M:%S")}] ' + ' '.join(str(x) for x in a)
    print(line, flush=True)
    global _LOG_PATH
    with _log_lock:
        try:
            with open(_LOG_PATH, 'a', encoding='utf-8') as fh:
                fh.write(line + '\n')
        except OSError:
            # Log held by someone else (an older cmd-redirect launcher): keep our
            # own copy instead of losing the output.
            _LOG_PATH = os.path.join(DIR, f'runner.{os.getpid()}.log')
            try:
                with open(_LOG_PATH, 'a', encoding='utf-8') as fh:
                    fh.write(line + '\n')
            except OSError:
                pass


def _encode_project_dir(repo_root):
    """Encode an absolute cwd the way Claude Code names its ~/.claude/projects/<dir>.

    POSIX:   /Users/x/repo            -> -Users-x-repo   (every '/' -> '-')
    Windows: C:\\Users\\x\\repo         -> c--Users-x-repo (every '/' '\\' ':' -> '-',
             and the drive letter lowercased).

    The original code only did `.replace('/', '-')`, which on Windows left the
    backslashes and the colon intact (e.g. 'C:\\Users\\...'), so the encoded dir
    never matched Claude's real folder ('c--Users-...'). Result: resume detection
    was always False on Windows -> every turn started a brand-new session (channel
    memory lost) and could collide with --session-id on an already-existing id.
    Verified against the real folder name on this machine.

    Claude also CANONICALIZES the cwd (resolves symlinks) before encoding: on macOS
    a home under /tmp is really /private/tmp, so a cwd '/tmp/x' is stored under
    '-private-tmp-x'. Without realpath here the encoded dir was '-tmp-x' -> resume
    detection False -> force-create an already-existing --session-id -> the CLI aborts
    with 'Session ID <id> is already in use' on the 2nd turn. realpath matches Claude
    (no-op for a normal, non-symlinked home like ~/Library, so it is safe).

    Claude also replaces EVERY non-alphanumeric char with '-', not just the path
    separators. The desktop app runs with cwd = the data-home '~/Library/Application
    Support/Logopsis', whose SPACE ('Application Support') the old replace() chain
    left intact, so the encoded dir never matched Claude's real folder and the same
    2nd-turn 'already in use' crash fired on every cold re-spawn (model switch or
    warm-process recycle). re.sub over the whole char class covers space, '\\', '/',
    ':' and any other separator in one pass."""
    repo_root = os.path.realpath(repo_root)
    enc = re.sub(r'[^A-Za-z0-9]', '-', repo_root)
    if sys.platform == 'win32' and enc:
        # Claude lowercases the drive letter (C: -> c--).
        enc = enc[0].lower() + enc[1:]
    return enc


def session_jsonl_exists(session_id):
    """True if claude already has a saved session with this id for the repo cwd.
    Encoded project dir mirrors Claude Code's own naming (see _encode_project_dir)."""
    enc = _encode_project_dir(REPO_ROOT)
    path = os.path.expanduser(f'~/.claude/projects/{enc}/{session_id}.jsonl')
    return os.path.exists(path)


def _bound_terminal_session(channel):
    """Reverse-lookup channels/.cc-sessions.json: the interactive terminal Claude
    Code session id that OWNS this channel (the one the SessionStart hook bound to
    it). Returns the session id or None."""
    try:
        m = json.load(open(os.path.join(CHANNELS_DIR, '.cc-sessions.json')))
        for sid, ch in m.items():
            if ch == channel:
                return sid
    except Exception:
        pass
    return None


def _ctx_autosync_on(channel):
    """Forward context auto-inheritance is ON by default. Disabled globally via
    env CHAT_CTX_AUTOSYNC=0, or per-channel via channels/<id>/ctx-autosync=0."""
    if os.environ.get('CHAT_CTX_AUTOSYNC', '1') == '0':
        return False
    try:
        v = open(os.path.join(CHANNELS_DIR, channel, 'ctx-autosync')).read().strip().lower()
        return v not in ('0', 'false', 'no', 'off')
    except Exception:
        return True


def _resume_or_seed_args(channel, session_id):
    """Build the claude session CLI args for a channel turn.

    OPT-IN context handoff (FORWARD): if channels/<channel>/seed-from exists
    (a one-shot marker holding a terminal session id) AND this channel's session
    has not started yet (no jsonl), fork the terminal session's full history into
    our fresh session id. The marker is consumed (removed) so it only applies to
    the very next turn.

    Otherwise this is the UNCHANGED default behavior: resume if our jsonl already
    exists, else start a brand-new session with --session-id. With no seed-from
    marker the returned list is EXACTLY the old logic, so the live chat path is
    untouched."""
    seed_path = os.path.join(CHANNELS_DIR, channel, 'seed-from')
    # One-time guard: a channel inherits the terminal's context AT MOST ONCE in its
    # life. Without this, every compaction rotates to a fresh (no-jsonl) session id
    # and the auto-seed-fork below RE-IMPORTS the entire (huge) terminal history —
    # blowing context to 300%+, $10 turns and 300s timeouts, which then surfaced as
    # the bogus "chat too big" error. After the first inherit we start fresh from
    # the compaction summary instead.
    seeded_path = os.path.join(CHANNELS_DIR, channel, '.context-seeded')
    def _mark_seeded():
        try:
            open(seeded_path, 'w').close()
        except OSError:
            pass
    try:
        has_jsonl = session_jsonl_exists(session_id)
        if os.path.exists(seed_path) and not has_jsonl:
            with open(seed_path) as f:
                seed = f.read().strip()
            if seed:
                try:
                    os.remove(seed_path)  # consume (one-shot)
                except OSError:
                    pass
                _mark_seeded()
                log(f'{channel}: seed-fork from {seed[:8]} -> {session_id[:8]}')
                return ['--resume', seed, '--fork-session',
                        '--session-id', session_id]
            # empty marker: drop it and fall through to default behavior
            try:
                os.remove(seed_path)
            except OSError:
                pass
            has_jsonl = session_jsonl_exists(session_id)
        # AUTO context handoff (FORWARD, no button): this channel's FIRST turn ever
        # and auto-sync is on -> fork the bound terminal session's full context into
        # our fresh session id. So writing in a Logopsis tab just inherits whatever
        # you were doing in Claude Code, with nothing to click. Guarded by
        # .context-seeded so it fires ONCE, never again after a compaction rotation.
        if (not has_jsonl and _ctx_autosync_on(channel)
                and not os.path.exists(seeded_path)):
            term = _bound_terminal_session(channel)
            if term and term != session_id and session_jsonl_exists(term):
                _mark_seeded()
                log(f'{channel}: auto-seed-fork from {term[:8]} -> {session_id[:8]}')
                return ['--resume', term, '--fork-session',
                        '--session-id', session_id]
        if has_jsonl:
            return ['--resume', session_id]
        return ['--session-id', session_id]
    except Exception as e:
        log(f'{channel}: _resume_or_seed_args fallback ({e})')
        if session_jsonl_exists(session_id):
            return ['--resume', session_id]
        return ['--session-id', session_id]


# Opus 4.8 [1m] context window. Used as the meter denominator (lastTurnInput / WINDOW).
CONTEXT_WINDOW = int(os.environ.get('CHAT_RUNNER_CONTEXT_WINDOW', '1000000'))


# ---- live turn state (Stage 3 transparency) -------------------------------
# During a stream-json turn the runner continuously rewrites channels/<id>/
# live.json so the polling front end can show real-time progress. Schema:
#   {
#     "active": true,
#     "phase": "thinking" | "tool" | "writing",
#     "steps": [ {"icon":"🔧","tool":"Bash","label":"git status","done":true} ],
#     "text": "accumulated assistant markdown so far",
#     "ts": "ISO8601"
#   }
# Deleted when the turn ends (the final reply lives in a normal NNNN.json bubble).

# Tool name -> emoji + how to summarize its primary input into a one-liner.
def _tool_icon(name):
    return {
        'Bash': '🔧', 'Read': '📖', 'Edit': '✏️', 'Write': '📝',
        'MultiEdit': '✏️', 'Grep': '🔎', 'Glob': '🗂️', 'Task': '🤖',
        'WebFetch': '🌐', 'WebSearch': '🌐', 'TodoWrite': '✅',
        'NotebookEdit': '📓',
    }.get(name, '🔹')


def _short(s, n=80):
    s = str(s or '').strip().replace('\n', ' ')
    return s if len(s) <= n else s[:n - 1] + '…'


def _path_label(p, n=80):
    """Шлях у підпис кроку: тека лишається, імʼя файлу не губиться ніколи.

    Раніше тут стояв просто basename, і смузі прогресу не було чим заповнити вільну
    ширину: теку викидав ще запис (specs/live-step-width, К5). Три відмінності від
    _short: домашня тека скорочується до `~`, ріжемо ЗЛІВА (праворуч стоїть імʼя файлу,
    з якого фронт будує речення «Читаю stepHuman.ts»), і мітка обрізання теж зліва.
    """
    s = str(p or '').strip().replace('\n', ' ')
    if not s:
        return ''
    home = os.path.expanduser('~')
    if home and s.startswith(home + os.sep):
        s = '~' + s[len(home):]
    if len(s) <= n:
        return s
    return '…' + s[-(n - 1):]


def _tool_label(name, inp):
    """One-line human summary of a tool call from its input dict."""
    inp = inp or {}
    if name == 'Bash':
        # Команда ріжеться щедріше за решту підписів (240 проти 80). Причина заміряна на
        # реальних кроках: у ланцюгу `cd <довгий абсолютний шлях> && <справжня команда>`
        # вісімдесяти символів не вистачало навіть на сам cd, тож справжньої дії в даних
        # просто не лишалось (146 однакових обрізків «cd …/tools/viz/chat &…»). Людський
        # підпис у смужці прогресу будується саме з цього рядка, тому обрізок означав
        # безлике «виконую команду». Показ від довжини не страждає: смужка і панель
        # агентів ріжуть рядок стилями (truncate / line-clamp), а не даними.
        return _short(inp.get('command', ''), 240)
    if name in ('Read', 'NotebookEdit', 'Edit', 'Write', 'MultiEdit'):
        # Шлях цілком, а не basename: людське речення фронт і далі будує з імені файлу
        # (stepHuman.base), а тека йде другою, приглушеною половиною рядка.
        return _path_label(inp.get('file_path', ''))
    if name == 'Grep':
        return _short(inp.get('pattern', ''))
    if name == 'Glob':
        return _short(inp.get('pattern', ''))
    if name == 'Task':
        # subagent: prefer agent type / description
        return _short(inp.get('subagent_type') or inp.get('description') or 'агент')
    if name in ('WebFetch', 'WebSearch'):
        return _short(inp.get('url') or inp.get('query') or '')
    if name == 'TodoWrite':
        todos = inp.get('todos') or []
        return _short(f'{len(todos)} пунктів плану')
    # generic / MCP tools: show a compact key=val of the first scalar field
    for k, v in inp.items():
        if isinstance(v, (str, int, float)):
            return _short(f'{k}={v}')
    return ''


# ---- Stop support (kill-switch) -------------------------------------------
# While a turn runs the runner records the live claude PID at channels/<id>/pid
# so server.py's POST /api/stop can kill exactly that process (group). The file
# is removed in the turn's finally. server.py may also remove it (when it kills
# the turn); either side deleting it is the agreed "stop" signal. The runner
# treats an externally vanished pid/busy as "stopped" and exits the turn quietly
# (no scary error bubble), and never re-picks the queue server.py just cleared.

def pid_path(channel):
    return os.path.join(CHANNELS_DIR, channel, 'pid')


# channel -> jobId поточного turn. Реєстрація висить саме на write_pid, бо це
# ЄДИНЕ місце, крізь яке проходять усі три двигуни (warm, sdk, single-shot):
# так /api/jobs бачить і головні turn-и, не лише фонових агентів.
_TURN_JOBS = {}

# channel -> job, ЗАКРИТИЙ без підсумку. Двигун SDK прибирає pid у власному
# finally, тобто раніше, ніж хід знає, чим скінчився; знімок job з його
# годинником чекає тут на виклик, який принесе підсумок (див. clear_pid).
_TURN_FINISHED = {}


def write_pid(channel, pid):
    try:
        p = pid_path(channel)
        os.makedirs(os.path.dirname(p), exist_ok=True)
        with open(p, 'w') as f:
            f.write(str(pid))
    except Exception as e:
        log(f'{channel}: pid write failed: {e}')
    try:
        import jobs
        prev = _TURN_JOBS.pop(channel, None)
        if prev:
            jobs.finish(prev, 'done')
        job = jobs.register('turn', channel, pid, label='турн')
        if job:
            _TURN_JOBS[channel] = job['jobId']
    except Exception:
        pass          # реєстр не критичний для самого турну


def clear_pid(channel, outcome=None):
    """Хід віддав свій pid. Тут же він звітує в реєстр уваги (specs/
    turn-done-notifications, К1).

    `outcome` це ПІДСУМОК ХОДУ ЛЮДИНИ: 'done' | 'failed' | 'stopped' | 'gone'.
    None означає «це не хід людини або він уже відзвітував» і не емітить нічого:
    так лишаються тихими службові виклики (стиснення контексту ходить тим самим
    двигуном і теж пише pid) і повторний виклик із finally, коли хід уже
    закрився нормально.

    'gone' приходить саме з finally і спрацьовує лише тоді, коли хід ТАК І НЕ
    дійшов до власного кінця: аварія воркера, обрив інтерпретатора. У
    нормальному житті job на цей момент уже знятий, тобто подія не дублюється.

    Тривалість береться з реєстру процесів, який тут і закривається: `finish`
    повертає job з `startedAt` і `endedAt`, тож другого годинника заводити не
    треба. Немає job (реєстрація не вдалась), немає і події: вигадувати
    тривалість з повітря гірше, ніж промовчати.

    ЗАКРИТТЯ JOB І ПІДСУМОК ХОДУ ПРИЇЖДЖАЮТЬ РІЗНИМИ ВИКЛИКАМИ. Двигун SDK
    прибирає pid у ВЛАСНОМУ finally (`engine_sdk.py`), тобто раніше, ніж хід
    узагалі дізнається, чим він скінчився. Перший живий прогін це й показав:
    job закривався двигуном, а виклик з підсумком заставав порожньо і мовчав.
    Тому закритий без підсумку job чекає тут, у `_TURN_FINISHED`, і дістається
    тому виклику, який принесе підсумок."""
    p = pid_path(channel)
    if os.path.exists(p):
        try:
            os.remove(p)
        except OSError:
            pass
    fin = None
    try:
        import jobs
        jid = _TURN_JOBS.pop(channel, None)
        if jid:
            # Стан у реєстрі процесів лишається 'done' навмисно: панель
            # «Процеси» і сповіщення про ФОНОВУ роботу читають саме його, і
            # правити його заради нашої події означало б чіпати чужий шар.
            fin = jobs.finish(jid, 'done')
    except Exception:
        fin = None
    if outcome is None:
        # Службовий виклик (двигун, стиснення, повторний finally): закритий job
        # лишається чекати на того, хто знає підсумок.
        if fin:
            _TURN_FINISHED[channel] = fin
        return
    # Забираємо завжди, навіть коли job закрили тут: інакше знімок попереднього
    # ходу лежав би в словнику до кінця життя процесу.
    parked = _TURN_FINISHED.pop(channel, None)
    fin = fin or parked
    if not fin:
        return          # ходу тут не було: повторний finally над закритим ходом
    # ЄДИНИЙ вихід раннера в реєстр уваги. Усе інше (текст, затримка на картку,
    # журнал, довгий запит) живе в attention.py: раннер лише називає факт.
    try:
        import attention
        attention.default(DIR).emit_turn(
            channel, outcome,
            started_at=fin.get('startedAt'), ended_at=fin.get('endedAt'))
    except Exception as e:
        log(f'{channel}: attention emit failed: {e!r}')


def _reap(proc):
    """Best-effort reap so a killed claude turn never lingers as a <defunct>
    zombie under the runner. Safe to call on an already-dead process."""
    try:
        proc.wait(timeout=3)
    except Exception:
        try:
            proc.kill()
            proc.wait(timeout=2)
        except Exception:
            pass


def pid_was_stopped(channel, expected_pid):
    """True when our pid file is gone or no longer points at our process — the
    signal that server.py's /api/stop killed this turn. Used to suppress the
    error bubble for an intentional kill."""
    try:
        p = pid_path(channel)
        if not os.path.exists(p):
            return True
        cur = open(p).read().strip()
        return cur != str(expected_pid)
    except Exception:
        return False


def live_path(channel):
    return os.path.join(CHANNELS_DIR, channel, 'live.json')


def write_live(channel, state):
    """Atomically rewrite the channel's live turn state (best-effort)."""
    try:
        p = live_path(channel)
        os.makedirs(os.path.dirname(p), exist_ok=True)
        state = dict(state)
        state['ts'] = datetime.now().isoformat()
        tmp = p + '.tmp'
        with open(tmp, 'w', encoding='utf-8') as f:
            json.dump(state, f, ensure_ascii=False)
        os.replace(tmp, p)
    except Exception as e:
        log(f'{channel}: live write failed: {e}')


def clear_live(channel):
    for p in (live_path(channel), live_path(channel) + '.tmp'):
        if os.path.exists(p):
            try:
                os.remove(p)
            except OSError:
                pass


def events_path(channel):
    return os.path.join(CHANNELS_DIR, channel, 'events.jsonl')


_EVENTS_MAX_LINES = 500
_EVENTS_TRIM_BYTES = 220 * 1024


def emit_event(channel, rec):
    """Append one JSON event line to channels/<id>/events.jsonl for the «Процеси»
    panel (mirrors hooks/_emit.cjs). Best-effort, never raises. Opportunistic trim
    keeps the file to ~_EVENTS_MAX_LINES once it grows past _EVENTS_TRIM_BYTES so the
    common path stays a cheap append. No-op when the channel dir does not exist."""
    try:
        if not channel or '/' in channel or '..' in channel:
            return
        ch_dir = os.path.join(CHANNELS_DIR, channel)
        if not os.path.isdir(ch_dir):
            return
        rec = dict(rec)
        rec.setdefault('ts', datetime.now().isoformat())
        p = events_path(channel)
        with open(p, 'a', encoding='utf-8') as f:
            f.write(json.dumps(rec, ensure_ascii=False) + '\n')
        try:
            if os.path.getsize(p) > _EVENTS_TRIM_BYTES:
                lines = [l for l in open(p, encoding='utf-8').read().split('\n') if l]
                if len(lines) > _EVENTS_MAX_LINES:
                    with open(p, 'w', encoding='utf-8') as f:
                        f.write('\n'.join(lines[-_EVENTS_MAX_LINES:]) + '\n')
        except Exception:
            pass
    except Exception as e:
        log(f'{channel}: emit_event failed: {e}')


def read_live_snapshot(channel):
    """Best-effort read of the channel's transient live.json (the streamed-so-far
    text + tool steps). Returns (text, steps). Used to recover partial output when
    a turn is idle-aborted or user-stopped, so the work is never silently lost.
    Returns ('', []) when there is nothing to recover."""
    try:
        p = live_path(channel)
        if not os.path.exists(p):
            return '', []
        data = json.load(open(p, encoding='utf-8')) or {}
        return (data.get('text') or ''), (data.get('steps') or [])
    except Exception:
        return '', []


def persist_partial(channel, text, note, reply_to=None, model=None):
    """Render whatever the turn streamed BEFORE it was aborted as a permanent
    chat bubble, with a small italic note appended (idle-abort or user-stop).

    The streamed text is parsed through reply_to_widgets so any complete chatui
    widget blocks render as real cards; an incomplete trailing block degrades to
    plain text (reply_to_widgets already tolerates malformed/partial blocks). The
    note is a separate text widget so it never corrupts the partial markdown.
    `model` is passed straight through to reply_to_widgets for the К7 reject log.

    Returns True when a partial bubble was written (there was something to keep),
    False when there was no streamed content (caller may then leave it to the
    normal error/stop path)."""
    # Strip any ```plan``` declaration so it never leaks into a partial bubble or
    # TTS. A partial turn's plan may be incomplete, so we only STRIP here, we do
    # NOT persist it (that would half-write the sidebar from an aborted turn).
    body, _plan = extract_plan_block((text or '').strip())
    body = (body or '').strip()
    has_body = bool(body)
    widgets = reply_to_widgets(body, model, channel) if has_body else []
    if note:
        widgets.append({'type': 'text', 'text': note})
    if not widgets:
        return False
    try:
        append_message(channel, widgets, frm='Claude',
                       tag='status' if has_body else 'error', reply_to=reply_to)
    except Exception as e:
        log(f'{channel}: persist_partial failed: {e}')
        return False
    log(f'{channel}: persisted partial ({len(body)} chars) note={note!r}')
    return has_body


# Watchdog tick sentinel: yielded by _iter_with_idle when no new stdout line has
# arrived within IDLE_TICK seconds, so the consuming loop can re-check the idle /
# absolute / stop timers WITHOUT blocking forever on a wedged process's readline.
_IDLE_TICK = object()
# How often the watchdog wakes to re-check timers. Small enough that a low
# CHAT_RUNNER_IDLE_TIMEOUT (tests) and the Стоп button feel responsive, large
# enough to not busy-spin.
IDLE_TICK = float(os.environ.get('CHAT_RUNNER_IDLE_TICK', '2'))


def _iter_with_idle(proc):
    """Yield lines from proc.stdout, but ALSO yield _IDLE_TICK every IDLE_TICK
    seconds of silence so the caller can enforce idle/absolute/stop timeouts on a
    wedged process (a plain `for line in proc.stdout` would block on readline and
    never let the caller abort a silent turn).

    A daemon thread does the blocking reads and pushes lines onto a Queue; the
    generator drains the queue with a timeout. Cross-platform (no select on pipes,
    which is unreliable on Windows). When stdout closes (process ended) the reader
    pushes a None terminator and the generator returns. The reader is daemon, so a
    proc.kill() by the caller unblocks readline (EOF) and the thread exits."""
    import queue as _queue
    q = _queue.Queue()

    def _reader():
        try:
            for ln in proc.stdout:
                q.put(ln)
        except Exception:
            pass
        finally:
            q.put(None)   # EOF terminator

    threading.Thread(target=_reader, daemon=True).start()
    while True:
        try:
            item = q.get(timeout=IDLE_TICK)
        except _queue.Empty:
            yield _IDLE_TICK
            continue
        if item is None:
            return
        yield item


def run_claude_stream(prompt, session_id, channel):
    """Stage 3 streaming turn. Spawns claude with stream-json, parses the event
    stream line by line, and rewrites channels/<id>/live.json as tool steps run
    and assistant text accumulates. Returns (text, result_data, error) with the
    same shape as run_claude_json so the caller's usage/meter code is unchanged.

    Event types observed on v2.1.169 (verified by a real call):
      system/init                     session boot (tools, model, cwd)
      stream_event/content_block_start  block opens; content_block.type =
                                        thinking | text | tool_use (+ name)
      stream_event/content_block_delta  text_delta.text  (streamed reply text)
                                        input_json_delta.partial_json (tool args)
      assistant                       a finalized assistant message; tool_use
                                        blocks here carry the complete .input
      user                            tool_result (we just mark the step done)
      result/success                  final; .result + .usage + .total_cost_usd
    """
    resume = session_jsonl_exists(session_id)
    model = channel_model(channel, prompt)
    perm = channel_permission(channel)
    cmd = [CLAUDE_BIN, '-p', prompt,
           *_resolve_model_args(model),
           '--append-system-prompt', _sys_prompt(channel, session_id),
           '--disallowedTools', *channel_disallowed_tools(channel),
           '--output-format', 'stream-json', '--verbose',
           '--include-partial-messages',
           '--permission-mode', perm]
    cmd += _resume_or_seed_args(channel, session_id)
    log(f'claude stream ({"resume" if resume else "new"}) sid={session_id[:8]} '
        f'model={model} perm={perm} prompt={prompt[:60]!r}')

    steps = []            # list of {icon, tool, label, done}
    text = ''             # accumulated final-answer text (text_delta only)
    cur_block = None      # type of the currently open streamed block
    result_data = None
    final_text = None
    last_ctx_usage = None  # last assistant message's usage = true context size
    turn_model = None      # `model` останнього assistant-повідомлення, див. _turn_model

    def flush(phase):
        write_live(channel, {'active': True, 'phase': phase,
                             'steps': steps, 'text': text})

    flush('thinking')
    try:
        # start_new_session=True puts claude (and any subprocesses it spawns)
        # into its own process group so /api/stop can kill the whole tree with
        # one signal to -pid, not just the claude parent.
        proc = subprocess.Popen(
            cmd, cwd=REPO_ROOT, stdout=subprocess.PIPE, stderr=subprocess.PIPE,
            text=True, bufsize=1, **_PROC_GROUP_KW, env=_child_env(channel),
        )
    except Exception as e:
        return None, None, f'spawn failed: {e}'
    # record the live PID so server.py /api/stop can kill exactly this turn
    write_pid(channel, proc.pid)

    start = time.time()
    last_activity = start   # reset on EVERY line from claude (any sign of life)
    try:
        # iter(readline,'') instead of `for line in proc.stdout`: the watchdog
        # wakes us every IDLE_TICK seconds of silence so we can still react to the
        # Стоп button and the absolute backstop on a quiet turn. We do NOT abort on
        # idle anymore: a long, silent turn (big build, deep think) keeps running.
        # Only TURN_TIMEOUT (runaway-loop guard) or /api/stop ends it early.
        for line in _iter_with_idle(proc):
            if line is _IDLE_TICK:
                # watchdog woke us with no new output. Check ONLY the absolute
                # backstop and the user's Стоп. NO idle auto-abort.
                now = time.time()
                if now - last_activity > IDLE_TIMEOUT:
                    # Calm "still working" UI signal, NOT a kill: the turn is just
                    # quiet (thinking / long tool). Keep the streamed text + steps.
                    write_live(channel, {'active': True, 'phase': 'thinking',
                                         'steps': steps, 'text': text,
                                         'longRunning': True})
                if now - start > TURN_TIMEOUT:
                    proc.kill(); _reap(proc)
                    return None, None, f'timeout after {TURN_TIMEOUT}s'
                if pid_was_stopped(channel, proc.pid):
                    _reap(proc)
                    return text, result_data, STOP_SENTINEL
                continue
            last_activity = time.time()   # got real output -> reset idle clock
            # External stop (server.py /api/stop removed our pid file): bail out
            # quietly. The kill itself usually closes stdout first, but this
            # catches the rare case where claude buffers output post-signal.
            # Return the streamed-so-far text so the partial is preserved.
            if pid_was_stopped(channel, proc.pid):
                _reap(proc)
                return text, result_data, STOP_SENTINEL
            line = line.strip()
            if not line:
                continue
            try:
                ev = json.loads(line)
            except Exception:
                continue
            t = ev.get('type')

            if t == 'stream_event':
                inner = ev.get('event', {}) or {}
                et = inner.get('type')
                if et == 'content_block_start':
                    cb = inner.get('content_block', {}) or {}
                    cur_block = cb.get('type')
                    if cur_block == 'tool_use':
                        # partial start: show the tool name immediately; the
                        # full input arrives in the matching assistant event.
                        name = cb.get('name', '')
                        steps.append({'icon': _tool_icon(name), 'tool': name,
                                      'label': '', 'done': False})
                        flush('tool')
                elif et == 'content_block_delta':
                    d = inner.get('delta', {}) or {}
                    if d.get('type') == 'text_delta' and d.get('text'):
                        text += d['text']
                        flush('writing')
                elif et == 'content_block_stop':
                    cur_block = None

            elif t == 'assistant':
                # finalized message: tool_use blocks now have complete .input.
                # Capture this message's OWN usage. The last assistant message of
                # the turn carries the true context occupancy (its input side),
                # unlike the result event whose usage SUMS cache reads over every
                # agentic step. See write_usage for why that matters.
                _mu = (ev.get('message', {}) or {}).get('usage')
                if _mu:
                    last_ctx_usage = _mu
                if (ev.get('message', {}) or {}).get('model') not in (None, '', '<synthetic>'):
                    turn_model = ev['message']['model']
                for b in (ev.get('message', {}) or {}).get('content', []):
                    if b.get('type') == 'tool_use':
                        name = b.get('name', '')
                        label = _tool_label(name, b.get('input'))
                        # backfill the most recent unlabeled step for this tool,
                        # else append (covers tools without a partial start).
                        slot = next((s for s in reversed(steps)
                                     if s['tool'] == name and not s['label']
                                     and not s['done']), None)
                        if slot:
                            slot['label'] = label
                        else:
                            slot = {'icon': _tool_icon(name), 'tool': name,
                                     'label': label, 'done': False}
                            steps.append(slot)
                        if name == 'Skill':
                            # Helper Invoked (К7): імʼя ловимо тут, бо саме тут
                            # `.input` уже повне; сама подія їде пізніше, разом
                            # з outcome, коли прийде tool_result.
                            slot['helper'] = (b.get('input') or {}).get('skill')
                        # «Процеси» panel timeline: a Task tool is a sub-agent launch,
                        # everything else is a tool step (owner decision, 2026-07-08).
                        if name == 'Task':
                            emit_event(channel, {'kind': 'agent', 'phase': 'start',
                                'name': (b.get('input') or {}).get('subagent_type') or 'agent',
                                'detail': label})
                        else:
                            emit_event(channel, {'kind': 'tool', 'phase': 'start',
                                'name': name, 'detail': label})
                        flush('tool')

            elif t == 'user':
                # tool_result: mark the oldest not-done step as completed.
                slot = next((s for s in steps if not s['done']), None)
                if slot:
                    slot['done'] = True
                    emit_event(channel, {
                        'kind': 'agent' if slot.get('tool') == 'Task' else 'tool',
                        'phase': 'done', 'name': slot.get('tool') or '',
                        'detail': slot.get('label') or ''})
                    if slot.get('tool') == 'Skill':
                        _tr = next((bl for bl in
                                    (ev.get('message', {}) or {}).get('content', []) or []
                                    if isinstance(bl, dict) and bl.get('type') == 'tool_result'),
                                   None)
                        telemetry.get(DIR).track('Helper Invoked', {
                            'helper_name': _telemetry_safe_helper_name(slot.get('helper')),
                            'outcome': _telemetry_tool_outcome(
                                _tr.get('is_error') if _tr else None),
                        })
                    flush('tool')

            elif t == 'result':
                result_data = ev
                if last_ctx_usage:
                    ev['contextUsage'] = last_ctx_usage
                if turn_model:
                    ev['turnModel'] = turn_model
                if ev.get('is_error'):
                    err = ev.get('result') or 'unknown error'
                    return None, ev, f'claude error: {err}'
                final_text = (ev.get('result') or '').strip()

        proc.wait(timeout=10)
    except Exception as e:
        if pid_was_stopped(channel, proc.pid):
            _reap(proc)
            return text, result_data, STOP_SENTINEL
        try:
            proc.kill()
        except Exception:
            pass
        _reap(proc)
        return None, result_data, f'stream parse failed: {e}'

    # Intentional kill via /api/stop: stdout closed, process died on a signal,
    # and our pid file is gone. Report the stop sentinel, not a crash. Carry the
    # streamed-so-far text so process_channel can keep the partial.
    if pid_was_stopped(channel, proc.pid):
        _reap(proc)
        return text, result_data, STOP_SENTINEL

    if proc.returncode not in (0, None):
        tail = (proc.stderr.read() if proc.stderr else '') or ''
        tail = tail.strip()[-500:]
        if not final_text:
            return None, result_data, f'claude exited {proc.returncode}: {tail}'

    # Prefer the result event's text; fall back to streamed text if missing.
    out = final_text if final_text is not None else text.strip()
    return out, result_data, None


# ── Двигун Antigravity (agy) ────────────────────────────────────────────────
# Брат run_claude_stream: той самий контракт (text, result_data, error) і та сама
# жива смуга через write_live, тільки хід їде іншим CLI.
#
# 🔓 РІШЕННЯ ПРО ДОСТУП (власник, 2026-08-03, переглянуто після живих зондів agy 1.1.10).
# Antigravity ходить з ТИМИ САМИМИ можливостями, що й Claude: той самий корінь
# проєкту, ті самі read/write/run_command. Попереднє рішення (fail-closed плюс
# --sandbox плюс тека каналу) скасоване цілком, і ось на яких вимірах:
#
#   1. --dangerously-skip-permissions ОБОВʼЯЗКОВИЙ, тоншої ручки на хід нема.
#      Зонд без нього: «a tool required the "command" permission that headless
#      mode cannot prompt for, so it was auto-denied». Те саме прилетіло і на
#      read_file. Сам CLI у цьому ж рядку називає рівно два виходи: allow-правило
#      в permissions.allow у ~/.gemini/antigravity-cli/settings.json АБО цей
#      прапорець. Правило в settings.json тонше по ЗМІСТУ, але воно ГЛОБАЛЬНЕ:
#      мовчки змінило б поведінку інтерактивного agy самого користувача в кожному
#      проєкті на машині. Прапорець грубіший по змісту, зате живе рівно один
#      процес-хід і за межі Logopsis не тече. Обрано менше зло: вужчий слід.
#   2. --sandbox ЗНЯТИЙ, і це не косметика. Зонд: з ним двигун відрапортував
#      «WRITE=ok», а файл насправді ліг у ~/.gemini/antigravity-cli/scratch/,
#      репозиторій лишився недоторканим. Тобто пісочниця не забороняє запис, вона
#      його ПІДМІНЮЄ, і модель цього не бачить. Тиха брехня «зроблено» гірша за
#      чесну відмову, тому прапорця більше нема.
#   3. --add-dir REPO_ROOT потрібен ОКРЕМО від cwd. Без нього agy стартує «Outside
#      of Project», і файлові інструменти розвʼязують ВІДНОСНІ шляхи в ту саму
#      scratch-теку: зонд прочитав tools/viz/chat/VERSION і повернув 1.0.0, тоді
#      як у репозиторії лежить 0.2.6. Мовчазне читання файла-примари. З --add-dir
#      той самий зонд віддав 0.2.6, pwd став коренем, запис ліг на реальний диск.
#   4. cwd = REPO_ROOT, як у run_claude_stream. Тека channels/<id>/agy-work знята:
#      вона тримала двигун у пісочниці рівно тоді, коли ізоляція вже не потрібна.
#
# ⚠️ ЩО ЦЕ ВІДКРИВАЄ, без прикрас. Ізоляція, яку має Logopsis, це ізоляція РОЗМОВ
# (свій conversation_id на канал), а НЕ файлової системи. З цієї миті чат на
# Antigravity може читати, писати і виконувати рівно там само, де це може чат на
# Claude, тобто по всьому дереву проєкту і поза ним. Рішення свідоме (власник), не
# побічний ефект.
#
# 🛡 ГЕЙТ ДОЗВОЛІВ (2026-08-06). Тут раніше стояло, що «agy у headless спитати
# фізично не може, тому діє одразу». Це більше НЕПРАВДА, і різниці з Клодом нема.
# Теза була правдою про ВБУДОВАНИЙ механізм дозволів agy (звідти й автовідмова
# «headless mode cannot prompt for»), але не про хуки: живі зонди agy 1.1.10
# довели, що lifecycle-хук PreToolUse спрацьовує в режимі -p, спрацьовує НАВІТЬ
# разом із --dangerously-skip-permissions, і що його {"decision":"deny"} жорстко
# блокує дію та доносить причину до моделі. Тому перед run_command, propose_code,
# delete_directory, edit_notebook, write_blob і deploy_firebase тепер стоїть той
# самий UI-гейт, що й у Клода: .agents/hooks.json кличе
# tools/viz/chat/agy_pretool_gate.py, той показує картку «Дозволити / Відхилити»
# в каналі через ті самі /api/perm-request і /api/perm-status і чекає людину.
# Сховище спільне з гейтом Клода (channels/<id>/perm-allow.json і perm-auto), щоб
# дві поверхні не рахували дозволи по-різному. Гейт це OPT-IN (perm-auto=0),
# дефолт лишається нуль підтверджень, а без CHAT_PERM_CHANNEL хук пропускає все
# миттєво, тож інтерактивні сесії agy самого користувача недоторкані.
#
# Слід fail-closed лишається одним рядком: якщо ЯВНЕ deny-правило користувача все
# ж переріже інструмент, response приїде порожній, а на stdout ляже «jetski: no
# output produced». Мовчазна порожня бульбашка читалась би як поломка, тому нижче
# ми його ловимо і пояснюємо людською мовою.
AGY_STDOUT_DENIED = 'no output produced'
AGY_TURN_TIMEOUT = int(os.environ.get('CHAT_AGY_TIMEOUT', '600'))

# Преамбула контракту для Antigravity: віджети ПЛЮС блок ```plan```.
#
# Чому саме префіксом, хоча read_file тепер доступний. У agy нема аналога
# --append-system-prompt, тож канонних варіантів два: AGENTS.md у корені проєкту
# або префікс першого ходу. AGENTS.md програє двічі. По-перше, він недетермінований:
# двигун ЧИТАЄ його на власний розсуд, і мовчазний пропуск дає відповідь без
# жодного віджета, тобто рівно ту поломку, від якої ми пішли. По-друге, файл у
# корені репозиторію бачить і інтерактивний agy самого користувача, тому наш чатовий
# контракт нав'язувався б його ручним сесіям. Префікс іде В САМОМУ ходi, його не
# можна не прочитати, і за межі Logopsis він не тече.
#
# ```plan``` вливаємо ТУТ, бо для Клода він живе в _CHAT_PLAN_ITEM всередині
# CHAT_SYSTEM_OVERRIDE, а преамбула agy збиралась лише з WIDGET_CONTRACT. Через це
# чат на Antigravity не оновив план каналу ЖОДНОГО разу: він просто не знав, що
# такий блок існує. Нумерацію пункту знімаємо (у преамбулі agy свій порядок), решта
# тексту та сама, щоб два двигуни вчились одному контракту з одного джерела.
#
# Ф1 для agy (specs/i18n-interface, К12, 2026-08-26): приклад віджета мусить іти
# мовою обраної локалі, як і в живому чаті (chat_system_override) та у фонових
# агентах Клода (agent_widget_preamble). Вступна репліка «Відповідай УКРАЇНСЬКОЮ»
# нижче навмисно НЕ чіпається цим латанням: вона поза межами задачі, яка фіксує
# саме WIDGET_CONTRACT (див. пояснення вище), і лишається окремим пунктом.
def agy_first_turn_prefix(lang=DEFAULT_LANG):
    return (
        'Ти асистент у чаті Logopsis. Відповідай УКРАЇНСЬКОЮ. Довге тире заборонене, '
        'заміняй його крапкою, комою або двокрапкою.\n\n'
        + _widget_syntax(lang) + WIDGET_ANSWER_SHAPE + WIDGET_JSON_RULE + _widget_catalog(lang)
        + '\n' + _CHAT_PLAN_ITEM.replace('5. PLAN SIDEBAR', 'PLAN SIDEBAR', 1)
        + '\nЦі правила діють на КОЖНУ твою наступну відповідь у цій розмові, не лише '
          'на цю. Далі йде перше повідомлення користувача.\n\n---\n\n'
    )


# Текст, який хук PreInvocation кладе в контекст ПЕРЕД викликом моделі.
#
# Префікс вище лишається як був: він доводить контракт до першого ходу і не
# змінюється. Хук закриває дві дірки, яких префікс закрити не може в принципі.
#
# Дірка 1: ходи 2+. Префікс іде рівно раз, далі контракт тримається лише на
# памʼяті моделі, і чим довший чат, тим певніше вона зʼїжджає з віджетів у голий
# текст. Хук доносить нагадування на кожен хід.
#
# Дірка 2: .agents/AGENTS.md. Цей файл лежить у корені репозиторію ще з 27.07 і
# agy читає його ЗАВЖДИ, зокрема на наших headless-ходах. Він забороняє
# run_command і велить створювати окремий канал у Logopsis. Обидва пункти писались
# під інтерактивну IDE і після паритету 2026-08-03 прямо суперечать тому, що ми
# двигуну відкрили: він має руки, а файл каже ними не користуватись. Видалити файл
# не можна, він керує ручними сесіями користувача. Тому ми не сперечаємось із ним
# глобально, а знімаємо його рівно для свого режиму, у самому контексті ходу.
AGY_HEADLESS_NOTE = (
    'Контекст запуску: ти працюєш headless усередині Logopsis, у режимі -p. '
    'Дозволи на інструменти вже видані наперед, ніхто нічого не підтверджує '
    'вручну, спливаючих вікон не існує. Тому правило з .agents/AGENTS.md про '
    'заборону run_command писалось під інтерактивну IDE і тут НЕ діє: '
    'run_command, читання і запис файлів тобі дозволені, користуйся ними. '
    'Так само не створюй окремий канал чи картку у Logopsis: твоя відповідь '
    'сама стає карткою в каналі, дубль призвів би до двох повідомлень.'
)

# Нагадування контракту на ходах 2+. Свідомо СТИСЛЕ, а не повний WIDGET_CONTRACT:
# ephemeralMessage лягає в хвіст контексту, а не в префікс, тож кешем двигуна він
# не покривається і повний контракт коштував би повну ціну на кожному ході.
#
# СХЕМНА ЧАСТИНА (specs/widget-dialect-adapter, К7). До 31.08.2026 тут не було
# ЖОДНОГО імені поля: перелічувались лише типи («порівняння через table, числа
# через stat-grid»). Модель бачить повний контракт рівно раз, у префіксі першого
# ходу, тому далі вона добудовувала схему зі своїх апріорі і писала `headers`
# замість `columns`, `status` замість `verdict`, `rows:[{key,value}]` замість
# `items:[{k,v}]`. Замір (scripts/widget-dialects-report.cjs, весь корпус):
# antigravity 4,50 % повідомлень із карткою «Віджет не вдалось відмалювати»
# проти 0,17 % у Клода, тобто 26 разів частіше.
#
# Типи взяті НЕ з реєстру, а з заміру: рівно ті вісім, які Gemini реально малює
# і реально ламає (verdict 23, table 13, comparison-matrix 7, key-value 4,
# key-values 2, checklist/list/bullet-list 3, stat-grid 1, gallery 1). Класти
# сюди решту 36 типів означало б платити за них токенами на кожному ході.
#
# Межа verdict/conclusion сказана ЯВНО і в одному реченні, бо перелік типів її
# не ловить: 9 разів модель написала `{"type":"verdict","text":...,"tone":...}`,
# тобто валідний conclusion під чужим іменем.
#
# Стеля 900 символів на схемну частину (ризик у розділі 4 спеки) тримається
# тестом tests/unit/test_agy_turn_reminder_fields.py: цей текст їде повз кеш
# двигуна на КОЖНОМУ ході, тому кожен зайвий рядок тут оплачується постійно.
AGY_TURN_REMINDER_UK = (
    'Нагадування контракту цього чату (діє на КОЖНУ відповідь): відповідай '
    'українською, довге тире заборонене (крапка, кома або двокрапка). '
    'Змістовну відповідь подавай віджетами у блоках ```chatui```: вирок або '
    'пряма відповідь першою, потім проза з причинністю, потім деталі, і '
    'ОСТАННІМ віджетом conclusion. Мінімум три РІЗНІ типи віджетів, будь-яке '
    'порівняння через table чи comparison-matrix, будь-які числа через '
    'stat-grid чи key-values, докази з detail: true. JSON усередині ```chatui``` '
    'мусить бути валідним, інакше картка втрачається. Інфо-рядок огорожі це '
    'РІВНО chatui, а не json: під ```json це буде сірий блок коду, а не картка. '
    'Якщо в задачі більше двох '
    'кроків, онови план каналу блоком ```plan```.\n'
    'Схеми полів, імена ПИШИ ДОСЛІВНО, синонім ворота відкидають. '
    'verdict: subject, verdict GO|PIVOT|KILL, (reasons); текст плюс тон без '
    'subject це не verdict, а conclusion: text, (tone, points). '
    'table: columns [рядки], rows [[клітинка]], клітинка це рядок або '
    '{text, status}. '
    'comparison-matrix: cols [{name}], rows [мітки рядків], cells [[{text, '
    'status}]], усі три списки обовʼязкові. '
    'key-values: items [{k, v}]. stat-grid: cards [{value, label, color}]. '
    'checklist: items [рядок або {text, state}]. gallery: images [{src, caption}]. '
    'Заборонені імена: headers, status замість verdict, rationale, values, '
    'rows з {key,value}.'
)


# Мовний хвіст нагадування (Д4, застосовано той самий приймальний зразок, що
# `_HAT_LANG_OVERRIDE_EN` нижче: гілка по мові для ДРУГОГО шару інструкцій).
#
# Що було зламано. Перше речення нагадування каже «відповідай українською, довге
# тире заборонене» БЕЗУМОВНО, а саме нагадування їде ephemeral-повідомленням у
# ХВІСТ контексту на кожному ході 2+, тобто стоїть до розмови ближче за будь-який
# правильний мовний шар у префіксі. Англійський інтерфейс через це отримував
# кирилицю: людина обрала en, а найближча до неї інструкція вимагала укр.
#
# Чому хвостом, а не другим повним перекладом. Рівно з тієї причини, що й у
# капелюха: шкідливе тут ОДНЕ речення, решта тексту це імена полів віджетів
# (columns, cells, k, v), які латиницею однакові в обох мовах. Другий переклад
# коштував би подвійного супроводу і другої стелі 900 символів на схемну частину,
# не давши моделі жодного нового факту. Хвіст цитує скасовуване речення дослівно,
# тому працює незалежно від того, що стоїть між ними.
#
# НЕ через _lang_text: порожній рядок для 'uk' там впав би на 'en'-гілку через
# `or` (chunks.get(lang) or chunks['en']), тобто мовчки віддав би override і
# українцеві. Та сама пастка, що описана біля _HAT_LANG_OVERRIDE_EN.
_AGY_REMINDER_LANG_OVERRIDE_EN = (
    '\nLANGUAGE NOTE (overrides the first sentence above): "відповідай '
    'українською, довге тире заборонене" is the Ukrainian-interface default and '
    'does not apply here. The user selected English as the interface language, '
    'so reply in English, and the em-dash ban does not apply in English. '
    'Everything else above stays in force exactly as written: the widget '
    'contract, the ```chatui``` fence and every field name.'
)


def agy_turn_reminder(lang=DEFAULT_LANG):
    """Нагадування контракту для ходів 2+ мовою інтерфейсу.

    Джерело мови тут це мова ІНТЕРФЕЙСУ, а не мова розмови: текст керує тим, як
    двигун відповідає ЛЮДИНІ в стрічці, тобто це чрома інтерфейсу, а не витяг із
    наявного змісту. Той самий поділ, що в chat_system_override і _hat_section.

    Бар-доступ `runner.AGY_TURN_REMINDER` лишається заморожений на 'uk' через
    _LAZY (PEP 562), щоб test_agy_turn_reminder_fields.py читав ту саму стрічку
    байт у байт, що й до латання."""
    return AGY_TURN_REMINDER_UK + ('' if lang == 'uk'
                                   else _AGY_REMINDER_LANG_OVERRIDE_EN)


# Вікно контексту моделей Antigravity, за родиною id (`agy models`).
#
# ЧЕСНО ПРО ДЖЕРЕЛО: сам двигун вікна НЕ віддає у потік stream-json, але воно
# лежить у ЙОГО ВЛАСНИХ базах розмов (~/.gemini/antigravity-cli/conversations/*.db,
# таблиця gen_metadata, protobuf-блоби). Замір по 150 базах, пошук varint:
#   256000  937 входжень у 129 базах
#   128000  110 входжень у 20 базах
#   1000000 НУЛЬ входжень
# Тобто попереднє число 1000000 не існує в даних двигуна взагалі: воно бралось з
# картки моделі, а harness Antigravity видає моделі менше, ніж вона вміє. Той
# самий висновок незалежно дав ресерч reference/antigravity-context-control.md
# (розділ 3.6) з того ж сховища: родина flash = 256000, pro = 128000, пікове
# заміряне навантаження 252377 проти стелі 256000.
#
# Збіг за ПІДРЯДКОМ, а не за точним іменем: наші канали звітують activeModel як
# `gemini-3.7-flash-high` чи `gemini-3.1-pro-high`, тобто з суфіксом рівня
# зусиль, і будь-який перелік точних імен застаріє на наступному релізі CLI.
# Кожне число можна перекрити змінною середовища, не чіпаючи код. Невідома
# модель падає на старий дефолт CONTEXT_WINDOW, тобто гірше, ніж було, не стає.
AGY_GEMINI_WINDOWS = (
    ('flash', int(os.environ.get('CHAT_AGY_CTX_GEMINI_FLASH', '256000'))),
    ('pro', int(os.environ.get('CHAT_AGY_CTX_GEMINI_PRO', '128000'))),
)
AGY_CONTEXT_WINDOWS = (
    ('gemini-', int(os.environ.get('CHAT_AGY_CTX_GEMINI', '256000'))),
    ('claude-', int(os.environ.get('CHAT_AGY_CTX_CLAUDE', '200000'))),
    ('gpt-oss', int(os.environ.get('CHAT_AGY_CTX_GPTOSS', '128000'))),
)


def agy_context_window(model_id):
    """Знаменник метра контексту для конкретної моделі Antigravity.

    Спершу підрядок flash/pro (родина gemini), потім префікс родини. Родина
    Клода зі збігу за підрядком виключена свідомо: там своє вікно, і випадкове
    `pro` в чужому імені не сміє його підмінити."""
    m = (model_id or '').lower()
    if not m.startswith('claude-'):
        for token, window in AGY_GEMINI_WINDOWS:
            if token in m:
                return window
    for prefix, window in AGY_CONTEXT_WINDOWS:
        if m.startswith(prefix):
            return window
    return CONTEXT_WINDOW


def agy_conversation_path(channel):
    return os.path.join(CHANNELS_DIR, channel, 'agy_conversation')


# Коди, за якими в лозі CLI впізнається СПРАВЖНЯ причина збою. Беремо останній
# рядок, що збігся: він описує саме той хід, який щойно впав.
AGY_LOG_CODE_RE = re.compile(
    r'PERMISSION_DENIED|UNAUTHENTICATED|RESOURCE_EXHAUSTED|UNAVAILABLE|'
    r'DEADLINE_EXCEEDED|INVALID_ARGUMENT|\bcode \d{3}\b', re.I)
# Префікс glog, яким agy починає КОЖЕН рядок ('ERROR: logging before google.Init:
# E0819 23:33:56.217173  562 errorreport.go:223] '). Для людини це шум, тому
# зрізаємо все до першої дужки з пробілом.
_AGY_LOG_PREFIX_RE = re.compile(r'^.*?\]\s+')
AGY_LOG_TAIL_BYTES = 400_000     # причина завжди в кінці, весь файл читати нема сенсу


def agy_log_path(channel):
    """Власний лог CLI цього каналу. ЄДИНЕ місце, де видно причину збою: при 403
    stderr порожній, а стрім віддає лише 'Agent execution terminated due to
    error.' (заміряно на 18 збоях 2026-08-19).

    Один файл на канал, і він спорожнюється перед кожним ходом (agy_log_reset),
    тож рости йому нема куди. Тека channels/ і так поза git."""
    return os.path.join(CHANNELS_DIR, channel, 'agy.log')


def agy_log_reset(channel):
    """Спорожнити лог перед ходом і повернути шлях, '' коли не вийшло.

    Повертає '' навмисно: тоді прапорець --log-file просто не додається, і хід
    їде рівно так, як їхав до цієї правки. Збій запису не сміє коштувати ходу."""
    path = agy_log_path(channel)
    try:
        os.makedirs(os.path.dirname(path), exist_ok=True)
        with open(path, 'w', encoding='utf-8'):
            pass
        return path
    except Exception as e:
        log(f'{channel}: agy log reset failed: {e}')
        return ''


def agy_log_cause(channel, path=None, limit=400):
    """Останній рядок лога CLI з кодом помилки, у людському вигляді. '' коли
    такого рядка нема або лога нема взагалі."""
    p = path or agy_log_path(channel)
    try:
        size = os.path.getsize(p)
        with open(p, 'rb') as f:
            if size > AGY_LOG_TAIL_BYTES:
                f.seek(size - AGY_LOG_TAIL_BYTES)
            blob = f.read().decode('utf-8', 'replace')
    except Exception:
        return ''
    for line in reversed(blob.splitlines()):
        line = line.strip()
        if line and AGY_LOG_CODE_RE.search(line):
            return _AGY_LOG_PREFIX_RE.sub('', line).strip()[:limit]
    return ''


# Рядки, на яких хід рубаємо НЕ чекаючи стріму. Дослівно з живого лога chat-332
# (2026-09-15):
#   run.go:389] Run: attempt 1 failed (UNAVAILABLE (code 503): No capacity
#   available for model gemini-3.8-flash-high on the server), retrying in 4s
# Google відмовляє в першу секунду і пише це у файл, але сам CLI на 503 не виходить:
# він мовчки сидить до власного --print-timeout 600s. Раннер читав лише stdout, де за
# ці 10 хвилин нема жодної події, тому причину дізнавався аж на 605-й секунді, а далі
# ' 503' підпадало під _is_transient_error і хід повторювався ТІЄЮ САМОЮ моделлю, до
# трьох разів: близько 30 хвилин тиші за помилку, відому одразу.
# Тригер свідомо ВУЗЬКИЙ, рівно на ці два дослівні рядки. Ширший збіг (будь-яке
# 'error' чи 'failed') рубав би живий хід на нешкідливому попередженні: цей самий лог
# сипле власними ERROR-рядками glog навіть коли все гаразд, починаючи з
# 'ERROR: logging before google.Init'.
AGY_LOG_FATAL_MARKERS = ('no capacity available for model', 'unavailable (code 503)')


def agy_log_watch(path):
    """Стан дочитування лога цього ходу. pos це скільки байтів уже розібрано."""
    return {'path': path or '', 'pos': 0}


def agy_log_tail_fatal(watch, limit=400):
    """Дочитати ХВІСТ лога з минулого разу і повернути дослівний рядок про відмову
    в потужності. '' поки такого рядка нема.

    Тримаємо зміщення, а не перечитуємо файл: на idle-tick у 2 с хід тривалістю
    600 с це 300 перевірок, тож повне читання лога коштувало б десятків мегабайт
    за один хід.

    Споживаємо лише ЗАВЕРШЕНІ рядки (ріжемо по останньому \\n і решту лишаємо на
    наступний тік): інакше маркер, який ліг на межу двох читань, розпався б навпіл
    і не збігся б ніколи."""
    path = (watch or {}).get('path')
    if not path:
        return ''
    try:
        size = os.path.getsize(path)
        if size < watch['pos']:
            watch['pos'] = 0       # лог вкоротили (agy_log_reset наступного ходу)
        if size <= watch['pos']:
            return ''
        with open(path, 'rb') as f:
            f.seek(watch['pos'])
            blob = f.read()
    except Exception:
        return ''
    cut = blob.rfind(b'\n')
    if cut < 0:
        return ''                  # рядок ще дописується, дочитаємо наступним тіком
    watch['pos'] += cut + 1
    for line in blob[:cut].decode('utf-8', 'replace').splitlines():
        low = line.lower()
        if any(mark in low for mark in AGY_LOG_FATAL_MARKERS):
            return _AGY_LOG_PREFIX_RE.sub('', line.strip()).strip()[:limit]
    return ''


def _is_agy_capacity_error(err) -> bool:
    """True для «під цю модель зараз нема потужності» (503 від Google).

    Окрема функція, а не кілька слів у _is_transient_error: той класифікатор
    спільний для обох двигунів, а лікування тут інше за визначенням. Повтор ТІЄЮ
    САМОЮ моделлю безнадійний, бо відмова прив'язана саме до моделі, і слід
    chat-332 це показує дослівно: три спроби поспіль на gemini-3.8-flash-high,
    усі три 503."""
    if not err or err == STOP_SENTINEL:
        return False
    low = err.lower()
    return any(mark in low for mark in AGY_LOG_FATAL_MARKERS)


# Канали, які цього ходу вже витратили свій ЄДИНИЙ фолбек моделі для Antigravity.
# Аналог _model_safe_retry, але окремий набір і окремий сенс: _FORCE_BARE впливає
# лише на _resolve_model_args, тобто на Клода, а run_agy_stream бере модель через
# agy_model_for і про той прапорець не знає взагалі. Прибирається на початку
# кожного промпта, поруч із _model_safe_retry.discard.
_agy_bare_retry = set()


# Імена параметрів інструментів Antigravity. Зняті ЖИВИМ зондом 2026-09-15 на agy
# 1.2.3 (`--output-format stream-json` у /tmp), НЕ вгадані з голови: у двигуна вони
# переважно PascalCase, але не всі (search_web віддає `query` малими літерами), тож
# здогад коштував би рівно тієї порожньої мітки, яку ми тут і лікуємо. Дослівні
# знімки parameters із зондів:
#   list_dir             {"DirectoryPath": "/tmp/agyprobe2"}
#   view_file            {"AbsolutePath": "/tmp/agyp_a/s.txt"}
#   grep_search          {"Query": "needle", "SearchPath": "/tmp/agyprobe2"}
#   find_by_name         {"Pattern": "*.md", "SearchDirectory": "/tmp/agyp_b"}
#   write_to_file        {"TargetFile": "/tmp/agyp_a/made.txt"}
#   replace_file_content {"TargetFile": "/tmp/agyp_a/s.txt"}
#   run_command          {"CommandLine": "echo probe-done"}
#   search_web           {"query": "OpenAI gpt-5 api pricing current price"}
#   call_mcp_tool        {"Arguments": {}, "ServerName": "chatview", "ToolName": "chats_list"}
# Решта з 56 інструментів двигуна свідомо не перелічена: її закриває універсальний
# фолбек у _agy_tool_label. Список вгаданих ключів мовчки не спрацював би, а мовчазна
# порожня мітка це саме той дефект, з якого почалась ця правка.
# Друге поле кортежа це ФОРМА значення, від неї залежить лише різання довжини.
AGY_TOOL_PARAMS = {
    'list_dir':             ('DirectoryPath', 'path'),
    'view_file':            ('AbsolutePath',  'path'),
    'write_to_file':        ('TargetFile',    'path'),
    'replace_file_content': ('TargetFile',    'path'),
    'grep_search':          ('Query',         'text'),
    'find_by_name':         ('Pattern',       'text'),
    'search_web':           ('query',         'text'),
    'run_command':          ('CommandLine',   'cmd'),
}


def _agy_tool_label(name, info):
    """Аргумент дії кроку Antigravity одним рядком: шлях, команда, шаблон, запит.

    Імʼя інструмента тут НЕ перекладається на клодівське і взагалі не чіпається:
    воно лишається сирим у полі `tool`, а ця функція дає лише ЗНАЧЕННЯ. Порядок
    джерел: відомий з зонда ключ, далі універсальний фолбек «перше непорожнє
    рядкове значення». Фолбек не косметика, а вимога: інструментів у двигуна 56,
    і будь-який неперелічений мусить дати підпис, а не порожнечу.

    Довжину ріже наявний _short, окрім шляхів: для них той самий наявний
    _path_label, бо він ріже ЗЛІВА і не губить імені файлу (справжній шлях у цьому
    репозиторії, .../tools/viz/chat/runner.py, це 84 символи, тобто під _short з
    його вісімдесятьма від нього лишився б обрізок без `runner.py`, а саме з імені
    файлу фронт будує людське речення кроку)."""
    params = (info or {}).get('parameters')
    if not isinstance(params, dict):
        return ''
    if name == 'call_mcp_tool':
        # Сервер і дія разом: самого ServerName мало (а саме його взяв би фолбек,
        # бо Arguments це dict і рядком не є), тож крок читався б як «chatview»
        # без жодної підказки, що саме там викликали.
        srv = params.get('ServerName')
        act = params.get('ToolName')
        if isinstance(srv, str) and isinstance(act, str) and srv.strip() and act.strip():
            return _short(f'{srv.strip()}/{act.strip()}')
    key, shape = AGY_TOOL_PARAMS.get(name, ('', 'text'))
    val = params.get(key) if key else None
    if not (isinstance(val, str) and val.strip()):
        # К2: dict зберігає порядок вставки, тож «перше» значення це справді
        # перший аргумент виклику, а не випадковий.
        val = next((v for v in params.values()
                    if isinstance(v, str) and v.strip()), '')
        shape = 'text'
    if not val:
        return ''
    if shape == 'path':
        return _path_label(val)
    # 240 для команди рівно з тієї причини, що вже описана в _tool_label для Bash:
    # у ланцюгу `cd <довгий абсолютний шлях> && <справжня команда>` вісімдесяти
    # символів не вистачає навіть на сам cd, і в даних не лишається дії. Фронт
    # проганяє run_command через той самий fromBash, тому й бюджет той самий.
    return _short(val, 240 if shape == 'cmd' else 80)


# Крок error_message у 18 заміряних збоях приходив БЕЗ тексту: двигун каже, що хід
# помер, і не каже чому. Мітка тримає сам факт, інакше причина була б порожньою і
# ми знову не відрізнили б «впав» від «відповів порожнім рядком».
AGY_ERROR_STEP_NOTE = 'двигун обірвав хід повідомленням про помилку'


def _agy_step_text(su):
    """Людський текст кроку стріму, '' коли його нема. Полів у двигуна кілька і
    вони різняться між версіями, тому перебираємо всі відомі, а не одне."""
    for key in ('text_delta', 'text', 'message', 'error', 'error_message'):
        v = (su or {}).get(key)
        if isinstance(v, str) and v.strip():
            return v.strip()
        if isinstance(v, dict):
            m = v.get('message') or v.get('text') or v.get('error')
            if isinstance(m, str) and m.strip():
                return m.strip()
    return ''


def _agy_failure_cause(channel, status, result_error, step_errors, err_tail):
    """Одна стрічка причини з УСІХ джерел ходу плюс дочитаний лог CLI.

    Склейка потрібна тому, що жодне джерело поодинці причини не несе: result.error
    каже лише «терміновано», крок error_message приходить порожній, stderr
    порожній, а рядок з кодом лежить тільки в лозі. Саме через це в лог раннера
    їхало 'agy exited 1:' з порожнім хвостом, і хід не можна було ні пояснити
    людині, ні визнати тимчасовим."""
    parts = []
    for p in [result_error] + list(step_errors or []) + [err_tail]:
        p = ' '.join((p or '').split())
        if p and p not in parts:
            parts.append(p)
    if (status or '').upper() == 'ERROR' and not parts:
        parts.append('двигун завершив хід зі статусом ERROR')
    # Лог дочитуємо РІВНО тоді, коли явної причини нема: код у ньому є завжди,
    # але зайве читання файла на кожному ході нам ні до чого.
    if not AGY_LOG_CODE_RE.search('; '.join(parts)):
        extra = agy_log_cause(channel)
        if extra and extra not in parts:
            parts.append(extra)
    return '; '.join(parts)


def agy_inject_path(channel):
    """Файл, який читає agy_preinvocation_hook.py на цьому ході."""
    return os.path.join(CHANNELS_DIR, channel, 'agy_inject.txt')


def write_agy_inject(channel, first_turn):
    """Покласти текст впорскування для цього ходу і повернути шлях до нього.

    Повертає '' якщо записати не вдалось: тоді runner просто не виставить
    LOGOPSIS_AGY_INJECT, хук побачить порожньо і віддасть {}, а хід поїде рівно
    так, як їхав до появи хука. Тобто збій тут нічого не ламає.

    КАПЕЛЮХ НА AGY (рішення власника, 2026-08-30). Тіло агента їде саме тут, а не в префіксі
    першого ходу, і на КОЖЕН хід. Причина в тому, що в agy нема аналога
    --append-system-prompt: персона може жити тільки в контексті, а контекст,
    доставлений один раз, вивітрюється рівно так само, як вивітрювався контракт
    віджетів (дірка 1 у поясненні хука вище). Один хід це одне впорскування,
    тому персона не накопичується.

    Дублю з префіксом тут нема: у префікс капелюх не кладеться взагалі, це
    ЄДИНЕ місце, звідки він доїжджає до двигуна."""
    parts = [AGY_HEADLESS_NOTE]
    if not first_turn:
        # На першому ході контракт уже приїхав префіксом, дублювати його в тому
        # самому ході означало б платити за нього двічі.
        parts.append(agy_turn_reminder(current_lang(channel)))
    hat = _hat_section(channel)
    if hat:
        parts.append(hat.strip())
    path = agy_inject_path(channel)
    try:
        os.makedirs(os.path.dirname(path), exist_ok=True)
        with open(path, 'w', encoding='utf-8') as f:
            f.write('\n\n'.join(parts))
        return path
    except Exception as e:
        log(f'{channel}: agy inject write failed: {e}')
        return ''


def agy_hat_marker_path(channel):
    """Слаг капелюха, під яким живе ПОТОЧНА розмова agy. '' у файлі = без капелюха."""
    return os.path.join(CHANNELS_DIR, channel, 'agy_hat')


def agy_reset_conversation_on_hat_change(channel):
    """Змінився капелюх -> обірвати розмову двигуна і почати нову. -> bool.

    Навіщо. Памʼять розмови на agy живе НЕ у нас, а в conversation_id на боці
    двигуна. Впорскування несе персону в контекст КОЖНОГО ходу, але вже
    сказане двигун памʼятає сам: продовживши стару розмову, він тягне за собою
    попередню особистість і власні відповіді від її імені. Тому зміна капелюха
    це не «додати нову інструкцію», а нова розмова.

    Знявся капелюх зовсім (''), це теж зміна: інакше загальний асистент
    успадкував би памʼять ментора.

    Збій читання чи запису тут навмисно не кидає: у найгіршому випадку розмова
    просто не обірветься, тобто поведінка рівно та, що була до цієї функції."""
    slug = _channel_agent_slug(channel) or ''
    path = agy_hat_marker_path(channel)
    try:
        prev = open(path, encoding='utf-8').read().strip() if os.path.exists(path) else None
    except Exception:
        prev = None
    if prev == slug:
        return False
    changed = prev is not None and prev != slug
    if changed:
        try:
            os.remove(agy_conversation_path(channel))
            log(f'{channel}: agy hat {prev or "(none)"} -> {slug or "(none)"}, '
                f'conversation reset')
        except FileNotFoundError:
            pass
        except Exception as e:
            log(f'{channel}: agy conversation reset failed: {e}')
    try:
        os.makedirs(os.path.dirname(path), exist_ok=True)
        with open(path, 'w', encoding='utf-8') as f:
            f.write(slug)
    except Exception as e:
        log(f'{channel}: agy hat marker write failed: {e}')
    return changed


def agy_workdir(channel):
    """Корінь проєкту, той самий, з якого стартує run_claude_stream. Аргумент
    channel лишається у підписі свідомо: він тримає місце на випадок, коли колись
    зʼявиться чат із власним коренем, і дозволяє не переписувати виклик.

    Історія: тут була channels/<id>/agy-work. Вона мала звузити горизонт двигуна,
    а насправді ламала його: відносні шляхи файлових інструментів agy розвʼязуються
    НЕ від cwd, тож із чужим коренем двигун читав файли-примари зі своєї scratch-теки
    замість справжніх (зонд: VERSION приїхав 1.0.0 замість 0.2.6)."""
    return REPO_ROOT


def _agy_alias(channel, prompt=None):
    """Модель каналу (аліас або повний id Клода) -> один із чотирьох аліасів."""
    v = str(channel_model(channel, prompt) or 'sonnet').lower()
    for a in ('fable', 'haiku', 'sonnet', 'opus'):
        if a in v:
            return a
    return 'sonnet'


# ---- Зображення, які СТВОРИВ хід Antigravity ------------------------------
# Двигун уміє генерувати картинки, але кладе артефакт у власну теку
# (~/.gemini/antigravity-cli/brain/<uuid>/<name>.jpg) і в тексті лишає рівно
# посилання `file://`. Живий зонд: JPEG 1024x1024 на диску є, а в стрічці була
# гола стрічка тексту з мертвим посиланням, бо шлях файлової системи браузер по
# http не читає в принципі. Тобто картинка, за яку вже заплачено денним лімітом,
# до людини не доїжджала взагалі.
#
# Лікуємо там же, де розбираємо відповідь: знайдені шляхи їдуть у стрічку
# ```chatui```-хвостом, тобто ТИМ САМИМ каналом, яким віджети пише сама модель.
# Далі все штатне: reply_to_widgets робить із хвоста віджет, append_message жене
# його через normalize_media, і той копіює файл у assets/media/ під імʼям з хеша
# (а зниклий мітить srcMissing, щоб фронт намалював помітну картку помилки).
# Свого шляху копіювання тут нема свідомо: два копіювальники розʼїхались би.
AGY_MEDIA_EXT = ('png', 'jpg', 'jpeg', 'gif', 'webp', 'bmp')
AGY_MEDIA_MAX = 12          # стеля на хід, щоб пакетна генерація не залила стрічку
# Наскільки раніше за старт ходу дозволено бути файлу. Секунди, а не хвилини:
# запас лише на грубість mtime і на різницю годинників, не на «майже свіжий».
AGY_MEDIA_SLACK = 5.0
AGY_MEDIA_TITLE = 'Зображення з цього ходу'

# Абсолютний шлях у двох формах, бо систем дві. POSIX це `/…` або `~/…`, Windows це
# буква диска плюс роздільник (`C:\…`, зустрічається і `C:/…`). Без другої гілки на
# Windows не знаходилось НІЧОГО: двигун друкує `C:\Users\…\circle.png`, регулярка
# вимагала слеша на початку, список шляхів виходив порожній, і згенерована картинка
# просто не зʼявлялась у стрічці. Заміряно на windows-раннері CI: 14 перевірок
# tests/unit/test_agy_image_artifact.py впали одним махом саме на цьому.
# Необовʼязковий слеш перед буквою диска зʼїдається ПОЗА захопленням: `file:///C:/x.png`
# це та сама адреса, і тягнути її провідний слеш у шлях на диску не можна.
_AGY_MEDIA_RE = re.compile(
    r'(?:file://)?(?:/(?=[A-Za-z]:[\\/]))?'
    r'((?:~?/|[A-Za-z]:[\\/])[^\s()\[\]<>"\'`]+\.(?:' + '|'.join(AGY_MEDIA_EXT) + r'))',
    re.I)


def _widget_media_srcs(widgets):
    """Усі src, які у відповіді ВЖЕ віддані медіа-віджетам (моделлю самою)."""
    out = set()

    def walk(node):
        if isinstance(node, list):
            for it in node:
                walk(it)
            return
        if not isinstance(node, dict):
            return
        if node.get('type') in ('image', 'gallery', 'video', 'audio', 'file'):
            for k in ('src', 'url', 'path', 'poster'):
                v = node.get(k)
                if isinstance(v, str) and v.strip():
                    out.add(v.strip())
            for im in (node.get('images') or []):
                if isinstance(im, dict) and isinstance(im.get('src'), str):
                    out.add(im['src'].strip())
        for v in node.values():
            if isinstance(v, (list, dict)):
                walk(v)

    try:
        walk(widgets)
    except Exception:
        pass
    return out


def agy_media_paths(text, since=None):
    """Шляхи до зображень, які цей хід СТВОРИВ на диску, у порядку згадки.

    Два фільтри, обидва обовʼязкові. Розширення: перетворювати на картинку можна
    лише картинку, тож pdf/txt/код лишаються текстом (інакше кожен звичайний хід
    із правкою коду перетворився б на стос карток-файлів). Час: беремо лише файли,
    молодші за початок ходу, бо «модель ЗГАДАЛА старий скрін» це не те саме, що
    «модель щойно намалювала», і чужу картинку в стрічку тягнути нема за що.
    """
    if not text:
        return []
    from urllib.parse import unquote
    seen, out = set(), []
    for raw in _AGY_MEDIA_RE.findall(text):
        try:
            p = os.path.realpath(os.path.expanduser(unquote(raw)))
        except Exception:
            continue
        if p in seen:
            continue
        seen.add(p)
        try:
            if not os.path.isfile(p):
                continue
            if since is not None and os.path.getmtime(p) < float(since) - AGY_MEDIA_SLACK:
                continue
        except OSError:
            continue
        out.append(p)
        if len(out) >= AGY_MEDIA_MAX:
            break
    return out


def agy_media_block(text, since=None):
    """```chatui```-хвіст із картинками цього ходу, або '' коли їх нема.

    Одна картинка це `image`, кілька це ОДНА `gallery`: стос однакових карток
    підряд читається як збій верстки, а не як результат. Шлях лишаємо сирим,
    таким, як він є на диску: нормалізувати його це робота media_normalize.
    """
    paths = agy_media_paths(text, since)
    if not paths:
        return ''
    # Модель, яка вже сама намалювала image-віджет із цим файлом, зробила роботу
    # за нас. Другий такий самий віджет був би дублем у стрічці.
    try:
        claimed = {os.path.realpath(os.path.expanduser(s))
                   for s in _widget_media_srcs(reply_to_widgets(text))}
    except Exception:
        claimed = set()
    paths = [p for p in paths if p not in claimed]
    if not paths:
        return ''
    if len(paths) == 1:
        w = {'type': 'image', 'src': paths[0], 'title': AGY_MEDIA_TITLE,
             'caption': os.path.basename(paths[0])}
    else:
        w = {'type': 'gallery', 'title': AGY_MEDIA_TITLE, 'cols': 2,
             'images': [{'src': p, 'caption': os.path.basename(p)} for p in paths]}
    return '\n\n```chatui\n' + json.dumps([w], ensure_ascii=False) + '\n```'


def run_agy_stream(prompt, channel):
    """Хід через Antigravity. Повертає (text, result_data, error) рівно тим самим
    контрактом, що й run_claude_stream, тож виклик у process_channel не змінюється.

    Памʼять розмови живе НЕ в нашому session-id, а в conversation_id на боці
    двигуна: перший хід віддає його у відповіді, ми кладемо у
    channels/<id>/agy_conversation і далі ходимо з --conversation."""
    if not AGY_BIN:
        return None, None, 'agy not installed'
    agy_reset_conversation_on_hat_change(channel)
    conv_p = agy_conversation_path(channel)
    conv = ''
    try:
        if os.path.exists(conv_p):
            conv = open(conv_p).read().strip()
    except Exception:
        conv = ''
    first_turn = not conv
    # К4: рівно ОДИН фолбек моделі на хід. Коли попередня спроба впала на «No
    # capacity available for model X», канал лежить у _agy_bare_retry, і ми йдемо
    # БЕЗ --model, щоб двигун узяв власний дефолт. Повторювати тією самою моделлю
    # безнадійно: відмова Google прив'язана саме до неї.
    model_id = ('' if channel in _agy_bare_retry
                else agy_model_for_channel(channel, prompt)['id'] or '')
    body = (agy_first_turn_prefix(current_lang(channel)) + prompt) if first_turn else prompt

    # Паритет із Клодом одним набором прапорців, кожен обґрунтований у блоці
    # «РІШЕННЯ ПРО ДОСТУП» вище: робочий простір це корінь проєкту (--add-dir),
    # інструменти не питають дозволу (headless не вміє питати), пісочниці нема
    # (вона підміняла запис замість того, щоб його заборонити).
    workdir = agy_workdir(channel)
    # --log-file додано свідомо як ЄДИНЕ джерело причини збою: без нього 403 від
    # Google не видно ніде (stderr порожній, стрім каже лише «terminated due to
    # error»), і в лог раннера місяцями їхало 'agy exited 1:' з порожнім хвостом.
    # Файл спорожнюється перед кожним ходом, тобто один на канал і не росте.
    log_file = agy_log_reset(channel)
    # К3: причина 503 лягає в цей файл за секунди, а stdout мовчить усі 600 с до
    # --print-timeout, тому дочитуємо хвіст лога на кожен idle-tick.
    log_watch = agy_log_watch(log_file)
    cmd = [AGY_BIN, '-p', body,
           '--output-format', 'stream-json',
           '--dangerously-skip-permissions',
           '--add-dir', workdir,
           '--print-timeout', f'{AGY_TURN_TIMEOUT}s']
    if log_file:
        cmd += ['--log-file', log_file]
    if model_id:
        cmd += ['--model', model_id]
    if conv:
        cmd += ['--conversation', conv]
    log(f'agy stream ({"new" if first_turn else "resume"}) channel={channel} '
        f'model={model_id or "(дефолт двигуна, без --model)"} '
        f'conv={conv[:8]} prompt={prompt[:60]!r}')

    steps = []
    text = ''             # накопичений стрім, лише для живої смуги (див. final_text)
    final_text = None     # чистий текст із події result, саме він іде в бульбашку
    usage = None          # ГРОШІ: накопичувальна бухгалтерія з події result
    ctx_usage = None      # КОНТЕКСТ: usage останнього кроку agent_response
    live_model = None     # модель, яку двигун НАЗВАВ сам, у події init
    denied = False          # двигун уперся в ЯВНЕ deny-правило (тепер рідкість)
    result_status = ''      # status із події result: SUCCESS | ERROR
    result_error = ''       # error із події result (текст двигуна, не наш)
    step_errors = []        # тексти кроків error_message у порядку появи
    new_conv = conv

    def flush(phase):
        write_live(channel, {'active': True, 'phase': phase,
                             'steps': steps, 'text': text})

    # Env для хука PreInvocation: рівно ця змінна вмикає впорскування контракту.
    # Її не бачить ніхто, крім процесів, які ми самі породили, тому інтерактивні
    # сесії agy самого користувача в цьому ж репозиторії лишаються недоторканими.
    env = _child_env(channel)
    inject_p = write_agy_inject(channel, first_turn)
    if inject_p:
        env['LOGOPSIS_AGY_INJECT'] = inject_p
    # Env для хука PreToolUse (agy_pretool_gate.py): рівно ці дві змінні вмикають
    # гейт дозволів і кажуть йому, в який канал слати картку. Той самий вимикач
    # CHAT_RUNNER_PERMUI=0, що й у Клода: без змінної хук миттєво віддає allow,
    # тобто одна ручка гасить обидві поверхні, а не одну з двох.
    if PERMUI_MODE:
        env['CHAT_PERM_CHANNEL'] = channel
        env['CHAT_PERM_PORT'] = str(PERM_PORT)

    flush('thinking')
    try:
        # stdin ЗАКРИТИЙ (DEVNULL): без цього agy в -p чекає на stdin і висить назавжди.
        proc = subprocess.Popen(
            cmd, cwd=workdir, stdin=subprocess.DEVNULL,
            stdout=subprocess.PIPE, stderr=subprocess.PIPE,
            text=True, bufsize=1, **_PROC_GROUP_KW, env=env,
        )
    except Exception as e:
        return None, None, f'agy spawn failed: {e}'
    write_pid(channel, proc.pid)

    start = time.time()
    try:
        for line in _iter_with_idle(proc):
            if line is _IDLE_TICK:
                if time.time() - start > AGY_TURN_TIMEOUT + 60:
                    proc.kill(); _reap(proc)
                    return None, None, f'agy timeout after {AGY_TURN_TIMEOUT}s'
                if pid_was_stopped(channel, proc.pid):
                    _reap(proc)
                    return text, None, STOP_SENTINEL
                # Стоп від людини перевіряється ВИЩЕ і виграє: якщо натиснули
                # Стоп, хід має піти як зупинений, а не як збій двигуна.
                fatal = agy_log_tail_fatal(log_watch)
                if fatal:
                    log(f'{channel}: agy log caught a fatal after '
                        f'{time.time() - start:.1f}s: {fatal[:160]}')
                    proc.kill(); _reap(proc)
                    return None, None, fatal
                continue
            if pid_was_stopped(channel, proc.pid):
                _reap(proc)
                return text, None, STOP_SENTINEL
            line = line.strip()
            if not line:
                continue
            if not line.startswith('{'):
                # Не-JSON рядок на stdout. Єдиний, який нас цікавить, це вирок про
                # відмову в дозволі. З --dangerously-skip-permissions він майже не
                # трапляється, лишається на явні deny-правила користувача.
                if AGY_STDOUT_DENIED in line:
                    denied = True
                continue
            try:
                ev = json.loads(line)
            except Exception:
                continue
            if ev.get('conversation_id'):
                new_conv = ev['conversation_id']
            kind = ev.get('event')
            if kind == 'init':
                # init несе ПРАВДУ про хід: яку модель двигун реально взяв, у
                # якій теці стоїть, який режим дозволів і скільки інструментів
                # має. Ми її досі викидали і потім здогадувались. Модель звідси
                # іде в лічильник каналу (див. modelUsage нижче), решта в лог:
                # саме за цим рядком видно, чи справді хід поїхав із коренем
                # репозиторію і з відкритими руками, без окремого зонда.
                ini = ev.get('init') or {}
                if isinstance(ini.get('model'), str) and ini['model'].strip():
                    live_model = ini['model'].strip()
                log(f'{channel}: agy init model={live_model or "?"} '
                    f'cwd={ini.get("cwd")!r} perm={ini.get("permission_mode")!r} '
                    f'tools={len(ini.get("tools") or [])}')
                flush('thinking')
                continue
            if kind == 'result':
                # Підсумкова подія несе ПОВНУ відповідь одним шматком. Беремо саме її,
                # а не склеєний стрім: двигун ріже потік по байтах, а не по символах,
                # і кирилична літера, що потрапила на межу двох text_delta, приїжджає
                # зіпсованою з обох боків (перевірено на сирих байтах: слово
                # «сторінка» приїжджало з дірою всередині). Це вада самого CLI,
                # полагодити її на
                # нашому боці неможливо, бо зіпсовані байти вже втрачені в JSON.
                # Стрім лишається рушієм ЖИВОЇ смуги, підсумок бере чистий текст.
                res = ev.get('result')
                if isinstance(res, dict):
                    if isinstance(res.get('usage'), dict):
                        usage = res['usage']
                    if res.get('conversation_id'):
                        new_conv = res['conversation_id']
                    if isinstance(res.get('response'), str) and res['response'].strip():
                        final_text = res['response']
                    # status і error читаємо ТЕПЕР. Досі бралось лише response, і
                    # хід, який приїхав зі status=ERROR, був для нас нерозрізненний
                    # від ходу з порожньою відповіддю.
                    if isinstance(res.get('status'), str):
                        result_status = res['status'].strip().upper()
                    if isinstance(res.get('error'), str) and res['error'].strip():
                        result_error = res['error'].strip()
                elif isinstance(ev.get('usage'), dict):
                    usage = ev['usage']
                continue
            if kind != 'step_update':
                continue
            su = ev.get('step_update') or {}
            if su.get('conversation_id'):
                new_conv = su['conversation_id']
            st = su.get('step_type')
            state = su.get('state')
            if isinstance(su.get('usage'), dict) and st != 'checkpoint':
                # Крок checkpoint несе усадку ВЛАСНОГО службового виклику (зонд:
                # input_tokens=117 при 30410 за хід). Раніше він теж лягав у
                # usage, і його рятувало лише те, що подія result приходить
                # пізніше і перетирає. Варто стріму обірватись після checkpoint,
                # і метр каналу відрапортував би 117 токенів замість тридцяти
                # тисяч. Службові кроки в лічильник ходу не беремо.
                usage = su['usage']
                if st == 'agent_response':
                    # РОЗМІР КОНТЕКСТУ живе ТІЛЬКИ тут. У кроці agent_response
                    # usage описує один модельний виклик: input_tokens це
                    # некешована частка ЙОГО входу, cache_read_tokens кешована,
                    # разом це повний промпт на момент виклику, тобто справжнє
                    # заповнення вікна. Подія result натомість несе АРИФМЕТИЧНУ
                    # СУМУ всіх викликів від створення розмови (замір:
                    # хід 1 agent_response input=19623 -> result input=19623;
                    # хід 2 agent_response input=3614 -> result input=23237,
                    # рівно 19623+3614). Сума росте монотонно і стелі не має,
                    # ділити її на вікно безглуздо. Клод цю саму пастку вже
                    # обходить через last_ctx_usage (runner.py:2629, 3938).
                    ctx_usage = su['usage']
            if st == 'tool':
                name = su.get('tool_name') or 'інструмент'
                done = state in ('DONE', 'ERROR')
                # tool_info читаємо ДО того, як покласти крок, а не після: зонд
                # 2026-09-15 показав, що parameters приходять уже в стані ACTIVE,
                # тобто крок може народитись підписаним. Раніше підпис тут стояв
                # порожній намертво, і смужка показувала стовпчик однакових
                # «Working with files» навіть на здоровому ході (К1).
                info = su.get('tool_info') or {}
                label = _agy_tool_label(name, info)
                for s in steps:
                    if s.get('tool') == name and not s.get('done'):
                        s['done'] = done
                        # Добір підпису на оновленні: якщо якась версія двигуна
                        # віддасть parameters лише в DONE, крок усе одно приїде
                        # підписаним, а не лишиться порожнім назавжди.
                        if label and not s.get('label'):
                            s['label'] = label
                        break
                else:
                    steps.append({'icon': '🔹', 'tool': name, 'label': label, 'done': done})
                if (info.get('error') or {}).get('message', '').find('denied permission') >= 0:
                    denied = True
                flush('tool')
            elif st == 'agent_response':
                d = su.get('text_delta')
                if d:
                    text += d
                    flush('writing')
            elif st == 'error_message':
                # Двигун сам каже, що хід помер. Текст тут буває порожній (у 18
                # заміряних збоях був порожній ЗАВЖДИ), тому кладемо мітку: сам
                # факт кроку це вже причина, якої нам бракувало.
                t = _agy_step_text(su) or AGY_ERROR_STEP_NOTE
                if t not in step_errors:
                    step_errors.append(t)
    except Exception as e:
        try:
            proc.kill()
        except Exception:
            pass
        _reap(proc)
        return None, None, f'agy stream parse failed: {e}'

    if pid_was_stopped(channel, proc.pid):
        _reap(proc)
        return text, None, STOP_SENTINEL

    err_tail = ''
    try:
        err_tail = ((proc.stderr.read() if proc.stderr else '') or '').strip()
    except Exception:
        err_tail = ''
    _reap(proc)
    if AGY_STDOUT_DENIED in err_tail:
        denied = True

    if new_conv and new_conv != conv:
        try:
            os.makedirs(os.path.dirname(conv_p), exist_ok=True)
            with open(conv_p, 'w', encoding='utf-8') as f:
                f.write(new_conv + '\n')
        except Exception as e:
            log(f'{channel}: agy conversation save failed: {e}')

    # Ключі лічильника переназвані під форму, яку читає write_usage: у agy кеш
    # зветься cache_read_tokens, у Клода cache_read_input_tokens. Без перекладу
    # метр каналу мовчки рахував би кеш нулем.
    #
    # thinking_tokens СВІДОМО не додаємо. Перша здогадка була додати їх до
    # вихідних як окремий кошик, живий зонд її спростував: на ході з реальним
    # мисленням прийшло input=22936, output=670, thinking=656, total=23606, а це
    # рівно input + output. Тобто thinking це ЧАСТИНА output_tokens, і сума дала б
    # подвійний рахунок. Лишаємо як є.
    #
    # modelUsage синтезуємо самі. write_usage бере і назву активної моделі, і
    # знаменник метра ВИКЛЮЧНО з modelUsage, а agy такого поля не віддає взагалі.
    # Через це канал на Antigravity показував activeModel = None, а знаменником
    # брав дефолтний CONTEXT_WINDOW. Для gemini-моделей (вікно ~1M) дефолт
    # випадково збігався, а для claude-* через agy він завищений у рази, тобто
    # метр показував умовні 12% там, де контекст уже під стелею. Ключ беремо з
    # події init (те, що двигун НАЗВАВ сам), і лише якщо її не було, з того, що
    # ми просили.
    data = None
    if usage:
        used_model = live_model or model_id or 'antigravity'
        data = {'usage': {'input_tokens': int(usage.get('input_tokens', 0) or 0),
                          'output_tokens': int(usage.get('output_tokens', 0) or 0),
                          'cache_read_input_tokens': int(usage.get('cache_read_tokens', 0) or 0)},
                'modelUsage': {used_model: {'contextWindow': agy_context_window(used_model)}},
                'model': used_model, 'provider': 'antigravity'}
        # Ключ `usage` вище лишається НАКОПИЧУВАЛЬНИМ навмисно: як бухгалтерія
        # витрат за нитку він коректний, з нього рахуються гроші і вихідні
        # токени. Для МЕТРА окремо кладемо contextUsage, і write_usage віддає
        # перевагу саме йому (`cu = data.get('contextUsage') or u`). Ключі
        # переназвані під клодівську форму: у agy кеш зветься cache_read_tokens.
        # Поля cache_creation у agy нема, у формулі це нуль.
        #
        # Кроку agent_response могло не бути взагалі (хід помер на інструменті).
        # Тоді contextUsage не кладемо, і write_usage сама падає у старий
        # запасний шлях: гірше, ніж було, не стає.
        if ctx_usage:
            data['contextUsage'] = {
                'input_tokens': int(ctx_usage.get('input_tokens', 0) or 0),
                'cache_read_input_tokens': int(ctx_usage.get('cache_read_tokens', 0) or 0),
                'cache_creation_input_tokens': 0,
            }
    # Підсумок з події result, стрім лише як запасний варіант (див. коментар вище).
    out = (final_text if final_text is not None else text).strip()
    if not out:
        if denied:
            # Чесна причина замість порожньої бульбашки. Формулювання переписане
            # разом із паритетом: інструменти двигуну ДОЗВОЛЕНІ, тож «йому можна
            # лише текст» стало б брехнею. Сюди тепер веде рівно один сценарій:
            # конкретну дію перерізало явне deny-правило в налаштуваннях agy.
            return None, data, ('agy denied: конкретну дію заблокувало правило '
                                'дозволів самого двигуна, і хід обірвався без '
                                'відповіді')
        cause = _agy_failure_cause(channel, result_status, result_error,
                                   step_errors, err_tail)
        if cause:
            log(f'{channel}: agy failure cause: {cause[:400]}')
        low = cause.lower()
        # 403 перевіряємо ПЕРШИМ: слово 'limit' легко приїжджає хвостом лога, і
        # без цієї умови тимчасова відмова Google вдягала б картку вичерпаного
        # ліміту, тобто чат радив би чекати оновлення там, де треба просто
        # повторити.
        if not _is_agy_transient_error(cause) and (
                'quota' in low or 'limit' in low or '429' in low):
            return None, data, f'agy quota: {cause[:600]}'
        if proc.returncode not in (0, None):
            return None, data, f'agy exited {proc.returncode}: {cause[:600]}'
        if cause:
            return None, data, f'agy failed: {cause[:600]}'
        return None, data, 'agy returned empty reply'
    # Картинку, яку хід намалював на диску, добудовуємо ДО тексту, а не замість
    # нього: пояснення моделі лишається, знизу зʼявляється сама картинка. `start`
    # це мітка початку саме цього ходу, тож чужий старий файл сюди не потрапить.
    media = agy_media_block(out, start)
    if media:
        log(f'{channel}: agy media -> {len(agy_media_paths(out, start))} зображ.')
        out += media
    return out, data, None


def _author_for(provider, channel=None):
    """Підпис автора картки. Відповідь Antigravity не сміє підписуватись Claude:
    Людина має бачити в стрічці, який саме двигун це написав.

    Капелюх каналу перебиває підпис двигуна (К3): у чаті з ментором відповідь
    підписана ЙОГО іменем, бо саме він співрозмовник, а двигун під ним це
    внутрішня деталь. Знявся капелюх, повернувся підпис двигуна: та сама одна
    функція, тому розʼїхатись їм нема де.

    ВИНЯТКУ ДЛЯ ANTIGRAVITY БІЛЬШЕ НЕМА (рішення власника, 2026-08-30). Він стояв тут, поки
    тіло агента до agy фізично не доїжджало: підпис іменем ментора при його
    відсутності в промпті був би брехнею. Тепер персона їде впорскуванням на
    кожен хід (write_agy_inject), тобто в промпті вона Є, і підпис став правдою.
    Порядок правок саме такий і не інакший: спершу доставка, потім підпис."""
    if channel:
        hat = channel_agent(channel)
        if hat:
            return hat['name']
    return 'Antigravity' if provider == 'antigravity' else 'Claude'


def _new_chat_button(label=None, provider='claude', channel=None):
    """Кнопка «почати новий чат на іншому двигуні», яка справді це робить.
    Двигун залочений на час життя чату, тому єдина чесна порада при збої це новий
    чат, а не перемикач. Порада без дії перетворилась би на квест з пʼяти кроків
    (відкрий, знайди, створи, обери, передрукуй питання), тому картка несе саме
    кнопку: фронт ловить action='new-chat', бʼє POST /api/new-chat з цим двигуном
    і перемикає екран на свіжий чат."""
    if label is None:
        label = _bt({'uk': 'Новий чат на Claude', 'en': 'New chat on Claude'}, channel)
    return {'type': 'buttons', 'buttons': [
        {'label': label, 'action': 'new-chat', 'provider': provider, 'variant': 'primary'}]}


def _kyiv_reset_phrase(iso, channel):
    """ISO-момент оновлення ліміту → людська фраза КИЇВСЬКИМ часом, або '' якщо нема чого
    сказати.

    Двигун віддає UTC ('2026-09-12T21:04:20Z'). Покласти цей рядок у картку як є означало б
    назвати людині чужий час, який розходиться з годинником на її стіні: 21:04Z це 00:04 у
    Києві, тобто не просто інша година, а інша ДОБА. Тому і «сьогодні» з «завтра» рахуємо
    теж у Києві, інакше опівнічний ліміт називався б учорашнім.

    Час у минулому повертає '': або стіни вже нема, або значення протухло, і в обох
    випадках чесніше впасти на розмите формулювання, ніж назвати момент, який минув."""
    if not iso:
        return ''
    try:
        from datetime import timezone
        from zoneinfo import ZoneInfo
        t = datetime.fromisoformat(str(iso).replace('Z', '+00:00'))
        if t.tzinfo is None:
            t = t.replace(tzinfo=timezone.utc)
        kyiv = ZoneInfo('Europe/Kyiv')
        t = t.astimezone(kyiv)
        now = datetime.now(kyiv)
    except Exception:
        return ''
    if t <= now:
        return ''
    hhmm = t.strftime('%H:%M')
    days = (t.date() - now.date()).days
    if days <= 0:
        when = {'uk': f'сьогодні о {hhmm}', 'en': f'today at {hhmm}'}
    elif days == 1:
        when = {'uk': f'завтра о {hhmm}', 'en': f'tomorrow at {hhmm}'}
    else:
        dm = t.strftime('%d.%m')
        when = {'uk': f'{dm} о {hhmm}', 'en': f'on {dm} at {hhmm}'}
    return _bt({'uk': f' Оновиться {when["uk"]} за київським часом.',
                'en': f' Resets {when["en"]} (Kyiv time).'}, channel)


def agy_error_widgets(err, channel):
    """Людська картка замість технічного тексту. Двигун вичерпав денний ліміт,
    уперся в заборону діяти на диску або відвалився: у всіх трьох випадках людина
    має бачити пояснення і що робити далі, а не мовчазну порожню бульбашку.

    Двигун чату НЕЗМІННИЙ (рішення власника, 2026-08-03), тому жодна гілка більше не радить
    «перемкни двигун у налаштуваннях»: така порада стала б брехнею і завела б
    у глухий кут рівно в найгіршу хвилину. Вихід тепер один і він чесний:
    почати новий чат на іншому двигуні, одним кліком просто з картки."""
    low = (err or '').lower()
    # 403 стоїть ПЕРЕД усіма іншими гілками свідомо. Слово 'denied' сидить
    # усередині PERMISSION_DENIED, а 'limit' легко приїжджає хвостом лога, тож
    # будь-який інший порядок дав би людині впевнену брехню про причину: «одну
    # дію заблокувала заборона» там, де Google просто тимчасово відмовив усьому
    # двигуну.
    if _is_agy_transient_error(err):
        return [{'type': 'callout', 'variant': 'warning',
                 'title': _bt({'uk': 'Google тимчасово відмовив двигуну',
                               'en': 'Google temporarily refused the engine'}, channel),
                 'text': _bt({
                     'uk': 'Сервіс Google відповів відмовою з кодом 403, тому хід не '
                           'відбувся. Це не твій ліміт і не поламаний чат: така '
                           'відмова приходить вікнами по 15-20 хвилин і минає сама. '
                           'Запит уже поїхав тричі поспіль, тож спробуй ще раз за '
                           'кілька хвилин. Якщо відповідь потрібна просто зараз, '
                           'почни новий чат на Claude.',
                     'en': 'The Google service refused with a 403 code, so the turn did '
                           'not go through. It is not your limit and not a broken chat: '
                           'this kind of refusal comes in 15-20 minute windows and clears '
                           'up on its own. The request already went three times in a row, '
                           'so try again in a few minutes. If you need an answer right now, '
                           'start a new chat on Claude.',
                 }, channel)},
                _new_chat_button(channel=channel)]
    if 'quota' in low or 'limit' in low or '429' in low:
        reset, reset_at = '', ''
        try:
            import urllib.request
            with urllib.request.urlopen(
                    f'http://127.0.0.1:{os.environ.get("CHAT_PORT", "5555")}'
                    '/api/connect/antigravity/status', timeout=20) as r:
                st = json.loads(r.read().decode()) or {}
            reset = st.get('quota_resets_in') or ''
            reset_at = st.get('quota_reset_at') or ''
        except Exception:
            reset, reset_at = '', ''
        # Сходинки навмисне саме в такому порядку: точний момент з лічильника квоти,
        # потім стара розмита фраза з тексту помилки, і лише тоді «найближчим часом».
        # Кожна наступна знає менше за попередню, тому падаємо на неї тільки коли та
        # справді порожня.
        tail = _kyiv_reset_phrase(reset_at, channel)
        if not tail:
            tail = (_bt({'uk': f' Оновиться {reset}.', 'en': f' Resets {reset}.'}, channel)
                    if reset else
                    _bt({'uk': ' Оновиться найближчим часом.', 'en': ' Resets soon.'}, channel))
        return [{'type': 'callout', 'variant': 'warning',
                 'title': _bt({'uk': 'Ліміт Antigravity на сьогодні вичерпано',
                               'en': 'Antigravity limit used up for today'}, channel),
                 'text': _bt({
                     'uk': 'Цей двигун більше не приймає запити до оновлення ліміту.',
                     'en': 'This engine no longer accepts requests until the limit resets.',
                 }, channel) + tail + _bt({
                     'uk': ' Цей чат живе на Antigravity і чекатиме разом з ним. '
                           'Якщо питання термінове, почни новий чат на Claude і постав '
                           'його там.',
                     'en': ' This chat lives on Antigravity and will wait along with it. '
                           'If the question is urgent, start a new chat on Claude and ask '
                           'it there.',
                 }, channel)},
                _new_chat_button(channel=channel)]
    if 'denied' in low:
        # Двигун МАЄ руки (той самий корінь проєкту і ті самі інструменти, що в
        # Claude), тому стара порада «переформулюй, щоб відповіддю був текст»
        # більше не звучить: вона описувала скасований режим. Лишилась одна чесна
        # причина: конкретну дію відрізало власне правило заборони двигуна.
        return [{'type': 'callout', 'variant': 'warning',
                 'title': _bt({'uk': 'Одну дію заблокувала заборона',
                               'en': 'A rule blocked one action'}, channel),
                 'text': _bt({
                     'uk': 'Двигун узявся за роботу, але саме цю дію не пропустило '
                           'його власне правило заборони, тому відповіді не вийшло. '
                           'Спробуй ще раз або іншим шляхом. Якщо впирається щоразу, '
                           'ту саму роботу зробить Claude у новому чаті.',
                     'en': 'The engine started the work, but its own denial rule blocked '
                           'this specific action, so there was no reply. Try again or a '
                           'different way. If it keeps blocking, Claude will do the same '
                           'work in a new chat.',
                 }, channel)},
                _new_chat_button(channel=channel)]
    if 'not installed' in low:
        return [{'type': 'callout', 'variant': 'warning',
                 'title': _bt({'uk': 'Antigravity не підключений',
                               'en': 'Antigravity is not connected'}, channel),
                 'text': _bt({
                     'uk': 'Двигун не знайдено на цьому компʼютері, а цей чат створений '
                           'саме на ньому. Підключи його в Налаштуваннях, і чат оживе. '
                           'Або почни новий чат на Claude, якщо чекати не хочеться.',
                     'en': 'The engine was not found on this computer, and this chat was '
                           'created on it specifically. Connect it in Settings and the chat '
                           'comes back to life. Or start a new chat on Claude if you do not '
                           'want to wait.',
                 }, channel)},
                _new_chat_button(channel=channel)]
    return [{'type': 'callout', 'variant': 'danger',
             'title': _bt({'uk': 'Antigravity не відповів', 'en': 'Antigravity did not respond'}, channel),
             'text': _bt({
                 'uk': 'Хід не вдався. Спробуй ще раз: збій міг бути разовий. Якщо '
                       'повториться, постав те саме питання у новому чаті на Claude.',
                 'en': 'The turn failed. Try again: it might have been a one-off glitch. '
                       'If it keeps happening, ask the same question in a new chat on Claude.',
             }, channel)},
            _new_chat_button(channel=channel)]


def channel_provider(channel):
    """Двигун каналу: 'claude' (дефолт) | 'antigravity'. Читається ЖИВО щоходу, як
    _sdk_enabled, тож перемикач у поповері діє без рестарту сервера. Файл
    навмисно `provider`, а не `engine`: `engine` вже зайнятий під opt-in на
    SDK-двигун Клода, і спільний файл злив би два різні перемикачі в один."""
    try:
        p = os.path.join(CHANNELS_DIR, channel, 'provider')
        if os.path.exists(p):
            v = open(p).read().strip().lower()
            if v in ('claude', 'antigravity'):
                return v
    except Exception:
        pass
    return 'claude'


# ── Капелюх каналу: агент як УЧАСНИК розмови ────────────────────────────────
# Хід іде ЗВИЧАЙНИМ шляхом (стрім, жива бульбашка, віджети, план), а тіло файлу
# агента підмішується в системний промпт цього каналу і ЗАМІНЮЄ роль
# оркестратора з CLAUDE.md. Спавну процесу на повідомлення тут нема свідомо: він
# коштував би стрім, живу бульбашку і памʼять розмови, а віддав би стрічку
# звітних карток (див. не-цілі спеки specs/agent-in-chat).
#
# Читається ЖИВО щоходу, як channel_provider: капелюх вдягають і знімають без
# рестарту, і саме тому наступне повідомлення вже їде в новій ролі.

def channel_participant_slugs(channel):
    """Слаги учасників каналу в порядку показу, [] коли нікого.

    Один рядок у файлі це рівно фаза 1, два і більше це кімната (фаза 2,
    specs/agent-room). Розбір спільний з сервером (agent_room.read_slugs), і це
    принципово: сервер вирішує, ХТО відповідає, раннер вдягає рівно того ж, а
    два власні парсери одного файлу гарантовано розійшлись би."""
    try:
        return agent_room.read_slugs(os.path.join(CHANNELS_DIR, channel))
    except Exception:
        return []


def _channel_agent_slug(channel):
    """Слаг того, хто говорить у ЦЬОМУ ході, '' коли ніхто.

    Нуль учасників -> ''. Один -> він (фаза 1, без жодних умов).
    Кімната -> учасник зі знімка меседжа (сервер обрав його на момент
    відправки: явна адресація або роутер). Знімка нема (службовий хід,
    стиснення контексту, старий файл черги) -> перший у кімнаті: відповісти
    мусить хтось, і сталий вибір чесніший за випадковий."""
    parts = channel_participant_slugs(channel)
    if not parts:
        return ''
    if len(parts) == 1:
        return parts[0]
    speaker = job_runtime(channel).get('speaker')
    return speaker if speaker in parts else parts[0]


def _split_frontmatter(text):
    """(dict фронтматера, тіло). Свій мінімальний парсер, бо runner.py не тягне
    pip-залежностей і не імпортує server.py (той при імпорті чіпає порт). Нам
    треба рівно три поля: name, skills і ТІЛО, тобто сам промпт агента."""
    fm, body = {}, text
    if text.startswith('---'):
        end = text[3:].find('\n---')
        if end != -1:
            block = text[3:3 + end]
            body = text[3 + end:].split('\n', 1)[-1] if '\n' in text[3 + end:] else ''
            for line in block.splitlines():
                if not line.strip() or line[:1] in (' ', '\t') or ':' not in line:
                    continue
                k, v = line.split(':', 1)
                v = v.strip()
                if len(v) >= 2 and v[0] in '"\'' and v[-1] == v[0]:
                    v = v[1:-1]
                fm[k.strip()] = v
    return fm, body


def channel_agent(channel):
    """Хто говорить у цьому ході, як {slug, name, skills, body}, або None.

    Слаг, тіла якого вже нема на диску, читається як «капелюха нема»: краще
    чесно повернути канал до звичайного, ніж підписувати відповіді іменем,
    промпту якого ніхто не підмішує.

    Фаза 2 не змінила ЖОДНОГО місця виклику цієї функції, і це головне її
    рішення: капелюх, підпис бульбашки і звуження інструментів так само питають
    «хто тут агент», просто у кімнаті відповідь тепер залежить від меседжа
    (див. _channel_agent_slug), а не лише від каналу."""
    slug = _channel_agent_slug(channel)
    if not slug:
        return None
    fp = os.path.join(REPO_ROOT, '.claude', 'agents', slug + '.md')
    try:
        with open(fp, encoding='utf-8') as f:
            fm, body = _split_frontmatter(f.read())
    except Exception:
        return None
    raw = (fm.get('skills') or '').strip()
    if raw[:1] == '[' and raw[-1:] == ']':
        raw = raw[1:-1]
    skills = []
    for part in raw.split(','):
        s = part.strip().strip('"\'').strip()
        if s and s not in skills:
            skills.append(s)
    return {'slug': slug, 'name': fm.get('name') or slug,
            'skills': skills, 'body': body.strip()}


# Рамка капелюха. Ключове слово тут REPLACES: правила проєкту роблять асистента
# оркестратором, який усе делегує, а капелюх робить його ментором. Нашарувати їх
# одне на одне означало б дві особистості в кожній відповіді (ризик №1 спеки),
# тому роль ЗАМІНЮЄТЬСЯ. Стандарт подачі (віджети, ```plan```, українська) при
# цьому лишається: це ФОРМА чату, а не роль співрозмовника, і без неї агент
# писав би у віджетний чат стіною тексту.
# Текст рамки живе у секції `hat` файлу правил; тут лишився тільки порожній рядок
# перед тілом персони.
def _hat_head():
    return rules_store.section(DIR, 'hat') + '\n\n'


_LAZY['_HAT_HEAD'] = _hat_head       # див. __getattr__ вище


# Мовний хвіст капелюха (specs/i18n-interface, К11 поширений на шар «учасник»,
# латання оберту 2, "Ревізор 3: ламає навмисно"). Заводський текст секції hat
# (rules.default.md, пункт b) каже "write in Ukrainian, no em-dash" БЕЗУМОВНО, і
# оскільки шар «учасник» найближчий до розмови (rules_store.LAYERS), ця фраза
# перемагала правильну "Reply in English" з шару «застосунок» для БУДЬ-ЯКОГО
# каналу з персоною, живий доказ на chat-213 (Макс — PM) у звіті ревізора.
# Заводський текст СВІДОМО не чіпаємо: на ньому стоять golden-hash тести
# test_rules_layer.py (BLOCKS/FROZEN), і зміна морфології всередині секції зламала
# б байтову рівність з git-переїздом, а не просто виросла б у кінець (як GROWN
# дозволяє для 'chat'). Натомість додаємо код-рівневий хвіст ЩЕ БЛИЖЧЕ до розмови
# (за тілом персони і за приміткою про skills), який явно скасовує саме ту одну
# фразу для не-української мови, тим самим принципом, що й _CHAT_TAIL_INSTRUCTION/
# _AGENT_CATALOG_TAIL. НЕ через _lang_text: порожній рядок для 'uk' там впав би на
# 'en'-гілку через `or` (chunks.get(lang) or chunks['en']), тобто мовчки повернув
# би override і для української, рівно та регресія, якої треба уникнути.
_HAT_LANG_OVERRIDE_EN = (
    '\n\nLANGUAGE NOTE (overrides the sentence above): "write in Ukrainian, no '
    'em-dash" is the Ukrainian-interface default and does not apply here. The '
    'user selected English as the interface language, reply in English, and the '
    'em-dash ban does not apply in English.'
)


def _hat_section(channel, lang=None):
    """Блок капелюха для системного промпту, '' коли капелюха нема. Тіло агента
    беремо ЯК Є з .claude/agents/: файли агентів ми не переписуємо (не-ціль).

    lang за замовчуванням current_lang(channel), той самий знімок, що й шар
    «застосунок»; явний параметр лише для викликів, де знімок уже порахований і
    повторне читання файлу/черги зайве (_layer_texts рахує один раз на обидва)."""
    hat = channel_agent(channel)
    if not hat or not hat['body']:
        return ''
    if lang is None:
        lang = current_lang(channel)
    tail = ''
    if not hat['skills']:
        # Ментор без оголошених помічників не має отримати каталог «раз уже під
        # рукою»: критерій К7 вимагає рівно те, що в файлі, і нічого понад.
        tail = ('\n\n(No helper skills are declared for this persona, so you '
                'have none available here. Do not offer to run any.)')
    else:
        tail = ('\n\n(The ONLY helper skills available to you here are: '
                + ', '.join(hat['skills']) + '. Nothing else from the catalogue.)')
    note = '' if lang == 'uk' else _HAT_LANG_OVERRIDE_EN
    return '\n\n' + _hat_head() + hat['body'] + tail + note + '\n'


def channel_disallowed_tools(channel):
    """DISALLOWED_TOOLS плюс те, що звужує капелюх каналу (К7).

    Персона без оголошених `skills:` не отримує інструмент Skill ВЗАГАЛІ: це
    єдине жорстке, а не прохальне звуження, яке рантайм дає нам сьогодні. Для
    персони з частковим списком вибірковий allow робить PreToolUse-хук
    hooks/skill-gate.cjs, бо --disallowedTools вміє імена, а не окремі скіли."""
    base = list(DISALLOWED_TOOLS)
    hat = channel_agent(channel)
    if hat and not hat['skills'] and 'Skill' not in base:
        base.append('Skill')
    return base


def _warm_get(channel, session_id, prompt):
    """Return a LIVE persistent claude (stream-json in+out) for this channel,
    spawning/respawning if missing, dead, or bound to a different (rotated) sid.
    Caller must hold _warm_lock. Drains stderr in a daemon thread so the pipe
    never fills and deadlocks the long-lived process. `prompt` is the current
    user turn text, used to resolve an 'auto' channel model per turn complexity
    (same as the stream/SDK branches); without it channel_model(auto) NameErrors."""
    from collections import deque
    want_model = channel_model(channel, prompt)
    e = _warm.get(channel)
    if e is not None:
        proc = e['proc']
        # Модель зашита в аргументи спавну (--model), на льоту її не змінити. Тому
        # теплий процес, піднятий під ІНШОЮ моделлю, перевикористати не можна: саме
        # так меседж зі знімком «opus» тихо їхав би Сонетом. Порівнюємо з тим, що
        # процес НАСПРАВДІ отримав при спавні (e['model']).
        same_model = e.get('model') in (None, want_model)
        if proc.poll() is None and e['sid'] == session_id and same_model:
            return e
        if not same_model:
            log(f'{channel}: warm engine model {e.get("model")} != {want_model} '
                f'— respawning for this message')
        # dead, session rotated (compaction), or a different model: tear it down.
        try:
            if proc.poll() is None:
                proc.kill()
        except Exception:
            pass
        _warm.pop(channel, None)
    model = want_model
    perm = channel_permission(channel)
    resume = session_jsonl_exists(session_id)
    cmd = [CLAUDE_BIN, '-p',
           '--input-format', 'stream-json',
           '--output-format', 'stream-json', '--verbose',
           '--include-partial-messages',
           *_resolve_model_args(model),
           '--append-system-prompt', _sys_prompt(channel, session_id),
           '--disallowedTools', *channel_disallowed_tools(channel),
           '--permission-mode', perm]
    cmd += _resume_or_seed_args(channel, session_id)
    spawn_env = _child_env(channel)
    _settings = _perm_settings_arg()
    if _settings:
        # ONE --settings for both hooks: the flag cannot be repeated, and a second
        # occurrence would silently win over the first.
        cmd += ['--settings', _settings]
        spawn_env['CHAT_PERM_CHANNEL'] = channel
        spawn_env['CHAT_PERM_PORT'] = str(PERM_PORT)
        # The bridge router prints a ready-to-run command; without the live port it
        # would print 5555, which is wrong in a packaged app (the port is auto-picked).
        spawn_env['LOGOPSIS_PORT'] = str(PERM_PORT)
        # Ensure the gate hook (and any node-based tool subprocess) can find node
        # even when launchd gave us a stripped PATH.
        _nd = os.path.dirname(NODE_BIN)
        if _nd and _nd not in spawn_env.get('PATH', ''):
            spawn_env['PATH'] = _nd + os.pathsep + spawn_env.get('PATH', '')
    log(f'{channel}: claude WARM spawn ({"resume" if resume else "new"}) '
        f'sid={session_id[:8]} model={model} perm={perm} permui={PERMUI_MODE}')
    proc = subprocess.Popen(
        cmd, cwd=REPO_ROOT, stdin=subprocess.PIPE,
        stdout=subprocess.PIPE, stderr=subprocess.PIPE,
        text=True, bufsize=1, **_PROC_GROUP_KW, env=spawn_env)
    buf = deque(maxlen=300)
    _errlog = os.path.join(CHANNELS_DIR, channel, 'claude-stderr.log')
    def _drain():
        try:
            for ln in proc.stderr:
                buf.append(ln)
                try:                       # DEBUG: mirror claude stderr to a file so a
                    with open(_errlog, 'a', encoding='utf-8') as _fh:   # wedged/dying
                        _fh.write(ln)      # turn is diagnosable in the desktop build.
                except Exception:
                    pass
        except Exception:
            pass
    threading.Thread(target=_drain, daemon=True).start()
    # ONE persistent stdout reader for the LIFETIME of this warm process, pushing
    # every line onto a shared Queue. All turns of this process drain the SAME
    # queue, so no line is ever lost between turns (a per-turn reader thread would
    # leak across the result-boundary `break` and steal the next turn's first
    # line). The turn loop reads with a timeout to detect idle/wedged turns; on
    # EOF the reader pushes None so a dead process is noticed.
    import queue as _queue
    stdout_q = _queue.Queue()
    def _read_stdout():
        try:
            for ln in proc.stdout:
                stdout_q.put(ln)
        except Exception:
            pass
        finally:
            stdout_q.put(None)
    threading.Thread(target=_read_stdout, daemon=True).start()
    # `model` фіксуємо разом із процесом: наступний меседж може приїхати зі своїм
    # знімком, і порівняти його буде з чим (див. початок цієї функції).
    e = {'proc': proc, 'sid': session_id, 'stderr': buf, 'stdout_q': stdout_q,
         'model': model}
    _warm[channel] = e
    return e


def run_claude_warm(prompt, session_id, channel):
    """Warm-session turn (CHAT_RUNNER_WARM=1): feed the prompt to a PERSISTENT
    claude over stdin and read its stream-json events until this turn's `result`,
    leaving the process ALIVE for the next turn (no cold start). Same return
    contract as run_claude_stream: (text, result_data, error). On stop/timeout/
    crash the warm proc is torn down; the next turn respawns and --resume restores
    full context from claude's own session .jsonl, so nothing is lost."""
    with _warm_lock:
        try:
            e = _warm_get(channel, session_id, prompt)
        except Exception as ex:
            return None, None, f'warm spawn failed: {ex}'
    proc = e['proc']
    write_pid(channel, proc.pid)
    # Send the user turn as a stream-json user message line.
    try:
        msg = json.dumps({'type': 'user', 'message': {'role': 'user',
              'content': [{'type': 'text', 'text': prompt}]}}, ensure_ascii=False)
        proc.stdin.write(msg + '\n')
        proc.stdin.flush()
    except Exception as ex:
        with _warm_lock:
            _warm.pop(channel, None)
        try:
            proc.kill()
        except Exception:
            pass
        return None, None, f'warm stdin write failed: {ex}'

    steps = []
    text = ''
    cur_block = None
    result_data = None
    final_text = None
    last_ctx_usage = None  # last assistant message's usage = true context size
    turn_model = None      # `model` останнього assistant-повідомлення, див. _turn_model

    def flush(phase):
        write_live(channel, {'active': True, 'phase': phase,
                             'steps': steps, 'text': text})

    def _drop_warm():
        with _warm_lock:
            if _warm.get(channel) is e:
                _warm.pop(channel, None)
        try:
            proc.kill()
        except Exception:
            pass

    import queue as _queue
    stdout_q = e['stdout_q']   # ONE persistent reader for the warm proc lifetime
    proc_eof = False
    flush('thinking')
    start = time.time()
    last_activity = start   # reset on EVERY line from claude (any sign of life)
    try:
        while True:
            try:
                line = stdout_q.get(timeout=IDLE_TICK)
            except _queue.Empty:
                # watchdog tick: no new output. Check ONLY the absolute backstop
                # and the user's Стоп. NO idle auto-abort anymore: a long, silent
                # turn (deep think / long tool) keeps running under the Стоп button.
                now = time.time()
                if now - last_activity > IDLE_TIMEOUT:
                    # Calm "still working" UI signal, NOT a kill. Keep the warm proc
                    # alive and the streamed text + steps intact.
                    write_live(channel, {'active': True, 'phase': 'thinking',
                                         'steps': steps, 'text': text,
                                         'longRunning': True})
                if now - start > TURN_TIMEOUT:
                    _drop_warm(); _reap(proc)
                    return None, None, f'timeout after {TURN_TIMEOUT}s'
                if pid_was_stopped(channel, proc.pid):
                    _drop_warm(); _reap(proc)
                    return text, result_data, STOP_SENTINEL
                continue
            if line is None:
                proc_eof = True   # reader hit EOF -> process died
                break
            last_activity = time.time()   # got real output -> reset idle clock
            # External stop: carry the streamed-so-far text so the partial stays.
            if pid_was_stopped(channel, proc.pid):
                _drop_warm(); _reap(proc)
                return text, result_data, STOP_SENTINEL
            line = line.strip()
            if not line:
                continue
            try:
                ev = json.loads(line)
            except Exception:
                continue
            t = ev.get('type')

            if t == 'stream_event':
                inner = ev.get('event', {}) or {}
                et = inner.get('type')
                if et == 'content_block_start':
                    cb = inner.get('content_block', {}) or {}
                    cur_block = cb.get('type')
                    if cur_block == 'tool_use':
                        name = cb.get('name', '')
                        steps.append({'icon': _tool_icon(name), 'tool': name,
                                      'label': '', 'done': False})
                        flush('tool')
                elif et == 'content_block_delta':
                    d = inner.get('delta', {}) or {}
                    if d.get('type') == 'text_delta' and d.get('text'):
                        text += d['text']
                        flush('writing')
                elif et == 'content_block_stop':
                    cur_block = None

            elif t == 'assistant':
                _mu = (ev.get('message', {}) or {}).get('usage')
                if _mu:
                    last_ctx_usage = _mu
                if (ev.get('message', {}) or {}).get('model') not in (None, '', '<synthetic>'):
                    turn_model = ev['message']['model']
                for b in (ev.get('message', {}) or {}).get('content', []):
                    if b.get('type') == 'tool_use':
                        name = b.get('name', '')
                        label = _tool_label(name, b.get('input'))
                        slot = next((s for s in reversed(steps)
                                     if s['tool'] == name and not s['label']
                                     and not s['done']), None)
                        if slot:
                            slot['label'] = label
                        else:
                            slot = {'icon': _tool_icon(name), 'tool': name,
                                     'label': label, 'done': False}
                            steps.append(slot)
                        if name == 'Skill':
                            # Helper Invoked (К7), як у холодному парсері вище.
                            slot['helper'] = (b.get('input') or {}).get('skill')
                        flush('tool')

            elif t == 'user':
                slot = next((s for s in steps if not s['done']), None)
                if slot:
                    slot['done'] = True
                    if slot.get('tool') == 'Skill':
                        _tr = next((bl for bl in
                                    (ev.get('message', {}) or {}).get('content', []) or []
                                    if isinstance(bl, dict) and bl.get('type') == 'tool_result'),
                                   None)
                        telemetry.get(DIR).track('Helper Invoked', {
                            'helper_name': _telemetry_safe_helper_name(slot.get('helper')),
                            'outcome': _telemetry_tool_outcome(
                                _tr.get('is_error') if _tr else None),
                        })
                    flush('tool')

            elif t == 'result':
                result_data = ev
                if last_ctx_usage:
                    ev['contextUsage'] = last_ctx_usage
                if turn_model:
                    ev['turnModel'] = turn_model
                if ev.get('is_error'):
                    err = ev.get('result') or 'unknown error'
                    # A turn error does NOT necessarily kill the process; but to be
                    # safe (avoid a wedged session) drop it so the next turn resumes.
                    _drop_warm()
                    return None, ev, f'claude error: {err}'
                final_text = (ev.get('result') or '').strip()
                break   # turn boundary: keep the process ALIVE for the next turn
        if proc_eof:
            # stdout reached EOF -> the persistent process died. If /api/stop already
            # removed our pid file, this EOF IS the stop (server SIGKILLed the warm
            # proc): report STOP_SENTINEL, NOT a transient "stdout closed" error.
            # Otherwise the drain loop treats 'stdout closed' as transient, RETRIES,
            # respawns warm and re-runs the same prompt, i.e. the turn "continues"
            # right after Stop. That was the intermittent "зупиняє і продовжує" bug.
            if pid_was_stopped(channel, proc.pid):
                _drop_warm()
                return text, result_data, STOP_SENTINEL
            tail = (''.join(e['stderr']) or '').strip()[-400:]
            _drop_warm()
            if final_text is None:
                return None, result_data, f'warm process ended: {tail or "stdout closed"}'
    except Exception as ex:
        if pid_was_stopped(channel, proc.pid):
            _drop_warm(); _reap(proc)
            return text, result_data, STOP_SENTINEL
        _drop_warm()
        return None, result_data, f'warm stream failed: {ex}'

    out = final_text if final_text is not None else text.strip()
    return out, result_data, None


def project_map_path(channel):
    """Frozen ecosystem snapshot for one conversation: {sid, map}. Lives beside the
    channel's other markers. Name deliberately starts with a letter: the message feed
    globs '[0-9]*.json', so this file can never be mistaken for a message."""
    return os.path.join(CHANNELS_DIR, channel, 'project-map.json')


# Статичний каркас блоку мовно залежний (specs/i18n-interface, К11/К12), заповнювані
# {}-поля лишаються цифрами і назвами каналів/канв/помічників без перекладу: це
# вміст користувача (спека, розділ 2, не-цілі), а не текст самого застосунку.
_PROJECT_MAP_TEMPLATE = {
    'uk': (
        '\n\n[Logopsis екосистема цього проєкту. Ти не один: ось що поруч, '
        'ти знаєш про це і можеш діяти]\n'
        'Канви ({cv_n}): {cv_s}.\n'
        'Чати ({ch_n}): {ch_s}.\n'
        'Помічники: встановлено {hp_n} ({inst}); '
        'каталог {cat_local} локальних + {cat_remote} зовнішніх.\n'
        'Коли користувач згадує канву, сторінку, помічника чи інший чат, ти '
        'знаєш що воно існує. Свіжий стан + як діяти (додати на канву, '
        'поставити помічника) у відповіді: GET /api/project-state.'
    ),
    'en': (
        "\n\n[This project's Logopsis ecosystem. You are not alone: here is "
        'what is nearby, you know about it and can act on it]\n'
        'Canvases ({cv_n}): {cv_s}.\n'
        'Chats ({ch_n}): {ch_s}.\n'
        'Helpers: {hp_n} installed ({inst}); '
        'catalog {cat_local} local + {cat_remote} external.\n'
        'When the user mentions a canvas, a page, a helper, or another chat, '
        'you know it exists. Fresh state plus how to act (add to canvas, '
        'install a helper): GET /api/project-state.'
    ),
}


def _project_map_build(lang=DEFAULT_LANG):
    """Render the CURRENT ecosystem (canvas pages, helpers, other chats) as one prompt
    block. Never raises. Returns '' on any error so awareness can never break a turn.

    Дірка оберту 3 (Ревізор 2, «живий застосунок очима»): цей блок лишався 100%
    українським у КОЖНОМУ ході, незалежно від обраної мови, попри те що решта шести
    шматків промпту Ф1 вже стали мовно залежні (176 кириличних слів на хід, сьоме і
    останнє джерело кирилиці в англійському промпті, поза шістьма місцями спеки).
    Статичний каркас тепер іде через _lang_text, тим самим механізмом, що й решта
    Ф1 (specs/engine-reply-language, К11/К12)."""
    try:
        import project_state
        st = project_state.build_project_state(DIR, REPO_ROOT)
        cv, ch, hp = st['canvases'], st['chats'], st['helpers']
        cv_s = ', '.join(f"{c['title']} ({c['id']})" for c in cv[:40])
        ch_s = ', '.join(c['label'] for c in ch[:40])
        inst = ', '.join(hp['installed'][:20])
        cat = hp.get('catalog', {})
        return _lang_text(_PROJECT_MAP_TEMPLATE, lang).format(
            cv_n=len(cv), cv_s=cv_s, ch_n=len(ch), ch_s=ch_s,
            hp_n=len(hp['installed']), inst=inst,
            cat_local=cat.get('local', 0), cat_remote=cat.get('remote', 0),
        )
    except Exception:
        return ''


def _project_map(channel, session_id=None, lang=DEFAULT_LANG):
    """Phase B awareness, FROZEN per (channel, session, lang).

    Це не мікро-оптимізація, а найдорожча стаття рахунку. Ми сидимо на ПІДПИСЦІ, де
    5-годинний ліміт списується за cache CREATE за повним тарифом, а cache READ майже
    не рахується: заміряний теплий хід у cc-7f2413 це cacheRead 187554 при cacheCreate
    931. Збіг префікса точний по байтах, шари йдуть tools -> system -> messages, тож
    один змінений байт у системному шарі перераховує ВСЕ нижче і перетворює хід на 931
    токен у хід на ~188k. Раніше цей блок збирався живцем на кожному спавні і містив
    рядок «Чати (N): ...» з реальними назвами, тому створення чи перейменування
    БУДЬ-ЯКОГО каналу переписувало системний шар КОЖНОЇ іншої розмови.

    Знімок морозиться на диску (переживає рестарт раннера) і оновлюється рівно тоді,
    коли префікс і так перебудовується, тобто безкоштовно:
      - ротація сесії (компакція / нова сесія) -> інший sid,
      - recycle_channel («хард рефреш», зміна моделі) -> файл видаляється.
    Свіжий стан між цими точками модель бере на вимогу через GET /api/project-state,
    на що прямо вказує сам текст блоку.

    Ніколи не рейзить: будь-яка помилка вироджується у попередній знімок або в ''.
    Порожній результат НЕ кешується, щоб разова похибка агрегатора не заморозила
    порожню обізнаність на всю сесію.
    """
    path = project_map_path(channel)
    cached, cached_sid, cached_lang = None, None, None
    try:
        with open(path, encoding='utf-8') as f:
            blob = json.load(f)
        if isinstance(blob, dict) and isinstance(blob.get('map'), str):
            cached, cached_sid = blob['map'], blob.get('sid')
            cached_lang = blob.get('lang')
    except Exception:
        pass
    # `lang` бере участь у ключі кешу так само, як `sid`: інакше перемикання мови
    # ПОСЕРЕД тієї самої сесії й далі віддавало б заморожений текст старою мовою
    # (та сама помилка, від якої К11/К12 уже застерігають решту шести шматків).
    if (cached is not None and (session_id is None or cached_sid == session_id)
            and cached_lang == lang):
        return cached
    fresh = _project_map_build(lang)
    if not fresh:
        return cached or ''
    try:
        os.makedirs(os.path.dirname(path), exist_ok=True)
        tmp = path + '.tmp'
        with open(tmp, 'w', encoding='utf-8') as f:
            json.dump({'sid': session_id, 'lang': lang, 'map': fresh}, f, ensure_ascii=False)
        os.replace(tmp, path)
    except Exception:
        pass
    return fresh


# ---- Дзеркало тону (як говорить користувач) --------------------------------
# Профілі пише Stop-хук hooks/tone-learn.cjs, читаючи ЙОГО повідомлення з історії
# каналів. Раннер нічого не вчить, він лише перекладає готові дані в секцію промпту.
# Такий поділ навмисний: навчання не сміє коштувати часу ходу, а промпт не сміє
# залежати від того, чи хук устиг відпрацювати.
TONE_DIR = os.environ.get('LOGOPSIS_TONE_DIR') or os.path.join(REPO_ROOT, 'work')
TONE_MIN_MESSAGES = 25    # менше = шум, на такому вчити голос не можна
TONE_LINE_MAX = 300       # ліміт на ОДИН рядок даних, щоб довгий список не зʼїв решту
TONE_DATA_MAX = 1900      # ліміт на ДАНІ секції; межі нижче ріжуться НІКОЛИ


def tone_snapshot_path(channel):
    """Заморожена секція тону для однієї розмови: {sid, section}. Лежить поруч із
    project-map.json і з тієї ж причини (див. _project_map): системний шар мусить
    бути байт-стабільним, інакше кожен хід перераховує весь кеш промпту."""
    return os.path.join(CHANNELS_DIR, channel, 'tone-section.json')


def _tone_mirror_on(channel):
    """Перемикач каналу «дзеркало тону» (channels/<id>/tone-mirror).

    ТИПОВО УВІМКНЕНО: файла нема означає увімкнено. Вимикається значенням
    0/false/no/off, і тоді секція не збирається взагалі, а системний промпт
    побайтово дорівнює тому, що був до появи цієї фічі."""
    try:
        p = os.path.join(CHANNELS_DIR, channel, 'tone-mirror')
        if os.path.exists(p):
            return open(p).read().strip().lower() not in ('0', 'false', 'no', 'off')
    except Exception:
        pass
    return True


def _tone_profile(name):
    """Один профіль з work/. Ніколи не рейзить: нема файлу означає нема секції."""
    try:
        with open(os.path.join(TONE_DIR, name), encoding='utf-8') as f:
            blob = json.load(f)
        return blob if isinstance(blob, dict) else {}
    except Exception:
        return {}


def _tone_section_build():
    """Секція «як говорить користувач» плюс «його слова для чіпів» плюс МЕЖІ.

    Повертає '' поки профілю нема або в ньому менше TONE_MIN_MESSAGES повідомлень:
    вчити голос на десятці реплік означає закріпити випадковість як звичку.

    Дані ріжуться по TONE_DATA_MAX, МЕЖІ не ріжуться ніколи. Порядок саме такий, бо
    обрізаний блок без меж це модель, якій сказали матюкатись і не сказали де стоп."""
    tone = _tone_profile('profile-tone.json')
    chips = _tone_profile('profile-chips.json')
    st = tone.get('stats') or {}
    top = tone.get('top') or {}
    if not st or (st.get('messages') or 0) < TONE_MIN_MESSAGES:
        return ''

    def words(items, n):
        return ', '.join(str(i.get('w')) for i in (items or [])[:n] if i and i.get('w'))

    def quotes(items, n):
        return '; '.join('«%s»' % i.get('w') for i in (items or [])[:n] if i and i.get('w'))

    def pct(x):
        return int(round(float(x or 0) * 100))

    data = [
        'Числа: речення в середньому %s слова, матюків %s на 100 слів, %s%% повідомлень '
        'починаються з малої літери, %s%% це питання (заміряно на %s його повідомленнях).'
        % (st.get('avgSentenceWords'), st.get('profanityPer100Words'),
           pct(st.get('lowercaseShare')), pct(st.get('questionShare')), st.get('messages')),
    ]
    for label, text in (
        ('Його слова', words(top.get('words'), 15)),
        ('Його звороти', quotes(top.get('phrases'), 6)),
        ('Лається так', words(top.get('profanity'), 6)),
        ('Починає повідомлення так', quotes(top.get('openers'), 6)),
        ('Погоджується так', quotes(top.get('agree'), 5)),
        ('Заперечує так', quotes(top.get('refuse'), 5)),
        ('Звучить так', quotes(top.get('quotes'), 4)),
    ):
        if text:
            data.append('%s: %s.' % (label, text))

    ctop = chips.get('top') or {}
    for label, text in (
        ('Формулювання чіпів, які він ТИСНЕ', quotes(ctop.get('clicked'), 5)),
        ('Пише руками замість чіпів (отже, ось його слова для кнопок)',
         quotes(ctop.get('typed'), 5)),
    ):
        if text:
            data.append('%s: %s.' % (label, text))
    # Категорії наміру (spec chips-rebuild, К7). Дослівні цитати вище лікують мертвий
    # РЯДОК, а це лікує мертву ТЕМУ, на яку припадає девʼяносто пʼять відсотків
    # промахів. Порядок такий: спершу жива тема (що взагалі пропонувати), потім мертва
    # (чого не пропонувати), і аж потім чорний список формулювань.
    def _intents(rows, n):
        out = []
        for r in (rows or [])[:n]:
            label = (r or {}).get('label')
            if label:
                out.append('%s %s%%' % (label, r.get('rate')))
        return ', '.join(out)

    itop = ctop.get('intents') or {}
    live = _intents(itop.get('live'), 3)
    dead = _intents(itop.get('dead'), 3)
    if live:
        data.append('Категорії чіпів, які він ТИСНЕ: %s.' % live)
    if dead:
        data.append('МЕРТВІ категорії, не пропонуй їх взагалі: %s.' % dead)
    typed_cats = ', '.join(
        str((r or {}).get('label')) for r in (itop.get('typed') or [])[:3] if (r or {}).get('label'))
    if typed_cats:
        data.append('Замість чіпів він частіше набирає руками саме це: %s.' % typed_cats)

    black = [b for b in (ctop.get('blacklist') or []) if b][:4]
    if black:
        data.append('НЕ пропонуй більше (проігноровано 3 рази поспіль): %s.'
                    % '; '.join('«%s»' % b for b in black))

    # Спершу ріжемо ДОВГІ рядки, і лише потім блок цілком. Інакше один розлогий
    # список цитат зʼїдав ліміт і викидав найдієвіший рядок, чорний список чіпів,
    # який стоїть останнім.
    def clip(line):
        if len(line) <= TONE_LINE_MAX:
            return line
        return line[:TONE_LINE_MAX].rsplit('; ', 1)[0] + '.'

    body = '\n'.join(clip(x) for x in data)
    if len(body) > TONE_DATA_MAX:
        body = body[:TONE_DATA_MAX].rsplit('\n', 1)[0]

    return (
        '\n\n[ЯК ГОВОРИТЬ КОРИСТУВАЧ. Профіль зібраний автоматично з його ж повідомлень, '
        'оновлюється сам після кожного ходу]\n'
        + body + '\n'
        'ГОВОРИ ТАК САМО у своїх відповідях у цьому чаті: той самий регістр, така сама '
        'коротка різка фраза, ті самі слова, той самий рівень матюка. Це дзеркало, а не '
        'карикатура: підхоплюєш регістр, а не перекривляєш людину.\n'
        'Це ПРЯМЕ прохання самого користувача, а не здогад про його смак. Тому суха нейтральна '
        'довідка тут це ПОМИЛКА подачі, а не безпечний дефолт: якщо відповідь можна було '
        'б слово в слово покласти в довідковий центр, ти не виконав інструкцію. Звертайся '
        'на «ти», ріж вступи, називай речі його словами. Матюк не обовʼязковий у кожній '
        'відповіді, але там, де він підсилює думку, він ДОРЕЧНИЙ, і стриматись «про всяк '
        'випадок» тут неправильно.\n'
        'Чіпи в `suggestions` підписуй ЙОГО словами, а не мовою інструкції.\n'
        'МЕЖІ (жорсткі, важать більше за дзеркалення тону):\n'
        '1. Матюк це ПІДСИЛЕННЯ думки. Ніколи не спрямований на людину, ніколи не образа.\n'
        '2. Тон живе ТІЛЬКИ в бульбашці цього чату. Коміти, документація, промпти '
        'агентам, тексти клієнтам, пости, файли памʼяті пишуться НЕЙТРАЛЬНО завжди, '
        'без винятків.\n'
        '3. Тон міняє СЛОВА, а не СТРУКТУРУ. Вирок першим рядком, причинна проза, '
        'віджети, conclusion в кінці лишаються недоторкані. Якщо тон і стандарт подачі '
        'конфліктують, виграє СТАНДАРТ.\n'
        '4. Нуль компліментарності лишається HARD. Дзеркалити тон це НЕ піддакувати: '
        'незгода і далі приходить з доказом.'
    )


def _tone_section(channel, session_id=None):
    """Секція тону, ЗАМОРОЖЕНА per (channel, session), рівно як _project_map.

    Профіль оновлюється після КОЖНОГО ходу, тому жива збірка переписувала б системний
    шар щоразу і перетворювала теплий хід на ~188k токенів (див. test_sys_prompt_
    stability.py). Знімок оновлюється тоді, коли префікс і так перебудовується.

    Вимкнений toneMirror повертає '' ДО читання знімка, тобто промпт стає байт-у-байт
    тим, що був до появи фічі. Порожній результат не кешується, щоб профіль, який
    зʼявиться пізніше, не лишився невидимим до кінця сесії.

    К14 (specs/i18n-interface): профіль зібраний з тисяч УКРАЇНСЬКИХ повідомлень
    однієї людини і міряє саме її матюки й звороти. Для будь-якої іншої мови секція
    вимикається ПОВНІСТЮ (не додається в промпт), а не перекладається: переклад дав
    би карикатуру на людину, якої в тій мові не існує."""
    if current_lang(channel) != 'uk':
        return ''
    if not _tone_mirror_on(channel):
        return ''
    path = tone_snapshot_path(channel)
    cached, cached_sid = None, None
    try:
        with open(path, encoding='utf-8') as f:
            blob = json.load(f)
        if isinstance(blob, dict) and isinstance(blob.get('section'), str):
            cached, cached_sid = blob['section'], blob.get('sid')
    except Exception:
        pass
    if cached is not None and (session_id is None or cached_sid == session_id):
        return cached
    try:
        fresh = _tone_section_build()
    except Exception:
        fresh = ''
    if not fresh:
        return cached or ''
    try:
        os.makedirs(os.path.dirname(path), exist_ok=True)
        tmp = path + '.tmp'
        with open(tmp, 'w', encoding='utf-8') as f:
            json.dump({'sid': session_id, 'section': fresh}, f, ensure_ascii=False)
        os.replace(tmp, path)
    except Exception:
        pass
    return fresh


# ---- Памʼять застосунку (specs/app-memory) ---------------------------------
# ЧОМУ ЦЕ ТУТ. До цієї правки раннер памʼять не підкладав узагалі. Вона доїжджала у
# хід лише як побічний ефект того, що рушій стартує з коренем репозиторію як робочою
# текою і успадковує памʼять ХАРНЕСУ з ~/.claude. На машині людини, у якої нема
# Claude Code з тим самим проєктом, того спадку не існує, тож памʼяті не було б, і
# мовчки. Тепер підкладає САМ застосунок зі свого сховища (К2).

MEMORY_LIMIT = 12         # стеля записів на хід. Ціна памʼяті платиться щоходу
MEMORY_QUERY_MSGS = 5     # скільки останніх реплік людини формують запит добору

# Бюджет на ВЕСЬ блок памʼяті одного ходу: ядро в системному шарі ПЛЮС динамічний
# добір у шарі ходу (specs/user-memory-v2, К16). Оголошений до реалізації і не
# переглядається на око: памʼять їде в КОЖНОМУ ході, тому зайвий символ це податок
# назавжди, а не разова витрата. Шість тисяч символів це приблизно півтори тисячі
# токенів, тобто менше відсотка вікна: помітно для моделі, непомітно для рахунку.
MEMORY_BUDGET_CHARS = 6000

# Шапка блоку в шарі ХОДУ. Відрізняється від шапки системного шару свідомо: у ході
# приїжджає добір саме під це питання, і модель мусить бачити різницю між «це про
# мене завжди» (ядро) і «це підняли, бо ти зараз про це спитав».
MEMORY_TURN_HEADER = ('[Памʼять застосунку, дібрана під ЦЕЙ запит. Це вже записано '
                      'раніше, спирайся на це і не вигадуй понад це]')


def memory_enabled():
    """Чи має ЗАСТОСУНОК підкладати памʼять у цей хід (specs/memory-packaged-only).

    Умова рівно одна: паковано (`LOGOPSIS_HOME` виставлений). Причина не в обережності,
    а в тому, що в дев-репо памʼять у хід уже підкладає ХАРНЕС зі своєї теки
    `~/.claude/projects/<ЗАКОДОВАНИЙ-ШЛЯХ>/memory/`. Якби застосунок додав ту саму
    памʼять зі свого сховища, кожен факт приїжджав би у хід двічі, і модель отримала б
    два трохи різні описи однієї правди замість одного.

    Гейт стоїть на ПІДКЛАДАННІ, а не на сховищі. Сховище лишається повним у будь-якому
    режимі, бо воно відповідає на питання «що застосунок про мене знає»: екран памʼяті,
    експорт і імпорт працюють однаково і в деві, і в пакованій збірці.
    """
    return bool(_CV_HOME)


def memory_snapshot_path(channel):
    """Заморожена секція памʼяті однієї розмови: {sid, section}. Лежить поруч із
    project-map.json і tone-section.json, з тієї ж причини: системний шар мусить бути
    байт-стабільним, інакше кожен хід перераховує весь префікс кеша промпту."""
    return os.path.join(CHANNELS_DIR, channel, 'memory-section.json')


def _drop_memory_snapshot(channel):
    """Викинути заморожену секцію памʼяті каналу. Відсутній файл це не помилка."""
    try:
        os.remove(memory_snapshot_path(channel))
    except OSError:
        pass


def _memory_query(channel, extra=''):
    """Запит добору: репліка ЦЬОГО ходу плюс останні репліки ЛЮДИНИ в цьому каналі.

    Саме репліки, а не весь діалог: добір іде по однорядковому опису запису (К6), і
    підмішувати туди власні відповіді означало б шукати памʼять по тому, що модель
    сама щойно сказала.

    `extra` це текст промпта, який ЩОЙНО поїхав у хід, і він іде ПЕРШИМ. Причина не
    в охайності: запит рахується тепер щоходу для шару ходу (К3), а бульбашка цього
    повідомлення могла ще не лягти в index.json на момент виклику. Без `extra` нова
    тема посеред сесії піднімала б факти по ПОПЕРЕДНІХ темах, тобто рівно та біда,
    заради якої добір і переїхав із системного шару.
    """
    try:
        idx_path = os.path.join(CHANNELS_DIR, channel, 'index.json')
        with open(idx_path, encoding='utf-8') as f:
            items = json.load(f)
        if not isinstance(items, list):
            items = []
    except Exception:
        # Порожня історія це вже НЕ причина віддати порожній запит: текст цього ходу
        # (`extra`) сам по собі є повноцінним запитом добору.
        items = []
    mine = [i for i in items if isinstance(i, dict) and i.get('from') == 'Я'][-MEMORY_QUERY_MSGS:]
    out = [extra] if isinstance(extra, str) and extra.strip() else []
    for item in mine:
        try:
            with open(os.path.join(CHANNELS_DIR, channel, item['file']), encoding='utf-8') as f:
                widgets = json.load(f)
        except Exception:
            continue
        for w in widgets if isinstance(widgets, list) else []:
            if isinstance(w, dict) and isinstance(w.get('text'), str):
                out.append(w['text'])
    return ' '.join(out)[:2000]


def _memory_fit(block, budget):
    """Обрізати зібраний блок памʼяті ЦІЛИМИ записами до бюджету символів (К16).

    Ріжеться по рядках, а не по символах, з однієї причини: обрізаний посеред слова
    факт це вже не факт, а недомовка, і модель сперлась би на половину правила з
    повною впевненістю. Краще дванадцять цілих записів, ніж дванадцять з половиною.

    Шапка без жодного запису повертається порожнім рядком: у системному шарі кожен
    байт це перерахунок префікса кеша, тому платити за заголовок ні за що не можна.
    """
    if not block:
        return ''
    if len(block) <= budget:
        return block
    kept, total = [], 0
    for line in block.split('\n'):
        step = len(line) + (1 if kept else 0)
        if kept and total + step > budget:
            break
        kept.append(line)
        total += step
    if not any(line.startswith('- ') for line in kept):
        return ''
    return '\n'.join(kept)


def _memory_scope(channel):
    """Область добору цього каналу. Окремою функцією, бо її однаково потребують
    обидва шари: і ядро в системному, і динамічний добір у ході."""
    import memory_store
    return {'project': memory_store.resolve_project(DIR, REPO_ROOT), 'channel': channel}


def _memory_section_build(channel):
    """Зібрати ЯДРО памʼяті для системного шару. Ніколи не рейзить.

    Тільки ядро (`tier == 'core'`), і саме тому тут стоїть `limit=0`: стеля в
    `memory_store.select` обмежує ЛИШЕ динамічну частину, ядро їде поза нею. Запит
    добору сюди не передається взагалі, і це головна властивість цієї функції: те, що
    не залежить від запиту, не може зрушити системний шар посеред сесії (К3).

    Повертає '' коли класти в системний шар нема чого (сховище порожнє або ядра в
    ньому ще нема), і None коли зібрати не вдалось. Різниця не косметична: порожньо це
    ЗАКОННИЙ стан (людина стерла все або ще нічого не підвищила до ядра), а зламано це
    тимчасова біда. Той, хто читає цю функцію, мусить лишити старий знімок на другому
    і викинути його на першому.
    """
    try:
        import memory_store
        facts = memory_store.load_all(DIR)
        if not facts:
            # Порожнє сховище виходить ДО реєстру проєктів свідомо: людині, у якої
            # памʼяті ще нема, застосунок не сміє класти маркер у робочу теку ні за що.
            return ''
        block = memory_store.prompt_block(DIR, query='', scope=_memory_scope(channel),
                                          limit=0, facts=facts)
    except Exception:
        return None
    fitted = _memory_fit(block, MEMORY_BUDGET_CHARS)
    if len(fitted) != len(block):
        # Мовчки ядро не ріжеться: стелю ядра тримає memory_store.set_tier (К2), тож
        # спрацювання ЦЬОГО запобіжника означає, що ядро наповнили в обхід нього.
        log('[памʼять]', channel + ':', 'ядро не влізло в бюджет, обрізав %d -> %d символів'
            % (len(block), len(fitted)))
    return fitted


def _memory_section(channel, session_id=None):
    """ЯДРО памʼяті в системному шарі, заморожене per (channel, session).

    Заморозка тут не оптимізація, а умова існування фічі: один змінений байт у
    системному шарі перераховує весь префікс кеша (див. test_sys_prompt_stability.py:
    теплий хід це cacheRead 187554 при cacheCreate 931). Памʼять, яка коштує 200x
    рахунку на квоту, це не памʼять, а покарання.

    ЩО ЗМІНИЛОСЬ (specs/user-memory-v2, S3, К3). Раніше сюди їхав увесь блок разом із
    динамічним добором, і заморозка платила за стабільність фічею: добір рахувався за
    репліками на СТАРТІ сесії, тож нова тема посеред розмови своїх фактів не піднімала
    ніколи. Тепер шарів два. Тут лишається ядро, яке від запиту не залежить взагалі,
    тому байти стоять не тому, що ми їх заморозили, а тому, що їм нема від чого
    зрушити. Динамічний добір поїхав у шар ХОДУ (`_memory_turn_section`), тобто після
    точки кешування, і перераховується щоходу без жодної ціни для префікса.

    Знімок при цьому лишається: він рятує від зайвого читання сотень файлів щоходу і
    від сценарію «людина підвищила факт до ядра посеред сесії», де байти зрушили б.

    Порожнє сховище повертає '' і СТИРАЄ знімок, а не лишає старий. Це відрізняє
    памʼять від мапи проєкту, де порожньо означає збій агрегатора: тут порожньо це
    закон, бо людина щойно натиснула «стерти». Лишити знімок означало б і далі
    підкладати у хід рівно те, що вона видалила, і жодним способом це не помітити.
    Збій збірки (None) знімок навпаки береже: разова похибка не сміє знеструмити
    памʼять на всю розмову.

    Дев-режим виходить ПЕРШИМ рядком, до читання знімка (К1, К3). Порядок тут несе
    сенс: знімок, заморожений ще до гейта, інакше проїхав би повз умову і далі вантажив
    би у хід ту саму памʼять, що й харнес. Тому дев не просто віддає порожньо, а й
    СТИРАЄ файл знімка."""
    if not memory_enabled():
        _drop_memory_snapshot(channel)
        # Мовчазна різниця між двома режимами це найгірший варіант: людина бачить повний
        # екран памʼяті і не має способу дізнатись, що в хід він не їде (К6).
        log('[памʼять]', channel + ':', 'дев-режим, у хід не підкладаю (памʼять дає харнес)')
        return ''
    path = memory_snapshot_path(channel)
    cached, cached_sid = None, None
    try:
        with open(path, encoding='utf-8') as f:
            blob = json.load(f)
        if isinstance(blob, dict) and isinstance(blob.get('section'), str):
            cached, cached_sid = blob['section'], blob.get('sid')
    except Exception:
        pass
    if cached is not None and (session_id is None or cached_sid == session_id):
        return cached
    try:
        fresh = _memory_section_build(channel)
    except Exception:
        fresh = None
    if fresh == '':
        _drop_memory_snapshot(channel)
        return ''
    if not fresh:
        return cached or ''
    try:
        os.makedirs(os.path.dirname(path), exist_ok=True)
        tmp = path + '.tmp'
        with open(tmp, 'w', encoding='utf-8') as f:
            json.dump({'sid': session_id, 'section': fresh}, f, ensure_ascii=False)
        os.replace(tmp, path)
    except Exception:
        pass
    return fresh


def _memory_retitle(block, header):
    """Підмінити шапку зібраного блоку. Шапка це ПЕРШИЙ рядок, що починається з '['.

    Потрібно тому, що `memory_store.prompt_block` віддає один і той самий заголовок
    обом шарам, а два однакові заголовки в одному ході модель читає як повтор однієї
    секції. Пошук по '[' замість жорсткого зрізу: рядки фактів починаються з '- (',
    тобто сплутати їх із шапкою неможливо, і зміна тексту шапки в сховищі цю функцію
    не зламає.
    """
    lines = block.split('\n')
    for i, line in enumerate(lines):
        if line.startswith('['):
            lines[i] = header
            break
    return '\n'.join(lines)


def _memory_turn_section(channel, prompt_text='', session_id=None):
    """Динамічний добір памʼяті у шар ХОДУ, ПІСЛЯ точки кешування (К3, К16).

    ДЕ ТУТ ТОЧКА КЕШУВАННЯ. Збіг кеша це точний префікс по байтах у порядку
    tools -> system -> messages. Системний шар ми віддаємо прапорцем
    `--append-system-prompt`, і в теплому режимі (`run_claude_warm`) він узагалі
    задається ОДИН раз при спавні процесу, а далі ходи їдуть у stdin окремими
    повідомленнями користувача. Тобто все, що дописано в текст промпта, лягає в кінець
    ланцюга messages: воно не чіпає жодного байта префікса і перерахунку не викликає.
    Саме тому динамічний добір їде сюди, а не в `_memory_section`.

    Ядро звідси ВИКИНУТО (`tier != 'core'`), бо воно вже приїхало системним шаром, і
    другий примірник коштував би токенів двічі за ту саму правду.

    Бюджет спільний на обидва шари (MEMORY_BUDGET_CHARS): скільки зʼїло ядро, стільки
    менше лишається добору. Порахувати інакше означало б оголосити стелю і мовчки
    платити подвійно.

    Ніколи не рейзить: памʼять це підсилення ходу, а не його умова, тому будь-яка біда
    тут коштує рядка в лозі і порожньої секції, а не втраченої відповіді людини.
    """
    if not memory_enabled():
        return ''
    try:
        import memory_store
        pool = [f for f in memory_store.load_all(DIR) if f.get('tier') != 'core']
        if not pool:
            return ''
        core_len = len(_memory_section(channel, session_id))
        budget = MEMORY_BUDGET_CHARS - core_len
        if budget <= 0:
            log('[памʼять]', channel + ':',
                'ядро зайняло весь бюджет (%d), динамічний добір цього ходу не їде' % core_len)
            return ''
        block = memory_store.prompt_block(DIR, query=_memory_query(channel, prompt_text),
                                          scope=_memory_scope(channel),
                                          limit=MEMORY_LIMIT, facts=pool)
        if not block:
            return ''
        fitted = _memory_fit(_memory_retitle(block, MEMORY_TURN_HEADER), budget)
    except Exception as e:
        log('[памʼять]', channel + ':', 'шар ходу зібрати не вдалось: %r' % (e,))
        return ''
    log('[памʼять]', channel + ':', 'шар ходу %d символів, ядро %d, бюджет %d'
        % (len(fitted), core_len, MEMORY_BUDGET_CHARS))
    return fitted


def memory_turn_prompt(channel, prompt, session_id=None):
    """Промпт цього ходу разом із дібраною під нього памʼяттю (К3).

    Блок дописується В КІНЕЦЬ, за прикладом переліку прикріплених зображень вище в
    `process_channel`: питання людини мусить лишитись питанням, а памʼять приїжджає як
    довідка до нього. Порожній блок повертає промпт незміненим байт у байт, тобто в
    каналі без памʼяті цей крок не коштує нічого.
    """
    block = _memory_turn_section(channel, prompt_text=prompt, session_id=session_id)
    return (prompt + block) if block else prompt


def memory_autolearn_enabled():
    """Вимикач автозапису. Одна змінна середовища, дефолт УВІМКНЕНО.

    Існує з двох причин. Перша: К8 вимагає заміру «з увімкненим і вимкненим
    автозаписом на однаковому наборі ходів», а без вимикача стан «вимкнено» нема
    чим відтворити. Друга: памʼять це допоміжна річ, і якщо вона колись почне
    заважати розмові, її мусить бути чим погасити без правки коду."""
    return os.environ.get('LOGOPSIS_MEMORY_AUTOLEARN', '1') != '0'


def _memory_autolearn_run(channel, text, msg_id):
    """Тіло автозапису. НІКОЛИ не рейзить, бо крутиться нікому не підзвітним потоком.

    Помилка тут не сміє чіпати розмову (і не може: хід уже віддано), тому єдина
    реакція на будь-яку біду це рядок у лозі. Мовчати теж не можна: автозапис, який
    зламався і не сказав, виглядає точно як автозапис, якому не було що записати."""
    try:
        import memory_learn
        found = memory_learn.candidate_from_message(
            DIR, text, channel=channel,
            message_file=('%04d.json' % msg_id) if msg_id else '')
    except Exception as e:
        log('[памʼять]', channel + ':', 'автозапис не вдався: %r' % (e,))
        return None
    if found:
        log('[памʼять]', channel + ':', 'кандидат %s у карантині, маркери: %s'
            % (found['id'], ', '.join(found['markers'])))
    return found


def memory_autolearn(channel, text, msg_id=None):
    """Автозапис з репліки людини ПОЗА критичним шляхом відповіді (К5, К8).

    Викликається вже ПІСЛЯ того, як відповідь лягла у стрічку, і все одно йде
    окремим потоком. Два кроки замість одного тут не перестраховка: після
    відповіді раннер одразу бере наступний елемент черги, тож синхронний автозапис
    крав би час не в цього ходу, а в наступного. Пачка з пʼяти повідомлень платила б
    за памʼять пʼять разів поспіль, і саме там людина чекає найдовше.

    Потік демонський і запис у сховище атомарний (`_atomic_write`), тому смерть
    процесу посеред запису лишає або цілий файл, або жодного, але ніколи половину.

    Повертає сам потік (або None, коли писати нема з чого): тесту потрібна точка,
    на якій можна дочекатись кінця, не вигадуючи пауз.

    Рейзити ця функція не має права взагалі, тому що вона стоїть у тілі `process_channel`,
    а не в потоці: виняток ТУТ обірвав би хід, який уже успішно віддано. Звідси і
    перевірка типу замість звичного `text or ''` (кривий елемент черги з нетекстовим
    полем дав би AttributeError), і піймана невдача старту потоку."""
    if (not memory_autolearn_enabled() or not isinstance(text, str)
            or not text.strip()):
        return None
    try:
        th = threading.Thread(target=_memory_autolearn_run,
                              args=(channel, text, msg_id),
                              name='memory-autolearn', daemon=True)
        th.start()
    except Exception as e:
        log('[памʼять]', channel + ':', 'автозапис не стартував: %r' % (e,))
        return None
    return th


def _sys_prompt(channel, session_id=None):
    """CHAT_SYSTEM_OVERRIDE + the ecosystem map + the tone mirror, both frozen for
    this conversation, plus the channel's agent hat when one is worn.

    `session_id` is what keeps the system layer byte-stable across turns; pass it from
    every call site. Omitting it reuses whatever snapshot the channel already has.

    Капелюх свідомо НЕ заморожується по session_id, на відміну від мапи і тону:
    його ставлять і знімають посеред розмови, і саме ця зміна мусить доїхати з
    наступним повідомленням (К2/К6). Ціною одного промах-кешу на той хід, де
    капелюх змінився, далі байти знову стабільні."""
    _log_layer_winner(channel)
    return _compose_layers(channel, session_id)


def _log_layer_winner(channel):
    """Рядок у лог ходу: який шар переміг і на чому саме (К4).

    Пишеться на кожен хід, а не «коли конфлікт трапився»: конфлікти між правилами
    застосунку і проєктним CLAUDE.md не випадкові, вони прямо задекларовані в тексті
    шару застосунку, тобто діють завжди. Без цього рядка питання «чому воно
    поводиться саме так» коштує пів години читання коду, і саме через це переїзд
    правил у файл сам по собі нічого б не пояснив.
    """
    try:
        log('[правила]', channel + ':', rules_store.conflict_log_line())
    except Exception:
        pass                         # лог не сміє ламати хід


# Стеля ОДНОГО опису дії в шарі гаджета. Задача просить «імена дій і ОДНОРЯДКОВІ
# описи», а маніфести цього не гарантують: у `publisher` один опис важить 2483 символи,
# у `tasks` таких описів 21 штука на 6101 символ разом. Без стелі шар адресації важив би
# більше за третину всього системного промпту, тобто платив би кешем за текст, який
# моделі потрібен рівно як покажчик «така дія існує». Повний опис вона все одно бачить у
# схемі МСП-містка `gadget_action`, коли справді збирається діяти.
_GADGET_ACTION_DESC_MAX = 120


def channel_gadget(channel):
    """Гаджет, обраний у рядку вводу ЦЬОГО каналу, як {id, name, icon, actions}, або None.

    Слайс Р2 спеки gadget-chat-engine, К23. Джерело правди це файл `channels/<канал>/gadget`
    з одним рядком (id гаджета), який пише `/api/channel-gadget`. Саме файл, а не поле в
    тілі повідомлення: вибір гаджета це стан КАНАЛУ («у цьому чаті працюємо ось із цим»), і
    К23 говорить саме про «хід у каналі з обраним гаджетом». Полем у send він губився б на
    перезавантаженні і жив би у двох правдах одночасно.

    Читається ЖИВЦЕМ на кожному ході, без заморозки по session_id, і це та сама причина,
    що в капелюха: гаджет обирають і знімають посеред розмови, тож зміна мусить доїхати з
    наступним повідомленням. Ціна це один промах кеша на той хід, де вибір змінився.

    Гаджет, id якого лежить у файлі, а теки на диску вже нема (видалили), читається як
    «вибору нема», а не як аварія: краще повернути канал до звичайного, ніж підкладати в
    хід ім'я, за яким нічого не стоїть.
    """
    try:
        p = os.path.join(CHANNELS_DIR, channel, 'gadget')
        if not os.path.exists(p):
            return None
        with open(p, encoding='utf-8') as f:
            gid = f.read().strip()
    except Exception as e:
        log(f'{channel}: gadget pick read failed: {e}')
        return None
    # Та сама перевірка, що в server._gadget_dir: файл на диску правиться руками, і
    # `../../` у ньому не сміє перетворитись на читання чужої теки.
    if not gid or '/' in gid or '\\' in gid or '..' in gid:
        return None
    try:
        with open(os.path.join(DIR, 'apps', gid, 'manifest.json'), encoding='utf-8') as f:
            man = json.load(f)
    except Exception:
        return None
    if not isinstance(man, dict):
        return None
    actions = []
    for a in (man.get('actions') or []):
        if not isinstance(a, dict):
            continue
        aid = str(a.get('id') or a.get('name') or '').strip()
        if not aid:
            continue
        desc = ' '.join(str(a.get('description') or a.get('label') or '').split())
        if len(desc) > _GADGET_ACTION_DESC_MAX:
            desc = desc[:_GADGET_ACTION_DESC_MAX].rstrip() + '…'
        actions.append((aid, desc))
    return {'id': gid,
            'name': str(man.get('name') or '').strip() or gid,
            'icon': str(man.get('icon') or '').strip(),
            'actions': actions}


def _gadget_section(channel):
    """Шар `канал`: ПРО ЯКИЙ гаджет іде мова в цьому чаті. '' коли вибору нема (К23).

    🚨 СЮДИ НЕ КЛАДЕТЬСЯ `apps/<id>/state.json`, І ЦЕ НЕ ЕКОНОМІЯ. К23 забороняє
    вантажити стан у системний шар прямим текстом, а `specs/gadget-mcp-hardening`
    записала в не-цілі сам перемикач «підключити гаджет до каналу». Вибір гаджета це
    АДРЕСАЦІЯ розмови, а не роздача доступу: доступ до всіх гаджетів у моделі і так є
    через МСП-містки, тому вибір нічого не відмикає і не має вигляду відмикання.
    Стан їде інструментом `gadget_state` і рівно тоді, коли модель його попросила.

    Другий, дешевший бік тієї ж заборони: стан гаджета міняється щохвилини (бойовий
    `today` важить 228 КБ), а системний шар це префікс кеша. Стан у ньому означав би
    перерахунок префікса на кожну галочку в гаджеті.
    """
    g = channel_gadget(channel)
    if not g:
        return ''
    head = ('SELECTED GADGET (this chat is addressed to it): «%s»%s, id `%s`.\n'
            'When the user says "the app", "there", "add it", "mark it done" without '
            'naming anything, they mean THIS gadget.'
            % (g['name'], (' ' + g['icon']) if g['icon'] else '', g['id']))
    if g['actions']:
        rows = '\n'.join('- `%s`%s' % (aid, (': ' + desc) if desc else '')
                         for aid, desc in g['actions'])
        acts = '\nActions it declares in its manifest:\n' + rows
    else:
        # Порожній список це ЗАКОННИЙ стан (свіжий гаджет з `apps/app-1`), і мовчати про
        # нього не можна: без цього рядка модель читала б відсутність переліку як обрив
        # тексту і вигадувала б дії, яких у маніфесті нема.
        acts = '\nIts manifest declares no actions.'
    tail = ('\nIts current state is deliberately NOT in this prompt: read it on demand '
            'with the `gadget_state` tool (gadgetId `%s`).' % g['id'])
    return '\n\n' + head + acts + tail + '\n'


def _layer_texts(channel, session_id=None):
    """Що саме несе кожен із чотирьох шарів У ЦЬОМУ рядку (К3).

    Порядок шарів у LAYERS це порядок ПРІОРИТЕТУ, від найближчого до розмови до
    найдальшого. Один шар навмисно порожній, і це не забудькуватість:

      проєкт     CLAUDE.md вантажить сам харнес, ДО нашого --append-system-prompt.
                 Тобто фізично він уже лежить лівіше за все, що ми тут додаємо, і
                 дублювати його сюди означало б дві копії тієї самої правди.

    Шар `канал` до слайса Р2 (specs/gadget-chat-engine, К23) теж був порожнім рядком і
    стояв там як заброньоване місце. Тепер він несе АДРЕСАЦІЮ розмови: який гаджет
    людина обрала в рядку вводу цього каналу. Інструкції каналу
    (`channels/<канал>/instructions.md`) сюди так і не поїхали і не поїдуть: модель
    читає їх файлом у ході, тобто ще ближче до розмови, ніж системний шар.

    Гаджета не обрано -> шар знову порожній рядок, і системний промпт побайтово такий
    самий, як до Р2. Це не оптимізація, а умова: порожній шар це і є відсутність
    вибору, а речення «гаджет не обрано» коштувало б кеш-префікса кожному каналу без
    гаджета і не сказало б моделі нічого.

    Повертає впорядкований список пар (шар, текст) саме в порядку LAYERS.
    """
    # Мова цього ходу (specs/engine-reply-language, К1, К2, К11): current_lang
    # читає знімок МЕСЕДЖА першим, той самий принцип, що і channel_model вище.
    # Рахуємо ОДИН раз і на «учасник» (капелюх), і на «застосунок»: обидва шари
    # мовно залежні (латання оберту 2), а current_lang() це файл плюс знімок черги,
    # повторне читання на кожен шар було б зайвим і теоретично могло розійтись.
    lang = current_lang(channel)
    return [
        ('учасник', _hat_section(channel, lang)),
        ('канал', _gadget_section(channel)),
        ('застосунок', chat_system_override(lang)
                       + _project_map(channel, session_id, lang)
                       + _tone_section(channel, session_id)
                       + _memory_section(channel, session_id)),
        ('проєкт', ''),
    ]


def _compose_layers(channel, session_id=None):
    """Склеїти шари в один системний рядок: найдальший першим, найближчий останнім.

    Склейка йде РЕВЕРСОМ до LAYERS, бо в промпті пізніший текст стоїть ближче до
    розмови, а ближчий до розмови перемагає. Байт при цьому не зрушив: до переїзду
    той самий рядок збирався руками в тому ж порядку, і це стереже
    tests/unit/test_rules_layer.py.
    """
    return ''.join(text for _, text in reversed(_layer_texts(channel, session_id)))


def _sdk_deps(channel, session_id=None):
    """Bundle the runner helpers/constants engine_sdk needs into one namespace,
    so engine_sdk stays decoupled (no `import runner`, which would re-run this
    module under its real name and double-spawn everything). `session_id` keys the
    frozen project map, so the SDK engine gets the same byte-stable system layer."""
    import types
    return types.SimpleNamespace(
        REPO_ROOT=REPO_ROOT, CLAUDE_BIN=CLAUDE_BIN,
        CHAT_SYSTEM_OVERRIDE=_sys_prompt(channel, session_id),
        DISALLOWED_TOOLS=channel_disallowed_tools(channel), CHANNELS_DIR=CHANNELS_DIR,
        STOP_SENTINEL=STOP_SENTINEL,
        channel_model=channel_model, channel_permission=channel_permission,
        # Зусилля цього конкретного меседжа (знімок з файла черги). Модель уже їде
        # через channel_model, який дивиться в той самий знімок.
        job_effort=job_effort,
        child_env=_child_env, write_live=write_live, clear_live=clear_live,
        write_pid=write_pid, clear_pid=clear_pid, pid_was_stopped=pid_was_stopped,
        tool_icon=_tool_icon, tool_label=_tool_label,
        session_jsonl_exists=session_jsonl_exists, log=log,
        # Каталог моделей CLI: модель і рівні зусиль на хід (specs/claude-model-catalog-auto).
        claude_families=_claude_families,
    )


def _sdk_enabled(channel):
    """Per-channel SDK opt-in (channels/<id>/engine == 'sdk') overrides the global
    SDK_MODE, so we can A/B the SDK engine on ONE channel while every other channel
    stays on the proven warm engine. Read live each turn (no restart to flip)."""
    try:
        p = os.path.join(CHANNELS_DIR, channel, 'engine')
        if os.path.exists(p):
            return open(p).read().strip().lower() == 'sdk'
    except Exception:
        pass
    return SDK_MODE


def _model_never_ran(data):
    """True коли лічильники ходу кажуть, що моделі не було ВЗАГАЛІ.

    Підпис 39 мовчазних смертей у лозі: `usage ctx=0 (0.0%) turn=$0.0000
    model=None`. modelUsage порожній рівно тоді, коли жодна модель не відповіла,
    бо CLI заповнює його на першій же відповіді. Мовчазний РОБОЧИЙ хід
    (інструменти відпрацювали, тексту нема) сюди не потрапляє: щоб покликати
    інструмент, модель мусила відповісти, тож у нього і modelUsage, і токени є.
    Тому «нічого» тут означає саме «нічого не сталось», і повтор безпечний."""
    d = data or {}
    if d.get('modelUsage'):
        return False
    for bag in (d.get('usage'), d.get('contextUsage')):
        if not isinstance(bag, dict):
            continue
        for k in ('input_tokens', 'output_tokens',
                  'cache_read_input_tokens', 'cache_creation_input_tokens'):
            try:
                if int(bag.get(k) or 0):
                    return False
            except (TypeError, ValueError):
                continue
    return True


def run_claude_sdk_turn(prompt, session_id, channel):
    """SDK engine dispatch with a safety net: if the SDK module fails to import or
    hits a transport-level error, fall back to the proven warm engine for this
    turn (a normal `claude error` or a user stop is passed through, NOT retried)."""
    try:
        import engine_sdk
    except Exception as e:
        log(f'{channel}: SDK engine import failed ({e}); using warm')
        return run_claude_warm(prompt, session_id, channel)
    text, data, err = engine_sdk.run_claude_sdk(prompt, session_id, channel,
                                                _sdk_deps(channel, session_id))
    if err and isinstance(err, str) and err.startswith('sdk'):
        log(f'{channel}: SDK engine error ({err}); falling back to warm')
        return run_claude_warm(prompt, session_id, channel)
    # Другий пояс на тому самому вузькому місці. Порожній текст БЕЗ помилки
    # проходив крізь умову вище і йшов простісінько в гілку «empty reply», де
    # Людина бачила «Відповідь не прийшла» і мусила тиснути повтор руками. Двигун
    # тепер сам мітить такий хід помилкою, але покладатись лише на нього не
    # можна: якщо класифікатор колись розійдеться з реальністю, рятує ця умова,
    # бо вона дивиться не на слова, а на лічильники ходу.
    if (not err and not (text or '').strip() and _model_never_ran(data)):
        log(f'{channel}: SDK returned nothing and the model never ran; '
            f'falling back to warm')
        return run_claude_warm(prompt, session_id, channel)
    return text, data, err


def run_claude(prompt, session_id, channel):
    """Single-shot json turn (Stage 1/2 fallback, CHAT_RUNNER_STREAM=0). First
    turn for a session uses --session-id (creates it), later turns use --resume
    (continues with full context). Returns (text, data_or_None, error_or_None)
    where data is the full parsed JSON result so the caller can read .usage /
    .total_cost_usd for the context+cost meter."""
    resume = session_jsonl_exists(session_id)
    model = channel_model(channel, prompt)
    perm = channel_permission(channel)
    cmd = [CLAUDE_BIN, '-p', prompt,
           *_resolve_model_args(model),
           '--append-system-prompt', _sys_prompt(channel, session_id),
           '--disallowedTools', *channel_disallowed_tools(channel),
           '--output-format', 'json',
           '--permission-mode', perm]
    cmd += _resume_or_seed_args(channel, session_id)
    log(f'claude turn ({"resume" if resume else "new"}) sid={session_id[:8]} '
        f'model={model} perm={perm} prompt={prompt[:60]!r}')
    # Popen (not subprocess.run) so we can record the PID for /api/stop and kill
    # the whole process group. start_new_session gives claude its own group.
    try:
        proc = subprocess.Popen(
            cmd, cwd=REPO_ROOT, stdout=subprocess.PIPE, stderr=subprocess.PIPE,
            text=True, **_PROC_GROUP_KW, env=_child_env(channel),
        )
    except Exception as e:
        return None, None, f'spawn failed: {e}'
    write_pid(channel, proc.pid)
    try:
        # Single-shot mode has no event stream, so there is no idle signal to act
        # on: only the absolute backstop (TURN_TIMEOUT, default 1h) guards against
        # a runaway. There is no partial to preserve here (the reply only exists
        # once the whole turn finishes). This path is the CHAT_RUNNER_STREAM=0
        # emergency fallback; the default warm/stream paths are idle-based.
        out_s, err_s = proc.communicate(timeout=TURN_TIMEOUT)
    except subprocess.TimeoutExpired:
        proc.kill()
        return None, None, f'timeout after {TURN_TIMEOUT}s'
    # Intentional kill via /api/stop -> quiet stop, not an error bubble.
    if pid_was_stopped(channel, proc.pid):
        return None, None, STOP_SENTINEL
    if proc.returncode != 0:
        tail = (err_s or out_s or '').strip()[-500:]
        return None, None, f'claude exited {proc.returncode}: {tail}'
    try:
        data = json.loads(out_s)
    except Exception as e:
        return None, None, f'bad json output: {e}; raw={out_s[:300]}'
    if data.get('is_error'):
        return None, data, f'claude error: {data.get("result")}'
    return (data.get('result') or '').strip(), data, None


def write_usage(channel, data, cost_only=False, kind=None):
    """Persist a cumulative usage/cost summary for the channel meter.

    v2.1.169 fields used (verified against a real `claude -p ... --output-format
    json` call):
      data.total_cost_usd                      cumulative cost of this turn
      data.usage.input_tokens                  non-cached input this turn
      data.usage.cache_read_input_tokens       cached prompt read this turn
      data.usage.cache_creation_input_tokens   cache written this turn
      data.modelUsage[MODEL].contextWindow     1_000_000 for opus-4-8[1m]

    "Context load" = the full prompt that actually went to the model this turn =
    input_tokens + cache_read + cache_creation. (input_tokens alone is only the
    non-cached slice; in Claude Code most of the context is served from cache.)
    The meter is that sum / contextWindow.

    cost_only=True: fold ONLY the money (cumulativeCostUsd) into usage.json and
    append the history line, leaving every context field exactly as it was. Used
    by compact_channel: the compaction turn is the single most expensive turn in
    a channel's life (the whole accumulated context goes to the model), so its
    cost MUST land in the meter, but its CONTEXT must not. reset_context_pct runs
    right after and deliberately zeroes the meter for the fresh session; writing
    the pre-compaction context back would re-arm the auto-compact gate on the very
    next message and compact every single turn (see the note at CHAT_RUNNER_SDK).

    kind: optional label for the usage-history line ('compact'), so the spend of
    compaction itself is separable later. Absent on normal turns, and old lines
    without the field stay valid for any reader.
    """
    try:
        u = (data or {}).get('usage', {}) or {}
        out = int(u.get('output_tokens', 0) or 0)
        # Context occupancy = the LAST assistant call's input side, NOT the
        # turn-aggregated usage. The result event's `usage` SUMS
        # cache_read_input_tokens across every agentic step of the turn, so a
        # multi-tool turn reports 100% to 500%+ of the window (that is read
        # throughput, not occupancy) and trips the auto-compact gate almost every
        # message. `contextUsage` is the final assistant message's own usage,
        # which is the real prompt size at turn end. Fall back to the aggregate
        # only when contextUsage is absent (rare non-stream json fallback path).
        cu = (data or {}).get('contextUsage') or u
        inp = int(cu.get('input_tokens', 0) or 0)
        cache_read = int(cu.get('cache_read_input_tokens', 0) or 0)
        cache_create = int(cu.get('cache_creation_input_tokens', 0) or 0)
        full_context = inp + cache_read + cache_create
        # contextWindow + actual model id: modelUsage is keyed by the real model
        # that ran this turn (e.g. "claude-haiku-4-5-20251001"). We take the
        # context window from whichever model has the largest one (the active
        # model), so the meter denominator follows the per-channel model. The
        # key itself is the ground-truth proof of which model executed.
        ctx_window = CONTEXT_WINDOW
        active_model = None
        mu = (data or {}).get('modelUsage', {}) or {}
        best_window = 0
        for name, m in mu.items():
            if not isinstance(m, dict):
                continue
            cw = int(m.get('contextWindow') or 0)
            if cw > best_window:
                best_window = cw
                ctx_window = cw
                active_model = name
        if active_model is None and mu:
            active_model = next(iter(mu.keys()))
        # Назва активної моделі: turnModel ходу має перевагу над накопиченим
        # modelUsage (див. _turn_model). Знаменник вище не чіпаємо.
        active_model = _turn_model(data) or active_model
        turn_cost = float((data or {}).get('total_cost_usd', 0) or 0)

        path = os.path.join(CHANNELS_DIR, channel, 'usage.json')
        prev = {}
        if os.path.exists(path):
            try:
                prev = json.load(open(path))
            except Exception:
                prev = {}
        cumulative = float(prev.get('cumulativeCostUsd', 0) or 0) + turn_cost
        ctx_pct = round(min(100.0, 100.0 * full_context / ctx_window), 1) if ctx_window else 0
        now_ts = datetime.now().isoformat()
        if cost_only:
            # Money only: keep every stored context field byte-identical.
            payload = dict(prev)
            payload['cumulativeCostUsd'] = round(cumulative, 6)
            payload['ts'] = now_ts
        else:
            payload = {
                'lastTurnInput': inp,
                'lastTurnCacheRead': cache_read,
                'lastTurnCacheCreate': cache_create,
                'lastTurnContext': full_context,
                'lastTurnOutput': out,
                'lastTurnCostUsd': round(turn_cost, 6),
                'cumulativeCostUsd': round(cumulative, 6),
                'contextWindow': ctx_window,
                'contextPct': ctx_pct,
                'activeModel': active_model,
                'ts': now_ts,
            }
            # Роздільний облік контексту (specs/agy-compaction, К7). Двигун ходу
            # називає себе сам: run_agy_stream кладе в data ключ provider, у
            # клодівських гілках його нема, тож дефолт claude і є правдою. Слот
            # чужого двигуна ЗБЕРІГАЄТЬСЯ як був, інакше кожен хід стирав би
            # лічильник сусіда і ми повернулись би до однієї спільної шкали.
            turn_provider = str((data or {}).get('provider') or 'claude').lower()
            if turn_provider not in ('claude', 'antigravity'):
                turn_provider = 'claude'
            by = prev.get('byProvider')
            by = dict(by) if isinstance(by, dict) else {}
            by[turn_provider] = {k: payload[k] for k in USAGE_CONTEXT_FIELDS}
            payload['byProvider'] = by
        atomic_write_json(path, payload)
        # Append a per-turn line to a GLOBAL usage history (foundation for the stats
        # panel). usage.json holds only the latest snapshot, so without this there is no
        # day/week history to aggregate. Best-effort; never affects the turn.
        try:
            # Дім, а не тека коду: читає цей файл панель статистики з
            # `os.path.join(DIR, 'usage-history.jsonl')` (server.py:11595). У
            # пакованій збірці тека коду це payload/, тому історія витрат лягала
            # туди, куди панель ніколи не заглядає (К2).
            hist = os.path.join(entities.data_root(), 'usage-history.jsonl')
            rec = {'ts': now_ts, 'channel': channel, 'cost': round(turn_cost, 6),
                   'in': inp, 'out': out, 'ctxPct': ctx_pct, 'model': active_model}
            if kind:
                rec['kind'] = kind
            with open(hist, 'a', encoding='utf-8') as hf:
                hf.write(json.dumps(rec, ensure_ascii=False) + '\n')
        except Exception:
            pass
        log(f'{channel}: usage{" (cost only, " + (kind or "") + ")" if cost_only else ""} '
            f'ctx={full_context} ({ctx_pct}%) '
            f'turn=${turn_cost:.4f} cum=${cumulative:.4f} model={active_model}')
    except Exception as e:
        log(f'{channel}: usage write failed: {e}')


# ---- Inline widget contract (Phase D) -------------------------------------
# The assistant structures its FINAL reply with fenced blocks whose info-string
# is `chatui`. Each block holds EITHER a JSON array of widget objects OR a single
# widget object. Blocks may be interleaved with normal markdown prose:
#
#   prose...
#   ```chatui
#   [ {"type":"verdict", ...}, {"type":"stat-grid", ...} ]
#   ```
#   more prose...
#   ```chatui
#   {"type":"conclusion","text":"...","tone":"green"}
#   ```
#
# reply_to_widgets() turns that into an ORDERED mixed widgets array:
#   - each non-empty prose segment -> {"type":"text","text": <markdown>}
#   - each chatui block -> its parsed widget item(s), spliced in order
# index.html already has ~30 live renderers dispatched by renderWidget over this
# array, so we only reconnect the last mile here (no renderer changes).
#
# Robustness: a chatui block that fails to JSON-parse, or an item without a
# "type" string, NEVER crashes the turn. We fall back to rendering that block's
# raw content as a plain text widget so the reply still lands, and continue.
# Backward compatible: a reply with ZERO chatui blocks yields exactly one text
# widget with the whole reply, identical to the pre-Phase-D behavior.

# Matches a ```chatui ... ``` fence. DOTALL so the body spans newlines; the body
# is captured non-greedily so back-to-back blocks do not merge. The opening fence
# may carry trailing spaces before the newline; the closing fence sits ON ITS OWN
# LINE. We tolerate an optional language tail like ```chatui json (rare).
#
# The closing fence is ANCHORED to its own line (MULTILINE ^...$ around it). Before
# that anchor the pattern stopped at the FIRST ``` anywhere, including one sitting
# INSIDE a JSON string: a widget whose text said "``` json видно буквально" cut the
# block in half, and the tail leaked into the feed as raw JSON
# (channels/cc-7f2413/0773.json, the single case of its kind in 10 564 messages).
# The frontend parser (lib/liveParse FENCE_CLOSE) has always been this strict, so
# the anchor also brings the two sides into agreement.
_CHATUI_FENCE = re.compile(
    r'```[ \t]*chatui[^\n]*\n(.*?)\n?[ \t]*```[ \t]*$',
    re.DOTALL | re.IGNORECASE | re.MULTILINE,
)

# A turn cut off mid-stream loses the CLOSING fence too, so the block never even
# matches _CHATUI_FENCE and the whole reply lands as one text widget.
_CHATUI_OPEN = re.compile(r'```[ \t]*chatui[^\n]*\n', re.IGNORECASE)

# ---- Fence tolerance (specs/chatui-fence-tolerance) -----------------------
# The contract says the info-string is EXACTLY `chatui`, and the model is told so
# on every turn (AGY_TURN_REMINDER). It still drifts: in chat-307 (provider
# antigravity) the engine wrote ```json around perfectly good widget objects, so
# the whole reply landed as a wall of grey code blocks. Measured over the entire
# archive on 10.09.2026: 17 193 messages, exactly 2 of them fenced that way, both
# in chat-307, both from antigravity. An instruction is a wish; the safety net has
# to live in the code.
#
# These two regexes are a LINE scanner, not a block matcher, and that is the point.
# A `(?:json)?`-flavoured version of _CHATUI_FENCE would happily start matching at
# the CLOSING fence of a neighbouring ```bash block (a bare ``` line satisfies an
# optional info-string too) and swallow everything up to the next closer. Pairing
# openers with closers line by line is the only way to get the boundaries right,
# and it is exactly what the frontend (lib/liveParse FENCE_OPEN/FENCE_CLOSE) has
# always done, so the two sides stay mirrors.
_FENCE_OPEN_LINE = re.compile(r'^[ \t]*```[ \t]*([A-Za-z0-9_-]*)')
_FENCE_CLOSE_LINE = re.compile(r'^[ \t]*```[ \t]*$')
# Info-strings we are willing to forgive. `chatui` is the contract, everything
# else here is drift; any other language (```bash, ```python, ```diff) is code the
# author meant to show.
_TOLERATED_FENCE_LANGS = ('', 'json')

# Керуючі символи, які JSON вимагає екранувати всередині рядка (R6a). Усе, що не
# має короткої форми, їде як \uXXXX.
_JSON_CTRL_ESCAPES = {'\n': '\\n', '\r': '\\r', '\t': '\\t',
                      '\b': '\\b', '\f': '\\f'}


def _repair_truncated_json(block):
    """Best-effort repair of a broken ```chatui``` block. Mirror of the frontend
    (logopsis/src/lib/jsonRepair.ts) so the live bubble and the written message
    agree on what is salvageable.

    Measured on all 10 564 messages under channels/: 35 raw-JSON leaks, of which
    27 were "Expecting ',' delimiter", 5 "Unterminated string", 2 "Extra data".
    The previous version only closed MISSING brackets and bailed out (return
    None) the moment it saw an EXTRA closer, which is exactly the dominant real
    failure:
        ...миттєво"},],[   -> a stray '}' where a ']' belonged
        ...не вбив"}},     -> a stray '}' at the top level of the array
    So there are three operations here, and exactly three: drop an unbalanced
    closer, close an unterminated string, cut a comma sitting before a closer.
    The result is ALWAYS re-validated by the caller, so a bad guess just falls
    through to the next rung of the salvage ladder.

    What is deliberately absent: inventing VALUES. Half a string never becomes a
    finished value (the jiter trailing-strings trap, langchain #34767 where
    parse_partial_json("") returned a valid {} and a tool started with empty
    args). A dangling key with no value is dropped together with its key rather
    than filled with null.

    Returns the repaired text, or None when there was nothing to repair.
    """
    body = (block or '').strip()
    if not body or body[0] not in '[{':
        return None

    out = []
    stack = []
    in_string = False
    escaped = False
    changed = False

    def last_significant():
        j = len(out) - 1
        while j >= 0 and out[j].isspace():
            j -= 1
        return j

    def drop_trailing_comma():
        nonlocal changed
        j = last_significant()
        if j >= 0 and out[j] == ',':
            del out[j]
            changed = True

    def drop_dangling_key():
        """`{"a":1,"b":` -> `{"a":1`. Cheaper and more honest than inventing null."""
        nonlocal changed
        j = last_significant()
        if j < 0 or out[j] != ':':
            return
        del out[j]
        changed = True
        j = last_significant()
        if j < 0 or out[j] != '"':
            return
        k = j - 1
        while k >= 0:
            if out[k] == '"' and (k == 0 or out[k - 1] != '\\'):
                break
            k -= 1
        if k < 0:
            return
        del out[k:j + 1]
        drop_trailing_comma()

    for ch in body:
        if in_string:
            # R6a (specs/widget-dialect-adapter/dialects.md): сирий керуючий символ
            # усередині рядкового літерала. Модель пише справжній перенос рядка чи
            # таб замість \n / \t, json.loads падає «Invalid control character»,
            # хоча зміст цілий. Екрануємо символ, а не ріжемо рядок: 2 живих випадки
            # у tests/fixtures/widget-dialects.json (cc-7f2413/1843, chat-222/0013).
            if not escaped and ch < ' ':
                out.append(_JSON_CTRL_ESCAPES.get(ch) or f'\\u{ord(ch):04x}')
                changed = True
                continue
            out.append(ch)
            if escaped:
                escaped = False
            elif ch == '\\':
                escaped = True
            elif ch == '"':
                in_string = False
            continue
        if ch == '"':
            in_string = True
            out.append(ch)
            continue
        if ch in '[{':
            stack.append(ch)
            out.append(ch)
            continue
        if ch in ']}':
            want = '[' if ch == ']' else '{'
            if not stack or stack[-1] != want:
                changed = True  # stray closer: drop it
                continue
            drop_dangling_key()
            drop_trailing_comma()
            stack.pop()
            out.append(ch)
            continue
        out.append(ch)

    if in_string:
        out.append('"')
        changed = True
    while out and out[-1].isspace():
        out.pop()
    drop_dangling_key()
    drop_trailing_comma()
    for opener in reversed(stack):
        drop_dangling_key()
        drop_trailing_comma()
        out.append(']' if opener == '[' else '}')
        changed = True

    if not changed:
        return None
    repaired = ''.join(out)
    return None if repaired == body else repaired


def _consume_json_value(src, i):
    """Index AFTER the JSON value starting at i, or -1 when it is not finished.
    A bare scalar counts as finished only when a separator follows it, so `12`
    is never mistaken for a complete value while `123` is still streaming."""
    n = len(src)
    ch = src[i]
    if ch == '"':
        j = i + 1
        while j < n:
            if src[j] == '\\':
                j += 2
                continue
            if src[j] == '"':
                return j + 1
            j += 1
        return -1
    if ch in '{[':
        depth = 0
        in_string = False
        j = i
        while j < n:
            c = src[j]
            if in_string:
                if c == '\\':
                    j += 2
                    continue
                if c == '"':
                    in_string = False
                j += 1
                continue
            if c == '"':
                in_string = True
            elif c in '{[':
                depth += 1
            elif c in '}]':
                depth -= 1
                if depth == 0:
                    return j + 1
                if depth < 0:
                    return -1
            j += 1
        return -1
    j = i
    while j < n and not src[j].isspace() and src[j] not in ',]}':
        j += 1
    return -1 if j >= n else j


def _scan_top_level_values(src):
    """Split the top level of a block into FINISHED values plus the offset of the
    unfinished tail. Returns (values, pending_start, closed) where values is a
    list of (raw, start). Works for `[a, b, c` and for a lone `{...}`."""
    n = len(src)
    i = 0
    while i < n and src[i].isspace():
        i += 1
    if i >= n:
        return [], -1, False
    if src[i] != '[':
        # R6b (specs/widget-dialect-adapter/dialects.md): модель написала кілька
        # обʼєктів підряд без масиву навколо ({...}\n\n{...}), і json.loads падає
        # «Extra data» на другому. Верхній рівень читається послідовно, і в стрічку
        # їдуть ВСІ завершені значення, а не лише перше. Живий випадок
        # chat-215/0158.json: таблиця плюс alert, з них рятується таблиця.
        vals = []
        while i < n:
            end = _consume_json_value(src, i)
            if end <= i:
                return vals, i, False
            vals.append((src[i:end], i))
            i = end
            while i < n and (src[i].isspace() or src[i] == ','):
                i += 1
        return vals, -1, True

    values = []
    pending_start = -1
    closed = False
    i += 1
    while i < n:
        while i < n and (src[i].isspace() or src[i] == ','):
            i += 1
        if i >= n:
            break
        if src[i] == ']':
            closed = True
            break
        if src[i] == '}':
            # Stray '}' between elements (the dominant real failure, 27 of 35 leaks).
            # Same operation as in the repair: drop it and keep walking.
            i += 1
            continue
        end = _consume_json_value(src, i)
        # end <= i means zero progress. Without this guard the loop spins forever and
        # eats the heap (caught by the stream test on the live leak cc-7f2413/1088).
        if end <= i:
            pending_start = i
            break
        values.append((src[i:end], i))
        i = end
    return values, pending_start, closed


def _nonempty_list(w, *keys):
    return any(isinstance(w.get(k), list) and w.get(k) for k in keys)


def _nonempty_str(w, *keys):
    return any(isinstance(w.get(k), str) and w.get(k).strip() for k in keys)


# THE GATE, step 3: required fields per type. Mirror of
# logopsis/src/lib/widgetGuard.ts — same 44 keys as widgets/registry.tsx.
# Without this a `{"type":"table"}` counts as "valid JSON" and renders an empty
# box. A type missing here is a type that silently drops out of the gate, so the
# frontend test widgetGuard.registry.test.ts walks the registry and fails on drift.
_WIDGET_VALIDATORS = {
    'verdict': lambda w: _nonempty_str(w, 'subject') and _nonempty_str(w, 'verdict'),
    'heatmap': lambda w: (_nonempty_list(w, 'cols') and _nonempty_list(w, 'rows')
                          and _nonempty_list(w, 'values')
                          and all(isinstance(r, list) for r in w['values'])),
    'funnel': lambda w: _nonempty_list(w, 'stages'),
    'journey-map': lambda w: _nonempty_list(w, 'stages'),
    'timeline': lambda w: _nonempty_list(w, 'milestones'),
    'quote-wall': lambda w: _nonempty_list(w, 'groups'),
    'stat-grid': lambda w: _nonempty_list(w, 'cards', 'stats', 'items'),
    'comparison-matrix': lambda w: (_nonempty_list(w, 'cols', 'columns')
                                    and _nonempty_list(w, 'rows')
                                    and _nonempty_list(w, 'cells')),
    'quadrant': lambda w: _nonempty_list(w, 'points'),
    'flywheel': lambda w: _nonempty_list(w, 'steps'),
    'decision': lambda w: _nonempty_list(w, 'options'),
    'callout': lambda w: _nonempty_str(w, 'text'),
    'table': lambda w: (_nonempty_list(w, 'columns') and _nonempty_list(w, 'rows')
                        and all(isinstance(r, list) for r in w['rows'])),
    'key-values': lambda w: _nonempty_list(w, 'items'),
    'badge-row': lambda w: _nonempty_list(w, 'badges'),
    'checklist': lambda w: _nonempty_list(w, 'items'),
    'progress': lambda w: _nonempty_list(w, 'bars', 'items'),
    'code-block': lambda w: isinstance(w.get('code'), str) and w.get('code') != '',
    'diff': lambda w: (_nonempty_list(w, 'files') and all(
        isinstance(f, dict) and _nonempty_str(f, 'path') and _nonempty_str(f, 'patch')
        for f in w['files'])),
    'accordion': lambda w: _nonempty_list(w, 'items'),
    'bar-chart': lambda w: _nonempty_list(w, 'bars'),
    'line-chart': lambda w: _nonempty_list(w, 'series'),
    'pie-chart': lambda w: _nonempty_list(w, 'slices'),
    'header': lambda w: _nonempty_str(w, 'title'),
    'text': lambda w: _nonempty_str(w, 'text', 'body') or _nonempty_list(w, 'body'),
    'conclusion': lambda w: _nonempty_str(w, 'text'),
    'buttons': lambda w: _nonempty_list(w, 'buttons', 'items'),
    'sources': lambda w: _nonempty_list(w, 'sources', 'items'),
    'reasoning': lambda w: (_nonempty_list(w, 'steps', 'items')
                            or _nonempty_str(w, 'body', 'summary')),
    'divider': lambda w: True,   # a rule needs no data
    'image': lambda w: _nonempty_str(w, 'src'),
    'gallery': lambda w: _nonempty_list(w, 'images'),
    'audio': lambda w: _nonempty_str(w, 'src', 'url'),
    'video': lambda w: _nonempty_str(w, 'src'),
    'file': lambda w: _nonempty_str(w, 'name', 'filename', 'title'),
    'attachments': lambda w: _nonempty_list(w, 'items'),
    'suggestions': lambda w: _nonempty_list(w, 'chips', 'items'),
    'form': lambda w: _nonempty_list(w, 'fields'),
    'phone-mockup': lambda w: _nonempty_list(w, 'messages'),
    'lean-canvas': lambda w: isinstance(w.get('blocks'), dict) and bool(w.get('blocks')),
    'prose': lambda w: _nonempty_list(w, 'blocks'),
    'reply': lambda w: _nonempty_str(w, 'snippet', 'author'),
    'ask': lambda w: _nonempty_str(w, 'question', 'title'),
    # Картка пропозиції скіла (specs/gadget-skills, S4b). Без ключа їй нема чим
    # відповісти серверу, без драфта нема чого зберігати: намальована така картка
    # була б кнопкою в нікуди.
    'skill-proposal': lambda w: (_nonempty_str(w, 'proposalKey')
                                 and isinstance(w.get('skill'), dict)
                                 and _nonempty_str(w['skill'], 'slug')),
    'voice-summary': lambda w: True,  # deprecated no-op, registry renders null
}


def _is_renderable_widget(w, model=None, log_rejection=True):
    """The full gate: an object, a type the registry knows, required fields present.
    False means we do NOT draw it. Neither an empty box nor raw JSON.

    К7 (specs/model-widget-contract/spec.md): every rejection is logged with the
    widget's type (or a "no type" mark), the reason (not an object / unknown
    type / failed the validator) and the turn's model, so a model-quality
    measurement can tell "the model drew badly" apart from "the gate silently
    dropped it". `model` is None when the caller genuinely has none to thread
    through (logged as "unknown", never a made-up default). `log_rejection=False`
    is for the internal JSON-repair stump probe below, which is documented to
    fail silently on purpose — that is our own repair artifact, not content the
    model actually lost."""
    def _reject(t, reason):
        if log_rejection:
            log(f'widget rejected: type={t or "(без типу)"} reason={reason} '
                f'model={model or "unknown"}')
        return False

    if not isinstance(w, dict):
        return _reject(None, 'не обʼєкт')
    t = w.get('type')
    if not isinstance(t, str) or t not in _WIDGET_VALIDATORS:
        return _reject(t if isinstance(t, str) and t else None, 'невідомий тип')
    try:
        ok = bool(_WIDGET_VALIDATORS[t](w))
    except Exception:
        return _reject(t, 'не пройшов валідатор')
    return ok if ok else _reject(t, 'не пройшов валідатор')


_dialect_log_lock = threading.Lock()


def _widget_dialect_log_path():
    """Файл структурованого обліку перекладів. DIR це LOGOPSIS_HOME у пакованій
    збірці і tools/viz/chat у дев-репо, тому шлях резолвиться на виклику, а не на
    імпорті (тести підміняють home)."""
    return os.path.join(DIR, widget_dialects.DIALECT_LOG_NAME)


def _log_widget_dialect(type_in, type_out, dialect, model):
    """К6 (specs/widget-dialect-adapter/spec.md): кожен переклад лишає слід, щоб нові
    діалекти було видно заміром, а не на око.

    Два сліди навмисно. Рядок у runner.out.log стоїть поруч з `widget rejected: ...`
    і того ж стилю, бо читає їх та сама людина в тому самому файлі. JSONL поруч з ним
    машиночитний: {"ts","type_in","type_out","dialect","model"}, саме його розбирає
    scripts/widget-dialects-report.cjs. Схему рядка будує сам widget_dialects, щоб
    вона жила поруч з правилами."""
    log(f'widget dialect: type={type_in or "(без типу)"}->{type_out or "(без типу)"} '
        f'dialect={dialect} model={model or "unknown"}')
    rec = widget_dialects.translation_record(
        datetime.now().isoformat(timespec='seconds'), type_in, type_out, dialect, model)
    line = json.dumps(rec, ensure_ascii=False)
    with _dialect_log_lock:
        try:
            with open(_widget_dialect_log_path(), 'a', encoding='utf-8') as fh:
                fh.write(line + '\n')
        except OSError:
            # Облік не має права завалити хід: без файла лишається рядок у лозі.
            pass


def _translate_dialect(item):
    """Шар 2 з трьох на межі: ремонт синтаксису -> АДАПТЕР ДІАЛЕКТІВ -> ворота.
    Повертає (канонічний віджет, підпис діалекту або None, вихідний віджет)."""
    out, dialect = widget_dialects.normalize_widget(item)
    return out, dialect, item


def _salvage_chatui_block(block, model=None):
    """Ladder: parse as is -> repair -> per element. Returns (widgets, leftovers),
    where leftovers are the raw pieces that could not be turned into anything
    renderable (they go into the collapsed accordion, never into the feed).

    `model` (the turn's model, or None) is threaded into every gate check so a
    rejection can be logged with it (К7); it is never invented here."""
    src = (block or '').strip()
    if not src:
        return [], []

    parsed = _MISSING = object()
    try:
        parsed = json.loads(src)
    except Exception:
        parsed = _MISSING
    repaired = False
    if parsed is _MISSING:
        fixed = _repair_truncated_json(src)
        if fixed is not None:
            try:
                parsed = json.loads(fixed)
                repaired = True
            except Exception:
                parsed = _MISSING

    if parsed is not _MISSING:
        items = parsed if isinstance(parsed, list) else [parsed]
        # THE SEAM (specs/widget-dialect-adapter, К1/К4): the dialect adapter runs
        # between a successful parse and THE GATE, so what reaches the gate (and
        # what is written into channels/<id>/*.json) is already canonical and no
        # renderer has to know a dialect exists. Translation is logged BELOW rather
        # than here, so the repair-tail stump dropped on the next line never leaves
        # a phantom К6 line about our own artifact.
        pairs = [_translate_dialect(it) for it in items]
        # Repair tail: when the block had to be fixed, its LAST element is a stump
        # we closed ourselves ({"type":"stat-gr -> {"type":"stat-gr"}). That is not
        # lost content, so it is dropped silently instead of advertised as an error
        # (log_rejection=False: this probe is not a real К7 rejection). The probe
        # runs on the NORMALIZED item: a stump in a known dialect is real content.
        if repaired and pairs and not _is_renderable_widget(pairs[-1][0], model, log_rejection=False):
            pairs = pairs[:-1]
        # One gate call per item (not two): the gate now logs on rejection, and
        # evaluating it twice per item would double every К7 log line.
        widgets, leftovers = [], []
        for it, dialect, original in pairs:
            if dialect:
                _log_widget_dialect(original.get('type'), it.get('type'), dialect, model)
            if _is_renderable_widget(it, model):
                widgets.append(it)
            else:
                # У згорнутий акордеон їде те, що написала МОДЕЛЬ, а не наш переклад:
                # людина має бачити свій же блок, а не артефакт адаптера.
                leftovers.append(json.dumps(original, ensure_ascii=False))
        return widgets, leftovers

    # Rung 3: the array as a whole is hopeless, individual elements may still live.
    values, pending_start, _closed = _scan_top_level_values(src)
    widgets, leftovers = [], []
    for raw, _start in values:
        item = None
        try:
            item = json.loads(raw)
        except Exception:
            fixed = _repair_truncated_json(raw)
            if fixed is not None:
                try:
                    item = json.loads(fixed)
                except Exception:
                    item = None
        # Той самий шов, що й у гілці вдалого розбору вище: спершу адаптер, потім
        # ворота. Без цього віджет, врятований поелементно (наприклад таблиця з
        # блоку «два обʼєкти підряд», R6b), доїжджав би до воріт у діалекті.
        item, dialect, original = _translate_dialect(item)
        if dialect:
            _log_widget_dialect(original.get('type'), item.get('type'), dialect, model)
        if _is_renderable_widget(item, model):
            widgets.append(item)
        else:
            leftovers.append(raw)
    if pending_start >= 0:
        tail = src[pending_start:].strip()
        if tail:
            leftovers.append(tail)
    if not widgets and not leftovers:
        leftovers.append(src)
    return widgets, leftovers


def _broken_block_card(raw, channel=None):
    """The last line of defence, replacing push_prose(raw JSON). A human sentence
    plus the raw block inside a COLLAPSED accordion: nothing is lost, the feed
    stays clean."""
    return [
        {
            'type': 'callout',
            'variant': 'warning',
            'title': _bt({'uk': 'Віджет не вдалось відмалювати',
                          'en': 'Could not render the widget'}, channel),
            'text': _bt({
                'uk': 'Модель віддала пошкоджений блок, і полагодити його не вийшло. '
                      'Сам вміст нижче, згорнутий, щоб не засмічувати стрічку.',
                'en': 'The model returned a broken block and it could not be repaired. '
                      'The raw content is below, collapsed so it does not clutter the feed.',
            }, channel),
        },
        {
            'type': 'accordion',
            'detail': True,
            'items': [{'title': _bt({'uk': 'Сирий блок', 'en': 'Raw block'}, channel),
                       'body': '```json\n' + raw + '\n```'}],
        },
    ]


def _close_dangling_chatui_fence(text):
    """Append the missing closing fence when the reply was cut off inside a
    ```chatui block, so the truncated JSON still reaches the repair above.
    A dangling opener means everything after it IS the block (there is nothing
    left to swallow); when the fence is properly closed this is a no-op."""
    opens = list(_CHATUI_OPEN.finditer(text))
    if not opens or '```' in text[opens[-1].end():]:
        return text
    return text.rstrip() + '\n```'


def _coerce_widget_items(parsed):
    """Normalize a parsed chatui block (array or single object) into a list of
    widget dicts. Returns (items, ok). ok is False when the shape is unusable or
    any item lacks a string "type", so the caller can fall back to raw text.

    Kept for callers that only need the shape check; the render decision itself
    lives in _is_renderable_widget (the gate)."""
    if isinstance(parsed, dict):
        items = [parsed]
    elif isinstance(parsed, list):
        items = parsed
    else:
        return [], False
    out = []
    for it in items:
        if not isinstance(it, dict) or not isinstance(it.get('type'), str) or not it.get('type'):
            return [], False
        out.append(it)
    return out, bool(out)


def _scan_fence_blocks(text):
    """Walk the reply line by line and pair every fence opener with its closer.

    Returns a list of dicts {lang, start, body_start, body_end, end}, where `start`
    is the offset of the opening fence line, `end` the offset just past the closing
    fence (before its newline), and body_start/body_end delimit the block body. An
    opener with no closer is NOT reported: half a block is not a block.

    Mirror of the scanner in logopsis/src/lib/liveParse.ts, deliberately: both sides
    read the SAME reply text, so a boundary rule that lives on one side only means
    the live bubble and the written message disagree about what a block even is."""
    out = []
    offset = 0
    open_fence = None
    for line in (text or '').split('\n'):
        line_start = offset
        offset += len(line) + 1        # +1 for the \n eaten by split
        if open_fence is None:
            m = _FENCE_OPEN_LINE.match(line)
            if m:
                open_fence = {'lang': (m.group(1) or '').lower(),
                              'start': line_start, 'body_start': offset}
            continue
        if not _FENCE_CLOSE_LINE.match(line):
            continue
        open_fence['body_end'] = line_start
        open_fence['end'] = line_start + len(line)
        out.append(open_fence)
        open_fence = None
    return out


def _widget_json_block_types(body):
    """The registry test behind fence tolerance: is this block widgets that merely
    got the wrong fence name? Returns the list of canonical types, or [] for "no".

    Deliberately STRICT, because the cost of a false positive is a documentation
    example silently turning into a card (non-goal #1 of the spec):
      - the body must parse as JSON AS IS. No repair ladder here: a block that is
        both mis-fenced AND broken stays code;
      - it must be an object or a NON-EMPTY array of objects;
      - EVERY element must pass THE GATE. One element that does not disqualifies
        the whole block (К3) rather than half-rendering it.

    THE GATE, not merely "the type is in the registry", and that is a deliberate
    tightening of К1's literal wording. `{"type": "table"}` with no columns and no
    rows is the canonical way a schema is DOCUMENTED, and non-goal #1 says such a
    block must stay code. Reading К1 literally would turn it into a yellow "could
    not render" card, i.e. break the non-goal to satisfy the criterion. With the
    full gate the two hold together and tolerance gains a clean invariant: it never
    produces a fallback card, it either yields real widgets or leaves the block
    alone. The chat-307 content this exists for passes the gate anyway.

    The registry and the required fields both come from _WIDGET_VALIDATORS, the
    single source of truth the gate itself uses, so a new widget type is forgiven
    here the day it is added and never needs a second hand-written list. The check
    runs AFTER the dialect adapter, the same seam as _salvage_chatui_block, so a
    block written in a known dialect is judged by what it will actually become.
    `log_rejection=False`: a block we decide to leave as CODE is not a rejected
    widget, and logging it as one would pollute the К7 model-quality measurement
    with every JSON snippet anybody ever pastes."""
    src = (body or '').strip()
    if not src or src[0] not in '[{':
        return []
    try:
        parsed = json.loads(src)
    except Exception:
        return []
    items = parsed if isinstance(parsed, list) else [parsed]
    if not items:
        return []
    types = []
    for it in items:
        norm, _dialect = widget_dialects.normalize_widget(it)
        if not isinstance(norm, dict):
            return []
        if not _is_renderable_widget(norm, log_rejection=False):
            return []
        types.append(norm.get('type'))
    return types


def _tolerated_widget_blocks(text, model=None):
    """Fence tolerance, the whole of it: the ```json (or bare ```) blocks in a reply
    that carries no ```chatui``` at all and that are unmistakably widgets.

    Returns the same (start, end, body) triples the chatui path produces, so the
    caller treats both kinds identically and the salvage ladder, the dialect
    adapter and THE GATE all still run over the content unchanged.

    К5: every hit is logged. A silent safety net would hide the engine drift it
    exists to absorb, and drift you cannot count is drift you cannot fix at the
    source. The `fence tolerance:` prefix is the countable token."""
    out = []
    for f in _scan_fence_blocks(text):
        if f['lang'] not in _TOLERATED_FENCE_LANGS:
            continue
        body = text[f['body_start']:f['body_end']]
        types = _widget_json_block_types(body)
        if not types:
            continue
        log(f'fence tolerance: block ```{f["lang"] or "(no lang)"} parsed as chatui, '
            f'{len(types)} widget(s) types={",".join(types)} model={model or "unknown"}')
        out.append((f['start'], f['end'], body))
    return out


def reply_to_widgets(text, model=None, channel=None):
    """Parse the assistant's final markdown reply into an ORDERED mixed widgets
    array, splitting on ```chatui``` fenced blocks (see contract above).

    - prose between/around blocks -> text widgets (markdown preserved verbatim)
    - each chatui block -> the widgets that PASS THE GATE, spliced in order
    - anything that cannot be rendered -> one honest callout plus the raw block
      inside a collapsed accordion. push_prose(raw JSON) is forbidden: dumping a
      wall of JSON into the feed is the very bug this path exists to kill
      (owner decision, 2026-08-05)
    - zero chatui blocks -> single text widget with the whole reply (back-compat)

    `model` is the turn's model (an alias like "sonnet" or a full model id);
    pass it whenever the caller has it so a gate rejection is logged with it
    (К7, specs/model-widget-contract/spec.md). Left as None when the caller has
    no model to give — that logs "model=unknown" rather than a guess.
    """
    if not text or not text.strip():
        return [{'type': 'text', 'text': _bt({'uk': '(порожня відповідь)', 'en': '(empty reply)'}, channel)}]

    text = _close_dangling_chatui_fence(text)
    widgets = []
    last_end = 0

    def push_prose(segment):
        seg = (segment or '').strip()
        if seg:
            widgets.append({'type': 'text', 'text': seg})

    # THE BLOCK LIST. Normally it is exactly the ```chatui``` fences. When the reply
    # has NONE of them, fence tolerance gets a turn (specs/chatui-fence-tolerance, К1):
    # ```json blocks whose content is unmistakably widgets are treated as if they had
    # been fenced correctly. The "none of them" condition IS К2: the moment the author
    # used the real fence even once, every json block in that reply is a deliberate
    # example and stays code. Everything downstream (salvage ladder, dialect adapter,
    # THE GATE) is identical for both kinds, so tolerance forgives the fence NAME and
    # nothing else.
    blocks = [(m.start(), m.end(), m.group(1) or '') for m in _CHATUI_FENCE.finditer(text)]
    if not blocks:
        blocks = _tolerated_widget_blocks(text, model)

    for start, end, body in blocks:
        # prose before this fence
        push_prose(text[last_end:start])
        last_end = end

        block = body.strip()
        if not block:
            continue
        good, leftovers = _salvage_chatui_block(block, model)
        if leftovers:
            log(f'reply_to_widgets: {len(good)} widget(s) recovered, '
                f'{len(leftovers)} piece(s) unrenderable -> collapsed fallback card')
        widgets.extend(good)
        if leftovers:
            widgets.extend(_broken_block_card('\n\n'.join(leftovers), channel))

    # trailing prose after the last fence (or the whole reply if no fences)
    push_prose(text[last_end:])

    # Guard: an all-whitespace reply that somehow produced nothing.
    if not widgets:
        return [{'type': 'text', 'text': text.strip() or _bt({'uk': '(порожня відповідь)',
                                                                'en': '(empty reply)'}, channel)}]
    return widgets


def text_to_widgets(text, model=None):
    """Backward-compatible alias. Phase D routes the final reply through
    reply_to_widgets(), which parses inline ```chatui``` blocks into a mixed
    widget array. A reply with no such block renders exactly as before."""
    return reply_to_widgets(text, model)


# ---- Declarative PLAN sidebar (Variant A) ---------------------------------
# The assistant DECLARES its plan as a fenced ```plan``` block of JSON (a full
# snapshot each turn). The RUNNER is the SOLE writer of channels/<id>/plan.json:
# it extracts the block, strips it from the visible reply, and persists it via the
# ONE canonical writer plan_store.write_plan (DRY: no re-implementation of the schema).
# Design patterns: single-source-of-truth / SRP (one writer), dependency inversion
# (assistant emits abstract data, knows nothing of files/scripts), least privilege
# (assistant executes nothing), best-effort/fail-safe (a bad/absent block never
# crashes a turn nor corrupts an existing plan.json).
#
# The info-string must be EXACTLY `plan` (optional surrounding spaces/tabs, then a
# newline), so `planning` / `chatui` never match. DOTALL so the body spans lines;
# the body is captured non-greedily so stacked blocks do not merge.
_PLAN_FENCE = re.compile(
    r'```[ \t]*plan[ \t]*\n(.*?)\n?```',
    re.DOTALL | re.IGNORECASE,
)

# The canonical plan writer (reused, never re-implemented). An IN-PROCESS import, not
# a subprocess: the previous `node set-plan.cjs` shell-out died silently in the packaged
# desktop, which had neither that file in its payload nor any guarantee of node.
try:
    import plan_store as _plan_store
except Exception:          # module missing -> a turn must still complete
    _plan_store = None


def extract_plan_block(text):
    """Split a ```plan``` declaration out of the assistant reply.

    Returns (clean_text, plan_json_str_or_None):
      - clean_text: the reply with ALL plan blocks removed and stray blank lines
        collapsed, so the block never renders as a bubble nor leaks into TTS.
      - plan_json_str: the raw JSON of the LAST plan block (the authoritative full
        snapshot when a reply somehow carries more than one), or None when there
        is no non-empty plan block.
    Pure/side-effect-free: safe to call anywhere, never raises on odd input."""
    if not text:
        return text, None
    matches = [m for m in _PLAN_FENCE.finditer(text) if (m.group(1) or '').strip()]
    if not matches:
        return text, None
    plan_json = matches[-1].group(1).strip()
    clean = _PLAN_FENCE.sub('', text)
    clean = re.sub(r'\n{3,}', '\n\n', clean).strip()
    return clean, (plan_json or None)


def persist_plan_declaration(channel, plan_json_str):
    """Persist a declared plan snapshot to channels/<id>/plan.json via plan_store
    (the SINGLE canonical writer). Best-effort and fail-safe: a malformed/empty
    block is validated here and skipped (logged) so it never reaches the writer and
    never corrupts an existing plan.json. Returns True only when the write succeeded.

    plan_store resolves the channels dir from LOGOPSIS_HOME exactly like this module
    does, so the desktop writes into the user's data home and dev writes into the repo.
    That is the second half of the 2026-08-04 fix: the old writer resolved its target
    from its own location on disk, which is only correct when code and data coincide."""
    if not plan_json_str or not plan_json_str.strip():
        return False
    # Validate here so a broken block never even reaches the writer.
    try:
        parsed = json.loads(plan_json_str)
    except Exception as e:
        log(f'{channel}: plan block invalid JSON, skipped ({e})')
        return False
    if not isinstance(parsed, dict):
        log(f'{channel}: plan block is not a JSON object, skipped')
        return False
    if _plan_store is None:
        log(f'{channel}: plan not persisted (plan_store module unavailable)')
        return False
    try:
        done, total = _plan_store.write_plan(channel, parsed, CHANNELS_DIR)
        log(f'{channel}: plan persisted ({parsed.get("goal") or ""} — {done}/{total} done)')
        return True
    except Exception as e:
        log(f'{channel}: plan persist failed ({e})')
        return False


def finalize_plan_declaration(channel, text):
    """Turn-finalize hook: extract any ```plan``` declaration from the assistant
    reply, persist it (single writer, best-effort), and return the reply with the
    block(s) STRIPPED so they never render as a bubble nor leak into TTS/retell.
    No plan block -> text unchanged and the existing plan.json is left untouched.

    Returns (clean_text, plan_declared) where plan_declared is True iff a non-empty
    ```plan``` block was found and persisted this turn. The caller uses that flag to
    tell a legit plan-only turn (skip the empty chat bubble, the sidebar is the
    output) apart from a genuine empty-reply whiff."""
    clean, plan_json = extract_plan_block(text)
    if plan_json is not None:
        persist_plan_declaration(channel, plan_json)
    return clean, (plan_json is not None)


# ---- channel storage (mirrors server.py / render-message.sh) ----

def channel_index_path(channel):
    return os.path.join(CHANNELS_DIR, channel, 'index.json')


def _channel_voice_auto(channel):
    """True when the channel's «Голосовий режим» toggle (channels/<id>/voice-auto) is ON."""
    try:
        v = open(os.path.join(CHANNELS_DIR, channel, 'voice-auto')).read().strip().lower()
        return v in ('1', 'true', 'yes', 'on')
    except Exception:
        return False


def _voice_speakable(text):
    """Turn the reply's OWN markdown text into a clean speakable string for TTS.
    This reads the ACTUAL message text verbatim (no LLM rephrasing/summary) and only
    strips non-speakable markdown noise: code fences, **bold**, *italic*, headings,
    bullets, links, em/en-dashes. Every word stays; only the symbols go."""
    import re
    t = (text or '')
    t = re.sub(r'```[\s\S]*?```', ' ', t)                 # fenced code blocks
    t = re.sub(r'`([^`]+)`', r'\1', t)                    # inline code
    t = re.sub(r'!?\[([^\]]+)\]\([^)]*\)', r'\1', t)      # [label](url) / images -> label
    t = re.sub(r'(\*\*|__)(.*?)\1', r'\2', t)             # **bold** / __bold__
    t = re.sub(r'(\*|_)(.*?)\1', r'\2', t)                # *italic* / _italic_
    t = re.sub(r'^[ \t]*#{1,6}[ \t]+', '', t, flags=re.M) # # headings
    t = re.sub(r'^[ \t]*[-*•+][ \t]+', '', t, flags=re.M) # - / * / • bullets
    t = re.sub(r'^[ \t]*>[ \t]?', '', t, flags=re.M)      # > blockquotes
    t = t.replace('—', ', ').replace('–', ', ')           # HARD: never em-dash in TTS
    t = re.sub(r'[ \t]+', ' ', t)
    t = re.sub(r'\n{2,}', '\n', t).strip()
    return t


def maybe_attach_voice(channel, widgets, text):
    """If voice-auto is ON for the channel, synth `text` via /api/voice (OpenAI onyx)
    and append an `audio` widget to `widgets` so the player sits ON THE SAME reply
    card. Graceful: never raises, bounded timeout, never blocks/fails the reply on a
    TTS error. There is no fallback engine any more (owner decision, 2026-08-03: /api/voice is
    OpenAI-only, on the user's own key), so no key simply means no audio widget.

    Owner decision, 2026-07-12: DISABLED. The bottom «🎙 Аудіо-версія» player was redundant with
    the on-demand «Переказати» button and TTS-ed every reply regardless of listening.
    Voice is on-demand only now; the voice-auto flag still drives the «Переказати»
    button in the UI. Flip AUTO_VOICE_APPEND to True to restore."""
    AUTO_VOICE_APPEND = False
    try:
        if not AUTO_VOICE_APPEND:
            return widgets
        if not _channel_voice_auto(channel) or not isinstance(widgets, list):
            return widgets
        say = _voice_speakable(text)   # the reply's OWN words, markdown stripped — NOT a summary
        if not say:
            return widgets
        if len(say) > 1500:
            say = say[:1500]
        import urllib.request
        # Text only: engine/voice/instructions come from the /api/voice default
        # (OpenAI gpt-4o-mini-tts «onyx» since 2026-07-28).
        body = json.dumps({'text': say}).encode('utf-8')
        req = urllib.request.Request(
            'http://127.0.0.1:%s/api/voice' % PERM_PORT, data=body,
            headers={'Content-Type': 'application/json'}, method='POST')
        with urllib.request.urlopen(req, timeout=25) as resp:
            data = json.loads(resp.read().decode('utf-8'))
        url = data.get('url')
        if url:
            widgets.append({'type': 'audio', 'src': url,
                            'engine': data.get('engine', 'openai'),
                            'title': _bt({'uk': '🎙 Аудіо-версія', 'en': '🎙 Audio version'}, channel),
                            'transcript': say})
            log(f'{channel}: voice-auto attached audio -> {url}')
    except Exception as e:
        log(f'{channel}: voice-auto skipped ({e})')
    return widgets


def compaction_divider_widget(freed_pct=None, channel=None):
    """Build the explicit compaction stream item. The frontend renders type
    'compaction-divider' as a thin V3 chip divider (NOT a chat bubble). The
    `text` field is kept so any older/unknown renderer degrades to a plain line
    instead of an empty card. `freedPct` (the running context % right BEFORE the
    compaction) + `ts` feed the hover detail ("Звільнено ~N% · HH:MM").

    No em-dash anywhere by request (periods/commas only)."""
    w = {'type': 'compaction-divider',
         'text': _bt({'uk': '♻️ Контекст стиснуто (звільнив місце для нових повідомлень).',
                      'en': '♻️ Context compacted (freed room for new messages).'}, channel),
         'ts': datetime.now().strftime('%H:%M')}
    try:
        if freed_pct is not None:
            fp = int(round(float(freed_pct)))
            if fp > 0:
                w['freedPct'] = fp
    except Exception:
        pass
    return w


# Довжина сніпета якоря. Рядок мусить лишитись ОДНИМ рядком у бульбашці, тому обрізаємо
# вже на записі: фронт додатково ставить CSS-обрізання, але покладатись лише на нього не
# можна (у вузькій колонці 400 символів у DOM це 400 символів у DOM).
ANCHOR_SNIPPET_MAX = 90


def _widgets_snippet(widgets, limit=ANCHOR_SNIPPET_MAX):
    """Початок тексту бульбашки користувача для рядка-якоря.

    Беремо ТІЛЬКИ `text`-віджети. Віджет `reply` свідомо пропущено: у бульбашці, де
    Людина відповідає на чужий меседж, згори лежить цитата ЧУЖОГО тексту, і якір показав
    би не те, що вона написала, а те, що процитувала. Коли тексту немає взагалі
    (меседж з самих вкладень), підписуємось іменами файлів, щоб якір не був німим."""
    parts = []
    for w in widgets or []:
        if not isinstance(w, dict):
            continue
        if w.get('type') == 'text' and isinstance(w.get('text'), str):
            parts.append(w['text'])
    if not parts:
        for w in widgets or []:
            if isinstance(w, dict) and w.get('type') == 'attachments':
                parts += [str(i.get('name') or '') for i in (w.get('items') or [])
                          if isinstance(i, dict)]
    s = re.sub(r'\s+', ' ', ' '.join(p for p in parts if p)).strip()
    return (s[:limit] + '…') if len(s) > limit else s


def reply_anchor(channel, msg_id):
    """Якір «ця відповідь на це повідомлення» для запису бульбашки-відповіді.

    Ідентифікатор НЕ вигадуємо і не рахуємо евристикою «попередня бульбашка»: беремо
    рівно той `user_msg_id`, що вже лежить у файлі черги і яким уже користується
    mark_turn_failed. Сніпет читаємо з самої бульбашки користувача, а не з тексту
    черги: у чергу їде промпт із вшитою цитатою-контекстом і вмістом текстових
    вкладень, тобто не те, що людина бачить у себе в стрічці.

    None = якоря не буде, і це НОРМАЛЬНИЙ стан (службовий хід, картка агента, меседж
    видалили посеред ходу). Фронт у такому разі малює бульбашку рівно як раніше."""
    if msg_id is None:
        return None
    try:
        mid = int(msg_id)
    except (TypeError, ValueError):
        return None
    try:
        idx_path = channel_index_path(channel)
        if not os.path.exists(idx_path):
            return None
        with open(idx_path, encoding='utf-8') as f:
            items = json.load(f) or []
        fname = next((i.get('file') for i in items
                      if isinstance(i, dict) and i.get('id') == mid), None)
        if not fname:
            return None
        with open(os.path.join(CHANNELS_DIR, channel, fname), encoding='utf-8') as f:
            widgets = json.load(f)
        return {'id': mid, 'snippet': _widgets_snippet(widgets)}
    except Exception as e:
        log(f'{channel}: reply-anchor error: {e}')
        return None


def drain_quiet_actions(channel, ch_dir, fname):
    """Забрати журнал тихих дій ходу і прикріпити його до цієї бульбашки.

    S2 спеки `specs/quiet-permissions`. Гейт (`hooks/_actions.cjs`) накопичує в
    `actions-pending.jsonl` рівно ті дії, які РАНІШЕ зупинили б людину питанням.
    Тут вони переїжджають у `NNNN.actions.json` поруч із повідомленням, тобто
    журнал завжди прикріплений до конкретної бульбашки, а не висить окремою
    стрічкою, якої ніхто не читає.

    В index.json іде тільки ЛІЧИЛЬНИК, а не самі рядки: index читається кожні дві
    секунди на кожному поллінгу, і складати туди тексти всіх дій усіх ходів
    означало б платити за підсумок щосекунди. Деталі фронт тягне окремо і лише
    коли людина розгорнула (К8-К9 спеки).

    Повертає {'total': N, 'attention': M} або None, коли тихих дій не було.
    НІКОЛИ не кидає: збій журналу не сміє коштувати записаної відповіді."""
    try:
        pending = os.path.join(ch_dir, 'actions-pending.jsonl')
        if not os.path.exists(pending):
            return None
        rows = []
        with open(pending, encoding='utf-8') as f:
            for line in f:
                line = line.strip()
                if not line:
                    continue
                try:
                    rec = json.loads(line)
                except Exception:
                    continue
                if isinstance(rec, dict) and rec.get('text'):
                    rows.append(rec)
        try:
            os.remove(pending)
        except OSError:
            pass
        if not rows:
            return None
        base = os.path.splitext(fname)[0]
        atomic_write_json(os.path.join(ch_dir, f'{base}.actions.json'), rows)
        return {'total': len(rows),
                'attention': sum(1 for r in rows if r.get('level') == 'attention')}
    except Exception as e:
        log(f'{channel}: журнал тихих дій не прикріпився: {e}')
        return None


def _turn_model(data):
    """Модель, яка реально відповіла цим ходом (specs/model-widget-contract, S5).

    Ground truth, не те, що канал ПРОСИВ (channel_model): модель могла піти на
    фолбек (safe-retry, сімейний фолбек Bedrock), а `modelUsage` заповнює сам
    CLI/SDK на першій же відповіді моделі (agy синтезує так само, див.
    run_agy_stream), ключ — реальний id. Той самий принцип, яким уже користується
    write_usage для знаменника метра контексту: при кількох ключах (фолбек
    усередині ходу) бере той з найбільшим contextWindow. Порожньо/нема
    modelUsage -> None, і поле в записі просто не зʼявляється — вигадувати
    значення для цього ходу заборонено (S5).

    Першим іде `turnModel` (поле `model` останнього assistant-повідомлення ходу,
    кладуть двигуни SDK/warm/stream): `modelUsage` накопичується за всю
    resumed-сесію, і після зміни моделі на нічиїй contextWindow вигравав
    перший, тобто СТАРИЙ ключ (chat-385, opus-5 замість opus-5-5)."""
    tm = (data or {}).get('turnModel')
    if isinstance(tm, str) and tm and tm != '<synthetic>':
        return tm
    mu = (data or {}).get('modelUsage')
    if not isinstance(mu, dict) or not mu:
        return None
    best_name, best_window = None, -1
    for name, m in mu.items():
        if not isinstance(m, dict):
            continue
        cw = int(m.get('contextWindow') or 0)
        if cw > best_window:
            best_window = cw
            best_name = name
    return best_name or next(iter(mu.keys()), None)


def append_message(channel, widgets, frm='Claude', tag=None, reply_to=None, qid=None,
                    model=None):
    ch_dir = os.path.join(CHANNELS_DIR, channel)
    os.makedirs(ch_dir, exist_ok=True)
    normalize_media(widgets)
    idx_path = channel_index_path(channel)
    items = []
    if os.path.exists(idx_path):
        try:
            items = json.load(open(idx_path))
        except Exception:
            items = []
    ids = [i.get('id', 0) for i in items]
    for f in glob.glob(os.path.join(ch_dir, '[0-9]*.json')):
        m = re.match(r'(\d+)', os.path.basename(f))
        if m:
            ids.append(int(m.group(1)))
    nxt = (max(ids) + 1) if ids else 1
    fname = f'{nxt:04d}.json'
    atomic_write_json(os.path.join(ch_dir, fname), widgets)
    items = [i for i in items if i.get('file') != fname]
    rec = {'id': nxt, 'file': fname,
           'timestamp': datetime.now().strftime('%H:%M:%S'),
           'from': frm, 'tag': tag or None}
    # Ключа НЕМА, коли якоря нема (а не порожній обʼєкт): відсутність поля це і є
    # контракт «малюй як раніше» для старої історії і службових ходів.
    if reply_to:
        rec['replyTo'] = reply_to
    # Модель, якою зроблено САМЕ ЦЕ повідомлення (specs/model-widget-contract, S5).
    # Поля НЕМА, коли модель невідома (виклик без model=, службовий хід, картка не
    # від двигуна): відсутність поля це нормальний стан для старої історії і для
    # меседжів, написаних не раннером, а НЕ привід підставляти вгадану модель.
    if model:
        rec['model'] = model
    # З якого елемента черги виросла ця бульбашка (specs/queue-order-pairs, S3). Поле
    # службове і несе рівно одну відповідальність: дає впізнати вже записаний промпт,
    # якщо раннер помер між записом бульбашки і оновленням файлу черги. Без нього такий
    # рестарт написав би той самий промпт удруге.
    if qid:
        rec['qid'] = qid
    # Підсумок тихих дій цього ходу (specs/quiet-permissions, К6). Поля НЕМА,
    # коли тихих дій не було, і це нормальний стан: бульбашка малюється як раніше.
    #
    # НЕ на бульбашці людини. Журнал розповідає, що зробив ДВИГУН, тому місце йому
    # лише на бульбашці двигуна. Практичний бік: якщо хід помер, не написавши
    # відповіді, накопичене лишається в pending, і наступний промпт людини забрав
    # би його собі. Людина побачила б у власному повідомленні «Виконано 3 дії»,
    # яких вона не робила. Спіймано на живому прогоні доказів, а не в теорії.
    if frm != 'Я':
        actions = drain_quiet_actions(channel, ch_dir, fname)
        if actions:
            rec['actions'] = actions
    items.append(rec)
    items.sort(key=lambda i: i['id'])
    atomic_write_json(idx_path, items)
    return nxt


def bubble_key(job):
    """Ключ ідемпотентності бульбашки для цього елемента черги.

    `qid` це ІМʼЯ ФАЙЛУ в теці черги («0001»), а нумерація починається з нуля щоразу,
    коли черга спорожніла. Тобто в межах каналу `0001` повторюється стільки разів,
    скільки разів людина щось питала, і пошук по ньому в index.json міг знайти бульбашку
    ПОЗАМИНУЛОГО ходу і вирішити, що промпт уже записаний.

    Тому ключ несе окреме поле `buid`, унікальне на канал (ставить server.py у /api/send).
    Старі файли черги його не мають, і для них лишається `qid`: гірше, ніж нове, але точно
    не гірше, ніж було. Той самий ключ лягає у `index.json`, тому бульбашку впізнають
    ОБИДВІ сторони, хто б її не написав першим (К2)."""
    if not isinstance(job, dict):
        return None
    return job.get('buid') or job.get('qid')


def bubble_widgets_for_job(job):
    """Віджети бульбашки промпту: готові з черги, інакше зібрані з тексту.

    Порожнє поле `bubble` НЕ дає права мовчки пропустити запис. Текст промпту у файлі
    черги є завжди, тож бульбашку є з чого зібрати, і людина побачить своє питання навіть
    тоді, коли віджети до неї не доїхали (старий файл черги, аварія при записі, чужий
    продюсер елемента черги)."""
    if not isinstance(job, dict):
        return None
    bubble = job.get('bubble')
    if isinstance(bubble, list) and bubble:
        return bubble
    text = (job.get('text') or '').strip()
    if not text:
        return None
    return [{'type': 'text', 'text': text}]


def mark_prompt_stopped(channel, msg_id):
    """Позначити бульбашку промпту як таку, на яку відповіді не буде (index.json).

    Дзеркалить server._mark_messages_stopped (те саме поле `stopped`, та сама мітка в UI).
    Потрібне саме тут, бо промпт може померти не лише кнопкою Стоп на сервері, а й у
    самому раннері: зняли busy, у файлі черги немає session-id. Best-effort: провал мітки
    не сміє зламати обробку черги."""
    if msg_id is None:
        return False
    try:
        idx_path = channel_index_path(channel)
        if not os.path.exists(idx_path):
            return False
        with open(idx_path, encoding='utf-8') as f:
            items = json.load(f) or []
        if not isinstance(items, list):
            return False
        hit = False
        for it in items:
            if isinstance(it, dict) and it.get('id') == msg_id and not it.get('stopped'):
                it['stopped'] = True
                hit = True
        if hit:
            atomic_write_json(idx_path, items)
        return hit
    except Exception as e:
        log(f'{channel}: не вдалось позначити промпт {msg_id} зупиненим: {e}')
        return False


def rescue_prompt_bubble(channel, job, why):
    """Промпт вибуває з черги, не діставшись ходу: зберегти його у стрічці з міткою (К3).

    Доти будь-який шлях, яким job покидав чергу без виконання (зняли busy, немає
    session-id), просто видаляв файл, і питання людини зникало назавжди: писати бульбашку
    було вже нікому, бо це робить сам хід. Тепер промпт лягає у стрічку тим самим записом
    і з тим самим ключем ідемпотентності, тож дубля не буде навіть якщо його встиг
    записати сервер запобіжником К1."""
    if not isinstance(job, dict):
        return None
    mid = job.get('user_msg_id')
    if mid is None:
        key = bubble_key(job)
        mid = _msg_id_for_qid(channel, key)
        if mid is None:
            widgets = bubble_widgets_for_job(job)
            if not widgets:
                log(f'{channel}: {why}: у елемента черги нема ні віджетів, ні тексту — '
                    f'рятувати нема чого')
                return None
            mid = append_message(channel, widgets, frm='Я', qid=key)
    log(f'{channel}: {why}: промпт збережено у стрічці (id={mid}) і позначено')
    mark_prompt_stopped(channel, mid)
    return mid


def _msg_id_for_qid(channel, qid):
    """id бульбашки, яку вже записали для цього елемента черги (або None)."""
    if not qid:
        return None
    try:
        idx_path = channel_index_path(channel)
        if not os.path.exists(idx_path):
            return None
        with open(idx_path, encoding='utf-8') as f:
            items = json.load(f) or []
        return next((i.get('id') for i in items
                     if isinstance(i, dict) and i.get('qid') == qid), None)
    except Exception:
        return None


def claim_prompt_bubble(channel, qf, job):
    """Записати бульбашку промпту в мить, коли черга ДІЙШЛА до нього (S3).

    Досі меседж писав `/api/send`, тобто позиція у стрічці фіксувалась часом
    надсилання. Пачка з пʼяти промптів давала пʼять бульбашок «Я» підряд, а потім пʼять
    відповідей підряд, і зіставити «що на що» можна було лише клікнувши по якорю. Тепер
    промпт лягає у стрічку рівно перед своїм ходом, тож виходить Я, Клод, Я, Клод.

    Ідемпотентно ТРИЧІ, бо між записом бульбашки і оновленням файлу черги процес може
    померти, а ще бульбашку міг написати сам сервер (запобіжник К1): (1) job з
    проставленим `user_msg_id` вже опрацьований, (2) бульбашку з тим самим ключем шукаємо
    в індексі і переюзаємо, (3) ключ наскрізний (`buid`), тож він однаковий у сервера і в
    раннера. Старий файл черги (є `user_msg_id`, нема `bubble`) проходить першою гілкою,
    тобто працює точно як раніше.

    Ключ це `bubble_key`, а НЕ голий `qid`: імʼя файлу в черзі повторюється щоразу, коли
    черга спорожніла, тому пошук по ньому міг знайти бульбашку минулого ходу.

    Повертає id бульбашки або None, коли писати нема чого (службовий job)."""
    if job.get('user_msg_id') is not None:
        return job.get('user_msg_id')
    bubble = bubble_widgets_for_job(job)
    if not bubble:
        # МОВЧАЗНОГО пропуску тут більше немає: раніше стояло голе `return None`, і промпт
        # зникав зі стрічки без жодного сліду в логу. Тепер порожній `bubble` лікується
        # текстом промпту (bubble_widgets_for_job), а сюди доходить лише справді порожній
        # елемент черги, і про нього видно запис.
        log(f'{channel}: елемент черги без бульбашки і без тексту '
            f'(qid={job.get("qid")}) — у стрічку писати нічого')
        return None
    if not job.get('bubble'):
        log(f'{channel}: у елемента черги qid={job.get("qid")} немає готових віджетів — '
            f'зібрав бульбашку з тексту промпту')
    qid = bubble_key(job)
    mid = _msg_id_for_qid(channel, qid)
    if mid is None:
        mid = append_message(channel, bubble, frm='Я', qid=qid)
        # Службові рядки цього ж ходу (зараз це рядок вибору учасника кімнати) лягають
        # ОДРАЗУ ПІСЛЯ промпту, як і до правки. Пишемо їх лише разом із самим промптом:
        # переживши аварію рівно між цими двома записами, ми втратимо пояснювальний
        # рядок, але не питання людини і не пару «промпт-відповідь».
        for note in (job.get('notes') or []):
            if isinstance(note, dict) and note.get('widgets'):
                append_message(channel, note['widgets'],
                               frm=note.get('from') or 'Система',
                               tag=note.get('tag'))
    job['user_msg_id'] = mid
    # Оновлений файл черги = страховка на випадок рестарту посеред ходу: наступний
    # захід побачить проставлений id і не напише бульбашку вдруге. Помилка запису тут
    # не фатальна, бо ту саму роль грає `qid` в індексі.
    try:
        with open(qf, 'w', encoding='utf-8') as f:
            json.dump(job, f, ensure_ascii=False)
    except Exception as e:
        log(f'{channel}: не вдалось оновити файл черги після запису промпту: {e}')
    return mid


def clear_busy(channel):
    p = os.path.join(CHANNELS_DIR, channel, 'busy')
    if os.path.exists(p):
        try:
            os.remove(p)
        except OSError:
            pass


# ── Телеметрія: Message Sent, Reply Received, Helper Invoked ────────────────
# Спека: specs/telemetry-events/spec.md, розділ 3, критерії К4 і К7. Точки
# спрацювання зняті в specs/telemetry-events/firing-points.md, розділи 4, 5, 8.
# Ці функції лише ГОТУЮТЬ властивості; білий список подій і алфавіт значень
# лишається закритий у telemetry.py, і саме він, а не ці функції, є останнім
# запобіжником проти витоку (К11).

def _channel_registry_entry(channel):
    """Сирий запис каналу з channels/index.json, або None. Не кешується:
    раз на хід дешевше, ніж ризик читати чужий кеш після зміни капелюха."""
    try:
        with open(os.path.join(CHANNELS_DIR, 'index.json'), encoding='utf-8') as f:
            reg = json.load(f)
    except Exception:
        return None
    if not isinstance(reg, list):
        return None
    for entry in reg:
        if isinstance(entry, dict) and entry.get('id') == channel:
            return entry
    return None


def _telemetry_channel_kind(channel):
    """channel -> 'chat' | 'agent' | 'twoway' | 'unknown' для Message Sent (К4).

    Рішення продакт-оунера (S5/S7): таксономії каналів у коді нема
    (firing-points.md, розділ 4), тому замість вигаданого детального переліку
    береться закритий набір рівно з чотирьох значень і сирі поля мапляться в
    нього. Сама назва чи id каналу сюди НІКОЛИ не потрапляють (К11) — рахуємо
    лише вже готові прапорці: капелюх агента (channel_agent, готовий і
    перевірений сигнал) і сирий `twoway` з реєстру. Усе незнайоме -> 'unknown'.
    """
    try:
        if channel_agent(channel):
            return 'agent'
    except Exception:
        pass
    entry = _channel_registry_entry(channel)
    if entry is None:
        return 'unknown'
    if entry.get('twoway'):
        return 'twoway'
    return 'chat'


_TELEMETRY_MEDIA_WIDGET_TYPES = {'image', 'gallery', 'video', 'audio', 'file'}


def _telemetry_has_media(widgets):
    """has_media для Reply Received (К4): чи є серед віджетів відповіді один з
    image/gallery/video/audio/file."""
    return any(isinstance(w, dict) and w.get('type') in _TELEMETRY_MEDIA_WIDGET_TYPES
               for w in (widgets or []))


def _telemetry_duration_ms(job):
    """duration_ms для Reply Received (К4): різниця між job['ts'] (мить, коли
    server.py поставив хід у чергу) і зараз. `ts` відсутній чи не парситься
    (старий файл черги) -> None, _safe_props сам відкине властивість (К8):
    вигадувати число тут гірше, ніж не надіслати його."""
    ts = (job or {}).get('ts')
    if not isinstance(ts, str):
        return None
    try:
        started = datetime.fromisoformat(ts)
    except ValueError:
        return None
    return max(0, int((datetime.now() - started).total_seconds() * 1000))


def _telemetry_safe_helper_name(raw):
    """helper_name для Helper Invoked (К7): лише алфавіт _SAFE_STR з
    telemetry.py (A-Za-z0-9._- до 32 символів), усе інше, включно з None і
    порожнім рядком, замінюється на 'other'. Ніколи не пускаємо сирий текст
    промпту чи довільний аргумент інструмента — тільки назву помічника."""
    if isinstance(raw, str) and telemetry._SAFE_STR.match(raw):
        return raw
    return 'other'


def _telemetry_tool_outcome(is_error):
    """is_error з блоку tool_result -> 'ok' / 'failed' / 'unknown' (К7).
    Прапорець недоступний (None, обидва SSE-парсери його сьогодні не завжди
    несуть) -> 'unknown', а не вигаданий успіх за замовчуванням: тиха брехня в
    даних гірша за чесну невизначеність."""
    if is_error is True:
        return 'failed'
    if is_error is False:
        return 'ok'
    return 'unknown'


def process_channel(channel):
    """Drain this channel's queue in order. Runs in its own thread."""
    job = None      # поточний job — щоб аварія нижче знала, який хід помітити
    try:
        q_dir = os.path.join(CHANNELS_DIR, channel, 'queue')
        while True:
            files = sorted(glob.glob(os.path.join(q_dir, '[0-9]*.json')))
            if not files:
                break
            qf = files[0]
            # Stop guard: server.py /api/stop removes the channel's `busy` flag
            # (and clears the queue) the moment the user hits Стоп. If busy is gone
            # we must NOT start another turn — discard whatever the poller may
            # have raced in and exit quietly. This is the belt to the kill's
            # braces: even if a queue file lingers, no new claude is spawned.
            if not os.path.exists(os.path.join(CHANNELS_DIR, channel, 'busy')):
                log(f'{channel}: busy cleared (stop) — draining queue, no new turn')
                for f in files:
                    # Питання людини не вмирає разом із ходом (К3): перед тим як прибрати
                    # елемент черги, кладемо його бульбашку у стрічку з міткою «відповіді
                    # не буде». Дубля не буде: rescue шукає вже записану бульбашку за тим
                    # самим ключем, що й claim_prompt_bubble.
                    try:
                        with open(f, encoding='utf-8') as _jf:
                            rescue_prompt_bubble(channel, json.load(_jf),
                                                 'зняли busy (Стоп)')
                    except Exception as e:
                        log(f'{channel}: не вдалось зберегти промпт із {f}: {e}')
                    try:
                        os.remove(f)
                    except OSError:
                        pass
                return
            try:
                job = json.load(open(qf))
            except Exception as e:
                # Файл нечитний, тобто тексту промпту в нас немає взагалі і бульбашку
                # збирати нема з чого. Тому НЕ видаляємо його мовчки, а відкладаємо убік:
                # єдиний носій питання людини лишається на диску, і його видно.
                broken = os.path.join(CHANNELS_DIR, channel, 'queue-broken')
                try:
                    os.makedirs(broken, exist_ok=True)
                    shutil.move(qf, os.path.join(broken, os.path.basename(qf)))
                    where = os.path.join('queue-broken', os.path.basename(qf))
                except Exception:
                    try:
                        os.remove(qf)
                    except OSError:
                        pass
                    where = '(не вдалось відкласти, файл прибрано)'
                log(f'{channel}: пошкоджений файл черги {qf}: {e}; відклав у {where}')
                continue
            # Message Sent (К4): раннер щойно дістав елемент черги і почав хід.
            # Властивості тільки типи, ані назви каналу, ані тексту (К11).
            telemetry.get(DIR).track('Message Sent', {
                'channel_kind': _telemetry_channel_kind(channel),
                'has_attachment': bool(job.get('attachments')),
            })
            # Знімок рантайму цього меседжа (модель + зусилля на момент відправки).
            # Ставиться ДО будь-якого рішення про хід, бо його читають і channel_model,
            # і движок SDK. Порожній знімок = старий файл черги, і тоді все працює як
            # раніше (файли каналу), а не падає.
            _snap = set_job_runtime(channel, job)
            log(f'{channel}: queue item {os.path.basename(qf)} runtime='
                f'{_snap or "(немає знімка, беру поточні налаштування каналу)"}')
            prompt = job.get('text', '')
            attachments = job.get('attachments') or []
            # Inject attached IMAGE paths so Claude opens them via the Read tool —
            # Read renders images visually, so the model actually "sees" them.
            # NOTE: text-file content is already inlined into the prompt by
            # server.py /api/send, and doc (pdf/docx) paths already get their own
            # "open via Read" note there. So here we ONLY list image attachments;
            # listing text/doc again would be redundant. We branch on each
            # attachment's `kind` (image|text|doc), defaulting to image for legacy
            # items that predate the kind field.
            if attachments:
                img_paths = []
                for a in attachments:
                    if isinstance(a, dict):
                        p = a.get('path')
                        kind = a.get('kind', 'image')
                    else:
                        p, kind = a, 'image'
                    if p and kind == 'image':
                        img_paths.append(p)
                if img_paths:
                    listing = '\n'.join(img_paths)
                    prompt = (
                        f'{prompt}\n\n'
                        f'Прикріплені зображення (прочитай кожне через Read tool, '
                        f'щоб побачити вміст):\n{listing}'
                    )
            # Двигун каналу читається САМЕ ТУТ, ДО гейту автостиснення, а не в
            # циклі ходу нижче (specs/compact-knows-engine). Раніше рішення про
            # стиснення приймалось наосліп: лічильник контексту ОДИН на канал і в
            # нього пише кожен двигун, тож контекст, нарощений ходами agy,
            # перетинав поріг і ми палили повний хід КЛОДА в чаті, де його ніхто
            # не кликав, плюс ротували session-id, яким цей канал не користується
            # (памʼять Antigravity тримає власний conversation_id на його боці).
            provider = channel_provider(channel)
            # Auto-compaction gate: if this channel's running context already
            # crossed the threshold, compact BEFORE spending this turn. The
            # summary turn rotates the session id, so we must re-read the bound
            # session id afterward (the job's stale session_id would resume the
            # poisoned session). On a failed/empty summary compact_channel returns
            # False and leaves everything as-is, so we just proceed normally.
            #
            # Стискає ЗАВЖДИ двигун самого каналу (specs/agy-compaction). Раніше
            # тут стояла умова `provider == 'claude'`: вона рятувала чужу квоту, але
            # лишала канал Antigravity узагалі без стиснення, тобто його контекст
            # ріс і не скидався ніколи. Тепер провайдер їде в compact_channel і той
            # веде свою гілку: Клод підсумовує сесію і ротує session-id, agy
            # підсумовує розмову і чистить agy_conversation.
            #
            # Відсоток теж читається ПО ДВИГУНУ: числа двох двигунів лежать окремо
            # (byProvider), тож гейт більше не міряє суміш двох різних вікон.
            pct = read_context_pct(channel, provider)
            if (pct is not None and pct >= COMPACT_THRESHOLD * 100
                    and autocompact_enabled(channel)):
                if compact_channel(channel, reason='auto', provider=provider):
                    append_message(
                        channel,
                        [compaction_divider_widget(freed_pct=pct, channel=channel)],
                        frm=('Antigravity' if provider == 'antigravity' else 'Claude'),
                        tag='compaction')
                    if provider != 'antigravity':
                        # force re-read of the rotated sid. Гілка agy наш session-id
                        # не рухає взагалі, тож і скидати тут нема чого.
                        job['session_id'] = None
            session_id = job.get('session_id')
            if not session_id:
                # fall back to channel-bound session file (also the path after a
                # compaction rotation above).
                sid_path = os.path.join(CHANNELS_DIR, channel, 'session-id')
                session_id = open(sid_path).read().strip() if os.path.exists(sid_path) else None
            if not session_id:
                # Хід не поїде, але питання людини лишається у стрічці з міткою (К3):
                # мовчки викидати його разом із job-ом ми більше не маємо права.
                log(f'{channel}: no session id, dropping job')
                rescue_prompt_bubble(channel, job, 'немає session-id')
                os.remove(qf)
                continue
            # Seed the prompt with any pending compaction summary (set by the
            # auto-compact above, or by a manual /api/compact while idle). This
            # is what carries the prior context into the fresh session.
            prompt = seed_prompt_with_summary(channel, prompt)
            # Промпт стає у стрічку САМЕ ТУТ (specs/queue-order-pairs, S3), і місце
            # вибране двома межами. Вище: гейт автокомпактингу, бо його розділювач
            # мусить лягти ПЕРЕД промптом, а не між промптом і відповіддю. Нижче:
            # перевірка session-id, яка може відкинути job — писати бульбашку, на яку
            # відповіді не буде, ми не маємо права.
            claim_prompt_bubble(channel, qf, job)
            # Памʼять під ЦЕЙ запит їде в шар ходу, а не в системний (specs/user-memory-v2,
            # S3, К3). Місце вибране двома межами. Вище: `claim_prompt_bubble`, після якого
            # бульбашка цього повідомлення вже в index.json, тобто добір бачить свіжу тему
            # обома шляхами (і текстом промпта, і історією). Нижче: цикл повторів, бо
            # перескладати блок на кожну спробу означало б рахувати покази фактів двічі за
            # той самий хід. У стрічку домішка не потрапляє: бульбашку вже записано з
            # `job`, а не з `prompt`, тому людина бачить рівно те, що написала.
            prompt = memory_turn_prompt(channel, prompt, session_id)
            # Auto-retry transient server hiccups (529 / rate-limit / warm died)
            # BEFORE ever surfacing an error to the user — the user should not have to
            # click "send" again for a temporary Anthropic overload. Timeouts and
            # policy blocks are NOT retried (a retry would just waste another turn).
            _model_safe_retry.discard(channel)   # clean state per prompt
            _agy_bare_retry.discard(channel)     # те саме для фолбеку моделі agy
            _FORCE_BARE['on'] = False
            _attempt = 0
            # `provider` уже прочитаний вище, перед гейтом автостиснення.
            while True:
                _attempt += 1
                if provider == 'antigravity':
                    # Двигун Antigravity не має ні нашого session-id, ні теплого
                    # процесу: памʼять ходу тримає conversation_id на його боці.
                    text, data, err = run_agy_stream(prompt, channel)
                elif _sdk_enabled(channel):
                    text, data, err = run_claude_sdk_turn(prompt, session_id, channel)
                elif WARM_MODE:
                    text, data, err = run_claude_warm(prompt, session_id, channel)
                elif STREAM_MODE:
                    text, data, err = run_claude_stream(prompt, session_id, channel)
                else:
                    text, data, err = run_claude(prompt, session_id, channel)
                # Robust stop detection (fixes "stopped then continued"): /api/stop
                # removes `busy` FIRST, before it kills the turn. If busy is gone
                # now, the user pressed Стоп while this turn ran. Force STOP_SENTINEL
                # so we do NOT retry (a transient-looking kill error like "warm
                # process ended" used to respawn the warm proc and re-run the same
                # prompt) and do NOT deliver a result that finished inside the
                # SIGTERM grace window before SIGKILL.
                if err != STOP_SENTINEL and not os.path.exists(
                        os.path.join(CHANNELS_DIR, channel, 'busy')):
                    log(f'{channel}: stop detected (busy cleared mid-turn), aborting turn')
                    err = STOP_SENTINEL
                # Зіткнення ідентифікатора сесії лікуємо самі, ОДИН раз: беремо
                # свіжий id і повторюємо той самий промпт. Це рівно те, що спека
                # вимагає від зміни моделі («підняти нову сесію з НОВИМ
                # ідентифікатором»), тільки без вимоги вгадати наперед, чи саме цей
                # хід у нього впреться. Розмова від ротації не гине: контекст на цю
                # мить або вже в .jsonl (тоді збігу і не буде), або його там ще нема
                # взагалі, бо жоден хід не дописався.
                if (err and err != STOP_SENTINEL and _is_session_collision_error(err)
                        and _attempt <= 2):
                    session_id = rotate_session_id(channel)
                    log(f'{channel}: session id collision (try {_attempt}), '
                        f'retrying on a fresh session {session_id[:8]}: {err[:110]}')
                    write_live(channel, {
                        'active': True, 'phase': 'thinking',
                        'steps': [{'icon': '🔄', 'tool': _bt({'uk': 'Оновлюю сесію',
                                                               'en': 'Refreshing the session'}, channel),
                                   'label': _bt({'uk': 'той самий запит, нова сесія',
                                                 'en': 'same request, new session'}, channel),
                                   'done': False}],
                        'text': ''})
                    continue
                # К4. «Під цю модель зараз нема потужності» лікується лише іншою
                # моделлю, тому один раз повторюємо БЕЗ --model і віддаємо вибір
                # двигуну. Гілка ЛИШЕ для Antigravity: канал Клода в неї не
                # заходить взагалі (provider у першій же умові), тож його розбір
                # помилок лишився недоторканим. Стоїть ВИЩЕ за _is_model_error і
                # _is_transient_error свідомо: обидва тепер збігаються з цим самим
                # рядком (' 503' і 'no capacity available'), і без цього порядку
                # хід пішов би на третю спробу тією самою моделлю, тобто рівно в ту
                # тишу, з якої все почалось.
                if provider == 'antigravity' and _is_agy_capacity_error(err):
                    if channel not in _agy_bare_retry:
                        _agy_bare_retry.add(channel)
                        log(f'{channel}: agy no capacity for model (try {_attempt}), '
                            f'retrying WITHOUT --model: {err[:120]}')
                        write_live(channel, {
                            'active': True, 'phase': 'thinking',
                            'steps': [{'icon': '🧠', 'tool': _bt({'uk': 'Нема потужності під модель',
                                                                   'en': 'No capacity for this model'}, channel),
                                       'label': _bt({'uk': 'міняю модель і пробую ще раз',
                                                     'en': 'switching the model and retrying'}, channel),
                                       'done': False}],
                            'text': ''})
                        continue
                    # Фолбек уже витрачено цим ходом: далі не повторюємо взагалі,
                    # людина отримує звичайну картку помилки з дослівною причиною.
                    log(f'{channel}: agy no capacity again after the model fallback '
                        f'(try {_attempt}), giving up: {err[:120]}')
                    break
                # Self-heal a model/CLI failure ONCE with a bare safe model before
                # ever surfacing it: chosen model missing on this machine / old CLI.
                if (err and err != STOP_SENTINEL and _is_model_error(err)
                        and channel not in _model_safe_retry and _attempt <= 2):
                    log(f'{channel}: model/CLI error (try {_attempt}), retry with safe '
                        f'default model: {err[:110]}')
                    _model_safe_retry.add(channel)
                    _FORCE_BARE['on'] = True
                    write_live(channel, {
                        'active': True, 'phase': 'thinking',
                        'steps': [{'icon': '🧠', 'tool': _bt({'uk': 'Модель недоступна',
                                                               'en': 'Model unavailable'}, channel),
                                   'label': _bt({'uk': 'пробую безпечну модель',
                                                 'en': 'trying a safe model'}, channel),
                                   'done': False}],
                        'text': ''})
                    continue
                # 403 від Google це ТИМЧАСОВА відмова, але рівно для Antigravity:
                # гілка нижче лишилась недоторканою, а ця вмикається лише коли
                # канал справді на цьому двигуні (К5). Пауза росте, бо вікно
                # відмов живе хвилинами, а не мілісекундами.
                if _agy_should_retry(provider, err, _attempt):
                    log(f'{channel}: agy transient 403 (try {_attempt}/'
                        f'{AGY_MAX_ATTEMPTS}), retrying: {err[:120]}')
                    write_live(channel, {
                        'active': True, 'phase': 'thinking',
                        'steps': [{'icon': '⏳', 'tool': _bt({'uk': 'Google тимчасово відмовив',
                                                               'en': 'Google temporarily refused'}, channel),
                                   'label': _bt({'uk': f'пробую ще раз ({_attempt})',
                                                 'en': f'trying again ({_attempt})'}, channel),
                                   'done': False}],
                        'text': ''})
                    time.sleep(AGY_RETRY_BACKOFF * _attempt)
                    continue
                if (err and err != STOP_SENTINEL and _is_transient_error(err)
                        and _attempt <= 2):
                    log(f'{channel}: transient error (try {_attempt}/3), retrying: {err[:90]}')
                    write_live(channel, {
                        'active': True, 'phase': 'thinking',
                        'steps': [{'icon': '⏳', 'tool': _bt({'uk': 'Сервер перевантажений',
                                                               'en': 'Server overloaded'}, channel),
                                   'label': _bt({'uk': f'пробую ще раз ({_attempt})',
                                                 'en': f'trying again ({_attempt})'}, channel),
                                   'done': False}],
                        'text': ''})
                    time.sleep(2 * _attempt)
                    continue
                break
            _FORCE_BARE['on'] = False   # end the safe-model window promptly
            # this turn's process is done; drop our pid file (server may already
            # have removed it on a stop — clear_pid is a no-op then).
            #
            # Підсумок ходу відомий рівно тут і більше ніде: нижче `err`
            # розгалужується на картку помилки, тиху зупинку і звичайну
            # відповідь, і кожна гілка вже не бачить двох інших. Три слова тут
            # це знання раннера про ВЛАСНИЙ хід, а не логіка сповіщень: що з
            # цим робити, вирішує attention.py.
            clear_pid(channel, outcome=('stopped' if err == STOP_SENTINEL
                                        else 'failed' if err else 'done'))
            # Якір «на що це відповідь». Знімається ТУТ, до будь-якого запису бульбашки,
            # і одним обʼєктом їде в усі виходи ходу (відповідь, картка помилки, залишок
            # від зупинки), бо для читача це один і той самий факт: ось меседж, ось що з
            # нього вийшло. Джерело те саме, що в mark_turn_failed — user_msg_id з файлу
            # черги, а не здогадка про сусідню бульбашку.
            _anchor = reply_anchor(channel, job.get('user_msg_id'))
            # Recover the streamed-so-far partial BEFORE we wipe live.json. Prefer
            # the engine's in-memory `text` (always current; survives the server
            # deleting live.json on /api/stop), and fall back to the live snapshot
            # for engines that return None on abort. The ONLY early-abort left is the
            # user's Стоп (/api/stop): the idle auto-abort was removed, so a long /
            # silent turn now runs to completion instead of being killed.
            aborted = (err == STOP_SENTINEL)
            partial_text = ''
            if aborted:
                partial_text = (text or '').strip()
                if not partial_text:
                    snap_text, _snap_steps = read_live_snapshot(channel)
                    partial_text = (snap_text or '').strip()
            # Чи робив цей хід реальну роботу інструментами. Знімок беремо САМЕ
            # тут, ДО clear_live: нижче live.json уже нема, а гілці порожнього
            # тексту цей факт потрібен, щоб не назвати провалом хід, який
            # відпрацював. Джерело те саме, що малює живу смугу, тож нових
            # даних ніхто не збирає: усі чотири двигуни (stream, warm, sdk, agy)
            # пишуть сюди свої кроки. Двигун, який live.json не пише взагалі
            # (одноразовий run_claude при CHAT_RUNNER_STREAM=0), дасть порожній
            # список і поведеться рівно як раніше.
            worked_steps = read_live_snapshot(channel)[1]
            # turn done: the final reply goes to a permanent bubble, so the
            # transient live panel can disappear now.
            clear_live(channel)
            # Intentional stop via /api/stop: the server already cleared the
            # queue/busy/live and flagged the killed prompt on the user's own bubble.
            # Keep whatever streamed before the stop as a real bubble (partial is
            # NOT discarded), then exit the drain loop quietly without an error
            # bubble and never re-pick the server-emptied queue.
            #
            # Nothing streamed = nothing to show. We used to post the note alone,
            # which is a bubble from Claude whose entire content is the word
            # «Зупинено» — pure noise now that the mark lives on the prompt
            # (owner decision, 2026-07-29). With partial text the note stays: it explains
            # why the answer breaks off mid-sentence.
            if err == STOP_SENTINEL:
                log(f'{channel}: turn stopped via /api/stop (partial {len(partial_text)} chars)')
                if partial_text:
                    # К7: те саме правило джерела моделі, що й на основному шляху
                    # відповіді нижче — 1) _turn_model(data) (ground truth ходу,
                    # частіше None тут: зупинений хід рідко встигає прислати
                    # modelUsage), 2) channel_model як друга за надійністю
                    # відповідь, коли даних ходу нема.
                    persist_partial(channel, partial_text,
                                    '⏸ Зупинено (ось що встиг).', reply_to=_anchor,
                                    model=_turn_model(data) or channel_model(channel, prompt))
                return
            if data:
                write_usage(channel, data)
            if err:
                # Raw technical error goes to the runner log only, never to the
                # user's chat bubble.
                log(f'{channel}: ERROR {err}')
                rotated = False
                if provider == 'antigravity':
                    # Ротація сесії тут безглузда: у Antigravity памʼять тримає
                    # conversation_id, а не наш session-id, тож лікуємо словами.
                    append_message(channel, agy_error_widgets(err, channel),
                                   frm='Antigravity', tag='error', reply_to=_anchor)
                else:
                    if _is_policy_error(err):
                        rotate_session_id(channel)
                        rotated = True
                    append_message(channel,
                                   friendly_error_bubble(err, rotated, channel),
                                   frm='Claude', tag='error', reply_to=_anchor)
                # …і одразу мітка на самому провальному ході: картка-пояснення
                # стоїть окремим бабблом і при прокрутці стрічки не звʼязується з
                # промптом, з якого хід починався. Мітка живе НА промпті і несе
                # кнопку повтору, тож видно і що саме померло, і чим це лікувати.
                _fail = classify_failure(err, rotated, channel)
                mark_turn_failed(channel, job.get('user_msg_id'), _fail, job)
                log(f'{channel}: turn marked failed ({_fail["reason"]})')
            else:
                # Declarative PLAN sidebar: persist any ```plan``` block and strip
                # it from the reply (single writer = set-plan.cjs) BEFORE the reply
                # is turned into widgets or spoken, so it never leaks as a bubble.
                text, plan_declared = finalize_plan_declaration(channel, text)
                body = (text or '').strip()
                if not body:
                    # Empty finalized reply. NEVER post the raw "(порожня відповідь)"
                    # placeholder — that reads as a broken message (hit live).
                    # Three legit causes, handled distinctly:
                    #   * plan-only turn: the model's whole reply was a ```plan```
                    #     block, already persisted to the sidebar -> the sidebar IS
                    #     the deliverable, a chat bubble would be noise, so skip it.
                    #   * мовчазний робочий хід: тексту нема, але інструменти
                    #     відпрацювали -> це НЕ провал, і плутати його з провалом
                    #     небезпечно. Кнопка «Надіслати знову» на такому ході жене
                    #     ту саму роботу вдруге (канал chat-173: повторним кліком
                    #     поїхали б удруге чотири агенти на 48 файлів). Тому тільки
                    #     спокійна нота: хід відпрацював, ось чим був зайнятий.
                    #   * genuine whiff: the model produced no text at all -> це ПРОВАЛ
                    #     ходу, а не успіх. Раніше сюди падав мінімальний ack «Готово ✓»,
                    #     щоб спінер не зникав у порожнечу. Наслідок виявився гіршим за
                    #     хворобу: збій виглядав як рапорт про виконану роботу, слід був
                    #     стертий (помилки формально не було), і повторити хід не було
                    #     чим. Тепер порожній хід їде тим самим конвеєром, що й будь-який
                    #     інший провал: чесна картка + мітка на промпті + «Надіслати
                    #     знову». Спінер так само не зникає в нікуди, але не бреше.
                    if plan_declared:
                        log(f'{channel}: plan-only turn — sidebar updated, no chat bubble')
                    elif worked_steps:
                        append_message(channel, silent_work_bubble(worked_steps, channel),
                                       frm=_author_for(provider, channel),
                                       tag='status', reply_to=_anchor)
                        log(f'{channel}: silent working turn ({len(worked_steps)} tool '
                            f'steps): calm note, NOT marked failed')
                    else:
                        append_message(
                            channel,
                            friendly_error_bubble(EMPTY_REPLY_SENTINEL, False, channel),
                            frm='Claude', tag='error', reply_to=_anchor)
                        _fail = classify_failure(EMPTY_REPLY_SENTINEL, False, channel)
                        mark_turn_failed(channel, job.get('user_msg_id'), _fail, job)
                        log(f'{channel}: empty reply — marked failed (retryable)')
                else:
                    # К7 (specs/model-widget-contract/spec.md): лог відмови воріт
                    # мусить нести ту саму модель, що йде в append_message нижче —
                    # модель ХОДУ, а не модель, яку канал ПРОСИВ. Порядок джерел за
                    # надійністю: 1) _turn_model(data) — ground truth з modelUsage,
                    # може відрізнятись від запиту на фолбеках (safe-retry, сімейний
                    # фолбек, підміна моделі всередині ходу); 2) channel_model —
                    # запит каналу, як друга за надійністю відповідь, коли
                    # modelUsage відсутній (старий двигун, який його не шле); 3) якщо
                    # й це None, reply_to_widgets сам логує «unknown», вигадувати
                    # нічого не треба.
                    _reply_model = _turn_model(data) or channel_model(channel, prompt)
                    _w = reply_to_widgets(body, model=_reply_model, channel=channel)
                    _w = maybe_attach_voice(channel, _w, body)   # voice-auto ON -> audio in the same card
                    append_message(channel, _w, frm=_author_for(provider, channel),
                                   reply_to=_anchor, model=_turn_model(data))
                    # Reply Received (К4): пара до Message Sent. Навмисно НЕ
                    # їде на error/empty/stop гілках вище — різниця між Sent і
                    # Received це і є сигнал тихої поломки (спека, розділ 5).
                    telemetry.get(DIR).track('Reply Received', {
                        'duration_ms': _telemetry_duration_ms(job),
                        'widget_count': len(_w),
                        'has_media': _telemetry_has_media(_w),
                    })
                    log(f'{channel}: replied ({len(body)} chars)')
            # Автозапис памʼяті (specs/user-memory-v2, S5). Місце вибране двома межами.
            # Вище: відповідь (або картка помилки) вже лежить у стрічці, тобто людина
            # своє отримала і жодного байта затримки автозапис їй не додає (К8). Нижче:
            # ще не прибраний елемент черги, тобто `job` живий і з нього видно і
            # ДОСЛІВНУ репліку, і id її бульбашки. Саме `job['text']`, а не `prompt`:
            # той уже обріс переліком вкладень і підсівом підсумку стиснення, і в тілі
            # кандидата людина читала б власні слова з чужим хвостом.
            #
            # Спільна точка для успіху і для помилки навмисно. «Ти знову все зламав»
            # це виправлення незалежно від того, чим хід закінчився, а провальний хід
            # ще й найімовірніша мить, коли таке пишуть.
            memory_autolearn(channel, job.get('text', ''), job.get('user_msg_id'))
            # job done: remove it whether ok or error (error is reported in chat).
            # On a stop we already returned above, so the server-cleared queue is
            # never re-drained here.
            try:
                os.remove(qf)
            except OSError:
                pass
            job = None      # хід віддано, аварія далі вже не його провина
    except Exception as e:
        # Аварія самого воркера (не движка): раніше тред просто помирав, finally
        # знімало busy — і спінер зникав без жодного сліду, що хід обірвався. Це
        # рівно та «незрозуміло, чи ще генерується, чи вже мертва» ситуація, тож
        # обриваємо чесно: мітка на промпті + картка-пояснення, як у будь-якого
        # іншого провалу. Далі підіймаємо, щоб трасу було видно в лозі.
        log(f'{channel}: worker crashed: {e!r}')
        if job is not None:
            try:
                append_message(channel, friendly_error_bubble(str(e), False, channel),
                               frm='Claude', tag='error')
                mark_turn_failed(channel, job.get('user_msg_id'),
                                 {'reason': 'crashed', 'tone': 'error',
                                  'text': _bt({'uk': 'Хід обірвано: внутрішня помилка чату',
                                               'en': 'Turn aborted: internal chat error'}, channel)}, job)
            except Exception:
                pass
        raise
    finally:
        clear_job_runtime(channel)
        clear_busy(channel)
        clear_live(channel)
        # 'gone' спрацює ЛИШЕ якщо хід не дійшов до власного кінця (аварія
        # воркера): у нормальному житті job знятий вище і подія вже поїхала,
        # тож другої не буде. Без цього рядка обірваний хід зникав би мовчки
        # саме тоді, коли сповіщення потрібне найбільше.
        clear_pid(channel, outcome='gone')
        with _active_lock:
            _active.pop(channel, None)


def process_compact_request(channel):
    """Manual compaction worker (triggered by /api/compact -> compact-request
    marker). Summarizes + rotates + stashes the summary for the next prompt,
    even when the queue is empty. Holds the channel busy so the UI shows a
    spinner, and posts a small bubble at the end. The stashed pending-summary is
    consumed by the next real prompt (process_channel -> seed_prompt_with_summary)."""
    marker = compact_request_path(channel)
    busy = os.path.join(CHANNELS_DIR, channel, 'busy')
    try:
        # mark busy so the front end shows activity during the summary turn
        try:
            os.makedirs(os.path.join(CHANNELS_DIR, channel), exist_ok=True)
            with open(busy, 'w') as f:
                f.write(datetime.now().isoformat())
        except Exception:
            pass
        # Кнопку веде той самий двигун, що й канал (specs/agy-compaction). Тут
        # стояла ВІДМОВА для не-Клодового каналу: вона була чесною, поки стиснення
        # вміло тільки Клодом, а тепер стала брехнею, бо agy стискає себе сам.
        # Підпис автора лишається різним: людина має бачити, ХТО саме працював.
        provider = channel_provider(channel)
        author = 'Antigravity' if provider == 'antigravity' else 'Claude'
        # Capture context % BEFORE compaction so the divider can show how much was
        # freed (compact_channel zeroes usage.json on success).
        pct_before = read_context_pct(channel, provider)
        ok = compact_channel(channel, reason='manual', provider=provider)
        if ok:
            append_message(
                channel,
                [compaction_divider_widget(freed_pct=pct_before, channel=channel)],
                frm=author, tag='compaction')
        else:
            append_message(
                channel,
                [{'type': 'text', 'text':
                  _bt({'uk': 'Поки нема що стискати (новий або порожній чат).',
                       'en': 'Nothing to compact yet (new or empty chat).'}, channel)}],
                frm=author, tag='status')
    finally:
        # remove the marker so we do not loop, and free the channel
        if os.path.exists(marker):
            try:
                os.remove(marker)
            except OSError:
                pass
        clear_busy(channel)
        clear_live(channel)
        clear_pid(channel)
        with _active_lock:
            _active.pop(channel, None)


def poll_once():
    if not os.path.isdir(CHANNELS_DIR):
        return
    for channel in os.listdir(CHANNELS_DIR):
        ch_dir = os.path.join(CHANNELS_DIR, channel)
        if not os.path.isdir(ch_dir):
            continue
        # "Хард рефреш" (POST /api/engine-restart) і зміна моделі (/api/channel-config):
        # evict the warm engine so the next turn cold-respawns fresh. Runs even with an
        # empty queue; recycle_channel is thread-safe and a no-op when nothing is warm
        # (SDK mode). We do NOT `continue` — any queued work then runs immediately on
        # the fresh engine.
        #
        # ЗАЧЕКАТИ, ПОКИ КАНАЛ ЗАЙНЯТИЙ (рішення власника, 2026-08-06). Раніше маркер зʼїдався
        # НЕГАЙНО, і зміна моделі під час живого ходу вбивала теплий процес просто
        # посеред нього: хід помирав, і людина бачила картку «не вдалось обробити цей
        # хід, спробуй ще раз, якщо повторюється: новий чат». Зміна налаштувань це
        # не помилка, тож маркер лежить до кінця ходу і спрацьовує перед наступним.
        # Модель самого наступного меседжа від цього не залежить: її несе його
        # власний знімок, а _warm_get і так респавнить процес під іншу модель.
        rq = recycle_request_path(channel)
        if os.path.exists(rq):
            with _active_lock:
                _turn_running = bool(_active.get(channel))
            if _turn_running:
                continue        # маркер лишається: заберемо його, коли хід дограє
            try:
                recycle_channel(channel)
            except Exception as e:
                log(f'{channel}: recycle error: {e}')
            try:
                os.remove(rq)
            except OSError:
                pass
        # Manual compaction has priority and works even with an empty queue.
        # Only when the channel is not already occupied by a turn/compact.
        if os.path.exists(compact_request_path(channel)):
            with _active_lock:
                if _active.get(channel):
                    continue
                _active[channel] = True
            t = threading.Thread(target=process_compact_request,
                                 args=(channel,), daemon=True)
            t.start()
            continue
        q_dir = os.path.join(ch_dir, 'queue')
        if not os.path.isdir(q_dir):
            continue
        if not glob.glob(os.path.join(q_dir, '[0-9]*.json')):
            continue
        with _active_lock:
            if _active.get(channel):
                continue
            _active[channel] = True
        t = threading.Thread(target=process_channel, args=(channel,), daemon=True)
        t.start()


# ── Биття серця ──────────────────────────────────────────────────────────────
# Раннер лишає поруч з каналами файл-заяву: хто я (pid, коли стартував), який у мене код
# (відбиток вмісту runner.py НА МОМЕНТ СТАРТУ) і що я вмію (caps). Сервер читає її в
# /api/send: якщо здатності `prompt-bubble` там немає, він пише бульбашку промпту сам.
#
# Без цього виходив стан, у якому бульбашку не писав НІХТО: сервер перезапустився на
# новому контракті (бульбашку кладе раннер), а раннер у памʼяті лишився з коду, у якому
# claim_prompt_bubble ще не існувало. Мовчазна втрата питання людини на кожному ході.
def heartbeat_home():
    """Тека даних, поруч з якою лежить channels/. Рахується ВІД CHANNELS_DIR, щоб у
    пакованій збірці биття серця лягло в LOGOPSIS_HOME, а не в read-only бандл коду."""
    return os.path.dirname(os.path.abspath(CHANNELS_DIR))


def write_heartbeat():
    """Оновити биття серця. Best-effort: збій запису не сміє зупинити чергу.

    Ціна провалу свідомо мала: сервер вирішить, що раннера немає, і напише бульбашку сам.
    Дубля з цього не буде, бо ідемпотентність тримається на наскрізному `buid`."""
    try:
        atomic_write_json(
            runner_pulse.heartbeat_path(heartbeat_home()),
            runner_pulse.build(pid=os.getpid(), started=RUNNER_STARTED,
                               code_fp=RUNNER_CODE_FP),
            indent=None)
        return True
    except Exception as e:
        log(f'не вдалось оновити биття серця: {e}')
        return False


# ── Самолікування розʼїзду версій ────────────────────────────────────────────
# Биття серця вище лише ЗАЯВЛЯЄ, який код крутиться, а картку про розʼїзд ще треба
# помітити і натиснути кнопку. 13.08 розʼїзд стався тричі за добу і жодного разу картку
# не помітили: вона вгорі, а працюють унизу, біля поля вводу. Тому раннер тепер міряє
# розʼїзд сам і сам себе перезапускає, але ЛИШЕ коли черга порожня і жоден хід не йде:
# перезапуск посеред ходу вбив би живу відповідь, тобто зробив би рівно ту шкоду, яку
# ми лікуємо.
SELFCHECK_SECONDS = float(os.environ.get('CHAT_RUNNER_SELFCHECK', '5'))
_selfcheck = {'at': 0.0, 'disk_fp': None, 'said': None}


def self_restart_blockers():
    """Чому перезапускатись ЗАРАЗ не можна. Порожній список = момент безпечний.

    Дивимось на три різні речі, бо «зайнято» буває трьох видів: хід уже крутиться в
    потоці (`_active`), канал позначений `busy` (хід міг стартувати в іншому процесі або
    щойно розпочатись), у черзі лежить непрочитаний промпт. Маркери перезбирання і
    стиснення теж рахуємо: вони означають роботу, яку хтось замовив і чекає."""
    out = []
    with _active_lock:
        out += [f'хід:{ch}' for ch, on in _active.items() if on]
    try:
        names = os.listdir(CHANNELS_DIR)
    except OSError:
        names = []
    for ch in names:
        d = os.path.join(CHANNELS_DIR, ch)
        if not os.path.isdir(d):
            continue
        if os.path.exists(os.path.join(d, 'busy')):
            out.append(f'busy:{ch}')
        if glob.glob(os.path.join(d, 'queue', '[0-9]*.json')):
            out.append(f'черга:{ch}')
        if os.path.exists(compact_request_path(ch)) or \
                os.path.exists(recycle_request_path(ch)):
            out.append(f'маркер:{ch}')
    return sorted(set(out))


def check_code_drift():
    """Порівняти свій код з диском і, якщо момент безпечний, перезапуститись.

    Відбиток мусить УЛЕЖАТИСЬ: беремо його двічі підряд і діємо лише коли обидва читання
    однакові. Інакше перезапуск міг би спрацювати на файлі, який зараз саме пишуть
    (git checkout, збереження з редактора), тобто на коді, якого ніхто не мав на увазі."""
    if not runner_pulse.self_restart_enabled():
        return
    now = time.time()
    if now - _selfcheck['at'] < SELFCHECK_SECONDS:
        return
    _selfcheck['at'] = now
    disk_fp = runner_pulse.code_fingerprint(os.path.abspath(__file__))
    prev, _selfcheck['disk_fp'] = _selfcheck['disk_fp'], disk_fp
    if disk_fp is None or disk_fp != prev:
        return                                     # ще не влігся: чекаємо наступного кола
    home = heartbeat_home()
    d = runner_pulse.self_restart_decision(
        RUNNER_CODE_FP, disk_fp, self_restart_blockers(),
        runner_pulse.read_self_restarts(home, 'runner'))
    if not d['restart']:
        # Про відмову кажемо, але один раз на кожну нову причину: розʼїзд може висіти
        # годинами, і рядок кожні 5 секунд перетворив би лог на смітник.
        said = (d['reason'], tuple(d['blockers']))
        if d['reason'] in ('busy', 'throttled') and _selfcheck['said'] != said:
            _selfcheck['said'] = said
            if d['reason'] == 'busy':
                log(f'розʼїзд версій ({RUNNER_CODE_FP} -> {disk_fp}), але зараз не можна: '
                    f'{", ".join(d["blockers"])}. Перезапущусь, щойно звільниться.')
            else:
                log(f'розʼїзд версій ({RUNNER_CODE_FP} -> {disk_fp}), але вичерпано ліміт '
                    f'самоперезапусків ({d["recent"]} за останні '
                    f'{int(runner_pulse.SELF_RESTART_WINDOW_SECONDS // 60)} хв). Далі руками.')
        return
    _selfcheck['said'] = None
    runner_pulse.note_self_restart(home, 'runner', RUNNER_CODE_FP, disk_fp)
    log(f'самоперезапуск: код на диску змінився, було {RUNNER_CODE_FP}, стало {disk_fp}; '
        f'причина: черга порожня і жоден хід не виконується, тож стара версія коду більше '
        f'нікому не потрібна (самоперезапусків за останні '
        f'{int(runner_pulse.SELF_RESTART_WINDOW_SECONDS // 60)} хв: {d["recent"] + 1})')
    runner_pulse.restart_self(
        os.environ.get('CHAT_RUNNER_LAUNCHD_LABEL', 'com.sharedknowledge.viz-chat-runner'),
        log)


# ── Singleton guard ──────────────────────────────────────────────────────────
# Only ONE runner may poll the channels/ queue at a time. Two runners double-
# process prompts (both grab turns, warm/SDK sessions collide) and, historically,
# repeated `python runner.py` launches across sessions stacked up 8 stale runners.
# We hold a loopback lock socket for the whole process lifetime; a second runner
# fails to bind and exits immediately. The OS frees the port the instant the
# holder dies, so there is no stale-lock file to clean up (unlike a PID lock).
# Disable with CHAT_RUNNER_SINGLETON=0; move the port with CHAT_RUNNER_LOCK_PORT.
_SINGLETON_SOCK = None


def _acquire_singleton():
    """Bind the runner lock port. Returns True if we are the sole runner, False if
    another instance already holds it. Never raises."""
    global _SINGLETON_SOCK
    if os.environ.get('CHAT_RUNNER_SINGLETON', '1') in ('0', 'false', 'no'):
        return True
    import socket as _socket
    port = int(os.environ.get('CHAT_RUNNER_LOCK_PORT', '5561'))
    s = _socket.socket(_socket.AF_INET, _socket.SOCK_STREAM)
    # NOTE: deliberately NO SO_REUSEADDR — we WANT the 2nd bind to fail.
    try:
        s.bind(('127.0.0.1', port))
        s.listen(1)
    except OSError:
        try:
            s.close()
        except Exception:
            pass
        return False
    _SINGLETON_SOCK = s   # keep a ref alive so the port stays held for our lifetime
    return True


def main():
    if not _acquire_singleton():
        log('another runner already holds the lock port — exiting (singleton).')
        return
    log(f'runner up. repo={REPO_ROOT} claude={CLAUDE_BIN} model={MODEL} '
        f'perm={PERMISSION_MODE} code_fp={RUNNER_CODE_FP}')
    if not os.path.exists(CLAUDE_BIN):
        log(f'FATAL: claude binary not found at {CLAUDE_BIN}. Set CLAUDE_BIN.')
        sys.exit(1)
    # Каталог моделей Клода (К1): кеш не свіжий -> тягнемо у фоні, цикл не чекає.
    claude_catalog().warm()
    while True:
        # Биття серця йде ПЕРЕД опитуванням і на КОЖНОМУ циклі. Цикл ходом не блокується
        # (хід крутиться в окремому потоці), тож навіть під годинною відповіддю заява
        # лишається свіжою, і сервер не візьметься писати бульбашку замість нас.
        write_heartbeat()
        try:
            poll_once()
        except Exception as e:
            log(f'poll error: {e}')
        # ПІСЛЯ опитування: якщо цей самий прохід щойно запустив хід, ми вже це побачимо
        # в `_active` і перезапуск не відбудеться. Порядок навпаки лишав би вікно в один
        # цикл, у яке хід стартував би саме тоді, коли ми вирішили вмирати.
        try:
            check_code_drift()
        except Exception as e:
            log(f'self-check error: {e}')
        time.sleep(POLL_SECONDS)


if __name__ == '__main__':
    main()
