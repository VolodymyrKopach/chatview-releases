# -*- coding: utf-8 -*-
"""ЄДИНЕ джерело правди: у яку модель Antigravity перетворюється наш рівень
(«Швидкий» / «Баланс» / «Розумний» / «Геній»).

Чому модуль зʼявився. Та сама мапа лежала у ДВОХ місцях, `runner.AGY_MODEL_PREFS` і
`logopsis/src/lib/api/agy-models.ts`, і обидві копії тримали КОНКРЕТНІ версійні id
(gemini-3.6-flash-high, claude-opus-4-6-thinking). Набір моделей двигуна міняється між
випусками, тож така мапа старіє мовчки. Живий випадок 2026-08-12: agy 1.1.12 почав
віддавати рядок `id<TAB>Людська назва` замість голого id. Фронт порівнював цілий рядок
із голим id, точний збіг не спрацьовував НІКОЛИ, і кожен рівень падав на запасну гілку
«перша модель тієї ж родини». Людина бачила Gemini 3.6 Flash High під трьома рівнями з
чотирьох, а під «Генієм» Claude Sonnet 4.6, бо саме sonnet стоїть у видачі перед opus.

Тому тут два принципи.

1. Рівень описаний ПРАВИЛОМ (виробник + клас + бажана глибина), а не списком id.
   Поява gemini-3.7 або зникнення 3.5 нічого не ламає: серед живих кандидатів береться
   найновіший, що підходить під правило.
2. Заміна не буває тихою. Якщо довелось узяти не той клас моделі, який рівень обіцяє,
   результат несе `fallback: True` і людський `reason`, і інтерфейс мусить це показати.
   Тихий фолбек, який ховає причину, гірший за чесну відмову.

Читають цей модуль і `runner.py` (обирає модель на хід), і `server.py` (віддає готову
мапу в UI). Фронт власної копії БІЛЬШЕ НЕ ТРИМАЄ, він читає `tiers` з /status.
"""
import json
import os
import re

MODEL_TIERS = ('haiku', 'sonnet', 'opus', 'fable')

# Наші людські назви рівнів. Дзеркало MODEL_OPTIONS у channel-config.ts: там вони
# потрібні для пілюль, тут для підпису «що саме стоїть за рівнем».
TIER_LABELS = {
    'haiku': 'Швидкий',
    'sonnet': 'Баланс',
    'opus': 'Розумний',
    'fable': 'Геній',
}

# Правило рівня: впорядкований список спроб (виробник, клас, порядок глибини).
# Перша спроба це ОБІЦЯНКА рівня; усе далі вже заміна, і вона позначається прапорцем.
# Клас None означає «будь-який клас цього виробника».
_TIER_RULES = {
    'haiku': (
        ('gemini', 'flash', ('low', 'medium', 'high')),
        ('gpt-oss', None, ('low', 'medium', 'high')),
        ('claude', 'haiku', ('low', 'medium', 'high')),
        ('gemini', 'pro', ('low', 'medium', 'high')),
    ),
    'sonnet': (
        ('gemini', 'flash', ('high', 'medium', 'low')),
        ('gpt-oss', None, ('high', 'medium', 'low')),
        ('claude', 'sonnet', ('high', 'medium', 'low')),
        ('gemini', 'pro', ('low', 'medium', 'high')),
    ),
    'opus': (
        ('gemini', 'pro', ('high', 'medium', 'low')),
        ('claude', 'sonnet', ('high', 'medium', 'low')),
        ('claude', 'opus', ('high', 'medium', 'low')),
        ('gemini', 'flash', ('high', 'medium', 'low')),
    ),
    'fable': (
        ('claude', 'opus', ('high', 'medium', 'low')),
        ('claude', 'sonnet', ('high', 'medium', 'low')),
        ('gemini', 'pro', ('high', 'medium', 'low')),
        ('gemini', 'flash', ('high', 'medium', 'low')),
    ),
}

# Людські імена того, ЧОГО рівень хотів. Потрібні лише для тексту заміни.
_WANT_NAMES = {
    ('gemini', 'flash'): 'Gemini Flash',
    ('gemini', 'pro'): 'Gemini Pro',
    ('claude', 'opus'): 'Claude Opus',
    ('claude', 'sonnet'): 'Claude Sonnet',
    ('claude', 'haiku'): 'Claude Haiku',
    ('gpt-oss', None): 'GPT-OSS',
}

# Рядки-заголовки, які CLI домішує до списку («Fetching available models...»).
_NOISE_PREFIXES = ('fetching', 'available', 'models', 'usage', 'these are', 'no models')


def _vendor(mid):
    if mid.startswith('gemini'):
        return 'gemini'
    if mid.startswith('claude'):
        return 'claude'
    if mid.startswith('gpt-oss'):
        return 'gpt-oss'
    return 'other'


def _klass(mid, vendor):
    # Клас читаємо в межах виробника: так «pro» у назві Gemini і «opus» у назві Claude
    # ніколи не переплутаються між собою.
    if vendor == 'gemini':
        if 'flash' in mid:
            return 'flash'
        if 'pro' in mid:
            return 'pro'
    elif vendor == 'claude':
        for k in ('opus', 'sonnet', 'haiku'):
            if k in mid:
                return k
    elif vendor == 'gpt-oss':
        return 'oss'
    return 'other'


def _depth(mid):
    """Глибина міркування, зашита в сам id. `thinking` це найглибший режим моделі."""
    if mid.endswith('-low'):
        return 'low'
    if mid.endswith('-high'):
        return 'high'
    if 'thinking' in mid:
        return 'high'
    return 'medium'


def _version(mid):
    """Версія числом, щоб «новіше» вигравало без зашитих id. `gemini-3.6-...` -> 3.6,
    `claude-opus-4-6-thinking` -> 4.6. Не знайшли версію -> 0, тобто в кінець черги."""
    m = re.search(r'(\d+)[.\-](\d+)', mid)
    if m:
        try:
            return float('%s.%s' % (m.group(1), m.group(2)))
        except ValueError:
            return 0.0
    m = re.search(r'(\d+)', mid)
    return float(m.group(1)) if m else 0.0


def facets(mid):
    """Розклад id на ознаки, за якими працює правило рівня."""
    s = (mid or '').strip().lower()
    v = _vendor(s)
    return {'vendor': v, 'klass': _klass(s, v), 'depth': _depth(s), 'version': _version(s)}


def parse_models(lines):
    """Сирі рядки `agy models` -> [{'id', 'label'}].

    Живий формат 1.1.12 це `id<TAB>Людська назва`; старіші версії віддавали голий id.
    Приймає також уже розібрані словники, щоб модуль не можна було погодувати двічі
    розібраним списком і отримати кашу. Сміття (порожнє, заголовки, не-рядки) відкидає."""
    out = []
    seen = set()
    for raw in (lines or []):
        if isinstance(raw, dict):
            mid = (raw.get('id') or '').strip()
            label = raw.get('label')
        elif isinstance(raw, str):
            s = re.sub(r'^\s*[-*•>·]\s*', '', raw).strip()
            if not s or s.lower().startswith(_NOISE_PREFIXES):
                continue
            # Розділювач це таб; деякі версії ставили кілька пробілів.
            parts = re.split(r'\t|\s{2,}', s, 1)
            mid = parts[0].strip()
            label = parts[1].strip() if len(parts) > 1 and parts[1].strip() else None
            # Після розділення id все одно з пробілом означає, що це не id, а фраза.
            if ' ' in mid:
                continue
        else:
            continue
        if not mid or mid in seen:
            continue
        seen.add(mid)
        out.append({'id': mid, 'label': label})
    return out


def _pick(models, vendor, klass, depth_order):
    """Найкращий кандидат під одну спробу правила: спершу бажана глибина, далі новіша
    версія, далі порядок видачі двигуна."""
    cands = []
    for i, m in enumerate(models):
        f = facets(m['id'])
        if f['vendor'] != vendor:
            continue
        if klass is not None and f['klass'] != klass:
            continue
        try:
            d = depth_order.index(f['depth'])
        except ValueError:
            d = len(depth_order)
        cands.append((d, -f['version'], i, m))
    if not cands:
        return None
    cands.sort(key=lambda c: c[:3])
    return cands[0][3]


def resolve_tier(alias, models):
    """Рівень -> конкретна модель живої видачі.

    Повертає {'alias', 'tier_label', 'id', 'label', 'fallback', 'reason'}.
    `fallback: True` означає, що обіцянку рівня довелось замінити, і UI мусить це
    показати. `id: None` буває лише коли двигун не віддав НІЧОГО: тоді краще чесно
    сказати «не знаю», ніж підставити модель навмання."""
    alias = alias if alias in _TIER_RULES else 'sonnet'
    tier_label = TIER_LABELS.get(alias, TIER_LABELS['sonnet'])
    parsed = parse_models(models)
    base = {'alias': alias, 'tier_label': tier_label}
    if not parsed:
        return dict(base, id=None, label=None, fallback=True,
                    reason='Двигун не віддав список моделей')

    rules = _TIER_RULES[alias]
    for idx, (vendor, klass, depth_order) in enumerate(rules):
        hit = _pick(parsed, vendor, klass, depth_order)
        if not hit:
            continue
        if idx == 0:
            return dict(base, id=hit['id'], label=hit['label'], fallback=False, reason=None)
        want = _WANT_NAMES.get((rules[0][0], rules[0][1]), 'звичної моделі')
        return dict(base, id=hit['id'], label=hit['label'], fallback=True,
                    reason='%s у видачі двигуна нема, узяли %s' % (want, hit['label'] or hit['id']))

    # Жодне правило не спрацювало: видача складається з незнайомих моделей. Беремо
    # найновішу і чесно кажемо, що це не наш вибір.
    newest = sorted(parsed, key=lambda m: -facets(m['id'])['version'])[0]
    return dict(base, id=newest['id'], label=newest['label'], fallback=True,
                reason='Знайомих моделей у видачі нема, узяли %s' % (newest['label'] or newest['id']))


def resolve_tiers(models):
    """Уся мапа рівнів за один розбір списку. Саме її сервер віддає в UI."""
    parsed = parse_models(models)
    return {a: resolve_tier(a, parsed) for a in MODEL_TIERS}


def model_ids(models):
    """Чисті id без людських назв: для панелей, лічильників і прапорця --model."""
    return [m['id'] for m in parse_models(models)]


def tier_of(mid):
    """Зворотне читання: id БУДЬ-ЯКОГО вендора -> наш рівень, або None.

    Дзеркало `modelTier` у channel-config.ts, свідомо тими самими правилами: панель
    агентів і поповер налаштувань мусять називати одну модель однаково. Правило, а не
    зашитий id: «opus у режимі thinking» це «Геній» і для 4.6, і для будь-якої
    наступної версії."""
    s = (mid or '').strip().lower()
    if not s:
        return None
    f = facets(s)
    if f['vendor'] == 'claude':
        if f['klass'] == 'opus':
            return 'fable' if 'thinking' in s else 'opus'
        if f['klass'] == 'sonnet':
            return 'sonnet'
        if f['klass'] == 'haiku':
            return 'haiku'
        return None
    if f['vendor'] == 'gemini':
        if f['klass'] == 'pro':
            return 'opus'
        if f['klass'] == 'flash':
            return 'haiku' if f['depth'] == 'low' else 'sonnet'
        return 'sonnet'
    if f['vendor'] == 'gpt-oss':
        return 'haiku' if f['depth'] == 'low' else 'sonnet'
    return None


# ── Родина + глибина (specs/agy-model-family-depth) ─────────────────────────
# Чотири рівні вище дивляться рівно на чотири моделі з видачі, решта недосяжні. Кожен
# id agy складається з РОДИНИ, ВЕРСІЇ і ГЛИБИНИ. Версію людина не обирає: найновіша
# підставляється сама в момент ходу. Тому канал зберігає родину і глибину, а не id,
# який протухне з наступним релізом. Функції нижче будуються ПОВЕРХ parse_models і
# нічого не міняють у рівнях: ними і далі живуть агенти та поле `tiers`.

DEPTH_SCALE = ('low', 'medium', 'high')
_DEPTH_TOKENS = DEPTH_SCALE + ('thinking',)
_NUM_RE = re.compile(r'\d+(\.\d+)?')
_INT_RE = re.compile(r'\d+')
_PARENS_RE = re.compile(r'\s*\(([^()]*)\)\s*$')


def split_id(mid):
    """id -> (ключ родини, версія рядком або None, глибина).

    Глибина: останній сегмент low|medium|high, або сегмент thinking будь-де, інакше
    `default`. Версія: перший суто числовий сегмент (`3.8`, `3`) або два суто цифрові
    підряд (`4-6` -> `4.6`). `120b` не версія (є літера), тому це частина родини."""
    segs = (mid or '').strip().lower().split('-')
    depth = 'default'
    if segs and segs[-1] in DEPTH_SCALE:
        depth = segs.pop()
    elif 'thinking' in segs:
        segs.remove('thinking')
        depth = 'thinking'
    ver = None
    for i, s in enumerate(segs):
        if _NUM_RE.fullmatch(s):
            if '.' not in s and i + 1 < len(segs) and _INT_RE.fullmatch(segs[i + 1]):
                ver = s + '.' + segs[i + 1]
                del segs[i:i + 2]
            else:
                ver = s
                del segs[i]
            break
    return '-'.join(segs), ver, depth


def _ver_key(ver):
    return tuple(int(p) for p in ver.split('.')) if ver else ()


def _depth_rank(depth):
    return DEPTH_SCALE.index(depth) if depth in DEPTH_SCALE else len(DEPTH_SCALE)


def _parens_word(label):
    m = _PARENS_RE.search(label or '')
    return m.group(1).strip() if m else None


def is_family_key(key):
    """Ключ родини без токена версії і глибини: саме це дозволено писати в agy-model."""
    if not isinstance(key, str) or not re.fullmatch(r'[a-z0-9][a-z0-9.\-]*', key):
        return False
    fam, ver, depth = split_id(key)
    return ver is None and depth == 'default' and fam == key


def families(models):
    """Жива видача -> [{key, label, version, depths:[{depth, id, label, word, tier}]}].

    Родини в порядку першої появи у видачі, у кожної лише найновіша версія, глибини
    в порядку low, medium, high, далі решта. Незнайома форма id стає ОКРЕМОЮ родиною,
    а не зникає."""
    groups = {}
    order = []
    for i, m in enumerate(parse_models(models)):
        key, ver, depth = split_id(m['id'])
        if not key:
            key = m['id'].lower()
        if key not in groups:
            groups[key] = []
            order.append(key)
        groups[key].append((i, ver, depth, m))
    out = []
    for key in order:
        items = groups[key]
        newest = max(_ver_key(v) for _, v, _, _ in items)
        top = [it for it in items if _ver_key(it[1]) == newest]
        depths = []
        seen = set()
        for i, ver, depth, m in sorted(top, key=lambda it: (_depth_rank(it[2]), it[0])):
            if depth in seen:
                continue
            seen.add(depth)
            depths.append({'depth': depth, 'id': m['id'], 'label': m['label'],
                           'word': _parens_word(m['label']), 'tier': tier_of(m['id'])})
        first = min(top, key=lambda it: it[0])[3]
        label = _PARENS_RE.sub('', first['label'] or '').strip() or key
        out.append({'key': key, 'label': label, 'version': top[0][1], 'depths': depths})
    return out


def _nearest_depth(want, have):
    """Найближча наявна глибина на шкалі low..high, при рівній відстані вища.
    Нестандартна збережена глибина (thinking/default) рахується найглибшою/середньою;
    коли на шкалі нема нічого, береться перша наявна як є."""
    on_scale = [d for d in have if d in DEPTH_SCALE]
    if not on_scale:
        return have[0]
    w = DEPTH_SCALE.index(want) if want in DEPTH_SCALE else (2 if want == 'thinking' else 1)
    return min(on_scale, key=lambda d: (abs(DEPTH_SCALE.index(d) - w), -DEPTH_SCALE.index(d)))


def resolve_family(family, depth, models):
    """Родина + глибина -> конкретна модель найновішої версії живої видачі.

    -> {'family', 'depth', 'id', 'label', 'fallback', 'reason'} або None, коли родини
    у видачі нема (тоді викликач іде старим шляхом resolve_tier)."""
    fam = next((f for f in families(models) if f['key'] == family), None)
    if not fam or not fam['depths']:
        return None
    by = {d['depth']: d for d in fam['depths']}
    if depth in by:
        d = by[depth]
        return {'family': family, 'depth': depth, 'id': d['id'], 'label': d['label'],
                'fallback': False, 'reason': None}
    got = by[_nearest_depth(depth, [d['depth'] for d in fam['depths']])]
    return {'family': family, 'depth': got['depth'], 'id': got['id'], 'label': got['label'],
            'fallback': True,
            'reason': 'У %s нема глибини «%s», узяли %s' % (
                fam['label'], depth, got['label'] or got['id'])}


def locate(mid, models):
    """id живої видачі -> {'family', 'depth'} або None. Потрібне, щоб канал без
    власного вибору показував ту родину і глибину, куди зараз резолвиться його рівень."""
    for f in families(models):
        for d in f['depths']:
            if d['id'] == mid:
                return {'family': f['key'], 'depth': d['depth']}
    return None


AGY_MODEL_FILE = 'agy-model'


def clean_choice(raw):
    """Сирий вибір (з файла або знімка черги) -> {'family','depth','tier'} або None.
    Битий тип, версійний ключ чи зайві поля не доживають до ходу."""
    if not isinstance(raw, dict):
        return None
    fam = raw.get('family')
    depth = raw.get('depth')
    tier = raw.get('tier')
    if not is_family_key(fam) or not isinstance(depth, str) \
            or not re.fullmatch(r'[a-z]+', depth):
        return None
    out = {'family': fam, 'depth': depth}
    if isinstance(tier, str) and tier.strip():
        out['tier'] = tier.strip()
    return out


def read_choice(ch_dir):
    """Файл agy-model теки каналу -> чистий вибір або None. Єдиний читач і для
    сервера (знімок черги, channel-state), і для раннера (запасний шлях ходу)."""
    try:
        with open(os.path.join(ch_dir, AGY_MODEL_FILE), encoding='utf-8') as f:
            return clean_choice(json.load(f))
    except Exception:
        return None
