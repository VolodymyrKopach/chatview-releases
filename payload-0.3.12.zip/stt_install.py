#!/usr/bin/env python3
"""Завантажувач локального розпізнавача: ваги Whisper + бінарник whisper.cpp.

НАВІЩО. Роздавальна збірка не везе ані бінарника, ані ваг (самі ваги це півтора
гігабайти в кожному завантаженні), тому `server._local_stt_ready()` там завжди
False, шлях іде в хмару, а без ключа людина впирається в картку «додайте свій
ключ OpenAI». Для неї це звучить як «платно або ніяк», хоча безкоштовний шлях
технічно вже підтриманий: увесь код локального розпізнавання в застосунку є.
Бракує рівно завантажувача, і це він (specs/mic-two-ways, М2).

ГОЛОВНЕ РІШЕННЯ: НЕДОВАНТАЖЕНЕ НЕ ЛЕЖИТЬ ТАМ, ДЕ ГОТОВЕ. Ризик зі спеки звучить
так: обрив на девʼяноста відсотках лишає биті файли, `_local_stt_ready()` бачить
наявність файлу як готовність, і розпізнавання падає незрозумілою помилкою. Тут
це закрито не прапорцем, а ГЕОМЕТРІЄЮ: байти течуть у `.staging/<імʼя>.part`, і
файл зʼявляється за своєю робочою адресою рівно одним `os.replace` ПІСЛЯ того, як
збігся sha256. Тобто немає стану, в якому за робочою адресою лежить половина
файлу: ані після обриву мережі, ані після SIGKILL, ані після падіння живлення.
Прапорець можна забути виставити, а неатомарного шляху тут просто не існує.

ЧОМУ ЦЕ ОКРЕМИЙ ПРОЦЕС, А НЕ НИТКА В СЕРВЕРІ. Панель процесів (`jobs.py`) вміє
показувати і ЗУПИНЯТИ те, що має власний pid. Нитка всередині сервера мала б pid
самого сервера, а він у захищеному списку (`jobs.PROTECTED_NAMES`), тому кнопка
Стоп чесно відмовила б, і людина, яка передумала качати півтора гігабайти, не
мала б жодного способу це спинити. Тому воркер це власний процес у власній
сесії, як агент і вартовий, і зупиняє його та сама кнопка, що й їх.

БЕЗ ЖОДНОГО ТОКЕНА (К9). У запити йде рівно один заголовок, `User-Agent`. Це не
акуратність, а вимога: ваги беруться з Hugging Face, бінарник з GitHub Releases,
і обидві платформи дозволяють таке завантаження саме доти, доки трафік іде як
звичайний публічний. Заборона прибита тестом, який читає дерево цього файлу і
падає на будь-якому заголовку авторизації.

ПОСИЛАННЯ ПРИБИТІ ДО РЕВІЗІЇ І ДО sha256. Hugging Face віддає `resolve/<коміт>`,
GitHub Releases віддає нерухомий тег. Якщо файл на тому боці колись підмінять,
звірка хешу впаде з чесною причиною замість того, щоб мовчки покласти людині на
диск інші ваги.
"""
import io
import os
import sys
import json
import time
import shutil
import signal
import hashlib
import platform
import tarfile
import tempfile
import zipfile
import urllib.error
import urllib.request

#: Дім ДАНИХ. Та сама формула, що `server.py:36` і `entities.data_root()`.
HOME = os.environ.get('CHATVIEW_HOME') or os.path.dirname(os.path.abspath(__file__))

#: Корінь локального розпізнавача. Свідомо ТОЙ САМИЙ, що вже шукає
#: `server.WHISPER_BIN`/`WHISPER_MODEL` (`<дім>/whisper/build/bin`,
#: `<дім>/whisper/models`): машина, де whisper.cpp зібрано руками, мусить
#: працювати як раніше, а не отримати другу копію на 1.6 ГБ поруч.
#:
#: ЧОМУ ЦЕЙ КОРІНЬ НЕ В РЕЄСТРІ КЛАСІВ (`entities.py`). За правилом трьох шухляд
#: це чистий `cache`: зникло означає «качається наново, витратили час і канал, а
#: не памʼять людини». Але додати клас це правка `entities.py`, а вона поза межею
#: цієї задачі (специфікація прямо називає архітектуру даних закритою). Тому тут
#: береться АДРЕСА, ЯКА ВЖЕ ІСНУЄ, і в звіті стоїть окремим рядком, що один запис
#: у реєстрі досі не зроблено.
ROOT = os.path.join(HOME, 'whisper')
MODELS_DIR = os.path.join(ROOT, 'models')
BIN_DIR = os.path.join(ROOT, 'build', 'bin')
STAGING_DIR = os.path.join(ROOT, '.staging')
STATE_PATH = os.path.join(ROOT, 'install.json')

#: Єдиний заголовок, який ми ставимо. Див. К9 у докстрінгу модуля.
UA = 'ChatView-STT-Installer'

#: Розмір шматка читання. Дрібніший робить поступ плавнішим, але й частішим
#: викликом до реєстру процесів; 1 МБ це компроміс, при якому реакція на Стоп
#: лишається під секунду навіть на повільному каналі.
CHUNK = 1024 * 1024

#: Як часто звітувати в панель процесів. Кожен шматок писав би у файл реєстру
#: сотні разів на секунду на швидкому каналі.
BEAT_SEC = 1.0

# ── що саме качаємо ─────────────────────────────────────────────────────────

#: Ваги. `large-v3-turbo` це офіційна швидка версія large-v3: якість близька до
#: повного large-v3 при вазі 1.62 ГБ проти 3.10 ГБ (обидва числа заміряні
#: `content-length` на Hugging Face 2026-09-04, не взяті з памʼяті). Повний large
#: відлякує трьома гігабайтами на першому ж екрані, `medium` важить майже стільки
#: ж (1.53 ГБ), але помітно гірший на українській.
MODEL = {
    'key': 'model',
    'name': 'ggml-large-v3-turbo.bin',
    'human': 'ваги Whisper large-v3-turbo',
    # `resolve/<коміт>`, а не `resolve/main`: прибите посилання не змінюється під
    # ногами між планом і завантаженням.
    'url': ('https://huggingface.co/ggerganov/whisper.cpp/resolve/'
            '5359861c739e955e79d9a303bcbc70fb988958b1/ggml-large-v3-turbo.bin'),
    'sha256': '1fc70f774d38eb169993ac391eea357ef47c88757ef72ee5943879b7e8e2bc69',
    'bytes': 1624555275,
    'unpacked': 1624555275,
    'kind': 'file',
    'dest': os.path.join('models', 'ggml-large-v3-turbo.bin'),
}

#: Бінарник whisper.cpp по платформах. Ключ це (`sys.platform`, розрядність/арх),
#: значення це нерухомий ассет релізу b4938 з опублікованим sha256 (звірено
#: локально: завантажене дає той самий хеш, що віддає GitHub API).
#:
#: MACOS ТУТ НЕМАЄ, І ЦЕ НЕ ПРОПУСК. whisper.cpp не публікує macOS-CLI у
#: Releases взагалі: там лише Windows, Ubuntu і xcframework (бібліотека, не
#: програма). Обхідні джерела кожне має ціну, і вибір між ними це рішення з
#: юридичним і ланцюговим наслідком, а не деталь реалізації, тому воно винесене
#: в звіт, а не вгадане тут. Поки джерела нема, план для macOS чесно каже про це
#: одним реченням і все одно везе ВАГИ: вони і є важка частина, і коли джерело
#: зʼявиться, качати їх удруге не доведеться.
RUNTIMES = {
    ('win32', 'x64'): {
        'key': 'runtime',
        'name': 'whisper-bin-x64.zip',
        'human': 'бінарник whisper.cpp для Windows',
        'url': ('https://github.com/ggml-org/whisper.cpp/releases/download/'
                'b4938/whisper-bin-x64.zip'),
        'sha256': 'c2a4b60edb11f7e11a9191ffb50929535527d4d91c9903dbe3e554583bbbc63d',
        'bytes': 8361840,
        'unpacked': 21213696,
        'kind': 'zip',
        'strip': 'Release/',
        'dest': os.path.join('build', 'bin'),
        'expect': 'whisper-cli.exe',
    },
    ('linux', 'x64'): {
        'key': 'runtime',
        'name': 'whisper-bin-ubuntu-x64.tar.gz',
        'human': 'бінарник whisper.cpp для Linux',
        'url': ('https://github.com/ggml-org/whisper.cpp/releases/download/'
                'b4938/whisper-bin-ubuntu-x64.tar.gz'),
        'sha256': 'f4cfc1f969a13805908fb72043ce7cc896eb42e0b8afbe841dc8e7298923b061',
        'bytes': 9503425,
        'unpacked': 24527510,
        'kind': 'tar',
        'strip': 'whisper-bin-ubuntu-x64/',
        'dest': os.path.join('build', 'bin'),
        'expect': 'whisper-cli',
    },
    ('linux', 'arm64'): {
        'key': 'runtime',
        'name': 'whisper-bin-ubuntu-arm64.tar.gz',
        'human': 'бінарник whisper.cpp для Linux ARM',
        'url': ('https://github.com/ggml-org/whisper.cpp/releases/download/'
                'b4938/whisper-bin-ubuntu-arm64.tar.gz'),
        'sha256': '94a33318650c57cc3d9a91439e0e3f0b94ba96bacd34203a06db395cf9204e40',
        'bytes': 4572294,
        'unpacked': 11000000,
        'kind': 'tar',
        'strip': 'whisper-bin-ubuntu-arm64/',
        'dest': os.path.join('build', 'bin'),
        'expect': 'whisper-cli',
    },
}

#: Чому бінарника нема для цієї платформи. Показується людині як є.
NO_RUNTIME = {
    'darwin': 'whisper.cpp не публікує готового бінарника для macOS: у релізах '
              'лише Windows, Linux і бібліотека для Xcode. Ваги завантажаться, '
              'але сам розпізнавач доведеться взяти окремо.',
}

#: Розміри офіційних ggml-моделей. Потрібні НЕ для краси: файл за робочою адресою
#: мусить мати рівно свій розмір, інакше він недовантажений або обрізаний диском,
#: і краще сказати це вголос, ніж дати whisper-cli впасти незрозумілою помилкою.
#: Числа заміряні `content-length` на Hugging Face 2026-09-04.
KNOWN_MODEL_BYTES = {
    'ggml-large-v3-turbo.bin': 1624555275,
    'ggml-large-v3.bin': 3095033483,
    'ggml-medium.bin': 1533763059,
}

#: Мінімум, нижче якого файл ваг не може бути справжнім (найменша офіційна модель
#: `tiny` важить близько 75 МБ). Мірка для моделі, якої нема в таблиці вище.
MIN_MODEL_BYTES = 50 * 1024 * 1024


# ── платформа ───────────────────────────────────────────────────────────────

def arch():
    """Архітектура в іменах, якими підписані ассети релізу."""
    m = (platform.machine() or '').lower()
    if m in ('arm64', 'aarch64'):
        return 'arm64'
    if m in ('amd64', 'x86_64', 'x64'):
        return 'x64'
    return m or 'unknown'


def runtime_asset(plat=None, ar=None):
    """Ассет бінарника для цієї платформи або None, якщо його не публікують."""
    return RUNTIMES.get((plat or sys.platform, ar or arch()))


def runtime_gap(plat=None):
    """Людське речення, чому бінарника не буде. Порожньо, якщо буде."""
    plat = plat or sys.platform
    if runtime_asset(plat):
        return ''
    return NO_RUNTIME.get(plat) or (
        'для платформи «%s» готового бінарника whisper.cpp у релізах немає.' % plat)


# ── план і чесна ціна (К7) ──────────────────────────────────────────────────

def assets():
    """Що саме поїде по мережі цього разу. Порядок сталий: спершу дрібний
    бінарник, потім важкі ваги. Так людина бачить рух поступу за секунди, а не
    через хвилину мовчання, і обрив на дрібному коштує їй копійки."""
    out = []
    rt = runtime_asset()
    if rt:
        out.append(rt)
    out.append(MODEL)
    return out


def plan():
    """Повний план для інтерфейсу (К7: чесна ціна ДО початку). -> dict.

    `downloadBytes` це трафік, `diskBytes` це місце на диску після розпакування.
    Це різні числа (архів бінарника розпаковується вдвічі-втричі), і показувати
    одне замість двох означало б збрехати в один бік."""
    items = assets()
    have = installed()
    return {
        'root': ROOT,
        'platform': sys.platform,
        'arch': arch(),
        'runtimeGap': runtime_gap(),
        'items': [{'key': a['key'], 'name': a['name'], 'human': a['human'],
                   'bytes': a['bytes'], 'unpacked': a['unpacked'],
                   'url': a['url']} for a in items],
        'downloadBytes': sum(a['bytes'] for a in items),
        'diskBytes': sum(a['unpacked'] for a in items),
        'ready': ready(),
        'have': have,
    }


def human_bytes(n):
    """Байти -> рядок для людини. ГБ рахуються по 1000, як їх рахують провайдери
    і як їх бачить людина в рахунку за трафік, а не по 1024."""
    n = float(n or 0)
    for unit, step in (('ТБ', 1000 ** 4), ('ГБ', 1000 ** 3), ('МБ', 1000 ** 2), ('КБ', 1000)):
        if n >= step:
            return ('%.2f %s' % (n / step, unit)) if step >= 1000 ** 3 else ('%.0f %s' % (n / step, unit))
    return '%d Б' % int(n)


# ── готовність (К5: недовантажене не видається за готове) ───────────────────

def model_path():
    """Шлях до ваг, які РЕАЛЬНО придатні. Порожньо, якщо придатних нема.

    Перевіряються не лише наявність, а й розмір: файл ваг з відомим іменем
    мусить важити рівно стільки, скільки важить оригінал. Обрізаний диском або
    підмінений файл тут відсіюється, а не в момент диктування."""
    env = os.environ.get('WHISPER_MODEL')
    cands = [env] if env else []
    try:
        names = sorted(os.listdir(MODELS_DIR))
    except OSError:
        names = []
    # Наш керований файл першим, далі решта ggml-моделей у теці (рукозбірка автора).
    for n in [MODEL['name']] + [x for x in names if x.endswith('.bin') and x != MODEL['name']]:
        cands.append(os.path.join(MODELS_DIR, n))
    for p in cands:
        if p and model_ok(p) is None:
            return p
    return ''


def model_ok(path):
    """Чи це справжні, цілі ваги. -> None (так) | причина українською."""
    try:
        size = os.path.getsize(path)
    except OSError:
        return 'файла ваг немає за адресою %s' % path
    want = KNOWN_MODEL_BYTES.get(os.path.basename(path))
    if want is not None and size != want:
        return ('файл ваг «%s» важить %s замість %s: він недовантажений або '
                'обрізаний' % (os.path.basename(path), human_bytes(size), human_bytes(want)))
    if want is None and size < MIN_MODEL_BYTES:
        return ('файл ваг «%s» важить %s, це менше за найменшу справжню модель'
                % (os.path.basename(path), human_bytes(size)))
    try:
        with open(path, 'rb') as fh:
            head = fh.read(4)
    except OSError as e:
        return 'файл ваг не читається: %s' % e
    # ggml-файл починається магією 'ggml'. Дешева перевірка, яка ловить випадок
    # «замість ваг лежить html-сторінка помилки з проксі».
    if head[:4] not in (b'ggml', b'lmgg'):
        return 'файл ваг «%s» не схожий на модель ggml' % os.path.basename(path)
    return None


def bin_path():
    """Шлях до whisper-cli, придатного до запуску. Порожньо, якщо такого нема."""
    exe = 'whisper-cli.exe' if os.name == 'nt' else 'whisper-cli'
    cands = [os.environ.get('WHISPER_CLI_BIN'),
             os.path.join(BIN_DIR, exe),
             os.path.join('/opt/homebrew/bin', exe),
             os.path.join('/usr/local/bin', exe)]
    for p in cands:
        if not p or not os.path.isfile(p):
            continue
        if os.name != 'nt' and not os.access(p, os.X_OK):
            continue
        return p
    return ''


def ready():
    """Чи можливе локальне розпізнавання ПРЯМО ЗАРАЗ. -> bool.

    Свідомо рахується щоразу заново, а не один раз на імпорті: після успішного
    завантаження людина мусить отримати робочий мікрофон одразу, а не після
    перезапуску застосунку."""
    return bool(bin_path()) and bool(model_path())


def installed():
    """Що вже лежить на диску. Для інтерфейсу і для звіту."""
    b, m = bin_path(), model_path()
    return {'binary': b, 'model': m,
            'modelBytes': (os.path.getsize(m) if m else 0)}


# ── стан установки на диску ─────────────────────────────────────────────────

def read_state():
    try:
        with open(STATE_PATH, encoding='utf-8') as fh:
            data = json.load(fh)
            return data if isinstance(data, dict) else {}
    except Exception:
        return {}


def write_state(patch):
    """Дописати у стан установки атомарно. Ніколи не кидає."""
    try:
        os.makedirs(ROOT, exist_ok=True)
        cur = read_state()
        cur.update(patch)
        cur['updatedAt'] = time.time()
        tmp = STATE_PATH + '.tmp'
        with open(tmp, 'w', encoding='utf-8') as fh:
            json.dump(cur, fh, ensure_ascii=False, indent=2)
        os.replace(tmp, STATE_PATH)
        return cur
    except Exception:
        return {}


def status():
    """Стан для інтерфейсу: план + остання спроба + що лежить на диску."""
    st = read_state()
    return {'ok': True, 'ready': ready(), 'plan': plan(),
            'state': st.get('state') or 'idle',
            'reason': st.get('reason') or '',
            'jobId': st.get('jobId') or '',
            'startedAt': st.get('startedAt'), 'endedAt': st.get('endedAt'),
            'resumable': bool(_parts())}


def _parts():
    """Недовантажені шматки в staging: саме вони роблять повтор дешевим."""
    out = {}
    try:
        for n in os.listdir(STAGING_DIR):
            if n.endswith('.part'):
                out[n[:-5]] = os.path.getsize(os.path.join(STAGING_DIR, n))
    except OSError:
        pass
    return out


# ── саме завантаження ───────────────────────────────────────────────────────

class Stopped(Exception):
    """Людина натиснула Стоп. Не помилка, окремий стан."""


def _sha256(path, cancel=None):
    h = hashlib.sha256()
    with open(path, 'rb') as fh:
        for block in iter(lambda: fh.read(CHUNK), b''):
            if cancel and cancel():
                raise Stopped()
            h.update(block)
    return h.hexdigest()


def _request(url, start=0):
    """Запит БЕЗ автентифікації. Один заголовок, і це `User-Agent` (К9).

    `Range` додається лише коли продовжуємо обірване: інакше повтор на 1.6 ГБ
    качав би все з нуля, і людина, у якої зірвалось на девʼяноста відсотках,
    платила б за чужий обрив повною ціною."""
    headers = {'User-Agent': UA}
    if start:
        headers['Range'] = 'bytes=%d-' % start
    return urllib.request.Request(url, headers=headers)


def _download(asset, on_progress, cancel, log):
    """Завантажити один ассет у staging і звірити sha256. -> шлях до цілого файлу.

    Файл лежить у `.staging/<імʼя>.part` доти, доки хеш не збігся. Лише після
    збігу він стає `.staging/<імʼя>`, і вже звідти його ставлять на місце. Тобто
    обрив будь-де лишає по собі рівно `.part`, який ніхто не сплутає з готовим."""
    os.makedirs(STAGING_DIR, exist_ok=True)
    part = os.path.join(STAGING_DIR, asset['name'] + '.part')
    whole = os.path.join(STAGING_DIR, asset['name'])
    if os.path.exists(whole):
        log('вже завантажено раніше: %s' % asset['name'])
        return whole

    have = os.path.getsize(part) if os.path.exists(part) else 0
    if have > asset['bytes']:
        log('обірваний шматок більший за очікуваний файл, починаю спочатку')
        os.remove(part)
        have = 0
    if have:
        log('продовжую з %s (уже було %s)' % (human_bytes(have), human_bytes(have)))

    total = asset['bytes']
    mode = 'ab' if have else 'wb'
    try:
        with urllib.request.urlopen(_request(asset['url'], have), timeout=60) as r:
            code = getattr(r, 'status', None) or r.getcode()
            if have and code != 206:
                # Сервер не підтримав докачку: чесно починаємо спочатку, а не
                # доклеюємо початок файлу до вже завантаженого хвоста.
                log('сервер не вміє докачку, качаю з нуля')
                have, mode = 0, 'wb'
            with open(part, mode) as out:
                done = have
                last = 0.0
                while True:
                    if cancel():
                        raise Stopped()
                    block = r.read(CHUNK)
                    if not block:
                        break
                    out.write(block)
                    done += len(block)
                    now = time.time()
                    if now - last >= BEAT_SEC:
                        last = now
                        on_progress(done, total)
                on_progress(done, total)
    except urllib.error.HTTPError as e:
        raise RuntimeError('сервер відповів %s %s на %s'
                           % (e.code, e.reason, asset['name']))
    except urllib.error.URLError as e:
        raise RuntimeError('не вдалось достукатись до сервера (%s)' % e.reason)

    got = os.path.getsize(part)
    if got != total:
        raise RuntimeError('звʼязок обірвався: завантажено %s з %s'
                           % (human_bytes(got), human_bytes(total)))
    log('звіряю контрольну суму %s' % asset['name'])
    digest = _sha256(part, cancel)
    if digest != asset['sha256']:
        os.remove(part)
        raise RuntimeError(
            'файл «%s» завантажився пошкодженим (контрольна сума не збіглась). '
            'Спробуйте ще раз.' % asset['name'])
    os.replace(part, whole)
    return whole


def _place_file(src, asset):
    """Поставити цілий файл на робоче місце ОДНИМ атомарним рухом."""
    dest = os.path.join(ROOT, asset['dest'])
    os.makedirs(os.path.dirname(dest), exist_ok=True)
    os.replace(src, dest)
    return dest


def _safe_members(names, strip):
    """Імена з архіву -> (імʼя в архіві, імʼя на диску), з відкинутим виходом.

    Той самий захист від zip-slip, що і в оновлювачі: запис з `..` або з
    абсолютним шляхом не розпаковується взагалі."""
    out = []
    for n in names:
        rel = n[len(strip):] if strip and n.startswith(strip) else n
        rel = rel.replace('\\', '/').strip('/')
        if not rel or rel.endswith('/'):
            continue
        if '..' in rel.split('/') or os.path.isabs(rel):
            continue
        out.append((n, os.path.basename(rel)))
    return out


def _place_archive(src, asset, log):
    """Розпакувати архів бінарника у `build/bin` і зробити whisper-cli запускним.

    Розпаковуємо ПЛОСКО: whisper-cli шукає свої бібліотеки поруч із собою, і
    рівно так лежить рукозбірка автора, тому одна тека це не спрощення, а
    збіг із тим, що вже працює."""
    dest = os.path.join(ROOT, asset['dest'])
    tmp = dest + '.new'
    shutil.rmtree(tmp, ignore_errors=True)
    os.makedirs(tmp, exist_ok=True)
    if asset['kind'] == 'zip':
        with zipfile.ZipFile(src) as zf:
            for inner, flat in _safe_members(zf.namelist(), asset.get('strip')):
                with zf.open(inner) as fh, open(os.path.join(tmp, flat), 'wb') as out:
                    shutil.copyfileobj(fh, out)
    else:
        with tarfile.open(src) as tf:
            for inner, flat in _safe_members([m.name for m in tf.getmembers() if m.isfile()],
                                             asset.get('strip')):
                fh = tf.extractfile(inner)
                if fh is None:
                    continue
                with fh, open(os.path.join(tmp, flat), 'wb') as out:
                    shutil.copyfileobj(fh, out)
    want = asset.get('expect')
    if want and not os.path.exists(os.path.join(tmp, want)):
        shutil.rmtree(tmp, ignore_errors=True)
        raise RuntimeError('в архіві «%s» немає %s' % (asset['name'], want))
    if os.name != 'nt':
        for n in os.listdir(tmp):
            p = os.path.join(tmp, n)
            if os.path.isfile(p):
                try:
                    os.chmod(p, os.stat(p).st_mode | 0o111)
                except OSError:
                    pass
    os.makedirs(os.path.dirname(dest), exist_ok=True)
    old = dest + '.old'
    shutil.rmtree(old, ignore_errors=True)
    if os.path.isdir(dest):
        os.replace(dest, old)
    os.replace(tmp, dest)
    shutil.rmtree(old, ignore_errors=True)
    try:
        os.remove(src)
    except OSError:
        pass
    log('розпаковано в %s' % dest)
    return dest


def install(job_id='', log=None, cancel=None):
    """Завантажити і поставити все, чого бракує. -> dict з підсумком.

    Ніколи не лишає застосунок у півстані: усе, що не доїхало, лишається під
    `.staging/` і не бачиться перевіркою готовності (К5)."""
    log = log or (lambda *_: None)
    cancel = cancel or (lambda: False)
    try:
        import jobs as _jobs
    except Exception:
        _jobs = None

    items = assets()
    total = sum(a['bytes'] for a in items)
    done_before = 0
    gap = runtime_gap()
    if gap:
        log('УВАГА: %s' % gap)

    write_state({'state': 'running', 'reason': '', 'jobId': job_id,
                 'startedAt': time.time(), 'endedAt': None,
                 'plan': {'downloadBytes': total, 'diskBytes': sum(a['unpacked'] for a in items)}})

    def beat(step, pct):
        if _jobs and job_id:
            _jobs.progress(job_id, step=step, pct=pct)

    try:
        for asset in items:
            base = done_before

            def on_progress(done, tot, _a=asset, _b=base):
                overall = (_b + done) * 100.0 / max(1, total)
                beat('%s: %s з %s' % (_a['human'], human_bytes(done), human_bytes(tot)),
                     overall)

            log('качаю %s (%s) з %s' % (asset['human'], human_bytes(asset['bytes']), asset['url']))
            src = _download(asset, on_progress, cancel, log)
            beat('%s: ставлю на місце' % asset['human'], (base + asset['bytes']) * 100.0 / max(1, total))
            if asset['kind'] == 'file':
                where = _place_file(src, asset)
            else:
                where = _place_archive(src, asset, log)
            log('готово: %s -> %s' % (asset['name'], where))
            done_before += asset['bytes']
    except Stopped:
        write_state({'state': 'stopped', 'endedAt': time.time(),
                     'reason': 'Завантаження зупинено. Уже завантажене збережено, '
                               'повтор продовжить з того самого місця.'})
        log('зупинено людиною')
        return {'ok': False, 'stopped': True, 'ready': ready()}
    except Exception as e:
        write_state({'state': 'failed', 'endedAt': time.time(), 'reason': str(e)})
        log('помилка: %s' % e)
        return {'ok': False, 'error': str(e), 'ready': ready()}

    ok = ready()
    reason = '' if ok else (
        gap or 'завантаження пройшло, але розпізнавач досі не збирається запускатись')
    write_state({'state': 'ok' if ok else 'failed', 'endedAt': time.time(),
                 'reason': reason, 'installed': installed()})
    beat('готово', 100)
    log('підсумок: ready=%s %s' % (ok, reason))
    return {'ok': ok, 'ready': ok, 'reason': reason, 'installed': installed()}


# ── запуск і зупинка з боку сервера ─────────────────────────────────────────

JOB_KIND = 'stt-install'
JOB_LABEL = 'Локальний розпізнавач: завантаження'


def _worker_argv():
    """Чим запускати воркера. У замороженій збірці `sys.executable` це САМ
    ChatView, віддати йому .py неможливо (він підняв би другий сервер), тому там
    лаунчер має власний режим. Точно та сама розвилка, що в `jobs._agent_argv`."""
    if getattr(sys, 'frozen', False):
        return [sys.executable, '--stt-install']
    return [sys.executable, os.path.abspath(__file__), '--run']


def running_job():
    """Живий рядок цієї установки в панелі процесів або None."""
    try:
        import jobs as _jobs
        for j in _jobs.list_jobs(running_only=True):
            if j.get('kind') == JOB_KIND:
                return j
    except Exception:
        pass
    return None


def start(channel=''):
    """Запустити завантаження власним процесом. -> (job, error).

    Другий запуск поверх живого НЕ робиться: два процеси, що пишуть у той самий
    `.part`, зіпсували б файл один одному, і вилізло б це аж на звірці хешу."""
    live = running_job()
    if live:
        return live, None
    if ready():
        return None, 'локальний розпізнавач уже встановлено'
    try:
        import jobs as _jobs
    except Exception as e:
        return None, 'реєстр процесів недоступний: %s' % e
    os.makedirs(ROOT, exist_ok=True)
    try:
        proc = __import__('subprocess').Popen(
            _worker_argv(), cwd=ROOT,
            stdout=__import__('subprocess').DEVNULL,
            stderr=__import__('subprocess').DEVNULL,
            **_jobs._spawn_kwargs())
    except Exception as e:
        return None, 'не вдалось запустити завантажувач: %s' % e
    items = assets()
    job = _jobs.register(
        JOB_KIND, channel, proc.pid, label=JOB_LABEL,
        why='качає %s, щоб мікрофон працював без ключа OpenAI'
            % human_bytes(sum(a['bytes'] for a in items)),
        meta={'downloadBytes': sum(a['bytes'] for a in items),
              'diskBytes': sum(a['unpacked'] for a in items),
              'log': log_path()})
    if not job:
        return None, 'не вдалось зареєструвати процес у панелі'
    write_state({'state': 'running', 'reason': '', 'jobId': job['jobId'],
                 'startedAt': time.time(), 'endedAt': None})
    return job, None


def stop(job_id=''):
    """Зупинити завантаження тією самою кнопкою, що зупиняє агентів."""
    try:
        import jobs as _jobs
    except Exception as e:
        return {'ok': False, 'reason': str(e)}
    if not job_id:
        live = running_job()
        if not live:
            return {'ok': True, 'reason': 'нічого не качається'}
        job_id = live['jobId']
    return _jobs.stop(job_id)


# ── запуск воркером ─────────────────────────────────────────────────────────

LOG_NAME = 'stt-install.log'

_STOP = {'flag': False}


def log_path():
    return os.path.join(ROOT, LOG_NAME)


def _install_job_id(timeout=8.0):
    """Свій рядок у панелі процесів. Сервер дописує jobId у стан ПІСЛЯ спавну,
    тому чекаємо його: та сама домовленість, що в agent_worker._close_jobs."""
    end = time.time() + timeout
    while time.time() < end:
        jid = read_state().get('jobId')
        if jid:
            return jid
        time.sleep(0.2)
    return ''


def main(argv=None):
    argv = list(argv if argv is not None else sys.argv[1:])
    if '--plan' in argv:
        print(json.dumps(plan(), ensure_ascii=False, indent=2))
        return 0
    if '--status' in argv:
        print(json.dumps(status(), ensure_ascii=False, indent=2))
        return 0

    os.makedirs(ROOT, exist_ok=True)
    fh = open(log_path(), 'a', encoding='utf-8')

    def log(msg):
        line = '%s %s\n' % (time.strftime('%H:%M:%S'), msg)
        fh.write(line)
        fh.flush()
        sys.stderr.write(line)

    job_id = _install_job_id()

    def on_signal(signum, _frame):
        # Стан пишемо ПРЯМО ТУТ, а не після розкрутки: панель б'є SIGTERM і через
        # 0.4 с добиває SIGKILL, тобто на охайне завершення часу може не бути.
        _STOP['flag'] = True
        write_state({'state': 'stopped', 'endedAt': time.time(),
                     'reason': 'Завантаження зупинено. Уже завантажене збережено, '
                               'повтор продовжить з того самого місця.'})
        log('сигнал %s: зупиняюсь' % signum)

    for sig in (signal.SIGTERM, signal.SIGINT):
        try:
            signal.signal(sig, on_signal)
        except (ValueError, OSError):
            pass

    log('старт установки локального розпізнавача, дім=%s job=%s' % (HOME, job_id or '-'))
    res = install(job_id=job_id, log=log, cancel=lambda: _STOP['flag'])
    try:
        import jobs as _jobs
        if job_id:
            state = 'done' if res.get('ok') else ('stopped' if res.get('stopped') else 'failed')
            _jobs.finish(job_id, state, res.get('reason') or res.get('error') or '')
    except Exception:
        pass
    fh.close()
    return 0 if res.get('ok') else 1


if __name__ == '__main__':
    sys.exit(main())
