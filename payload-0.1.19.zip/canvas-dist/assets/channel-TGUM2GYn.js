import{aq as o,ar as n}from"./mermaid.core-B56d7h_3.js";const t=(r,a)=>o.lang.round(n.parse(r)[a]);export{t as c};
