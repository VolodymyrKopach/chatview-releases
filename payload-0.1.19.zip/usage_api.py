"""usage_api.py: pull the REAL per-window rate-limit utilization from Anthropic.

WHY this module exists (the bug it fixes):
  The SDK's streamed `rate_limit_event` (RateLimitInfo) does NOT carry `utilization`
  in the steady "allowed" state — the CLI only sends status/resetsAt/rateLimitType,
  utilization is None. So capturing from the stream can never show a real "used %".
  The number the Claude Code `/usage` panel shows comes from a PULL endpoint:
      GET https://api.anthropic.com/api/oauth/usage
  which returns per-window objects, e.g.:
      {"five_hour": {"utilization": 25.0, "resets_at": "2026-07-06T16:00:00+00:00", ...},
       "seven_day": {"utilization": 64.0, "resets_at": "2026-07-09T21:00:00+00:00", ...},
       "seven_day_opus": null, "seven_day_sonnet": null, ...}
  `utilization` is a PERCENT (0..100). This module fetches it (OAuth token from the
  same place the CLI stores it) and writes it into rate-limit.json so the usage panel
  shows the true per-window %.

Best-effort everywhere: any failure (no token, offline, 401, parse error) returns
without touching rate-limit.json, so the panel just keeps the last-known values.
"""
import os
import json
import time
import threading
import subprocess
import urllib.request
from datetime import datetime, timezone

_DIR = os.path.dirname(os.path.abspath(__file__))
_RLP = os.path.join(_DIR, 'rate-limit.json')
_USAGE_URL = 'https://api.anthropic.com/api/oauth/usage'

# Windows we surface, in the order the API exposes them. Anything with a non-null
# object + numeric utilization gets written; null windows are skipped.
_WINDOWS = ('five_hour', 'seven_day', 'seven_day_opus', 'seven_day_sonnet',
            'seven_day_oauth_apps', 'seven_day_cowork')

# TTL cache so a UI that polls usage-stats every few seconds does not hammer the
# endpoint. We refresh at most once per _TTL seconds.
_TTL = 30.0
_last_fetch = 0.0
_lock = threading.Lock()


def _oauth_token():
    """The CLI's OAuth access token, from (in order): macOS keychain, the
    ~/.claude/.credentials.json file, or the CLAUDE_CODE_OAUTH_TOKEN env var.
    Returns None if none is available."""
    # 1) macOS keychain (where `claude` stores it on a Mac).
    try:
        out = subprocess.run(
            ['security', 'find-generic-password', '-s', 'Claude Code-credentials', '-w'],
            capture_output=True, text=True, timeout=4)
        if out.returncode == 0 and out.stdout.strip():
            d = json.loads(out.stdout.strip())
            tok = (d.get('claudeAiOauth') or {}).get('accessToken')
            if tok:
                return tok
    except Exception:
        pass
    # 2) credentials file (Linux / non-keychain installs).
    try:
        p = os.path.expanduser('~/.claude/.credentials.json')
        if os.path.exists(p):
            d = json.load(open(p, encoding='utf-8'))
            tok = (d.get('claudeAiOauth') or {}).get('accessToken')
            if tok:
                return tok
    except Exception:
        pass
    # 3) explicit env override.
    return os.environ.get('CLAUDE_CODE_OAUTH_TOKEN') or None


def _iso_to_unix_str(v):
    """API resets_at is an ISO-8601 string; rate-limit.json stores resetsAt as a
    UNIX-seconds string (server._reset_in_past does float(ra)). Convert so the
    past-reset / countdown logic keeps working. Returns None on failure."""
    if v is None:
        return None
    if isinstance(v, (int, float)):
        return str(int(v))
    try:
        s = str(v).replace('Z', '+00:00')
        dt = datetime.fromisoformat(s)
        if dt.tzinfo is None:
            dt = dt.replace(tzinfo=timezone.utc)
        return str(int(dt.timestamp()))
    except Exception:
        return None


def _fetch():
    """GET /api/oauth/usage → parsed dict, or None on any failure."""
    tok = _oauth_token()
    if not tok:
        return None
    req = urllib.request.Request(_USAGE_URL, headers={
        'Authorization': 'Bearer ' + tok,
        'anthropic-beta': 'oauth-2025-04-20',
        'Content-Type': 'application/json',
    })
    try:
        with urllib.request.urlopen(req, timeout=5) as r:
            return json.loads(r.read().decode('utf-8'))
    except Exception:
        return None


def _merge_into_rate_limit(usage):
    """Write the API's per-window utilization into rate-limit.json's `limits`,
    preserving any other (stream-captured) entries. Overwrites only the windows
    the API actually reports with a numeric utilization."""
    data = {'limits': {}}
    try:
        if os.path.exists(_RLP):
            old = json.load(open(_RLP, encoding='utf-8'))
            if isinstance(old, dict) and isinstance(old.get('limits'), dict):
                data = old
            elif isinstance(old, dict) and old.get('limitType'):
                data = {'limits': {old['limitType']: old}}
    except Exception:
        data = {'limits': {}}
    if not isinstance(data.get('limits'), dict):
        data = {'limits': {}}

    now_iso = datetime.now().isoformat()
    wrote = False
    for key in _WINDOWS:
        w = usage.get(key)
        if not isinstance(w, dict):
            continue
        util = w.get('utilization')
        if util is None:
            continue
        try:
            util = float(util)
        except Exception:
            continue
        rec = {
            # utilization >= 100 → the window is exhausted (rejected). The panel
            # only paints red when the reset is still in the future, so a
            # just-reset window never shows a false "вичерпано".
            'status': 'rejected' if util >= 100 else 'allowed',
            'utilization': util,                       # PERCENT 0..100 (UI handles it)
            'resetsAt': _iso_to_unix_str(w.get('resets_at')),
            'limitType': key,
            'overageStatus': None,
            'ts': now_iso,
            'source': 'oauth-usage-api',
            'raw': w,
        }
        data['limits'][key] = rec
        wrote = True

    if not wrote:
        return False
    data['ts'] = now_iso
    tmp = _RLP + '.tmp'
    with open(tmp, 'w', encoding='utf-8') as f:
        json.dump(data, f, ensure_ascii=False, indent=1)
    os.replace(tmp, _RLP)
    return True


def refresh(force=False):
    """Best-effort: refresh rate-limit.json from the pull endpoint, at most once
    per _TTL seconds (unless force). Returns True if it wrote fresh data.
    Never raises — safe to call from a request handler."""
    global _last_fetch
    try:
        with _lock:
            now = time.time()
            if not force and (now - _last_fetch) < _TTL:
                return False
            _last_fetch = now          # set before the network call so a burst of
            usage = _fetch()           # concurrent polls doesn't all fire requests
            if not usage:
                return False
            return _merge_into_rate_limit(usage)
    except Exception:
        return False


if __name__ == '__main__':
    # Manual test: python usage_api.py  → fetch + print + write.
    u = _fetch()
    print('fetch:', 'OK' if u else 'FAILED (no token / offline / 401)')
    if u:
        for k in _WINDOWS:
            w = u.get(k)
            if isinstance(w, dict):
                print(f'  {k}: utilization={w.get("utilization")} resets_at={w.get("resets_at")}')
        print('wrote rate-limit.json:', _merge_into_rate_limit(u))
