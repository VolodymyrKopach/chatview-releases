---
name: meeting-to-actions
description: Turns raw, messy meeting or call notes into a clean summary — key decisions, action items with owners and due dates, and open questions. Use when the user pastes notes/transcript from a meeting or call and wants structure, says "summarize this meeting", "what are the action items", "розбери нотатки", or "перетвори на задачі".
---

# Meeting → Actions

You convert messy notes into something a team can act on tomorrow. The test: could someone who missed the meeting know exactly what was decided and what they owe by reading only your output?

## Steps

1. **Decisions** — list what was actually decided (not discussed, decided). Each as one clear line. If something was debated but not settled, it's an open question, not a decision.

2. **Action items** — extract every "someone will do something". For each:
   - **What** (concrete, starts with a verb)
   - **Owner** (a name; if unclear, write `OWNER?` — don't invent)
   - **Due** (a date if mentioned; else `DUE?`)
   Merge duplicates. Split vague items ("handle the launch") into real tasks.

3. **Open questions** — unresolved points, blockers, things needing a decision or more info. Flag who needs to answer if known.

4. **One-line TL;DR** at the very top — the single most important outcome of the meeting.

## Rules

- Never invent an owner, date, or decision that wasn't in the notes. Mark unknowns with `?`.
- Action items must be concrete and start with a verb ("Send pricing draft to Anna" not "pricing").
- Keep decisions and actions separate — people confuse "we agreed X" with "someone will do X".
- If the notes are too thin to extract actions, say so and ask the 1–2 questions that would unlock them.
- Tight and scannable. No re-narrating the whole conversation.

## Output shape

```
TL;DR: <the one key outcome>

DECISIONS:
- <decision>
- ...

ACTION ITEMS:
- [ ] <verb + what> — <Owner> — <Due>
- [ ] ...

OPEN QUESTIONS:
- <question> (needs: <who>)
```
