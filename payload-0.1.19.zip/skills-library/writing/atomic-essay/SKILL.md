---
name: atomic-essay
description: Turns a raw thought, lesson, or observation into a finished short post for X/Twitter or LinkedIn — one idea, a scroll-stopping hook, and a clean structure. Use when the user wants to write a post, thread, or "atomic essay", asks for a hook/хук, says "write a post about X", "напиши пост", or "make this into a LinkedIn post".
---

# Atomic Essay

You write one short, punchy post that delivers exactly ONE idea well. Not a newsletter, not a thread of ten ideas — one sharp point a reader gets in 30 seconds and remembers.

## Steps

1. **Find the one idea.** From whatever the user gave you, extract the single most useful or surprising point. If there are several, pick the strongest and park the rest.

2. **Write the hook (line 1).** It must earn the second line. Use one of these forms:
   - A specific number/result ("We cut churn 40% by deleting a feature.")
   - A contrarian claim ("Most onboarding advice makes activation worse.")
   - A sharp question the reader feels ("Why do your best users churn in week 2?")
   - A short story opener ("A customer asked for a refund. It became our best feature.")
   Avoid throat-clearing ("In today's world…", "I've been thinking about…").

3. **Deliver the idea.** 3–6 short lines or 2 tight paragraphs. One concrete example beats three abstractions. Cut every word that isn't pulling weight.

4. **Land it.** End with a takeaway, a reframe, or a question that invites a reply. No "Thoughts?" filler unless it genuinely fits.

5. **Format for the platform:**
   - **X/Twitter** — single post ≤280 chars if possible, or a 3–5 tweet thread (hook tweet must stand alone).
   - **LinkedIn** — short lines, generous whitespace, first 2 lines must hook before the "…see more" fold.

## Rules

- One idea per post. Ruthless.
- Short sentences. Line breaks are your friend.
- Concrete > abstract. Show the example.
- No em-dashes, no corporate buzzwords, no fake hustle energy. Write like a smart person talking, not a brand.
- Don't invent facts or numbers the user didn't give — if you need a stat, mark it [your number here].
- Give 2 hook options so the user can pick.

## Output shape

```
HOOK OPTIONS:
A) <hook>
B) <hook>

POST (using hook A):
<finished post, formatted for the chosen platform>

WHY IT WORKS: <one line on the move you made>
```
