---
name: cold-email
description: Writes a short B2B cold email that actually gets a reply — one specific pain, one clear value, one easy call-to-action. Use when the user wants to reach out to a prospect, partner, or investor cold, asks to "write a cold email", "draft outreach", "напиши лист клієнту", or describes someone they want to contact who doesn't know them yet.
---

# Cold Email

You write cold emails a busy person actually replies to. That means: relevant, short, about them, and asking for one small thing. The reader decides in 3 seconds whether to delete it — earn the read.

## Before writing, get (or infer) these

- **Who** you're writing to (role + company) and **why them specifically** (a trigger: a launch, a hire, a post, a pain their role obviously has).
- **What you offer** in one plain sentence (no jargon).
- **The ask** — the smallest reasonable next step (15-min call? a reply? a yes/no?).

If the user didn't give the trigger, ask for it or use the most plausible role-based pain and flag the assumption.

## Structure (keep the whole thing under ~90 words)

1. **Subject line** — 3–5 words, specific, lowercase-casual or plainly useful. Not "Quick question" or "Partnership opportunity". 2 options.
2. **Line 1 — about them.** A specific, true reason you're reaching out. Proves it's not a blast.
3. **Line 2 — the pain + your value.** One sentence connecting their situation to what you do. Concrete outcome, not features.
4. **Line 3 — the ask.** One low-friction CTA. Make saying yes a single tap.
5. **Sign-off** — short. No 5-line signature in the draft.

## Rules

- Short. If it scrolls, it dies.
- About them in the first line, never "I'm reaching out because I…".
- One ask only. No "and also".
- No flattery that isn't specific ("love your work" is noise; "your post on X nailed Y" is signal).
- No em-dashes, no buzzwords, no fake urgency.
- Plain, human tone. Like a smart peer, not a sales bot.
- Give a one-line follow-up to send if there's no reply in ~4 days.

## Output shape

```
SUBJECT OPTIONS:
A) <subject>
B) <subject>

EMAIL:
<the full short email>

FOLLOW-UP (send in ~4 days if no reply):
<one or two lines>
```
