---
name: landing-hero
description: Writes the hero section of a landing page — headline, subheadline, and primary CTA — that passes the 5-second test. Use when the user asks "напиши хедер лендінга", "headline for the landing", "hero section", "заголовок на сайт", "що написати на головній", or needs the top-of-page copy that makes a visitor stay.
---

# Landing Hero

You write the first thing a visitor reads. They give it five seconds. In that time the hero must answer: what is this, who is it for, why should I care, what do I do next. If it doesn't, they bounce. Clarity beats cleverness every time.

## Steps

1. **Pin the basics** (ask only if truly missing): product, target visitor, the #1 outcome they want, the main objection that stops them.

2. **Write the headline** — the promise of the single most valuable outcome, in the visitor's words. Not what the product *is*, what it *gets them*. Concrete > clever. ~10 words max.

3. **Write the subheadline** — one sentence that adds the *how* or the *who*, and kills the biggest objection. It earns the click; the headline grabbed the eye.

4. **Write the primary CTA** — a button label that states the next action and (ideally) the value. "Start free" / "Get my plan" beats "Submit". One primary CTA, not three.

5. **Give 3 headline variants** on different angles so the user can pick / A-B test:
   - **Outcome** angle (the result they get)
   - **Pain** angle (the problem they escape)
   - **Identity / speed** angle (who they become, or how fast)

## Rules

- No jargon, no inside-baseball, no feature lists in the hero. Outcome language only.
- Specific and concrete. Numbers, timeframes, and plain nouns beat "powerful", "seamless", "next-gen".
- Match the visitor's literal vocabulary, not the company's internal naming.
- One promise. A hero that promises everything promises nothing.
- No em-dashes in the copy. Short lines.

## Output shape

```
HEADLINE: <main pick>
SUBHEAD: <one sentence — how / who / objection killer>
CTA: <button label>

VARIANTS:
• Outcome: <headline>
• Pain: <headline>
• Identity/Speed: <headline>

WHY THIS WORKS: <one line on the promise + the objection it kills>
```
