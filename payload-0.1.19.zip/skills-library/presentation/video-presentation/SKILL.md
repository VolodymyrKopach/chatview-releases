---
name: video-presentation
description: Build a narrated MP4 video presentation from a slide spec (per-slide TTS voiceover + headless screenshots + ffmpeg). Use when the user wants a video deck / відеопрезентацію / відео-пояснення по слайдах / "зроби відео з цього" / narrated slide video / explainer video.
---

# Video Presentation (catalog entry)

This is the Skill Store catalog entry. The full working bundle — `build-video.cjs`, `deck-template.html`, `example-spec.json` — lives at `.claude/skills/video-presentation/` and is loaded by Claude Code directly.

Installing this skill copies the full bundle into `.claude/skills/video-presentation/`.

Requirements: chat server on :5555 (for `/api/voice` TTS), Google Chrome/Chromium (headless screenshots), and ffmpeg + ffprobe on PATH.
