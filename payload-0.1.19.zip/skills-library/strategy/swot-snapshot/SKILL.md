---
name: swot-snapshot
description: Produces a fast, honest SWOT (Strengths, Weaknesses, Opportunities, Threats) for a company, product, or decision, then turns it into 2-3 concrete moves instead of a static grid. Use when the user asks "зроби SWOT", "what's our SWOT", "сильні та слабкі сторони", "аналіз ситуації", or wants a quick strategic read before a decision.
---

# SWOT Snapshot

You produce a SWOT that drives action, not a poster. A list of adjectives is useless. The value is in the cross-reads: which strength attacks which opportunity, which weakness exposes which threat. End with moves, not boxes.

## Steps

1. **Frame the subject in one line** — the company, product, or specific decision under analysis. SWOT for "the whole business" is mush; tighten it.

2. **Fill four quadrants, 2–4 items each, all specific:**
   - **Strengths** (internal, real today) — assets, unfair advantages, things you do better. No vanity ("great team").
   - **Weaknesses** (internal, honest) — gaps, dependencies, what a competitor would attack first.
   - **Opportunities** (external) — market shifts, unmet demand, channels opening up. Things you don't control but could ride.
   - **Threats** (external) — competitors, regulation, platform risk, timing. Things that could hurt you.

3. **Cross-read for moves** (this is the point):
   - **S×O** → where a strength can seize an opportunity → an offensive move.
   - **W×T** → where a weakness meets a threat → the danger to defend or fix now.

4. **Output 2–3 concrete moves** with a rough priority, drawn from the cross-reads. Each move = a verb and an owner-able action, not a theme.

## Rules

- Internal vs external discipline: Strengths/Weaknesses are about you, Opportunities/Threats about the world. Don't mix.
- Specific over generic. "30 logged-in therapist users we can interview this week" beats "good user base".
- Be honest in Weaknesses. A flattering SWOT is worthless.
- The deliverable is the moves. A SWOT that ends at the grid failed.

## Output shape

```
SUBJECT: <one line>

STRENGTHS            WEAKNESSES
• …                  • …

OPPORTUNITIES        THREATS
• …                  • …

MOVES:
1. (S×O) <offensive move> — priority H/M/L
2. (W×T) <defend/fix now> — priority H/M/L
3. <move> — priority H/M/L
```
