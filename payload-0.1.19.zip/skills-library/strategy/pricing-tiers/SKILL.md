---
name: pricing-tiers
description: Designs a 3-tier pricing structure (Good / Better / Best) for a product or service, grounded in competitor benchmarks rather than guesswork. Use when the user asks "how should I price this", "зроби тарифи", "яку ціну поставити", "побудуй pricing", or is packaging a SaaS/service and needs tiers, anchors, and a recommended price.
---

# Pricing Tiers

You package a product into three tiers the way a sharp SaaS operator would: anchored on what the market already charges, designed to make the middle tier the obvious pick. Research first, then price. Never invent numbers from thin air.

## Steps

1. **Name the product and the buyer in one line.** Who pays, and what job are they hiring it for?

2. **Benchmark 3–5 real competitors** (WebSearch if you can): their entry price, mid price, and what's gated behind each. State the going rate as a range. If you can't verify, say so and mark the price as a hypothesis to test.

3. **Pick the value metric** — the one thing that scales with how much value the customer gets (seats, projects, calls, GB, contacts). Everything else is a feature, not a meter.

4. **Build three tiers** using the Good / Better / Best frame:
   - **Good** — removes the #1 objection to starting. Cheap or free entry, real but limited.
   - **Better** — the one you actually want most people on. Bundle the features 80% need. This is the anchor target.
   - **Best** — high-touch / high-volume / team. Priced to make Better look like a steal, and to catch whales.

5. **Set the anchor**: price Best high enough that Better reads as obvious value (classic decoy effect). Note the % jump between tiers.

6. **Recommend the launch price** for the middle tier with a one-line rationale, and name the single riskiest pricing assumption to validate with the first 10 customers.

## Rules

- Ground every number in a benchmark or label it a hypothesis. No confident guessing.
- One value metric. If you're metering on three things, you've designed confusion.
- Don't over-engineer: 3 tiers max for launch. Usage add-ons and enterprise "contact us" are fine, a 5-tier matrix is not.
- Price on value, not cost-plus. What is the outcome worth to the buyer?

## Output shape

```
PRODUCT: <one line> · BUYER: <who>

MARKET RATE: entry ~$X · mid ~$Y · top ~$Z  (source: <competitors>)
VALUE METRIC: <the meter>

GOOD  — $A/mo · for <who> · includes <…> · gates <…>
BETTER — $B/mo · for <who> · includes <…>  ← anchor target
BEST  — $C/mo · for <who> · includes <…>

JUMPS: Good→Better +X% · Better→Best +Y%
LAUNCH PICK: $B for Better — <why>
RISKIEST ASSUMPTION: <the thing to test on first 10 buyers>
```
