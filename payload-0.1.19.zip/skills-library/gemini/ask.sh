#!/usr/bin/env bash
# Gemini helper — надійний враппер над scripts/gemini.sh (agy / Antigravity).
# Фіксить: правильна модель під режим, довгий watchdog, і САМ дочитує agy-артефакт.
# Usage: ask.sh <mode> "<prompt>" ["<system override>"]   modes: research|thinking|flash|raw
set -uo pipefail

# Знайти корінь репо shared-knowledge (працює і з .claude/skills/, і з helpers/, і при override).
find_gem() {
  if [ -n "${GEM_OVERRIDE:-}" ]; then echo "$GEM_OVERRIDE"; return; fi
  local d; d="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
  while [ "$d" != "/" ]; do
    [ -x "$d/scripts/gemini.sh" ] && { echo "$d/scripts/gemini.sh"; return; }
    d="$(dirname "$d")"
  done
  for c in "$HOME/WebstormProjects/shared-knowledge/scripts/gemini.sh"; do
    [ -x "$c" ] && { echo "$c"; return; }
  done
  echo ""
}
GEM="$(find_gem)"
MODE="${1:-flash}"; PROMPT="${2:-}"; SYS_OVERRIDE="${3:-}"

if [ -z "$PROMPT" ]; then echo "ERROR: потрібен промпт. Usage: ask.sh <mode> \"<prompt>\"" >&2; exit 2; fi
if [ -z "$GEM" ] || [ ! -x "$GEM" ]; then echo "ERROR: не знайдено scripts/gemini.sh" >&2; exit 2; fi

case "$MODE" in
  research)
    : "${MODEL:=Gemini 3.1 Pro (High)}"; export GEMINI_TIMEOUT="${GEMINI_TIMEOUT:-360}"
    SYS="Ти дослідник світового рівня. Дай глибоку, структуровану, багатокутову відповідь по секціях. Познач припущення тегом [оцінка]. Конкретика без води. Українською, без довгих тире." ;;
  thinking)
    : "${MODEL:=Gemini 3.1 Pro (High)}"; export GEMINI_TIMEOUT="${GEMINI_TIMEOUT:-360}"
    SYS="Міркуй ретельно, крок за кроком. Стрес-тестуй власні висновки, шукай діри, дай чіткий вердикт з упевненістю у відсотках. Українською, без довгих тире." ;;
  flash)
    : "${MODEL:=Gemini 3.5 Flash (High)}"; export GEMINI_TIMEOUT="${GEMINI_TIMEOUT:-150}"
    SYS="Відповідай стисло й по суті, конкретика. Українською, без довгих тире." ;;
  raw)
    : "${MODEL:=Gemini 3.1 Pro (Low)}"; export GEMINI_TIMEOUT="${GEMINI_TIMEOUT:-240}"
    SYS="" ;;
  *) echo "ERROR: невідомий режим '$MODE' (research|thinking|flash|raw)" >&2; exit 2 ;;
esac
[ -n "$SYS_OVERRIDE" ] && SYS="$SYS_OVERRIDE"
export MODEL

OUT="$(printf '%s' "$PROMPT" | "$GEM" - "$SYS" 2>/tmp/gemini-ask.err)"; CODE=$?
if [ $CODE -ne 0 ]; then
  echo "ERROR: gemini.sh exit $CODE (mode=$MODE, model=$MODEL):" >&2; tail -4 /tmp/gemini-ask.err >&2; exit $CODE
fi
ART="$(printf '%s' "$OUT" | grep -oE 'file://[^ )]+\.md' | head -1 | sed 's#^file://##' || true)"
if [ -n "$ART" ] && [ -f "$ART" ]; then
  echo "===== GEMINI [$MODE · $MODEL] — повна відповідь ====="; cat "$ART"; printf '\n----- (артефакт: %s) -----\n' "$ART"
else
  printf '%s\n' "$OUT"
fi
