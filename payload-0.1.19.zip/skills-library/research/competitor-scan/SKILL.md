---
name: competitor-scan
description: Runs a fast, structured competitor research pass — who the main players are, their pricing, positioning, where they're weak, and where the user can win. Use when the user is about to launch a product/feature and asks "who are my competitors", "research the market", "ресерч конкурентів", "how is X positioned", or wants to find a gap to attack.
---

# Competitor Scan

You map a competitive landscape quickly and honestly so the user knows where to attack. Not a 40-page report — a sharp scan that ends with "here's your gap".

## Steps

1. **Define the arena.** One line: what category, for which customer, solving what job. If the user was vague, narrow it and state the framing.

2. **Identify 3–6 real competitors.** Mix of: the obvious leader(s), a close challenger, and the "non-obvious" alternative (the spreadsheet / the status quo / doing nothing). If you have web access, verify names, pricing, and claims — don't rely on memory for fast-moving facts. If you don't, flag which facts are from memory and should be checked.

3. **For each competitor, capture:**
   - Positioning (the one promise they sell on)
   - Pricing (model + rough number)
   - Who it's really for
   - Strength (why people pick them)
   - Weakness / complaint (what users gripe about — check reviews if you can)

4. **Find the gap.** Where is demand underserved? Look for: a segment nobody targets well, a job everyone does badly, a price tier that's empty, a complaint that repeats across reviews.

5. **Recommend a wedge.** One sentence: the position the user should take and why it's defensible. Plus the single riskiest assumption behind it.

## Rules

- Be specific. "They're expensive" is useless; "$99/mo with a 3-seat minimum, so solos can't afford it" is a wedge.
- Include the boring alternative (Excel, pen and paper, doing nothing) — it's usually the real competitor.
- Separate verified facts from guesses. Never present a remembered price as current truth.
- End with the gap and the wedge, not a neutral summary.

## Output shape

```
ARENA: <category, for whom, what job>

COMPETITORS:
1. <name> — positioning · pricing · for whom · strength · weakness
2. ...

THE GAP: <where demand is underserved>

YOUR WEDGE: <the position to take> 
RISKIEST ASSUMPTION: <the one thing that must be true>
TO VERIFY: <facts to check before betting>
```
