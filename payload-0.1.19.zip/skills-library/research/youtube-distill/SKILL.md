---
name: youtube-distill
description: Turns a YouTube video (talk, interview, tutorial, podcast) into a tight set of insights, key claims, and actionable takeaways without watching the whole thing. Use when the user drops a YouTube link and asks "конспект", "summarize this", "що важливого", "розбери це відео", "key points", or wants the signal from a long video distilled into something they can act on.
---

# YouTube Distill

You extract the signal from a long video so the user doesn't have to sit through it. The win is not a transcript summary, it's the 5–8 ideas worth remembering plus what to actually do with them. Be faithful to the source: distinguish what the speaker claimed from your own read.

## Steps

1. **Get the content.** Use the transcript / captions if available (WebFetch or transcript tools). If you can't access it, say so plainly and ask the user to paste the transcript rather than hallucinating contents.

2. **One-line thesis** — what is this video actually arguing or teaching, in a sentence.

3. **5–8 key takeaways** — the load-bearing ideas, each one line, in the speaker's logic, ordered by importance not by timestamp. Skip the filler, the sponsor read, the anecdotes that don't carry an idea.

4. **Notable claims / data** — specific numbers, frameworks, or strong assertions worth quoting or fact-checking. Flag any that sound dubious with a 🟡.

5. **So what — actions** — 2–3 concrete things the user could do with this, tailored to their context if known (founder, content, product, sales).

6. **Worth watching in full?** One honest line: yes/skim/skip, and for whom.

## Rules

- Faithful to the source. Separate "speaker says" from "I think". Don't invent points the video didn't make.
- If you couldn't access the actual content, do not fake a summary. Ask for the transcript.
- Ideas over chronology. Reorder by importance.
- Flag weak or unverified claims rather than passing them on as fact.
- Tight. The whole point is to save time, so no padding.

## Output shape

```
VIDEO: <title / channel if known>
THESIS: <one line>

TAKEAWAYS:
1. …
2. …
…

CLAIMS / DATA:
• <claim> 🟡 <if dubious>

SO WHAT (actions):
• …
• …

VERDICT: watch in full / skim / skip — for <who>
```
