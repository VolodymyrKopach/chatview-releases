#!/usr/bin/env bash
# «озвучити» — OpenAI TTS через ChatView /api/voice. Повертає URL mp3.
# Usage: say.sh "<текст>" [voice=nova] [model=tts-1] [port=5555]
# НЕ програє локально. Готовий mp3 подаю у ChatView як audio-widget.
set -uo pipefail
TEXT="${1:-}"; VOICE="${2:-nova}"; MODEL="${3:-tts-1}"; PORT="${4:-5555}"
[ -z "$TEXT" ] && { echo "ERROR: потрібен текст. Usage: say.sh \"<текст>\" [voice] [model]" >&2; exit 2; }
PY=""; for c in python3 python; do "$c" -c 'print(1)' >/dev/null 2>&1 && { PY="$c"; break; }; done
[ -z "$PY" ] && { echo "ERROR: python не знайдено" >&2; exit 2; }
BODY="$("$PY" - "$TEXT" "$VOICE" "$MODEL" <<'PYEOF'
import json,sys
print(json.dumps({"text":sys.argv[1],"engine":"openai","voice":sys.argv[2],"model":sys.argv[3]}))
PYEOF
)"
RESP="$(curl -s -X POST "http://localhost:$PORT/api/voice" -H 'Content-Type: application/json' -d "$BODY")"
URL="$(printf '%s' "$RESP" | "$PY" -c 'import json,sys;print(json.load(sys.stdin).get("url",""))' 2>/dev/null)"
if [ -z "$URL" ]; then echo "ERROR: TTS не повернув url. Відповідь: $RESP" >&2; exit 1; fi
echo "$URL"
