#!/usr/bin/env bash
# OpenAI chat helper — обгортка над scripts/openai.sh.
# Usage: ask.sh <mode> "<prompt>" ["<system>"]   modes: ask|thinking|search
set -uo pipefail
find_oa() {
  if [ -n "${OA_OVERRIDE:-}" ]; then echo "$OA_OVERRIDE"; return; fi
  local d; d="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
  while [ "$d" != "/" ]; do
    [ -x "$d/scripts/openai.sh" ] && { echo "$d/scripts/openai.sh"; return; }
    d="$(dirname "$d")"
  done
  [ -x "$HOME/WebstormProjects/shared-knowledge/scripts/openai.sh" ] && echo "$HOME/WebstormProjects/shared-knowledge/scripts/openai.sh"
}
OA="$(find_oa)"
MODE="${1:-ask}"; PROMPT="${2:-}"; SYS="${3:-Відповідай стисло, конкретика, українською, без довгих тире.}"
[ -z "$PROMPT" ] && { echo "ERROR: потрібен промпт. Usage: ask.sh <mode> \"<prompt>\"" >&2; exit 2; }
[ -z "$OA" ] || [ ! -x "$OA" ] && { echo "ERROR: не знайдено scripts/openai.sh" >&2; exit 2; }
case "$MODE" in
  ask)      export MODEL="${MODEL:-gpt-5}" ;;
  thinking) export MODEL="${MODEL:-o4-mini}" ;;
  search)   export MODEL="${MODEL:-gpt-5-search-api}" ;;
  *) echo "ERROR: невідомий режим '$MODE' (ask|thinking|search)" >&2; exit 2 ;;
esac
printf '%s' "$PROMPT" | "$OA" - "$SYS"
