"""project_state.py: ONE read-only snapshot of the ChatView ecosystem.

So any chat (via runner system-prompt injection, Phase B) and the UI (via
/api/project-state) know what exists in this project: chats, canvas pages,
helpers. Pure file reads, no side effects, cheap. Phase A of the Project Context
Layer.

build_project_state(dir_, repo_root) -> {
  chats:     [{id, label}],            # visible channels (registry + local overlay)
  canvases:  [{id, title}],            # tldraw pages from canvas-state store
  helpers:   {installed:[name], catalog:{local:N, remote:M}},
  counts:    {chats, canvases, installed},
}
"""
import os
import json


def _load_json(path, default):
    try:
        with open(path, encoding='utf-8') as f:
            return json.load(f)
    except Exception:
        return default


def _chats(dir_):
    """Visible channels, merged from the committed registry + local cc-* overlay,
    deduped by id, hidden ones dropped."""
    ch_dir = os.path.join(dir_, 'channels')
    out = {}
    for fn in ('index.json', 'index.local.json'):
        data = _load_json(os.path.join(ch_dir, fn), [])
        items = data if isinstance(data, list) else (data.get('channels') or [])
        for c in items:
            if isinstance(c, dict) and c.get('id') and not c.get('hidden'):
                out[c['id']] = {'id': c['id'], 'label': c.get('label') or c['id']}
    return list(out.values())


def _canvases(dir_):
    """Live tldraw pages (typeName == 'page') from the canvas store."""
    p = os.path.join(dir_, '..', '..', 'canvas-cmd', 'data', 'canvas-state.json')
    store = (_load_json(p, {}) or {}).get('store', {}) or {}
    out = []
    for k, v in store.items():
        if isinstance(v, dict) and v.get('typeName') == 'page':
            out.append({'id': k, 'title': (v.get('name') or k)})
    return out


def _helpers(dir_, repo_root):
    """Installed skill folders + catalog sizes (local + harvested remote)."""
    installed = []
    sk_dir = os.path.join(repo_root, '.claude', 'skills')
    try:
        installed = sorted(d for d in os.listdir(sk_dir)
                           if os.path.isdir(os.path.join(sk_dir, d)))
    except Exception:
        installed = []
    lib = os.path.join(dir_, 'skills-library')
    local_n = len((_load_json(os.path.join(lib, 'index.json'), {}) or {}).get('skills', []))
    remote = _load_json(os.path.join(lib, 'remote-catalog.json'), {}) or {}
    remote_n = remote.get('count') or len(remote.get('skills', []))
    return {'installed': installed, 'catalog': {'local': local_n, 'remote': remote_n}}


def build_project_state(dir_, repo_root):
    chats = _chats(dir_)
    canvases = _canvases(dir_)
    helpers = _helpers(dir_, repo_root)
    return {
        'chats': chats,
        'canvases': canvases,
        'helpers': helpers,
        'counts': {
            'chats': len(chats),
            'canvases': len(canvases),
            'installed': len(helpers['installed']),
        },
        # Phase C: action contracts so awareness becomes action. Verified live
        # endpoints; a chat fetches this state then acts on entities.
        'actions': {
            'fresh_state': 'GET /api/project-state',
            'add_to_canvas': 'POST /api/canvas/add-shapes {pageId, shapes:[...]} (pageId = id з canvases[])',
            'install_helper': 'POST /api/helpers/install {id} (id з каталогу помічників)',
            'note': 'Не постити в чужий канал; інші чати тільки для контексту.',
        },
    }


if __name__ == '__main__':
    d = os.path.dirname(os.path.abspath(__file__))
    repo = os.path.abspath(os.path.join(d, '..', '..', '..'))
    st = build_project_state(d, repo)
    print(json.dumps(st['counts'], ensure_ascii=False))
    print('chats sample:', [c['label'] for c in st['chats'][:3]])
    print('canvas sample:', [c['title'] for c in st['canvases'][:3]])
    print('installed sample:', st['helpers']['installed'][:3])
    print('catalog:', st['helpers']['catalog'])
