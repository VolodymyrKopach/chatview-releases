#!/usr/bin/env node
/**
 * Minimal CLI bridge to `fractional-indexing-jittered` so the Python ChatView
 * server (server.py) can generate tldraw-valid fractional-index keys when an
 * agent posts shapes via POST /api/canvas/add-shapes.
 *
 * Why a node bridge instead of a pure-Python reimplementation: tldraw validates
 * index keys with this exact library (base-62 fractional indexing + jitter).
 * Reimplementing the jitter/base-62 logic faithfully in Python is error-prone;
 * shelling out to the real library guarantees byte-identical, valid keys — the
 * same approach server/index.ts uses (it imports the library directly).
 *
 * The library is resolved from tools/canvas-cmd/node_modules (already installed
 * for the canvas app). No new dependency is added.
 *
 * Usage (stdin JSON):
 *   echo '{"between":[["a0",null],["a0",null]]}' | node fractional-index.cjs
 *   -> {"keys":["a1","a1V"]}        // one generated key per [below, above] pair
 *
 * Each request is a list of [below, above] bounds (null = open end). We return
 * one fresh key strictly between each pair. Callers that need to chain (insert N
 * keys all after the same `below`) must thread the previous result as the next
 * `below` themselves — server.py does this so per-parent ordering is monotonic.
 */
// Resolve the library from tools/canvas-cmd/node_modules (it is not installed
// next to this file). __dirname = tools/viz/chat → ../../canvas-cmd.
const path = require('path')
const canvasNodeModules = path.resolve(__dirname, '..', '..', 'canvas-cmd', 'node_modules')
const libPath = require.resolve('fractional-indexing-jittered', { paths: [canvasNodeModules] })
const { generateJitteredKeyBetween } = require(libPath)

let raw = ''
process.stdin.setEncoding('utf-8')
process.stdin.on('data', (c) => { raw += c })
process.stdin.on('end', () => {
  try {
    const req = JSON.parse(raw || '{}')
    const between = Array.isArray(req.between) ? req.between : []
    const keys = between.map(([below, above]) =>
      generateJitteredKeyBetween(below ?? null, above ?? null),
    )
    process.stdout.write(JSON.stringify({ keys }))
  } catch (e) {
    process.stdout.write(JSON.stringify({ error: String(e && e.message || e) }))
    process.exitCode = 1
  }
})
