#!/usr/bin/env python3
"""Offline EXPORT / IMPORT for ChatView.

Moves a user's chats *and* their Claude Code context to another machine.

What travels:
  1. ChatView data - `channels/<id>/` (index.json, NNNN.json bubbles, plan.json,
     `session-id` pin) + `canvas-data/`. Runtime scratch is stripped (queue/,
     live.json, busy/cc-busy, *.lock, owner-session).
  2. Claude Code context - the per-session transcripts
     `~/.claude/projects/<encoded-cwd>/<session-id>.jsonl`. `encoded-cwd` is the
     repo root (the cwd claude runs in) encoded the way Claude Code names its
     project folder. We RE-USE the runner's `_encode_project_dir` so the naming
     never drifts.

The whole point of IMPORT is the *re-encoding*: on the target machine the repo
root (home) is almost always a different absolute path, so `<encoded-cwd>` is
different. We compute the TARGET encoded dir from the TARGET repo root (NOT from
the manifest) and drop each `<session-id>.jsonl` there. That is what lets
`claude --resume <sid>` find the session under the new user/path.

This module is pure stdlib and dependency-injected (no import of server/runner),
so it stays trivially bundle-able (see desktop/export-app.sh) and unit-testable.
"""
import io
import os
import json
import zipfile
from datetime import datetime


# Channel-dir entries that are pure runtime scratch and must NOT travel. Matched
# by exact basename. Everything else in a channel dir (session-id, index.json,
# NNNN.json, plan.json, model, usage.json, uploads/) is content and DOES travel.
_RUNTIME_JUNK = {
    'queue',          # dir: pending user turns, machine-local
    'live.json',      # streaming scratch for the in-flight turn
    'cc-busy',        # interactive-terminal busy lock
    'busy',           # web-turn busy lock
    'owner-session',  # which terminal session owns the channel (machine-local)
}


def _is_junk(name):
    """True if a channel-dir entry (by basename) is runtime scratch to skip."""
    if name in _RUNTIME_JUNK:
        return True
    if name.endswith('.lock'):
        return True
    return False


def _iter_channel_files(channels_dir):
    """Yield (arcname_rel, abs_path) for every content file under channels/,
    skipping runtime junk. arcname_rel is relative to channels_dir's parent-view
    i.e. 'channels/<id>/<...>'. Junk is filtered at the channel-top level (queue/
    etc.) so nested content is never accidentally dropped."""
    if not os.path.isdir(channels_dir):
        return
    for cid in sorted(os.listdir(channels_dir)):
        ch_dir = os.path.join(channels_dir, cid)
        # Keep top-level channel registry files (e.g. index.json, .cc-sessions.json).
        if not os.path.isdir(ch_dir):
            # Registry / bookkeeping files that live directly in channels/.
            # index.json (the channel list) is essential; hidden dotfiles like
            # .cc-sessions.json map sessions to owning terminals -> machine-local,
            # skip. Ship only the plain channel registry.
            if cid == 'index.json':
                yield (f'channels/{cid}', ch_dir)
            continue
        for root, dirs, files in os.walk(ch_dir):
            # Prune junk directories in-place so os.walk does not descend them.
            rel_top = os.path.relpath(root, ch_dir)
            if rel_top == '.':
                dirs[:] = [d for d in dirs if not _is_junk(d)]
            for fn in files:
                if _is_junk(fn):
                    continue
                abs_p = os.path.join(root, fn)
                rel = os.path.relpath(abs_p, channels_dir)  # '<id>/...'
                yield (f'channels/{rel}', abs_p)


def _channels_with_sessions(channels_dir):
    """Return [(channel_id, session_id)] for every channel that pins a session."""
    out = []
    if not os.path.isdir(channels_dir):
        return out
    for cid in sorted(os.listdir(channels_dir)):
        sid_path = os.path.join(channels_dir, cid, 'session-id')
        if not os.path.isfile(sid_path):
            continue
        try:
            with open(sid_path, 'r', encoding='utf-8') as f:
                sid = f.read().strip()
        except Exception:
            continue
        if sid:
            out.append((cid, sid))
    return out


def build_export_zip(dir_home, claude_repo_root, encode_fn, log=print):
    """Build the export .zip in memory and return (filename, bytes).

    dir_home         - ChatView data home (contains channels/, canvas-data/).
    claude_repo_root - the cwd claude runs in (== the repo root that names the
                       ~/.claude/projects/<enc>/ folder). NOT necessarily dir_home
                       (dev: shared-knowledge root; desktop: the home itself).
    encode_fn        - runner._encode_project_dir. Re-used so encoding never drifts.
    """
    channels_dir = os.path.join(dir_home, 'channels')
    canvas_dir = os.path.join(dir_home, 'canvas-data')
    src_enc = encode_fn(claude_repo_root)
    projects_dir = os.path.expanduser(f'~/.claude/projects/{src_enc}')

    created_at = datetime.now().isoformat()
    ts = datetime.now().strftime('%Y%m%d-%H%M%S')
    fname = f'chatview-export-{ts}.zip'

    manifest_channels = []
    buf = io.BytesIO()
    n_files = 0
    n_jsonl = 0
    with zipfile.ZipFile(buf, 'w', zipfile.ZIP_DEFLATED) as zf:
        # 1) chatview-data/  (channels + canvas-data, runtime junk stripped)
        for arc_rel, abs_p in _iter_channel_files(channels_dir):
            zf.write(abs_p, f'chatview-data/{arc_rel}')
            n_files += 1
        if os.path.isdir(canvas_dir):
            for root, _dirs, files in os.walk(canvas_dir):
                for fn in files:
                    abs_p = os.path.join(root, fn)
                    rel = os.path.relpath(abs_p, dir_home)  # 'canvas-data/...'
                    zf.write(abs_p, f'chatview-data/{rel}')
                    n_files += 1

        # 2) claude-sessions/  (one <sid>.jsonl per channel that has one on disk)
        seen_sids = set()
        for cid, sid in _channels_with_sessions(channels_dir):
            has = False
            jsonl = os.path.join(projects_dir, f'{sid}.jsonl')
            if os.path.isfile(jsonl):
                if sid not in seen_sids:
                    zf.write(jsonl, f'claude-sessions/{sid}.jsonl')
                    seen_sids.add(sid)
                    n_jsonl += 1
                has = True
            else:
                log(f'[transfer] export: no jsonl for channel {cid} (sid {sid}), skipping session')
            manifest_channels.append({'id': cid, 'session_id': sid, 'has_jsonl': has})

        # 3) manifest.json
        manifest = {
            'version': 1,
            'created_at': created_at,
            'source_home_abs': dir_home,
            'source_repo_root_abs': claude_repo_root,
            'source_encoded_dir': src_enc,
            'channels': manifest_channels,
        }
        zf.writestr('manifest.json', json.dumps(manifest, ensure_ascii=False, indent=2))

    log(f'[transfer] export: {n_files} data files, {n_jsonl} sessions, '
        f'{len(manifest_channels)} channels -> {fname}')
    return fname, buf.getvalue()


def _safe_extract_member(zf, member, dest_root):
    """Extract one zip member under dest_root, refusing path traversal. Returns
    the written absolute path, or None if the member was skipped (dir entry)."""
    name = member.filename
    if name.endswith('/'):
        return None
    # Normalize and confine.
    target = os.path.normpath(os.path.join(dest_root, name))
    root_real = os.path.realpath(dest_root)
    if not (os.path.realpath(target) == root_real or
            os.path.realpath(target).startswith(root_real + os.sep) or
            target == dest_root or target.startswith(dest_root + os.sep)):
        raise ValueError(f'unsafe path in zip: {name}')
    os.makedirs(os.path.dirname(target), exist_ok=True)
    with zf.open(member) as src, open(target, 'wb') as dst:
        dst.write(src.read())
    return target


def import_zip(zip_bytes, dir_home, claude_repo_root, encode_fn, log=print):
    """Restore a ChatView export .zip into this machine.

    - chatview-data/ -> dir_home  (MERGE: existing channels of the same id are
      kept as-is; only channels absent locally are imported. Per-channel, all-or-
      nothing to avoid mixing two histories under one id.)
    - claude-sessions/<sid>.jsonl -> ~/.claude/projects/<enc(TARGET repo root)>/<sid>.jsonl
      i.e. RE-ENCODED for THIS machine's repo root (the manifest's source dir is
      ignored on purpose - that is the whole re-encode).

    Returns a JSON-able report dict.
    """
    report = {
        'imported_channels': [],
        'skipped_channels': [],
        'imported_sessions': [],
        'skipped_sessions': [],
        'imported_canvas_files': 0,
        'warnings': [],
    }

    target_enc = encode_fn(claude_repo_root)
    target_projects_dir = os.path.expanduser(f'~/.claude/projects/{target_enc}')

    channels_dir = os.path.join(dir_home, 'channels')
    os.makedirs(channels_dir, exist_ok=True)

    zf = zipfile.ZipFile(io.BytesIO(zip_bytes), 'r')

    # Read manifest (optional - import stays robust if absent).
    manifest = {}
    if 'manifest.json' in zf.namelist():
        try:
            manifest = json.loads(zf.read('manifest.json').decode('utf-8'))
        except Exception as e:
            report['warnings'].append(f'manifest.json unreadable: {e}')

    # 1) Discover incoming channel ids (top folder under chatview-data/channels/).
    incoming_channels = {}   # cid -> [member, ...]
    canvas_members = []
    other_members = []
    for member in zf.infolist():
        n = member.filename
        if n.endswith('/'):
            continue
        if n.startswith('chatview-data/channels/'):
            rest = n[len('chatview-data/channels/'):]
            if '/' not in rest:
                # channels/index.json (registry) - handle separately below.
                other_members.append(member)
                continue
            cid = rest.split('/', 1)[0]
            incoming_channels.setdefault(cid, []).append(member)
        elif n.startswith('chatview-data/canvas-data/'):
            canvas_members.append(member)

    # 2) Merge channels: import only ids not already present locally.
    for cid, members in incoming_channels.items():
        local_ch = os.path.join(channels_dir, cid)
        if os.path.isdir(local_ch):
            report['skipped_channels'].append(cid)
            log(f'[transfer] import: channel {cid} already exists locally, skipping (kept local)')
            continue
        for member in members:
            # Re-root chatview-data/ -> dir_home.
            member2_name = member.filename[len('chatview-data/'):]
            _write_member_to(zf, member, os.path.join(dir_home, member2_name))
        report['imported_channels'].append(cid)
        log(f'[transfer] import: channel {cid} imported')

    # 3) Canvas data - merge file-by-file (add missing, keep existing).
    for member in canvas_members:
        rel = member.filename[len('chatview-data/'):]  # 'canvas-data/...'
        dest = os.path.join(dir_home, rel)
        if os.path.exists(dest):
            continue
        _write_member_to(zf, member, dest)
        report['imported_canvas_files'] += 1

    # 4) channels/index.json registry - merge entries for imported channels only.
    _merge_channel_registry(zf, other_members, channels_dir,
                            set(report['imported_channels']), report, log)

    # 5) Claude sessions -> RE-ENCODED target projects dir.
    os.makedirs(target_projects_dir, exist_ok=True)
    for member in zf.infolist():
        n = member.filename
        if not n.startswith('claude-sessions/') or n.endswith('/'):
            continue
        base = os.path.basename(n)
        if not base.endswith('.jsonl'):
            continue
        sid = base[:-len('.jsonl')]
        dest = os.path.join(target_projects_dir, base)
        if os.path.exists(dest):
            report['skipped_sessions'].append(sid)
            log(f'[transfer] import: session {sid} already present at target, keeping existing')
            continue
        with zf.open(member) as src, open(dest, 'wb') as dst:
            dst.write(src.read())
        report['imported_sessions'].append(sid)
        log(f'[transfer] import: session {sid} -> {dest}')

    report['target_encoded_dir'] = target_enc
    report['target_projects_dir'] = target_projects_dir
    if manifest.get('source_encoded_dir') and manifest['source_encoded_dir'] != target_enc:
        log(f'[transfer] import: re-encoded {manifest["source_encoded_dir"]} '
            f'-> {target_enc}')
    return report


def _write_member_to(zf, member, dest_abs):
    """Extract a single zip member to an explicit absolute destination path,
    with traversal safety relative to that path's existence."""
    dest_abs = os.path.normpath(dest_abs)
    os.makedirs(os.path.dirname(dest_abs), exist_ok=True)
    with zf.open(member) as src, open(dest_abs, 'wb') as dst:
        dst.write(src.read())


def _merge_channel_registry(zf, registry_members, channels_dir, imported_cids,
                            report, log):
    """channels/index.json is the channel list the UI reads. Merge: append the
    incoming entries for channels we actually imported, without disturbing local
    ones. If no local registry exists, seed it from the incoming one."""
    incoming_reg = None
    for member in registry_members:
        if os.path.basename(member.filename) == 'index.json':
            try:
                incoming_reg = json.loads(zf.read(member).decode('utf-8'))
            except Exception as e:
                report['warnings'].append(f'incoming channels/index.json unreadable: {e}')
            break
    if incoming_reg is None:
        return
    local_path = os.path.join(channels_dir, 'index.json')
    try:
        local_reg = json.load(open(local_path, encoding='utf-8')) if os.path.exists(local_path) else []
    except Exception:
        local_reg = []
    if not isinstance(local_reg, list):
        local_reg = []
    have_ids = {c.get('id') for c in local_reg if isinstance(c, dict)}
    added = 0
    for entry in incoming_reg if isinstance(incoming_reg, list) else []:
        if not isinstance(entry, dict):
            continue
        cid = entry.get('id')
        # Only add registry rows for channels we actually imported and don't have.
        if cid in imported_cids and cid not in have_ids:
            local_reg.append(entry)
            have_ids.add(cid)
            added += 1
    if added or not os.path.exists(local_path):
        with open(local_path, 'w', encoding='utf-8') as f:
            json.dump(local_reg, f, ensure_ascii=False, indent=2)
        log(f'[transfer] import: merged {added} channel(s) into channels/index.json')
