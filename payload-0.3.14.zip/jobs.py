#!/usr/bin/env python3
"""Реєстр живих процесів ChatView плюс два гейти: на вбивство і на спавн.

НАВІЩО. Досі кожен, хто щось спавнив, сам вирішував як це вбивати, і вбивав по
голому pid з диска. Звідси клас багів «стоп поклав не те»: pid у status.json
міг застаріти, pgid міг вести в групу раннера (див. chatview_platform.safe_pgid),
а API приймав будь-який pid, який йому передали.

Тут одна точка правди. Кожен спавн реєструється файлом jobs/<jobId>.json, і
вбити можна ЛИШЕ зареєстрований job, ЛИШЕ якщо це досі той самий процес.

ГЕЙТ НА ВБИВСТВО, чотири перевірки поспіль:
  1. job існує в реєстрі. Довільний pid ззовні вбити неможливо в принципі.
  2. pid не в захищеному списку (сам сервер, раннер, init).
  3. процес ТОЙ САМИЙ: збігається час старту, знятий при реєстрації. Закриває
     pid-reuse, коли ОС видала номер небіжчика новому процесу.
  4. killpg лише коли safe_pgid підтвердив, що pid сам лідер своєї групи.

ГЕЙТ НА СПАВН: /api/job-spawn не запускає довільну команду з тіла запиту, лише
іменований тип з SPAWN_KINDS. Сервер слухає localhost, але localhost це і
кожна вкладка браузера, тому endpoint «виконай що передали» був би дірою.

ГЕЙТ НА ПОВТОР: /api/job-rerun бере argv не з запиту, а з сайдкар-файла
jobs/<jobId>.cmd, який кладе поруч сам локальний врапер (job.cjs). Записати
такий файл може лише те, що має доступ до диска, тобто процес на цій машині;
вкладка браузера не може ніяк. Той самий файл дає шлях до лога, тому і
/api/job-log читає не той шлях, що прийшов у запиті (це була б ручка «віддай
будь-який файл»), а той, що лежить на диску.

Чистий stdlib, без залежностей: модуль однаково імпортується в dev і в
замороженому PyInstaller-білді.
"""
import csv
import os
import sys
import json
import time
import signal
import subprocess
import threading
import uuid

DIR = os.environ.get('CHATVIEW_HOME') or os.path.dirname(os.path.abspath(__file__))
JOBS_DIR = os.path.join(DIR, 'jobs')

# Тека з КОДОМ, свідомо окремо від DIR. DIR це дім ДАНИХ: у пакованій збірці він
# вказує на ~/Library/Application Support/ChatView, тоді як самі модулі лежать
# глибше, у payload/. Шлях до воркера, який ми спавнимо, треба брати від себе
# самого, інакше десктоп шукав би agent_worker.py у теці даних і не знаходив.
CODE_DIR = os.path.dirname(os.path.abspath(__file__))

# Скільки завершений job лежить у реєстрі, перш ніж його приберуть. Треба, щоб
# UI встиг показати «щойно завершилось», але тека не росла вічно.
KEEP_DONE_SEC = 10 * 60
# Стеля на кількість файлів у реєстрі: захист від нескінченного росту, якщо
# prune десь не спрацював.
MAX_FILES = 500

_LOCK = threading.Lock()

# Імена процесів, які не можна вбивати ЖОДНИМ шляхом через цей модуль.
PROTECTED_NAMES = ('runner.py', 'server.py', 'launchd', 'systemd')

# Програми, для яких «що виконується» це НЕ сам бінарник, а його скрипт: движок у ps
# виглядає як `/…/Python.app/Contents/MacOS/Python /…/chat/server.py`, і по argv[0]
# там лише «Python». Тому для інтерпретатора дивимось ще й на перший файл-аргумент.
INTERPRETERS = ('node', 'nodejs', 'sh', 'bash', 'zsh', 'dash', 'ksh',
                'ruby', 'perl', 'deno', 'bun', 'osascript')
# Прапорці інтерпретатора, які ЗАБИРАЮТЬ значення: без цього `python -W ignore server.py`
# прийняв би `ignore` за скрипт, зупинився і не побачив движка.
_FLAGS_WITH_VALUE = ('-W', '-X', '-Q', '--check-prefix')
# Прапорці, після яких скрипта нема взагалі: далі йде код або модуль, тобто АРГУМЕНТИ.
# Саме сюди впирається `sh -c 'echo "живий server.py"'`, і впертись він мусить.
_FLAGS_NO_SCRIPT = ('-c', '-m', '-e')

try:
    from chatview_platform import safe_pgid as _safe_pgid
except Exception:                                    # частковий чекаут
    def _safe_pgid(pid):
        if not hasattr(os, 'getpgid'):
            return None
        try:
            pid = int(pid)
            if pid <= 1:
                return None
            pgid = os.getpgid(pid)
        except (TypeError, ValueError, OSError):
            return None
        if pgid != pid or pgid == os.getpgrp():
            return None
        return pgid


# ── пробники Windows ─────────────────────────────────────────────────────────
#
# НАВІЩО ЦЕЙ БЛОК. На Windows у Python немає сигналу 0: документація os.kill каже
# прямо, що будь-яке значення, крім CTRL_C_EVENT і CTRL_BREAK_EVENT, віддається в
# TerminateProcess. Тобто звична POSIX-проба os.kill(pid, 0) там не питає «чи
# живий», а ВБИВАЄ і зверху рапортує «живий». Панель «Процеси» смикає /api/jobs
# постійно, list_jobs на кожному проході кличе alive_map, тож проба вбивала рівно
# ті job-и, які показувала (див. specs/windows-parity/audit-process.md, BLOCK 5).
#
# Три речі, яких нам бракує на nt і які на POSIX дає один ps: чи живий процес, що
# він виконує і хто його батько. Тут вони зроблені локально і приватно. Місце їм
# у chatview_platform поруч з kill_process_tree, але той файл зараз тримає інший
# агент, тому переносити не можна: див. звіт до цієї правки.

# OpenProcess з цим правом нічого процесу не робить: воно рівно на «подивитись».
_PROCESS_QUERY_LIMITED_INFORMATION = 0x1000
_STILL_ACTIVE = 259
_ERROR_INVALID_PARAMETER = 87        # такого pid у системі немає
_ERROR_ACCESS_DENIED = 5             # pid є, але процес чужий


def _nt_alive_ctypes(pid):
    """Живість через саме ядро: True/False, або None якщо спитати не вдалось.

    Найдешевший і найточніший з двох пробників, тому перший. Пастка відома і
    свідомо прийнята: процес, який завершився з кодом рівно 259, виглядатиме
    живим. Ціна помилки тут це зайвий рядок у смужці, тоді як ціна os.kill(pid, 0)
    це вбитий процес."""
    try:
        import ctypes
        k32 = ctypes.windll.kernel32          # поза Windows цього атрибута немає
    except Exception:
        return None
    try:
        h = k32.OpenProcess(_PROCESS_QUERY_LIMITED_INFORMATION, False, int(pid))
        if not h:
            err = k32.GetLastError()
            if err == _ERROR_INVALID_PARAMETER:
                return False
            if err == _ERROR_ACCESS_DENIED:
                return True                   # не пустили всередину, але процес є
            return None
        try:
            code = ctypes.c_ulong()
            if not k32.GetExitCodeProcess(h, ctypes.byref(code)):
                return None
            return code.value == _STILL_ACTIVE
        finally:
            k32.CloseHandle(h)
    except Exception:
        return None


def _nt_tasklist_row(pid):
    """Рядок tasklist про цей pid: список полів CSV, [] якщо процесу немає,
    None якщо спитати не вдалось.

    Формат саме CSV, а не /NH-колонки, і це не смак: у колонковому виводі pid
    доводиться шукати підрядком, а в сусідній колонці памʼяті стоїть «12,345 K»,
    де малий pid знайшовся б як частина числа. У CSV номер це рівно поле [1]."""
    try:
        r = subprocess.run(['tasklist', '/FO', 'CSV', '/NH', '/FI', 'PID eq %d' % int(pid)],
                           capture_output=True, text=True, timeout=5)
    except Exception:
        return None
    if getattr(r, 'returncode', 0) != 0:
        return None
    for row in csv.reader((r.stdout or '').splitlines()):
        # Порожня вибірка це один рядок «INFO: No tasks…», тобто одне поле. Текст
        # локалізований, тому впізнаємо його не за словами, а за формою.
        if len(row) >= 2 and row[1].strip() == str(int(pid)):
            return row
    return []


def _nt_alive_tasklist(pid):
    row = _nt_tasklist_row(pid)
    return None if row is None else bool(row)


def _nt_pid_alive(pid):
    """Чи живий процес на Windows. Жодного os.kill на цьому шляху.

    Коли не відповів ЖОДЕН пробник, кажемо «живий». Напрямок обраний свідомо:
    сказати «мертвий» означає прибрати живу фонову роботу зі смужки без причини,
    а це рівно та сліпота, проти якої весь реєстр і будувався. Зайвий рядок, який
    висить, людина бачить і може зупинити; роботу, якої не видно, не може."""
    for probe in (_nt_alive_ctypes, _nt_alive_tasklist):
        v = probe(pid)
        if v is not None:
            return v
    return True


def _nt_wmic_field(pid, field):
    """Одне поле Win32_Process через wmic, або '' якщо не вийшло.

    wmic оголошений застарілим і на свіжих збірках Windows 11 його може не бути
    взагалі, тому це СПРОБА, а не опора. Іншого джерела ПОВНОГО командного рядка
    і батьківського pid у чистій stdlib немає, тож коли wmic мовчить, викликач
    мусить сам вирішити, як поводитись із незнанням. Обидва наші викликачі
    вирішують однаково: незнання читається як «не чіпати»."""
    try:
        r = subprocess.run(['wmic', 'process', 'where', 'ProcessId=%d' % int(pid),
                            'get', field, '/format:list'],
                           capture_output=True, text=True, timeout=5)
    except Exception:
        return ''
    if getattr(r, 'returncode', 0) != 0:
        return ''
    head = field.lower() + '='
    for line in (r.stdout or '').splitlines():
        line = line.strip()
        if line.lower().startswith(head):
            return line.split('=', 1)[1].strip()
    return ''


def _nt_proc_cmd(pid):
    """Що процес виконує. Повний рядок від wmic, інакше хоч імʼя образу від
    tasklist, інакше ''.

    Другий рівень слабший чесно: у tasklist є лише «python.exe», без скрипта, тож
    движок під ним не впізнається. Це не привід прибирати другий рівень: він
    відрізняє «процес є, але деталей не дали» від «нічого не змогли спитати», а
    саме на цій різниці стоїть fail-safe у _protected."""
    cmd = _nt_wmic_field(pid, 'CommandLine')
    if cmd:
        return cmd
    row = _nt_tasklist_row(pid)
    return row[0].strip() if row else ''


def _nt_ppid(pid):
    """Батьківський pid на Windows, або None якщо не дізнались."""
    try:
        return int(_nt_wmic_field(pid, 'ParentProcessId'))
    except (TypeError, ValueError):
        return None


# ── ідентичність процесу ─────────────────────────────────────────────────────

def _proc_start(pid):
    """Час старту процесу як рядок, або '' якщо не дізнались.

    Це відбиток, за яким ми впізнаємо, що pid досі НАШ. Номери pid ОС переюзує,
    і без такої перевірки стоп через хвилину після смерті агента міг би влучити
    у чужий свіжий процес з тим самим номером."""
    if os.name == 'nt':
        return ''
    try:
        r = subprocess.run(['ps', '-o', 'lstart=', '-p', str(int(pid))],
                           capture_output=True, text=True, timeout=5)
        return (r.stdout or '').strip()
    except Exception:
        return ''


def _proc_cmd(pid):
    if os.name == 'nt':
        return _nt_proc_cmd(pid)
    try:
        r = subprocess.run(['ps', '-o', 'command=', '-p', str(int(pid))],
                           capture_output=True, text=True, timeout=5)
        return (r.stdout or '').strip()
    except Exception:
        return ''


def is_alive(pid):
    """Живий = існує і не зомбі. Зомбі відповідає на сигнальну пробу, тому
    os.kill(pid, 0) тут брехав би.

    На Windows os.kill заборонений не з обережності, а тому що він там убиває:
    див. блок пробників угорі файлу."""
    try:
        pid = int(pid)
    except (TypeError, ValueError):
        return False
    if pid <= 1:
        return False
    if os.name == 'nt':
        return _nt_pid_alive(pid)
    try:
        r = subprocess.run(['ps', '-o', 'stat=', '-p', str(pid)],
                           capture_output=True, text=True, timeout=5)
        st = (r.stdout or '').strip()
        return bool(st) and not st.startswith('Z')
    except Exception:
        try:
            os.kill(pid, 0)
            return True
        except OSError:
            return False


def alive_map(pids):
    """Живість ПАЧКОЮ: {pid: bool} за ОДИН виклик ps замість одного на кожен.

    Народилось із заміру: /api/jobs віддавав відповідь 130 мс проти 19 мс у сусіднього
    /api/agents-all, і різниця вся була в підпроцесах. Кожен list_jobs() смикав ps на
    КОЖЕН запис, а тепер цей список ще й опитує UI кожні кілька секунд з кожної колонки.
    З десятком записів це вже секунда на запит, і рахунок платить увесь сервер, бо він
    один на всі вкладки."""
    pids = [p for p in {int(p) for p in pids if str(p).lstrip('-').isdigit()} if p > 1]
    if not pids:
        return {}
    if os.name == 'nt':
        return {p: is_alive(p) for p in pids}
    seen = {}
    try:
        r = subprocess.run(['ps', '-o', 'pid=,stat=', '-p', ','.join(str(p) for p in pids)],
                           capture_output=True, text=True, timeout=5)
        for line in (r.stdout or '').splitlines():
            parts = line.split()
            if len(parts) < 2:
                continue
            try:
                seen[int(parts[0])] = not parts[1].startswith('Z')
            except ValueError:
                continue
    except Exception:
        pass
    # ПАСТКА, через яку ця функція мало не стала багом гірше того, що лікує: macOS ps
    # відмовляє на ВЕСЬ список, щойно в ньому трапиться завеликий pid
    # («ps: process id too large», код 1, порожній stdout). Один сміттєвий запис у реєстрі
    # оголосив би мертвими геть усі живі job-и, і смужка спорожніла б посеред роботи.
    # Тому «не потрапив у пачку» != «мертвий»: такий pid дознімаємо поштучно. У штатному
    # випадку (усі pid справжні) цей цикл не виконується жодного разу.
    return {p: (seen[p] if p in seen else is_alive(p)) for p in pids}


def _is_interpreter(base):
    return base in INTERPRETERS or base.startswith('python')


def _exec_names(cmd):
    """Імена того, що процес РЕАЛЬНО виконує: сам бінарник і, для інтерпретатора,
    його скрипт. Аргументи сюди не потрапляють НАВМИСНО.

    Раніше захист звіряв усю командну стрічку підрядком, і будь-яка команда, яка
    просто ЗГАДУЄ движок (`sh -c 'echo "живий server.py"'`), отримувала protected-pid
    і не реєструвалась. Наслідок був тихий і бридкий: робота йде, а в смужці її нема,
    тобто рівно та сліпота, проти якої весь цей реєстр і будувався.

    Дірку в інший бік (недозахистити движок) закривають два правила: для інтерпретатора
    беремо перший ФАЙЛ-аргумент, пропускаючи прапорці разом з їхніми значеннями, і
    зупиняємось на `-c`/`-m`, після яких скрипта немає в принципі."""
    toks = (cmd or '').split()
    if not toks:
        return []
    names = [os.path.basename(toks[0])]
    if not _is_interpreter(names[0].lower()):
        return names
    skip_next = False
    for t in toks[1:]:
        if skip_next:
            skip_next = False
            continue
        if t.startswith('-'):
            if t in _FLAGS_NO_SCRIPT:
                break
            if t in _FLAGS_WITH_VALUE:
                skip_next = True
            continue
        names.append(os.path.basename(t))
        break
    return names


def _protected(pid):
    """True якщо цей pid чіпати заборонено: ми самі, наш батько, init, або
    процес, ЩО ВИКОНУЄ сам движок (див. _exec_names: бінарник і скрипт, не аргументи)."""
    try:
        pid = int(pid)
    except (TypeError, ValueError):
        return True
    if pid <= 1 or pid == os.getpid() or pid == os.getppid():
        return True
    cmd = _proc_cmd(pid)
    if os.name == 'nt' and not cmd:
        # FAIL-SAFE У БІК «НЕ ВБИВАТИ». На POSIX порожній ps означає «процесу вже
        # немає», і пустити такий pid безпечно. На Windows порожньо означає інше:
        # «не змогли спитати» (wmic знесений, tasklist недоступний). Пустити його
        # означало б віддати кнопці «Стоп» право покласти власний сервер або IDE,
        # тобто гейт перестав би бути гейтом рівно там, де він потрібен.
        return True
    names = {n.lower() for n in _exec_names(cmd)}
    return any(n.lower() in names for n in PROTECTED_NAMES)


def _descendants(pid, depth=6):
    """Дерево нащадків процесу, зверху вниз. Порожнє на Windows (там taskkill /T).

    Знімати його треба ДО вбивства предка. Після смерті батька ОС перевішує дітей
    на init, і pgrep -P по вже мертвому pid не знаходить нічого: саме на цій гонці
    неізольований стоп лишав онуків живими (доказ: test_jobs_survive.py, кейс 9)."""
    if os.name == 'nt':
        return []
    out, frontier = [], [int(pid)]
    for _ in range(depth):
        nxt = []
        for p in frontier:
            try:
                r = subprocess.run(['pgrep', '-P', str(p)], capture_output=True,
                                   text=True, timeout=3)
                nxt += [int(x) for x in (r.stdout or '').split() if x.isdigit()]
            except Exception:
                pass
        if not nxt:
            break
        out += nxt
        frontier = nxt
    return out


def _ppid(pid):
    """Батько процесу, або None."""
    if os.name == 'nt':
        return _nt_ppid(pid)
    try:
        r = subprocess.run(['ps', '-o', 'ppid=', '-p', str(int(pid))],
                           capture_output=True, text=True, timeout=5)
        return int((r.stdout or '').strip())
    except Exception:
        return None


# Родовід, який дає право зареєструвати процес ззовні. Не «будь-хто на цій
# машині», а «щось, що росте з нашого дерева»: сам сервер, раннер ходу,
# воркер агента або сесія claude (термінальна теж рахується — саме вона
# спавнить фоновий Bash, який ми й хочемо показати у смужці).
#
# job.cjs у списку навмисно: у формі `bg` він спавнить наглядача у ВЛАСНІЙ сесії,
# щоб той пережив вбивство ходу, і наглядач одразу після цього реєструє команду.
# Без цього імені родовід тримався б лише на тому, що батьківський job.cjs ще не
# встиг вийти, тобто гейт то пускав би, то ні залежно від планувальника.
ANCESTOR_NAMES = ('server.py', 'runner.py', 'agent_worker.py', 'claude', 'ChatView',
                  'job.cjs')


def _descends_from_us(pid, depth=16):
    """True якщо процес росте з нашого дерева (див. ANCESTOR_NAMES).

    ГЕЙТ НА РЕЄСТРАЦІЮ ЗЗОВНІ. /api/job-register приймає готовий pid, а не
    спавнить сам, тому без цієї перевірки будь-яка вкладка браузера могла б
    зареєструвати чужий pid (Finder, IDE) і слідом легально вбити його через
    /api/job-stop: гейт на вбивство пропускає все, що є в реєстрі.

    Тут довго стояв беззастережний `return True` на nt, тобто на Windows гейта не
    існувало взагалі. Тепер родовід читається однаково на обох ОС, просто через
    різні джерела (_ppid і _proc_cmd самі знають, де вони живуть). Коли джерело
    мовчить, _ppid віддає None, обхід обривається і функція каже False. Напрямок
    такий тому, що не пустити СВОЮ роботу в реєстр неприємно, але видно одразу і
    виправляється перезапуском, а пустити ЧУЖИЙ pid невиправно: слідом його можна
    легально вбити через /api/job-stop."""
    try:
        cur = int(pid)
    except (TypeError, ValueError):
        return False
    me = os.getpid()
    for _ in range(depth):
        cur = _ppid(cur)
        if not cur or cur <= 1:
            return False
        if cur == me:
            return True
        cmd = _proc_cmd(cur)
        if any(n in cmd for n in ANCESTOR_NAMES):
            return True
    return False


# ── зберігання ───────────────────────────────────────────────────────────────

def _path(job_id):
    return os.path.join(JOBS_DIR, f'{job_id}.json')


def _write(job):
    os.makedirs(JOBS_DIR, exist_ok=True)
    p = _path(job['jobId'])
    tmp = f'{p}.{os.getpid()}.tmp'
    with open(tmp, 'w', encoding='utf-8') as f:
        json.dump(job, f, ensure_ascii=False, indent=2)
    os.replace(tmp, p)
    return job


def _read(job_id):
    try:
        with open(_path(job_id), encoding='utf-8') as f:
            return json.load(f)
    except Exception:
        return None


def _valid_id(job_id):
    return bool(job_id) and all(c.isalnum() or c in '-_' for c in str(job_id))


# ── журнал команд: сайдкар зі спекою ─────────────────────────────────────────
#
# Розширення НАВМИСНО не .json: і prune, і list_jobs ходять по '*.json' у цій самій
# теці, тож спека потрапила б їм у вибірку як «job без jobId» і поклала б /api/jobs
# у 500. Одна буква замість окремої теки.
SPEC_EXT = '.cmd'
# Стеля на хвіст лога в одній відповіді. 64 КБ це десь 800 рядків: більше однаково
# ніхто не читає з поповера, а віддавати гігабайтний лог рендера в JSON не можна.
LOG_TAIL_MAX = 64 * 1024
ARGV_MAX = 200

# Скільки живе спека. НЕ KEEP_DONE_SEC, і це навмисна асиметрія: сам запис job гасне за
# 10 хвилин, бо його читає смужка живого, а журнал у браузері показує ДОБУ історії
# (workLog.ts). Якби спека вмирала разом із записом, кнопка «Запустити знову» працювала б
# лише на десять хвилин з доби видимих рядків, тобто майже ніколи. Для повтору сам запис
# і не потрібен: там усе, що треба, є у спеці. Файл ~200 байт, доба їх нічого не коштує.
SPEC_TTL_SEC = 24 * 60 * 60
SPEC_MAX = 300


def spec_path(job_id):
    """Куди локальний врапер кладе спеку команди. Він дізнається шлях у відповіді
    на /api/job-register, щоб не вгадувати дім даних (у пакованій збірці це
    ~/Library/Application Support/ChatView, а не тека коду)."""
    return os.path.join(JOBS_DIR, f'{job_id}{SPEC_EXT}')


def _sane_spec(raw):
    """Спека у придатному вигляді, або None. Файл лежить на диску і його могли
    зіпсувати руками, тому перевіряємо все, чим потім запускаємо процес."""
    if not isinstance(raw, dict):
        return None
    argv = raw.get('argv')
    if not isinstance(argv, list) or not argv or len(argv) > ARGV_MAX:
        return None
    if not all(isinstance(a, str) and a and len(a) < 4096 for a in argv):
        return None
    out = {'argv': argv}
    for k in ('cwd', 'log', 'kind', 'label', 'channel'):
        v = raw.get(k)
        out[k] = v if isinstance(v, str) else ''
    return out


def read_spec(job_id):
    if not _valid_id(job_id):
        return None
    try:
        with open(spec_path(job_id), encoding='utf-8') as f:
            return _sane_spec(json.load(f))
    except Exception:
        return None


def write_spec(job_id, spec):
    """Записати спеку самим сервером. Потрібно лише для повтору: щоб те, що ми
    щойно перезапустили, теж можна було перезапустити ще раз."""
    if not _valid_id(job_id) or not _sane_spec(spec):
        return False
    try:
        os.makedirs(JOBS_DIR, exist_ok=True)
        p = spec_path(job_id)
        tmp = f'{p}.{os.getpid()}.tmp'
        with open(tmp, 'w', encoding='utf-8') as f:
            json.dump(spec, f, ensure_ascii=False)
        os.replace(tmp, p)
        return True
    except OSError:
        return False


# ── реєстрація ───────────────────────────────────────────────────────────────

def register(kind, channel, pid, label='', meta=None, why='', waiting=''):
    """Записати живий процес у реєстр. Повертає job dict (ніколи не кидає).

    isolated=False означає, що процес сидить у чужій групі, тобто стоп зможе
    вбити лише його самого плюс прямих дітей, не все дерево. Це видно у
    /api/jobs, щоб деградація не була мовчазною."""
    try:
        pgid = _safe_pgid(pid)
        now = time.time()
        job = {
            'jobId': f'job-{uuid.uuid4().hex[:12]}',
            'kind': str(kind or 'proc'),
            'channel': str(channel or ''),
            'label': str(label or ''),
            'pid': int(pid),
            'pgid': pgid,
            'isolated': pgid is not None,
            'startMark': _proc_start(pid),
            'state': 'running',
            'startedAt': now,
            # Живі поля для смужки фонової роботи. Порожні на старті: процес
            # може не звітувати взагалі, і смужка мусить це показати чесно
            # (приглушена смуга «живий, але відсотка не знаю»), а не малювати 0%.
            'step': '',
            'pct': None,
            # НАВІЩО це крутиться. Лейбл відповідає «що це», і для рендера відео
            # цього досить, а для вартового ні: «слот» у смужці не каже нічого, поки
            # не написано, що по звільненні слота піде така-то задача.
            'why': str(why or '')[:300],
            # ЧОГО ЧЕКАЄ і ВІДКОЛИ. Окремо від step навмисно: крок це «що я роблю
            # просто зараз», а очікування це стан, у якому можна висіти годину, і
            # питання до нього інше — «скільки вже» і «воно взагалі настане?».
            'waitingFor': str(waiting or '')[:200],
            'waitingSince': now if waiting else None,
            # ОСТАННЯ ОЗНАКА ЖИТТЯ. Живість pid відповідає лише на «процес існує»;
            # процес може існувати і при цьому висіти намертво. Кожен звіт через
            # /api/job-progress рухає цю мітку, тож мовчання видно окремо від смерті.
            'lastBeat': now,
            'meta': meta or {},
        }
        with _LOCK:
            _write(job)
            _prune_locked()
        return job
    except Exception:
        return None


# Типи, які реєструє САМ движок і які ззовні підробити не можна: 'turn' пише
# runner.py на кожен хід, 'agent'/'agent-claude' — agent_worker.py. Якби HTTP
# дозволяв їх писати, у смужці міг би зʼявитись фантомний «хід» або «агент»,
# і UI відрізнити його від справжнього не зміг би.
RESERVED_KINDS = {'turn', 'agent', 'agent-claude'}


def register_external(kind, channel, pid, label='', meta=None, why='', waiting=''):
    """Реєстрація ГОТОВОГО процесу ззовні (HTTP). Повертає (job, error).

    Відрізняється від register() лише гейтами: сам register() викликають наші
    ж модулі одразу після Popen, там перевіряти нічого. Тут pid приходить у
    тілі запиту, тож перевіряємо все: тип не зарезервований, процес живий, не
    захищений і росте з нашого дерева (_descends_from_us)."""
    kind = str(kind or '').strip()
    if not kind or len(kind) > 24 or not all(c.isalnum() or c in '-_' for c in kind):
        return None, 'bad kind'
    if kind in RESERVED_KINDS:
        return None, f'kind зарезервований движком: {kind}'
    try:
        pid = int(pid)
    except (TypeError, ValueError):
        return None, 'bad pid'
    if not is_alive(pid):
        return None, 'процес не живий'
    if _protected(pid):
        return None, 'protected-pid'
    if not _descends_from_us(pid):
        return None, 'pid не з нашого дерева процесів'
    job = register(kind, channel, pid, label=label, meta=meta, why=why, waiting=waiting)
    return (job, None) if job else (None, 'register failed')


def finish(job_id, state='done', detail=''):
    """Позначити job завершеним. Файл лишається ще KEEP_DONE_SEC, щоб UI встиг
    показати завершення, потім його прибирає prune."""
    if not _valid_id(job_id):
        return None
    with _LOCK:
        job = _read(job_id)
        if not job:
            return None
        job['state'] = state
        job['detail'] = str(detail or '')
        job['endedAt'] = time.time()
        try:
            return _write(job)
        except Exception:
            return None


def progress(job_id, step=None, pct=None, label=None, waiting=None, why=None):
    """Оновити живі поля job-а: поточний крок, відсоток, назву, очікування.

    Пише ЛИШЕ те, що передали: процес може звітувати кроком без відсотка або
    навпаки, і часткове оновлення не мусить затирати друге поле. Завершений
    job не чіпаємо, інакше запізнілий звіт воскресив би його у смужці.

    ОЧІКУВАННЯ має власний годинник. waitingSince переставляється лише коли
    текст очікування ЗМІНИВСЯ: вартовий звітує тим самим рядком щотридцять
    секунд, і якби мітка оновлювалась на кожен звіт, «чекає вже 40 хв»
    показувало б вічні нуль секунд, тобто рівно ту брехню, проти якої це поле
    й заведено. Порожній рядок = дочекались, годинник знімаємо."""
    if not _valid_id(job_id):
        return None
    with _LOCK:
        job = _read(job_id)
        if not job or job.get('state') != 'running':
            return None
        if step is not None:
            job['step'] = str(step)[:200]
        if label is not None:
            job['label'] = str(label)[:120]
        if why is not None:
            job['why'] = str(why)[:300]
        if waiting is not None:
            new = str(waiting)[:200]
            if new != (job.get('waitingFor') or ''):
                job['waitingFor'] = new
                job['waitingSince'] = time.time() if new else None
        if pct is not None:
            try:
                job['pct'] = max(0, min(100, int(float(pct))))
            except (TypeError, ValueError):
                pass
        # Пульс рухає БУДЬ-ЯКИЙ звіт, навіть порожній: сам факт, що процес
        # достукався до реєстру, і є ознакою життя.
        job['lastBeat'] = time.time()
        try:
            return _write(job)
        except Exception:
            return None


def _remove_files(job_id):
    """Прибрати сам запис job. Спеку НЕ чіпаємо: вона переживає запис навмисно і
    гасне за власним строком (див. SPEC_TTL_SEC), інакше повтор не дожив би до
    ранку, хоч рядок у журналі видно цілу добу."""
    try:
        os.remove(_path(job_id))
    except OSError:
        pass


def _prune_specs_locked(now):
    """Своя чистка для спек і для логів, які завів сам повтор. Ходить по інших
    розширеннях і за іншим строком, тому окремим проходом, а не всередині
    загального: змішати їх означало б поховати повтор разом із записом."""
    try:
        names = os.listdir(JOBS_DIR)
    except OSError:
        return
    rows = []
    for n in names:
        if not (n.endswith(SPEC_EXT) or (n.startswith('run-') and n.endswith('.log'))):
            continue
        p = os.path.join(JOBS_DIR, n)
        try:
            age = now - os.path.getmtime(p)
        except OSError:
            continue
        if age > SPEC_TTL_SEC:
            try:
                os.remove(p)
            except OSError:
                pass
            continue
        rows.append((age, p))
    # Стеля: найстаріші першими. Захист від росту, якщо строк десь не спрацював.
    if len(rows) > SPEC_MAX:
        for _age, p in sorted(rows, reverse=True)[:len(rows) - SPEC_MAX]:
            try:
                os.remove(p)
            except OSError:
                pass


def _prune_locked():
    """Прибрати завершені старші за KEEP_DONE_SEC і ті, чий процес зник."""
    try:
        names = [n for n in os.listdir(JOBS_DIR) if n.endswith('.json')]
    except OSError:
        return
    now = time.time()
    rows = []
    loaded = []
    for n in names:
        job = _read(n[:-5])
        if not job:
            try:
                os.remove(os.path.join(JOBS_DIR, n))
            except OSError:
                pass
            continue
        loaded.append(job)
    # Один ps на весь прохід замість одного на кожен запис (див. alive_map).
    alive = alive_map([j.get('pid') for j in loaded if j.get('state') == 'running'])
    for job in loaded:
        if job.get('state') == 'running' and not alive.get(int(job.get('pid') or 0), False):
            # Перечитуємо ПЕРЕД записом. Між читанням списку і замірами живості минає
            # ціле ps, і за цей час запис міг закрити хтось інший: врапер своїм
            # job-finish або сусідній процес зі своїм prune (реєстр один на диску, а
            # _LOCK стереже лише потоки всередині одного процесу). Без цієї звірки
            # чесне 'stopped'/'failed' затиралось би пізнім 'gone'.
            fresh = _read(job['jobId'])
            if fresh and fresh.get('state') != 'running':
                job.update(fresh)
            else:
                job['state'] = 'gone'
                job['endedAt'] = now
                try:
                    _write(job)
                except Exception:
                    pass
        if job.get('state') != 'running' and (now - (job.get('endedAt') or 0)) > KEEP_DONE_SEC:
            # Видаляємо файл САМЕ цього job. Тут довго стояло os.remove(... n ...), де n —
            # протікла змінна ПОПЕРЕДНЬОГО циклу, тобто ЗАВЖДИ останнє імʼя в лістингу
            # теки. Через це кожен застарілий запис зносив випадковий чужий файл, у тому
            # числі ЖИВОГО процесу: рендер зникав зі смужки на десятій хвилині, хоч сам
            # процес жив далі. Це той самий клас баги, проти якого ця смужка й робилась.
            _remove_files(job['jobId'])
            continue
        rows.append(job)
    # Стеля: найстаріші завершені йдуть першими.
    if len(rows) > MAX_FILES:
        done = sorted((r for r in rows if r.get('state') != 'running'),
                      key=lambda r: r.get('endedAt') or 0)
        for r in done[:len(rows) - MAX_FILES]:
            _remove_files(r['jobId'])
    _prune_specs_locked(now)


def list_jobs(channel=None, running_only=False):
    """Знімок реєстру, свіжий: спершу звіряємо живість, потім віддаємо."""
    with _LOCK:
        _prune_locked()
        try:
            names = [n for n in os.listdir(JOBS_DIR) if n.endswith('.json')]
        except OSError:
            names = []
        out = []
        for n in names:
            job = _read(n[:-5])
            if not job:
                continue
            if channel and job.get('channel') != channel:
                continue
            if running_only and job.get('state') != 'running':
                continue
            # Команду показуємо зі СПЕКИ, а не з meta. meta приходить у тілі HTTP,
            # тобто її може написати будь-яка вкладка; спека лежить на диску, і те, що
            # UI малює в рядку, збігається з тим, що реально запуститься на повтор.
            # Окремого прапорця «можна повторити» свідомо нема: він завжди дорівнював би
            # «спека є», а два поля про один факт рано чи пізно розʼїжджаються.
            spec = read_spec(job['jobId'])
            if spec:
                job['cmd'] = {'argv': spec['argv'], 'cwd': spec['cwd'], 'log': spec['log']}
            out.append(job)
    out.sort(key=lambda j: j.get('startedAt') or 0, reverse=True)
    return out


# ── гейт на вбивство ─────────────────────────────────────────────────────────

def stop(job_id, grace=0.4):
    """Зупинити зареєстрований job. Повертає {ok, reason, killed, pgid}.

    Кожна відмова має причину в reason, щоб з логу було видно, який саме гейт
    спрацював, а не глухе «нічого не сталось»."""
    if not _valid_id(job_id):
        return {'ok': False, 'reason': 'bad-id'}
    job = _read(job_id)
    if not job:                                   # гейт 1: тільки зареєстроване
        return {'ok': False, 'reason': 'unknown-job'}
    pid = job.get('pid')
    # Гейт 2 стоїть ПЕРШИМ навмисно: «цей pid чіпати не можна» важливіше за
    # «він уже завершився». Інакше відповідь на спробу вбити движок залежала б
    # від того, чи встиг prune переписати стан запису, і причина відмови
    # плавала б між protected-pid і already-finished.
    if _protected(pid):                           # гейт 2: захищені процеси
        return {'ok': False, 'reason': 'protected-pid'}
    if job.get('state') != 'running':
        return {'ok': True, 'reason': 'already-finished', 'killed': False}
    if not is_alive(pid):
        finish(job_id, 'gone')
        return {'ok': True, 'reason': 'already-dead', 'killed': False}
    mark = job.get('startMark') or ''
    if mark and _proc_start(pid) != mark:         # гейт 3: той самий процес?
        finish(job_id, 'gone', 'pid переюзаний ОС')
        return {'ok': False, 'reason': 'pid-reused'}

    if os.name == 'nt':
        try:
            subprocess.run(['taskkill', '/F', '/T', '/PID', str(pid)],
                           capture_output=True, timeout=5)
        except Exception:
            pass
        finish(job_id, 'stopped')
        return {'ok': True, 'reason': 'taskkill', 'killed': True, 'pgid': None}

    pgid = _safe_pgid(pid)                        # гейт 4: група лише своя
    # Неізольований job: сигнал по групі заборонений, тож дерево нащадків знімаємо
    # ЗАРАЗ, поки батько живий і ще тримає їх при собі (див. _descendants).
    kids = [] if pgid is not None else _descendants(pid)
    try:
        if pgid is not None:
            os.killpg(pgid, signal.SIGTERM)
        else:
            os.kill(int(pid), signal.SIGTERM)
    except OSError:
        pass
    time.sleep(grace)
    if is_alive(pid):
        try:
            if pgid is not None:
                os.killpg(pgid, signal.SIGKILL)
            else:
                os.kill(int(pid), signal.SIGKILL)
        except OSError:
            pass
    if pgid is None:
        # Група була чужа, сигнал її не накрив: добиваємо нащадків, знятих ДО вбивства.
        for kid in kids:
            try:
                os.kill(kid, signal.SIGKILL)
            except OSError:
                pass
    finish(job_id, 'stopped')
    return {'ok': True, 'reason': 'killed', 'killed': True, 'pgid': pgid}


def stop_channel(channel):
    """Зупинити всі живі jobs каналу. Повертає список результатів."""
    return [dict(stop(j['jobId']), jobId=j['jobId'])
            for j in list_jobs(channel=channel, running_only=True)]


# ── гейт на спавн ────────────────────────────────────────────────────────────

def _agent_argv(args):
    """agent: agent_worker.py <channel> <agentId>. Обидва аргументи мусять бути
    простими іменами: жодних слешів, крапок-крапок і порожнечі.

    Дві форми запуску, бо в пакованій збірці sys.executable це САМ ChatView, а не
    python: віддати йому .py неможливо, він просто підняв би другий сервер. Тому
    заморожений лаунчер має режим --agent-worker, який виконує той самий
    agent_worker.py з активного payload. У dev усе лишається як було."""
    channel = str(args.get('channel') or '').strip()
    agent_id = str(args.get('agentId') or '').strip()
    for v in (channel, agent_id):
        if not v or '/' in v or '\\' in v or '..' in v:
            raise ValueError('bad channel/agentId')
    if getattr(sys, 'frozen', False):
        return [sys.executable, '--agent-worker', channel, agent_id]
    return [sys.executable, os.path.join(CODE_DIR, 'agent_worker.py'), channel, agent_id]


# Білий список: іменований тип -> будівник argv. Тіло запиту дає ПАРАМЕТРИ, а
# не команду, тож через HTTP не можна запустити нічого, чого тут не написано.
SPAWN_KINDS = {
    'agent': _agent_argv,
}

# Прапорці CreateProcess беремо через getattr: у subprocess вони існують ЛИШЕ на
# Windows, а модуль мусить імпортуватись (і тестуватись) на маку теж.
_CREATE_NEW_PROCESS_GROUP = getattr(subprocess, 'CREATE_NEW_PROCESS_GROUP', 0x00000200)
_DETACHED_PROCESS = getattr(subprocess, 'DETACHED_PROCESS', 0x00000008)
_CREATE_NO_WINDOW = getattr(subprocess, 'CREATE_NO_WINDOW', 0x08000000)


def _spawn_kwargs(name=None):
    """Аргументи Popen, щоб дитина пережила і наш хід, і нашу консоль.

    Однієї групи процесів на Windows мало: CREATE_NEW_PROCESS_GROUP рятує від
    Ctrl-C і від смерті разом з ходом, але процес лишається ПРИКРІПЛЕНИМ до
    консолі сервера і гине разом з нею. Відчіплює саме DETACHED_PROCESS, а
    CREATE_NO_WINDOW не дає блимнути чорним вікном на робочому столі. Третій
    прапорець поруч з DETACHED_PROCESS документація називає ігнорованим, тримаємо
    його для однакової форми з chatview_platform._detach_kwargs, де набір рівно
    такий самий і зроблений правильно."""
    if (name or os.name) == 'nt':
        return {'creationflags': (_CREATE_NEW_PROCESS_GROUP | _DETACHED_PROCESS
                                  | _CREATE_NO_WINDOW)}
    return {'start_new_session': True}


def spawn(kind, args=None, label='', channel=''):
    """Запустити процес з білого списку у ВЛАСНІЙ сесії і зареєструвати його.

    Повертає (job, error). Довільний argv не приймається принципово: див.
    SPAWN_KINDS."""
    args = args or {}
    build = SPAWN_KINDS.get(str(kind))
    if build is None:
        return None, f'kind не дозволений: {kind}'
    try:
        argv = build(args)
    except Exception as e:
        return None, str(e)
    kw = _spawn_kwargs()
    try:
        proc = subprocess.Popen(argv, cwd=DIR, stdout=subprocess.DEVNULL,
                                stderr=subprocess.DEVNULL, **kw)
    except Exception as e:
        return None, f'spawn failed: {e}'
    job = register(kind, channel or args.get('channel') or '', proc.pid,
                   label=label, meta={'argv': argv[1:], 'args': args})
    return job, None


# ── повтор і хвіст лога ──────────────────────────────────────────────────────

def _reap(proc, job_id):
    """Дочекатись кінця перезапущеної команди і закрити job чесним станом.

    Без цього повтор завжди закінчувався б 'gone': реєстр помічає лише те, що процес
    зник, і причини не знає. Нитка демонська, тож рестарт сервера її обриває, і job
    доживе до 'gone' штатним шляхом. Це деградація, а не поломка: гірше показати
    «зникло без звіту» після рестарту, ніж тримати сервер заручником чужого рендера."""
    try:
        code = proc.wait()
    except Exception:
        code = None
    finish(job_id, 'done' if code == 0 else 'failed',
           '' if code == 0 else f'код виходу {code}')


def rerun(job_id, channel=''):
    """Запустити ще раз те, що вже запускали. Повертає (job, error).

    argv береться ЛИШЕ зі спеки на диску (див. гейт на повтор угорі файлу). Вивід
    доливаємо в той самий лог, що просила початкова команда; якщо лога не було
    (форма wrap пише в термінал, а термінала тут нема) — заводимо власний, щоб
    повтор ніколи не був сліпим."""
    spec = read_spec(job_id)
    if not spec:
        return None, 'нема запису команди: повторити можна лише те, що реєстрував job.cjs'
    argv = spec['argv']
    cwd = spec['cwd'] if os.path.isdir(spec['cwd'] or '') else DIR
    log = spec['log']
    if not log:
        os.makedirs(JOBS_DIR, exist_ok=True)
        log = os.path.join(JOBS_DIR, f'run-{uuid.uuid4().hex[:8]}.log')
    try:
        out = open(log, 'a', encoding='utf-8')
    except OSError:
        out, log = subprocess.DEVNULL, ''
    kw = ({'creationflags': subprocess.CREATE_NEW_PROCESS_GROUP}
          if os.name == 'nt' else {'start_new_session': True})
    try:
        proc = subprocess.Popen(argv, cwd=cwd, stdin=subprocess.DEVNULL,
                                stdout=out, stderr=subprocess.STDOUT, **kw)
    except Exception as e:
        return None, f'не запустилось: {e}'
    finally:
        # Дескриптор уже продубльований у дитину, батькові він більше не потрібен.
        if out is not subprocess.DEVNULL:
            try:
                out.close()
            except OSError:
                pass
    job = register(spec['kind'] or 'proc', channel or spec['channel'], proc.pid,
                   label=spec['label'] or ' '.join(argv)[:60],
                   meta={'argv': argv, 'rerunOf': job_id})
    if not job:
        return None, 'запустилось, але не зареєструвалось'
    write_spec(job['jobId'], dict(spec, log=log))
    threading.Thread(target=_reap, args=(proc, job['jobId']), daemon=True).start()
    return job, None


def log_tail(job_id, max_bytes=LOG_TAIL_MAX):
    """Хвіст лога команди. Повертає (dict, error).

    Шлях беремо зі спеки НА ДИСКУ і ніколи з запиту: ручка, якій можна передати
    свій шлях, це ручка «віддай будь-який файл цієї машини» для кожної вкладки."""
    spec = read_spec(job_id)
    if not spec:
        return None, 'нема запису команди'
    if not spec['log']:
        return None, 'команда не писала лог'
    try:
        size = os.path.getsize(spec['log'])
        with open(spec['log'], 'rb') as f:
            if size > max_bytes:
                f.seek(size - max_bytes)
            data = f.read()
    except OSError as e:
        return None, f'лог недоступний: {e}'
    return {'path': spec['log'], 'size': size, 'truncated': size > max_bytes,
            'text': data.decode('utf-8', 'replace')}, None
