#!/usr/bin/env python3
"""ChatView self-update — the updatable PAYLOAD, thin-launcher model.

The frozen .app/.exe is a THIN launcher that rarely changes. The code it runs
(server.py, runner.py, index.html, canvas SPA ...) is a PAYLOAD that lives in the
user's writable data home and can be replaced in place by a newer download —
WITHOUT touching the signed binary (so Gatekeeper/SmartScreen never re-trip) and
WITHOUT ever touching user DATA (channels/, canvas-data/ live in the home, NOT in
the payload dir). Same flow on Mac and Windows; only relaunch differs (delegated
to chatview_platform).

Design (patterns named in code):
  * Strategy       - `UpdateSource` interface; `GitHubReleaseSource` (public manifest)
                     and `BrokerSource` (private payloads behind signed URLs) are two
                     interchangeable impls, exactly the OCP seam this file promised.
  * Composite      - `ChainSource` tries sources in order, so a broker outage falls
                     back to the legacy public manifest instead of stranding the app.
  * Template Method - `Updater.update()` fixes the algorithm (check -> download ->
                     verify -> stage -> atomic swap) and defers the "where do I
                     look" step to the injected source (Dependency Inversion).

Pure stdlib (urllib, hashlib, zipfile) so it imports identically frozen and in dev.
"""
import os
import re
import abc
import json
import base64
import shutil
import hashlib
import zipfile
import tempfile
import urllib.parse
import urllib.request


# --- where updates come from -------------------------------------------------
#
# TWO channels, tried in order, because closing the source must not brick the fleet.
#
# (STATUS 2026-09-04: only channel 2 is actually wired in by default, because the broker
# was never deployed. The code below is unchanged and ready; see default_source().)
#
# 1. BROKER (primary, private code). A tiny serverless endpoint that holds a read-only
#    GitHub token for the PRIVATE payload repo and hands the app a freshly minted,
#    short-lived signed URL for the zip. The token never leaves the server; the app
#    only carries APP_GATE_KEY, which is a revocable throttle/telemetry handle, NOT a
#    secret (anything shipped in a binary is extractable by definition). What the
#    broker genuinely buys: the payload zips stop being clonable/indexable off a public
#    repo, every fetch is logged and attributable, and access can be cut off per key.
# 2. LEGACY public manifest (fallback, forever). The address every already-installed
#    app was born knowing. It stays reachable and frozen at the bridge release so an
#    app that predates the broker can still self-update ONTO the broker. Deleting it
#    is the one move that would actually strand users, so it is never deleted.
#
# Env overrides for dev/staging: CHATVIEW_BROKER_URL, CHATVIEW_APP_KEY,
# CHATVIEW_UPDATE_URL (the last one pins a single plain manifest and skips the chain).
LEGACY_UPDATE_URL = ('https://raw.githubusercontent.com/'
                     'VolodymyrKopach/chatview-releases/main/version.json')

# Kept under the original name: entry.py imports DEFAULT_UPDATE_URL and ships inside the
# frozen binary, so it can only change with a new .dmg. Pointing it at the legacy channel
# keeps old shells working; check_and_stage() upgrades that value to the full chain.
DEFAULT_UPDATE_URL = LEGACY_UPDATE_URL

# The address the broker is MEANT to live at. Not wired into the default chain: it is
# not deployed, and a source that always fails makes every check report a false alarm.
# default_source() explains it in full and shows how to switch it back on.
DEFAULT_BROKER_URL = 'https://chatview-updates.vercel.app/api/version'

# Gate key, not a credential. Rotating = add the new key to the broker's CHATVIEW_APP_KEYS
# and ship it here; the broker accepts a LIST so old apps keep working indefinitely.
APP_GATE_KEY = 'cvk1_a44f34c72a00ff7413227fed74e86cab'


# --- release signing (Ed25519, pure stdlib) ----------------------------------
#
# WHAT THIS CLOSES. Until now the only integrity check was `if info.sha256:` — an
# OPTIONAL hash, taken from the same manifest as the URL. Anyone who could answer the
# manifest request (a MITM on a hostile network, a hijacked CDN edge, a compromised
# broker, a typo-squatted host) could serve their own zip AND their own matching hash,
# and the app would install it as the code it runs on every launch. A hash proves only
# "this is the file the manifest named"; it says nothing about WHO wrote the manifest.
# Worse, the check was skippable by simply OMITTING sha256 — the weakest possible
# default, chosen by the attacker.
#
# So verification is now MANDATORY and AUTHENTICATED:
#   1. the manifest must carry a well-formed sha256,
#   2. it must carry an Ed25519 signature over (version, sha256) by a key we ship,
#   3. the downloaded bytes must hash to exactly that sha256.
# Any missing piece aborts the update — fail CLOSED. The private key never leaves the
# release machine / CI secret, so forging step 2 needs the signing key, not just a
# position on the network.
#
# WHY THE KEY LIVES IN THE BINARY. RELEASE_PUBKEYS is compiled into the frozen bundle
# (ChatView.spec ships this file) and pinned a SECOND time in desktop/entry.py, which
# only ever changes with a new .dmg/.exe. The chain of custody is: signed installer ->
# pinned key -> every payload thereafter. A payload can ADD keys (that is how rotation
# reaches the fleet) but can never remove the binary's own key from the accepted set.
#
# ROTATION (append-only, same discipline as the gate key): generate the new key, ship it
# in this tuple via a normal payload update, wait for the fleet to carry it, and only
# THEN start signing with it. Removing a key that apps still rely on strands them.
SIG_ALG = 'ed25519-v1'

# Public halves only. Private seed lives outside the repo:
#   ~/.chatview/release-signing-key.json  (local)  /  CHATVIEW_SIGNING_KEY (CI secret)
RELEASE_PUBKEYS = (
    # cv-release-2026-07 — active signer, generated 2026-07-31
    'ded02cf2a2efcafd1ce9acbbb6d18fe306c9416d8c686b9aa0589935cdf3b60b',
)

_HEX64_RE = re.compile(r'^[0-9a-f]{64}$')
# Versions go INTO the signed message, so they must not be able to smuggle a newline and
# re-frame what was signed ("0.1\nsha=<other>" style). Digits/dots/dashes only.
_VERSION_RE = re.compile(r'^[0-9A-Za-z][0-9A-Za-z.+-]{0,31}$')


class VerifyError(Exception):
    """Manifest is not provably ours. Always fatal to an update, never to the app."""


def signing_message(version, sha256_hex):
    """The exact bytes a release signature covers.

    Binds the artifact hash to the version it claims to be, so a valid old signature
    cannot be replayed against a new version number (and downgrade is separately blocked
    by is_newer). Deliberately NOT covering the URL: the broker mints a fresh signed URL
    per request, so the URL is not stable release data — the hash is what pins content."""
    return ('chatview-payload-v1\n%s\n%s\n' % (version, sha256_hex)).encode('utf-8')


# ---- Ed25519 (RFC 8032 reference arithmetic, verbatim shapes) ---------------
# Hand-rolled rather than `cryptography`/`PyNaCl` on purpose: this module must import
# identically in a PyInstaller bundle and in a bare `python3 server.py` dev run. A
# third-party wheel is one missing hidden-import away from "the updater cannot verify,
# so the app can never update again" — a brick that only a reinstall fixes. Stdlib
# hashlib + int arithmetic can never go missing. Verify costs ~30 ms, once per check.
_ED_P = 2 ** 255 - 19
_ED_L = 2 ** 252 + 27742317777372353535851937790883648493   # group order


def _ed_inv(x):
    return pow(x, _ED_P - 2, _ED_P)


_ED_D = -121665 * _ed_inv(121666) % _ED_P
_ED_SQRT_M1 = pow(2, (_ED_P - 1) // 4, _ED_P)


def _ed_recover_x(y, sign):
    if y >= _ED_P:
        return None
    xx = (y * y - 1) * _ed_inv(_ED_D * y * y + 1)
    if xx % _ED_P == 0:
        return None if sign else 0
    x = pow(xx, (_ED_P + 3) // 8, _ED_P)
    if (x * x - xx) % _ED_P != 0:
        x = x * _ED_SQRT_M1 % _ED_P
    if (x * x - xx) % _ED_P != 0:
        return None
    if (x & 1) != sign:
        x = _ED_P - x
    return x


_ED_GY = 4 * _ed_inv(5) % _ED_P
_ED_GX = _ed_recover_x(_ED_GY, 0)
_ED_G = (_ED_GX, _ED_GY, 1, _ED_GX * _ED_GY % _ED_P)   # extended coords (x, y, z, t)


def _ed_add(p, q):
    a = (p[1] - p[0]) * (q[1] - q[0]) % _ED_P
    b = (p[1] + p[0]) * (q[1] + q[0]) % _ED_P
    c = 2 * p[3] * q[3] * _ED_D % _ED_P
    d = 2 * p[2] * q[2] % _ED_P
    e, f, g, h = b - a, d - c, d + c, b + a
    return (e * f % _ED_P, g * h % _ED_P, f * g % _ED_P, e * h % _ED_P)


def _ed_mul(s, p):
    q = (0, 1, 1, 0)          # neutral element
    while s > 0:
        if s & 1:
            q = _ed_add(q, p)
        p = _ed_add(p, p)
        s >>= 1
    return q


def _ed_equal(p, q):
    return (p[0] * q[2] - q[0] * p[2]) % _ED_P == 0 \
        and (p[1] * q[2] - q[1] * p[2]) % _ED_P == 0


def _ed_compress(p):
    zi = _ed_inv(p[2])
    x, y = p[0] * zi % _ED_P, p[1] * zi % _ED_P
    return int.to_bytes(y | ((x & 1) << 255), 32, 'little')


def _ed_decompress(raw):
    if len(raw) != 32:
        return None
    y = int.from_bytes(raw, 'little')
    sign = y >> 255
    y &= (1 << 255) - 1
    x = _ed_recover_x(y, sign)
    if x is None:
        return None
    return (x, y, 1, x * y % _ED_P)


def _ed_expand(seed):
    h = hashlib.sha512(seed).digest()
    a = int.from_bytes(h[:32], 'little')
    a &= (1 << 254) - 8
    a |= (1 << 254)
    return a, h[32:]


def ed25519_public_from_seed(seed):
    """32-byte private seed -> 32-byte public key."""
    a, _ = _ed_expand(seed)
    return _ed_compress(_ed_mul(a, _ED_G))


def ed25519_sign(seed, msg):
    """Signing lives here, next to verification, so the release tooling and the fleet can
    never drift onto two different notions of a valid signature. Nothing in the app calls
    it; it is used by the tests and by any Python signing path."""
    a, prefix = _ed_expand(seed)
    pub = _ed_compress(_ed_mul(a, _ED_G))
    r = int.from_bytes(hashlib.sha512(prefix + msg).digest(), 'little') % _ED_L
    rs = _ed_compress(_ed_mul(r, _ED_G))
    k = int.from_bytes(hashlib.sha512(rs + pub + msg).digest(), 'little') % _ED_L
    return rs + int.to_bytes((r + k * a) % _ED_L, 32, 'little')


def ed25519_verify(public, msg, signature):
    """True iff `signature` is a valid Ed25519 signature of `msg` under `public`.
    Never raises on malformed input — a hostile manifest must degrade to False."""
    try:
        if len(public) != 32 or len(signature) != 64:
            return False
        a = _ed_decompress(public)
        if a is None:
            return False
        rs = signature[:32]
        r = _ed_decompress(rs)
        if r is None:
            return False
        s = int.from_bytes(signature[32:], 'little')
        if s >= _ED_L:                      # non-canonical S -> malleable, reject
            return False
        k = int.from_bytes(hashlib.sha512(rs + public + msg).digest(), 'little') % _ED_L
        return _ed_equal(_ed_mul(s, _ED_G), _ed_add(r, _ed_mul(k, a)))
    except Exception:
        return False


# ---- manifest verification --------------------------------------------------

def trusted_keys(extra=None):
    """The accepted signer set: keys pinned by the caller (the frozen binary) first, then
    the ones shipped in this module, then an optional dev key from the environment.

    UNION, not override, and that is deliberate. Pinned-only would brick every old binary
    the day a key is rotated; module-only would let a payload quietly drop the binary's
    key. Both sets always count, so rotation ships like normal code and the installer's
    key stays authoritative forever.

    CHATVIEW_UPDATE_PUBKEY exists for a dev/staging channel signed with a throwaway key.
    It ADDS a signer; there is deliberately no switch that turns verification OFF."""
    out = []
    env = os.environ.get('CHATVIEW_UPDATE_PUBKEY') or ''
    for raw in list(extra or ()) + list(RELEASE_PUBKEYS) + env.replace(';', ',').split(','):
        key = str(raw or '').strip().lower()
        if _HEX64_RE.match(key) and key not in out:
            out.append(key)
    return tuple(out)


def verify_manifest(version, sha256_hex, sig_b64, keys):
    """Raise VerifyError unless (version, sha256) is signed by one of `keys`.

    Every rejection carries WHY: an update that silently does nothing is the failure mode
    that made this whole file distrust its own 'current' status in the first place."""
    if not keys:
        raise VerifyError('no trusted release key compiled in')
    version = str(version or '').strip()
    digest = str(sha256_hex or '').strip().lower()
    if not _VERSION_RE.match(version):
        raise VerifyError('refusing manifest with unusable version %r' % version[:32])
    if not _HEX64_RE.match(digest):
        raise VerifyError('manifest carries no usable sha256 (unsigned channel?)')
    if not sig_b64:
        raise VerifyError('manifest is not signed (no %s signature)' % SIG_ALG)
    try:
        sig = base64.b64decode(str(sig_b64).strip(), validate=True)
    except Exception:
        raise VerifyError('signature is not valid base64')
    if len(sig) != 64:
        raise VerifyError('signature is %d bytes, expected 64' % len(sig))
    msg = signing_message(version, digest)
    for key in keys:
        if ed25519_verify(bytes.fromhex(key), msg, sig):
            return key
    raise VerifyError('signature does not match any trusted release key')


# Files that make up the payload (everything the launcher runs from the home).
# Single source of truth; the build ships these and the updater swaps these.
PAYLOAD_FILES = (
    'VERSION',
    'server.py',
    'runner.py',
    'chatview_updater.py',      # the updater ships ITSELF: entry.py prefers the payload
                                # copy for update checks, so a fix to the update logic
                                # lands via a normal payload instead of a new .dmg.
    'chatview_platform.py',
    'chatview_onboarding.py',   # onboarding (install/login Claude Code); server.py imports it
    'onboarding_store.py',      # стан онбордингу першого запуску (specs/onboarding-empty-states,
                                # Р2/К9). server.py імпортує його на РІВНІ МОДУЛЯ (рядок 64), тож
                                # без нього паковка не деградує, а взагалі не стартує:
                                # `No module named 'onboarding_store'` ще до біндингу порту.
                                # На домі Vova це невидимо, бо там лежить старий payload і код
                                # береться звідти; помирає рівно ЧУЖА машина, тобто той, кому
                                # застосунок дають уперше, і рівно та людина, заради якої
                                # робились підпис і нотаризація. Модуль приїхав 2026-08-21,
                                # у маніфест не потрапив.
    'jobs.py',                  # process registry + kill/spawn gates; server.py + runner.py import it
    'agent_worker.py',          # detached background agent; jobs.spawn runs it (entry.py --agent-worker)
    'stt_install.py',           # завантажувач локального розпізнавача
                                # (specs/mic-two-ways, М2). server.py імпортує його
                                # на РІВНІ МОДУЛЯ (біля WHISPER_BIN), тож без цього
                                # рядка паковка не деградує, а взагалі не стартує:
                                # `No module named 'stt_install'` ще до біндингу
                                # порту. Той самий обрив, що вже стався з
                                # onboarding_store.py і home_spread.py: на домі
                                # автора невидимо, бо там лежить старий payload,
                                # помирає рівно ЧУЖА машина. Він же і воркер, якого
                                # запускає entry.py --stt-install.
    'project_state.py',
    'transfer.py',
    'usage_api.py',
    'media_normalize.py',       # media src -> fetchable URL; server.py + runner.py import
                                # it. Missing here, both swallowed the ImportError and
                                # normalization became a silent no-op, so every audio/
                                # image widget carrying a disk path rendered as nothing
                                # in the desktop app while dev :5555 was fine.
    'plan_store.py',            # THE plan.json writer; runner.py imports it to persist a
                                # declared ```plan``` block. Its predecessor (set-plan.cjs)
                                # was never in this list, so declared plans silently
                                # vanished in every packaged build.
    'auth_store.py',            # login/session store; server.py imports it
    'skill_search.py',          # skill-store ranking (BM25 + embeddings, fused by RRF)
    'skill_scan.py',            # static scan of a foreign skill before it leaves quarantine.
                                # Both are imported by server.py at MODULE level, so absent
                                # from this list the packaged app does not degrade — server.py
                                # fails to import at all and the whole app is dead on boot.
    'skill_live.py',            # запасний шлях стору скілів: живий пошук у GitHub, коли в
                                # індексі порожньо. server.py імпортує його на РІВНІ МОДУЛЯ,
                                # тобто той самий клас смерті на старті, що й два рядки вище.
    'skill_asks.py',            # ознаки скіла (що він просить: ключі, мережа, диск) для
                                # картки в сторі. server.py імпортує його на РІВНІ МОДУЛЯ
                                # (`import skill_asks as _skasks`), тобто той самий клас
                                # смерті на старті. Модуль внесли в git 2026-08-07, а сюди
                                # ні: збірка від того дня і донині падала б на імпорті, і
                                # спіймали це саме payload-guards, коли вперше пакували
                                # після того коміту.
    'rules_store.py',           # шар правил застосунку. server.py і runner.py імпортують
                                # його на РІВНІ МОДУЛЯ, тож без нього паковка не
                                # деградує, а взагалі не стартує.
    'rules.default.md',         # ЗАВОДСЬКИЙ текст правил. Не код, а дані, і саме тому
                                # його найлегше забути: без нього перший старт створює
                                # порожні правила, системний шар зникає, і виглядає це
                                # як «модель раптом здуріла», а не як брак файлу.
    'telemetry.py',             # згода, вимикач і ЄДИНИЙ транспорт телеметрії
                                # (specs/telemetry-onboarding). server.py імпортує
                                # його на РІВНІ МОДУЛЯ, тож без нього паковка не
                                # деградує, а взагалі не стартує. Окремо гірше:
                                # це модуль, у якому живе вимикач, тому забути
                                # його в маніфесті означало б зібрати застосунок,
                                # де вимикача немає, а сховище згоди неможливо
                                # прочитати.
    'agent_room.py',            # кімната каналу: список учасників, роутер, паралель.
                                # І server.py, і runner.py імпортують його на РІВНІ
                                # МОДУЛЯ (саме щоб алгоритм був один на два процеси),
                                # тож без нього паковка не деградує, а не стартує.
    'tls_trust.py',             # довіра до сертифікатів ЦІЄЇ машини (specs/tls-system-trust).
                                # server.py і runner.py імпортують його на РІВНІ МОДУЛЯ,
                                # тобто без нього паковка не стартує взагалі. Іронія в
                                # тому, що саме цей модуль лікує машини з антивірусом:
                                # забути його тут означало б полагодити рівно ту збірку,
                                # яка до таких машин і не доїде.
    'runner_pulse.py',          # пульс раннера: відбиток коду, серцебиття, розбіжність
                                # версій і ознака «хто пише бульбашку промпту». І server.py
                                # (рядок 60), і runner.py (рядок 192) імпортують його на
                                # РІВНІ МОДУЛЯ, тобто без нього паковка не деградує, а
                                # взагалі не стартує. Модуль приїхав комітом 3506b7f0
                                # разом із самою фічею, а сюди не потрапив.
    'agy_models.py',            # правило вибору моделі agy (виробник + клас + глибина)
                                # замість списку версійних імен. runner.py імпортує його на
                                # РІВНІ МОДУЛЯ (рядок 188), server.py ВКЛАДЕНО у хендлері,
                                # тож той самий клас смерті на старті. Приїхав комітом
                                # 07a93c26, у маніфест не внесли.
    'memory_store.py',          # памʼять застосунку (specs/app-memory): сховище під
                                # CHATVIEW_HOME, добір у хід, конфлікти, перенос.
                                # server.py і runner.py імпортують його ВКЛАДЕНО, тому
                                # без нього паковка не падає, а мовчки лишається без
                                # памʼяті. Саме той тип поломки, від якого ця фіча і є.
    'memory_learn.py',          # детектор виправлень тієї ж памʼяті: ловить у ході
                                # правку від людини і кладе кандидата в карантин.
                                # runner.py імпортує його ВКЛАДЕНО у _memory_autolearn_run,
                                # а той ковтає будь-який виняток і лише пише рядок у лог.
                                # Тобто без цього рядка паковка стартує як здорова, везе
                                # memory_store і мовчки не вчиться ніколи. Приїхав комітом
                                # 9f34a0bc разом із сусідом вище, у маніфест не внесли.
    'gadget_pwa.py',            # гаджет як встановлювана апка (specs/gadget-pwa):
                                # веб-маніфест, іконки, вставка посилання у видачу
                                # сторінки. server.py імпортує його ВКЛАДЕНО в хендлері,
                                # тому без нього збірка стартує нормально і просто
                                # перестає бути встановлюваною, мовчки.
    'emoji_raster.py',          # емодзі -> png для іконок апки. Живе окремо від
                                # gadget_pwa, бо це чистий розбір шрифту без жодного
                                # знання про гаджети; gadget_pwa імпортує його на РІВНІ
                                # МОДУЛЯ, тож забути тут = зламати і маніфест теж.
    'specs_board.py',           # дошка спек (GET /api/specs-board). Імпорт вкладений у
                                # хендлер, тому апка не падає на старті: замість дошки
                                # приїжджає 500, і екран порожній без жодної підказки чому.
    'cleanup_scan.py',          # інтелектуальна чистка чатів (specs/smart-chat-cleanup):
                                # правила «порожній / крихітний / без назви», захисти і
                                # партії для моделі. server.py імпортує його ВКЛАДЕНО у
                                # хендлері, тобто збірка стартувала б нормально і померла
                                # б рівно в мить, коли людина натисне «прибрати зайве».
                                # Модуль зʼявився 2026-08-10 і сюди не потрапив; спіймали
                                # payload-guards на першій же збірці після того коміту.
    'library_cache.py',         # каталог ДОСТУПНОГО як кеш у <дім>/library, а не як
                                # бандл (specs/user-owned-entities, 6.3).
                                # skill_search.Corpus._files() імпортує його ВКЛАДЕНО
                                # і має чесний запасний шлях (старий шлях поруч із
                                # index.json), тому без нього збірка не падає, а
                                # мовчки лишається без каталогу в роздачі. Саме тому
                                # рядок тут: мовчазна деградація в цьому місці
                                # виглядає як «магазин порожній», тобто як фіча.
    'entities.py',              # реєстр класів сутностей користувача
                                # (specs/user-owned-entities, К7): один запис на клас
                                # замість розсипаних `os.path.join(DIR, 'apps')`.
                                # Їде ЗАРАЗ, хоч server.py на нього ще не переведений:
                                # переведення двигунів це окрема задача, а модуль, який
                                # приїде в маніфест «потім», рівно так само загубиться,
                                # як загубились memory_learn.py і skill_asks.py.
    'home_migrate.py',          # переїзд домівки в три шухляди
    'home_spread.py',           # корені класів: медіа, стан гаджета, канва (К5)
                                # (specs/user-data-architecture, К9). server.py імпортує
                                # його на РІВНІ МОДУЛЯ і кличе першим рядком запуску,
                                # тож без цього файлу паковка не деградує, а взагалі не
                                # стартує. Той самий обрив, що вже стався з
                                # onboarding_store.py: на домі автора невидимо, бо там
                                # лежить старий payload, помирає рівно ЧУЖА машина.
    'harvest-skills.py',        # збирач каталогу. skill_live._hs() підвантажує його ПО
                                # ШЛЯХУ (дефіс в імені, тому importlib, а не import), і
                                # робить це на гарячій гілці живого пошуку без фолбеку.
                                # Не привезти = запасний шлях падає рівно тоді, коли він
                                # єдиний лишився: індекс порожній.
    'widget_dialects.py',       # адаптер діалектів віджетів (specs/widget-dialect-adapter):
                                # перекладає чужі імена полів у канонічну схему ДО воріт
                                # рендерабельності. runner.py імпортує його на РІВНІ МОДУЛЯ
                                # (рядок 193), а agent_worker.py тягне runner, тож без нього
                                # не стартує ні раннер, ні фоновий агент: паковка не
                                # деградує, а мовчить назавжди, бо помирає ще до першого ходу.
    'batch_publish.py',         # публікація підсумку пачки меседжів (specs/agent-batch-summary,
                                # S5). agent_worker.py імпортує його на РІВНІ МОДУЛЯ (рядок 32),
                                # тобто без цього файлу detached-агент не падає в роботі, а
                                # взагалі не запускається. Найгірший клас: агента спавнять, він
                                # вмирає на імпорті, і в каналі просто ніколи не зʼявляється
                                # картка-результат.
    'batch_claim.py',           # заявка на пачку під тим самим S5: хто саме з агентів має
                                # право написати підсумок, щоб на пачку не приїхало N карток.
                                # У маніфест не потрапив разом із сусідом вище, і це видно
                                # тільки з РОЗПАКОВАНОГО архіву: batch_publish.py імпортує
                                # його на РІВНІ МОДУЛЯ (рядок 23), тому привезти batch_publish
                                # без batch_claim означає не полагодити agent_worker, а лише
                                # пересунути те саме падіння на рядок глибше.
    'batch_detect.py',          # межа пачки: де вона почалась і чи вже закрита.
    'batch_summary.py',         # текст того підсумку. Обидва так само на РІВНІ МОДУЛЯ в
                                # batch_publish.py (рядки 24 і 25), тобто вся четвірка S5
                                # їде або цілком, або ніяк: привезти три з чотирьох означає
                                # рівно ту саму мертву паковку, лише з іншим іменем у трейсі.
    'export_policy.py',         # правило експорту даних (specs/user-owned-entities, К6): який
                                # клас сутностей узагалі можна винести назовні. У server.py
                                # імпорт ВКЛАДЕНИЙ, і саме тому його легко проґавити, але
                                # transfer.py (рядок 40) і memory_store.py (рядок 48) тягнуть
                                # його на РІВНІ МОДУЛЯ, а server.py імпортує transfer на рівні
                                # модуля (рядок 3303). Тобто ланцюг server -> transfer ->
                                # export_policy фатальний: паковка не стартує взагалі.
    'summary_store.py',         # сховище саммарі розмов. server.py імпортує його ВКЛАДЕНО
                                # (рядок 931 і далі в хендлерах), тому без нього збірка
                                # стартує як здорова і мовчки не вміє саммарі: замість
                                # відповіді приїжджає 500 у мить, коли людина його попросить.
    'summary_generate.py',      # генератор тих самих саммарі; server.py тягне його ВКЛАДЕНО
                                # поруч зі сховищем (`import summary_store, summary_generate`),
                                # а сам він імпортує summary_store на РІВНІ МОДУЛЯ. Привезти
                                # сховище без генератора означає зібрати половину фічі, яка
                                # ламається рівно на кроці «згенеруй».
    'worksheet_store.py',       # сховище воркшитів. server.py імпортує його ВКЛАДЕНО (рядки
                                # 12622, 16748, 16757), тож це та сама тиха втрата: апка
                                # стартує, вкладка є, а будь-яка дія з воркшитом падає в 500
                                # без жодної підказки, що бракує саме файлу в маніфесті.
    'index.html',
    'fractional-index.cjs',
    'agent-run.cjs',            # detached-agent bridge (POST /api/agent-spawn). Lived in
                                # repo scripts/ — OUTSIDE this tree — so no packaged build
                                # ever had it, while hooks/agent-bridge-router.cjs tells
                                # the model to run exactly that file. scripts/agent-run.cjs
                                # is now a forwarder; the implementation is here so the
                                # installer AND auto-update both carry it.
)
PAYLOAD_DIRS = (
    'hooks',            # runner.py resolves PERM_HOOK as <its own dir>/hooks/perm-gate.cjs,
                        # and its own dir IS the payload once one is staged. Absent here,
                        # the in-UI permission gate pointed at a file that does not exist;
                        # a PreToolUse hook that fails to run is non-blocking, so the gate
                        # silently FAILED OPEN and tools ran unapproved.
    'canvas-dist',
    'assets',           # V2 React SPA bundle (index-*.js / index-*.css). Present only in
                        # V2 builds; a missing dir in the bundle is a harmless no-op (V1).
    'skills-library',   # ПРОДУКТ-МІНІМУМ помічників, ~264 КБ: наш index.json,
                        # personas-catalog.json, onboarding.json, README і тіла семи
                        # наших помічників. Без них панель Помічників не порожня, а
                        # МЕРТВА: server.py:1633 відкриває index.json без запасного
                        # шляху, а «Встановити» на нашому помічнику копіює теку звідси.
                        #
                        # КАТАЛОГ ДОСТУПНОГО (remote-catalog.json, 5.6 МБ, ~7400 чужих
                        # скілів) у РОЗДАВАЛЬНІЙ збірці звідси вирізається стадією
                        # build.stage_payload_dir і тягнеться з мережі в
                        # <дім>/library/ на перше звернення (library_cache.py). Тека
                        # лишається в списку цілком, бо в особистій збірці Vova і в
                        # оновленні його дому каталог їде як їхав: не-ціль спеки
                        # «його наповнення лишається на місці».
    'mcp',              # реєстр здатностей застосунку (capabilities.json + registry.py):
                        # project_state вантажить його з диска, щоб самоопис не розходився
                        # з тим, що сервер реально вміє. Фолбек там чесний (повертає
                        # людське «реєстр не знайдено поруч із застосунком»), але це
                        # означало, що паковані збірки жили БЕЗ самоопису взагалі. 52 КБ.
    # apps/ (гаджети) НАВМИСНО поза списком, і це рішення один раз уже відкочували в
    # неправильний бік, тому причина записана повністю (рішення власника, 2026-08-18).
    #
    # Гаджет ЦІЛКОМ, разом зі своїм `manifest.json` і `view.html`, це сутність
    # КОРИСТУВАЧА, а не наш пейлоуд. Вона живе в його теці даних: `server.py:36` дає
    # `DIR = CHATVIEW_HOME or тека_репо`, і всі десять читань `os.path.join(DIR, 'apps')`
    # ходять саме туди. Апка привозить ДВИГУН (створити, показати, виконати гаджет), а
    # наповнення знаходить у домі або створює на місці.
    #
    # Що збило з пантелику попереднього разу: панель гаджетів у пакованій апці порожня.
    # Звідси зробили висновок «забули запакувати теку» і внесли `apps` сюди та в
    # --add-data. Насправді порожня вона законно, і бандл її не полагодив би: `entry.py`
    # READONLY_ASSETS теку `apps` не засіває (сказано там прямим текстом), тому з бандла
    # в дім вона все одно не переїхала б, а `server.py` на `/apps/index.json` при
    # відсутній теці свідомо віддає `{"gadgets": []}`. Єдиним живим наслідком того
    # запису було б те, що чужа людина отримує Публікатора, Задачі, Ідеї і CRM автора.
    #
    # specs/ теж НАВМИСНО поза списком (і поза бандлом): це наші внутрішні документи
    # розробки, у застосунку кінцевого користувача їм не місце. Дошка спек читає їх із
    # РОБОЧОЇ ТЕКИ (specs_board.resolve_root), тому «привезти specs у збірку» ніколи не
    # є правильним лікуванням порожньої дошки. Прибито тестом
    # test_build.TestSpecsNeverShip.
)


# ---- version helpers --------------------------------------------------------

def parse_version(s):
    """'1.2.3' -> (1,2,3). Non-numeric / missing parts degrade to 0 so a bad file
    never crashes the launcher; it just compares as an older version."""
    parts = []
    for chunk in str(s or '').strip().split('.'):
        num = ''.join(ch for ch in chunk if ch.isdigit())
        parts.append(int(num) if num else 0)
    while len(parts) < 3:
        parts.append(0)
    return tuple(parts[:3])


def read_version(code_dir):
    try:
        with open(os.path.join(code_dir, 'VERSION'), encoding='utf-8') as fh:
            return fh.read().strip()
    except Exception:
        return '0.0.0'


def is_newer(candidate, current):
    return parse_version(candidate) > parse_version(current)


# ---- update source (Strategy) ----------------------------------------------

class UpdateInfo:
    __slots__ = ('version', 'url', 'sha256', 'sig')

    def __init__(self, version, url, sha256=None, sig=None):
        self.version = version
        self.url = url
        self.sha256 = (sha256 or '').lower() or None
        # base64 Ed25519 signature over signing_message(version, sha256). Absent = the
        # update WILL be refused; carried as None so the refusal names the real reason.
        self.sig = (sig or '').strip() or None

    def __repr__(self):
        return 'UpdateInfo(v=%s, url=%s, sha256=%s, signed=%s)' % (
            self.version, self.url, (self.sha256 or '')[:12], bool(self.sig))


class UpdateSource(abc.ABC):
    """Where a new payload is discovered. Swap the impl to change channels
    (public GitHub Releases vs a private HTTPS endpoint) with zero updater edits.

    CONTRACT — `latest()` returning None is ambiguous on its own, so every impl MUST
    also set `last_error`:
        None returned, last_error is None  -> authoritative "nothing newer exists"
        None returned, last_error is set   -> could not find out (offline/5xx/bad JSON)
    ChainSource and check_and_stage both branch on that difference; collapsing the two
    is what once made a network failure render as a green «у вас найновіша версія»."""

    last_error = None

    @abc.abstractmethod
    def latest(self, since=None) -> 'UpdateInfo':
        """Return the newest available UpdateInfo (or None).

        `since` is the version the caller already holds (running or staged, whichever is
        newer). A dumb manifest ignores it; the broker uses it to answer "nothing newer"
        without minting a signed download URL, which keeps the 99% no-op poll to a single
        upstream call."""


class GitHubReleaseSource(UpdateSource):
    """Reads a small `version.json` manifest published on the release channel:
        {"version": "0.2.0", "url": "https://.../payload.zip", "sha256": "<hex>",
         "sig": "<base64 ed25519 over version+sha256>"}
    A plain JSON manifest (not the GitHub API) keeps it rate-limit-free and lets a
    private server serve the exact same shape. The manifest is fetched over plain HTTPS
    with no pinning, so NOTHING here is trusted: authenticity comes from `sig` alone."""

    def __init__(self, manifest_url, timeout=8):
        self.manifest_url = manifest_url
        self.timeout = timeout
        # Set by latest() on any failure so a caller (the on-demand /api/desktop/
        # update-check handler) can tell "genuinely current" apart from "couldn't
        # even reach the manifest" — both used to collapse into the same silent
        # None, which made the UI show the misleading green "найновіша версія"
        # on a network/TLS failure instead of "не вдалося перевірити".
        self.last_error = None

    def latest(self, since=None):
        self.last_error = None
        try:
            req = urllib.request.Request(self.manifest_url,
                                         headers={'User-Agent': 'ChatView-Updater'})
            with urllib.request.urlopen(req, timeout=self.timeout) as r:
                data = json.loads(r.read().decode('utf-8'))
            v = data.get('version')
            url = data.get('url')
            if not v or not url:
                self.last_error = 'malformed manifest'
                return None
            return UpdateInfo(v, url, data.get('sha256'), data.get('sig'))
        except Exception as e:
            self.last_error = str(e)
            return None  # offline / unreachable -> just no update this launch


class BrokerSource(UpdateSource):
    """Private-payload channel: asks a broker endpoint what the newest version is and
    gets back a SHORT-LIVED signed URL for the zip, minted per request.

    Wire format (deliberately a superset of the plain manifest, so both sources feed the
    identical UpdateInfo and the download path below stays untouched):
        GET <endpoint>?v=<version we already hold>
        Authorization: Bearer <APP_GATE_KEY>
      -> 200 {"version": "0.2.6", "current": true}                  nothing newer
      -> 200 {"version": "0.2.6", "url": "https://...?token=...", "sha256": "<hex>",
              "sig": "<base64>"}
      -> 401 unauthorized / 5xx upstream  -> last_error set, chain falls through

    The broker relays sha256+sig straight from the published manifest and cannot mint
    either: it holds a GitHub token, not the release signing key. So even a fully
    compromised broker can withhold or delay an update, but not substitute one.

    The returned URL is a real GitHub signed object URL: it serves the private zip
    anonymously for a few minutes, supports Range (so a dropped download resumes), and
    404s the moment the signature is stripped or expires. The updater never sees a
    credential, which is the whole point."""

    def __init__(self, endpoint, app_key, timeout=8):
        self.endpoint = endpoint
        self.app_key = app_key
        self.timeout = timeout
        self.last_error = None

    def latest(self, since=None):
        self.last_error = None
        url = self.endpoint
        if since:
            sep = '&' if '?' in url else '?'
            url = url + sep + urllib.parse.urlencode({'v': since})
        try:
            req = urllib.request.Request(url, headers={
                'User-Agent': 'ChatView-Updater',
                'Authorization': 'Bearer %s' % self.app_key,
                'Accept': 'application/json',
            })
            with urllib.request.urlopen(req, timeout=self.timeout) as r:
                data = json.loads(r.read().decode('utf-8'))
        except Exception as e:
            self.last_error = str(e)
            return None
        if data.get('current'):
            return None  # authoritative: broker says we already hold the newest
        v, dl = data.get('version'), data.get('url')
        if not v or not dl:
            self.last_error = 'malformed broker reply'
            return None
        return UpdateInfo(v, dl, data.get('sha256'), data.get('sig'))


class ChainSource(UpdateSource):
    """Composite: ask each source in turn, first ANSWER wins — where an answer is either
    an UpdateInfo or an authoritative "nothing newer" (None with no last_error).

    Only a genuine failure falls through to the next source. That distinction is what
    stops a healthy broker's "you are current" from being second-guessed by a stale
    legacy manifest, while still letting a dead broker hand over cleanly.

    last_error is set whenever ANY source failed, even when a later one still produced an
    answer. The composite EXTENDS the base contract on purpose: for a chain, last_error
    means «this reply is not authoritative», not «there is no reply». Without that, a
    fallback answering with a version OLDER than the installed one silently laundered a
    dead primary into a clean check: Updater.check() drops such a candidate on the
    downgrade guard, check_and_stage then sees an empty answer with no error and says
    «у вас найновіша версія». Measured on the live channel 2026-09-04: broker
    DEPLOYMENT_NOT_FOUND plus legacy manifest 0.2.5 reported an installed 0.3.10 as
    "current". Same lie as a swallowed network error, different door (spec К3)."""

    def __init__(self, *sources):
        self.sources = [s for s in sources if s is not None]
        self.last_error = None

    def latest(self, since=None):
        self.last_error = None
        errors = []
        answer = None
        for src in self.sources:
            info = src.latest(since)
            if src.last_error:
                errors.append('%s: %s' % (type(src).__name__, src.last_error))
                if not info:
                    continue           # genuine failure -> hand over to the next source
            answer = info              # an UpdateInfo, or authoritative "nothing newer"
            break
        # Errors are kept even when `answer` is not None: the caller needs them the moment
        # that answer turns out to be unusable (too old to beat the downgrade baseline).
        self.last_error = ('; '.join(errors) or None) if self.sources \
            else 'no sources configured'
        return answer


def default_source():
    """The shipped chain: the legacy public manifest, plus the private broker IN FRONT of
    it whenever CHATVIEW_BROKER_URL names a deployment.

    WHY THERE IS NO BROKER HERE BY DEFAULT (do not "restore" it as an oversight).
    The broker is not an architectural mistake and nothing about it is deprecated:
    BrokerSource, ChainSource and the whole Strategy seam stay intact and are still
    covered end to end by desktop/test_broker_e2e.py against the real api/version.js. It
    is simply NOT DEPLOYED. Measured 2026-09-04: DEFAULT_BROKER_URL answers Vercel's
    DEPLOYMENT_NOT_FOUND (HTTP 404) to every request, and the private payload repo it
    would serve from does not exist either.

    A source that is guaranteed to fail is not a safety net, it is a permanent
    last_error. Since the К3 fix (55a99d23) a set last_error correctly forbids reporting
    a green «у вас найновіша версія» — so the undeployed broker made EVERY check answer
    error/unreachable, even when the public channel replied successfully and honestly
    that nothing newer exists. The newest version could not see the green answer at all
    (spec К4). We traded a silent lie for a permanent false alarm; both are equally
    useless to a human, and a check that cries wolf on every poll gets ignored.

    Bringing it back is one ENV VAR, no code change and no new .dmg: set
    CHATVIEW_BROKER_URL to the deployment (DEFAULT_BROKER_URL is the address it is meant
    to live at) and the chain is the original broker-first one again. Standing it up is
    the owner's separate job; see desktop/release-broker/README.md for the migration
    order it requires.
    """
    broker_url = os.environ.get('CHATVIEW_BROKER_URL')
    broker = BrokerSource(
        broker_url, os.environ.get('CHATVIEW_APP_KEY') or APP_GATE_KEY
    ) if broker_url else None
    # ChainSource drops a None source, so an unset env var simply means a one-source chain.
    return ChainSource(broker, GitHubReleaseSource(LEGACY_UPDATE_URL))


# ---- updater (Template Method) ---------------------------------------------

class Updater:
    def __init__(self, source: UpdateSource, home: str, current_version: str,
                 log=lambda *_: None, keys=None):
        self.source = source
        self.home = home
        self.current_version = current_version
        self.payload_dir = os.path.join(home, 'payload')
        self.log = log
        # Resolved ONCE at construction: the accepted signer set for this run.
        # `keys` are extra pins from the caller (the frozen launcher passes its own).
        self.keys = trusted_keys(keys)
        # Why the last update() gave up, verbatim. check_and_stage surfaces it instead of
        # the old catch-all «download or verify failed», which hid a refused signature
        # behind the same words as a dropped connection. `refused` is the machine-readable
        # half: True only when authenticity failed, i.e. retrying cannot possibly help.
        self.last_failure = None
        self.refused = False

    # -- individual steps (each independently testable) --

    def staged_version(self):
        """Version of the payload sitting in the home RIGHT NOW. Can be newer than the
        running one: a previous check may have staged an update that only applies on the
        next launch."""
        if os.path.isdir(self.payload_dir):
            return read_version(self.payload_dir)
        return '0.0.0'

    def baseline(self):
        """The version a candidate must strictly beat = the NEWER of what runs now and
        what is already staged on disk.

        Comparing against the RUNNING version alone caused two real bugs:
          * downgrade — a second, older instance (or an old app opened after a new one)
            saw the channel as "newer than me" and overwrote a NEWER staged payload with
            an older one. Observed in chatview.log: payload 0.2.1 clobbered by 0.1.19.
          * re-download loop — once checks run periodically, an already-staged version
            stays "newer than running" forever, so every poll re-downloaded it."""
        staged = self.staged_version()
        return staged if is_newer(staged, self.current_version) else self.current_version

    def check(self):
        """Return UpdateInfo if a strictly-newer payload is available, else None.

        The baseline is handed to the source as a hint (`since`) AND re-checked here:
        a source may ignore the hint, and a broker must never be trusted to gate our
        own downgrade protection."""
        base = self.baseline()
        info = self.source.latest(base)
        if info and is_newer(info.version, base):
            return info
        return None

    def _download(self, info):
        fd, tmp = tempfile.mkstemp(prefix='cv-payload-', suffix='.zip')
        os.close(fd)
        req = urllib.request.Request(info.url, headers={'User-Agent': 'ChatView-Updater'})
        with urllib.request.urlopen(req, timeout=60) as r, open(tmp, 'wb') as out:
            shutil.copyfileobj(r, out)
        return tmp

    @staticmethod
    def _sha256(path):
        h = hashlib.sha256()
        with open(path, 'rb') as fh:
            for block in iter(lambda: fh.read(65536), b''):
                h.update(block)
        return h.hexdigest()

    def _stage_and_swap(self, zip_path):
        """Extract into payload.new, then atomically replace payload/ with it.
        User DATA is never inside payload/, so it is untouched. Old payload kept as
        payload.bak until the swap succeeds (rollback safety)."""
        staging = self.payload_dir + '.new'
        backup = self.payload_dir + '.bak'
        shutil.rmtree(staging, ignore_errors=True)
        os.makedirs(staging, exist_ok=True)
        with zipfile.ZipFile(zip_path) as zf:
            # guard against zip-slip: reject entries that escape the staging dir
            for member in zf.namelist():
                dest = os.path.realpath(os.path.join(staging, member))
                if not dest.startswith(os.path.realpath(staging) + os.sep) \
                   and dest != os.path.realpath(staging):
                    raise ValueError('unsafe zip entry: %s' % member)
            zf.extractall(staging)
        # atomic-ish swap
        shutil.rmtree(backup, ignore_errors=True)
        if os.path.isdir(self.payload_dir):
            os.rename(self.payload_dir, backup)
        os.rename(staging, self.payload_dir)
        shutil.rmtree(backup, ignore_errors=True)

    # -- the algorithm (Template Method) --

    def update(self):
        """check -> AUTHENTICATE -> download -> verify bytes -> stage -> swap. Returns
        the new version string if a payload was installed, else None. Any failure rolls
        forward to None (the launcher keeps running the current payload).

        The signature is checked BEFORE a single byte is downloaded: an unsigned or
        foreign manifest is not worth a 40 MB transfer, and failing early keeps the
        refusal reason unambiguous."""
        info = self.check()
        if not info:
            return None
        self.last_failure = None
        self.refused = False
        try:
            key = verify_manifest(info.version, info.sha256, info.sig, self.keys)
        except VerifyError as e:
            self.refused = True
            # Loud on purpose. This branch means someone published something we cannot
            # attribute — either a release-process mistake or an actual attack, and both
            # deserve a line in chatview.log rather than a silent no-op.
            self.last_failure = 'REFUSED %s: %s' % (info.version, e)
            self.log('[update] %s\n' % self.last_failure)
            return None
        self.log('[update] newer payload %s available (signed by %s)\n'
                 % (info.version, key[:12]))
        tmp = None
        try:
            tmp = self._download(info)
            got = self._sha256(tmp)
            if got.lower() != info.sha256:
                # The signature covered this exact hash, so a mismatch is a corrupted or
                # substituted download, never a stale manifest.
                self.last_failure = ('downloaded bytes do not match the signed sha256 '
                                     '(%s != %s)' % (got[:12], info.sha256[:12]))
                self.log('[update] %s; aborting\n' % self.last_failure)
                return None
            self._stage_and_swap(tmp)
            self.log('[update] installed payload %s\n' % info.version)
            return info.version
        except Exception as e:
            self.last_failure = str(e)
            self.log('[update] failed: %s\n' % e)
            return None
        finally:
            if tmp and os.path.exists(tmp):
                try:
                    os.remove(tmp)
                except OSError:
                    pass


# ---- one shared entry point for every caller --------------------------------

def check_and_stage(home, running_version, url=None, log=lambda *_: None,
                    pinned_keys=None):
    """Poll the channel and, if it offers something newer, download+verify+stage it.

    The SINGLE flow behind all three callers — the launch-time background check
    (entry.py), the periodic in-session check and the manual "Перевірити оновлення"
    button (both server.py). They used to each hand-roll the Updater wiring, which is
    how the manual path ended up with no logging and a subtly different notion of
    "current". Returns a dict the HTTP endpoint can serialise as-is:

        {'status': 'current' | 'staged' | 'error',
         'running': <version running now>,
         'staged':  <version now on disk, only when status == 'staged'>,
         'error':   <human reason, only when status == 'error'>,
         'reason':  'unreachable' | 'refused' | 'download', only when status == 'error'}

    `reason` exists because the UI must not answer a REFUSED signature with «спробуйте ще
    раз»: retrying is exactly what will not help, and a manifest we cannot attribute is
    worth saying out loud. Machine-readable so the frontend never string-matches Ukrainian
    (or English) prose.

    'error' covers an unreachable channel, a failed download AND a refused signature; the
    'error' string names which. It never raises, so a caller can fire it blind on a timer.

    `pinned_keys` are extra Ed25519 public keys the CALLER vouches for — the frozen
    launcher passes the ones compiled into the binary, so a payload can never shrink the
    accepted signer set below what the installer shipped. Named `pinned_keys`, not
    `trusted_keys`, so it cannot shadow the module-level trusted_keys() helper inside this
    function: that exact shadowing pattern already cost this codebase one live bug.
    """
    running = running_version or '0.0.0'
    # A caller that names a SPECIFIC manifest (tests, dev, staging) gets exactly that and
    # nothing else. But entry.py lives in the frozen shell and always passes the legacy
    # default it was compiled with, so treat that one value as "no preference" and give it
    # the chain — otherwise the launch-time check would keep polling the frozen public
    # channel until the user installs a new .dmg, which is the trap this whole design
    # exists to avoid.
    pinned = url or os.environ.get('CHATVIEW_UPDATE_URL')
    if pinned and pinned != LEGACY_UPDATE_URL:
        src = GitHubReleaseSource(pinned)
    else:
        src = default_source()
    up = Updater(src, home, running, log, keys=pinned_keys)
    info = up.check()
    if not info:
        # Already holding something newer (staged on disk) -> report it so the UI can
        # still offer "Перезапустити зараз" for a pending update. Answered BEFORE the
        # failure branch: a staged payload is a fact on disk, and an unreachable channel
        # does not make it any less applicable. Taking the restart button away because
        # today's poll failed is a strictly worse answer than naming the pending version.
        staged = up.staged_version()
        if is_newer(staged, running):
            return {'status': 'staged', 'running': running, 'staged': staged}
        # A fetch/parse failure must NOT look identical to "genuinely up to date", else
        # the UI shows a green "найновіша версія" on a silent network error. `not info`
        # covers two shapes of the same non-answer: nobody replied at all, AND somebody
        # replied with a version older than our baseline (a frozen fallback behind a dead
        # primary). Either way nothing newer was learned while a source is down, so the
        # honest status is "не вдалося перевірити" (spec К3). When every source answered
        # cleanly, last_error stays None and the green "current" survives (spec К4).
        if src.last_error:
            return {'status': 'error', 'running': running, 'reason': 'unreachable',
                    'error': 'unreachable: %s' % src.last_error}
        return {'status': 'current', 'running': running}
    newv = up.update()
    if newv:
        return {'status': 'staged', 'running': running, 'staged': newv}
    return {'status': 'error', 'running': running,
            'reason': 'refused' if up.refused else 'download',
            'error': up.last_failure or 'download or verify failed'}


# ---- payload selection (used by the launcher) ------------------------------

def seed_payload_from_bundle(bundle_dir, home, log=lambda *_: None):
    """Populate home/payload from the frozen bundle when it is missing or the
    bundle is newer (i.e. the user installed a fresh .app). This is the baseline
    the online updater then upgrades. Never overwrites a home payload that is
    already newer than the bundle."""
    payload = os.path.join(home, 'payload')
    bundle_v = read_version(bundle_dir)
    home_v = read_version(payload) if os.path.isdir(payload) else '0.0.0'
    # Keep the home payload ONLY if it is STRICTLY newer than the bundle — i.e. the
    # online updater installed a newer version. Otherwise (bundle newer OR SAME
    # version) re-seed from the bundle. Same-version re-seed matters: reinstalling /
    # relaunching a rebuilt .app of the same version must refresh the code, else the
    # launcher keeps running a stale payload from an earlier build (observed bug).
    if os.path.isdir(payload) and is_newer(home_v, bundle_v):
        return payload  # online-updated payload is newer -> keep it
    os.makedirs(payload, exist_ok=True)
    for name in PAYLOAD_FILES:
        src = os.path.join(bundle_dir, name)
        if os.path.exists(src):
            try:
                shutil.copy2(src, os.path.join(payload, name))
            except Exception as e:
                log('[update] seed %s failed: %s\n' % (name, e))
    for name in PAYLOAD_DIRS:
        src = os.path.join(bundle_dir, name)
        if os.path.isdir(src):
            try:
                shutil.copytree(src, os.path.join(payload, name), dirs_exist_ok=True)
            except Exception as e:
                log('[update] seed dir %s failed: %s\n' % (name, e))
    log('[update] seeded payload %s from bundle\n' % bundle_v)
    return payload


def choose_code_dir(bundle_dir, home, log=lambda *_: None):
    """Return the dir the launcher should run server.py/runner.py from: the home
    payload (updatable) if it is valid and >= the bundle, else the bundle itself
    (safe fallback). Seeds the home payload from the bundle first."""
    payload = seed_payload_from_bundle(bundle_dir, home, log)
    if os.path.exists(os.path.join(payload, 'server.py')) \
       and not is_newer(read_version(bundle_dir), read_version(payload)):
        return payload
    return bundle_dir
