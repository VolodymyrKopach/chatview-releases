#!/usr/bin/env python3
"""summary_store.py — сховище САММАРІ КАНАЛУ: channels/<id>/summary.json.

ЧИМ ЦЕ ВІДРІЗНЯЄТЬСЯ ВІД worksheet_store (specs/chat-summary)
------------------------------------------------------------
Аркуш зростає ПОБЛОЧНО: агент кладе етап 5, потім етап 15, і колізія завжди локальна.
Тому там працює головний закон «операції перезапису всього документа НЕ ІСНУЄ».

Саммарі приїжджає ЦІЛИМ ЗНІМКОМ і перегенеровується цілком, тобто той закон тут зламаний
за означенням. Його не викидають, його ПЕРЕФОРМУЛЬОВУЮТЬ:

    На аркуші:  немає операції, яка замінює всі блоки.
    У саммарі:  немає операції, яка пише і в `generation`, і в `overlay`.

Два писарі, два неперетинні піддерева. Машина володіє `generation` і перезаписує його як
завгодно. Людина володіє `overlay`, і це не текст, а СПИСОК ПАТЧІВ. Класичний lost update
стає неможливим КОНСТРУКТИВНО, а не завдяки дисципліні агента.

ОДИНИЦЯ АДРЕСАЦІЇ ЦЕ ПУНКТ (`item`), не секція і не окремий віджет.
Секція завелика: одна правка заморозила б пʼять сусідніх пунктів. Віджет замалий і
нестабільний: перегенерація легко міняє `conclusion` на `verdict`, і адреса вмирає рівно
тоді, коли вона потрібна. Пункт це те, чия смислова тотожність переживає переписування.

ТРИ КЛЮЧІ ПРАЦЮЮТЬ РАЗОМ, і жоден з них не зайвий:
  * `key`        смисловий якір, переживає перефразування і перестановку;
  * `baseHash`   знімок змісту на момент правки, ловить «машина переписала це під нами»;
  * `widgetType` рятує від СЛІПОГО запису, коли тип віджета змінився між версіями.

КОМПОЗИЦІЯ ВІДБУВАЄТЬСЯ НА ЧИТАННІ, А НЕ В ФАЙЛІ. `compose()` накладає overlay на
generation щоразу заново. Зберігати склеєний результат означало б завести третю копію
правди, яка тихо розходиться з обома шарами.
"""
import copy
import hashlib
import json
import os
import re
import sys
import time

# Той самий рядок, що в plan_store і worksheet_store: десктоп ставить CHATVIEW_HOME,
# дев крутиться з теки репозиторію. Читаємо ліниво, щоб тест міг підмінити.
def base_dir():
    return os.environ.get('CHATVIEW_HOME') or os.path.dirname(os.path.abspath(__file__))


def channels_dir():
    return os.path.join(base_dir(), 'channels')


def _channel_message_count(channel, root=None):
    """Кількість карток каналу (К19: `total` для freshness). Той самий фільтр, яким
    рахує сам чат картки в теці каналу (server.py, runner.py, backfill_icons.py):
    `\\d+\\.json` у корені `channels/<id>/`, без службових файлів на кшталт summary.json."""
    ch_dir = os.path.join(root or channels_dir(), channel)
    try:
        names = os.listdir(ch_dir)
    except OSError:
        return 0
    return sum(1 for n in names if re.match(r'\d+\.json$', n))


FILENAME = 'summary.json'

#: Максимальна глибина дерева. Заміряно на шести саммарі Vova (агент D): реально потрібні
#: ДВА рівні, жоден файл не просить довільної. Ріжемо на трьох, щоб лишити запас на один
#: непередбачений випадок і не пустити модель у шестирівневе місиво.
MAX_DEPTH = 3
#: Капи. Файл лежить на гарячому шляху поллінга, і саме на цьому вже обпікались з
#: index.json: 80 КБ на канал перетворювали кожен полл на дискову операцію.
MAX_ITEMS_PER_SECTION = 40
MAX_SECTIONS = 20
MAX_PATCHES = 200
MAX_ORPHANS = 50
HISTORY_MAX = 5

#: ЗАКРИТИЙ СЛОВНИК. Дефолт це заборона: невідомий тип відхиляється НА ЗАПИСІ, а не
#: малюється UnknownWidget усередині артефакту, якому людина довіряє (К3).
#: Контейнери тримають дітей, листки тримають слоти.
CONTAINERS = {
    'sheet',     # корінь документа
    'section',   # смуга з заголовком
    'columns',   # 2-4 колонки поруч
    'grid',      # сітка з іменованими клітинками і спанами (лін канва)
    'card',      # картка-обгортка
}
LEAVES = {
    'doc-header',   # назва, статус, дата, джерело
    'note',         # абзац з тоном
    'kpi-strip',    # 2-6 великих чисел
    'fact-list',    # пари мітка/значення
    'checklist',    # зроблено / лишилось
    'table',        # рядки x колонки
    'quote',        # дослівні слова людини
    'cell',         # клітинка сітки: номер, назва, вміст, спан
    'media',        # К27: картинка, відео чи аудіо з підписом (9.6% живого змісту)
    'axis',         # К28: відрізки на спільній осі, координати з даних
    'avatar-card',  # розділ 7.3: персона — круглий аватар, імʼя, роль, цитата
    'vpc',          # розділ 7.3: Value Proposition Canvas (Strategyzer), 6 зон закритої ролі
    'journey',      # розділ 7.3: Customer Journey Map з емоційною кривою, координата
                    # рахується з `value` (К28-дух), етапи/крапки/барʼєри одним items[]
}
KNOWN_TYPES = CONTAINERS | LEAVES

#: Закритий словник ролей зони `vpc` (specs/chat-summary, 7.3). Роль це РУШІЙ геометрії
#: (chatview/src/summary/nodes.tsx: VPC_ZONE_GEOMETRY, лукап роль -> форма/позиція/тон):
#: позицію задає САМЕ це поле, а не порядок масиву чи ручний CSS. Ліва (квадрат) половина
#: це продукт (products/gainCreators/painRelievers), права (коло) це клієнт
#: (jobs/gains/pains) — канонічна геометрія Strategyzer.
VPC_ROLES = {'products', 'gainCreators', 'painRelievers', 'jobs', 'gains', 'pains'}

#: Кап окремий від MAX_ITEMS_PER_SECTION: секція може нести 40 пунктів, але ОДИН
#: journey-віджет з 40 етапами вздовж однієї осі часу нечитний фізично (класичний CJM
#: це 4-7 етапів). Обмежуємо ЗМІСТОВНО вузол, а не лише пункт секції зверху.
MAX_JOURNEY_STAGES = 8

#: К31 (specs/chat-summary, 7.5). Тема документа лягає в генерацію як ЗВИЧАЙНИЙ пункт
#: (`hdr`, тип `doc-header`), не як окреме поле поза сховищем: інакше правка теми (К33)
#: потребувала б другого механізму адресації, який розійдеться з першим. `summary_generate.py`
#: заводить для неї ОКРЕМУ секцію з цим фіксованим ключем, а не кладе першим пунктом першої
#: секції моделі: перша секція належить моделі, і її ключ та вміст вільно міняються між
#: генераціями (модель може перейменувати чи прибрати секцію), тоді як адреса теми мусить
#: лишатись стабільною незалежно від того, що модель робить зі змістом. Секція і пункт нічим
#: не відрізняються від будь-яких інших для валідатора, хешу і композиції (перевірено тестами
#: у test_summary_store.py), спеціального коду для них тут нема.
HEADER_SECTION_KEY = 'sec.hdr'
HEADER_ITEM_KEY = 'hdr'


class SummaryError(ValueError):
    """Погана структура або погана операція. Текст адресований ВИКЛИКАЧУ і мусить
    називати вузол і причину: розпливчаста помилка тут означає, що модель повторить
    той самий кривий виклик."""


def _now():
    return time.strftime('%Y-%m-%d %H:%M')


def _write_json_atomic(path, obj):
    tmp = path + '.tmp'
    with open(tmp, 'w', encoding='utf-8') as f:
        json.dump(obj, f, ensure_ascii=False, indent=2)
    os.replace(tmp, path)


def item_hash(item):
    """Стабільний хеш ЗМІСТУ пункту. Саме він ловить «машина переписала це під нами».

    Рахується з віджетів і заголовка, і НЕ включає `key`: перейменування ключа це інша
    подія (втрата якоря), і плутати її зі зміною змісту не можна."""
    payload = json.dumps(
        {'title': item.get('title'), 'widgets': item.get('widgets', [])},
        ensure_ascii=False, sort_keys=True, separators=(',', ':'))
    return hashlib.sha1(payload.encode('utf-8')).hexdigest()[:6]


# ── Валідатор: пишеться ДО генератора, бо саме він тримає систему ────────────
# Агент D: у ProseMirror схема ловить ПРАВКИ, але не ловить СТВОРЕННЯ (NodeType.create
# збирає ноду з невалідним вмістом). Тому власна перевірка на шляху запису обовʼязкова,
# інакше система за кілька тижнів тихо сповзе назад у вільний HTML.

#: `name`/`role` додані для `avatar-card` (розділ 7.3): це той самий "зміст для читання",
#: що title/body деінде, тільки з іншою назвою поля, бо `title`/`label` тут уже позначені
#: іншим сенсом у сусідніх вузлах. Цитата персони навмисно лежить у ВЖЕ наявному `text`
#: (тому самому полі, що в `quote`), а не в третьому новому ключі.
_SLOT_KEYS = ('title', 'body', 'text', 'label', 'value', 'caption', 'note', 'name', 'role')


def _check_slot(node_type, key, val):
    """Слот це рядок АБО масив рядків (К4).

    Масив тут не забаганка: у комірках шести саммарі заміряно 46 жирних вставок і 57
    пунктів списку. Слот у вигляді голого рядка дав би результат гірший, ніж те, що
    Vova вже має, тобто фіча провалилась би на першому ж показі."""
    if isinstance(val, str):
        return
    if isinstance(val, list) and all(isinstance(x, str) for x in val):
        return
    raise SummaryError(
        'вузол "%s", слот "%s": очікується рядок або масив рядків, прийшло %s'
        % (node_type, key, type(val).__name__))


def _check_vpc_zones(node, path):
    """Deep-check для `items[]` вузла `vpc` (розділ 7.3). Це НЕ той самий вид «геометрія з
    даних», що в `axis` (К28): там координата рахується з БЕЗПЕРЕРВНОГО числа, тут — з
    ДИСКРЕТНОГО поля-ролі через закритий словник `VPC_ROLES`. Саме тому перевірка сувора:
    невідома чи повторена роль мовчки телепортувала б зону в інше місце/форму на екрані,
    а generic `_SLOT_KEYS`-цикл цього не ловить, бо `items` вузла `vpc` це масив ЗОН
    (обʼєктів), а не слот-рядків.

    Пункти зони лежать у полі `points`, НЕ `items`: знайдено на живому скріні
    (work/vpc-proof/vpc-light.png) — фронтовий `SummaryDocView.stampAddr` рекурсивно
    стемпить адресу в КОЖЕН масив на ключі `items`, і якби зона теж мала `items[]` рядків,
    кожен рядок-буллет підмінявся б на обʼєкт (spread рядка по символьних індексах),
    показуючи `[object Object]` замість тексту. `points` жодним генеричним циклом ні
    тут, ні в summary_export._embed_media_in_node не зачіпається."""
    zones = node.get('items')
    if zones is None:
        return
    if not isinstance(zones, list):
        raise SummaryError('вузол "vpc" на шляху %s: items мусить бути масивом зон' % path)
    seen_roles = set()
    for i, zone in enumerate(zones):
        zpath = '%s > vpc.items[%d]' % (path, i)
        if not isinstance(zone, dict):
            raise SummaryError('%s не є обʼєктом' % zpath)
        role = zone.get('role')
        if role not in VPC_ROLES:
            raise SummaryError(
                '%s: невідома роль "%s". Дозволені: %s'
                % (zpath, role, ', '.join(sorted(VPC_ROLES))))
        if role in seen_roles:
            raise SummaryError('%s: роль "%s" уже зайнята іншою зоною цього vpc' % (zpath, role))
        seen_roles.add(role)
        if 'title' in zone and zone['title'] is not None:
            _check_slot('vpc', 'items[].title', zone['title'])
        if 'points' in zone and zone['points'] is not None:
            _check_slot('vpc', 'items[].points', zone['points'])
        if 'icon' in zone and zone['icon'] is not None and not isinstance(zone['icon'], str):
            raise SummaryError('%s: icon мусить бути рядком' % zpath)


def _check_journey_items(node, path):
    """Deep-check для `items[]` вузла `journey` (розділ 7.3). Головне правило задачі:
    емоція це ЧИСЛО в даних, а координата (і навіть емодзі-крапка на кривій) виводиться з
    нього рендерером, а не приходить окремим полем — саме тому тут ОБОВʼЯЗКОВЕ `value` і
    НЕМА `emoji` в схемі взагалі (той самий клас ризику, що description до задачі назвав
    ризиком №1: окремий emoji-токен нічим не гарантовано узгоджений із власним value).

    Етапи, крапки кривої й барʼєри/рішення свідомо ОДИН масив `items[]`, а не три
    паралельні структури: три незалежні масиви модель могла б згенерувати різної довжини
    (off-by-one), один масив унеможливлює розсинхрон конструктивно."""
    stages = node.get('items')
    if not isinstance(stages, list) or not stages:
        raise SummaryError(
            'вузол "journey" на шляху %s: items мусить бути непорожнім масивом етапів' % path)
    if len(stages) > MAX_JOURNEY_STAGES:
        raise SummaryError(
            'вузол "journey" на шляху %s: етапів %d, стеля %d'
            % (path, len(stages), MAX_JOURNEY_STAGES))
    mn, mx = node.get('min'), node.get('max')
    for bound_name, bound in (('min', mn), ('max', mx)):
        if bound is not None and (isinstance(bound, bool) or not isinstance(bound, (int, float))):
            raise SummaryError('вузол "journey" на шляху %s: "%s" мусить бути числом' % (path, bound_name))
    if mn is not None and mx is not None and not mn < mx:
        raise SummaryError('вузол "journey" на шляху %s: "min" мусить бути менше "max"' % path)
    for i, stage in enumerate(stages):
        spath = '%s > journey.items[%d]' % (path, i)
        if not isinstance(stage, dict):
            raise SummaryError('%s не є обʼєктом' % spath)
        val = stage.get('value')
        if isinstance(val, bool) or not isinstance(val, (int, float)):
            raise SummaryError(
                '%s: "value" мусить бути числом — воно рушій Y-координати кривої' % spath)
        if not stage.get('label'):
            raise SummaryError('%s: бракує "label"' % spath)
        for k in ('label', 'action', 'barrier', 'solution'):
            if k in stage and stage[k] is not None:
                _check_slot('journey', 'items[].%s' % k, stage[k])
        if 'emoji' in stage:
            raise SummaryError(
                '%s: "emoji" не є полем схеми — крапка на кривій виводиться з "value" '
                'рендерером, окреме поле дало б емодзі, що суперечить числу поруч' % spath)


def validate_node(node, depth=1, path='sheet'):
    """Рекурсивна перевірка одного вузла. Кидає SummaryError з ІМЕНЕМ вузла і глибиною."""
    if not isinstance(node, dict):
        raise SummaryError('вузол на шляху %s не є обʼєктом' % path)
    t = node.get('type')
    if t not in KNOWN_TYPES:
        raise SummaryError(
            'невідомий тип вузла "%s" на шляху %s. Дозволені: %s'
            % (t, path, ', '.join(sorted(KNOWN_TYPES))))
    if depth > MAX_DEPTH:
        raise SummaryError(
            'вузол "%s" на шляху %s лежить на глибині %d, стеля %d'
            % (t, path, depth, MAX_DEPTH))

    for k in _SLOT_KEYS:
        if k in node and node[k] is not None:
            _check_slot(t, k, node[k])
    if t == 'vpc':
        _check_vpc_zones(node, path)
    if t == 'journey':
        _check_journey_items(node, path)

    kids = node.get('children')
    if kids is not None:
        if t not in CONTAINERS:
            raise SummaryError(
                'вузол "%s" на шляху %s це листок і дітей мати не може' % (t, path))
        if not isinstance(kids, list):
            raise SummaryError('children вузла "%s" мусить бути масивом' % t)
        for i, kid in enumerate(kids):
            validate_node(kid, depth + 1, '%s > %s[%d]' % (path, t, i))
    return True


def validate_generation(gen):
    """Перевірка цілого шару машини перед записом."""
    if not isinstance(gen, dict):
        raise SummaryError('generation мусить бути обʼєктом')
    secs = gen.get('sections')
    if not isinstance(secs, list) or not secs:
        raise SummaryError('generation.sections мусить бути непорожнім масивом')
    if len(secs) > MAX_SECTIONS:
        raise SummaryError('секцій %d, стеля %d' % (len(secs), MAX_SECTIONS))
    seen = set()
    for s in secs:
        if not isinstance(s, dict) or not s.get('key'):
            raise SummaryError('у кожної секції мусить бути key')
        if s['key'] in seen:
            raise SummaryError('ключ секції "%s" не унікальний' % s['key'])
        seen.add(s['key'])
        items = s.get('items') or []
        if len(items) > MAX_ITEMS_PER_SECTION:
            raise SummaryError(
                'секція "%s": пунктів %d, стеля %d'
                % (s['key'], len(items), MAX_ITEMS_PER_SECTION))
        for it in items:
            if not isinstance(it, dict) or not it.get('key'):
                raise SummaryError('у кожного пункту мусить бути key (секція %s)' % s['key'])
            if it['key'] in seen:
                raise SummaryError('ключ пункту "%s" не унікальний' % it['key'])
            seen.add(it['key'])
            for n in (it.get('widgets') or []):
                validate_node(n, 1, 'item %s' % it['key'])
    return True


# ── Що взагалі можна правити руками ──────────────────────────────────────────
# Правило з дослідження, дослівно: правити можна те, що людина ЧИТАЄ; не можна те, за що
# документ ВІДПОВІДАЄ. Ключі, числа і посилання це відповідальність, решта це читання.
EDITABLE_FIELDS = {
    'note': ('title', 'body'),
    'doc-header': ('title', 'subtitle'),
    'quote': ('text', 'author'),
    'cell': ('title', 'body'),
    'kpi-strip': ('label',),      # підпис так, ЧИСЛО ні: за число відповідає документ
    'fact-list': ('label',),      # мітка так, значення ні, з тієї ж причини
    'checklist': ('text',),
    'table': (),                  # комірки не правляться: це витягнутий факт
    'media': ('caption',),        # підпис так, `src` ні: за адресу файлу відповідає
                                  # нормалізатор (К27), і рука тут ламає саме те, що він
                                  # полагодив. `kind` теж ні: це не текст, а тип носія.
    'axis': (),                   # нічого: у вузла лишились самі координати і мітки
                                  # серій, а координата це відповідальність документа
                                  # (К28), не зміст для читання.
    'avatar-card': ('name', 'role', 'text'),  # розділ 7.3: імʼя, роль, цитата це зміст,
                                  # який Vova читає. `avatar`/`src` ні: емодзі і адреса
                                  # файлу це ідентичність персони, той самий клас поля, що
                                  # `kind`/`n`/`span` деінде — документ вирішує, чим саме
                                  # персона позначена, а не рука. `src` додатково дзеркалить
                                  # заборону `media.src` (К27): за адресу файлу відповідає
                                  # нормалізатор, рука тут ламала б рівно те, що він лагодить.
    'vpc': ('title', 'points'),   # розділ 7.3: заголовок зони і пункти списку це зміст,
                                  # який Vova читає (К12). `role`/`icon` ні: роль це РУШІЙ
                                  # геометрії (VPC_ZONE_GEOMETRY), зміна ролі мовчки
                                  # телепортувала б зону в інше місце/форму; icon той самий
                                  # клас поля, що й деінде в словнику (cell.icon теж не
                                  # редагується). Поле зветься `points`, не `items`: див.
                                  # коментар над _check_vpc_zones (stampAddr-колізія).
    'journey': ('label', 'action', 'barrier', 'solution'),  # розділ 7.3: назви етапів і
                                  # підписи це наратив, який Vova читає (К12). `value` ні:
                                  # рушій Y-координати кривої, за неї відповідає документ.
                                  # `emoji` не поле схеми взагалі (виводиться з `value`),
                                  # тому й правити нічого — немає що адресувати.
}


def editable_fields(widget_type):
    """Дозволені поля типу. Невідомий тип віддає порожньо: дефолт це заборона."""
    return EDITABLE_FIELDS.get(widget_type, ())


def empty_doc(channel=''):
    return {
        'schema': 1, 'channel': channel, 'rev': 0, 'updated': '',
        'generation': {'genRev': 0, 'mode': 'none', 'source': {}, 'sections': []},
        'overlay': {'rev': 0, 'patches': [], 'orphans': []},
        'history': [],
    }


def path_for(channel, root=None):
    if not channel or '/' in channel or '\\' in channel or '..' in channel:
        raise SummaryError('bad channel')
    return os.path.join(root or channels_dir(), channel, FILENAME)


def read_doc(channel, root=None):
    """Сирий документ з обох шарів. Не кидає на відсутньому чи битому файлі: зламане
    саммарі не має класти чат."""
    try:
        with open(path_for(channel, root), encoding='utf-8') as f:
            doc = json.load(f)
    except SummaryError:
        raise
    except Exception:
        return empty_doc(channel)
    if not isinstance(doc, dict):
        return empty_doc(channel)
    base = empty_doc(channel)
    base.update(doc)
    for k in ('generation', 'overlay'):
        if not isinstance(base.get(k), dict):
            base[k] = empty_doc(channel)[k]
    base['overlay'].setdefault('patches', [])
    base['overlay'].setdefault('orphans', [])
    base['generation'].setdefault('sections', [])
    return base


def _save(channel, doc, root=None):
    doc['rev'] = int(doc.get('rev') or 0) + 1
    doc['updated'] = _now()
    p = path_for(channel, root)
    os.makedirs(os.path.dirname(p), exist_ok=True)
    _write_json_atomic(p, doc)
    return doc


# ── Шар машини ───────────────────────────────────────────────────────────────

def write_generation(channel, sections, source=None, mode='full', model=None,
                      counted=None, root=None):
    """Замінити шар машини ЦІЛКОМ. Патчів людини НЕ торкається (К6).

    Після запису перевіряються всі патчі: ті, чия ціль зникла або змінила тип, їдуть у
    `orphans` разом із текстом людини. Викидати їх не можна: це єдиний слід її роботи.

    `counted` (К19) це скільки карток каналу врахувала ця генерація. Необовʼязковий:
    поки генератор його не передає, свіжість лишається невідомою, а не вигаданим нулем."""
    gen = {
        'genRev': int((read_doc(channel, root)['generation'].get('genRev') or 0)) + 1,
        'mode': mode, 'model': model, 'at': _now(), 'counted': counted,
        'source': source or {}, 'sections': sections,
    }
    validate_generation(gen)
    # Хеш кожного пункту рахуємо ТУТ, один раз: далі на нього спирається вся адресація.
    for s in gen['sections']:
        for it in (s.get('items') or []):
            it['hash'] = item_hash(it)

    doc = read_doc(channel, root)
    old = doc['generation']
    doc['generation'] = gen
    doc['history'] = ([{'genRev': old.get('genRev'), 'at': old.get('at'),
                        'sections': old.get('sections', [])}] + doc.get('history', [])
                      )[:HISTORY_MAX] if old.get('sections') else doc.get('history', [])
    _reap_orphans(doc)
    _save(channel, doc, root)
    return gen


def _index_items(gen):
    out = {}
    for s in gen.get('sections', []):
        for it in (s.get('items') or []):
            out[str(it.get('key'))] = it
    return out


def _reap_orphans(doc):
    """Патчі, чия ціль зникла або змінила тип віджета, стають сиротами (К9, К11).

    Сирота це НЕ помилка і не сміття: це збережений текст людини плюс те, до чого він
    був прикладений. Саме з цього вона потім вирішує, куди його подіти."""
    items = _index_items(doc['generation'])
    live, orphans = [], list(doc['overlay'].get('orphans', []))
    for p in doc['overlay'].get('patches', []):
        tgt = p.get('target') or {}
        key = tgt.get('item') or tgt.get('section')
        if tgt.get('section') and not tgt.get('item'):
            # патч на секцію (порядок, вставка): жива, поки жива секція
            if any(s.get('key') == key for s in doc['generation'].get('sections', [])):
                live.append(p)
            else:
                orphans.append({**p, 'lostAt': _now(), 'why': 'секція зникла'})
            continue
        it = items.get(str(key))
        if it is None:
            orphans.append({**p, 'lostAt': _now(), 'why': 'пункт зник з генерації'})
            continue
        wt = tgt.get('widgetType')
        wi = tgt.get('widget')
        if wt is not None and wi is not None:
            ws = it.get('widgets') or []
            actual = ws[wi].get('type') if 0 <= wi < len(ws) else None
            if actual != wt:
                orphans.append({**p, 'lostAt': _now(),
                                'why': 'тип віджета змінився: був %s, став %s' % (wt, actual)})
                continue
        live.append(p)
    doc['overlay']['patches'] = live[:MAX_PATCHES]
    doc['overlay']['orphans'] = orphans[:MAX_ORPHANS]


# ── Шар людини ───────────────────────────────────────────────────────────────

PATCH_OPS = ('set', 'hide', 'order', 'insert', 'freeze')


def add_patch(channel, patch, root=None):
    """Додати правку людини. Пише ТІЛЬКИ в overlay (К5)."""
    op = (patch or {}).get('op')
    if op not in PATCH_OPS:
        raise SummaryError('невідома операція "%s". Відомі: %s' % (op, ', '.join(PATCH_OPS)))
    tgt = patch.get('target') or {}
    doc = read_doc(channel, root)
    items = _index_items(doc['generation'])

    if op == 'set':
        key = str(tgt.get('item') or '')
        it = items.get(key)
        if it is None:
            raise SummaryError('немає пункту "%s" у генерації' % key)
        wi, field = tgt.get('widget'), tgt.get('field')
        ws = it.get('widgets') or []
        if not isinstance(wi, int) or not 0 <= wi < len(ws):
            raise SummaryError('віджет %r поза межами пункту "%s"' % (wi, key))
        wtype = ws[wi].get('type')
        allowed = editable_fields(wtype)
        if field not in allowed:
            raise SummaryError(
                'поле "%s" у "%s" правити не можна. Дозволені: %s. '
                'За числа, ключі й посилання відповідає документ, а не людина'
                % (field, wtype, ', '.join(allowed) or 'жодних'))
        patch = {**patch, 'target': {**tgt, 'widgetType': wtype},
                 'baseHash': it.get('hash')}

    patch = {**patch, 'id': patch.get('id') or 'p%d' % (len(doc['overlay']['patches']) + 1),
             'by': patch.get('by') or 'human', 'at': _now()}
    doc['overlay']['patches'] = (doc['overlay']['patches'] + [patch])[:MAX_PATCHES]
    doc['overlay']['rev'] = int(doc['overlay'].get('rev') or 0) + 1
    _save(channel, doc, root)
    return patch


def drop_patch(channel, patch_id, root=None):
    """Скасувати правку. Рядок менше в overlay, і пункт САМ повертається під керування
    машини (К10). У злитому документі це коштувало б ще однієї правки назавжди."""
    doc = read_doc(channel, root)
    before = len(doc['overlay']['patches'])
    doc['overlay']['patches'] = [p for p in doc['overlay']['patches'] if p.get('id') != patch_id]
    if len(doc['overlay']['patches']) == before:
        raise SummaryError('немає патча "%s"' % patch_id)
    doc['overlay']['rev'] = int(doc['overlay'].get('rev') or 0) + 1
    _save(channel, doc, root)
    return True


RESOLVE_MODES = ('keep-human', 'take-machine')


def resolve_conflict(channel, patch_id, mode, root=None):
    """К24. Конфлікт (К8) не вирішується автоматично, але руками мусить бути ЩО
    зробити з ним, а не лише unpatch («здатись машині»). Обидва режими йдуть через
    ОДНУ ручку, щоб UI мав один словник дій:

      * keep-human    baseHash патча перебазовується на поточний hash пункту, патч
                       знову застосовується на читанні (compose), конфлікт зникає;
      * take-machine   те саме, що unpatch, але тим самим словником.

    ПИШЕ ТІЛЬКИ в overlay: перебазування чіпає баланс патча, не сам зміст generation."""
    if mode not in RESOLVE_MODES:
        raise SummaryError(
            'невідомий режим "%s". Відомі: %s' % (mode, ', '.join(RESOLVE_MODES)))
    doc = read_doc(channel, root)
    patches = doc['overlay'].get('patches', [])
    p = next((x for x in patches if x.get('id') == patch_id), None)
    if p is None:
        raise SummaryError('немає патча "%s"' % patch_id)

    items = _index_items(doc['generation'])
    it = items.get(str((p.get('target') or {}).get('item')))
    in_conflict = (p.get('op') == 'set' and it is not None and p.get('baseHash')
                   and it.get('hash') != p.get('baseHash'))
    if not in_conflict:
        raise SummaryError('патч "%s" не в конфлікті: вирішувати нічого' % patch_id)

    if mode == 'take-machine':
        drop_patch(channel, patch_id, root=root)
        return {'resolved': patch_id, 'mode': mode}

    for x in patches:
        if x.get('id') == patch_id:
            x['baseHash'] = it.get('hash')
    doc['overlay']['rev'] = int(doc['overlay'].get('rev') or 0) + 1
    _save(channel, doc, root)
    return {'resolved': patch_id, 'mode': mode}


def restore_orphan(channel, orphan_id, section_key, root=None):
    """К25. Сирота (К9) це збережений текст людини, не сміття: `restore` повертає
    його в документ як людський пункт (`op: insert`, `by: human`) вказаної секції.

    Секція, якої нема, називається по КЛЮЧУ в помилці: мовчазна втрата тексту людини
    тут заборонена так само, як і скрізь в overlay."""
    doc = read_doc(channel, root)
    orphans = doc['overlay'].get('orphans', [])
    o = next((x for x in orphans if x.get('id') == orphan_id), None)
    if o is None:
        raise SummaryError('немає сироти "%s"' % orphan_id)
    secs = doc['generation'].get('sections', [])
    if not any(s.get('key') == section_key for s in secs):
        raise SummaryError(
            'секції "%s" нема в поточній генерації, текст людини НЕ втрачено, '
            'сирота лишається на місці' % section_key)

    orig_op = o.get('op')
    tgt = o.get('target') or {}
    if orig_op == 'insert':
        item_value = dict(o.get('value') or {})
    elif orig_op == 'set':
        key = tgt.get('item') or ('restored.%s' % orphan_id)
        wtype = tgt.get('widgetType') or 'note'
        field = tgt.get('field') or 'body'
        item_value = {'key': key, 'widgets': [{'type': wtype, field: o.get('value')}]}
    else:
        raise SummaryError(
            'сироту з операції "%s" повернути не можна: у ній нема тексту людини для '
            'вставки в документ' % orig_op)

    patch = add_patch(channel, {
        'op': 'insert', 'target': {'section': section_key}, 'value': item_value,
    }, root=root)

    doc = read_doc(channel, root)
    doc['overlay']['orphans'] = [x for x in doc['overlay'].get('orphans', [])
                                  if x.get('id') != orphan_id]
    doc['overlay']['rev'] = int(doc['overlay'].get('rev') or 0) + 1
    _save(channel, doc, root)
    return {'restored': orphan_id, 'patch': patch}


# ── Композиція: тільки на читанні ────────────────────────────────────────────

def compose(channel, root=None):
    """Документ, який бачить людина: generation з накладеним overlay (К7).

    Ніколи не зберігається у файл. Третя копія правди тихо розійшлась би з обома шарами,
    і саме вона стала б тим місцем, де правки починають зникати."""
    doc = read_doc(channel, root)
    gen = copy.deepcopy(doc['generation'])
    conflicts = []
    hidden, frozen = set(), set()
    inserts, orders = [], {}

    for p in doc['overlay'].get('patches', []):
        tgt = p.get('target') or {}
        op = p.get('op')
        if op == 'hide':
            hidden.add(str(tgt.get('item')))
        elif op == 'freeze':
            frozen.add(str(tgt.get('item')))
        elif op == 'order':
            orders[str(tgt.get('section'))] = p.get('value') or []
        elif op == 'insert':
            inserts.append(p)

    items = _index_items(gen)
    for p in doc['overlay'].get('patches', []):
        if p.get('op') != 'set':
            continue
        tgt = p['target']
        it = items.get(str(tgt.get('item')))
        if it is None:
            continue
        # КОНФЛІКТ не вирішується автоматично в жоден бік: обидві сторони мають рацію
        # по-своєму, і вибір це рішення людини (К8).
        if p.get('baseHash') and it.get('hash') != p['baseHash']:
            conflicts.append({
                'patch': p['id'], 'item': it['key'],
                'human': p.get('value'),
                'machine': (it.get('widgets') or [{}])[tgt['widget']].get(tgt['field'])
                if 0 <= tgt.get('widget', -1) < len(it.get('widgets') or []) else None,
            })
            continue
        ws = it.get('widgets') or []
        wi = tgt.get('widget')
        if isinstance(wi, int) and 0 <= wi < len(ws):
            ws[wi] = {**ws[wi], tgt['field']: p.get('value'), 'edited': True}

    for s in gen.get('sections', []):
        s['items'] = [it for it in (s.get('items') or []) if str(it.get('key')) not in hidden]
        for it in s['items']:
            if str(it.get('key')) in frozen:
                it['frozen'] = True
        for p in inserts:
            if str((p.get('target') or {}).get('section')) != str(s.get('key')):
                continue
            val = dict(p.get('value') or {})
            val['by'] = 'human'
            after = (p.get('target') or {}).get('after')
            idx = next((i + 1 for i, it in enumerate(s['items'])
                        if str(it.get('key')) == str(after)), len(s['items']))
            s['items'].insert(idx, val)
        want = orders.get(str(s.get('key')))
        if want:
            pos = {k: i for i, k in enumerate(want)}
            s['items'].sort(key=lambda it: pos.get(str(it.get('key')), 10_000))

    counted = gen.get('counted')
    total = _channel_message_count(channel, root)
    unread = max(0, total - counted) if isinstance(counted, int) else None

    return {
        'channel': channel, 'rev': doc.get('rev'), 'updated': doc.get('updated'),
        'genRev': gen.get('genRev'), 'mode': gen.get('mode'), 'source': gen.get('source'),
        'sections': gen.get('sections', []),
        'conflicts': conflicts,
        'orphans': doc['overlay'].get('orphans', []),
        'editCount': len(doc['overlay'].get('patches', [])),
        'freshness': {'counted': counted, 'total': total, 'unread': unread},
    }


def apply_op(channel, op, body, root=None):
    """Один вхід для HTTP і CLI. ЖОДНА гілка не пише в обидва шари (К5)."""
    op = (op or '').strip()
    if op == 'generate':
        return {'generation': write_generation(
            channel, body.get('sections'), body.get('source'),
            body.get('mode') or 'full', body.get('model'), body.get('counted'), root)}
    if op == 'patch':
        return {'patch': add_patch(channel, body.get('patch') or {}, root)}
    if op == 'unpatch':
        drop_patch(channel, body.get('id'), root)
        return {'dropped': body.get('id')}
    if op == 'resolve':
        return resolve_conflict(channel, body.get('id'), body.get('mode'), root)
    if op == 'restore':
        return restore_orphan(channel, body.get('id'), body.get('section'), root)
    if op == 'read':
        return {'doc': compose(channel, root)}
    raise SummaryError(
        'невідома операція "%s". Відомі: generate, patch, unpatch, resolve, restore, read.' % op)


def main(argv=None):
    args = list(sys.argv[1:] if argv is None else argv)
    if not args:
        sys.stderr.write('summary_store: usage: <channel> <op> [payload.json]\n')
        return 1
    channel, op = args[0], (args[1] if len(args) > 1 else 'read')
    raw = open(args[2], encoding='utf-8').read() if len(args) > 2 else (
        '' if op == 'read' else sys.stdin.read())
    body = json.loads(raw) if raw.strip() else {}
    try:
        print(json.dumps(apply_op(channel, op, body), ensure_ascii=False, indent=2))
    except SummaryError as e:
        sys.stderr.write('summary_store: %s\n' % e)
        return 1
    return 0


if __name__ == '__main__':
    sys.exit(main())
