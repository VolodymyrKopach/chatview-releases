#!/usr/bin/env python3
"""summary_generate.py — генератор саммарі каналу (specs/chat-summary, розділ 4.4 і 7.1).

НАЙРИЗИКОВАНІШИЙ ФРАГМЕНТ ФІЧІ. Дослівно зі спеки: «Провалить не рендерер (двісті рядків),
а генератор. Схема ловить правки, але не ловить створення... Без власного валідатора з
циклом ремонту система за кілька тижнів тихо деградує назад у вільний HTML.» Тому весь цей
файл побудований навколо ОДНОГО факту: модель повертає JSON з ймовірністю помилки, і кожен
виклик `summary_store.validate_generation` тут не формальність, а єдине, що стоїть між
моделлю і тихою деградацією.

ЯК ВИКЛИКАЄТЬСЯ МОДЕЛЬ (дослідження перед кодом, а не вигадка)
----------------------------------------------------------------
`agent_worker.py` уже показує канонічний шлях: детач-агенти ChatView крутять модель через
сирий `<claude_bin> -p <prompt> ...` subprocess, з бінарником з `runner.CLAUDE_BIN` і
аргументами моделі з `runner._resolve_model_args`. Це ЄДИНА автентифікація в проєкті для
викликів Claude: сесія `claude` CLI, залогінена на машині (OAuth/keychain), той самий шлях,
яким кермує вся ChatView. Жодного нового ключа не заведено: BYOK-політика проєкту стосується
OpenAI (TTS), а не цього виклику.

Але для ЦЬОГО виклику (фонова генерація структурованого дерева, а не чат-хід) є три різниці
з тим, як `agent_worker.py` спавнить агента-кодера, і всі три перевірені живим прогоном
(не здогад):
  1. `cwd`. `agent_worker.py` стартує з `cwd=REPO_ROOT`, бо агенту-коду потрібен репозиторій.
     Наш генератор працює ЛИШЕ з текстом, який ми самі кладемо у промпт, тож ставимо
     `cwd` у нейтральну системну temp-теку. Перевірено: коли `cwd` лежить УСЕРЕДИНІ
     репозиторію, харнес підвантажує `.claude/settings.json` цього репо (MCP-сервери,
     UserPromptSubmit-хуки типу `skills-roster.cjs`), а це чужий шум у промпті генератора.
  2. `--system-prompt` (ПОВНА заміна), а не `--append-system-prompt` (додавання). Живий
     прогін підтвердив: з `--system-prompt` дефолтний системний промпт claude_code preset
     (і razом з ним CLAUDE.md ЦЬОГО репозиторію, з рядком «ти оркестратор, делегуй усе
     Тарасу») НЕ підмішується. Ловись: user-рівневий `~/.claude/CLAUDE.md` все одно
     прилітає окремим `<system-reminder>` у ПЕРШЕ повідомлення користувача, незалежно від
     `--system-prompt` і від `cwd` (це властивість автентифікованої сесії, не проєкту).
     Тому екстракція відповіді (`_extract_json`) мусить бути стійкою до чужого тексту
     навколо JSON, а не вірити, що відповідь це рівно JSON і нічого більше.
  3. `--tools "" --strict-mcp-config`. Без цього перший же холодний виклик коштував
     $0.147 на «PONG» (36572 токени кеш-запису: у системний контекст вантажились описи
     MCP-серверів з user-рівневого реєстру — chrome-devtools, context7, serena, clickup,
     posthog, sentry). З цими двома прапорцями той самий виклик впав до $0.003 (953 токени).
     Генератору інструменти не потрібні взагалі: увесь контекст (нові картки + попереднє
     саммарі) ми самі кладемо у промпт, моделі нема чого читати з диска.

ЦИКЛ РЕМОНТУ (К16)
-------------------
Дерево від моделі йде через `summary_store.validate_generation` СИНХРОННО, до будь-якого
запису. При помилці моделі повертається ТЕКСТ помилки (той самий, що бачив би розробник) і
дається ще одна спроба, до `MAX_GENERATION_ATTEMPTS`. Жодна проміжна спроба нічого не пише:
`write_generation` викликається РІВНО ОДИН РАЗ, і тільки для дерева, яке вже пройшло
валідатор. Якщо спроби скінчились — попередня генерація лишається на місці (ми просто не
викликаємо `write_generation`).

Провал видно двома способами: у поверненому результаті (`ok: False`, `error`, `attempts`) і
в лозі (`log_fn`, за замовчуванням `runner.log`, той самий журнал, який уже пише решта
ChatView) — ніколи мовчки.
"""
import json
import os
import re
import subprocess
import tempfile
import threading

import summary_store as ss

try:
    import runner
except Exception:  # pragma: no cover - runner тягне платформний шар; тести підміняють CLI
    runner = None


# ── Константи модуля (жодного магічного числа в коді) ────────────────────────

#: К16. Обмежена кількість спроб: 1 перша + до 3 ремонтів. Достатньо, щоб пережити типову
#: одну криву спробу моделі, замало, щоб цикл ремонту сам перетворився на дорогий цикл.
MAX_GENERATION_ATTEMPTS = 4

#: К17. Стеля попереднього саммарі в символах, дослівно зі спеки (розділ 4.3): 6000 символів
#: ≈ 2000 токенів. Наївний водяний знак ламає сценарій «на 5-му висновок один, на 15-му
#: інший»: модель не бачить твердження, яке треба СКАСУВАТИ. Ліки — подати старе саммарі
#: ЦІЛКОМ, а не тільки дельту.
PREV_SUMMARY_CHAR_CEILING = 6000

#: К18. Кожні стільки ІНКРЕМЕНТАЛЬНИХ оновлень поспіль — повна перезбірка (mode='full'),
#: щоб дрейф (початок чату «виїжджає» з підсумку) не накопичувався без обмеження.
FULL_REBUILD_EVERY = 5

#: Захист від однієї картки-мастодонта, що займе весь промпт сама. Не є критерієм зі спеки,
#: це наш власний запобіжник: без нього одна велика картка витіснила б решту нових карток
#: з контексту генерації.
CARD_TEXT_CAP = 600

#: Таймаут одного виклику CLI. Генерація однієї моделі — це не інтерактивний хід з
#: інструментами, тому й не потребує годинного вікна, яким живе runner.TURN_TIMEOUT.
CLI_TIMEOUT_SECONDS = 180

#: Поля, які НЕ несуть змісту для читача (службова розмітка вузла), тому виключені з
#: дайджесту картки, який іде моделі. Найкраще зусилля, не вичерпний список: краще
#: пропустити службове поле, ніж змусити модель продиратись крізь `"type":"note"` у
#: кожному рядку історії.
_DIGEST_SKIP_KEYS = {
    'type', 'tone', 'color', 'icon', 'id', 'key', 'src', 'lang', 'variant',
    'tag', 'state', 'kind', 'detail', 'by', 'hash', 'widgetType', 'span', 'n',
    'cols', 'poster', 'href', 'url',
}


class GenerationError(RuntimeError):
    """Виклик моделі провалився технічно (CLI впав, не автентифікований, таймаут).

    Окремо від `ss.SummaryError`: та каже «модель відповіла, але криво», ця каже
    «модель взагалі не відповіла». Обидві однаково йдуть у цикл ремонту (К16)."""


# ── Промпт для моделі. Англійською (економія токенів), зміст документа —
# українською: закритий словник, стеля глибини і форма слота беруться З ЖИВОГО summary_store,
# а не переписані тут руками, щоб промпт не розійшовся зі схемою, яка реально валідує. ─────

_ENVELOPE_EXAMPLE = json.dumps({
    'header': {'title': 'Коротка тема розмови',
               'subtitle': 'Одне речення про що саме ця розмова.'},
    'sections': [{
        'key': 'sec.example', 'title': 'Приклад секції',
        'items': [{'key': 'item.example', 'widgets': [
            {'type': 'note', 'title': 'Заголовок', 'body': 'Абзац з **інлайновою** розміткою.'},
        ]}],
    }],
}, ensure_ascii=False)


def _system_prompt():
    containers = ', '.join(sorted(ss.CONTAINERS))
    leaves = ', '.join(sorted(ss.LEAVES))
    slots = ', '.join(ss._SLOT_KEYS)
    return f'''You are the background summary generator for a chat app (ChatView). You read
chat history and produce a compact "sheet" document a human can scan in a few seconds
instead of scrolling the whole channel.

OUTPUT CONTRACT — return ONLY a single JSON object, nothing before or after it, no markdown
code fence:
{_ENVELOPE_EXAMPLE}

Top level: {{"header": {{...}}, "sections": [section, ...]}}. Each section:
{{"key", "title", "items": [item, ...]}}. Each item: {{"key", "widgets": [node, ...]}}. A
"widgets" array holds one or more top-level nodes (depth 1).

CLOSED NODE VOCABULARY — this is the whole set, do not invent a type outside it:
  CONTAINERS (may have a "children" array of nodes): {containers}
  LEAVES (never have "children", carry slot fields instead): {leaves}
An unknown type is REJECTED on write, not silently rendered as a fallback box, so use only
the types above.

DEPTH CEILING: {ss.MAX_DEPTH}. A node placed directly in "widgets" is depth 1; each nested
"children" level adds 1. A tree deeper than {ss.MAX_DEPTH} is rejected by name and depth, not
silently trimmed.

SLOT SHAPE: fields {slots} accept EITHER a plain string (inline markdown like **bold** is
fine) OR an array of strings for a bullet list. Never a nested object, never a number.

STABLE KEYS — this is the most load-bearing rule. Every section and every item needs a
unique "key" (short, semantic, kebab-case, e.g. "dec.byok", not "item3" or a random id).
A human may have hand-edited content addressed by that exact key. If you keep the same key
across regenerations for a fact that is still true, the human's edit re-applies automatically.
If you rename the key while the underlying fact is unchanged, that edit is silently orphaned
even though nothing actually changed. Only give a fact a NEW key when it is a materially
different fact, not a rephrasing of the same one.

CONTENT LANGUAGE: every section title, item title/body/text and any other content field must
be written in Ukrainian. Only the JSON field names and node "type" values stay in English
(they are schema, not content).

DOCUMENT TOPIC: always include the top-level "header" field, every time you build or update
the sheet. "title" is the short topic of this whole conversation (aim for at most ~60
characters), "subtitle" is one sentence describing what the conversation is actually about.
Both are written in the same CONTENT LANGUAGE as everything else (Ukrainian). If the EXISTING
SUMMARY JSON shown to you below contains a section with key "{ss.HEADER_SECTION_KEY}" holding
an item "{ss.HEADER_ITEM_KEY}" of type "doc-header", that is the CURRENT topic and is shown
for your context only: never put it back inside your own "sections" array, express the
(possibly unchanged) topic only through the top-level "header" field, exactly once.

When asked to UPDATE an existing sheet: if a new message contradicts or supersedes an earlier
claim, REPLACE that claim in place (same key if the fact is the same topic) instead of adding
a second, contradicting note next to it. Do not just append.'''


SYSTEM_PROMPT = _system_prompt()


# ── Дайджест повідомлень: сирі widgets-картки -> компактний рядок для промпту ────────────

def _collect_strings(node, out):
    if isinstance(node, dict):
        for k, v in node.items():
            if k in _DIGEST_SKIP_KEYS:
                continue
            _collect_strings(v, out)
    elif isinstance(node, list):
        for v in node:
            _collect_strings(v, out)
    elif isinstance(node, str):
        s = node.strip()
        if s:
            out.append(s)


def _digest_message(msg, cap=CARD_TEXT_CAP):
    """Одна картка чату -> один рядок «[id] відправник: текст», обрізаний до `cap`.

    Найкраще зусилля: збирає всі рядкові значення з віджетів картки, крім службових
    полів (`_DIGEST_SKIP_KEYS`). Не претендує на ідеальний переказ 44 типів віджетів,
    лише на достатній контекст для генератора саммарі."""
    strings = []
    _collect_strings(msg.get('widgets'), strings)
    text = ' / '.join(strings) if strings else '(порожня картка)'
    if len(text) > cap:
        text = text[:cap] + '…'
    return f"[{msg.get('id')}] {msg.get('from') or '?'}: {text}"


def _messages_block(messages):
    if not messages:
        return '(немає карток)'
    return '\n'.join(_digest_message(m) for m in messages)


def _patched_item_keys(doc):
    """specs/chat-summary розділ 6 (найдорожчий ризик): ключі пунктів, на які стоїть
    ЖИВИЙ патч людини (`op` set/hide/freeze, тобто `target.item` заповнений).

    Замір `summary_reanchor_bench.py` на трьох живих каналах: 57 патчів, 31.6% осиротіло,
    і у ВСІХ 18 випадках причина дослівно «пункт зник з генерації». Ключі при цьому НЕ
    перейменовуються (перевірено окремо на chat-269: 11/11 ключів пережили ревізію) —
    пункт просто не влазив у стелю `_previous_summary_block`, бо вона різала хвіст дерева
    без розбору, і модель фізично не могла його побачити й відтворити. Ці ключі мусять
    лишатись видимими моделі незалежно від стелі нижче."""
    keys, seen = [], set()
    for p in doc.get('overlay', {}).get('patches', []):
        key = (p.get('target') or {}).get('item')
        if key is None:
            continue
        key = str(key)
        if key not in seen:
            seen.add(key)
            keys.append(key)
    return keys


def _extract_items_by_key(sections, keys):
    """Сирі пункти машини (з `hash`), чиї ключі входять у `keys`, у порядку появи в дереві."""
    if not keys:
        return []
    wanted = set(keys)
    return [it for s in (sections or []) for it in (s.get('items') or [])
            if str(it.get('key')) in wanted]


def _drop_items_by_key(sections, keys):
    """Ті самі секції без пунктів із `keys` — щоб пінений пункт не дублювався в
    непінованому хвості, який ще й ріжеться стелею."""
    if not keys:
        return sections
    drop = set(keys)
    return [{**s, 'items': [it for it in (s.get('items') or [])
                             if str(it.get('key')) not in drop]}
            for s in (sections or [])]


def _previous_summary_block(doc):
    """К17 + specs/chat-summary розділ 6 (найдорожчий ризик, доказ числом — К21).
    Попереднє саммарі йде моделі ЦІЛКОМ, стеля символів, ріжеться з кінця з явною
    позначкою при перевищенні. Береться сирий шар машини (`generation`), а не
    `compose()`: у промпт має йти те, за що документ ВІДПОВІДАЄ (факти), а не шар
    людських правок, який живе і мириться зі своїми конфліктами окремо (К8/К9).

    Пункти, на які стоїть живий патч людини (`_patched_item_keys`), ПІНЮЮТЬСЯ окремим
    блоком і йдуть у промпт ЗАВЖДИ, поза чергою; стеля ріже тільки решту (непінований
    хвіст). Стеля НЕ піднімається наосліп (вона тримає ціну виклику, спека розділ 4.3):
    якщо самі пінені пункти вже перевищують стелю, для непінованої частини лишається 0
    бюджету, і промпт отримує ОКРЕМУ явну позначку про це замість тихого порожнього блоку.

    Повертає `(текст_блоку, список_пінених_ключів)`."""
    sections = doc['generation'].get('sections', [])
    pinned_keys = _patched_item_keys(doc)
    full_raw = json.dumps({'sections': sections}, ensure_ascii=False)
    if len(full_raw) <= PREV_SUMMARY_CHAR_CEILING:
        return full_raw, pinned_keys  # усе влазить, пінити нема потреби

    cut_marker = (
        ' …[ОБРІЗАНО: попереднє саммарі довше за стелю %d символів]' % PREV_SUMMARY_CHAR_CEILING)
    if not pinned_keys:
        return full_raw[:PREV_SUMMARY_CHAR_CEILING] + cut_marker, pinned_keys

    pinned_items = _extract_items_by_key(sections, pinned_keys)
    pinned_raw = json.dumps({'humanEditedItems': pinned_items}, ensure_ascii=False)
    pinned_header = (
        '[ЦІ ПУНКТИ ПРАВИЛА ЛЮДИНА РУКАМИ, показані повністю незалежно від стелі нижче: '
        '%s]\n' % ', '.join(pinned_keys))
    budget_left = PREV_SUMMARY_CHAR_CEILING - len(pinned_header) - len(pinned_raw)

    if budget_left <= 0:
        # Розділ 6: самі пінені пункти вже перекрили стелю. Стелю не піднімаємо наосліп —
        # решта попереднього саммарі в цей виклик просто не влазить, і це сказано моделі
        # прямим текстом, а не тихим порожнім блоком.
        return pinned_header + pinned_raw + (
            '\n…[СТЕЛЯ %d ПЕРЕВИЩЕНА САМИМИ ПРАВЛЕНИМИ ПУНКТАМИ: решта попереднього '
            'саммарі в цей виклик не влізла]' % PREV_SUMMARY_CHAR_CEILING), pinned_keys

    rest_raw = json.dumps(
        {'sections': _drop_items_by_key(sections, pinned_keys)}, ensure_ascii=False)
    if len(rest_raw) > budget_left:
        rest_raw = rest_raw[:budget_left] + cut_marker
    return pinned_header + pinned_raw + '\n' + rest_raw, pinned_keys


def _build_user_prompt(mode, new_messages, prev_summary_block, pinned_keys=None):
    msgs_block = _messages_block(new_messages)
    if mode == 'full':
        return (
            'Build a fresh summary sheet from scratch for this chat channel.\n'
            'Full message history, chronological, one line per card as "[id] sender: text":\n'
            f'{msgs_block}\n\n'
            'Return only the JSON object described in the system prompt.'
        )
    pinned_note = ''
    if pinned_keys:
        # specs/chat-summary розділ 6: дослівна інструкція, чому ці ключі не можна тихо
        # перейменувати чи викинути як «застарілий дубль» під час апдейту.
        pinned_note = (
            'HUMAN-EDITED KEYS: %s. A human hand-edited these exact items in the sheet below. '
            'If the underlying fact is still true, KEEP THE SAME KEY for it: do not rename it '
            'and do not drop it as a stale duplicate. Only remove one of these keys if that '
            'specific fact has genuinely stopped being true.\n\n' % ', '.join(pinned_keys)
        )
    return (
        'Update the existing summary sheet below to account for the new messages that arrived '
        'after it was generated.\n\n'
        f'{pinned_note}'
        f'EXISTING SUMMARY (previous generation, JSON, may be cut at the end if long):\n'
        f'{prev_summary_block}\n\n'
        'NEW MESSAGES since that summary, one line per card as "[id] sender: text":\n'
        f'{msgs_block}\n\n'
        'Return the FULL updated JSON object (the whole sheet, not just the changed part).'
    )


def _repair_prompt(original_user_prompt, error_text, raw_reply=None):
    """К16: модель отримує ТЕКСТ помилки валідатора і повертається до тієї самої
    задачі. Кожна спроба — окремий однокроковий виклик (`--no-session-persistence`),
    тому повний контекст (оригінальний промпт + що саме було не так) переноситься
    руками, а не через памʼять сесії."""
    bad = f'\n\nYour previous raw reply was:\n{raw_reply[:2000]}' if raw_reply else ''
    return (
        f'{original_user_prompt}\n\n'
        '--- REPAIR ---\n'
        'Your previous answer was REJECTED by the schema validator with this exact error:\n'
        f'{error_text}{bad}\n'
        'Fix exactly that problem and return ONLY the corrected full JSON object. '
        'No prose, no markdown code fence.'
    )


# ── Екстракція JSON з відповіді моделі: стійка до чужого тексту навколо ──────────────────
# Живий прогін довів, що навіть з --system-prompt user-рівневий ~/.claude/CLAUDE.md
# долітає окремим system-reminder і модель МОЖЕ обрамити відповідь поясненням чи
# markdown-огорожею попри пряму заборону в промпті. Тому парсер не вірить, що вся
# відповідь — рівно JSON, а вміє витягти перший збалансований {...} з чого завгодно.

def _first_balanced_object(text):
    start = text.find('{')
    if start == -1:
        raise ValueError('no opening { found')
    depth = 0
    in_str = False
    esc = False
    for i in range(start, len(text)):
        c = text[i]
        if in_str:
            if esc:
                esc = False
            elif c == '\\':
                esc = True
            elif c == '"':
                in_str = False
            continue
        if c == '"':
            in_str = True
        elif c == '{':
            depth += 1
        elif c == '}':
            depth -= 1
            if depth == 0:
                return text[start:i + 1]
    raise ValueError('unbalanced braces, no closing } for the first {')


def _extract_json(raw):
    text = (raw or '').strip()
    if not text:
        raise ValueError('empty model reply')
    candidates = []
    fence = re.search(r'```(?:json)?\s*(.*?)```', text, re.DOTALL)
    if fence:
        candidates.append(fence.group(1).strip())
    candidates.append(text)
    last_err = None
    for cand in candidates:
        try:
            return json.loads(cand)
        except Exception as e:
            last_err = e
        try:
            return json.loads(_first_balanced_object(cand))
        except Exception as e:
            last_err = e
    raise ValueError(f'no valid JSON object found in model reply: {last_err}')


# ── Виклик моделі: сирий `claude -p`, той самий бінарник і той самий спосіб резолвити
# модель, яким уже керує agent_worker.py. Нового способу тримати ключі тут немає: сесія
# claude CLI на машині — вже автентифікована, ідентична решті ChatView. ────────────────

def _invoke_claude_cli(system_prompt, user_prompt, model):
    if runner is None:
        raise GenerationError('runner module unavailable: cannot resolve the claude CLI')
    cmd = [runner.CLAUDE_BIN, '-p', user_prompt,
           '--system-prompt', system_prompt,
           *runner._resolve_model_args(model),
           '--tools', '',                 # генератору не треба жодного інструмента
           '--strict-mcp-config',         # і жодного MCP-сервера (перевірено: $0.147 -> $0.003)
           '--output-format', 'json',
           '--no-session-persistence']
    try:
        r = subprocess.run(cmd, cwd=tempfile.gettempdir(), capture_output=True,
                           text=True, timeout=CLI_TIMEOUT_SECONDS)
    except subprocess.TimeoutExpired as e:
        raise GenerationError(f'claude CLI timed out after {CLI_TIMEOUT_SECONDS}s: {e}')
    except Exception as e:
        raise GenerationError(f'claude CLI failed to start: {e}')
    if r.returncode != 0:
        raise GenerationError(
            f'claude CLI exited {r.returncode}: {(r.stderr or "").strip()[:500]}')
    try:
        data = json.loads(r.stdout)
    except Exception as e:
        raise GenerationError(
            f'claude CLI did not return a JSON envelope: {e}: {r.stdout[:300]!r}')
    if data.get('is_error'):
        raise GenerationError(f'claude CLI reported an error turn: {data.get("result")}')
    return data.get('result') or ''


def _resolve_model(channel, root):
    """Модель каналу, тим самим шляхом, що й будь-який інший хід ChatView. Файл каналу
    живе поза `root` (він у `runner.CHANNELS_DIR`, не у нашому storage `root`), тому цей
    шлях працює тільки для СПРАВЖНЬОГО каналу (root=None); тести завжди підміняють
    `model_call` і сюди не заходять."""
    if root is None and runner is not None:
        try:
            return runner.channel_model(channel)
        except Exception:
            pass
    return 'sonnet'


def _default_log(msg):
    if runner is not None:
        try:
            runner.log('summary_generate:', msg)
            return
        except Exception:
            pass
    print(f'[summary_generate] {msg}')


# ── Тема документа (К31, К34): "header" з відповіді моделі -> звичайний пункт `hdr` ──────

def _build_header_item(header):
    """К31: `header` опційний. Відсутність (`None`) не помилка — теми просто немає (К34),
    заглушки бути не може. Якщо модель щось повернула, `title` не може бути порожнім: це
    криве дерево, і воно йде в той самий цикл ремонту (К16), що й помилки в `sections`."""
    if header is None:
        return None
    if not isinstance(header, dict):
        raise ss.SummaryError('header мусить бути обʼєктом, прийшло %s' % type(header).__name__)
    title = header.get('title')
    if not isinstance(title, str) or not title.strip():
        raise ss.SummaryError('header.title не може бути порожнім')
    subtitle = header.get('subtitle')
    if subtitle is not None and not isinstance(subtitle, str):
        raise ss.SummaryError('header.subtitle мусить бути рядком')
    widget = {'type': 'doc-header', 'title': title}
    if subtitle:
        widget['subtitle'] = subtitle
    return {'key': ss.HEADER_ITEM_KEY, 'widgets': [widget]}


def _demote_stray_headers(sections, topic_title=None):
    """`doc-header` існує в документі РІВНО в одному місці: пункт `hdr` у секції `sec.hdr`.

    Привід заміряний на живому каналі chat-269: після введення теми (К31) документ мав ДВА
    вузли `doc-header` з однаковим заголовком, і на екрані тема була надрукована двічі
    підряд. Другий приїхав не з примхи моделі, а з ІСТОРІЇ: пункт існував ще з тих часів,
    коли тему клали руками всередину секції стану, і інкрементальна генерація чесно
    перенесла його далі.

    Тому лагодимо детерміновано, а не інструкцією в промпті: інструкція це прохання, і на
    пункті, який модель бачить у попередньому саммарі як даність, вона його не виконує.
    Чужий `doc-header` знижується до `note`, а не викидається: `status` і `meta` там несуть
    зміст, якого більше ніде немає. Заголовок, що дублює тему, при цьому не переїжджає,
    інакше дубль лишився б, просто іншим шрифтом."""
    if not isinstance(sections, list):
        return sections
    topic = (topic_title or '').strip()
    out = []
    for s in sections:
        if not isinstance(s, dict) or s.get('key') == ss.HEADER_SECTION_KEY:
            out.append(s)
            continue
        items = []
        for it in (s.get('items') or []):
            if not isinstance(it, dict):
                items.append(it)
                continue
            widgets = []
            for w in (it.get('widgets') or []):
                if not isinstance(w, dict) or w.get('type') != 'doc-header':
                    widgets.append(w)
                    continue
                title = (w.get('status') or '').strip()
                own = (w.get('title') or '').strip()
                if not title and own and own != topic:
                    title = own
                body = [x for x in ((w.get('subtitle') or '').strip(),
                                    (w.get('meta') or '').strip()) if x]
                if not title and not body:
                    continue  # нічого, крім дубля теми: тихо зникає разом з ним
                note = {'type': 'note'}
                if title:
                    note['title'] = title
                if body:
                    note['body'] = body if len(body) > 1 else body[0]
                widgets.append(note)
            if widgets:
                items.append(dict(it, widgets=widgets))
        out.append(dict(s, items=items))
    return out


def _with_header_section(sections, header_item):
    """К31: тема лягає в генерацію як звичайний пункт, не як окреме поле поза сховищем.
    Кладемо його в окрему секцію з фіксованим ключем (`ss.HEADER_SECTION_KEY`), не першим
    пунктом першої секції моделі — обґрунтування біля самої константи в summary_store.py."""
    if not isinstance(sections, list):
        return sections  # невалідне саме по собі: validate_generation дасть точну причину
    topic = None
    if isinstance(header_item, dict):
        for w in (header_item.get('widgets') or []):
            if isinstance(w, dict) and w.get('type') == 'doc-header':
                topic = w.get('title')
                break
    sections = _demote_stray_headers(sections, topic)
    if header_item is None:
        return sections
    return [{'key': ss.HEADER_SECTION_KEY, 'items': [header_item]}] + list(sections)


# ── Цикл ремонту (К16) ────────────────────────────────────────────────────────────────

def _run_with_repair(channel, model_call, user_prompt, log_fn):
    """Повертає (sections, attempts, error). `sections is None` означає повний провал:
    жоден із `MAX_GENERATION_ATTEMPTS` не дав дерева, яке проходить `validate_generation`."""
    convo = user_prompt
    last_error = None
    for attempt in range(1, MAX_GENERATION_ATTEMPTS + 1):
        raw = None
        try:
            raw = model_call(SYSTEM_PROMPT, convo)
        except Exception as e:
            last_error = f'model call failed: {e}'
            log_fn(f'{channel}: attempt {attempt}/{MAX_GENERATION_ATTEMPTS} — {last_error}')
            convo = _repair_prompt(user_prompt, last_error)
            continue
        try:
            parsed = _extract_json(raw)
        except Exception as e:
            last_error = f'model reply is not valid JSON: {e}'
            log_fn(f'{channel}: attempt {attempt}/{MAX_GENERATION_ATTEMPTS} — {last_error}')
            convo = _repair_prompt(user_prompt, last_error, raw)
            continue
        raw_sections = parsed.get('sections') if isinstance(parsed, dict) else None
        header = parsed.get('header') if isinstance(parsed, dict) else None
        try:
            header_item = _build_header_item(header)
            sections = _with_header_section(raw_sections, header_item)
            ss.validate_generation({'sections': sections})
        except ss.SummaryError as e:
            last_error = str(e)
            log_fn(f'{channel}: attempt {attempt}/{MAX_GENERATION_ATTEMPTS} — '
                   f'validate_generation refused: {last_error}')
            convo = _repair_prompt(user_prompt, last_error, raw)
            continue
        return sections, attempt, None
    return None, MAX_GENERATION_ATTEMPTS, last_error


# ── К20: одна генерація на канал одночасно ────────────────────────────────────────────
# Сервер багатопотоковий (socketserver.ThreadingTCPServer, один процес), тому замок у
# памʼяті процесу, а не файл-лок, — правильний і достатній інструмент: другий потік, що
# прийшов, поки перший генерує, БЛОКУЄТЬСЯ на тому самому замку, а щойно перший записав
# нову генерацію — перечитує стан і бачить «нових карток немає», тобто повертає щойно
# зроблений результат замість того, щоб запускати другий виклик моделі. Ніякого окремого
# «чи вже йде генерація» прапорця не треба: double-checked freshness під замком дає той
# самий ефект простіше.
_locks = {}
_locks_guard = threading.Lock()


def _channel_lock(channel):
    with _locks_guard:
        lock = _locks.get(channel)
        if lock is None:
            lock = threading.Lock()
            _locks[channel] = lock
        return lock


# ── Публічний вхід ──────────────────────────────────────────────────────────────────

def ensure_summary(channel, root=None, model_call=None, model=None, log_fn=None):
    """К15: викликати при ВІДКРИТТІ каналу. Якщо з часу останньої генерації додались
    картки — генерує (інкрементально або повною перезбіркою, К18) і повертає свіжий
    документ; якщо ні — не робить нічого дорожчого за читання файлу.

    `model_call(system_prompt, user_prompt) -> str` — точка підміни для тестів (fake
    модель, нуль токенів). Продакшн-виклик за замовчуванням — `_invoke_claude_cli`,
    той самий `claude` CLI і той самий спосіб резолвити модель, яким уже керує
    `agent_worker.py`.

    Повертає dict:
      {'doc': compose()-документ, 'generated': bool, 'ok': bool,
       'mode': 'full'|'incremental'|None, 'attempts': int, 'error': str|None}
    """
    log_fn = log_fn or _default_log
    channel_dir = os.path.join(root or ss.channels_dir(), channel)

    lock = _channel_lock(channel)
    with lock:
        doc = ss.read_doc(channel, root)
        messages = _read_channel_messages(channel_dir)
        last_id = max((m['id'] for m in messages if isinstance(m.get('id'), int)), default=0)
        has_previous = bool(doc['generation'].get('sections'))
        prev_source = doc['generation'].get('source') or {}
        prev_last_id = int(prev_source.get('lastMessageId') or 0)
        stale = last_id > 0 and (not has_previous or last_id > prev_last_id)

        if not stale:
            return {'doc': ss.compose(channel, root), 'generated': False, 'ok': True,
                    'mode': None, 'attempts': 0, 'error': None}

        prev_incremental = int(prev_source.get('incrementalCount') or 0)
        do_full = (not has_previous) or (prev_incremental + 1 >= FULL_REBUILD_EVERY)
        mode = 'full' if do_full else 'incremental'
        new_messages = messages if mode == 'full' else [m for m in messages if m['id'] > prev_last_id]
        prev_block, pinned_keys = (None, []) if mode == 'full' else _previous_summary_block(doc)
        user_prompt = _build_user_prompt(mode, new_messages, prev_block, pinned_keys)

        model_name = model or _resolve_model(channel, root)
        call = model_call or (lambda sp, up: _invoke_claude_cli(sp, up, model_name))

        sections, attempts, error = _run_with_repair(channel, call, user_prompt, log_fn)

        if sections is None:
            log_fn(f'{channel}: generation FAILED after {attempts} attempts, '
                    f'previous generation left untouched. Last error: {error}')
            return {'doc': ss.compose(channel, root), 'generated': False, 'ok': False,
                    'mode': mode, 'attempts': attempts, 'error': error}

        new_incremental = 0 if mode == 'full' else prev_incremental + 1
        gen = ss.write_generation(
            channel, sections,
            source={'lastMessageId': last_id, 'messageCount': len(messages),
                    'incrementalCount': new_incremental},
            mode=mode, model=model_name, root=root)
        log_fn(f'{channel}: generated ok, mode={mode}, attempts={attempts}, genRev={gen["genRev"]}')
        return {'doc': ss.compose(channel, root), 'generated': True, 'ok': True,
                'mode': mode, 'attempts': attempts, 'error': None}


def _read_channel_messages(channel_dir):
    """Картки каналу в хронологічному порядку: `index.json` + по одному `NNNN.json` на
    картку. Той самий контракт, яким пише `runner.append_message` (docstring runner.py,
    розділ «Storage contract»). Відсутній чи битий індекс читається як порожній канал,
    так само, як `summary_store.read_doc` читає відсутнє саммарі порожнім документом."""
    idx_path = os.path.join(channel_dir, 'index.json')
    try:
        with open(idx_path, encoding='utf-8') as f:
            items = json.load(f)
    except Exception:
        return []
    if not isinstance(items, list):
        return []
    out = []
    for it in sorted(items, key=lambda i: i.get('id', 0)):
        fname = it.get('file')
        widgets = []
        if fname:
            try:
                with open(os.path.join(channel_dir, fname), encoding='utf-8') as f:
                    widgets = json.load(f)
            except Exception:
                widgets = []
        out.append({'id': it.get('id'), 'from': it.get('from') or '', 'widgets': widgets})
    return out


if __name__ == '__main__':
    import sys
    if len(sys.argv) < 2:
        sys.stderr.write('usage: summary_generate.py <channel>\n')
        sys.exit(1)
    result = ensure_summary(sys.argv[1])
    print(json.dumps(result, ensure_ascii=False, indent=2))
