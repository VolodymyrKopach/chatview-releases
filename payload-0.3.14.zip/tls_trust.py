#!/usr/bin/env python3
"""Довіряти тим самим кореневим сертифікатам, що й операційна система.

ПРИВІД (Vova, 10 серпня 2026). На машинах з антивірусом або корпоративним проксі
озвучка і диктування падали з «інтернет є, але цей комп'ютер не зміг перевірити
сертифікат», хоч браузер на тій самій машині ту саму OpenAI відкривав.

ПРИЧИНА, заміряна тут же. Python бере корені НЕ зі сховища ОС, а з certifi:

    ssl.get_default_verify_paths().cafile
      = .../Python.framework/Versions/3.10/etc/openssl/cert.pem -> certifi/cacert.pem
    коренів у контексті Python: 151
    у macOS Keychain: 161, з них Python не знає 44

Тобто розрив є навіть на здоровій машині. Антивірус лише робить його помітним: він
підміняє сертифікат api.openai.com своїм, підписаним коренем, який лежить у
/Library/Keychains/System.keychain. Браузер і curl цей корінь бачать, ми ні.

ЩО РОБИТЬ ЦЕЙ МОДУЛЬ. Складає ОБʼЄДНАНИЙ набір довіри (поточний bundle плюс корені
цієї ОС) у CHATVIEW_HOME/ca-trust.pem і вмикає його на весь процес однією точкою:
змінні середовища плюс дефолтна фабрика https-контексту. Місця виклику urlopen (їх
десятки) не змінюються взагалі.

ЧОГО ЦЕЙ МОДУЛЬ НЕ РОБИТЬ НІКОЛИ. Не вимикає перевірку. Ні CERT_NONE, ні verify=False,
ні прапорцем, ні тимчасово. Застосунок, який мовчки приймає будь-який сертифікат,
гірший за застосунок, що чесно каже про проблему: перший так само зламаний, але про це
ніхто не дізнається.

Тільки stdlib: паковану збірку везе PyInstaller, і кожна нова залежність це ще один
спосіб її зламати.

Контракт і критерії приймання: specs/tls-system-trust/spec.md.
"""
import hashlib
import os
import ssl
import subprocess
import sys
import time

# Імʼя файла довіри в CHATVIEW_HOME. Поруч із ним живе решта даних користувача, тож
# він переживає оновлення застосунку і не потребує прав на теку програми.
BUNDLE_NAME = 'ca-trust.pem'

# Скільки живе зібраний набір. Перебирати сховище на кожен старт немає сенсу: корені
# змінюються раз на місяці, а `security` на великому Keychain це десяті секунди.
CACHE_TTL = 24 * 3600

# Жорсткий таймаут на зовнішній збирач. Під MDM `security` може попросити пароль і
# зависнути назавжди; краще лишитись на дефолтному наборі, ніж не піднятись взагалі.
PROBE_TIMEOUT = 10

# macOS. Три сховища за зростанням приватності: системні корені, машинне сховище
# (сюди кладе корінь антивірус і MDM, саме воно нас і цікавить) і сховище користувача.
MAC_KEYCHAINS = (
    '/System/Library/Keychains/SystemRootCertificates.keychain',
    '/Library/Keychains/System.keychain',
    '~/Library/Keychains/login.keychain-db',
)

# Linux. Дистрибутиви не домовились, тому перебираємо відомі шляхи і беремо всі, що є.
LINUX_BUNDLES = (
    '/etc/ssl/certs/ca-certificates.crt',      # Debian, Ubuntu, Alpine
    '/etc/pki/tls/certs/ca-bundle.crt',        # Fedora, RHEL, CentOS
    '/etc/ssl/ca-bundle.pem',                  # openSUSE
    '/etc/pki/tls/cacert.pem',                 # старі RHEL
    '/etc/ssl/cert.pem',                       # Arch, FreeBSD
)

# Windows. Корінь у сховищі може бути виданий під інші задачі (підпис коду, пошта), і
# довіряти йому для сайтів через це не можна. Беремо тільки serverAuth.
SERVER_AUTH_OID = '1.3.6.1.5.5.7.3.1'

_default_cafile = None      # памʼять про bundle, який був ДО нас (див. default_cafile)
_default_roots = None       # скільки в ньому коренів (див. default_root_count)


def _log(msg):
    """Одна подія про довіру в stderr.

    Не logging: модуль стартує ДО того, як застосунок налаштує логування, і мовчазний
    збій довіри це рівно та хвороба, яку ми тут лікуємо."""
    try:
        sys.stderr.write('[tls-trust] %s\n' % msg)
        sys.stderr.flush()
    except Exception:
        pass


# ── Читання сховищ ─────────────────────────────────────────────────────────────

def pem_blocks(text):
    """Текст із сертифікатами -> список окремих PEM-блоків.

    Власний розбір, а не регулярка на весь файл: сховища віддають PEM упереміш із
    підписами, коментарями і назвами, і одна зіпсована пара BEGIN/END не сміє
    забрати з собою решту файла."""
    out, cur = [], None
    for line in (text or '').splitlines():
        s = line.strip()
        if s.startswith('-----BEGIN CERTIFICATE'):
            cur = [s]
        elif cur is not None:
            cur.append(s)
            if s.startswith('-----END CERTIFICATE'):
                out.append('\n'.join(cur) + '\n')
                cur = None
    return out


def _ders(text):
    """Текст із сертифікатами -> список DER. Нерозбірливе просто пропускаємо."""
    out = []
    for block in pem_blocks(text):
        try:
            out.append(ssl.PEM_cert_to_DER_cert(block))
        except Exception:
            continue
    return out


def _read(path):
    try:
        with open(path, encoding='utf-8', errors='replace') as fh:
            return fh.read()
    except Exception:
        return ''


def _roots_windows():
    """Сховища Windows через ssl.enum_certificates (рідний API, без сторонніх пакетів)."""
    out = []
    for store in ('ROOT', 'CA'):
        try:
            certs = ssl.enum_certificates(store)
        except Exception:
            continue          # сховища може не бути, це не привід падати
        for der, encoding, trust in certs:
            if encoding != 'x509_asn':
                continue
            # trust is True означає «для всього»; інакше це набір OID дозволених задач.
            if trust is True or (not isinstance(trust, bool) and trust
                                 and SERVER_AUTH_OID in trust):
                out.append(der)
    return out


def _roots_macos():
    """Сховища macOS через `security find-certificate -a -p`.

    Читаються без пароля, бо це публічні сертифікати, а не ключі. Кожен keychain
    окремим викликом із таймаутом: під MDM один із них може зависнути, і решта мусить
    доїхати."""
    tool = '/usr/bin/security'
    if not os.path.exists(tool):
        return []
    out = []
    for kc in MAC_KEYCHAINS:
        path = os.path.expanduser(kc)
        if not os.path.exists(path):
            continue
        try:
            r = subprocess.run([tool, 'find-certificate', '-a', '-p', path],
                               stdout=subprocess.PIPE, stderr=subprocess.DEVNULL,
                               timeout=PROBE_TIMEOUT)
        except Exception:
            continue          # таймаут або відмова політики: цей keychain пропущено
        if r.returncode == 0 and r.stdout:
            out += _ders(r.stdout.decode('utf-8', 'replace'))
    return out


def _roots_linux():
    """Стандартні bundle-файли дистрибутивів."""
    out = []
    for path in LINUX_BUNDLES:
        if os.path.isfile(path):
            out += _ders(_read(path))
    return out


def system_roots(platform=None):
    """Кореневі сертифікати ЦІЄЇ операційної системи -> список DER.

    Збій будь-якої гілки означає порожній список, ніколи виняток: довіра, зібрана з
    системи, це покращення, а не умова старту. `platform` існує для тестів."""
    plat = platform or sys.platform
    if plat.startswith('win'):
        collect = _roots_windows
    elif plat == 'darwin':
        collect = _roots_macos
    else:
        collect = _roots_linux
    try:
        return collect() or []
    except Exception:
        return []


# ── Складання набору ───────────────────────────────────────────────────────────

def default_cafile():
    """Bundle, яким процес користувався ДО нас. Запамʼятовується з першого разу.

    Памʼять тут не оптимізація, а коректність: install() перезаписує SSL_CERT_FILE на
    наш файл, тож без неї повторний виклик почав би складати набір сам із себе і
    втратив би точку відліку «скільки коренів було спочатку»."""
    global _default_cafile
    if _default_cafile is None:
        paths = ssl.get_default_verify_paths()
        for cand in (os.environ.get('SSL_CERT_FILE'), paths.cafile, paths.openssl_cafile):
            try:
                if cand and os.path.isfile(cand) and os.path.getsize(cand) > 0:
                    _default_cafile = cand
                    break
            except Exception:
                continue
        else:
            _default_cafile = ''
    return _default_cafile


def _accept(ders):
    """Лишає рівно те, що OpenSSL справді бере у сховище, без дублікатів.

    Перевірка кожного сертифіката ОКРЕМО, а не пачкою: сховище цілком може віддати
    сміття (обрізаний файл, чужий формат), і один поганий запис не сміє забрати з
    собою всі інші. Дублікати рахуємо по SHA-256 від DER, бо той самий корінь лежить
    і в certifi, і в Keychain."""
    probe = ssl.SSLContext(ssl.PROTOCOL_TLS_CLIENT)
    out, seen = [], set()
    for der in ders:
        if not isinstance(der, (bytes, bytearray)):
            continue
        raw = bytes(der)
        digest = hashlib.sha256(raw).digest()
        if digest in seen:
            continue
        try:
            probe.load_verify_locations(cadata=raw)
        except Exception:
            continue
        seen.add(digest)
        out.append(raw)
    return out


def _count_roots(path):
    """Скільки коренів OpenSSL СПРАВДІ бере з цього файла. 0 = не бере нічого.

    Єдина чесна міра придатності набору. Не розмір і не кількість рядків BEGIN, а те,
    що з файла дістає та сама бібліотека, яка потім перевірятиме сертифікат сервера.
    Нечитабельний, порожній і зіпсований файл дають нуль, і це відповідь, а не помилка."""
    try:
        if not path or not os.path.isfile(path) or os.path.getsize(path) <= 0:
            return 0
        probe = ssl.SSLContext(ssl.PROTOCOL_TLS_CLIENT)
        probe.load_verify_locations(cafile=path)
        return probe.cert_store_stats()['x509_ca']
    except Exception:
        return 0


def default_root_count():
    """Скільки коренів у bundle, який був до нас. Памʼятається так само, як його шлях."""
    global _default_roots
    if _default_roots is None:
        _default_roots = _count_roots(default_cafile())
    return _default_roots


def _fresh(path):
    """Чи можна перевикористати вже зібраний файл замість перебору сховища.

    Три дешеві умови (файл є, непорожній, молодший за CACHE_TTL) і одна дорога: OpenSSL
    мусить його прочитати і знайти там коренів не менше, ніж у дефолтному bundle.
    Дорога умова додана не для краси. Без неї зіпсований кеш віддавався наосліп, а
    install() ставив на нього SSL_CERT_FILE, і процес втрачав не одну фічу, а всю
    мережу: розмір і час у такого файла бездоганні, брехня лежить усередині (К1, К5).

    Порядок умов саме такий, бо дорога перевірка коштує два читання файла і має сенс
    лише тоді, коли решта вже сказала «так»."""
    try:
        if not (os.path.isfile(path) and os.path.getsize(path) > 0
                and (time.time() - os.path.getmtime(path)) < CACHE_TTL):
            return False
    except Exception:
        return False
    have, want = _count_roots(path), default_root_count()
    if have <= 0 or have < want:
        _log('кеш довіри непридатний: коренів %d, у дефолтному наборі %d, перезбираємо'
             % (have, want))
        return False
    return True


def _fallback(default, target):
    """Куди відступити, коли складання не дало виграшу. -> шлях або порожній рядок.

    Дефолтний bundle, якщо він є: він щойно працював, і це головне правило модуля.
    Якщо його немає взагалі, лишається хіба колись зібраний файл, і віддати його можна
    ЛИШЕ коли OpenSSL із нього щось бере. Інакше install() поставить SSL_CERT_FILE на
    нечитабельний файл і забере в процесу всю мережу, тобто зробить рівно те, від чого
    ми тут захищаємось (К5). Порожній рядок чесніший: він лишає все як було."""
    if default:
        return default
    return target if _count_roots(target) > 0 else ''


def build_bundle(home):
    """Зібрати <home>/ca-trust.pem = поточний bundle + корені ОС. -> шлях до довіри.

    Повертає шлях до ДЕФОЛТНОГО bundle (а не до нашого файла) щоразу, коли складання
    не дало виграшу. Це головне правило тут: зіпсований файл довіри забирає в
    застосунку не одну фічу, а всю мережу, тому будь-який сумнів вирішується на
    користь того, що вже працює. Порожній файл не пишемо ніколи."""
    target = os.path.join(home, BUNDLE_NAME)
    if _fresh(target):
        return target                      # К8: набір не змінюється щогодини

    default = default_cafile()
    base = _accept(_ders(_read(default))) if default else []
    merged = _accept(base + system_roots())
    if not merged or len(merged) < len(base):
        return _fallback(default, target)

    body = []
    for der in merged:
        try:
            body.append(ssl.DER_cert_to_PEM_cert(der))
        except Exception:
            continue
    if not body:
        return _fallback(default, target)

    tmp = target + '.tmp'
    try:
        os.makedirs(home, exist_ok=True)
        with open(tmp, 'w', encoding='utf-8') as fh:
            fh.write(''.join(body))
        # Читаємо ЩОЙНО НАПИСАНИЙ файл так само, як його читатиме OpenSSL у бою. Якщо
        # тут щось не так, старий файл лишається на місці і мережа не страждає.
        probe = ssl.SSLContext(ssl.PROTOCOL_TLS_CLIENT)
        probe.load_verify_locations(cafile=tmp)
        # Обидві сторони порівняння міряються ОДНАКОВО: скільки коренів OpenSSL бере зі
        # сховища. Раніше зліва стояв цей лічильник, а справа len(base), тобто кількість
        # ПРИЙНЯТИХ блобів, і це різні речі. Keychain віддає сертифікати, які OpenSSL у
        # файл кладе, але коренями не рахує (x509_ca менше за x509): на цій машині 195
        # блобів дають 193 корені. Щойно наш власний набір ставав дефолтним для
        # наступного процесу (install() пише SSL_CERT_FILE, діти його успадковують),
        # умова 193 < 195 спрацьовувала ЗАВЖДИ, складання відкочувалось на старий файл, і
        # корінь антивіруса, що приїхав у сховище пізніше за перший запуск, не потрапляв
        # у набір уже ніколи, навіть через invalidate(). Це та сама міра, що й у _fresh().
        if probe.cert_store_stats()['x509_ca'] < default_root_count():
            raise RuntimeError('зібраний набір вужчий за дефолтний')
        os.replace(tmp, target)
        return target
    except Exception:
        try:
            os.unlink(tmp)
        except Exception:
            pass
        return _fallback(default, target)


# ── Вмикання на весь процес ────────────────────────────────────────────────────

def install(home):
    """Зібрати набір довіри і застосувати його до ВСЬОГО процесу. -> шлях до файла.

    Дві дії, і обидві потрібні. Змінні середовища вмикають набір там, де контекст
    створює OpenSSL сам, і заразом передають його дочірнім процесам: NODE_EXTRA_CA_CERTS
    лагодить на такій машині ще й claude CLI, який ми запускаємо на кожен хід.
    Підміна ssl._create_default_https_context покриває вже написані urlopen: http.client
    бере фабрику з модуля ssl у момент зʼєднання, тому жодне з десятків місць виклику
    правити не треба.

    Ідемпотентна і мовчазна: якщо зібрати не вдалось, лишається рівно та поведінка, що
    була до виклику."""
    try:
        os.makedirs(home, exist_ok=True)
    except Exception:
        pass
    try:
        path = build_bundle(home)
    except Exception:
        path = default_cafile()
    if not path or not os.path.isfile(path):
        return path or ''

    for var in ('SSL_CERT_FILE', 'REQUESTS_CA_BUNDLE', 'NODE_EXTRA_CA_CERTS'):
        os.environ[var] = path

    def _https_context(purpose=ssl.Purpose.SERVER_AUTH, *, cafile=None, capath=None,
                       cadata=None):
        # Явно переданий cafile поважаємо: той, хто його вказав, знає більше за нас.
        return ssl.create_default_context(purpose, cafile=cafile or path,
                                          capath=capath, cadata=cadata)

    ssl._create_default_https_context = _https_context
    return path


def invalidate(home):
    """Викинути зібраний набір і скласти його заново. -> {before, after, path, message}.

    Єдина точка самолікування, і потрібна вона рівно тому, що придатність набору не
    завжди видно з нього самого. Класичний випадок: корпоративний корінь приїхав у
    сховище ОС ПІЗНІШЕ за перший запуск застосунку. Набір при цьому валідний,
    непорожній, свіжий і ШИРШИЙ за дефолтний, просто без одного потрібного кореня, тому
    перевірка вмісту з _fresh() його не чіпає і не має чіпати. Єдиний, хто знає правду,
    це відмова перевірки сертифіката на живому запиті, і саме вона сюди приводить.

    Памʼять про дефолтний bundle скидається разом із файлом: без цього повторне
    складання взяло б за точку відліку наш власний набір і не побачило б різниці.
    Змінні довіри, що вели на викинутий файл, знімаються ДО складання з тієї ж причини,
    плюс вони не сміють ані хвилини вказувати на файл, якого вже немає.

    Складання йде через install(), а не через build_bundle(): набір, який нікуди не
    ввімкнено, нічого не лікує, а змінні оточення після видалення файла вказують у
    порожнечу. Хто кличе цю функцію і як часто, вирішує місце помилки, тут обмежень
    немає навмисно: рахувати спроби мусить той, хто знає, що це той самий запит."""
    target = os.path.join(home, BUNDLE_NAME)
    before = _count_roots(target)

    for var in ('SSL_CERT_FILE', 'REQUESTS_CA_BUNDLE', 'NODE_EXTRA_CA_CERTS'):
        if os.environ.get(var) == target:
            os.environ.pop(var, None)
    try:
        os.unlink(target)
    except Exception:
        pass                      # файла могло не бути, це не привід не збирати новий

    global _default_cafile, _default_roots
    _default_cafile = None
    _default_roots = None

    path = install(home)
    after = _count_roots(path)
    msg = ('набір довіри перезібрано після помилки перевірки сертифіката: '
           'коренів %d -> %d, файл %s' % (before, after, path or 'немає'))
    _log(msg)
    return {'before': before, 'after': after, 'path': path, 'message': msg}


if __name__ == '__main__':
    # Ручний замір: `python3 tls_trust.py` друкує ДО і ПІСЛЯ на цій машині.
    import tempfile
    before = ssl.create_default_context().cert_store_stats()['x509_ca']
    out = install(os.environ.get('CHATVIEW_HOME') or tempfile.mkdtemp(prefix='cvtls-'))
    after = ssl._create_default_https_context().cert_store_stats()['x509_ca']
    print('дефолт   : %s' % default_cafile())
    print('набір    : %s' % out)
    print('коренів  : %d -> %d (+%d)' % (before, after, after - before))
