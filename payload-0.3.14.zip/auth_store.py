"""Серверна половина Фази 1 логіну ChatView.

Три речі, яких браузер зробити не може, і саме тому вони тут:

1. Кеш сесії на диску (``CHATVIEW_HOME/session.json``). localStorage живе в профілі
   вебвʼю, а спека 3.3 вимагає, щоб після ПЕРШОГО входу на цій машині мережа більше
   не була потрібна. Профіль вебвʼю чиститься оновленням апки; тека CHATVIEW_HOME ні.
2. Локальний кеш налаштувань (``CHATVIEW_HOME/user-settings.json``). Той самий доказ:
   в офлайні локальний файл і є істина, а rev доїде при наступному підключенні.
3. Одноразовий loopback-слухач під OAuth. Порт застосунку динамічний (entry.py:143
   бере вільний у 5555..5600), тому редірект на нього зареєструвати наперед неможливо.
   Слухач сідає ПОЗА цим діапазоном і глушиться одразу після того, як код приїхав.

Свідомо окремий модуль, а не ще пʼятсот рядків у server.py: усе тут тестується без
підняття HTTP-сервера ChatView, і рівно це роблять tests/test_auth_store.py.
"""

import json
import os
import socket
import socketserver
import threading
import time
import uuid
from http.server import BaseHTTPRequestHandler, HTTPServer
from urllib.parse import parse_qs, urlparse

# Діапазон, у якому entry.py підбирає порт для самої апки. Слухач НЕ має права сюди
# сісти: інакше вхід через Google конфліктував би з живим ChatView, і зламалось би це
# тихо, бо обидва слухають те саме, а відповідає той, хто встиг перший.
APP_PORT_MIN = 5555
APP_PORT_MAX = 5600

# Де шукаємо порт під слухач. Свідомо далеко від діапазону апки і від типових портів
# дев-серверів (3000/5173/8080), щоб не відбирати порт у чужого процесу.
LOOPBACK_PORT_MIN = 8765
LOOPBACK_PORT_MAX = 8825

# Скільки слухач живе без відповіді. Це стеля на людину в діалозі Google, а не таймаут
# мережі: порт, забутий відкритим після скасованого входу, це і є витік.
LOOPBACK_TTL_SEC = 300


# ─────────────────────────── кеш сесії і налаштувань ───────────────────────────

def session_path(home):
    return os.path.join(home, 'session.json')


def settings_path(home):
    return os.path.join(home, 'user-settings.json')


def _read_json(path):
    try:
        with open(path, encoding='utf-8') as f:
            data = json.load(f)
        return data if isinstance(data, dict) else None
    except Exception:
        return None


def _replace_atomic(tmp, path, attempts=50, pause=0.01):
    """os.replace, який переживає Windows.

    На POSIX перейменування поверх відкритого файлу дозволене завжди, тому там цикл
    відпрацьовує з першої спроби. На Windows файл, який ХТОСЬ тримає відкритим, не
    можна ні замінити, ні видалити: MoveFileEx повертає ERROR_ACCESS_DENIED, python
    показує його як PermissionError(13, 'Access is denied'). Тримати його може або
    сусідній потік, який саме читає кеш, або антивірус чи індексатор, який відкрив
    щойно створений файл на пів-секунди.

    Заміряно на windows-раннері CI: 24 одночасні записи налаштувань дали 9
    PermissionError з 24. Для користувача це виглядало б як «вхід не зберігся»,
    причому випадково, бо перший потік свій запис таки проводив. Пауза тут коротка
    (до пів секунди сумарно), бо чужий хендл живе мілісекунди; якщо права справді
    відібрані, остання спроба чесно кидає виняток далі.
    """
    for attempt in range(attempts):
        try:
            os.replace(tmp, path)
            return
        except PermissionError:
            if attempt == attempts - 1:
                raise
            time.sleep(pause)


def _write_json(path, data):
    """Атомарний запис: пишемо в сусідній тимчасовий файл і перейменовуємо.

    Прямий open('w') на пів-секунди лишає файл порожнім, і саме в цю щілину влучає
    старт апки, який читає кеш сесії. Наслідок виглядав би як «іноді після оновлення
    просить увійти заново», тобто як плаваючий баг без причини.

    Імʼя тимчасового файлу УНІКАЛЬНЕ на кожен запис, і це не косметика. Сервер
    багатопотоковий, тому два записи легко перекриваються в часі. З фіксованим
    `session.json.tmp` виходило так: обидва створюють ОДИН файл, перший os.replace
    його забирає, і другий падає з ENOENT. Заміряно на живому прогоні: рівно один
    400 на кожен вхід, причому запис першого потоку встигав пройти, тому кеш на диску
    виглядав правильним і баг мовчав. Такий тихий збій найдорожчий: усе працює, поки
    одного разу не програє гонку саме та спроба, що була єдиною.
    """
    d = os.path.dirname(path) or '.'
    os.makedirs(d, exist_ok=True)
    tmp = '%s.%d.%d.tmp' % (path, os.getpid(), threading.get_ident())
    try:
        with open(tmp, 'w', encoding='utf-8') as f:
            json.dump(data, f, ensure_ascii=False, indent=2)
            f.flush()
            os.fsync(f.fileno())
        _replace_atomic(tmp, path)
    except Exception:
        try:
            os.remove(tmp)
        except Exception:
            pass
        raise


def read_session(home):
    """Кешована сесія або None. Побитий файл = «сесії нема», без винятку."""
    data = _read_json(session_path(home))
    if not data:
        return None
    if not data.get('user_id') or not data.get('refresh_token'):
        return None
    return data


def write_session(home, session):
    # Помилка називає, ЧОГО саме бракує. Голе «bad session» у логах браузера це рядок,
    # який виглядає діагностикою, але не звужує пошук ні на крок: полів шість, а причин
    # відмови дві, і без імені поля їх не розрізнити.
    if not isinstance(session, dict):
        raise ValueError('bad session: не обʼєкт')
    missing = [k for k in ('user_id', 'refresh_token') if not session.get(k)]
    if missing:
        raise ValueError('bad session: бракує %s (є: %s)'
                         % (', '.join(missing), ', '.join(sorted(session.keys())) or 'нічого'))
    keep = ('user_id', 'email', 'access_token', 'refresh_token', 'expires_at', 'saved_at')
    # Кладемо РІВНО відомі поля. Дзеркалити все, що надіслав клієнт, означало б, що
    # будь-яка майбутня властивість токена осідає на диску без жодного рішення.
    _write_json(session_path(home), {k: session.get(k) for k in keep})
    return True


def clear_session(home):
    """Вихід. Критерій приймання 9: токена в CHATVIEW_HOME не лишається."""
    path = session_path(home)
    existed = os.path.exists(path)
    for p in (path, path + '.tmp'):
        try:
            os.remove(p)
        except Exception:
            pass
    return existed


def read_settings(home):
    return _read_json(settings_path(home))


def write_settings(home, settings):
    if not isinstance(settings, dict):
        raise ValueError('bad settings')
    _write_json(settings_path(home), {
        'defaults': settings.get('defaults') or {},
        'presets': settings.get('presets') or [],
        'rev': int(settings.get('rev') or 1),
    })
    return True


# ─────────────────────────── одноразовий OAuth-слухач ───────────────────────────

_LOCK = threading.Lock()
_LISTENERS = {}


class _CallbackHandler(BaseHTTPRequestHandler):
    """Ловить рівно один редірект від Supabase і одразу гасить свій сервер."""

    record = None  # проставляє start_loopback

    def log_message(self, *args):  # тиша: це не веб-сервер, а разова поштова скринька
        pass

    def do_GET(self):
        q = parse_qs(urlparse(self.path).query)
        code = (q.get('code') or [''])[0]
        err = (q.get('error_description') or q.get('error') or [''])[0]
        rec = self.record
        with _LOCK:
            if rec is not None and rec.get('status') == 'pending':
                if code:
                    rec['status'] = 'code'
                    rec['code'] = code
                else:
                    rec['status'] = 'error'
                    rec['error'] = err or 'провайдер не повернув код'
        ok = bool(code)
        body = _CLOSE_PAGE_OK if ok else _CLOSE_PAGE_ERR.replace('{{err}}', _escape(err))
        raw = body.encode('utf-8')
        self.send_response(200)
        self.send_header('Content-Type', 'text/html; charset=utf-8')
        self.send_header('Content-Length', str(len(raw)))
        self.send_header('Cache-Control', 'no-store')
        self.end_headers()
        self.wfile.write(raw)
        # shutdown() блокує до зупинки serve_forever, тому з ЦЬОГО потоку його кликати
        # не можна: він і є той потік. Гасимо окремим, одразу після відповіді.
        threading.Thread(target=self.server.shutdown, daemon=True).start()


class _LoopbackServer(HTTPServer):
    """HTTPServer, який НЕ питає DNS про власну адресу.

    http.server.HTTPServer.server_bind після bind робить socket.getfqdn(host), тобто
    зворотний DNS-запит про 127.0.0.1. Відповідь потрібна лише як `server_name` для
    CGI-змінних, яких ми не віддаємо взагалі, а от ціна цього запиту залежить від
    чужого резолвера: там, де на зворотну зону нема відповіді, gethostbyaddr чекає
    таймаут.

    Заміряно на macos-раннері CI: POST /api/oauth-loopback-start не відповідав понад
    15 секунд і клієнт відвалювався по таймауту, тобто «Увійти через Google» на такій
    машині виглядало б як зависла кнопка. Решта сервера цього не зачепила лише тому,
    що ChatView стоїть на socketserver.ThreadingTCPServer, а той у DNS не ходить.
    """

    def server_bind(self):
        socketserver.TCPServer.server_bind(self)
        host, port = self.server_address[:2]
        self.server_name = str(host)
        self.server_port = port


def _escape(s):
    return (s or '').replace('&', '&amp;').replace('<', '&lt;').replace('>', '&gt;')


_CLOSE_PAGE_OK = """<!doctype html><html lang="uk"><meta charset="utf-8">
<title>Готово</title><style>
body{margin:0;min-height:100vh;display:flex;align-items:center;justify-content:center;
font:15px/1.5 -apple-system,system-ui,sans-serif;background:#0d1117;color:#e6edf3}
div{text-align:center;max-width:22rem;padding:1.5rem}b{display:block;font-size:1.1rem;margin-bottom:.4rem}
p{color:#8b949e;margin:0}</style>
<div><b>Готово</b><p>Вкладку можна закрити і повернутись у ChatView.</p></div>"""

_CLOSE_PAGE_ERR = """<!doctype html><html lang="uk"><meta charset="utf-8">
<title>Не вийшло</title><style>
body{margin:0;min-height:100vh;display:flex;align-items:center;justify-content:center;
font:15px/1.5 -apple-system,system-ui,sans-serif;background:#0d1117;color:#e6edf3}
div{text-align:center;max-width:22rem;padding:1.5rem}b{display:block;font-size:1.1rem;margin-bottom:.4rem;color:#f85149}
p{color:#8b949e;margin:0}</style>
<div><b>Вхід не завершився</b><p>{{err}}</p></div>"""


def _free_port():
    """Вільний порт ПОЗА діапазоном апки. Перебираємо явно, а не беремо ефемерний.

    Ефемерний порт (bind на 0) міг би впасти всередину 5555..5600, і тоді редірект
    сів би на порт, який завтра займе сама апка. Явний перебір робить гарантію
    діапазону властивістю коду, а не везінням.
    """
    for port in range(LOOPBACK_PORT_MIN, LOOPBACK_PORT_MAX + 1):
        if APP_PORT_MIN <= port <= APP_PORT_MAX:
            continue
        s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        try:
            s.bind(('127.0.0.1', port))
            return port
        except OSError:
            continue
        finally:
            s.close()
    raise RuntimeError('немає вільного порту під слухач входу')


def start_loopback(path='/callback'):
    """Підняти одноразовий слухач. Повертає {id, port, redirectUrl}."""
    _sweep()
    port = _free_port()
    rec = {
        'id': uuid.uuid4().hex,
        'port': port,
        'status': 'pending',
        'code': None,
        'error': None,
        'created': time.time(),
        'server': None,
    }
    handler = type('_H', (_CallbackHandler,), {'record': rec})
    httpd = _LoopbackServer(('127.0.0.1', port), handler)
    rec['server'] = httpd
    threading.Thread(target=httpd.serve_forever, kwargs={'poll_interval': 0.2}, daemon=True).start()
    with _LOCK:
        _LISTENERS[rec['id']] = rec
    # Адреса ЗАВЖДИ localhost, а не 127.0.0.1: у списку дозволених редіректів Supabase
    # стоїть шаблон http://localhost:*/**, і хост має збігатись буквально.
    return {'id': rec['id'], 'port': port, 'redirectUrl': 'http://localhost:%d%s' % (port, path)}


def loopback_result(lid):
    _sweep()
    with _LOCK:
        rec = _LISTENERS.get(lid)
        if not rec:
            return {'status': 'gone'}
        return {'status': rec['status'], 'code': rec.get('code'), 'error': rec.get('error')}


def stop_loopback(lid):
    with _LOCK:
        rec = _LISTENERS.pop(lid, None)
    if not rec:
        return False
    _shutdown(rec)
    return True


def loopback_ports():
    """Живі порти. Для доказу «піднявся на час входу і закрився після»."""
    with _LOCK:
        return sorted(r['port'] for r in _LISTENERS.values())


def _shutdown(rec):
    srv = rec.get('server')
    if not srv:
        return
    try:
        srv.shutdown()
    except Exception:
        pass
    try:
        srv.server_close()
    except Exception:
        pass
    rec['server'] = None


def _sweep():
    """Прибрати протухлі. Скасований вхід не має лишати по собі відкритий порт."""
    now = time.time()
    dead = []
    with _LOCK:
        for lid, rec in list(_LISTENERS.items()):
            if now - rec['created'] > LOOPBACK_TTL_SEC:
                dead.append(_LISTENERS.pop(lid))
    for rec in dead:
        _shutdown(rec)
