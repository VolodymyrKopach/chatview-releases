// skill-run.cjs: ЗАКРИТИЙ ЗАПУСК УМІННЯ ПОМІЧНИКА (specs/harness-80).
//
// НАВІЩО ОКРЕМИЙ МОДУЛЬ. Модель бачить каталог помічників і вміє їх ставити, але
// покликати не може, тому весь шар помічників для неї вітрина: видно, не візьмеш. Запуск
// потрібен. Але помічник це інструкції ПЛЮС враппери, які запускають команди, тобто
// «виконай будь-яке вміння» дорівнює рядку «запуск команд» із `forbidden` того самого
// реєстру. Тому весь ризик зібраний в одному файлі, який тільки цим і займається, а
// `server.cjs` лишається тонким містком над HTTP і, як і раніше, не імпортує ані `fs`,
// ані `child_process` (на цьому стоять тести гаджетів і повідомлень). Той самий прийом,
// що з `canvas-widgets.cjs`: сусідній модуль читає СВОЇ файли, до чужих даних це
// відношення не має.
//
// ТРИ ЗАСУВИ, і жоден не покладається на два інші.
//
//   1. ДЕФОЛТ ЗАБОРОНА. Виконується лише те, що названо в `skillRun.allowed`
//      (capabilities.json). Нове вміння в каталозі німе, доки його не впишуть руками в
//      комміті. Модель безпеки взята ТА САМА, що вже працює на гаджетах: перелік
//      дозволеного оголошений заздалегідь, усе інше відхиляється з переліком дозволеного.
//
//   2. ЧОРНИЙ СПИСОК ПЕРЕМАГАЄ БІЛИЙ. Помічник із `skillRun.neverAllowed` не запуститься,
//      навіть якщо хтось вписав його в дозволені. Це не подвійна параноя, а розділення
//      повноважень: надсилання назовні в цьому проєкті дозволяє ЛИШЕ людина, і одна
//      неуважна правка реєстру не повинна цього скасовувати.
//
//   3. КОД БЕРЕТЬСЯ З РЕПОЗИТОРІЮ (`helpers/<id>/`), а не зі встановленої копії під
//      `.claude/skills/<id>/`. Модель уміє ставити помічників (`helper_install`), тож
//      запуск встановленої копії замикав би ланцюг «постав чуже -> запусти чуже»
//      всередині самої моделі. З тієї ж причини перелік дозволеного живе в реєстрі
//      репозиторію, а не у фронтматері SKILL.md: позначка, яка приїжджає РАЗОМ із
//      помічником, означала б, що дозвіл собі підписує той, кого він мав обмежити.
//
// Аргументи йдуть масивом без шела, кожен параметр перевіряється шаблоном із реєстру, а
// оточення дитини збирається мінімальне: ані ключів, ані решти середовища вона не бачить.
'use strict';

const fs = require('fs');
const path = require('path');
const { spawn } = require('child_process');
const { load } = require('./registry.cjs');

// Тека помічників перевизначається CHATVIEW_HELPERS_DIR (потрібно тестам і пакованій
// збірці), рівно як шлях до реєстру віджетів канви в canvas-widgets.cjs.
const DEFAULT_HELPERS_DIR = path.resolve(__dirname, '..', '..', '..', '..', 'helpers');
const DEFAULT_TIMEOUT = 60000;
const MAX_OUTPUT = 40000;

/** Відмова, яку МОЖНА показати людині: причина плюс наступна дія (К9). */
class SkillRunError extends Error {}

function helpersDir() {
  return process.env.CHATVIEW_HELPERS_DIR || DEFAULT_HELPERS_DIR;
}

function config() {
  const cfg = load().skillRun || {};
  return {
    allowed: Array.isArray(cfg.allowed) ? cfg.allowed : [],
    never: new Set(Array.isArray(cfg.neverAllowed) ? cfg.neverAllowed : []),
  };
}

/** Що модель має право запустити просто зараз. Чорний список вирізається ТУТ, тому
 *  помилково дозволене не потрапляє навіть у перелік, не те що у виконання. */
function runnable() {
  const { allowed, never } = config();
  return allowed
    .filter(e => e && e.id && e.skill && !never.has(e.id))
    .map(e => ({
      id: e.id, skill: e.skill, summary: e.summary || '',
      params: Object.keys(e.params || {}),
    }));
}

const runnableNames = () =>
  runnable().map(e => `${e.id} ${e.skill}`).join(', ') || '(наразі нічого)';

function findSkill(id, skill) {
  const { allowed, never } = config();
  if (never.has(id)) {
    throw new SkillRunError(
      `Не запущено нічого: помічника «${id}» модель не запускає ніколи, і ця заборона ` +
      'сильніша за будь-який дозвіл у реєстрі. Він або шле щось назовні, або розширює ' +
      'права, а надсилати назовні в цьому проєкті має право лише людина: попросіть її ' +
      `зробити це руками. Запускати можна: ${runnableNames()}.`);
  }
  const hit = allowed.find(e => e && e.id === id && e.skill === skill);
  if (!hit) {
    const same = allowed.filter(e => e && e.id === id).map(e => e.skill);
    throw new SkillRunError(
      `Не запущено нічого: вміння «${skill}» помічника «${id}» не позначене як запускне, ` +
      'а дефолт тут це заборона. ' +
      (same.length ? `У «${id}» запускні: ${same.join(', ')}. ` : '') +
      `Усе запускне: ${runnableNames()}; його ж показує helpers_list полем runnable. ` +
      'Решту запускає людина руками.');
  }
  return hit;
}

/** Параметри -> аргументи командного рядка. Шаблон «{імʼя}» це ОКРЕМИЙ аргумент цілком,
 *  тому склеїти два значення в одне або дописати прапорець збоку неможливо в принципі. */
function skillArgs(entry, params) {
  if (params !== undefined && params !== null &&
      (typeof params !== 'object' || Array.isArray(params))) {
    throw new SkillRunError(
      'Параметр «params» має бути обʼєктом, напр. {"slug": "harness-80"}. Які параметри ' +
      `бере «${entry.id} ${entry.skill}», видно в helpers_list полем runnable.`);
  }
  const declared = entry.params || {};
  const given = params || {};
  // Зайвий параметр це ВІДМОВА, а не мовчазне викидання: модель, яка думає, що передала
  // прапорець, інакше рапортує людині виконання того, чого не було.
  const extra = Object.keys(given)
    .filter(k => !Object.prototype.hasOwnProperty.call(declared, k));
  if (extra.length) {
    throw new SkillRunError(
      `Не запущено нічого: вміння «${entry.id} ${entry.skill}» не бере ` +
      `${extra.map(k => `«${k}»`).join(', ')}. ` +
      (Object.keys(declared).length
        ? `Воно бере: ${Object.keys(declared).join(', ')}.`
        : 'Воно не бере жодного параметра.'));
  }
  const values = {};
  for (const name of Object.keys(declared)) {
    const rule = declared[name] || {};
    const raw = given[name];
    if (raw === undefined || raw === null || raw === '') {
      if (rule.required) {
        throw new SkillRunError(
          `Не запущено нічого: бракує обовʼязкового параметра «${name}» для ` +
          `«${entry.id} ${entry.skill}». ${rule.description || ''}`.trim());
      }
      values[name] = null;
      continue;
    }
    const val = String(raw);
    if (rule.pattern && !new RegExp(rule.pattern).test(val)) {
      throw new SkillRunError(
        `Не запущено нічого: параметр «${name}» = «${val}» не того вигляду, який бере ` +
        `«${entry.id} ${entry.skill}» (${rule.pattern}). ${rule.description || ''}`.trim());
    }
    values[name] = val;
  }
  const argv = [];
  for (const tpl of (entry.run && entry.run.args) || []) {
    const m = /^\{([a-zA-Z0-9_]+)\}$/.exec(String(tpl));
    if (!m) { argv.push(String(tpl)); continue; }
    if (!Object.prototype.hasOwnProperty.call(values, m[1])) {
      throw new SkillRunError(
        `Реєстр здатностей зламаний: «${entry.id} ${entry.skill}» підставляє «${m[1]}», ` +
        'якого нема серед його оголошених параметрів. Це правиться в capabilities.json.');
    }
    if (values[m[1]] !== null) argv.push(values[m[1]]);
  }
  return argv;
}

/** Куди саме бʼємо. Шлях складається з двох частин реєстру і перевіряється на вихід за
 *  теку помічника: «file» з крапками вгору не дає нічого, крім відмови. */
function target(entry) {
  const run = entry.run || {};
  if (run.interpreter !== 'node') {
    throw new SkillRunError(
      `Не запущено нічого: реєстр оголосив для «${entry.id} ${entry.skill}» двигун ` +
      `«${run.interpreter || 'не названо'}», а місток запускає лише «node». Вміння на ` +
      'іншому двигуні поки лишається за людиною.');
  }
  const dir = path.resolve(helpersDir(), entry.id);
  const file = path.resolve(dir, String(run.file || ''));
  const rel = path.relative(dir, file);
  if (!rel || rel.startsWith('..') || path.isAbsolute(rel)) {
    throw new SkillRunError(
      `Не запущено нічого: реєстр показує на файл поза текою помічника «${entry.id}». ` +
      'Це правиться в capabilities.json.');
  }
  if (!fs.existsSync(file)) {
    throw new SkillRunError(
      `Не запущено нічого: враппера «${run.file}» помічника «${entry.id}» нема за ` +
      `шляхом ${file}. Перевірте, що репозиторій цілий, або вкажіть теку помічників ` +
      'змінною CHATVIEW_HELPERS_DIR.');
  }
  return { file, cwd: path.resolve(helpersDir(), '..') };
}

function spawnWrapper(file, argv, cwd, timeoutMs) {
  return new Promise((resolve, reject) => {
    const started = Date.now();
    // Оточення МІНІМАЛЬНЕ: ключів, токенів і решти середовища дитина не бачить. Це не
    // косметика, а другий поверх до «нічого не шле»: без ключа платний виклик назовні не
    // поїде, навіть якщо колись сюди потрапить вміння, яке його вміє.
    const env = {
      PATH: process.env.PATH || '/usr/bin:/bin',
      HOME: process.env.HOME || '',
      LANG: process.env.LANG || 'en_US.UTF-8',
      TMPDIR: process.env.TMPDIR || '/tmp',
    };
    let child;
    try {
      // Масив аргументів, жодного шела: підставити «; rm -rf /» нема куди.
      child = spawn(process.execPath, [file, ...argv],
                    { cwd, env, stdio: ['ignore', 'pipe', 'pipe'] });
    } catch (e) {
      reject(new SkillRunError(`Не вдалось запустити ${file}: ${e.message}`));
      return;
    }
    let out = '', errOut = '', killed = false;
    const timer = setTimeout(() => { killed = true; child.kill('SIGKILL'); }, timeoutMs);
    child.stdout.on('data', c => { out += c; });
    child.stderr.on('data', c => { errOut += c; });
    child.on('error', e => {
      clearTimeout(timer);
      reject(new SkillRunError(`Не вдалось запустити ${file}: ${e.message}`));
    });
    child.on('close', code => {
      clearTimeout(timer);
      if (killed) {
        reject(new SkillRunError(
          `Вміння «${path.basename(file)}» не вклалось у ${Math.round(timeoutMs / 1000)} ` +
          'секунд і було зупинене. Що воно встигло зробити, невідомо, тому вважати його ' +
          'виконаним не можна.'));
        return;
      }
      resolve({ code, out, errOut, ms: Date.now() - started });
    });
  });
}

/** Виконати вміння. Повертає те, що ВІДДАВ ПРОЦЕС (К2), і кидає, якщо він скінчився
 *  кодом, не оголошеним для цього вміння (К3). */
async function run(id, skill, params) {
  const entry = findSkill(id, skill);
  const argv = skillArgs(entry, params);
  const { file, cwd } = target(entry);
  const timeoutMs = Number(entry.timeoutMs) > 0 ? Number(entry.timeoutMs) : DEFAULT_TIMEOUT;
  const res = await spawnWrapper(file, argv, cwd, timeoutMs);

  let output = res.out + (res.errOut ? (res.out ? '\n' : '') + res.errOut : '');
  const truncated = output.length > MAX_OUTPUT;
  if (truncated) {
    // Обрив із названою причиною: мовчазно обрізаний вивід читається як повний.
    output = output.slice(0, MAX_OUTPUT) +
      `\n… обрізано: помічник надрукував ${res.out.length + res.errOut.length} символів, ` +
      `показано перші ${MAX_OUTPUT}.`;
  }
  // Код виходу поза оголошеним для ЦЬОГО вміння це не результат, а поломка. Для
  // `spec check` одиниця це чесний вирок «спека не зелена», і реєстр каже це прямо,
  // тому один список кодів на всіх тут не годиться.
  const ok = Array.isArray(entry.okExit) && entry.okExit.length ? entry.okExit : [0];
  if (!ok.includes(res.code)) {
    throw new SkillRunError(
      `Вміння «${id} ${skill}» завершилось кодом ${res.code}, а робочими для нього ` +
      `оголошені ${ok.join(', ')}. Це не «запустив»: помічник почався і зламався. ` +
      `Ось що він устиг сказати:\n${output.slice(-1500) || '(нічого)'}`);
  }
  return { helper: id, skill, ran: `${file} ${argv.join(' ')}`.trim(),
           exitCode: res.code, durationMs: res.ms, output, truncated };
}

module.exports = { SkillRunError, runnable, run, helpersDir, DEFAULT_HELPERS_DIR };
