// canvas-widgets.cjs: ПЕРЕЛІК ТИПІВ ВІДЖЕТІВ КАНВИ, прочитаний з того самого файла,
// яким малює сам рендерер.
//
// НАВІЩО ОКРЕМИЙ ЧИТАЧ, А НЕ СПИСОК У РЕЄСТРІ. Другий, руками ведений перелік типів
// розʼїжджається з першим: це вже спіймано на віджетах чату (specs/model-widget-contract,
// К4) і закрито тестом паритету, який ПАРСИТЬ живий реєстр, а не копіює його. Тут та сама
// техніка, тільки джерело інше і це принципово: віджет на канві малює
// `tools/canvas-cmd/src/shapes/HtmlWidgetShape.tsx:29` через `WIDGET_REGISTRY` з
// `tools/canvas-cmd/src/widgets/registry.ts`. Тип, якого там нема, дає на екрані
// «Unknown widget: X». Реєстр чату (`chatview/src/widgets/registry.tsx`, 44 типи) до канви
// стосунку не має: жодного спільного типу з ним нема, тому взяти перелік звідти означало б
// гарантовано намалювати «Unknown widget» на кожен виклик.
//
// Звідси ж беруться і РОЗМІРИ (`defaultSize`): К5 вимагає, щоб харнес дописав службове сам,
// а розмір за замовчуванням у кожного віджета свій (від 320x380 до 2050x11000).
//
// Шлях перевизначається CHATVIEW_CANVAS_REGISTRY (потрібно тестам і пакованій збірці).
// Файла нема = чесна відмова з назвою шляху, а НЕ «пропускаємо будь-який тип».
'use strict';

const fs = require('fs');
const path = require('path');

const DEFAULT_REGISTRY_TS = path.resolve(
  __dirname, '..', '..', '..', 'canvas-cmd', 'src', 'widgets', 'registry.ts');

function registryPath() {
  return process.env.CHATVIEW_CANVAS_REGISTRY || DEFAULT_REGISTRY_TS;
}

const ANCHOR = 'export const WIDGET_REGISTRY';
// Запис реєстру: ключ на двох пробілах, тіло до закривної дужки на тих самих двох
// пробілах. Вкладені обʼєкти (`defaultSize: { w, h }`) однорядкові, тому такий кінець
// однозначний.
const ENTRY = /^ {2}(?:'([^']+)'|"([^"]+)"|([A-Za-z0-9_$]+)):\s*\{([\s\S]*?)^ {2}\}/gm;
const LABEL = /label:\s*(?:'([^']*)'|"([^"]*)"|`([^`]*)`)/;
const SIZE = /defaultSize:\s*\{\s*w:\s*(\d+)\s*,\s*h:\s*(\d+)\s*\}/;

let cache = null;

/** [{type, label, w, h}] з живого registry.ts. Кидає, якщо файл не читається. */
function widgetTypes() {
  const file = registryPath();
  let src;
  try {
    src = fs.readFileSync(file, 'utf8');
  } catch (e) {
    throw new Error(
      `Перелік типів віджетів канви читається з ${file}, і цей файл недоступний ` +
      `(${e.code || e.message}). Без нього перевірити тип неможливо, а пускати ` +
      'будь-який тип означало б малювати «Unknown widget» на канві. ' +
      'Вкажіть шлях змінною CHATVIEW_CANVAS_REGISTRY.');
  }
  if (cache && cache.src === src) return cache.list;
  const at = src.indexOf(ANCHOR);
  if (at < 0) {
    throw new Error(
      `У ${file} нема «${ANCHOR}»: формат реєстру віджетів канви змінився, ` +
      'читач типів треба оновити разом з ним.');
  }
  const body = src.slice(at);
  const list = [];
  let m;
  ENTRY.lastIndex = 0;
  while ((m = ENTRY.exec(body)) !== null) {
    const type = m[1] || m[2] || m[3];
    const entry = m[4] || '';
    const label = LABEL.exec(entry);
    const size = SIZE.exec(entry);
    list.push({
      type,
      label: label ? (label[1] || label[2] || label[3]) : type,
      w: size ? Number(size[1]) : 360,
      h: size ? Number(size[2]) : 420,
    });
  }
  if (!list.length) {
    throw new Error(
      `З ${file} не витягнуто жодного типу віджета: формат реєстру змінився.`);
  }
  cache = { src, list };
  return list;
}

function byType() {
  const out = new Map();
  for (const w of widgetTypes()) out.set(w.type, w);
  return out;
}

/** Найближчі за написанням типи: підказка замість переліку на 158 рядків.
 *
 * Поріг тут навмисний. Перша редакція давала бал і за збіг ПЕРШОЇ ЛІТЕРИ, і на
 * «stat-grid» (тип із чату, на канві його нема) радила «sales-insights,
 * steal-features, sentry-monitor…»: підказка, яка не має стосунку до питання, гірша
 * за відсутність підказки, бо слабка модель бере з неї перший рядок. Тепер у список
 * потрапляє лише справжній збіг підрядком, а коли його нема, відмова просто веде до
 * canvas_widget_types. */
function nearest(name, limit) {
  const want = String(name || '').toLowerCase();
  const parts = want.split(/[^a-z0-9]+/).filter(Boolean);
  const scored = widgetTypes().map(w => {
    const t = w.type.toLowerCase();
    let score = 0;
    if (t === want) score += 100;
    if (t.includes(want) || want.includes(t)) score += 40;
    for (const p of parts) if (p.length > 2 && t.includes(p)) score += 10;
    return { w, score };
  }).filter(s => s.score >= 10);
  scored.sort((a, b) => b.score - a.score);
  return scored.slice(0, limit || 8).map(s => s.w.type);
}

module.exports = { registryPath, widgetTypes, byType, nearest, DEFAULT_REGISTRY_TS };
