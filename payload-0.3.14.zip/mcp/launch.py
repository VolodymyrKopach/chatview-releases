#!/usr/bin/env python3
"""launch.py: підйом MCP-сервера ChatView, коли `node` НЕ в PATH.

ЧОМУ ЦЕ ІСНУЄ. У `.mcp.json` командою стояло голе `node`, а клієнт спавнить MCP-сервери
з бідним PATH (`~/.local/bin:/usr/local/bin:/usr/bin:/bin`). Нода на цій машині живе під
nvm, тобто в PATH її нема, і `claude mcp list` віддавав:

    chatview: node tools/viz/chat/mcp/server.cjs
              ✘ Failed to connect - ENOENT: Executable not found in $PATH: "node"

Тобто всі 16 інструментів ChatView були недоступні ЖОДНОГО разу, і мовчки: асистент не
бачив ні інструментів, ні причини.

ЧОМУ САМЕ ТАК, а не абсолютним шляхом до ноди. Абсолютний шлях
(`~/.nvm/versions/node/v20.20.2/bin/node`) вмирає від першого `nvm install`, а на чужій
машині його нема взагалі. Тут натомість те саме правило, яким уже живе сам застосунок
(`server.py:_resolve_node_bin`, `runner.py:_resolve_node`): спершу PATH, потім відомі
місця менеджерів версій, і все це ГЛОБОМ, без жодної прибитої версії.

ЧОМУ ЛАУНЧЕР НА PYTHON. Нової залежності це не додає: ChatView сам написаний на Python
(`server.py`), і місток без запущеного застосунку безглуздий, тож python3 на машині вже
мусить бути. Зате python3 є в бідному PATH (`/usr/local/bin/python3`), а node нема, і
саме це різниця між «інструменти є» і «інструментів нема».

Windows. Команду в `.mcp.json` записано як `${CHATVIEW_MCP_PYTHON:-python3}`. Там, де
інтерпретатор зветься `python` або `py`, це лікується однією змінною середовища, без
правок у репозиторії:

    setx CHATVIEW_MCP_PYTHON python

Ноду сам лаунчер шукає і в Windows-місцях (nvm4w, Program Files, fnm, volta, asdf).
Точковий обхід: CHATVIEW_MCP_NODE=<повний шлях до node>.

Не знайшли ноду ніде: виходимо кодом 1 і кажемо ОДНЕ людське речення в stderr. Мовчазний
провал це рівно те, що ця правка лікує.

ОДНЕ ЗАСТЕРЕЖЕННЯ, заміряне, а не здогадане. Шлях у `args` клієнт резолвить від СВОГО
робочого каталогу (перевірено: `claude mcp list` з `tools/viz/chat` дає «Connection
closed», з кореня репозиторію «✔ Connected»), а `${CLAUDE_PROJECT_DIR}` у середовищі
спавна MCP не виставлений. Тобто клієнта треба піднімати з кореня репозиторію, як і для
решти записів у `.mcp.json` (meta-ads, playwright там такі самі). Сам server.cjs цей
лаунчер шукає ВІД СЕБЕ (`__file__`), тому теку mcp/ можна переносити цілком.
"""
import glob
import os
import shutil
import subprocess
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
SERVER_CJS = os.path.join(HERE, 'server.cjs')

WINDOWS = os.name == 'nt'
NODE_NAME = 'node.exe' if WINDOWS else 'node'


def _version_key(path):
    """Впорядкувати версії ЧИСЛАМИ, а не рядком: рядкове сортування ставить v9 вище
    за v20, і тоді місток піднімався б на найстарішій ноді в системі."""
    for part in path.replace('\\', '/').split('/'):
        digits = part.lstrip('v').split('.')
        if part.startswith('v') and all(d.isdigit() for d in digits if d):
            return tuple(int(d) for d in digits if d.isdigit())
    return ()


def _managed_candidates(home):
    """Місця, куди менеджери версій кладуть ноду. Тільки шаблони, жодної версії."""
    patterns = [
        os.path.join(home, '.nvm/versions/node/*/bin', NODE_NAME),          # nvm
        os.path.join(home, '.volta/tools/image/node/*/bin', NODE_NAME),     # volta
        os.path.join(home, '.asdf/installs/nodejs/*/bin', NODE_NAME),       # asdf
        os.path.join(home, '.local/share/fnm/node-versions/*/installation/bin', NODE_NAME),
        os.path.join(home, 'Library/Application Support/fnm/node-versions/*/installation/bin',
                     NODE_NAME),
        os.path.join(home, 'n/versions/node/*/bin', NODE_NAME),             # n
    ]
    if WINDOWS:
        for var in ('NVM_HOME', 'APPDATA', 'LOCALAPPDATA'):
            root = os.environ.get(var)
            if root:
                patterns.append(os.path.join(root, 'nvm', '*', NODE_NAME))  # nvm-windows
        patterns.append(os.path.join(home, 'AppData/Roaming/nvm/*', NODE_NAME))
        patterns.append(os.path.join(home, 'scoop/apps/nodejs/*', NODE_NAME))
    found = []
    for pattern in patterns:
        found.extend(glob.glob(pattern))
    # Найновіша версія перша: місток нічого екзотичного не вимагає, тому свіжа нода
    # завжди безпечніша за випадкову стару, що валялась у системі.
    return sorted(set(found), key=_version_key, reverse=True)


def _fixed_candidates():
    out = []
    if WINDOWS:
        for var in ('ProgramFiles', 'ProgramW6432', 'LOCALAPPDATA'):
            root = os.environ.get(var)
            if root:
                out.append(os.path.join(root, 'nodejs', NODE_NAME))
                out.append(os.path.join(root, 'Programs', 'nodejs', NODE_NAME))
    else:
        out += ['/opt/homebrew/bin/node', '/usr/local/bin/node', '/usr/bin/node',
                '/snap/bin/node']
    return out


def resolve_node():
    """Перший робочий кандидат. Порядок: явна вказівка, PATH, менеджери версій,
    типові інсталяції. Той самий порядок, що в server.py і runner.py."""
    explicit = (os.environ.get('CHATVIEW_MCP_NODE') or '').strip()
    if explicit:
        return explicit if os.path.isfile(explicit) else None
    on_path = shutil.which('node')
    if on_path:
        return on_path
    home = os.path.expanduser('~')
    for cand in _managed_candidates(home) + _fixed_candidates():
        if os.path.isfile(cand) and os.access(cand, os.X_OK):
            return cand
    return None


def fail(message):
    sys.stderr.write('ChatView MCP: ' + message + '\n')
    raise SystemExit(1)


def main():
    if not os.path.isfile(SERVER_CJS):
        fail('поруч із цим лаунчером нема server.cjs (%s). Схоже, теку mcp/ перенесли '
             'або зіпсували: поверніть файл на місце.' % SERVER_CJS)
    node = resolve_node()
    if not node:
        fail('не знайшов Node.js ні в PATH, ні там, куди його кладуть nvm, fnm, volta, '
             'asdf і звичайний інсталятор. Поставте Node 18+ або вкажіть шлях змінною '
             'CHATVIEW_MCP_NODE=/повний/шлях/до/node, і перезапустіть клієнта.')
    argv = [node, SERVER_CJS] + sys.argv[1:]
    if WINDOWS:
        # На Windows execv підміняє процес не так, як на POSIX, і клієнт бачить це як
        # смерть сервера. Тому лишаємось батьком і чесно віддаємо код виходу.
        raise SystemExit(subprocess.call(argv))
    os.execv(node, argv)


if __name__ == '__main__':
    main()
