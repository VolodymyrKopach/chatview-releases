#!/usr/bin/env node
// proof-shot.cjs: знімок вкладки, яку щойно перейменував MCP-місток.
// Головний доказ спеки specs/chatview-mcp/spec.md, розділ 7: «реальний виклик
// перейменування чату через MCP і скрін вкладки з новою назвою».
//
//   node tools/viz/chat/mcp/proof-shot.cjs <label> [base] [outDir]
'use strict';
const path = require('path');
const fs = require('fs');

const LABEL = process.argv[2] || 'МСР перейменував цей чат';
const BASE = process.argv[3] || 'http://127.0.0.1:5555';
const OUT = process.argv[4] || path.join(__dirname, '..', 'proof-mcp');
const PW = path.join(__dirname, '..', '..', '..', '..', 'node_modules', 'playwright');

(async () => {
  const { chromium } = require(PW);
  fs.mkdirSync(OUT, { recursive: true });
  const browser = await chromium.launch();
  for (const theme of ['light', 'dark']) {
    const page = await browser.newPage({
      viewport: { width: 1920, height: 900 },
      colorScheme: theme,
    });
    await page.goto(BASE, { waitUntil: 'domcontentloaded' });
    await page.waitForTimeout(6000);

    // Де саме на екрані живе нова назва: без цього «знайшов у DOM» ще не означає
    // «людина це бачить».
    const info = await page.evaluate((label) => {
      const hits = [];
      for (const el of document.querySelectorAll('*')) {
        if (el.children.length) continue;
        if ((el.textContent || '').trim() !== label) continue;
        const r = el.getBoundingClientRect();
        hits.push({ tag: el.tagName, x: Math.round(r.x), y: Math.round(r.y),
                    w: Math.round(r.width), h: Math.round(r.height),
                    visible: r.width > 0 && r.height > 0 });
      }
      return hits;
    }, LABEL);
    console.log(`[${theme}] знайдено на екрані:`, JSON.stringify(info));

    const el = page.getByText(LABEL, { exact: true }).first();
    try { await el.scrollIntoViewIfNeeded({ timeout: 3000 }); } catch { /* уже видно */ }
    await page.waitForTimeout(400);
    await page.screenshot({ path: path.join(OUT, `rename-${theme}.png`) });

    // Плюс крупний план смужки вкладок, щоб назву було видно без збільшення.
    const box = await el.boundingBox().catch(() => null);
    if (box) {
      const clip = {
        x: Math.max(0, box.x - 260), y: Math.max(0, box.y - 22),
        width: Math.min(1920, box.width + 520), height: box.height + 44,
      };
      await page.screenshot({ path: path.join(OUT, `rename-${theme}-zoom.png`), clip });
    }
    await page.close();
  }
  await browser.close();
})().catch(e => { console.error(e); process.exit(1); });
