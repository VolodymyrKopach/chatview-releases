"""registry.py: ЧИТАЧ єдиного реєстру здатностей ChatView (capabilities.json).

Другий споживач реєстру. Перший це mcp/server.cjs (список інструментів MCP), цей
модуль обслуговує `actions` у GET /api/project-state.

НАВІЩО ЦЕ ІСНУЄ (specs/chatview-mcp/spec.md). До цього самоопис і здатності жили
окремо: /api/project-state документував 4 дії, а сервер мав 81 POST-ендпоінт, серед них
і перейменування каналу. Асистент чесно відмовлявся бити навмання у незадокументований
ендпоінт, тобто дірка не лікувалась сама і не була видима. Тепер обидві поверхні
народжуються з ОДНОГО файла: розійтись вони фізично не можуть, а тест на збіг падає,
щойно хтось спробує.

Формулювання опису теж живе тут, а не в кожного споживача свій: інструмент, що змінює
стан, зобовʼязаний нести в описі те саме речення про явне прохання користувача.
"""
import json
import os

CAPABILITIES_FILE = os.path.join(os.path.dirname(os.path.abspath(__file__)),
                                 'capabilities.json')


def load(path=None):
    """Сирий реєстр як dict. Кидає, якщо файл зник або зіпсутий: тихий фолбек тут
    означав би повернення рівно того бага, який ми лікуємо (порожній самоопис)."""
    with open(path or CAPABILITIES_FILE, encoding='utf-8') as f:
        data = json.load(f)
    if not isinstance(data, dict) or not isinstance(data.get('capabilities'), list):
        raise ValueError('capabilities.json: очікується {capabilities: [...]}')
    return data


def capabilities(path=None):
    return load(path)['capabilities']


def names(path=None):
    return [c['name'] for c in capabilities(path)]


def describe(cap, consent_clause):
    """Опис здатності людською мовою: що робить, куди йде, і (для змінних) що це
    робиться тільки на явне прохання."""
    calls = ' + '.join('%s %s' % (c['method'], c['path']) for c in cap.get('calls', []))
    parts = [cap['summary'], calls]
    if cap.get('mutates'):
        parts.append(consent_clause)
    clean = [p.strip().rstrip('.') for p in parts if p and p.strip()]
    return '. '.join(clean) + '.'


def actions_map(path=None):
    """{імʼя_інструмента: людський опис} для поля `actions` у /api/project-state.

    Ключі тут це РІВНО імена інструментів MCP: на цьому стоїть тест на збіг двох
    поверхонь."""
    data = load(path)
    clause = data.get('consentClause', '')
    return {c['name']: describe(c, clause) for c in data['capabilities']}


if __name__ == '__main__':
    m = actions_map()
    print('%d здатностей:' % len(m))
    for k, v in m.items():
        print(' -', k, '::', v)
