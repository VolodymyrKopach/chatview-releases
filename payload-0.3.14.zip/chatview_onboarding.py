#!/usr/bin/env python3
"""Onboarding orchestration for the local Claude Code CLI the desktop shell drives.

Three jobs, done FOR the user so they never touch a terminal:
  1. detect   - is `claude` installed? is the user signed in?  (`claude auth status`)
  2. install  - run the official installer in the background       (`install.sh`)
  3. sign in  - launch `claude auth login`, which opens the browser itself

Design note (why this is robust): DETECTION IS DECOUPLED from the install/login
processes. Success is observed by asking `claude auth status --json` out-of-band,
never by parsing an installer log or a login TUI stream (which drift across CLI
versions). So even if a spawned process behaves oddly, the UI still learns the
true state on the next poll.

OS-specific primitives (install command, pty spawn) live on `Platform`
(chatview_platform.py); this module only orchestrates them. Pure stdlib so it
imports identically frozen (PyInstaller) and in dev.
"""
import json
import os
import subprocess
import threading
import time


# `claude auth status` shells out to the node CLI (~0.5-1s cold). Cache the answer
# briefly so a burst of /api/desktop/status polls does not spawn it repeatedly.
_AUTH_TIMEOUT = 8
_AUTH_TTL = 2.0
_auth_cache = {'at': 0.0, 'data': None}
_auth_lock = threading.Lock()

# Background install: single-flight. Progress is surfaced through status_snapshot,
# NOT streamed, so a 30s install never blocks the HTTP request.
_install_lock = threading.Lock()
_install = {'running': False, 'error': None}

# In-flight `claude auth login`. Kept so we can reap it once auth succeeds and so a
# second login tap does not spawn a duplicate.
_login_lock = threading.Lock()
_login = {'proc': None, 'error': None}


def auth_status(platform, force=False):
    """Return `claude auth status --json` as a dict (loggedIn/email/subscriptionType),
    or {} when Claude Code is absent or the probe fails. Cached for _AUTH_TTL sec."""
    claude = platform.find_claude()
    if not claude:
        return {}
    now = time.monotonic()
    with _auth_lock:
        if not force and _auth_cache['data'] is not None \
                and (now - _auth_cache['at']) < _AUTH_TTL:
            return _auth_cache['data']
    data = {}
    try:
        # platform.claude_env(): without $USER the CLI cannot read its Keychain
        # credentials and reports loggedIn:false, which used to freeze the
        # onboarding gate on a machine that WAS signed in.
        r = subprocess.run([claude, 'auth', 'status', '--json'],
                           capture_output=True, text=True, timeout=_AUTH_TIMEOUT,
                           env=platform.claude_env())
        parsed = json.loads((r.stdout or '').strip() or '{}')
        if isinstance(parsed, dict):
            data = parsed
    except Exception:
        data = {}
    with _auth_lock:
        _auth_cache['at'] = time.monotonic()
        _auth_cache['data'] = data
    return data


def _invalidate_auth_cache():
    with _auth_lock:
        _auth_cache['at'] = 0.0
        _auth_cache['data'] = None


def _invalidate_claude_cache():
    """Drop the platform layer's cached CLI lookup (best-effort)."""
    try:
        import chatview_platform
        chatview_platform.invalidate_claude_cache()
    except Exception:
        pass


def _searched_paths_text(platform):
    """Comma-joined list of the locations the last probe checked. Used in error
    text so 'not found' always says WHERE we looked."""
    try:
        rep = platform.claude_search_report()
        return ', '.join(s.get('path', '') for s in rep.get('searched', []))
    except Exception:
        return 'unknown'


# --- install ----------------------------------------------------------------

def _run_install(platform):
    cmd = platform.claude_install_command()
    if not cmd:
        with _install_lock:
            _install['running'] = False
            _install['error'] = 'auto-install is not supported on this OS'
        return
    err = None
    try:
        r = subprocess.run(cmd, capture_output=True, text=True, timeout=600,
                           **platform.process_group_kwargs())
        if r.returncode != 0:
            tail = (r.stderr or r.stdout or '').strip().splitlines()[-3:]
            err = 'installer exited %s: %s' % (r.returncode, ' '.join(tail))
    except Exception as e:  # pragma: no cover - network/OS dependent
        err = str(e)
    # The resolver caches misses for ~20s; drop that cache so the freshly
    # installed binary is seen NOW rather than on some later poll.
    _invalidate_claude_cache()
    # Truth check: did `claude` actually appear? (not-found beats a zero exit code)
    if not err and not platform.find_claude(refresh=True):
        err = ('installer finished but `claude` was not found afterwards; looked in: %s'
               % _searched_paths_text(platform))
    with _install_lock:
        _install['running'] = False
        _install['error'] = err


def start_install(platform):
    """Kick off the installer in the background (single-flight). Returns immediately;
    the UI polls status_snapshot() to see `found` flip true (or an install error)."""
    if platform.find_claude():
        return {'ok': True, 'status': 'already', 'path': platform.find_claude()}
    with _install_lock:
        if _install['running']:
            return {'ok': True, 'status': 'running'}
        if platform.claude_install_command() is None:
            return {'ok': False, 'status': 'unsupported',
                    'error': 'auto-install is not supported on this OS'}
        _install['running'] = True
        _install['error'] = None
    threading.Thread(target=_run_install, args=(platform,), daemon=True).start()
    return {'ok': True, 'status': 'started'}


# --- sign in ----------------------------------------------------------------

def start_login(platform, console=False):
    """Launch `claude auth login` (which opens the browser + completes via its own
    localhost OAuth callback). Idempotent: no-op if already signed in, single-flight
    if a login is already running. Completion is observed via auth_status()."""
    if not platform.find_claude():
        return {'ok': False, 'status': 'not-installed'}
    if auth_status(platform, force=True).get('loggedIn'):
        return {'ok': True, 'status': 'already'}
    claude = platform.find_claude()
    argv = [claude, 'auth', 'login', '--console' if console else '--claudeai']
    with _login_lock:
        prev = _login['proc']
        if prev is not None and prev.poll() is None:
            return {'ok': True, 'status': 'running'}
        try:
            _login['proc'] = platform.spawn_login(argv)
            _login['error'] = None
        except Exception as e:
            _login['proc'] = None
            _login['error'] = str(e)
            return {'ok': False, 'status': 'error', 'error': str(e)}
    return {'ok': True, 'status': 'started'}


def _login_pending():
    with _login_lock:
        proc = _login['proc']
        return bool(proc is not None and proc.poll() is None)


def _reap_login(platform):
    """Once the user is signed in, retire any lingering login process."""
    with _login_lock:
        proc = _login['proc']
        if proc is not None and proc.poll() is None:
            try:
                platform.kill_process_tree(proc.pid)
            except Exception:
                pass
        _login['proc'] = None


# --- snapshot for /api/desktop/status ---------------------------------------

def status_snapshot(platform):
    """Everything the onboarding card needs, best-effort and never raising:
      found / path        - is the CLI installed
      authed / email/plan - is the user signed in (and who / which plan)
      installing / installError / loginPending - live phase for the card
    """
    path = platform.find_claude()
    out = {'found': bool(path), 'path': path,
           'authed': None, 'email': None, 'plan': None,
           'installing': False, 'installError': None, 'loginPending': False}
    with _install_lock:
        out['installing'] = _install['running']
        out['installError'] = _install['error']
    if not path:
        # Nothing found: ship the search trace so the card can say WHERE we looked
        # instead of a bare "не знайдено" the user cannot act on.
        try:
            rep = platform.claude_search_report()
            out['platform'] = rep.get('platform')
            out['searched'] = [s.get('path') for s in rep.get('searched', [])]
        except Exception:
            pass
        return out
    st = auth_status(platform)
    authed = bool(st.get('loggedIn')) if st else None
    out['authed'] = authed
    out['email'] = st.get('email') if st else None
    out['plan'] = st.get('subscriptionType') if st else None
    if authed:
        _reap_login(platform)
        out['loginPending'] = False
    else:
        out['loginPending'] = _login_pending()
    return out
