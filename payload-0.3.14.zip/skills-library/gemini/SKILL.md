---
name: gemini
description: "Помічник Gemini: викликає Gemini (через agy/Antigravity) надійно, без травлі з таймаутом/артефактом. Скіли: research (глибоке дослідження), thinking (жорсткий reasoning + вердикт), flash (швидка відповідь), raw (довільний промпт). Використовуй коли користувач каже «запитай Gemini», «Gemini research/дослідь», «Gemini подумай/thinking», «use Gemini», «прожени через Gemini», «друга думка від Gemini», або треба зовнішня модель для ресерчу/міркувань."
---

# Gemini 🔷 — надійний помічник виклику Gemini

Обгортка над `scripts/gemini.sh` (маршрут через `agy` / Antigravity CLI). Робить виклик детермінованим і прибирає 3 граблі, через які «Gemini не відповідала».

## Граблі, які фіксить
1. **agy пише у файл-артефакт**, а в stdout лише summary + `file://...*.md`. Тут враппер САМ дочитує артефакт і віддає ПОВНУ відповідь.
2. **Pro (High) не влазить у 120с watchdog** → тут важким режимам `GEMINI_TIMEOUT=360`.
3. **Старі curl-назви моделей** не валідні для agy → реальні стрічки `Gemini 3.1 Pro (Low/High)`, `Gemini 3.5 Flash (Low/Medium/High)`.

Деталі: [[reference_gemini_agy_artifact_gotcha]].

## Як користуватись
`ask.sh <mode> "<prompt>" ["<system override>"]` — режими research | thinking | flash | raw. Друкує повну відповідь у stdout.

| Режим | Модель | Таймаут | Для чого |
|-------|--------|---------|----------|
| `research` | Gemini 3.1 Pro (High) | 360с | глибоке дослідження по секціях |
| `thinking` | Gemini 3.1 Pro (High) | 360с | жорсткий reasoning + вердикт у % |
| `flash` | Gemini 3.5 Flash (High) | 150с | швидка стисла відповідь |
| `raw` | Gemini 3.1 Pro (Low) | 240с | довільний промпт; MODEL/GEMINI_TIMEOUT override |

## Правила
- Синхронно, дочекатись повного результату. [[feedback_this_chat_no_agents_do_yourself]].
- ERROR ≠ квота: підняти `GEMINI_TIMEOUT` або легша модель.
- Українською, без довгих тире. Філософія: [[project_pomichnyky_first_philosophy]].
