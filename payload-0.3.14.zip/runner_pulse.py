"""Биття серця раннера: спільний контракт двох процесів (specs/stale-runner-eats-prompts).

Навіщо цей модуль існує окремим файлом. Бульбашку промпту пише раннер (specs/queue-order-pairs),
але Python вантажить модуль у памʼять НА СТАРТІ процесу: правка `runner.py` на диску не змінює
раннер, який уже біжить. 12.08 це і вистрелило: сервер перезапустився на новому контракті і
чесно віддав бульбашку раннеру, а обидва живі раннери стартували ще до того коміту і про
`claim_prompt_bubble` не знали взагалі. Бульбашку не писав НІХТО, 4786 записів `from: "Я"`
до перезапуску і рівно 0 після.

Лікується не вірою, а заявою: раннер лишає поруч з каналами файл, у якому написано ХТО він
(pid, коли стартував), ЯКИЙ у нього код (відбиток вмісту `runner.py` на момент старту) і ЩО
ВІН УМІЄ (`caps`). Сервер читає цю заяву перед тим, як покласти промпт у чергу, і якщо
здатності `prompt-bubble` там немає (файлу нема, він протух, раннер старий) — пише бульбашку
сам, як до коміту 6fd8eb23.

Модуль навмисно чистий: ні мережі, ні глобального стану, ні імпорту `runner`/`server`. Саме
тому його можуть читати ОБИДВА процеси, не тягнучи один одного (`server.py` при імпорті
підіймає порт, `runner.py` при імпорті робить os.execv на Windows).
"""
import hashlib
import json
import os
from datetime import datetime, timezone

# Здатність «я пишу бульбашку промпту сам». Рядок, а не версія, свідомо: сервер питає
# не «хто ти», а «ти це вмієш», і додати наступну здатність можна не чіпаючи порівняння.
CAP_PROMPT_BUBBLE = 'prompt-bubble'

# Скільки биття серця лишається чинним. Свідомо БІЛЬШЕ за період опитування черги
# (`runner.POLL_SECONDS`, 1.5с) на два порядки: раннер оновлює ts у кожному циклі опитування,
# а цикл не блокується ходом (хід іде в окремому потоці). Тобто навіть під годинним ходом
# биття свіже. Поріг тут для іншого: сервер мусить ВПЕВНЕНО відрізнити «раннер живий і
# зайнятий» від «раннера немає». Занизьке значення дало б хибний «мертвий» на кожному
# підвисанні файлової системи, а ціна хибного спрацювання все одно нульова: ідемпотентність
# за `buid` не дасть другої бульбашки, навіть якщо обидві сторони запишуть її в гонці.
STALE_SECONDS = 60.0

HEARTBEAT_NAME = 'runner-heartbeat.json'


def heartbeat_path(home_dir):
    """Шлях до биття серця. `home_dir` це тека даних (DIR), поруч з якою лежить `channels/`.

    Саме поруч з каналами, а не в теці коду: у пакованій збірці код лежить у read-only
    бандлі, а дані у `CHATVIEW_HOME`. Той самий розрахунок з обох боків гарантує, що
    сервер читає рівно той файл, який пише раннер."""
    return os.path.join(home_dir, HEARTBEAT_NAME)


def code_fingerprint(path):
    """Відбиток ВМІСТУ файлу коду. Читається ОДИН раз, на старті процесу.

    Читати з диска щоразу було б рівно тією помилкою, яку ми ловимо: диск показував би
    новий код, а в памʼяті працював би старий, і розʼїзд лишався б невидимим."""
    try:
        with open(path, 'rb') as f:
            return hashlib.sha256(f.read()).hexdigest()[:16]
    except Exception:
        return None


def build(pid, started, code_fp, caps=None, now=None):
    """Тіло биття серця. Час у ISO з поясом, щоб порівняння не залежало від зони."""
    ts = (now or datetime.now(timezone.utc).astimezone()).isoformat()
    return {'pid': pid, 'started': started, 'ts': ts, 'code_fp': code_fp,
            'caps': list(caps if caps is not None else [CAP_PROMPT_BUBBLE])}


def read(home_dir):
    """Биття серця з диска або None. Ніколи не кидає: відсутній/битий файл це теж відповідь."""
    try:
        with open(heartbeat_path(home_dir), encoding='utf-8') as f:
            hb = json.load(f)
        return hb if isinstance(hb, dict) else None
    except Exception:
        return None


def age_seconds(hb, now=None):
    """Скільки секунд минуло від останнього биття. None = часу нема або він нечитний."""
    if not isinstance(hb, dict):
        return None
    try:
        ts = datetime.fromisoformat(str(hb.get('ts')))
    except Exception:
        return None
    now = now or datetime.now(timezone.utc).astimezone()
    if ts.tzinfo is None:
        ts = ts.astimezone()
    if now.tzinfo is None:
        now = now.astimezone()
    return (now - ts).total_seconds()


def is_fresh(hb, now=None, stale_seconds=STALE_SECONDS):
    age = age_seconds(hb, now)
    return age is not None and age <= stale_seconds


def writes_prompt_bubble(hb, now=None, stale_seconds=STALE_SECONDS):
    """Чи можна довірити бульбашку промпту раннеру.

    Три «ні» і всі три означають одне: покласти промпт у чергу і піти означало б втратити
    питання людини. Немає файлу (раннера нема або він старший за сам контракт), протухле
    биття (процес помер, не прибравши файл), немає здатності в `caps` (раннер є, але цієї
    роботи не робить)."""
    if not isinstance(hb, dict):
        return False
    if not is_fresh(hb, now, stale_seconds):
        return False
    caps = hb.get('caps')
    return isinstance(caps, (list, tuple)) and CAP_PROMPT_BUBBLE in caps


# ── Самоперезапуск на розʼїзді ───────────────────────────────────────────────
# Картка `drift()` нижче лише РОЗПОВІДАЄ людині про розʼїзд, а лікує його кнопка. 13.08
# розʼїзд стався тричі за добу і всі три рази картку не помітили: вона вгорі, а працюють
# унизу біля поля вводу. Тому процес тепер лікує себе сам, а картка лишається видимою
# ознакою (і єдиним шляхом, коли самоперезапуск заборонений).
#
# Ці функції спільні для раннера і сервера навмисно: семантика «коли можна перезапуститись
# і скільки разів» мусить бути ОДНА, інакше два процеси розійдуться ще й у цьому.

# Скільки самоперезапусків дозволено за вікно. Захист від циклу: якщо файл коду міняється
# безперервно (rebase, редактор, скрипт), процес інакше крутився б у нескінченному
# перезапуску і не обробив би жодного промпту.
SELF_RESTART_WINDOW_SECONDS = 900.0
SELF_RESTART_LIMIT = 3

# Скільки міток тримаємо у файлі. Більше за ліміт, щоб було видно історію, але скінченно.
_SELF_RESTART_KEEP = 20


def self_restart_path(home_dir, who):
    """Файл лічильника. Поруч з каналами, з тієї ж причини, що й биття серця."""
    return os.path.join(home_dir, f'{who}-selfrestart.json')


def read_self_restarts(home_dir, who):
    """Мітки часу попередніх самоперезапусків. Ніколи не кидає: немає файлу = їх не було.

    Лічильник живе на ДИСКУ, а не в памʼяті, бо памʼять гине разом із самим перезапуском,
    тобто захист від циклу в памʼяті не захищав би саме від циклу."""
    try:
        with open(self_restart_path(home_dir, who), encoding='utf-8') as f:
            data = json.load(f)
    except Exception:
        return []
    items = data.get('restarts') if isinstance(data, dict) else data
    return [str(x) for x in items] if isinstance(items, list) else []


def recent_self_restarts(stamps, now=None, window=SELF_RESTART_WINDOW_SECONDS):
    """Ті мітки, що потрапили у вікно. Ліміт це ЧАСТОТА, а не лічильник назавжди:
    вчорашні перезапуски не сміють блокувати сьогоднішній розʼїзд."""
    now = now or datetime.now(timezone.utc).astimezone()
    out = []
    for s in stamps or []:
        try:
            ts = datetime.fromisoformat(str(s))
        except Exception:
            continue
        if ts.tzinfo is None:
            ts = ts.astimezone()
        if 0 <= (now - ts).total_seconds() <= window:
            out.append(s)
    return out


def note_self_restart(home_dir, who, old_fp, new_fp, now=None,
                      window=SELF_RESTART_WINDOW_SECONDS):
    """Записати факт ПЕРЕД виходом з процесу. Після виходу писати нікому."""
    now = now or datetime.now(timezone.utc).astimezone()
    stamps = recent_self_restarts(read_self_restarts(home_dir, who), now, window)
    stamps.append(now.isoformat())
    payload = {'restarts': stamps[-_SELF_RESTART_KEEP:],
               'last': {'from': old_fp, 'to': new_fp, 'at': now.isoformat()}}
    path = self_restart_path(home_dir, who)
    tmp = path + '.tmp'
    with open(tmp, 'w', encoding='utf-8') as f:
        json.dump(payload, f, ensure_ascii=False)
    os.replace(tmp, path)
    return payload


def self_restart_decision(boot_fp, disk_fp, blockers, stamps, now=None,
                          window=SELF_RESTART_WINDOW_SECONDS, limit=SELF_RESTART_LIMIT):
    """Чи можна ЗАРАЗ перезапуститись. Чиста функція, тому її можна пінити без процесів.

    `blockers` це список причин, чому момент небезпечний (живий хід, непорожня черга,
    запит у польоті). Порядок відповідей навмисний: спершу «нема розʼїзду», бо смикати
    процес без причини гірше за сам баг; потім «зайнято», бо це найкорисніша людині
    причина; ліміт останній, бо він рідкісний."""
    recent = recent_self_restarts(stamps, now, window)
    out = {'restart': False, 'reason': None, 'recent': len(recent),
           'blockers': list(blockers or []), 'from': boot_fp, 'to': disk_fp}
    if not boot_fp or not disk_fp:
        out['reason'] = 'unknown'          # відбиток не прочитався: «не знаю» != «розʼїзд»
    elif boot_fp == disk_fp:
        out['reason'] = 'match'
    elif out['blockers']:
        out['reason'] = 'busy'
    elif len(recent) >= limit:
        out['reason'] = 'throttled'
    else:
        out['reason'] = 'drift'
        out['restart'] = True
    return out


def self_restart_enabled():
    """Чи взагалі дозволено лікувати себе перезапуском.

    Вимкнено у замороженій збірці: там код лежить у read-only бандлі і не міняється під
    живим процесом (оновлення СТАВЛЯТЬСЯ на наступний запуск), а `os.execv` від імені
    бінарника застосунку підняв би не те. CHAT_SELF_RESTART=0 глушить вручну."""
    import sys as _sys
    if os.environ.get('CHAT_SELF_RESTART', '1') in ('0', 'false', 'no'):
        return False
    return not getattr(_sys, 'frozen', False)


def launchd_owns_me(label):
    """Чи цей самий pid тримає launchd під вказаною міткою. Best-effort, ніколи не кидає.

    Питаємо саме про pid, а не про наявність служби: раннер, запущений руками з термінала
    поруч зі службою, теж побачив би службу і вирішив би, що його піднімуть."""
    import sys as _sys
    if _sys.platform != 'darwin' or not label:
        return False
    try:
        import re as _re
        import subprocess as _sp
        r = _sp.run(['launchctl', 'print', f'gui/{os.getuid()}/{label}'],
                    capture_output=True, text=True, timeout=5)
    except Exception:
        return False
    if r.returncode != 0:
        return False
    m = _re.search(r'^\s*pid\s*=\s*(\d+)', r.stdout or '', _re.M)
    return bool(m) and int(m.group(1)) == os.getpid()


def restart_self(label=None, log=None):
    """Підняти ЦЕЙ процес на коді з диска. Не повертається.

    Два шляхи і обидва потрібні. Під launchd (KeepAlive=true) достатньо коректно
    завершитись: служба підніме процес заново, з чистим середовищем плиста, і залишиться
    рівно один нагляд. Без launchd (дев-прогін, запуск руками) вихід лишив би людину
    взагалі без процесу, тому там процес замінює себе через `os.execv`: pid той самий,
    код новий, вікна «процесу немає» не існує взагалі."""
    import sys as _sys
    say = log or (lambda _m: None)
    try:
        _sys.stdout.flush()
        _sys.stderr.flush()
    except Exception:
        pass
    if launchd_owns_me(label):
        say(f'самоперезапуск: віддаю процес launchd ({label}), KeepAlive підніме новий код')
        os._exit(0)
    try:
        argv = [_sys.executable, os.path.abspath(_sys.argv[0])] + list(_sys.argv[1:])
        say('самоперезапуск: підміняю себе через execv ' + ' '.join(argv))
        os.execv(_sys.executable, argv)
    except Exception as e:      # execv не вдався -> лишається чесний вихід під нагляд
        say(f'самоперезапуск: execv не вдався ({e}), виходжу і покладаюсь на нагляд')
        os._exit(0)


def drift(hb, disk_fp, lock_pids=None, now=None, stale_seconds=STALE_SECONDS):
    """Знімок «чи розʼїхався живий раннер з тим, що лежить на диску» (К4).

    `lock_pids` це процеси, які тримають лок-порт раннера. Два тримачі означають, що
    співіснують два раннери; тримач з чужим pid означає те саме, тільки другий раннер
    старіший за сам лок і порту не бере, а биття серця перезаписує.

    Повертає готовий для UI словник: причина кодом, а не українською прозою, бо фронт не
    має матчити текст з бекенду."""
    pids = [p for p in (lock_pids or []) if isinstance(p, int)]
    hb_pid = hb.get('pid') if isinstance(hb, dict) else None
    duplicate = len(set(pids)) > 1 or bool(pids and hb_pid and hb_pid not in pids)
    fresh = is_fresh(hb, now, stale_seconds)
    code_fp = hb.get('code_fp') if isinstance(hb, dict) else None
    mismatch = bool(hb and disk_fp and code_fp and code_fp != disk_fp)

    if not hb:
        reason = 'missing'
    elif not fresh:
        reason = 'stale'
    elif mismatch:
        reason = 'code'
    elif duplicate:
        reason = 'duplicate'
    else:
        reason = None

    return {
        'seen': bool(hb),
        'fresh': bool(fresh),
        'pid': hb_pid,
        'started': hb.get('started') if isinstance(hb, dict) else None,
        'ts': hb.get('ts') if isinstance(hb, dict) else None,
        'caps': list(hb.get('caps') or []) if isinstance(hb, dict) else [],
        'codeFp': code_fp,
        'diskFp': disk_fp,
        'lockPids': sorted(set(pids)),
        'duplicate': bool(duplicate),
        'writesPromptBubble': writes_prompt_bubble(hb, now, stale_seconds),
        'drift': reason is not None,
        'reason': reason,
    }
