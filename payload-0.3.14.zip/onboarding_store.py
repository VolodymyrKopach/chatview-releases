#!/usr/bin/env python3
"""Стан онбордингу першого запуску (specs/onboarding-empty-states, Р2 і К9).

ЧОМУ ОКРЕМИЙ МОДУЛЬ, А НЕ ДЕСЯТОК РЯДКІВ У server.py. Питання «чи цей дім незайманий»
має рівно одну правильну відповідь, і перевіряти її треба без підняття HTTP-сервера:
server.py біндить порт на рівні модуля, тому все, що там живе, тестується лише через
живий сокет. Тут же чистий stdlib без побічних ефектів, тож юніт-тест просто імпортує
модуль і підсовує йому теки (tests/unit/test_onboarding_state.py).

ЧОМУ НЕЗАЙМАНІСТЬ РАХУЄ СЕРВЕР, А НЕ ФРОНТ (Р2). Тільки сервер бачить дім користувача.
Фронт, який рахує це сам, помиляється на першому ж порожньому кеші і показує онбординг
людині, яка вже рік працює (ризик 2 у спеці). Тому фронт не рахує нічого: він питає
`/api/onboarding` і робить, що сказано.

ЧОМУ ФАЙЛ ЛЕЖИТЬ У ДОМІ, А НЕ В ТЕЦІ ЗАСТОСУНКУ (К9). У пакованій збірці тека
застосунку читається лише на читання і їде в роздачу: стан онбордингу або не
записався б узагалі, або поїхав би новій людині вже «пройденим». Дім користувача
(`CHATVIEW_HOME`) це єдине місце, яке переживає оновлення застосунку і належить саме
цій людині.
"""
import json
import os
import threading

# Ім'я файлу стану всередині дому. Коротке і без крапки спереду: дім користувача це
# видима тека, у яку людина має право зазирнути.
STATE_FILE = 'onboarding.json'

# Рівно три треки (К2). Список тримається ТУТ, а не у фронті, бо саме сервер
# відповідає за те, що записано на диску: невідомий трек мусить бути відхилений, а не
# тихо створити четверте поле, яке потім ніхто не прибере.
TRACKS = ('chat', 'canvas', 'gadget')

# Запис іде з HTTP-хендлера, тобто з довільного потоку ThreadingTCPServer. Два
# паралельні POST (React у режимі строгості робить рівно два виклики поспіль) без
# замка дали б «прочитав старе, записав своє» і загублену галочку треку.
_LOCK = threading.RLock()


def state_path(home):
    """Шлях до файлу стану. Єдине місце, де це знання живе."""
    return os.path.join(home, STATE_FILE)


def _blank():
    return {'dismissed': False, 'tracks': {t: False for t in TRACKS}}


def read(home):
    """Стан онбордингу цього дому. Немає файлу або він побитий -> чистий стан.

    Виняток звідси не виходить НІКОЛИ: онбординг це вітальний екран, і впасти на
    ньому означає зустріти нову людину білою сторінкою замість продукту.
    """
    doc = _blank()
    try:
        with open(state_path(home), encoding='utf-8') as f:
            raw = json.load(f)
    except Exception:
        return doc
    if not isinstance(raw, dict):
        return doc
    doc['dismissed'] = bool(raw.get('dismissed'))
    tracks = raw.get('tracks')
    if isinstance(tracks, dict):
        for t in TRACKS:
            doc['tracks'][t] = bool(tracks.get(t))
    return doc


def _atomic_write(path, doc):
    """tmp + os.replace: обірваний запис не сміє лишити по собі порожній файл."""
    tmp = '%s.tmp.%d' % (path, os.getpid())
    with open(tmp, 'w', encoding='utf-8') as f:
        json.dump(doc, f, ensure_ascii=False, indent=2)
        f.flush()
        os.fsync(f.fileno())
    os.replace(tmp, path)


def write(home, dismissed=None, track=None):
    """Оновити стан і повернути його ЦІЛИМ.

    `dismissed` і `track` незалежні: перше це К5 (людина натиснула вихід), друге це
    К3 (трек справді створив сутність). Невідомий трек відхиляється помилкою, а не
    ігнорується мовчки: тиха відмова тут означала б, що фронт вважає крок пройденим,
    а диск про це не знає.
    """
    if track is not None and track not in TRACKS:
        raise ValueError('невідомий трек онбордингу: %r' % (track,))
    with _LOCK:
        doc = read(home)
        if dismissed is not None:
            doc['dismissed'] = bool(dismissed)
        if track is not None:
            doc['tracks'][track] = True
        os.makedirs(home, exist_ok=True)
        _atomic_write(state_path(home), doc)
        return doc


def _has_channel(home):
    """Чи є в домі бодай один чат.

    Дивимось і на ТЕКИ, і на реєстри. Тека без рядка в реєстрі це чат, створений
    скриптом; рядок без теки це чат, чиї повідомлення ще не писались. Обидва означають
    «людина тут уже щось завела», тому обидва рахуються.
    """
    root = os.path.join(home, 'channels')
    try:
        names = os.listdir(root)
    except Exception:
        return False
    for name in names:
        # `_closed_*` і приховані це службові теки, а не чати людини.
        if name.startswith('_') or name.startswith('.'):
            continue
        if os.path.isdir(os.path.join(root, name)):
            return True
    for reg in ('index.json', 'index.local.json'):
        try:
            with open(os.path.join(root, reg), encoding='utf-8') as f:
                items = json.load(f)
        except Exception:
            continue
        if isinstance(items, list) and any(
                isinstance(c, dict) and c.get('id') for c in items):
            return True
    return False


def _has_gadget(home):
    """Чи є в домі бодай один гаджет.

    Рахуємо ТЕКУ `apps/<id>/manifest.json`, а не лише рядок у `apps/index.json`.
    Причина буквальна: `/api/app-create` кладе гаджет на диск одразу, а в реєстр
    він потрапляє аж коли людина скаже «Готово». Рахувати самий реєстр означало б
    вважати дім порожнім рівно після того, як людина створила в ньому перший
    додаток.
    """
    root = os.path.join(home, 'apps')
    try:
        names = os.listdir(root)
    except Exception:
        return False
    for name in names:
        if name.startswith('_') or name.startswith('.'):
            continue
        if os.path.isfile(os.path.join(root, name, 'manifest.json')):
            return True
    try:
        with open(os.path.join(root, 'index.json'), encoding='utf-8') as f:
            idx = json.load(f)
    except Exception:
        return False
    items = idx.get('gadgets') if isinstance(idx, dict) else None
    return bool(isinstance(items, list) and items)


def is_virgin(home, canvas_pages=0):
    """Дім незайманий = нема ні чату, ні сторінки канви, ні гаджета (Р2).

    Сторінки канви приходять ЧИСЛОМ ззовні: живий стор канви тримає server.py у
    памʼяті під власним замком, а тека даних канви задається окремою змінною
    (`CANVAS_DATA_DIR`) і в пакованій збірці лежить не там, де решта дому. Тягнути
    сюди друге джерело правди про канву означало б завести два різні поняття
    «сторінка існує».
    """
    if canvas_pages:
        return False
    return not _has_channel(home) and not _has_gadget(home)


def snapshot(home, canvas_pages=0):
    """Повна відповідь `GET /api/onboarding` одним викликом."""
    doc = read(home)
    return {
        'virgin': is_virgin(home, canvas_pages),
        'dismissed': doc['dismissed'],
        'tracks': dict(doc['tracks']),
    }
