#!/usr/bin/env python3
"""batch_detect: чи пачка агентів завершилась, і хто саме в неї входить.

specs/agent-batch-summary/spec.md, сабтаск S2, критерії К3, К7, К9. Це рівно та
частина, яка ЗНАХОДИТЬ склад пачки на диску і РОБИТЬ ВИСНОВОК «завершилась чи ні».
Побудову самої картки підсумку робить batch_summary.py (S3, не чіпати), атомарне
захоплення права на публікацію робить batch_claim.py (S4, паралельний сабтаск,
файл теж не чіпати), а виклик усього цього разом — окремий сабтаск S5.

Ідентифікатор пачки живе в полі status.json.task, куди його вшиває
agent-batch.cjs:119-134 рядком `[пачка: <id>]`. Рядок не завжди перший: перед ним
може стояти рядок спеки (`[спека: ...]` або `[без спеки: ...]`). Рядка пачки може
не бути взагалі — одиночний запуск через agent-run.cjs ідентифікатора не отримує,
і за К7 це не помилка, а пачка з одного агента, чия поведінка не сміє змінитись.

Термінальні стани: done, error, stopped. Нетермінальні: queued, running (К3: поки
хоч один запис нетермінальний, пачка не завершена). Виняток — сирота (К9): запис
лишився нетермінальним на диску, бо процес агента помер раніше, ніж встиг
записати фінальний стан. Ознака сироти: нетермінальний стан + мертвий pid.

Перевірку живості НЕ беремо імпортом із server.py: це модуль на десятки тисяч
рядків, і тягнути його заради однієї дешевої проби в кожен тест сенсу нема. Вона
йде параметром `pid_alive`; дефолт — легка локальна проба, яка на POSIX питає
ядро сигналом 0, а на Windows чесно каже «не знаю» (сигналу 0 там нема,
os.kill(pid, 0) це TerminateProcess — див. chatview_platform.py:160-173, та ж
обережність). Майбутній викликач на Windows підсуне сюди PLATFORM.pid_alive.

Модуль нічого не пише на диск: сирота лишається сиротою у status.json, лікування
запису (server.py::_agent_settle_status) це побічний ефект, якого в чистому
детекторі бути не повинно.
"""
import json
import os
import re

TERMINAL_STATES = frozenset({'done', 'error', 'stopped'})
NONTERMINAL_STATES = frozenset({'queued', 'running'})

_BATCH_LINE_RE = re.compile(r'^\s*\[пачка:\s*(?P<id>[^\]\s]+)\s*\]\s*$', re.MULTILINE)


def parse_batch_id(task):
    """Ідентифікатор пачки з поля status.json.task, або None якщо маркера нема.

    Рядок може стояти не першим (перед ним рядок спеки), тому шукаємо будь-де в
    тексті, а не лише на початку рядка задачі."""
    if not isinstance(task, str) or not task:
        return None
    normalized = task.replace('\r\n', '\n')
    m = _BATCH_LINE_RE.search(normalized)
    return m.group('id') if m else None


def _iter_status_records(agents_dir):
    """Yield кожен читабельний status.json з agents_dir.

    Битий, порожній чи відсутній файл просто пропускається, обхід не падає:
    ~700 старих записів мають усілякий мотлох поруч, і жоден не сміє звалити
    збирача (К7)."""
    try:
        names = os.listdir(agents_dir)
    except OSError:
        return
    for name in names:
        status_path = os.path.join(agents_dir, name, 'status.json')
        try:
            with open(status_path, encoding='utf-8') as fh:
                record = json.load(fh)
        except (OSError, ValueError):
            continue
        if isinstance(record, dict):
            yield record


def collect_batch_records(agents_dir, batch_id):
    """1. Збирач складу пачки: усі записи agents_dir, чий task несе саме цей
    batch_id.

    Порожній batch_id навмисно дає []: групувати записи БЕЗ маркера тут не
    можна, інакше всі старі агенти без маркера склеїлись би в одну пачку.
    Для одиночного запису без маркера дивись batch_records_for нижче (К7)."""
    if not batch_id:
        return []
    return [r for r in _iter_status_records(agents_dir)
            if parse_batch_id(r.get('task')) == batch_id]


def batch_records_for(agents_dir, record):
    """Склад пачки для КОНКРЕТНОГО відомого запису (К7): є маркер — зібрати
    всіх однопачечників з диска; немає маркера — пачка з одного, цей самий
    запис, і нікого зайвого з-поміж інших записів без маркера поруч."""
    batch_id = parse_batch_id(record.get('task'))
    if not batch_id:
        return [record]
    found = collect_batch_records(agents_dir, batch_id)
    return found or [record]


def _default_pid_alive(pid):
    """Легка локальна проба живості (без імпорту server.py, див. шапку модуля).

    POSIX: канонічний os.kill(pid, 0). Windows: такого сигналу нема — будь-яке
    значення крім CTRL-подій os.kill там віддає в TerminateProcess, тобто проба
    вбила б процес, який питає. Тому тут чесне «не знаю» -> вважаємо живим:
    помилятись можна лише в цей бік (пачка з живим агентом на Windows просто не
    закриється сама автоматично, а не навпаки)."""
    if os.name == 'nt':
        return True
    try:
        pid = int(pid)
    except (TypeError, ValueError):
        return False
    if pid <= 0:
        return False
    try:
        os.kill(pid, 0)
    except ProcessLookupError:
        return False
    except PermissionError:
        return True
    except OSError:
        return False
    return True


def is_orphan(record, pid_alive=_default_pid_alive):
    """Сирота (К9): нетермінальний стан на диску + мертвий процес.

    Запис у черзі БЕЗ pid ще не стартував, і це не смерть (той самий нюанс, що
    й у server.py::_agent_settle_status) — інакше щойно поставлений у чергу
    елемент визнавався б сиротою раніше, ніж узагалі отримав процес."""
    if record.get('state') not in NONTERMINAL_STATES:
        return False
    pid = record.get('pid')
    if not pid:
        return False
    return not pid_alive(pid)


def is_batch_finished(records, pid_alive=_default_pid_alive):
    """2. Відповідь на питання «пачка завершилась»: так, коли КОЖЕН запис або
    термінальний, або сирота (К3, К9). Порожній список -> вакуозно завершена,
    нема на що чекати."""
    for record in records:
        if record.get('state') in NONTERMINAL_STATES and not is_orphan(record, pid_alive):
            return False
    return True
