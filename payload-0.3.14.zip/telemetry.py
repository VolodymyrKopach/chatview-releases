#!/usr/bin/env python3
"""Телеметрія ChatView: згода, вимикач і ОДИН транспорт назовні.

Спека: specs/telemetry-onboarding/spec.md (Фаза 0). Карта фаз: там же, plan.md.

ЩО ЦЕ Є І ЧОГО ТУТ СВІДОМО НЕМА. Це механізм, а не збір. PostHog і Sentry у цій
фазі НЕ підключені: тут будується місце, куди вони під'єднаються (Фази 1 і 3), і
запобіжники, які на той момент уже мусять діяти. Порядок зворотний до звичного
саме тому, що це інструмент розробника: застосунок має доступ до диска, виконує
команди в теці людини і тримає її ключ OpenAI. Телеметрія, яка з'явилась тихо,
коштує довіри незворотно, і жоден пізніший екран згоди цього не відкупить.

ЧОМУ ТРАНСПОРТ ОДИН. Кожен додатковий шлях назовні це ще одне місце, де можна
забути перевірити вимикач. Тут рівно одна функція, яка торкається мережі
(`_http_post`), рівно одне місце, де оголошені адреси (`ENDPOINTS`), і рівно один
шлюз, який вирішує «можна чи ні» (`Telemetry._allowed`). Sentry у Фазі 1 не
отримає власного каналу: він отримає цей.

ЧОТИРИ ЗАМКИ ПЕРЕД МЕРЕЖЕЮ, у порядку перевірки:
  1. `decided`  людина ще не бачила екран згоди -> назовні не йде НІЧОГО.
     Це не opt-in. Вимикач стоїть в «увімкнено» (рішення власника: opt-out), але
     збір починається після того, як екран показали, а не до нього. Так робить
     Homebrew (повідомлення в інсталяторі ДО першої відправки) і Next.js (банер
     перед першою подією); ціна нульова, а різниця між «ми сказали» і «ми
     промовчали» це і є вся різниця в усіх шести скандалах з ресерчу.
  2. `enabled`  вимикач. Вимкнення СТИРАЄ чергу, а не ставить її на паузу.
  3. `key`      немає ключа проєкту -> немає куди слати. У Фазі 0 його немає ні в
     кого, тому фактично назовні не йде нічого взагалі, і це правильний стан.
  4. `_safe_*`  подія й властивості проходять БІЛИЙ список. Не чорний: чорний
     список ловить те, що згадали, білий пропускає лише те, що оголосили.

ЧОМУ БІЛИЙ СПИСОК, А НЕ ЧИСТКА. Наш інтерфейс і є текст користувача: назви
чатів, повідомлення, шляхи у відповідях агентів, вміст файлів. Будь-яка спроба
«вирізати зайве» з довільного рядка це гонка, яку ми програємо на першому
недогляді. Тому подія може нести лише названі властивості названих подій, і
лише скалярні значення з вузького алфавіту. Те, чого не оголосили, не їде.

ЩО КЛАДЕТЬСЯ НА ДИСК. `<CHATVIEW_HOME>/telemetry.json`, той самий патерн, що й
keys.json і rules.md: у пакованій збірці під домівкою користувача, у дев-репо
поруч зі скриптами. Файл малий і людиночитний навмисне: людина мусить мати змогу
подивитись очима, що саме ми про неї памʼятаємо.

Чистий stdlib, без побічних ефектів на імпорті і без мережі на старті (К7).
"""
import json
import os
import platform
import re
import sys
import threading
import time
import uuid
from collections import deque

# ── ЄДИНЕ місце, де живуть адреси призначення (К6) ───────────────────────────
# Регіон EU, рішення власника. Обидва сервіси у Франкфурті:
#   PostHog Cloud EU  eu.i.posthog.com   (AWS eu-central-1, анонімізація IP за
#                                         замовчуванням на EU-проєктах)
#   Sentry EU         de.sentry.io       (вибір регіону робиться ОДИН раз при
#                                         створенні організації і незворотний)
# Тут саме адреса, а не ключ: ключ проєкту приносить власник у Фазах 1 і 3, а
# адреса це рішення, яке ухвалене вже і перевіряється тестом
# (tests/unit/test_telemetry_phase0.py::test_k6_*). Розсипати її по коду означало б
# лишити один хвіст на американському хості і не помітити цього роками.
ENDPOINTS = {
    'analytics': 'https://eu.i.posthog.com/i/v0/e/',
    'crash': 'https://de.sentry.io/',
}

STORE_FILE = 'telemetry.json'
STORE_VERSION = 1

# Скільки подій тримаємо, поки їх нікуди слати. Черга ОБМЕЖЕНА: без стелі
# застосунок, що місяць пропрацював без мережі, роздув би памʼять, а потім
# вивалив би місячний архів одним пострілом при першому конекті.
QUEUE_MAX = 100

# Скільки чекаємо мережу. Коротко: телеметрія не має права тримати потік.
TIMEOUT = 5


# ── білий список подій (К4) ──────────────────────────────────────────────────
# Конвенція Segment: Object Action, Title Case, дієслово в минулому часі, назви
# властивостей snake_case. Взята дослівно і зафіксована зараз, бо перейменувати
# події заднім числом означає втратити історію.
#
# Модель подій, Фаза 3 (specs/telemetry-events/spec.md, розділ 3). Стеля РІВНО
# ДЕСЯТЬ, і це рішення, а не випадковість (К12, тест test_events_ceiling):
# кожен новий запис має письмове призначення в спеці, інакше набір перетворюється
# на шум, якому за півроку ніхто не довіряє.
#
# П'ять подій це ланцюг воронки першого запуску, у порядку проходження людиною:
#   App Launched -> Setup Step Completed -> Sign In Completed -> Message Sent
#   -> Reply Received. Остання пара найцінніша: різниця між Message Sent і
#   Reply Received ловить тиху поломку (відправив і не отримав нічого), а не
#   лише факт наміру.
#
# Permission Decided і App Error Shown стоять ЗБОКУ від воронки як датчики
# довіри: перша міряє, наскільки людина боїться того, що застосунок робить з її
# диском (частка deny), друга ловить момент, коли людині ПОКАЗАНО відмову (не
# виняток у коді, це справа Sentry Фази 1, а видиму картку).
#
# Helper Invoked перевіряє продуктову гіпотезу «помічники-first» цифрою, а не
# відчуттям. Onboarding Completed і Telemetry Consent Set замикають картину
# контекстом: перша завершує лійку першого запуску, друга каже, наскільки
# репрезентативна вся решта даних.
#
# Onboarding Completed ОГОЛОШЕНА, але точки спрацювання ще не отримала: екран
# опитування це Фаза 2, якої на момент цього коміту не існує. Це навмисно
# (не-ціль у спеці), а не забутий виклик .track() -- не шукай його.
EVENTS = {
    'Telemetry Consent Set': ('enabled',),
    'App Launched': ('version', 'os_version', 'is_first_launch'),
    'Setup Step Completed': ('step', 'outcome', 'attempt_count'),
    'Sign In Completed': ('method', 'outcome', 'is_first'),
    'Message Sent': ('channel_kind', 'has_attachment'),
    'Reply Received': ('duration_ms', 'widget_count', 'has_media'),
    'Permission Decided': ('decision', 'tool_kind'),
    'App Error Shown': ('error_kind', 'surface'),
    'Helper Invoked': ('helper_name', 'outcome'),
    'Onboarding Completed': ('source', 'skipped'),
}

# Контекст, який дозволено додавати до БУДЬ-ЯКОЇ події. Свідомо коротко:
# нічого про машину, нічого про людину, нічого про проєкт.
CONTEXT_KEYS = ('app_version', 'os', 'os_version')

# Алфавіт значення-рядка. Ані пробілу, ані слеша, ані тильди, ані собаки: усе,
# з чого складаються шляхи, речення, пошти і назви чатів, тут не проходить.
_SAFE_STR = re.compile(r'^[A-Za-z0-9._-]{1,32}$')
# Назва події: Title Case зі слів латиницею. Кирилиця, шляхи і ключі відпадають.
_SAFE_EVENT = re.compile(r'^[A-Z][A-Za-z0-9]*(?: [A-Z][A-Za-z0-9]*)*$')
_SAFE_KEY = re.compile(r'^[a-z][a-z0-9_]{0,30}$')


def store_path(home):
    return os.path.join(home, STORE_FILE)


def _new_install_id():
    """Локальний випадковий ідентифікатор (К5).

    `uuid.uuid4()` це CSPRNG операційної системи і НЕ `uuid1`: uuid1 зашиває в
    себе MAC-адресу мережевої карти, тобто перетворив би ідентифікатор установки
    на ідентифікатор заліза. Різниця в одному символі назви і в усьому іншому.

    Псевдонімний ідентифікатор все одно лишається персональними даними за
    Recital 26 GDPR, тому в інтерфейсі ми не пишемо «ніяких персональних даних»,
    а пишемо чесно: «випадковий номер установки, не пов'язаний з вашим іменем».
    Він показаний у Налаштуваннях саме тому, що без нього право на стирання
    технічно нездійсненне: людині нема чого процитувати в листі.
    """
    return uuid.uuid4().hex


def _defaults():
    return {
        'version': STORE_VERSION,
        # opt-out: вимикач стоїть в «увімкнено» (рішення власника). Але поки
        # decided=False, замок №1 не пускає назовні нічого.
        'enabled': True,
        'decided': False,
        'install_id': _new_install_id(),
    }


def _app_version():
    """Версія застосунку з файлу VERSION поруч із модулем. Немає файлу -> '0'."""
    try:
        with open(os.path.join(os.path.dirname(os.path.abspath(__file__)), 'VERSION'),
                  encoding='utf-8') as fh:
            return fh.read().strip() or '0'
    except OSError:
        return '0'


def _os_version():
    """Версія ОС БЕЗ імені машини.

    `platform.node()` тут не використовується ніде і ніколи: типовий macOS
    hostname виглядає як `Volodymyrs-MacBook-Pro`, тобто це ім'я людини. Саме на
    цьому спотикається Sentry за замовчуванням (`server_name`), і Фаза 1 має
    прийти в уже закриті двері.
    """
    try:
        if sys.platform == 'darwin':
            ver = platform.mac_ver()[0]
            if ver:
                return ver
        return platform.release() or 'unknown'
    except Exception:
        return 'unknown'


def _safe_value(value):
    """Скаляр -> він сам; усе інше -> None (тобто не поїде)."""
    if isinstance(value, bool):
        return value
    if isinstance(value, int) and not isinstance(value, bool):
        return value if abs(value) < 10 ** 12 else None
    if isinstance(value, float):
        return round(value, 3) if abs(value) < 10 ** 12 else None
    if isinstance(value, str):
        return value if _SAFE_STR.match(value) else None
    return None


def _safe_props(props, allowed):
    """Білий список ключів плюс білий список значень. Мовчки, без винятків:
    втеча не має права стати падінням застосунку, вона має право лише не поїхати."""
    out = {}
    for key in allowed:
        if key not in (props or {}):
            continue
        if not _SAFE_KEY.match(key):
            continue
        value = _safe_value(props[key])
        if value is not None:
            out[key] = value
    return out


def _http_post(url, body, headers, timeout):
    """ЄДИНА функція в застосунку, що торкається мережі заради телеметрії.

    Окремо і найпростіше навмисно: її підміняють тести (перехоплення мережі,
    К3), і вона мусить бути настільки дурною, щоб у ній не було чого перевіряти.
    """
    import urllib.request
    req = urllib.request.Request(url, data=body, headers=headers, method='POST')
    with urllib.request.urlopen(req, timeout=timeout) as resp:
        resp.read()


class Telemetry:
    """Стан згоди плюс черга плюс транспорт для ОДНІЄЇ домівки.

    Клас, а не купа функцій на модулі, рівно з однієї причини: черга це стан, а
    стан на рівні модуля неможливо ізолювати в тестах, і перший же тест почав би
    успадковувати сміття попереднього. У застосунку екземпляр один (`get()`).

    :param home: тека даних (CHATVIEW_HOME або тека скриптів у дев-репо)
    :param sender: перехоплювач мережі; тести підміняють, продакшн лишає дефолт
    :param key: ключ проєкту аналітики; у Фазі 0 його немає ні в кого
    :param auto: слати у фоні одразу після track(). У застосунку True, у тестах
                 False, щоб перевіряти детерміновано, а не ганятись за потоком
    """

    def __init__(self, home, sender=None, key=None, auto=False):
        self.home = home
        self._send = sender or _http_post
        self._key = key if key is not None else os.environ.get('CHATVIEW_TELEMETRY_KEY') or ''
        self._auto = auto
        self._queue = deque(maxlen=QUEUE_MAX)
        self._lock = threading.Lock()
        self._flushing = False
        self._state = self._load()

    # ── сховище ─────────────────────────────────────────────────────────────

    def _load(self):
        state = _defaults()
        try:
            with open(store_path(self.home), encoding='utf-8') as fh:
                disk = json.load(fh)
            if isinstance(disk, dict):
                for key in ('enabled', 'decided'):
                    if isinstance(disk.get(key), bool):
                        state[key] = disk[key]
                iid = disk.get('install_id')
                if isinstance(iid, str) and re.fullmatch(r'[0-9a-f]{32}', iid):
                    state['install_id'] = iid
        except (OSError, ValueError, UnicodeDecodeError):
            # Зіпсований або відсутній файл це дефолт, а не падіння старту.
            pass
        self._state = state
        self._save(state)
        return state

    def _save(self, state):
        """Атомарний запис. Помилка диску НЕ підіймається вище: телеметрія не
        сміє бути причиною, через яку застосунок не стартував (К7)."""
        try:
            os.makedirs(self.home, exist_ok=True)
            tmp = store_path(self.home) + '.tmp'
            with open(tmp, 'w', encoding='utf-8') as fh:
                json.dump(state, fh, ensure_ascii=False, indent=2, sort_keys=True)
            os.replace(tmp, store_path(self.home))
        except OSError:
            pass

    # ── стан ────────────────────────────────────────────────────────────────

    @property
    def enabled(self):
        return bool(self._state.get('enabled'))

    @property
    def decided(self):
        return bool(self._state.get('decided'))

    @property
    def install_id(self):
        return self._state['install_id']

    @property
    def pending(self):
        return len(self._queue)

    def decide(self, enabled=True):
        """Людина пройшла перший екран. Саме тут згода стає згодою."""
        self._state['decided'] = True
        return self.set_enabled(enabled)

    def set_enabled(self, value):
        """Вимикач. Діє НЕГАЙНО і в межах цього ж запуску (К8).

        Вимкнення СТИРАЄ чергу. Це не оптимізація, це і є критерій К3: інакше
        людина вимикає збір, а події, що вже накопичились, вистрілюють при
        наступному увімкненні. Вона б назвала це обманом і мала б рацію.
        """
        self._state['enabled'] = bool(value)
        if not value:
            with self._lock:
                self._queue.clear()
        self._save(self._state)
        return dict(self._state)

    def reset_install_id(self):
        """Скидання з Налаштувань (К5): далі ми не звʼяжемо нове з попереднім."""
        self._state['install_id'] = _new_install_id()
        with self._lock:
            self._queue.clear()   # черга несла старий id, і він уже не наш
        self._save(self._state)
        return self._state['install_id']

    # ── подія ───────────────────────────────────────────────────────────────

    def build_event(self, name, props=None):
        """Сформувати подію або повернути None, якщо їй тут не місце.

        None, а не виняток: невідома подія це помилка програміста, і вона мусить
        призвести до тиші, а не до падіння в людини на екрані.
        """
        if not isinstance(name, str) or not _SAFE_EVENT.match(name) or name not in EVENTS:
            return None
        safe = _safe_props(props, EVENTS[name])
        safe.update(_safe_props({
            'app_version': _app_version(),
            'os': sys.platform,
            'os_version': _os_version(),
        }, CONTEXT_KEYS))
        return {
            'event': name,
            'install_id': self.install_id,
            'ts': int(time.time()),
            'props': safe,
        }

    # ── транспорт ───────────────────────────────────────────────────────────

    def _allowed(self):
        """Єдина відповідь на «чи можна назовні». Три замки з чотирьох тут,
        четвертий (білий список) стоїть у build_event."""
        return self.decided and self.enabled and bool(self._key)

    def track(self, name, props=None):
        """Поставити подію в чергу. НІКОЛИ не ходить у мережу сам (К7): виклик
        мусить коштувати мікросекунди, бо його роблять з обробника запиту."""
        if not self.decided or not self.enabled:
            return False
        event = self.build_event(name, props)
        if event is None:
            return False
        with self._lock:
            self._queue.append(event)
        if self._auto:
            self.flush_async()
        return True

    def _envelope(self, event):
        """Подія -> тіло запиту PostHog. Форма чужа, вміст наш і вже чистий."""
        return {
            'api_key': self._key,
            'event': event['event'],
            'distinct_id': event['install_id'],
            'timestamp': event['ts'],
            'properties': event['props'],
        }

    def flush(self):
        """Віддати чергу транспорту. Повертає кількість успішних відправок.

        Невідправлене НЕ повертається в чергу. Ретрай тут коштував би дорожче,
        ніж дає: телеметрія, яка накопичує борг, одного дня його віддає, і саме
        цього людина боїться, коли тисне вимикач. Втратити подію не страшно,
        віддати непрохану страшно.
        """
        if not self._allowed():
            if not self.enabled:
                with self._lock:
                    self._queue.clear()
            return 0
        with self._lock:
            batch = list(self._queue)
            self._queue.clear()
        sent = 0
        headers = {
            'Content-Type': 'application/json',
            # Ані hostname, ані шляху, ані мови: рівно продукт і версія.
            'User-Agent': 'ChatView/%s' % _app_version(),
        }
        for event in batch:
            # Замок перевіряється НА КОЖНІЙ події, а не один раз перед циклом:
            # вимикач могли натиснути, поки ми стоїмо в мережі на першій.
            if not self._allowed():
                break
            try:
                body = json.dumps(self._envelope(event), ensure_ascii=False).encode('utf-8')
                self._send(ENDPOINTS['analytics'], body, headers, TIMEOUT)
                sent += 1
            except Exception:
                # Мовчки. Сервіс недоступний це не подія для людини (К7): ні
                # вікна, ні рядка в стрічці чату, ні запису в лог, який вона
                # відкриє і злякається.
                pass
        return sent

    def flush_async(self):
        """Те саме у фоні. Один потік на раз: без цього черга з десяти подій
        породжувала б десять потоків, які штовхаються за той самий список."""
        with self._lock:
            if self._flushing:
                return
            self._flushing = True

        def run():
            try:
                self.flush()
            finally:
                with self._lock:
                    self._flushing = False

        threading.Thread(target=run, daemon=True).start()

    # ── для API ─────────────────────────────────────────────────────────────

    def snapshot(self):
        """Що показати в інтерфейсі. Ключа тут немає і бути не може."""
        return {
            'enabled': self.enabled,
            'decided': self.decided,
            'installId': self.install_id,
            'endpoint': ENDPOINTS['analytics'],
            'region': 'EU',
            'connected': bool(self._key),
        }


# ── один екземпляр на застосунок ─────────────────────────────────────────────
_INSTANCES = {}
_INSTANCES_LOCK = threading.Lock()


def get(home):
    """Екземпляр для цієї домівки. Саме його бере server.py."""
    with _INSTANCES_LOCK:
        inst = _INSTANCES.get(home)
        if inst is None:
            inst = Telemetry(home, auto=True)
            _INSTANCES[home] = inst
        return inst


def ensure(home):
    """Створити сховище на старті сервера. Мережі не торкається (К7)."""
    try:
        return get(home)
    except Exception:
        return None
