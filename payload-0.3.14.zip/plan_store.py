#!/usr/bin/env python3
"""plan_store.py — THE single writer of channels/<id>/plan.json.

WHY THIS MODULE EXISTS (Vova 2026-08-04)
----------------------------------------
The plan sidebar was declarative already: the assistant emits a ```plan``` block,
runner.py strips it and persists it. The persisting half shelled out to
`set-plan.cjs`, and that broke the packaged desktop app in two independent ways at
once:

  1. `set-plan.cjs` was never in the payload manifest, so ChatView.app simply had no
     such file. `subprocess.run` failed, the caller was best-effort, and the plan
     vanished without a single visible symptom. Vova: «кажу в чаті додай план, воно
     не додає».
  2. Even shipped, it wrote to `<dir-of-the-script>/channels/...`. In the desktop the
     script would sit inside the read-only bundle while the DATA lives in
     CHATVIEW_HOME, so the plan would have landed beside the app instead of in the
     user's home.

Both are gone here: the write is plain Python, in-process (no node, no subprocess, no
file to forget in a manifest), and the target dir is derived from the SAME environment
rule server.py and runner.py use, so the plan always lands in the active data home.

SINGLE WRITER. This module is the only code that creates plan.json. `set-plan.cjs`
and `set-plan.sh` are now thin argument-forwarding wrappers over `main()` here, kept
only so the documented CLI keeps working; neither owns any plan logic anymore.

APPEND, NEVER OVERWRITE (Vova 2026-08-06)
-----------------------------------------
The writer used to REPLACE plan.json with whatever snapshot arrived. That made "the
plan" a picture of the present, so a turn that declared six current steps silently
deleted twenty finished ones, and there was nothing to roll back to. Vova: «це ж
історія, це як з комітами: ми просто йдемо поверх».

So a snapshot is now MERGED into the stored plan:
  * a step is matched by its explicit `id`, else by its normalized `text`;
  * a `done` step is INDESTRUCTIBLE: it cannot be removed, reverted to pending/progress
    or reworded. A snapshot that omits it leaves it exactly where it was;
  * steps that are not done are updated when the snapshot mentions them and kept when
    it does not;
  * the ONLY way to remove a mistaken step is an explicit `"state": "dropped"`, and it
    works on non-done steps only;
  * `goal` (and the other top-level fields) update freely: they describe the present,
    not the history;
  * order is active first, finished history below in the order it was finished, and
    every step gets a `doneAt` stamp the moment it turns done, so the tail reads as a
    feed of events.
"""
import json
import os
import re
import sys
import time

# Same rule as server.py / runner.py: the desktop sets CHATVIEW_HOME to the writable
# data home, dev/live runs out of the repo dir. Read lazily (not frozen at import) so
# a test can point it somewhere else.
def base_dir():
    return os.environ.get('CHATVIEW_HOME') or os.path.dirname(os.path.abspath(__file__))


def channels_dir():
    return os.path.join(base_dir(), 'channels')


# Keyword -> emoji for auto-iconing a fresh chat from its plan goal. First match wins,
# so this is ordered most specific to most generic. Mirrors render-message.cjs, which
# is why a plan-first channel and a message-first channel get the same lively icon.
ICON_RULES = (
    (r'гро[шж]|оплат|комунал|payment|підписк|білінг|invoice|рахунок', '💰'),
    (r'баг|fix|фікс|помилк|bug|debug|зламал|crash|exception', '🛠'),
    (r'код|code|деплой|deploy|рефактор|refactor|api\b|docker|сервер|backend', '💻'),
    (r'дизайн|design|\bui\b|\bux\b|макет|figma|mockup|wireframe', '🎨'),
    (r'відео|reels|рілс|кліп|video|youtube|монтаж', '🎬'),
    (r'маркетинг|реклам|\bads?\b|кампан|campaign|воронк|funnel', '📣'),
    (r'аналітик|метрик|\bsql\b|дашборд|analytics|metric|dashboard|конверс', '📊'),
    (r'іде[яї]|брейншторм|brainstorm|гіпотез', '💡'),
    (r'чат[- ]?в|chatview|chat[- ]?view|інтерфейс|widget|віджет', '🪟'),
    (r'контент|пост\b|статт|copy|копірайт|article', '✍️'),
    (r'дослід|research|конкурент|competitor|ресерч', '🔬'),
    (r'план|roadmap|стратег|strategy|спрінт|sprint', '🗺️'),
    (r'лист\b|email|розсилк|drip|newsletter|імейл', '📨'),
)


def _plain(raw):
    """Free text -> one clean line: strip tags, collapse whitespace."""
    return re.sub(r'\s+', ' ', re.sub(r'<[^>]*>', ' ', '' if raw is None else str(raw))).strip()


def snippet_label(raw, max_len=32):
    """Trim free text into a concise tab label, cutting on a word boundary."""
    s = _plain(raw)
    if not s or len(s) <= max_len:
        return s
    cut = s[:max_len]
    sp = cut.rfind(' ')
    if sp > 12:
        cut = cut[:sp]
    return cut.rstrip() + '…'


def derive_icon(text):
    """Topical emoji for free text. '🆕' (fresh chat) when nothing matches, never the
    dull gray '💬'."""
    s = _plain(text)
    if not s:
        return '🆕'
    for pattern, emoji in ICON_RULES:
        if re.search(pattern, s, re.IGNORECASE):
            return emoji
    return '🆕'


def code_time_label():
    """The old hardcoded 'Code HH:MM' tab name, now only a safety net."""
    return time.strftime('Code %H:%M')


def _write_json_atomic(path, obj):
    """Write then rename, so the 2s poller never reads a half-written file."""
    tmp = path + '.tmp'
    with open(tmp, 'w', encoding='utf-8') as f:
        json.dump(obj, f, ensure_ascii=False, indent=2)
    os.replace(tmp, path)


def _in_registry(path, cid):
    try:
        with open(path, encoding='utf-8') as f:
            reg = json.load(f)
        return isinstance(reg, list) and any(
            isinstance(x, dict) and x.get('id') == cid for x in reg)
    except Exception:
        return False


def ensure_registered(ch_dir_root, cid, goal):
    """Lazy channel registration (mirror of render-message.cjs): a plan is content too,
    so writing one materializes the tab when the channel is in neither registry. A cc-*
    channel derives its label from the plan goal, else falls back to 'Code HH:MM'."""
    if not cid:
        return
    reg_path = os.path.join(ch_dir_root, 'index.json')
    local_path = os.path.join(ch_dir_root, 'index.local.json')
    if _in_registry(reg_path, cid) or _in_registry(local_path, cid):
        return
    try:
        with open(local_path, encoding='utf-8') as f:
            local_reg = json.load(f)
    except Exception:
        local_reg = []
    if not isinstance(local_reg, list):
        local_reg = []
    if any(isinstance(x, dict) and x.get('id') == cid for x in local_reg):
        return
    label, icon = cid, '🆕'
    if cid.startswith('cc-'):
        label = snippet_label(goal) or code_time_label()
        icon = derive_icon(goal)
    local_reg.append({'id': cid, 'label': label, 'icon': icon, 'twoway': False, 'cc': True})
    _write_json_atomic(local_path, local_reg)


def collect_steps(plan):
    """Every step of a plan, flat or phased."""
    phases = plan.get('phases')
    if isinstance(phases, list):
        out = []
        for ph in phases:
            if isinstance(ph, dict):
                out.extend(ph.get('steps') or [])
        return out
    return plan.get('steps') or []


DONE = 'done'
DROPPED = 'dropped'


def _state(step):
    """Lowercased state of a step, '' when absent (which the UI reads as pending)."""
    raw = step.get('state') if isinstance(step, dict) else None
    return str(raw).strip().lower() if raw else ''


def step_aliases(step):
    """Every handle a step can be recognized by, most specific first: its explicit `id`,
    then its normalized text (lowercased, whitespace collapsed).

    Both, not one of them, because the two sides use different handles: a caller that
    assigns ids matches by id, while the assistant re-declares steps by wording. Text
    normalization means a reflowed line is still the same step. A step with neither has
    no identity at all: it can only be appended, never matched."""
    if not isinstance(step, dict):
        return []
    out = []
    sid = step.get('id')
    if sid is not None and str(sid).strip():
        out.append('id:' + str(sid).strip())
    text = re.sub(r'\s+', ' ', str(step.get('text') or '')).strip().lower()
    if text:
        out.append('text:' + text)
    return out


def _index(index, step):
    """Register a step under all its handles. First writer of a handle wins, so a
    duplicated wording never lets a later step hijack an earlier one's identity."""
    for alias in step_aliases(step):
        index.setdefault(alias, step)


def _lookup(index, step):
    """The stored step this snapshot step refers to, or None."""
    for alias in step_aliases(step):
        if alias in index:
            return index[alias]
    return None


def _buckets(plan):
    """Plan -> [(phase_title_or_None, [steps])]. A flat plan is one unnamed bucket, so
    merging is written once and works on both shapes."""
    phases = plan.get('phases') if isinstance(plan, dict) else None
    if isinstance(phases, list) and phases:
        out = []
        for ph in phases:
            if isinstance(ph, dict):
                out.append((ph.get('title'), [s for s in (ph.get('steps') or []) if isinstance(s, dict)]))
        if out:
            return out
    steps = plan.get('steps') if isinstance(plan, dict) else None
    return [(None, [s for s in (steps or []) if isinstance(s, dict)])]


def _target_bucket(old_title, old_index, new_titles):
    """Where a surviving old step lands when the snapshot reshaped the phases: same
    title if it is still there, else the same position, else the last bucket. History
    never falls off the edge just because a phase was renamed away."""
    if old_title is not None and old_title in new_titles:
        return new_titles.index(old_title)
    if 0 <= old_index < len(new_titles):
        return old_index
    return len(new_titles) - 1


def merge_plan(old, new, stamp=None):
    """Merge a snapshot into the stored plan. Pure function, no I/O.

    Everything the module docstring promises lives here: done is indestructible, the
    snapshot owns the active part, `dropped` removes only non-done steps, and the
    output is ordered active-then-history."""
    if not isinstance(new, dict):
        raise ValueError('plan must be a JSON object')
    old = old if isinstance(old, dict) else {}
    stamp = stamp or time.strftime('%Y-%m-%d %H:%M')

    old_buckets = _buckets(old)
    new_buckets = _buckets(new)
    new_titles = [t for t, _ in new_buckets]
    slots = [{'new_active': [], 'survivors': [], 'old_done': [], 'new_done': []}
             for _ in new_buckets]

    # Index the stored steps once. `done` and active are kept apart because they obey
    # opposite rules: one is frozen, the other is the snapshot's to rewrite.
    old_done_idx, old_active_idx = {}, {}
    for _title, steps in old_buckets:
        for st in steps:
            _index(old_done_idx if _state(st) == DONE else old_active_idx, st)

    # Consumption is tracked by object identity, not by handle: a stored step matched
    # by its text must not resurface just because it also carries an id.
    claimed = set()

    for bi, (_title, steps) in enumerate(new_buckets):
        for st in steps:
            state = _state(st)
            if _lookup(old_done_idx, st) is not None:
                continue                      # frozen: no edit, no revert, no drop
            prev = _lookup(old_active_idx, st)
            if prev is not None:
                claimed.add(id(prev))
            if state == DROPPED:
                continue                      # a no-op when nothing matched
            # Field-wise, not wholesale: the snapshot wins on every field it DECLARES
            # (send "note": "" to clear one) and the stored value survives on the rest.
            # Otherwise the usual one-liner `{"text": X, "state": "done"}` would strip
            # goal/substeps/result at the exact moment the step becomes frozen, and the
            # history would be a list of bare titles.
            step = dict(prev) if prev else {}
            step.update(st)
            if state == DONE:
                # setdefault, not assignment: a caller replaying a real completion time
                # keeps it. Stamped once, then frozen with the step itself.
                step.setdefault('doneAt', stamp)
                slots[bi]['new_done'].append(step)
            else:
                slots[bi]['new_active'].append(step)

    # Stored steps the snapshot did not mention. Walked in stored order, so finished
    # history keeps the sequence it was finished in.
    for bi, (title, steps) in enumerate(old_buckets):
        target = _target_bucket(title, bi, new_titles)
        for st in steps:
            if _state(st) == DONE:
                slots[target]['old_done'].append(st)
            elif id(st) not in claimed:
                slots[target]['survivors'].append(st)

    merged_buckets = [s['new_active'] + s['survivors'] + s['old_done'] + s['new_done']
                      for s in slots]

    # Top-level fields describe the present, so the snapshot wins; a field the snapshot
    # omits keeps its stored value (a partial declaration must not erase the goal).
    out = {k: v for k, v in old.items() if k not in ('steps', 'phases')}
    out.update({k: v for k, v in new.items() if k not in ('steps', 'phases')})
    if any(t is not None for t in new_titles) or len(new_buckets) > 1:
        out.pop('steps', None)
        out['phases'] = [{'title': t, 'steps': merged_buckets[i]}
                         for i, t in enumerate(new_titles)]
    else:
        out.pop('phases', None)               # or collect_steps would read stale phases
        out['steps'] = merged_buckets[0]
    return out


def read_plan(channel, root=None):
    """The stored plan of a channel, or {} when there is none / it is unreadable."""
    path = os.path.join(root or channels_dir(), channel, 'plan.json')
    try:
        with open(path, encoding='utf-8') as f:
            plan = json.load(f)
        return plan if isinstance(plan, dict) else {}
    except Exception:
        return {}


def write_plan(channel, plan, root=None):
    """MERGE a plan snapshot into <channels>/<channel>/plan.json. Returns (done, total).

    `plan` is the parsed dict; `root` overrides the channels dir (tests only). Stamps
    `updated` so the sidebar can show staleness, writes atomically, then lazily
    registers the tab. Raises on a genuinely unwritable target: callers that must not
    fail a turn over a plan (runner.py) catch it themselves.

    It MERGES rather than replaces (see the module docstring): the snapshot is the
    current picture, the file is the history, and history is not the snapshot's to
    delete."""
    if not isinstance(plan, dict):
        raise ValueError('plan must be a JSON object')
    root = root or channels_dir()
    plan = merge_plan(read_plan(channel, root), plan)
    plan['updated'] = time.strftime('%Y-%m-%d %H:%M')
    ch_dir = os.path.join(root, channel)
    os.makedirs(ch_dir, exist_ok=True)
    _write_json_atomic(os.path.join(ch_dir, 'plan.json'), plan)
    try:
        ensure_registered(root, channel, plan.get('goal'))
    except Exception:
        pass          # a tab that fails to auto-name must never lose the plan itself
    steps = collect_steps(plan)
    done = sum(1 for s in steps if isinstance(s, dict) and s.get('state') == 'done')
    return done, len(steps)


def main(argv=None):
    """CLI kept compatible with the old set-plan.cjs / set-plan.sh:
        plan_store.py <channel> plan.json     |  echo '{...}' | plan_store.py <channel>
    A token that is an existing file is the source; any other token is the channel."""
    args = list(sys.argv[1:] if argv is None else argv)
    channel = os.environ.get('CHANNEL') or None
    source = None
    for a in args:
        if a == '-':
            continue
        if source is None and os.path.isfile(a):
            source = a
            continue
        channel = a
    channel = channel or 'main'

    raw = open(source, encoding='utf-8').read() if source else sys.stdin.read()
    if not raw.strip():
        sys.stderr.write('plan_store: no plan JSON provided (file or stdin).\n')
        return 1
    try:
        plan = json.loads(raw)
    except Exception as e:
        sys.stderr.write('plan_store: invalid JSON — %s\n' % e)
        return 1
    try:
        done, total = write_plan(channel, plan)
    except Exception as e:
        sys.stderr.write('plan_store: %s\n' % e)
        return 1
    # Report the MERGED goal, not the snapshot's: a partial snapshot legitimately omits
    # it, and echoing an empty line there reads like the goal was just erased.
    goal = read_plan(channel).get('goal') or ''
    print('[%s] plan: %s — %d/%d done' % (channel, goal, done, total))
    return 0


if __name__ == '__main__':
    sys.exit(main())
