#!/usr/bin/env python3
"""batch_claim: атомарне право «хто публікує підсумок пачки» (specs/agent-batch-summary/spec.md,
plan.md S4, критерій К6).

ПРИВІД. Коли пачка агентів завершується, кілька агентів фінішують майже одночасно. Кожен
перевіряє, чи можна публікувати підсумок, і кожен бачить, що решта вже завершилась. Без
захисту вийде два-три однакові підсумки замість одного — це не гіпотеза, а прямий наслідок
того, що стан живе у файлах без транзакцій. Потрібен механізм, у якому право отримує РІВНО
ОДИН претендент, скільки б їх не прийшло одночасно.

МЕХАНІЗМ. Ексклюзивне СТВОРЕННЯ файлу-претензії (`os.open` з `O_CREAT|O_EXCL`): хто створив
файл, той і отримав право, решта отримують `FileExistsError`. Атомарність тут дає файлова
система, вигадувати нічого не треба — той самий крос-платформний трюк, яким `append-mutex.cjs`
(S0, `channels/<id>/.append.mutex`) закриває гонку номера повідомлення без fcntl, якого нема
на Windows.

ЧИМ ЦЕ НЕ МЬЮТЕКС. `append-mutex.cjs` тримає лок на час короткого запису і звільняє його
одразу після — семантика короткої критичної секції. Претензія на підсумок пачки НАЗАВЖДИ:
вона мусить відповідати на питання «цей підсумок уже робили?» навіть через добу, тому тут
немає й не буде автозвільнення по виходу з процесу.

ТРИ СТАНИ: `free` (файлу нема, право вільне), `claimed` (файл є, претендент ще працює),
`done` (претендент фактично опублікував підсумок і сам про це відзвітував через mark_done).

ЗАВИСЛИЙ ПРЕТЕНДЕНТ. Претендент, що захопив право і впав до публікації, назавжди заблокував
би підсумок цієї пачки — постійна претензія без запобіжника саме так і працює. Тому окремо:
`stale_claim` лише ПОВІДОМЛЯЄ про застарілу незавершену претензію за порогом часу, який задає
викликач, а `release_stale_claim` це окрема явна ДІЯ зняття. Автоматичного зняття тут немає:
рішення знімати чи ні належить викликачу (agent_worker у наступному сабтаску), не механізму.
"""
import json
import os
import time

CLAIM_FILENAME = 'summary-claim.json'


def batch_dir(channels_dir, channel_id, batch_id):
    return os.path.join(channels_dir, channel_id, 'batches', batch_id)


def claim_path(channels_dir, channel_id, batch_id):
    return os.path.join(batch_dir(channels_dir, channel_id, batch_id), CLAIM_FILENAME)


def _read(path):
    try:
        with open(path, encoding='utf-8') as fh:
            return json.load(fh)
    except (FileNotFoundError, json.JSONDecodeError):
        return None


def try_claim(channels_dir, channel_id, batch_id):
    """Спроба стати ЄДИНИМ претендентом, кому дозволено опублікувати підсумок цієї пачки.

    Повертає True, якщо ЦЕЙ виклик щойно створив претензію (право за викликачем), False —
    якщо претензія на цю пачку вже існує (хтось інший її тримає, живий чи мертвий). Права,
    відкликаного через release_stale_claim, можна забрати повторним викликом.
    """
    target_dir = batch_dir(channels_dir, channel_id, batch_id)
    os.makedirs(target_dir, exist_ok=True)
    path = os.path.join(target_dir, CLAIM_FILENAME)
    now = time.time()
    payload = json.dumps({
        'pid': os.getpid(),
        'claimedAt': now,
        'claimedAtHuman': time.strftime('%Y-%m-%d %H:%M:%S', time.localtime(now)),
        'done': False,
        'doneAt': None,
    }).encode('utf-8')
    try:
        fd = os.open(path, os.O_CREAT | os.O_EXCL | os.O_WRONLY)
    except FileExistsError:
        return False
    try:
        os.write(fd, payload)
    finally:
        os.close(fd)
    return True


def claim_state(channels_dir, channel_id, batch_id):
    """'free' | 'claimed' | 'done'. Файл, що існує, але не читається (пошкоджений
    запис посеред запису), звітується як 'claimed', а не 'free': O_EXCL все одно
    вважає його зайнятим, тож звіт про стан не сміє брехати про вільне місце."""
    path = claim_path(channels_dir, channel_id, batch_id)
    if not os.path.exists(path):
        return 'free'
    data = _read(path)
    if data is None:
        return 'claimed'
    return 'done' if data.get('done') else 'claimed'


def mark_done(channels_dir, channel_id, batch_id):
    """Позначити ВЖЕ ЗАХОПЛЕНУ претензію як доведену до кінця: викликач насправді
    опублікував підсумок. Пише через тимчасовий файл + os.replace (атомарна заміна
    і на POSIX, і на Windows), щоб читач ніколи не побачив напівзаписаний файл."""
    path = claim_path(channels_dir, channel_id, batch_id)
    data = _read(path) or {}
    data['done'] = True
    data['doneAt'] = time.time()
    tmp = f'{path}.tmp-{os.getpid()}'
    with open(tmp, 'w', encoding='utf-8') as fh:
        json.dump(data, fh)
    os.replace(tmp, path)


def stale_claim(channels_dir, channel_id, batch_id, threshold_seconds):
    """None якщо застарілої незавершеної претензії немає (вільно, done, або ще свіжа).
    Інакше словник претензії з доданим 'ageSeconds' — досить, щоб побачити хто (pid) і
    скільки вже висить, і вирішити знімати чи ні."""
    data = _read(claim_path(channels_dir, channel_id, batch_id))
    if data is None or data.get('done'):
        return None
    claimed_at = data.get('claimedAt')
    if not isinstance(claimed_at, (int, float)):
        return None
    age = time.time() - claimed_at
    if age <= threshold_seconds:
        return None
    info = dict(data)
    info['ageSeconds'] = age
    return info


def release_stale_claim(channels_dir, channel_id, batch_id, threshold_seconds):
    """Явна дія: зняти застарілу незавершену претензію, щоб новий претендент міг
    спробувати знову. Відмовляється (False), якщо за тим самим порогом претензія
    насправді ще не застаріла, або вже доведена до кінця — цю дію ніколи не викликає
    сам механізм, лише викликач, що свідомо вирішив прибрати мертвого власника.
    """
    if stale_claim(channels_dir, channel_id, batch_id, threshold_seconds) is None:
        return False
    path = claim_path(channels_dir, channel_id, batch_id)
    # Повторна перевірка прямо перед видаленням звужує (але не усуває) TOCTOU-гонку
    # з власником, що саме зараз доводить претензію до кінця — той самий best-effort
    # компроміс, що й clearIfStale в append-mutex.cjs.
    if stale_claim(channels_dir, channel_id, batch_id, threshold_seconds) is None:
        return False
    try:
        os.remove(path)
    except FileNotFoundError:
        return False
    return True
