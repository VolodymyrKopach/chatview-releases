#!/usr/bin/env python3
"""ChatView cross-platform service layer.

ONE place for every OS-specific quirk that used to be scattered across entry.py,
runner.py and server.py as inline `sys.platform` checks. The rest of the codebase
depends on the abstract `Platform` interface (Dependency Inversion), never on
`sys.platform` directly, so adding/adjusting an OS is a local change here.

Patterns:
  * Strategy      - MacPlatform / WindowsPlatform / LinuxPlatform each own only
                    their own OS behaviour (Single Responsibility).
  * Factory Method - `Platform.current()` returns the right strategy for the host.
                    Adding an OS = a new subclass, zero caller edits (Open/Closed).

Pure stdlib so it imports identically in dev and in the frozen PyInstaller build.
"""
import os
import sys
import abc
import time
import shutil
import signal
import threading
import subprocess
import contextlib


# --- claude CLI resolution cache -------------------------------------------
# find_claude() is polled by the onboarding card every ~2.5s, and the deep probes
# (npm prefix -g, login-shell PATH) shell out. Without a cache that is a subprocess
# storm. A HIT is cached until the file disappears; a MISS is re-probed after
# _CLAUDE_MISS_TTL so a fresh install is picked up on its own within ~20s (the
# installer also calls invalidate_claude_cache() for an instant flip).
_CLAUDE_MISS_TTL = 20.0
_CLAUDE_CACHE = {'path': None, 'at': 0.0, 'searched': []}
_CLAUDE_CACHE_LOCK = threading.Lock()


# --- РЕЖИМ ЗБІРКИ: хто ця копія застосунку ------------------------------------
# Роздавальна (public) і особиста (personal) збірки живуть на одній машині і НЕ мають
# права ділити теку даних. Ділили: домівка була зашита рядком 'ChatView' і про режим не
# знала, тому гола збірка відкривала теку особистої і показувала людині 293 чужі факти
# памʼяті, чужі налаштування і чужий keys.json.
#
# Канонічне імʼя лишається за РОЗДАЧЕЮ, а не за особистою збіркою, і це навмисно: людей
# з роздачею буде багато і мігрувати їм нічого, а особиста збірка одна і переїзд для неї
# робиться один раз (entry.migrate_personal_home).
#
# Режим приходить оточенням, бо його ставить лаунчер, прочитавши позначку всередині
# бандла (entry.read_build_mode -> CHATVIEW_BUILD_MODE). НЕВІДОМЕ значення тут це
# ОСОБИСТА збірка, ніколи не роздавальна: описка в режимі не сміє відкрити чужій людині
# теку з даними, а описка в інший бік дає лише зайву порожню теку.
BUILD_MODE_ENV = 'CHATVIEW_BUILD_MODE'
BUILD_PERSONAL = 'personal'
BUILD_PUBLIC = 'public'


def normalize_build_mode(value) -> str:
    """Довільне значення -> рівно 'public' або 'personal'."""
    try:
        raw = str(value or '').strip().lower()
    except Exception:
        return BUILD_PERSONAL
    return BUILD_PUBLIC if raw == BUILD_PUBLIC else BUILD_PERSONAL


def build_mode(env=None) -> str:
    """Режим ЦЬОГО процесу з оточення. Немає змінної = особиста збірка."""
    src = os.environ if env is None else env
    return normalize_build_mode(src.get(BUILD_MODE_ENV))


def invalidate_claude_cache():
    """Force the next find_claude() to re-probe (call after installing the CLI)."""
    with _CLAUDE_CACHE_LOCK:
        _CLAUDE_CACHE['path'] = None
        _CLAUDE_CACHE['at'] = 0.0


def safe_pgid(pid):
    """pgid, яким МОЖНА бити killpg, або None якщо група чужа.

    Правило одне: сигнал групі дозволений лише коли `pid` САМ є лідером своєї
    групи (pgid == pid). Тоді група створена спеціально для нього і не містить
    нікого стороннього.

    Навіщо: SDK-двигун спавнить claude через anyio.open_process БЕЗ
    start_new_session, тож claude сідає в групу раннера. Заміряно на живій
    машині 2026-07-30: claude pid 9554, pgid 62218, а 62218 це pid runner.py.
    killpg по такій групі валив раннер разом з УСІМА каналами, тобто кнопка
    «Стоп» в одному чаті гасила движок цілком. Тут ця можливість зникає:
    неізольований pid отримує None і викликач б'є точково по pid.

    Повертає None також для власної групи процесу (сервер/раннер ніколи не
    вбиває себе) і на платформах без getpgid (Windows).
    """
    if not hasattr(os, 'getpgid'):
        return None
    try:
        pid = int(pid)
    except (TypeError, ValueError):
        return None
    if pid <= 1:                       # 0 = «моя група», 1 = init. Ніколи.
        return None
    try:
        pgid = os.getpgid(pid)
    except (ProcessLookupError, PermissionError, OSError):
        return None
    if pgid != pid:                    # не лідер: група спільна з раннером
        return None
    try:
        if pgid == os.getpgrp():       # наша власна група, подвійний пояс
            return None
    except OSError:
        pass
    return pgid


class Platform(abc.ABC):
    """Interface every concrete platform implements. Callers hold a Platform, not
    a `sys.platform` string, so behaviour is swappable and testable."""

    name = 'base'

    # --- writable per-user data home (survives app delete/update/reinstall) ---
    #
    # Імена теки на КОЖНІЙ платформі: роздавальна збірка сидить на канонічному імені,
    # особиста на власному. Різниця в написанні (дужки на macOS, дефіс на решті) це не
    # смак, а місцева традиція: у `Application Support` теки звуться людською назвою з
    # пробілами, а в `%APPDATA%` і `~/.local/share` пробіл у шляху досі ламає чужі
    # скрипти. Підклас перевизначає лише те, що в нього інакше.
    HOME_DIR_PUBLIC = 'ChatView'
    HOME_DIR_PERSONAL = 'ChatView-Personal'

    @abc.abstractmethod
    def data_home_base(self) -> str:
        """Тека ОС, усередині якої живе домівка застосунку (без імені самої домівки)."""

    def data_home_name(self, mode=None) -> str:
        """Імʼя теки домівки для режиму. Немає режиму = беремо з оточення."""
        chosen = build_mode() if mode is None else normalize_build_mode(mode)
        return self.HOME_DIR_PUBLIC if chosen == BUILD_PUBLIC else self.HOME_DIR_PERSONAL

    def data_home(self, mode=None) -> str:
        """OS-standard writable dir for ChatView user data, OUTSIDE the app bundle.

        РІЗНИЙ режим збірки означає РІЗНУ теку, інакше роздавальна копія відкриває
        дані особистої (див. specs/public-build-home-isolation)."""
        return os.path.join(self.data_home_base(), self.data_home_name(mode))

    # --- process management for the spawned `claude` tree ---
    @abc.abstractmethod
    def process_group_kwargs(self) -> dict:
        """Popen kwargs that put a spawned child in its OWN process group, so the
        whole tree (claude + its children) can be killed together."""

    @abc.abstractmethod
    def kill_process_tree(self, pid: int) -> bool:
        """Kill `pid` AND its children. Returns True if a kill was attempted.
        Best-effort: a already-dead pid is not an error."""

    # --- «чи живий цей pid», без побічних ефектів -----------------------------
    def pid_alive(self, pid) -> bool:
        """Чи існує процес `pid`. НІЧОГО не робить з ним, лише питає.

        Окремий метод, бо канонічна POSIX-ідіома `os.kill(pid, 0)` на Windows не
        просто не працює, а робить ПРОТИЛЕЖНЕ: там немає сигналу 0, і документація
        os.kill каже прямо, що будь-яке значення, крім CTRL_C_EVENT і
        CTRL_BREAK_EVENT, віддається в TerminateProcess. Тобто «проба» відкриває
        хендл і завершує процес з кодом 0, а зверху рапортує «живий». Панель
        агентів кличе це кожні дві секунди з кожної відкритої колонки, тож на
        Windows вона вбивала рівно тих, кого показувала."""
        return False

    # --- ексклюзивний лок на файл (index.json має одного письменника) ---------
    @contextlib.contextmanager
    def file_lock(self, fh):
        """Ексклюзивний лок на ВЖЕ ВІДКРИТИЙ файл. Віддає True, якщо лок узято.

        Один контекст замість чотирьох `import fcntl` у server.py і пʼятого в
        runner.py. Модуля fcntl на Windows не існує в принципі, тож кожен такий
        рядок був ModuleNotFoundError на запис бульбашки, тобто /api/send лежав
        цілком.

        Best-effort за задумом: якщо лок узяти не вдалось, письменник усе одно
        пише. Втратити лок погано (можлива колізія id з render-message.cjs, який
        пише в ту саму теку взагалі без локу), втратити повідомлення користувача
        гірше."""
        held = False
        try:
            held = bool(self._lock_acquire(fh))
        except Exception:
            held = False
        try:
            yield held
        finally:
            if held:
                try:
                    self._lock_release(fh)
                except Exception:
                    pass

    def _lock_acquire(self, fh) -> bool:
        """Захопити лок. База: чесний no-op, а не вдавання успіху."""
        return False

    def _lock_release(self, fh) -> None:
        pass

    # --- locating the user's already-installed Claude Code CLI (BYOK model) ---
    #
    # THE single resolver for the whole app. Until 2026-07-30 four independent
    # copies of this logic lived in chatview_platform / runner / server /
    # onboarding, each with a DIFFERENT candidate list. Same machine, same CLI,
    # opposite answers: the chat engine drove claude happily while the onboarding
    # card sat on "код не знайдено" forever, and its install button was a no-op
    # because the post-install truth check used the blind list too. The concrete
    # hole: the official installer puts the CLI in ~/.local/bin, and the Windows
    # candidate list had no ~\.local\bin\claude.exe at all. Everything now routes
    # here, so a path added once is known everywhere.
    #
    # Order (first hit wins):
    #   1. CLAUDE_BIN env         - explicit escape hatch, always honoured
    #   2. PATH, native name      - Windows looks for claude.exe, never the npm
    #                               .cmd wrapper: cmd.exe caps the command line at
    #                               ~8191 chars and the runner's big
    #                               --append-system-prompt blows past it
    #   3. npm native layout      - <prefix>\node_modules\...\bin\claude.exe
    #   4. well-known install dirs- native installer, Homebrew, npm, bun, volta
    #   5. npm global bin         - nvm / custom prefix that which() cannot see
    #   6. login-shell PATH probe - a .app started from Finder/launchd inherits a
    #                               thin PATH; the user's own shell knows better
    #   7. last resort            - the .cmd wrapper on Windows (short prompts ok)
    def find_claude(self, refresh=False):
        """Absolute path to the `claude` executable, or None if not installed."""
        now = time.monotonic()
        if not refresh:
            with _CLAUDE_CACHE_LOCK:
                hit = _CLAUDE_CACHE['path']
                if hit and os.path.isfile(hit):
                    return hit
                if hit is None and _CLAUDE_CACHE['at'] \
                        and (now - _CLAUDE_CACHE['at']) < _CLAUDE_MISS_TTL:
                    return None
        path, searched = self._probe_claude()
        with _CLAUDE_CACHE_LOCK:
            _CLAUDE_CACHE['path'] = path
            _CLAUDE_CACHE['at'] = time.monotonic()
            _CLAUDE_CACHE['searched'] = searched
        return path

    def claude_search_report(self):
        """{path, platform, searched:[{where,path,hit}]} — every location the last
        probe actually looked at. Surfaced by /api/desktop/status so a future
        "not found" says WHERE we looked instead of leaving the user guessing."""
        self.find_claude()
        with _CLAUDE_CACHE_LOCK:
            return {'path': _CLAUDE_CACHE['path'], 'platform': self.name,
                    'searched': list(_CLAUDE_CACHE['searched'])}

    def _probe_claude(self):
        """Run the full search. Returns (path_or_None, searched_trace)."""
        searched = []

        def probe(where, cand):
            if not cand:
                return None
            cand = os.path.expanduser(cand)
            ok = os.path.isfile(cand) and os.access(cand, os.X_OK)
            searched.append({'where': where, 'path': cand, 'hit': ok})
            return cand if ok else None

        hit = probe('CLAUDE_BIN', os.environ.get('CLAUDE_BIN'))
        if hit:
            return hit, searched

        for name in self._claude_path_names():
            found = shutil.which(name)
            searched.append({'where': 'PATH', 'path': found or name, 'hit': bool(found)})
            if found:
                return found, searched

        hit = probe('npm-native', self._npm_native_claude())
        if hit:
            return hit, searched

        for cand in self._claude_candidates():
            hit = probe('known-dir', cand)
            if hit:
                return hit, searched

        for cand in self._npm_global_candidates():
            hit = probe('npm-global', cand)
            if hit:
                return hit, searched

        hit = probe('login-shell', self._login_shell_claude())
        if hit:
            return hit, searched

        hit = probe('wrapper', self._claude_last_resort())
        if hit:
            return hit, searched
        return None, searched

    # --- probe steps (subclasses override only what differs) ------------------
    def _claude_path_names(self):
        """Executable names to look for on PATH, in preference order."""
        return ['claude']

    def _claude_candidates(self):
        """Per-OS well-known install locations. Overridden by subclasses."""
        return []

    def _npm_native_claude(self):
        """Windows only: the real .exe inside the npm package next to the wrapper."""
        return None

    def _claude_last_resort(self):
        """Windows only: accept the npm .cmd wrapper rather than report nothing."""
        return None

    def _login_shell_claude(self):
        """POSIX only: ask the user's login shell where claude is."""
        return None

    def _quiet_kwargs(self):
        """Popen kwargs that keep helper probes from flashing a console window."""
        return {}

    def _npm_global_candidates(self):
        """claude inside npm's own global bin. Covers nvm and custom prefixes,
        which shutil.which() cannot see from a GUI-launched process."""
        npm = None
        for name in ('npm', 'npm.cmd'):
            npm = shutil.which(name)
            if npm:
                break
        if not npm:
            return []
        out = []
        for sub in (['bin', '-g'], ['prefix', '-g']):
            try:
                r = subprocess.run([npm] + sub, capture_output=True, text=True,
                                   timeout=8, **self._quiet_kwargs())
            except Exception:
                continue
            lines = [ln.strip() for ln in (r.stdout or '').splitlines() if ln.strip()]
            base = lines[-1] if lines else ''
            if not base or not os.path.isdir(base):
                continue
            for d in (base, os.path.join(base, 'bin')):
                for nm in self._claude_path_names() + ['claude']:
                    cand = os.path.join(d, nm)
                    if cand not in out:
                        out.append(cand)
        return out

    def claude_env(self, base=None):
        """Environment that lets a spawned `claude` actually see its credentials.

        Second half of the same "works in a terminal, dead in the .app" family of
        bugs. macOS stores the login token in the Keychain and the CLI looks it up
        BY ACCOUNT NAME, so a process started without $USER (launchd, a
        Finder-launched .app, a frozen build) reports loggedIn:false even though
        the user is signed in — and the onboarding gate, which needs found AND
        authed, stays shut forever. Measured on this box 2026-07-30:
            env -i HOME=… PATH=…            -> "loggedIn": false
            env -i HOME=… PATH=… USER=…     -> "loggedIn": true
        So we backfill USER/LOGNAME/HOME when missing, and prepend the dir the CLI
        actually lives in to PATH so its own child tools resolve too. Never
        overwrites a value the caller already set."""
        env = dict(base if base is not None else os.environ)
        home = env.get('HOME') or os.path.expanduser('~')
        env.setdefault('HOME', home)
        user = env.get('USER') or env.get('LOGNAME') or env.get('USERNAME')
        if not user:
            try:
                import getpass
                user = getpass.getuser()
            except Exception:
                user = os.path.basename(home) or ''
        if user:
            env.setdefault('USER', user)
            env.setdefault('LOGNAME', user)
            if os.name == 'nt':
                env.setdefault('USERNAME', user)
        binp = self.find_claude()
        if binp:
            bindir = os.path.dirname(binp)
            parts = [p for p in (env.get('PATH') or '').split(os.pathsep) if p]
            if bindir and bindir not in parts:
                env['PATH'] = os.pathsep.join([bindir] + parts)
        return env

    # --- opening the UI (kept behind the interface for a future native webview) ---
    def open_url(self, url: str) -> None:
        import webbrowser
        try:
            webbrowser.open(url)
        except Exception:
            pass

    # --- relaunching the whole app ("Restart to update", best practice) ---------
    def _detach_kwargs(self) -> dict:
        """Popen kwargs for a FULLY DETACHED child that outlives this process, so we
        can spawn a fresh app instance and then exit. POSIX: own session (via
        process_group_kwargs); Windows overrides to add DETACHED_PROCESS."""
        kw = {'stdin': subprocess.DEVNULL, 'stdout': subprocess.DEVNULL,
              'stderr': subprocess.DEVNULL}
        kw.update(self.process_group_kwargs())
        return kw

    def relaunch(self, port=None, wait_for_port=True, log=lambda *_: None):
        """Spawn a FRESH copy of the app and return the child Popen (the caller then
        exits THIS process). Modeled on Chrome/VSCode «Relaunch»: pinned to the SAME
        port with the browser suppressed, so the already-open tab reloads in place
        once the new server is up, and the staged payload is applied automatically on
        the fresh boot (entry.choose_code_dir picks it up). On a frozen build
        sys.executable IS the app binary; in dev we re-exec argv. Best-effort:
        returns None on failure (caller stays running)."""
        if getattr(sys, 'frozen', False):
            argv = [sys.executable]
        else:
            argv = [sys.executable] + list(sys.argv)  # dev: re-exec the script
        env = dict(os.environ)
        if port:
            env['VIZ_CHAT_PORT'] = str(port)     # same port -> the tab reloads in place
        env['CHATVIEW_NO_BROWSER'] = '1'          # do not pop a second browser tab
        if wait_for_port:
            env['CHATVIEW_BIND_WAIT'] = '1'       # new server retries bind until we free it
        try:
            return subprocess.Popen(argv, env=env, **self._detach_kwargs())
        except Exception as e:
            log('[relaunch] spawn failed: %s\n' % e)
            return None

    # --- onboarding the CLI FOR the user (install + sign-in) --------------------
    def claude_install_command(self):
        """Argv for the official Claude Code installer on this OS, or None if we
        cannot auto-install (caller then falls back to the manual instructions)."""
        return None

    def spawn_login(self, argv):
        """Start `claude auth login` so it behaves as if run interactively (opens the
        browser, completes via its own localhost OAuth callback). Returns the Popen.
        Concrete per-OS: pty on POSIX, plain detached process on Windows."""
        raise NotImplementedError

    # --- factory ---------------------------------------------------------------
    @staticmethod
    def current() -> 'Platform':
        """Return the Platform strategy for the host OS (Factory Method)."""
        if sys.platform == 'darwin':
            return MacPlatform()
        if os.name == 'nt' or sys.platform == 'win32':
            return WindowsPlatform()
        return LinuxPlatform()


class _PosixPlatform(Platform):
    """Shared POSIX behaviour (Mac + Linux): own session per child, kill via
    process-group signal. OS-specific paths stay in the leaf subclasses."""

    def process_group_kwargs(self) -> dict:
        # start_new_session=True -> child becomes a session/group leader; we kill
        # the whole group with killpg(-pgid).
        return {'start_new_session': True}

    def kill_process_tree(self, pid: int) -> bool:
        # safe_pgid, не getpgid: група дозволена лише коли pid її лідер, інакше
        # б'ємо точково по pid (див. safe_pgid).
        pgid = safe_pgid(pid)
        try:
            if pgid is not None:
                os.killpg(pgid, signal.SIGTERM)
            else:
                os.kill(pid, signal.SIGTERM)
        except (ProcessLookupError, PermissionError, OSError):
            return False
        # escalate to SIGKILL if still alive (caller may also re-invoke later)
        try:
            if pgid is not None:
                os.killpg(pgid, signal.SIGKILL)
            else:
                os.kill(pid, signal.SIGKILL)
        except (ProcessLookupError, PermissionError, OSError):
            pass
        if pgid is None:
            # Група була чужа, тож дерево не накрилось сигналом групи. Добиваємо
            # прямих дітей окремо, інакше MCP-сервери й тули лишаються сиротами.
            try:
                subprocess.run(['pkill', '-KILL', '-P', str(pid)],
                               capture_output=True, timeout=3)
            except Exception:
                pass
        return True

    def pid_alive(self, pid) -> bool:
        # Тут сигнал 0 означає рівно те, що написано: «перевір, чи є такий процес».
        # Це ЄДИНЕ місце в репо, де така проба дозволена (страж:
        # tests/unit/test_windows_pid_alive.py).
        try:
            pid = int(pid)
        except (TypeError, ValueError):
            return False
        if pid <= 0:                       # 0 = «моя група», відʼємне = група
            return False
        try:
            os.kill(pid, 0)
            return True
        except Exception:
            return False

    def _lock_acquire(self, fh) -> bool:
        import fcntl
        fcntl.flock(fh.fileno(), fcntl.LOCK_EX)
        return True

    def _lock_release(self, fh) -> None:
        import fcntl
        fcntl.flock(fh.fileno(), fcntl.LOCK_UN)

    def _login_shell_claude(self):
        """Ask the user's LOGIN shell where claude is.

        A .app double-clicked from Finder (or started by launchd) inherits a thin
        PATH that has neither ~/.local/bin nor the nvm shims, so shutil.which()
        can miss a perfectly good install. The login shell sources the user's own
        profile, so it sees the real PATH. Best-effort: any failure -> None."""
        shell = os.environ.get('SHELL') or '/bin/sh'
        try:
            r = subprocess.run([shell, '-lc', 'command -v claude'],
                               capture_output=True, text=True, timeout=10)
        except Exception:
            return None
        # Profiles can print banners; take the last non-empty line that is a path.
        for line in reversed([ln.strip() for ln in (r.stdout or '').splitlines()]):
            if line.startswith('/'):
                return line
        return None

    def _posix_claude_dirs(self):
        """Install dirs shared by Mac and Linux, most-official first."""
        home = os.path.expanduser('~')
        return [
            os.path.join(home, '.local', 'bin'),      # official install.sh
            os.path.join(home, '.claude', 'local'),   # legacy local install
            os.path.join(home, '.npm-global', 'bin'), # npm config prefix=~/.npm-global
            os.path.join(home, '.bun', 'bin'),        # bun global
            os.path.join(home, '.volta', 'bin'),      # volta shims
            os.path.join(home, '.yarn', 'bin'),       # yarn global
        ]

    def claude_install_command(self):
        # Official native installer -> ~/.local/bin/claude (no sudo, no node needed).
        # find_claude() already knows that dir, so the CLI is discoverable right after.
        return ['/bin/sh', '-c', 'curl -fsSL https://claude.ai/install.sh | bash']

    def spawn_login(self, argv, env=None):
        # Attach to a pseudo-terminal so the CLI behaves as if interactive. We only
        # DRAIN the pty (so the child never blocks on a full buffer); we never parse
        # it for correctness - success is observed via `claude auth status`.
        import pty
        master, slave = pty.openpty()
        try:
            proc = subprocess.Popen(
                argv, stdin=slave, stdout=slave, stderr=slave,
                close_fds=True, env=self.claude_env(env),
                **self.process_group_kwargs())
        finally:
            os.close(slave)

        def _drain():
            try:
                while os.read(master, 1024):
                    pass
            except OSError:
                pass
            finally:
                try:
                    os.close(master)
                except OSError:
                    pass

        threading.Thread(target=_drain, daemon=True).start()
        return proc


class MacPlatform(_PosixPlatform):
    name = 'mac'

    HOME_DIR_PERSONAL = 'ChatView (Personal)'

    def data_home_base(self) -> str:
        return os.path.expanduser('~/Library/Application Support')

    def _claude_candidates(self):
        dirs = self._posix_claude_dirs() + [
            '/opt/homebrew/bin',    # Homebrew (Apple Silicon)
            '/usr/local/bin',       # Homebrew (Intel) / manual
            '/usr/bin',
        ]
        return [os.path.join(d, 'claude') for d in dirs]


class LinuxPlatform(_PosixPlatform):
    name = 'linux'

    def data_home_base(self) -> str:
        return os.environ.get('XDG_DATA_HOME') or os.path.expanduser('~/.local/share')

    def _claude_candidates(self):
        dirs = self._posix_claude_dirs() + [
            '/usr/local/bin',
            '/usr/bin',
            '/snap/bin',
        ]
        return [os.path.join(d, 'claude') for d in dirs]


class WindowsPlatform(Platform):
    name = 'windows'

    def data_home_base(self) -> str:
        return os.environ.get('APPDATA') or os.path.expanduser(r'~\AppData\Roaming')

    def process_group_kwargs(self) -> dict:
        # CREATE_NEW_PROCESS_GROUP so `taskkill /T` (or CTRL_BREAK) reaches children.
        # Attribute only exists on Windows, so read it dynamically to stay import-safe.
        flags = getattr(subprocess, 'CREATE_NEW_PROCESS_GROUP', 0)
        return {'creationflags': flags}

    def kill_process_tree(self, pid: int) -> bool:
        try:
            subprocess.run(['taskkill', '/F', '/T', '/PID', str(pid)],
                           stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
                           check=False)
            return True
        except Exception:
            return False

    # --- проба живості: OpenProcess, ніколи os.kill ---------------------------
    # STILL_ACTIVE=259 це те, що GetExitCodeProcess віддає для процесу, який ще
    # біжить. PROCESS_QUERY_LIMITED_INFORMATION (0x1000) навмисне вужчий за
    # PROCESS_QUERY_INFORMATION: його дають навіть на процеси з вищою цілісністю,
    # і він дозволяє рівно читання коду виходу, тобто нічим не ризикує.
    _STILL_ACTIVE = 259
    _PROCESS_QUERY_LIMITED_INFORMATION = 0x1000
    _ERROR_ACCESS_DENIED = 5
    _ERROR_INVALID_PARAMETER = 87

    def pid_alive(self, pid) -> bool:
        try:
            pid = int(pid)
        except (TypeError, ValueError):
            return False
        if pid <= 0:
            return False
        probe = self._alive_via_ctypes(pid)
        if probe is not None:
            return probe
        probe = self._alive_via_tasklist(pid)
        if probe is not None:
            return probe
        # Обидва пробники недоступні. Помилятись можна ЛИШЕ в бік «живий»: сирота
        # закриється пізніше, а живого агента ми не закриємо ніколи.
        return True

    def _alive_via_ctypes(self, pid):
        """True/False, або None якщо сам пробник недоступний (хай скаже tasklist)."""
        try:
            import ctypes
            k32 = ctypes.WinDLL('kernel32', use_last_error=True)
        except Exception:
            return None
        try:
            handle = k32.OpenProcess(
                self._PROCESS_QUERY_LIMITED_INFORMATION, False, pid)
            if not handle:
                err = ctypes.get_last_error()
                if err == self._ERROR_ACCESS_DENIED:
                    return True        # процес Є, просто чужий
                if err == self._ERROR_INVALID_PARAMETER:
                    return False       # такого pid у системі немає
                return None
            try:
                code = ctypes.c_ulong(0)
                if not k32.GetExitCodeProcess(handle, ctypes.byref(code)):
                    return None
                return code.value == self._STILL_ACTIVE
            finally:
                k32.CloseHandle(handle)
        except Exception:
            return None

    def _alive_via_tasklist(self, pid):
        """Фолбек без ctypes. Теж лише читає, нікого не чіпає."""
        try:
            r = subprocess.run(
                ['tasklist', '/FI', 'PID eq %d' % pid, '/NH', '/FO', 'CSV'],
                capture_output=True, text=True, timeout=8, **self._quiet_kwargs())
        except Exception:
            return None
        out = (r.stdout or '')
        if not out.strip():
            return None
        # Рядок з pid у лапках є ЛИШЕ коли процес існує; інакше tasklist друкує
        # «INFO: No tasks are running which match the criteria.»
        return ('"%d"' % pid) in out

    # --- лок на файл: msvcrt.locking по тому самому .append.lock --------------
    # LK_NBLCK (неблокуючий), а не LK_LOCK: LK_LOCK всередині сам крутить 10 спроб
    # по секунді і аж тоді кидає, тобто запис бульбашки міг би стати на 10 секунд.
    # Свій цикл дає той самий результат за передбачувані ~3 с.
    _LOCK_BYTES = 1
    _LOCK_TRIES = 60
    _LOCK_PAUSE = 0.05

    def _lock_acquire(self, fh) -> bool:
        import msvcrt
        fh.seek(0)
        for attempt in range(self._LOCK_TRIES):
            try:
                msvcrt.locking(fh.fileno(), msvcrt.LK_NBLCK, self._LOCK_BYTES)
                return True
            except OSError:
                if attempt == self._LOCK_TRIES - 1:
                    return False
                time.sleep(self._LOCK_PAUSE)
        return False

    def _lock_release(self, fh) -> None:
        import msvcrt
        fh.seek(0)
        msvcrt.locking(fh.fileno(), msvcrt.LK_UNLCK, self._LOCK_BYTES)

    def _detach_kwargs(self) -> dict:
        # DETACHED_PROCESS + own group + no console flash, so the relaunched app
        # survives this process exiting and does not steal our console.
        flags = getattr(subprocess, 'DETACHED_PROCESS', 0) \
            | getattr(subprocess, 'CREATE_NEW_PROCESS_GROUP', 0) \
            | getattr(subprocess, 'CREATE_NO_WINDOW', 0)
        return {'stdin': subprocess.DEVNULL, 'stdout': subprocess.DEVNULL,
                'stderr': subprocess.DEVNULL, 'creationflags': flags, 'close_fds': True}

    def claude_install_command(self):
        # Official Windows installer (PowerShell). Parallels install.sh on POSIX.
        return ['powershell', '-NoProfile', '-ExecutionPolicy', 'Bypass',
                '-Command', 'irm https://claude.ai/install.ps1 | iex']

    def spawn_login(self, argv, env=None):
        # No pty on Windows; the CLI opens the browser and completes via its callback.
        # CREATE_NO_WINDOW avoids a console flash; the group flag lets us kill the tree.
        flags = getattr(subprocess, 'CREATE_NO_WINDOW', 0) \
            | getattr(subprocess, 'CREATE_NEW_PROCESS_GROUP', 0)
        return subprocess.Popen(
            argv, stdin=subprocess.DEVNULL,
            stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
            env=self.claude_env(env), creationflags=flags)

    # --- claude resolution, Windows specifics ---------------------------------
    # The .exe MUST win over the npm .cmd wrapper: spawning the wrapper routes
    # through cmd.exe, whose command line is capped at ~8191 chars, and the
    # runner's --append-system-prompt exceeds that ("The command line is too
    # long."), which killed every chat turn. CreateProcess on the native .exe
    # allows 32767. So .exe first everywhere, .cmd only as a last resort.
    def _claude_path_names(self):
        return ['claude.exe']

    def _npm_native_claude(self):
        wrapper = shutil.which('claude')
        if not wrapper:
            return None
        # npm global layout: <prefix>\node_modules\@anthropic-ai\claude-code\bin\claude.exe
        return os.path.join(os.path.dirname(wrapper), 'node_modules',
                            '@anthropic-ai', 'claude-code', 'bin', 'claude.exe')

    def _claude_last_resort(self):
        return shutil.which('claude')

    def _quiet_kwargs(self):
        return {'creationflags': getattr(subprocess, 'CREATE_NO_WINDOW', 0)}

    def _claude_candidates(self):
        home = os.path.expanduser('~')
        appdata = os.environ.get('APPDATA', '')
        localapp = os.environ.get('LOCALAPPDATA', '')
        progfiles = os.environ.get('ProgramFiles', '')
        dirs = [
            # Official install.ps1 target. Its absence here was THE bug: the CLI
            # sat right there and the onboarding card still said "not found".
            os.path.join(home, '.local', 'bin'),
            os.path.join(home, '.claude', 'local'),
            os.path.join(localapp, 'Programs', 'claude') if localapp else '',
            os.path.join(appdata, 'npm') if appdata else '',
            os.path.join(home, '.bun', 'bin'),
            os.path.join(home, '.volta', 'bin'),
            os.path.join(progfiles, 'claude') if progfiles else '',
        ]
        cands = []
        for d in dirs:                       # .exe before .cmd in EVERY dir
            if not d:
                continue
            for nm in ('claude.exe', 'claude.cmd', 'claude.bat'):
                cands.append(os.path.join(d, nm))
        return cands


# Convenience singleton: `from chatview_platform import PLATFORM`
PLATFORM = Platform.current()


if __name__ == '__main__':
    p = Platform.current()
    print('platform :', p.name)
    print('build    :', build_mode())
    print('data_home:', p.data_home())
    print('  public  :', p.data_home('public'))
    print('  personal:', p.data_home('personal'))
    print('claude   :', p.find_claude())
    print('proc_kw  :', p.process_group_kwargs())
