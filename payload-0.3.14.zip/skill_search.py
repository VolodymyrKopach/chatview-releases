"""Пошук за наміром по каталогу скілів (стор помічників).

Задача, словами Vova: «сижу я, і в мене виникає якась задача, і я можу вже в
списку готових скілів знайти рішення. Просто заходжу, пишу, і воно щось шукає».

Тобто на вході НЕ назва скіла, а опис задачі українською. Пошук підрядком, який
тут був, на такий запит не відповідає в принципі: у каталозі 1552 зовнішні записи
англійською, і жодне слово фрази «у мене впав деплой» у них не зустрічається.

Тому два шари, які злиті через reciprocal rank fusion:

  1. ЛЕКСИЧНИЙ (BM25). Працює ЗАВЖДИ: офлайн, без ключа, без мережі. Українську
     тягне не морфологією, а доменним словником UA→EN (`UA_EN` нижче): «деплой»
     розкривається в deploy/deployment/rollback/ci, і BM25 уже має що шукати в
     англомовному корпусі. Це свідомо простий підхід замість стемера: доменних
     слів у продукті кількасот, а не мільйон, і словник видно очима.
  2. ВЕКТОРНИЙ (text-embedding-3-small, dimensions=256). Ловить те, чого в
     словнику нема: перефраз, синонім, суміжне поняття. Рахується ОДИН раз на
     весь каталог і лежить у skills-library/embeddings.json з відбитком (fp)
     кожного запису, тому оновлення каталогу перераховує ЛИШЕ нові записи.

Ключ береться там само, де його бере озвучка (BYOK, keys.json). Немає ключа,
немає мережі, немає кешу: другий шар просто мовчить, а перший віддає результат.
Пошук НЕ має права ставати мертвим через відсутній ключ, тому жодна гілка тут не
кидає нагору виняток і не малює червону картку.
"""

import json
import math
import os
import re
import hashlib
import threading

EMB_MODEL = 'text-embedding-3-small'
EMB_DIMS = 256              # не 1536: файл кешу роздувся б у 6 разів без виграшу в ранзі
EMB_BATCH = 128             # входів на один запит до /v1/embeddings
RRF_K = 60.0                # класична константа reciprocal rank fusion
LEX_DEPTH = 120             # скільки беремо з кожного шару перед злиттям
VEC_DEPTH = 120


# ── токенізація ────────────────────────────────────────────────────────────
_WORD_RE = re.compile(r"[a-zA-Z0-9Ѐ-ӿ']+", re.UNICODE)

# Службові слова, які в запиті-фразі несуть нуль сигналу і лише розмивають BM25.
STOP = {
    'у', 'в', 'на', 'з', 'із', 'зі', 'до', 'по', 'за', 'та', 'і', 'й', 'а', 'бо',
    'що', 'як', 'це', 'цей', 'ця', 'мене', 'мені', 'мій', 'моя', 'моє', 'мною',
    'я', 'ми', 'ти', 'він', 'вона', 'воно', 'вони', 'нам', 'нас', 'the', 'a',
    'an', 'of', 'to', 'for', 'and', 'or', 'is', 'are', 'my', 'me', 'i', 'we',
    'треба', 'потрібно', 'хочу', 'якийсь', 'якась', 'якесь', 'щось', 'дуже',
    # дієслова-порожняки: у корпусі вони є майже скрізь, тому тягнуть у топ
    # випадкові записи («зробити» витягало data-storytelling на запит про деплой)
    'зробити', 'зроби', 'зробив', 'зробила', 'робити', 'можна', 'потім', 'ще',
}


def tok(text):
    """Слова у нижньому регістрі, довжиною від 2. Кирилиця і латиниця разом."""
    if not text:
        return []
    return [w.lower() for w in _WORD_RE.findall(str(text)) if len(w) > 1]


def _stem(t):
    """Груба обрізка замість морфології: «деплою» і «деплой» дають один ключ.

    Свідомо тупо. Повноцінний український стемер тягне залежність, а тут треба
    лише щоб відмінок не ламав збіг; хибні склейки на 5 символах у цьому домені
    коштують один зайвий кандидат у сотні, і RRF його все одно опускає."""
    return t[:5] if len(t) > 5 else t


# ── доменний словник UA→EN ─────────────────────────────────────────────────
# Ключ = основа українського слова (порівнюємо префіксом, тому «деплой»,
# «деплою», «деплоїти» ловляться одним записом). Значення = англійські терміни,
# якими цей намір реально названий у каталозі.
UA_EN = {
    # інфраструктура, релізи, інциденти
    'деплой': ['deploy', 'deployment', 'release', 'ci', 'cd', 'pipeline'],
    'релиз': ['release', 'deploy'],
    'реліз': ['release', 'deploy', 'changelog'],
    'впав': ['fail', 'failed', 'failure', 'down', 'outage', 'crash', 'incident'],
    'впало': ['fail', 'failed', 'failure', 'down', 'outage'],
    'падає': ['fail', 'failing', 'crash', 'flaky', 'error'],
    'зламал': ['broken', 'break', 'crash', 'regression', 'fix'],
    'полама': ['broken', 'break', 'fix', 'repair'],
    'помилк': ['error', 'exception', 'bug', 'failure', 'stack', 'trace'],
    'баг': ['bug', 'defect', 'issue', 'fix'],
    'відкат': ['rollback', 'revert', 'undo'],
    'інцидент': ['incident', 'outage', 'postmortem', 'oncall'],
    'логи': ['logs', 'logging', 'observability'],
    'моніторинг': ['monitoring', 'observability', 'alerting', 'metrics'],
    'сервер': ['server', 'backend', 'infrastructure'],
    'докер': ['docker', 'container', 'kubernetes'],
    'кубер': ['kubernetes', 'k8s', 'cluster'],
    'хмар': ['cloud', 'aws', 'gcp', 'azure'],
    'термінал': ['terminal', 'shell', 'cli', 'bash'],
    'скрипт': ['script', 'automation', 'cli'],
    'налашт': ['config', 'configuration', 'setup'],
    # база даних
    'база': ['database', 'db', 'sql', 'postgres', 'schema'],
    'бази': ['database', 'db', 'sql', 'postgres'],
    'базу': ['database', 'db', 'sql', 'postgres'],
    'бд': ['database', 'db', 'sql'],
    'бекап': ['backup', 'dump', 'snapshot', 'restore'],
    'резервн': ['backup', 'dump', 'snapshot'],
    'відновл': ['restore', 'recovery', 'recover', 'disaster'],
    'підняти': ['restore', 'recover', 'provision', 'bootstrap', 'setup'],
    'підняв': ['restore', 'provision', 'setup'],
    'міграц': ['migration', 'migrate', 'schema'],
    'запит': ['query', 'sql', 'request'],
    'таблиц': ['table', 'schema', 'sql'],
    'індекс': ['index', 'indexing', 'performance'],
    # код і рев'ю
    'код': ['code', 'coding', 'implementation'],
    'рефактор': ['refactor', 'refactoring', 'cleanup'],
    'рев': ['review', 'reviewer', 'code-review'],
    'ревю': ['review', 'code-review', 'pull', 'request'],
    'розібрат': ['review', 'analyze', 'breakdown', 'explain'],
    'розбор': ['review', 'analysis', 'breakdown'],
    'розбір': ['review', 'analysis', 'breakdown'],
    'пулреквест': ['pull', 'request', 'pr', 'diff', 'review'],
    'пул': ['pull', 'request', 'pr', 'merge'],
    'мердж': ['merge', 'conflict', 'rebase'],
    'коміт': ['commit', 'git', 'message'],
    'гіт': ['git', 'github', 'branch'],
    'тест': ['test', 'testing', 'qa', 'coverage', 'unit'],
    'дебаг': ['debug', 'debugging', 'troubleshoot'],
    'великий': ['large', 'big', 'huge', 'monorepo'],
    'великого': ['large', 'big', 'huge'],
    'безпек': ['security', 'audit', 'vulnerability', 'secure'],
    'вразлив': ['vulnerability', 'security', 'exploit'],
    'продуктивн': ['performance', 'optimization', 'profiling', 'latency'],
    'архітект': ['architecture', 'design', 'system'],
    'апі': ['api', 'rest', 'endpoint', 'graphql'],
    'фронт': ['frontend', 'react', 'ui', 'component'],
    'бек': ['backend', 'server', 'api'],
    'мобіл': ['mobile', 'ios', 'android', 'app'],
    # контент, копірайт, соцмережі
    'пост': ['post', 'content', 'copy', 'writing', 'social'],
    'допис': ['post', 'content', 'writing'],
    'лінкедін': ['linkedin', 'social', 'post', 'professional'],
    'linkedin': ['linkedin', 'social', 'post'],
    'твіт': ['tweet', 'twitter', 'thread', 'social'],
    'тред': ['thread', 'twitter', 'tweet'],
    'інстаграм': ['instagram', 'social', 'carousel'],
    'тікток': ['tiktok', 'short', 'video', 'social'],
    'ютуб': ['youtube', 'video', 'script', 'transcript'],
    'соцмереж': ['social', 'media', 'smm'],
    'текст': ['text', 'copy', 'writing', 'copywriting'],
    'копірайт': ['copywriting', 'copy', 'writing', 'marketing'],
    'напис': ['write', 'writing', 'draft', 'copywriting'],
    'написа': ['write', 'writing', 'draft', 'copywriting'],
    'заголов': ['headline', 'title', 'hook'],
    'стат': ['article', 'blog', 'post', 'writing'],
    'блог': ['blog', 'article', 'post', 'content'],
    'лендінг': ['landing', 'page', 'website', 'copy'],
    'розсилк': ['newsletter', 'email', 'campaign'],
    'імейл': ['email', 'newsletter', 'outreach'],
    'переклад': ['translate', 'translation', 'localization'],
    'редагув': ['edit', 'editing', 'proofread', 'rewrite'],
    'сценар': ['script', 'screenplay', 'storyboard', 'narrative'],
    # медіа
    'відео': ['video', 'clip', 'footage', 'render', 'editing'],
    'ролик': ['video', 'clip', 'reel'],
    'кліп': ['clip', 'video', 'reel', 'cut'],
    'монтаж': ['editing', 'edit', 'video', 'cut', 'ffmpeg'],
    'аудіо': ['audio', 'sound', 'voice', 'podcast'],
    'подкаст': ['podcast', 'audio', 'episode'],
    'озвуч': ['voice', 'tts', 'narration', 'speech'],
    'транскр': ['transcript', 'transcription', 'speech', 'whisper'],
    'субтитр': ['subtitles', 'captions', 'srt'],
    'картинк': ['image', 'picture', 'graphic', 'generation'],
    'зображ': ['image', 'picture', 'graphic'],
    'фото': ['photo', 'image', 'picture'],
    'дизайн': ['design', 'ui', 'ux', 'visual'],
    'логотип': ['logo', 'brand', 'identity'],
    # презентації, документи
    'презентац': ['presentation', 'slides', 'deck', 'pptx', 'powerpoint', 'keynote'],
    'слайд': ['slide', 'slides', 'deck', 'presentation'],
    'документ': ['document', 'docx', 'doc', 'word'],
    'пдф': ['pdf', 'document'],
    'таблич': ['spreadsheet', 'excel', 'xlsx', 'csv'],
    'ексель': ['excel', 'xlsx', 'spreadsheet'],
    'звіт': ['report', 'reporting', 'summary', 'dashboard'],
    'конспект': ['summary', 'notes', 'summarize', 'digest'],
    'нотат': ['notes', 'note', 'knowledge'],
    # бізнес, продажі, маркетинг
    'продаж': ['sales', 'selling', 'deal', 'pipeline', 'crm'],
    'клієнт': ['customer', 'client', 'account'],
    'лід': ['lead', 'leads', 'prospect', 'generation'],
    'воронк': ['funnel', 'conversion', 'pipeline'],
    'оффер': ['offer', 'pricing', 'proposal', 'value'],
    'ціна': ['pricing', 'price', 'monetization'],
    'прайс': ['pricing', 'price'],
    'реклам': ['ads', 'advertising', 'campaign', 'marketing'],
    'маркет': ['marketing', 'market', 'growth'],
    'бренд': ['brand', 'branding', 'identity'],
    'конкурент': ['competitor', 'competitive', 'landscape', 'analysis'],
    'ринок': ['market', 'sizing', 'research', 'tam'],
    'ринк': ['market', 'sizing', 'research'],
    'стратег': ['strategy', 'strategic', 'gtm', 'positioning'],
    'дослідж': ['research', 'analysis', 'study'],
    'ресерч': ['research', 'analysis'],
    'аналіт': ['analytics', 'analysis', 'data', 'metrics'],
    'метрик': ['metrics', 'kpi', 'analytics'],
    'дані': ['data', 'dataset', 'analysis'],
    'графік': ['chart', 'graph', 'visualization', 'plot'],
    'дашборд': ['dashboard', 'analytics', 'visualization'],
    'фінанс': ['finance', 'financial', 'model', 'budget'],
    'бюджет': ['budget', 'finance', 'cost'],
    'стартап': ['startup', 'founder', 'venture'],
    'інвест': ['investment', 'investor', 'funding', 'pitch'],
    'пітч': ['pitch', 'deck', 'investor'],
    'найм': ['hiring', 'recruiting', 'interview', 'candidate'],
    'співбесід': ['interview', 'hiring', 'candidate'],
    'юрид': ['legal', 'contract', 'compliance'],
    'договір': ['contract', 'agreement', 'legal'],
    'підтримк': ['support', 'helpdesk', 'customer'],
    # процес і продуктивність
    'план': ['plan', 'planning', 'roadmap', 'sprint'],
    'задач': ['task', 'todo', 'ticket', 'issue'],
    'проєкт': ['project', 'management', 'delivery'],
    'проект': ['project', 'management', 'delivery'],
    'дедлайн': ['deadline', 'schedule', 'timeline'],
    'зустріч': ['meeting', 'notes', 'agenda'],
    'автоматиз': ['automation', 'automate', 'workflow'],
    'інтеграц': ['integration', 'webhook', 'api'],
    'пошук': ['search', 'find', 'retrieval'],
    'навчан': ['learning', 'training', 'tutorial', 'course'],
    'пояснит': ['explain', 'explanation', 'tutorial'],
    'ідея': ['idea', 'brainstorm', 'ideation'],
    'рішенн': ['decision', 'decide', 'framework'],
}
# найдовший префікс виграє, інакше «пул» перехопить «пулреквест»
_UA_KEYS = sorted(UA_EN.keys(), key=len, reverse=True)


def expand(tokens):
    """Токени запиту -> [(термін, вага, джерело)]. Оригінал важить 1.0, підказка
    зі словника 0.75: словник допомагає, але не має права переважити пряме слово."""
    out = []
    seen = set()
    for t in tokens:
        if t in STOP:
            continue
        if t not in seen:
            out.append((t, 1.0, t))
            seen.add(t)
        hits = UA_EN.get(t)
        if hits is None:
            for k in _UA_KEYS:
                if len(k) >= 3 and t.startswith(k):
                    hits = UA_EN[k]
                    break
        for h in (hits or []):
            if h not in seen:
                out.append((h, 0.75, t))
                seen.add(h)
    return out


# ── корпус ─────────────────────────────────────────────────────────────────
PROF_LABELS = {}     # key -> укр. назва професії, заповнюється з professionsIndex


def _read_json(path):
    try:
        with open(path, encoding='utf-8') as f:
            return json.load(f)
    except Exception:
        return {}


def _doc_terms(rec):
    """Терміни запису з ваговими повторами: назва важить 3, теги і професії 2,
    опис 1. Повтор токена = вища term frequency, тобто BM25 сам це врахує без
    окремої польової математики."""
    terms = []
    terms += tok(rec.get('name')) * 3
    terms += [p for p in re.split(r'[-_]', rec.get('id') or '') if len(p) > 1] * 2
    for t in (rec.get('tags') or []):
        terms += tok(t) * 2
    for p in (rec.get('professions') or []):
        terms += [p.lower()] * 2
        terms += tok(PROF_LABELS.get(p, '')) * 2
    terms += tok(rec.get('description'))
    stems = [_stem(t) for t in terms]
    return terms + [s for s in stems if s not in terms]


class Corpus:
    """Злитий каталог (наші 62 + зовнішні 1552) з готовим BM25-індексом.

    Кешується в памʼяті і перебудовується лише коли міняється mtime будь-якого з
    двох файлів каталогу."""

    def __init__(self, lib_dir):
        self.lib_dir = lib_dir
        self.stamp = None
        self.records = []
        self.professions = []
        # Сирі розміри двох файлів каталогу і поіменний список того, що НЕ дійшло
        # до корпусу. Тримаємо поруч із записами, бо це єдине місце, де ми знаємо
        # обидві величини одночасно: далі різниця вже не відновлюється.
        self.sizes = {'local': 0, 'remote': 0}
        self.dropped = []
        self._lock = threading.Lock()
        self._df = {}
        self._tf = []
        self._len = []
        self._avg = 1.0

    def _files(self):
        """(наш перелік, каталог доступного). Другий може лежати у ДВОХ місцях.

        Наш `index.json` це продукт-мінімум: він у бандлі і поруч завжди. Каталог
        доступного (7400 чужих скілів, 5.6 МБ) у роздавальній збірці НЕ пакується, а
        тягнеться в `<дім>/library/` на вимогу, тому шлях до нього питаємо в
        `library_cache`, а не складаємо рядком (specs/user-owned-entities, 6.3).

        Порядок джерел усередині `ensure_catalog` такий, що дев-репо і особиста
        збірка не міняють поведінки взагалі: файл лежить поруч, він і виграє. None
        означає «каталогу ще немає», і причина при цьому вже записана у
        `<дім>/library/status.json` замість тиші."""
        remote = None
        try:
            import library_cache
            remote = library_cache.ensure_catalog(lib_dir=self.lib_dir)
        except Exception:
            # Модуль кешу це ПОКРАЩЕННЯ шляху до каталогу, а не умова роботи пошуку.
            # Впав імпорт (стара збірка без нього) -> лишаємось на старому шляху,
            # тобто рівно на тому, що було до цієї правки.
            remote = None
        return (os.path.join(self.lib_dir, 'index.json'),
                remote or os.path.join(self.lib_dir, 'remote-catalog.json'))

    def catalog_status(self):
        """Стан каталогу доступного для показу людині. -> dict з `library_cache`.

        Живе тут, бо саме `Corpus` знає `lib_dir`, а поверхні (API, UI) не мусять
        знати ні про теку кешу, ні про те, що каталог узагалі буває віддаленим."""
        try:
            import library_cache
            return library_cache.status(lib_dir=self.lib_dir)
        except Exception as e:
            return {'state': 'unknown', 'ok': False, 'reason': str(e)[:120]}

    def _current_stamp(self):
        out = []
        for p in self._files():
            try:
                out.append(os.path.getmtime(p))
            except Exception:
                out.append(0)
        return tuple(out)

    def ensure(self):
        st = self._current_stamp()
        if st == self.stamp and self.records:
            return self
        with self._lock:
            if st == self.stamp and self.records:
                return self
            self._build()
            self.stamp = st
        return self

    def _build(self):
        local_p, remote_p = self._files()
        local = _read_json(local_p)
        remote = _read_json(remote_p)

        profs = {}
        for src in (local, remote):
            for p in (src.get('professionsIndex') or []):
                if isinstance(p, dict) and p.get('key'):
                    profs.setdefault(p['key'], {'key': p['key'],
                                                'emoji': p.get('emoji'),
                                                'label': p.get('label') or p['key'],
                                                'count': 0})
        PROF_LABELS.clear()
        PROF_LABELS.update({k: v['label'] for k, v in profs.items()})

        local_skills = local.get('skills') or []
        remote_skills = remote.get('skills') or []

        recs = []
        seen = set()
        dropped = []

        def take(sk, origin):
            """-> True, якщо запис іде в корпус. Інакше він потрапляє в `dropped`
            з причиною. Мовчазного пропуску тут бути не може: різниця між розміром
            файлів і розміром корпусу мусить пояснюватись поіменно, інакше два
            лічильники розходяться і ніхто не бачить чому."""
            sid = sk.get('id')
            if not sid:
                dropped.append({'id': None, 'name': sk.get('name'),
                                'from': origin, 'reason': 'noId'})
                return False
            if sid in seen:
                dropped.append({'id': sid, 'name': sk.get('name'),
                                'from': origin, 'reason': 'duplicate'})
                return False
            seen.add(sid)
            return True

        # наші йдуть першими, тому при колізії id (20 записів davila7-*, voltagent-*
        # і wshobson-*, які вже перенесені в index.json) виграє наша, збагачена
        # версія, а зовнішня копія лягає в `dropped`
        for sk in local_skills:
            if not take(sk, 'local'):
                continue
            r = dict(sk)
            # curated = ми цей запис відібрали руками (index.json). Це сигнал
            # ЯКОСТІ і дає буст у ранжуванні.
            r['ours'] = True
            # local = файли лежать у нашому репозиторії. Це сигнал ПОХОДЖЕННЯ, і
            # він інший: із 62 записів index.json лише частина написана нами,
            # решта це відібрані чужі плагіни, які так само тягнуться з GitHub.
            p = sk.get('path')
            r['local'] = bool(p) and os.path.isdir(os.path.join(self.lib_dir, p))
            recs.append(r)
        for sk in remote_skills:
            if not take(sk, 'remote'):
                continue
            r = dict(sk)
            r['ours'] = False
            recs.append(r)

        self.sizes = {'local': len(local_skills), 'remote': len(remote_skills)}
        self.dropped = dropped

        for r in recs:
            for p in (r.get('professions') or []):
                if p in profs:
                    profs[p]['count'] += 1

        self.records = recs
        self.professions = sorted(
            (p for p in profs.values() if p['count']),
            key=lambda p: -p['count'])

        df = {}
        tfs = []
        lens = []
        for r in recs:
            terms = _doc_terms(r)
            tf = {}
            for t in terms:
                tf[t] = tf.get(t, 0) + 1
            tfs.append(tf)
            lens.append(max(1, len(terms)))
            for t in tf:
                df[t] = df.get(t, 0) + 1
        self._df = df
        self._tf = tfs
        self._len = lens
        self._avg = sum(lens) / max(1, len(lens))

    # ── BM25 ───────────────────────────────────────────────────────────────
    def bm25(self, weighted_terms, allow=None, k1=1.5, b=0.75, depth=LEX_DEPTH):
        """-> [(idx, score, {термін: джерело})] за спаданням score."""
        n = len(self.records)
        if not n or not weighted_terms:
            return []
        scored = []
        want = {}
        for term, w, origin in weighted_terms:
            want[term] = (w, origin)
            st = _stem(term)
            if st != term and st not in want:
                want[st] = (w * 0.6, origin)
        idf = {}
        for t, (w, _o) in want.items():
            d = self._df.get(t, 0)
            if d:
                idf[t] = math.log(1 + (n - d + 0.5) / (d + 0.5))
        if not idf:
            return []
        for i in range(n):
            if allow is not None and i not in allow:
                continue
            tf = self._tf[i]
            dl = self._len[i]
            s = 0.0
            hits = {}
            for t, iv in idf.items():
                f = tf.get(t)
                if not f:
                    continue
                w, origin = want[t]
                s += w * iv * (f * (k1 + 1)) / (f + k1 * (1 - b + b * dl / self._avg))
                hits[t] = origin
            if s > 0:
                scored.append((i, s, hits))
        scored.sort(key=lambda x: -x[1])
        return scored[:depth]


_CORPORA = {}


def corpus(lib_dir):
    c = _CORPORA.get(lib_dir)
    if c is None:
        c = _CORPORA[lib_dir] = Corpus(lib_dir)
    return c.ensure()


def catalog_stats(lib_dir):
    """ЄДИНЕ джерело чисел каталогу для всіх поверхонь.

    Було дві формули на дві поверхні: /api/helpers віддавав довжину пошукового
    корпусу (7478), а /api/project-state два доданки з сирих файлів (62 + 7436 =
    7498). Обидва числа технічно правдиві, різницю в 20 записів не пояснював ніхто,
    і на її розшифровку йшло пів години щоразу. Тому число тепер рахується тут, а
    поверхні його лише беруть.

    -> {local, remote, total, dropped:[{id, name, from, reason}]}
       local/remote це СИРІ розміри файлів, total це скільки записів реально живе в
       корпусі, dropped пояснює різницю поіменно. Інваріант, який тримає цей
       контракт чесним: local + remote - len(dropped) == total.
    """
    c = corpus(lib_dir)
    return {
        'local': c.sizes.get('local', 0),
        'remote': c.sizes.get('remote', 0),
        'total': len(c.records),
        'dropped': list(c.dropped),
        # ЧОМУ remote може бути нулем. Без цього поля порожній каталог у свіжій апці
        # виглядає точно так само, як каталог, у якому просто нічого не знайшлось, і
        # людина робить висновок «магазин порожній». `source.reason` це одне речення
        # причини українською, `source.state` придатний до розгалуження в UI.
        # Поле їде на поверхні САМЕ ТУТ, бо `catalog_stats` уже віддається цілком і
        # в /api/helpers, і в /api/project-state: одне джерело чисел, одне джерело
        # причини, і жодної правки в сервері (specs/user-owned-entities, 6.3).
        'source': c.catalog_status(),
    }


# ── ембединги ──────────────────────────────────────────────────────────────
def emb_path(lib_dir):
    return os.path.join(lib_dir, 'embeddings.json')


def emb_text(rec):
    """Що саме ембедимо. Опис обрізаний: далі йде шум зі змісту репозиторію, а не
    сенс скіла."""
    parts = [rec.get('name') or '']
    d = (rec.get('description') or '').strip()
    if d:
        parts.append(d[:500])
    tags = [t for t in (rec.get('tags') or []) if t]
    if tags:
        parts.append('теги: ' + ', '.join(tags[:12]))
    profs = [PROF_LABELS.get(p, p) for p in (rec.get('professions') or [])]
    if profs:
        parts.append('для кого: ' + ', '.join(profs))
    return '. '.join(p for p in parts if p)


def fingerprint(rec):
    """Відбиток входу. Міняється тільки коли міняється те, що ми ембедили, тому
    оновлення каталогу перераховує рівно нові записи, а не всі 1614."""
    raw = '|'.join([rec.get('id') or '', emb_text(rec)])
    return hashlib.sha1(raw.encode('utf-8')).hexdigest()[:16]


def load_emb(lib_dir):
    data = _read_json(emb_path(lib_dir))
    if not isinstance(data, dict) or data.get('model') != EMB_MODEL \
            or int(data.get('dims') or 0) != EMB_DIMS:
        return {'model': EMB_MODEL, 'dims': EMB_DIMS, 'items': {}}
    items = data.get('items')
    if not isinstance(items, dict):
        data['items'] = {}
    return data


def save_emb(lib_dir, data):
    p = emb_path(lib_dir)
    tmp = p + '.tmp'
    with open(tmp, 'w', encoding='utf-8') as f:
        json.dump(data, f, ensure_ascii=False, separators=(',', ':'))
    os.replace(tmp, p)


def _post_embeddings(key, inputs, timeout=60):
    """Один виклик /v1/embeddings. Кидає виняток нагору: викликач вирішує, чи це
    привід замовкнути (пошук) чи привід зупинити білд (індексатор)."""
    import urllib.request
    body = json.dumps({'model': EMB_MODEL, 'input': inputs,
                       'dimensions': EMB_DIMS}).encode('utf-8')
    req = urllib.request.Request(
        'https://api.openai.com/v1/embeddings', data=body,
        headers={'Authorization': f'Bearer {key}',
                 'Content-Type': 'application/json'}, method='POST')
    with urllib.request.urlopen(req, timeout=timeout) as r:
        out = json.loads(r.read().decode('utf-8'))
    rows = sorted(out.get('data') or [], key=lambda d: d.get('index', 0))
    return [d['embedding'] for d in rows]


def _norm(v):
    n = math.sqrt(sum(x * x for x in v)) or 1.0
    return [x / n for x in v]


def build_embeddings(lib_dir, key, progress=None, limit=None):
    """Дорахувати кеш до повного. -> статистика (скільки було, скільки додано).

    Інкрементальність тримається на fingerprint: запис із незмінним fp навіть не
    потрапляє у список на відправку."""
    c = corpus(lib_dir)
    data = load_emb(lib_dir)
    items = data['items']
    todo = []
    for r in c.records:
        fp = fingerprint(r)
        cur = items.get(r['id'])
        if isinstance(cur, dict) and cur.get('fp') == fp and cur.get('v'):
            continue
        todo.append((r['id'], fp, emb_text(r)))
    stats = {'total': len(c.records), 'cached': len(c.records) - len(todo),
             'todo': len(todo), 'added': 0, 'batches': 0, 'error': None}
    if limit:
        todo = todo[:limit]
    if not todo:
        # каталог міг зменшитись: приберемо сиріт, щоб файл не ріс вічно
        live = {r['id'] for r in c.records}
        drop = [k for k in items if k not in live]
        if drop:
            for k in drop:
                items.pop(k, None)
            save_emb(lib_dir, data)
        return stats
    try:
        for i in range(0, len(todo), EMB_BATCH):
            chunk = todo[i:i + EMB_BATCH]
            vecs = _post_embeddings(key, [t[2] for t in chunk])
            if len(vecs) != len(chunk):
                raise ValueError('embeddings: розмір відповіді не збігся')
            for (sid, fp, _t), v in zip(chunk, vecs):
                items[sid] = {'fp': fp,
                              'v': [round(x, 5) for x in _norm(v)]}
            stats['added'] += len(chunk)
            stats['batches'] += 1
            save_emb(lib_dir, data)
            if progress:
                progress(stats)
    except Exception as e:
        stats['error'] = str(e)[:200]
        save_emb(lib_dir, data)
    return stats


_QCACHE = {}
_QCACHE_LOCK = threading.Lock()


def embed_query(key, text, timeout=20):
    """Вектор запиту. Маленький кеш, бо UI шле той самий рядок на кожен дебаунс."""
    k = text.strip().lower()
    with _QCACHE_LOCK:
        hit = _QCACHE.get(k)
    if hit:
        return hit
    v = _norm(_post_embeddings(key, [k], timeout=timeout)[0])
    with _QCACHE_LOCK:
        if len(_QCACHE) > 64:
            _QCACHE.clear()
        _QCACHE[k] = v
    return v


# ── пояснення збігу ────────────────────────────────────────────────────────
def _why(rec, hits, from_vector):
    """Чому цей скіл тут. Показуємо ДЖЕРЕЛЬНЕ слово Vova і поле, у яке воно влучило,
    бо «збіг є» без «де саме» читається як магія і не дає довіритись видачі."""
    if not hits:
        return ('схоже за змістом' if from_vector else 'збіг у каталозі'), []
    name_t = set(tok(rec.get('name'))) | {p for p in re.split(r'[-_]', rec.get('id') or '')}
    tag_t = set()
    for t in (rec.get('tags') or []):
        tag_t |= set(tok(t))
    prof_t = {p.lower() for p in (rec.get('professions') or [])}
    desc_t = set(tok(rec.get('description')))

    by_origin = {}
    for term, origin in hits.items():
        by_origin.setdefault(origin, set()).add(term)

    bits = []
    words = []
    for origin, terms in list(by_origin.items())[:3]:
        where = None
        shown = None
        for t in sorted(terms, key=len, reverse=True):
            if t in name_t:
                where, shown = 'у назві', t
                break
            if t in tag_t and where is None:
                where, shown = 'у тегах', t
            elif t in prof_t and where is None:
                where, shown = 'у професії', t
            elif t in desc_t and where is None:
                where, shown = 'в описі', t
        if where is None:
            continue
        words.append(shown)
        bits.append(f'{origin} → {shown} {where}' if shown != origin
                    else f'«{origin}» {where}')
    if not bits:
        return ('схоже за змістом' if from_vector else 'збіг у каталозі'), []
    text = ', '.join(bits)
    if from_vector:
        text += ' + близько за змістом'
    return text, words


def level(rec):
    """Рівень для бейджа: наш / код / текст. Не про якість скіла, а рівно про те,
    ЩО приїде на диск.

    Свідоме уточнення проти початкової постановки («наш» = усе з index.json).
    З 62 записів index.json файли в нашому репозиторії мають лише 16, решта це
    чужі плагіни, які ми відібрали, але які так само тягнуться з GitHub і так
    само можуть змінитись після того, як ми їх подивились. Зелений бейдж «наш»
    на чужому плагіні був би хибним спокоєм саме в тому місці, заради якого ця
    картка і робилась, тому «наш» означає «наші файли», а не «наша полиця»."""
    if rec.get('local') or (rec.get('source') or '') == 'shared-knowledge':
        return 'ours'
    return 'code' if rec.get('hasCode') else 'text'


def public(rec):
    """Запис у формі, яку віддаємо у фронт."""
    return {
        'id': rec.get('id'),
        'name': rec.get('name'),
        'description': rec.get('description'),
        'icon': rec.get('icon'),
        'category': rec.get('category'),
        'tags': (rec.get('tags') or [])[:8],
        'professions': rec.get('professions') or [],
        'source': rec.get('source'),
        'url': rec.get('url'),
        'stars': rec.get('stars'),
        'license': rec.get('license'),
        'install': rec.get('install'),
        'kind': rec.get('kind'),
        'hasCode': bool(rec.get('hasCode')),
        'ours': bool(rec.get('ours')),
        'local': bool(rec.get('local')),
        'level': level(rec),
    }


# ── власне пошук ───────────────────────────────────────────────────────────
def search(lib_dir, query, key=None, limit=8, profession=None, use_vector=True):
    """Гібридний пошук. Ніколи не кидає: гірший сценарій це порожній список.

    -> {ok, query, usedVector, vectorError, results:[{...public, score, why, whyWords}]}
    """
    c = corpus(lib_dir)
    q = (query or '').strip()
    # total це скільки РЕЗУЛЬТАТІВ показано, а не розмір каталогу. Раніше сюди
    # їхало len(c.records), і фронт на будь-який запит малював «знайшов 8 із
    # 7478»: число технічно правдиве і людині марне, бо каталог не «знайдено»,
    # каталог просто є. Розмір корпусу лишається окремим полем catalogTotal для
    # діагностики, але в підпис під пошуком він більше не потрапляє.
    out = {'ok': True, 'query': q, 'usedVector': False, 'vectorError': None,
           'total': 0, 'catalogTotal': len(c.records), 'results': []}
    if not q:
        return out

    allow = None
    if profession:
        allow = {i for i, r in enumerate(c.records)
                 if profession in (r.get('professions') or [])}
        if not allow:
            return out

    terms = expand(tok(q))
    lex = c.bm25(terms, allow=allow)

    vec = []
    if use_vector and key:
        try:
            data = load_emb(lib_dir)
            items = data.get('items') or {}
            if items:
                qv = embed_query(key, q)
                sims = []
                for i, r in enumerate(c.records):
                    if allow is not None and i not in allow:
                        continue
                    e = items.get(r['id'])
                    if not e or not e.get('v'):
                        continue
                    v = e['v']
                    sims.append((i, sum(a * b for a, b in zip(qv, v))))
                sims.sort(key=lambda x: -x[1])
                vec = sims[:VEC_DEPTH]
                out['usedVector'] = True
            else:
                out['vectorError'] = 'кеш ембедингів ще не побудований'
        except Exception as e:
            # Ключ протух, мережі нема, OpenAI 429: це НЕ привід ламати пошук.
            out['vectorError'] = str(e)[:160]

    fused = {}
    for rank, (i, _s, hits) in enumerate(lex):
        e = fused.setdefault(i, {'rrf': 0.0, 'hits': {}, 'vec': False})
        e['rrf'] += 1.0 / (RRF_K + rank + 1)
        e['hits'].update(hits)
    for rank, (i, _s) in enumerate(vec):
        e = fused.setdefault(i, {'rrf': 0.0, 'hits': {}, 'vec': False})
        # Вектор важить трохи менше лексики (0.85). Він добирає перефраз, але сам
        # по собі не має права підняти запис, у якому не збіглось жодне слово:
        # так на «у мене впав деплой» у топ лізли сусіди по темі «щось падає».
        e['rrf'] += 0.85 / (RRF_K + rank + 1)
        e['vec'] = True

    ranked = []
    for i, e in fused.items():
        r = c.records[i]
        score = e['rrf']
        # Наші скіли знаємо і підтримуємо, тому за інших рівних вони йдуть вище.
        if r.get('ours'):
            score += 0.006
        stars = r.get('stars') or 0
        if stars:
            score += 0.004 * min(1.0, math.log10(stars + 1) / 5.5)
        ranked.append((score, i, e))
    ranked.sort(key=lambda x: -x[0])

    for score, i, e in ranked[:max(1, int(limit))]:
        r = c.records[i]
        why, words = _why(r, e['hits'], e['vec'])
        item = public(r)
        item['score'] = round(score, 6)
        item['why'] = why
        item['whyWords'] = words
        item['matchedVector'] = e['vec']
        item['matchedLexical'] = bool(e['hits'])
        out['results'].append(item)
    out['total'] = len(out['results'])
    return out


def find(lib_dir, skill_id):
    """Запис за id у злитому каталозі (наші мають пріоритет)."""
    for r in corpus(lib_dir).records:
        if r.get('id') == skill_id:
            return r
    return None


def professions(lib_dir):
    return corpus(lib_dir).professions


# ── CLI: побудувати/дорахувати кеш ембедингів ──────────────────────────────
if __name__ == '__main__':
    import sys as _sys
    import time as _time
    _lib = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'skills-library')
    _key = ''
    try:
        with open(os.path.join(os.path.dirname(os.path.abspath(__file__)),
                               'keys.json'), encoding='utf-8') as _f:
            _key = (json.load(_f).get('openai') or '').strip()
    except Exception:
        pass
    if not _key:
        print('нема ключа OpenAI у keys.json: кеш не будується, пошук лишається на BM25')
        _sys.exit(0)
    _t0 = _time.time()

    def _p(st):
        print('  батч %d: %d/%d' % (st['batches'], st['added'], st['todo']), flush=True)

    _st = build_embeddings(_lib, _key, progress=_p)
    _st['seconds'] = round(_time.time() - _t0, 1)
    try:
        _st['bytes'] = os.path.getsize(emb_path(_lib))
    except Exception:
        _st['bytes'] = 0
    print(json.dumps(_st, ensure_ascii=False))
