#!/usr/bin/env python3
"""batch_publish: «я щойно завершився, спробуй опублікувати підсумок пачки, якщо час настав».

specs/agent-batch-summary/spec.md, сабтаск S5, критерії К1, К2. Останній сабтаск-склейка:
з'єднує детектор завершення (batch_detect.py, S2), атомарне право (batch_claim.py, S4) і
механічну шапку (batch_summary.py, S3) в одну дію, яку agent_worker.py кличе щоразу, коли
ВЛАСНИЙ запис агента вже ліг на диск у термінальному стані (done/error/stopped). Порядок
усередині фіксований спекою: дістати batch_id зі свого запису -> зібрати склад пачки ->
спитати чи всі термінальні -> спробувати захопити право -> зібрати віджети -> опублікувати
ОДИН меседж -> позначити претензію доведеною.

Жоден із трьох модулів тут не чіпається і не переписується: batch_publish лише зшиває
їхні вже готові публічні функції. Публікація йде через injected `post_card(channel_id,
widgets, from_name, tag)`, а не напряму через agent_worker._post_card — так модуль
лишається тестованим фікстурами і фейковими функціями, без жодного справжнього агента чи
HTTP-сервера, тим самим стилем, яким batch_detect приймає pid_alive() параметром замість
імпорту server.py.

БУДЬ-ЯКИЙ виняток на будь-якому кроці тут ловиться і логується, ніколи не спливає вище:
агент, чия власна робота вже готова і чекає лише публікації власної картки, не сміє
впасти через підсумок пачки, до якої він лише випадково належить.
"""
import batch_claim
import batch_detect
import batch_summary

SUMMARY_FROM_NAME = 'Підсумок пачки'
SUMMARY_TAG = 'batch-summary'

# Претензія, захоплена мілісекунди тому цим самим викликом, звільняється НЕГАЙНО, коли
# побудова картки чи публікація впала: нульовий поріг, а не власний механізм зняття
# (наявний release_stale_claim саме для цього і зроблений, S4).
_RELEASE_THRESHOLD_SECONDS = 0


def _noop_log(*_args):
    pass


def try_publish_batch_summary(channels_dir, channel_id, agents_dir, record, post_card, log=None):
    """Спроба опублікувати підсумок пачки одразу після того, як ВЛАСНИЙ запис агента вже
    ліг на диск у термінальному стані. Виклик мусить прийти саме ПІСЛЯ цього запису:
    інакше детектор бачить агента, що викликає, як «ще працює», і пачка ніколи не
    завершиться.

    record: словник status.json щойно завершеного агента (не всієї пачки, лише його).
    post_card(channel_id, widgets, from_name, tag): та сама функція, якою агент постить
    власну картку. Виклик тут відбувається ПІСЛЯ неї (на боці agent_worker), тож підсумок
    лягає в стрічку останнім.

    Повертає True, якщо саме ЦЕЙ виклик опублікував підсумок, інакше False — з якої саме
    причини (нема batch_id, пачка не завершена, право забрав хтось інший, крок усередині
    зазнав невдачі) назовні не видно навмисно: усі вони означають те саме «нічого не
    сталось», і саме так за К6 виглядає повторний виклик після успішної публікації.
    Ніколи не кидає винятків."""
    log = log or _noop_log
    try:
        batch_id = batch_detect.parse_batch_id((record or {}).get('task'))
        if not batch_id:
            return False

        records = batch_detect.collect_batch_records(agents_dir, batch_id)
        if not records or not batch_detect.is_batch_finished(records):
            return False

        if not batch_claim.try_claim(channels_dir, channel_id, batch_id):
            return False

        try:
            widgets = batch_summary.build_batch_summary_widgets(records)
            post_card(channel_id, widgets, SUMMARY_FROM_NAME, SUMMARY_TAG)
        except Exception as e:
            log(f'batch_publish: build/post failed for batch {batch_id}: {e}')
            batch_claim.release_stale_claim(channels_dir, channel_id, batch_id,
                                             _RELEASE_THRESHOLD_SECONDS)
            return False

        batch_claim.mark_done(channels_dir, channel_id, batch_id)
        return True
    except Exception as e:
        log(f'batch_publish: unexpected error: {e}')
        return False
