#!/usr/bin/env node
// agent-run.cjs — spawn a DETACHED background agent through ChatView's engine.
//
// THE BRIDGE (Vova 2026-07-13). Fixes the long-standing "agents die on the next
// message / I never see «Тарас закінчив»" gripe. The harness Agent tool runs a
// subagent INSIDE my turn (the runner's `claude -p` process); when that turn ends
// (a new message = a new turn), the subagent dies and was never really visible.
//
// This helper instead POSTs to the ChatView server's /api/agent-spawn, which runs
// the task in agent_worker.py in its OWN process group + session. That agent:
//   • survives a new message, an Esc on the main turn, and a ChatView restart,
//   • shows live in the «Процеси» panel AND the global bubble над інпутом,
//   • posts its result as a card to the owning channel on done (auto).
//
// So: LONG / background work → this helper (detached). Quick inline reads that
// finish within my turn → the normal Agent tool is fine.
//
// Usage:
//   node scripts/agent-run.cjs --channel <id> --label "<name>" --task "<self-contained task>" \
//        [--model opus|sonnet|haiku] [--effort low|medium|high|xhigh|max] [--port 5555]
//   echo "<task>" | node scripts/agent-run.cjs --channel <id> --label "<name>" --task -
//
// The task MUST be self-contained: a detached agent does NOT see this conversation,
// so pass all needed context in --task (same discipline as delegating to Taras).
//
// Output (stdout): a single line.
//   ok <agentId>                         → spawned; watch it in «Процеси»/bubble.
//   err <reason>                         → NOT spawned. If the server is down, fall
//                                          back to the normal Agent tool and say so.
// Exit code: 0 on spawn, 1 on any failure (so callers can branch).

const http = require('http');
const fs = require('fs');

function parseArgs(argv) {
  const a = { port: process.env.CHATVIEW_PORT || '5555', channelArg: '' };
  for (let i = 0; i < argv.length; i++) {
    const k = argv[i];
    const v = argv[i + 1];
    if (k === '--channel') { a.channelArg = v; i++; }
    else if (k === '--label') { a.label = v; i++; }
    else if (k === '--task') { a.task = v; i++; }
    else if (k === '--model') { a.model = v; i++; }
    // Глибина міркування агента (Vova 2026-08-03). Без цього detached-агент їхав
    // на дефолті сесії, і вимога «найсильніший рівень зусиль» тихо злітала.
    else if (k === '--effort') { a.effort = v; i++; }
    else if (k === '--port') { a.port = v; i++; }
  }
  // `--task -` reads the task from stdin (avoids shell-escaping a long prompt).
  if (a.task === '-') {
    try { a.task = fs.readFileSync(0, 'utf8').trim(); } catch { a.task = ''; }
  }
  return a;
}

function fail(reason) {
  process.stdout.write('err ' + reason + '\n');
  process.exit(1);
}

const EFFORTS = ['low', 'medium', 'high', 'xhigh', 'max'];

/** Ідентифікатор каналу, яким його не можна пускати ні в шлях, ні в мережу. */
const badChannel = (c) => !c || c.includes('..') || /[/\\]/.test(c);

/**
 * ВЛАСНИК АГЕНТА (specs/agent-owner-channel). Канал ходу СИЛЬНІШИЙ за аргумент.
 *
 * Привід: агента замовили у чаті `chat-167`, а місток покликали з `--channel main`.
 * Далі все відпрацювало рівно за проєктом і саме тому виглядало як зникнення роботи:
 * смужка фонової роботи фільтрує строго по каналу, тож чат-замовник агента не показав;
 * картка результату лягла власнику, тобто в `main`; у «Процесах» агент був, бо там є
 * секція чужої роботи. Одна описка в аргументі відрізала агента від чату, де на нього
 * чекали, і жодна ланка про це не сказала.
 *
 * Тому підміна, а не відмова: відмова лишила б роботу незробленою і вимагала б ручного
 * перезапуску, а підміна ставить агента туди, де його видно, і КАЖЕ про це в stderr.
 * Поза чатом (`CHATVIEW_CHANNEL` порожній або битий) правило не вмикається взагалі, і
 * явний `--channel` лишається єдиним джерелом, як було.
 */
function resolveChannel(asked, bound) {
  const want = String(asked || '').trim();
  const turn = String(bound || '').trim();
  if (turn && !badChannel(turn) && want && want !== turn) {
    return { channel: turn,
             warn: `channel forced to ${turn} (asked ${want}): агент належить чату, `
                 + 'з якого його запустили, інакше його не видно ні в смужці, ні у звіті' };
  }
  if (turn && !badChannel(turn)) return { channel: turn, warn: '' };
  return { channel: want, warn: '' };
}

const a = parseArgs(process.argv.slice(2));
const owner = resolveChannel(a.channelArg, process.env.CHATVIEW_CHANNEL);
a.channel = owner.channel;
if (!a.channel) fail('no --channel (pass the owning ChatView channel id)');
if (badChannel(a.channel)) fail('bad --channel ' + a.channel + ' (no slashes, no ..)');
if (owner.warn) process.stderr.write('warn ' + owner.warn + '\n');
if (!a.task) fail('empty --task (a detached agent needs a self-contained task)');
if (a.effort && !EFFORTS.includes(a.effort)) {
  fail('bad --effort ' + a.effort + ' (expected ' + EFFORTS.join('|') + ')');
}

const payload = JSON.stringify({
  channel: a.channel,
  label: a.label || 'Агент',
  task: a.task,
  ...(a.model ? { model: a.model } : {}),
  ...(a.effort ? { effort: a.effort } : {}),
});

const req = http.request({
  host: '127.0.0.1',
  port: Number(a.port) || 5555,
  path: '/api/agent-spawn',
  method: 'POST',
  headers: { 'Content-Type': 'application/json',
             'Content-Length': Buffer.byteLength(payload) },
  timeout: 8000,
}, (res) => {
  let buf = '';
  res.on('data', (d) => { buf += d; });
  res.on('end', () => {
    let j = {};
    try { j = JSON.parse(buf); } catch {}
    if (res.statusCode === 200 && j.ok && j.agentId) {
      process.stdout.write('ok ' + j.agentId + '\n');
      process.exit(0);
    }
    // 200 {ok:false} is the "cap reached" / soft-refusal path — surface its reason.
    fail(j.error || ('server said ' + res.statusCode + ' ' + buf.slice(0, 200)));
  });
});

req.on('timeout', () => { req.destroy(); fail('server timeout on :' + a.port); });
req.on('error', (e) => {
  const down = e && (e.code === 'ECONNREFUSED' || e.code === 'ECONNRESET');
  fail((down ? 'ChatView server not running on :' + a.port
             : String(e && e.message || e)) + ' — fall back to the normal Agent tool');
});

req.write(payload);
req.end();
