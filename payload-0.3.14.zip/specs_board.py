"""specs_board.py: specs/ for the ChatView "Спеки" board (S5) — читання плюс створення.

Mirrors the parsing rules of .claude/skills/spec/spec.cjs (sections by heading →
criteria in EARS syntax → one proof line per criterion id), so the board's progress
count agrees with `spec check`. It does NOT import spec.cjs and does NOT touch it.

ЧОМУ ТУТ ЗʼЯВИВСЯ ПИСЬМЕННИК (Д6 приймального прогону). Довго цей модуль ТІЛЬКИ читав, а
створював спеки лише `spec.cjs` зі скіла `spec` у репозиторії. У пакованій апці того
скіла нема ні в каталозі помічників, ні в payload, тому специфікацію можна було
подивитись і не можна було завести: розділ показував порожнечу і пропонував вказати
чужий репозиторій. За контрактом (specs/user-owned-entities, розділ 6.1) спека це
СУТНІСТЬ КОРИСТУВАЧА, отже застосунок мусить уміти її створити сам, у своєму корені
даних. `create_spec()` нижче і є цей письменник: той самий шаблон, той самий формат
`Статус:`, тобто дошка і `spec check` читають створене без окремих правил.

Де живуть спеки: у РОБОЧІЙ ТЕЦІ (репозиторії), а не всередині застосунку. specs/ це
наші внутрішні документи розробки, у збірку для кінцевого користувача вони не їдуть
(див. chatview_updater.PAYLOAD_DIRS), тому паковану апку треба ЗАВЖДИ показувати на
репо ззовні: змінна оточення CHATVIEW_SPECS_ROOT або збережене налаштування. Запуск
із репо (dev) сам знаходить корінь, бо там specs/ лежить поруч.

build_board(repo_root, configured=None) -> {
  root: '/шлях/до/репо' | None,   # звідки читали (або куди дивились і не знайшли)
  source: 'env' | 'settings' | 'repo' | None,
  reason: None | 'not-configured' | 'root-missing' | 'no-specs-dir' | 'no-specs',
  specs: [{
    slug, title, status, statusRaw,
    criteriaTotal, criteriaWithProof,
    hasPlan, updatedAt,
    commits: {count, last: {hash, date, subject} | None},
  }],
}
reason != None означає «показати картку з ПРИЧИНОЮ», а не мовчазну порожнечу: мовчазний
порожній екран читається як «спек нема», хоча насправді вони є, просто дошка дивиться не
туди. Це прямо критерій спеки S5.
"""
import os
import re
import subprocess

STATES = ('чернетка', 'у роботі', 'закрита')

# Явний перебивач шляху до робочої теки. Перший у черзі, бо це найдешевший спосіб
# показати паковану апку на потрібне репо (запуск із термінала, CI, друга копія репо).
ROOT_ENV = 'CHATVIEW_SPECS_ROOT'

# Word boundary via (?=\s|$), not \b: JS \b (and Python's) only treats ASCII
# letters as word chars, so \b right after Cyrillic text does not match — the
# same gotcha spec.cjs works around for the same reason.
EARS_RE = re.compile(r'^(КОЛИ|ЯКЩО|ПОКИ|ТАМ ДЕ)(?=\s|$)')
HEAD_RE = re.compile(r'^#{1,6}\s+(.*)$')
ID_RE = re.compile(r'^К(\d+)[.)]?\s*')
PLACEHOLDER_RE = re.compile(r'<[^<>\n]{2,}>')
# Канонічний формат (specs/_templates/spec.md): рядок `Статус: <стан>` дослівно, РІВНО
# одне з трьох слів і більше нічого на рядку. Раніше тут була толерантна евристика
# (bullet/bold/крапка на кінці, підрядковий збіг), і саме вона мовчки "розпізнавала" би
# сміттєвий рядок «чернетка 1, 2026-08-06. Автор: ...» як валідний стан — один формат,
# одна перевірка, а не вгадування.
# [ \t]*, не \s*: \s у Python/JS ковтає і переведення рядка, тож `\s*(.*)` після
# порожнього значення захопив би НАСТУПНИЙ рядок («Дата: ...») як нібито значення статусу.
STATUS_LINE_RE = re.compile(r'^Статус:[ \t]*(.*)$', re.M)

CRITERIA_KEYS = ('критері',)
PROOF_KEYS = ('як доводимо', 'доказ', 'ворота')


def _norm_title(t):
    t = t.lower()
    t = re.sub(r'[`*]', '', t)
    t = re.sub(r'^\s*\d+[.)]\s*', '', t)
    return t.strip()


def _sections(text):
    """Markdown headings -> [{title, norm, body:[lines]}], same fold as spec.cjs."""
    out = []
    cur = None
    for ln in text.splitlines():
        m = HEAD_RE.match(ln)
        if m:
            cur = {'title': m.group(1).strip(), 'norm': _norm_title(m.group(1)), 'body': []}
            out.append(cur)
        elif cur is not None:
            cur['body'].append(ln)
    return out


def _find_section(sections, keys):
    for s in sections:
        if any(k in s['norm'] for k in keys):
            return s
    return None


def _items(body):
    """Section body -> list of {'text', 'id', 'full'}. An item starts at an
    unindented line; indented continuation lines glue onto the previous item so
    a criterion wrapped over two lines still counts as one."""
    raws = []
    cur = None
    for raw in body:
        if not raw.strip():
            cur = None
            continue
        if re.match(r'^\s', raw) and cur is not None:
            cur['raw'] += ' ' + raw.strip()
            continue
        cur = {'raw': raw.strip()}
        raws.append(cur)
    out = []
    for i in raws:
        clean = re.sub(r'[`*]', '', i['raw'])
        clean = re.sub(r'^\s*(?:[-*+]\s+)?', '', clean)
        clean = re.sub(r'\s+', ' ', clean).strip()
        idm = ID_RE.match(clean)
        out.append({
            'text': clean[idm.end():] if idm else clean,
            'id': ('К' + idm.group(1)) if idm else None,
            'full': clean,
        })
    return out


def _is_criterion(it):
    t = re.sub(r'^\s*\d+[.)]\s*', '', it['text'])
    return bool(EARS_RE.match(t)) and 'СИСТЕМА МУСИТЬ' in t


def _has_placeholder(s):
    return bool(PLACEHOLDER_RE.search(s))


def status_of(text):
    """(raw, state). raw is exactly what follows `Статус:` on its line (or None if
    the line is missing/empty); state is raw itself if it's an EXACT match to one of
    STATES, else None so the caller can show "стан не розпізнано: <raw>" instead of
    silently guessing."""
    m = STATUS_LINE_RE.search(text)
    if not m:
        return None, None
    raw = m.group(1).strip()
    if not raw:
        return None, None
    state = raw if raw in STATES else None
    return raw, state


def criteria_detail(spec_text):
    """List of {'text', 'id', 'hasProof'} for every EARS criterion, counted the way
    `spec check` counts them: criteria are the EARS-syntax items (КОЛИ/ЯКЩО.../ПОКИ/
    ТАМ ДЕ + СИСТЕМА МУСИТЬ) inside the «Критерії приймання» section. When they
    carry К1/К2 ids, proof is matched id-for-id against the «Як доводимо» section
    (same as `spec.cjs`'s missing-id check); without ids there is no per-item
    identity to match, so every criterion is marked proven up to the plain
    headcount of non-placeholder proof lines — the same fuzziness `spec check`
    itself accepts in that case."""
    sections = _sections(spec_text)
    crit_section = _find_section(sections, CRITERIA_KEYS)
    if not crit_section:
        return []
    criteria = [it for it in _items(crit_section['body']) if _is_criterion(it)]
    if not criteria:
        return []
    proof_section = _find_section(sections, PROOF_KEYS)
    proofs = []
    if proof_section:
        proofs = [p for p in _items(proof_section['body']) if p['full'] and not _has_placeholder(p['full'])]
    with_id = [c for c in criteria if c['id']]
    if with_id:
        have_ids = {p['id'] for p in proofs if p['id']}
        return [{'text': c['text'], 'id': c['id'], 'hasProof': c['id'] in have_ids} for c in criteria]
    proven_count = min(len(criteria), len(proofs))
    return [{'text': c['text'], 'id': None, 'hasProof': idx < proven_count}
            for idx, c in enumerate(criteria)]


def criteria_progress(spec_text):
    """(criteria_total, criteria_with_proof) — the counts behind criteria_detail()."""
    detail = criteria_detail(spec_text)
    return len(detail), sum(1 for c in detail if c['hasProof'])


def _title_of(text, slug):
    m = re.search(r'^#\s+(.+)$', text, re.M)
    if m:
        return re.sub(r'[`*]', '', m.group(1)).strip()
    return slug.replace('-', ' ').capitalize()


def _run_git(repo_root, args):
    try:
        r = subprocess.run(['git'] + args, cwd=repo_root, capture_output=True,
                            text=True, timeout=10)
        if r.returncode != 0:
            return ''
        return r.stdout
    except Exception:
        return ''


def _commits_for(repo_root, slug):
    """Commits whose message mentions the slug, newest first. Reads git history
    directly (per the S5 spec: 'не вигадуй окремого реєстру, читай git'), no
    separate index of spec<->commit links is kept anywhere."""
    out = _run_git(repo_root, ['log', '--format=%h\x1f%ad\x1f%s', '--date=short',
                                '--grep=' + slug, '-i'])
    lines = [ln for ln in out.split('\n') if ln.strip()]
    last = None
    if lines:
        h, d, s = lines[0].split('\x1f', 2)
        last = {'hash': h, 'date': d, 'subject': s}
    return {'count': len(lines), 'last': last}


def _updated_at(repo_root, rel_path, abs_path):
    """Date the spec last changed. Prefers git history of the file itself; falls
    back to filesystem mtime for a spec that is still untracked (`git status ??`),
    which git log for that path would otherwise report as never touched."""
    out = _run_git(repo_root, ['log', '-1', '--format=%ad', '--date=short', '--', rel_path])
    d = out.strip()
    if d:
        return d
    try:
        import datetime
        return datetime.date.fromtimestamp(os.path.getmtime(abs_path)).isoformat()
    except Exception:
        return None


def _all_slugs(specs_dir):
    if not os.path.isdir(specs_dir):
        return []
    return sorted(
        d for d in os.listdir(specs_dir)
        if not d.startswith('_') and not d.startswith('.')
        and os.path.isdir(os.path.join(specs_dir, d))
    )


def resolve_root(default_root=None, configured=None, env=None):
    """Звідки дошка читає спеки -> (root, source, reason).

    Черга: CHATVIEW_SPECS_ROOT -> збережене налаштування -> тека, з якої запущено
    (лише якщо в ній справді є specs/, тобто це репо, а не нутрощі .app).

    root повертається навіть коли він непридатний (нема теки / нема specs/), щоб UI
    показав КОНКРЕТНИЙ шлях, куди дошка дивилась. Причина при цьому в reason.
    """
    env_val = os.environ.get(ROOT_ENV, '') if env is None else env
    for value, source in ((env_val or '', 'env'), (configured or '', 'settings')):
        value = value.strip()
        if not value:
            continue
        root = os.path.abspath(os.path.expanduser(value))
        if not os.path.isdir(root):
            return root, source, 'root-missing'
        if not os.path.isdir(os.path.join(root, 'specs')):
            return root, source, 'no-specs-dir'
        return root, source, None
    # Дефолт: запуск із репо. У пакованій апці цей шлях веде всередину бандла, там
    # specs/ нема і ніколи не буде, тому мовчки віддаємо 'not-configured', а не
    # порожній список під виглядом «спек нема».
    if default_root and os.path.isdir(os.path.join(default_root, 'specs')):
        return os.path.abspath(default_root), 'repo', None
    return None, None, 'not-configured'


def build_board(repo_root=None, configured=None, env=None):
    root, source, reason = resolve_root(repo_root, configured, env)
    specs = _scan(root) if reason is None else []
    if reason is None and not specs:
        reason = 'no-specs'
    return {'specs': specs, 'root': root, 'source': source, 'reason': reason}


# ── Письменник спек (Д6) ─────────────────────────────────────────────────────

# Дозволене імʼя теки спеки. Те саме правило, що в spec.cjs: імʼя йде в шлях, тому
# ніякої кирилиці, пробілів і крапок.
SLUG_RE = re.compile(r'^[a-z0-9][a-z0-9-]*$')

SLUG_MAX = 48

# Транслітерація для slug. Береться від ЗАГОЛОВКА, бо заголовок людина пише українською,
# а тека на диску мусить лишатись латинською і читабельною.
_TRANSLIT = {
    'а': 'a', 'б': 'b', 'в': 'v', 'г': 'h', 'ґ': 'g', 'д': 'd', 'е': 'e', 'є': 'ie',
    'ж': 'zh', 'з': 'z', 'и': 'y', 'і': 'i', 'ї': 'i', 'й': 'i', 'к': 'k', 'л': 'l',
    'м': 'm', 'н': 'n', 'о': 'o', 'п': 'p', 'р': 'r', 'с': 's', 'т': 't', 'у': 'u',
    'ф': 'f', 'х': 'kh', 'ц': 'ts', 'ч': 'ch', 'ш': 'sh', 'щ': 'shch', 'ь': '',
    'ю': 'iu', 'я': 'ia', 'ы': 'y', 'э': 'e', 'ё': 'e', 'ъ': '', 'ʼ': '', "'": '',
}

# Заводський шаблон. Живе В КОДІ, бо `specs/_templates/` це наші внутрішні документи
# розробки, і в паковану апку вони не їдуть (chatview_updater.PAYLOAD_DIRS каже це прямим
# текстом). Коли поруч із коренем спек шаблон Є (запуск із репо або людина показала на
# свій репозиторій), береться ВІН: у чужому репозиторії правила чужі.
#
# Текст навмисно без імені автора застосунку: цей файл пише апка в дім чужої людини
# (К8 спеки user-owned-entities).
SPEC_TEMPLATE = '''# {{TITLE}}

Статус: чернетка
<!-- Канонічний формат, машина читає рядок буквально: `Статус: ` + РІВНО одне з трьох
     слів (чернетка / у роботі / закрита) і більше нічого в цьому рядку. Дата, автор,
     версія йдуть своїми рядками нижче, не дописуй їх сюди — інакше дошка спек не
     впізнає стан. -->
Дата: {{DATE}}

## 1. Проблема

Дослівні слова замовника:

> {{WORDS}}

Кому болить і в який момент: <хто, що робить, що бачить замість очікуваного>.
Що вже спробували і чому не спрацювало: <або «нічого, це нове»>.

## 2. Не-цілі

Що свідомо поза межами цієї роботи. Головний запобіжник проти розповзання скоупу,
тому пишемо його ДО критеріїв, а не після.

- <не робимо це, бо ...>
- <не чіпаємо цей файл/підсистему>

## 3. Критерії приймання

Синтаксис EARS українською. Копіюй рядок і заміняй кутові дужки, не переказуй своїми
словами. Критерій, який неможливо перевірити, це не критерій, а побажання.

К1. КОЛИ <тригер> СИСТЕМА МУСИТЬ <реакція>
К2. ЯКЩО <умова> ТОДІ СИСТЕМА МУСИТЬ <реакція>
К3. ПОКИ <стан> СИСТЕМА МУСИТЬ <реакція>
К4. ТАМ ДЕ <контекст> СИСТЕМА МУСИТЬ <реакція>

## 4. Ризики

Що станеться, якщо помилитись, і що ми при цьому втратимо.

- <ризик> → <наслідок> → <чим ловимо>

## 5. Як доводимо

По одному доказу на КОЖЕН критерій, id у доказі той самий, що в критерії.
Доказ це тест, скрін, замір або лог, а не слово «перевірив».

К1. <тест / скрін / замір, який закриває К1>
К2. <тест / скрін / замір, який закриває К2>
К3. <тест / скрін / замір, який закриває К3>
К4. <тест / скрін / замір, який закриває К4>
'''

# Що стоїть у спеці, коли слів замовника не дали. Кутові дужки навмисно: рівно так
# `spec check` і дошка бачать «поле не заповнене», а не вигадану цитату.
WORDS_PLACEHOLDER = '<дослівні слова замовника>'


def slugify(title):
    """Заголовок українською -> імʼя теки латиною. '' коли не лишилось нічого."""
    lat = ''.join(_TRANSLIT.get(ch, ch) for ch in (title or '').strip().lower())
    slug = re.sub(r'[^a-z0-9]+', '-', lat).strip('-')
    return slug[:SLUG_MAX].strip('-')


def read_template(root):
    """Шаблон спеки: з `<root>/specs/_templates/spec.md`, якщо він там є, інакше
    заводський із коду. Помилка читання це НЕ привід упасти: краще створити спеку за
    заводським шаблоном, ніж не створити взагалі."""
    try:
        path = os.path.join(root, 'specs', '_templates', 'spec.md')
        if os.path.isfile(path):
            with open(path, encoding='utf-8') as f:
                text = f.read()
            if text.strip():
                return text
    except OSError:
        pass
    return SPEC_TEMPLATE


def _fill(template, values):
    return re.sub(r'\{\{(\w+)\}\}',
                  lambda m: values.get(m.group(1), m.group(0)), template)


def create_spec(root, title, words=None, slug=None, date=None):
    """Створити `<root>/specs/<slug>/spec.md` із шаблону. -> {slug, path, dir, title}.

    Кидає ValueError з ЛЮДСЬКОЮ причиною на кривому вводі і FileExistsError на дублі:
    мовчазний перезапис зʼїв би чужу роботу, а мовчазна відмова виглядала б як «апка
    зламана» (К5 спеки user-owned-entities)."""
    import datetime

    title = (title or '').strip()
    if not title:
        raise ValueError('у специфікації мусить бути назва')

    if slug is not None and str(slug).strip():
        slug = str(slug).strip()
        if not SLUG_RE.match(slug):
            raise ValueError('імʼя «%s» негодяще: дозволено малі латинські літери, '
                             'цифри і дефіс' % slug)
    else:
        slug = slugify(title)
        if not slug:
            raise ValueError('з назви «%s» не вийшло імені теки: додай літери або '
                             'цифри' % title)

    specs_dir = os.path.join(root, 'specs')
    target = os.path.join(specs_dir, slug)
    path = os.path.join(target, 'spec.md')
    if os.path.exists(path):
        raise FileExistsError('специфікація «%s» уже існує, не перезаписую' % slug)

    body = _fill(read_template(root), {
        'TITLE': title,
        'SLUG': slug,
        'DATE': (date or datetime.date.today().isoformat()),
        'WORDS': (words or '').strip() or WORDS_PLACEHOLDER,
    })
    os.makedirs(target, exist_ok=True)
    tmp = path + '.tmp'
    with open(tmp, 'w', encoding='utf-8') as f:
        f.write(body)
        f.flush()
        os.fsync(f.fileno())
    os.replace(tmp, path)
    return {'slug': slug, 'path': path, 'dir': target, 'title': title}


def _scan(repo_root):
    specs_dir = os.path.join(repo_root, 'specs')
    out = []
    for slug in _all_slugs(specs_dir):
        fp = os.path.join(specs_dir, slug, 'spec.md')
        if not os.path.isfile(fp):
            continue
        with open(fp, encoding='utf-8') as f:
            text = f.read()
        status_raw, status = status_of(text)
        detail = criteria_detail(text)
        rel_path = os.path.join('specs', slug, 'spec.md')
        out.append({
            'slug': slug,
            'title': _title_of(text, slug),
            'status': status,
            'statusRaw': status_raw,
            'criteriaTotal': len(detail),
            'criteriaWithProof': sum(1 for c in detail if c['hasProof']),
            'criteria': detail,
            'hasPlan': os.path.isfile(os.path.join(specs_dir, slug, 'plan.md')),
            'updatedAt': _updated_at(repo_root, rel_path, fp),
            'commits': _commits_for(repo_root, slug),
        })
    return out
