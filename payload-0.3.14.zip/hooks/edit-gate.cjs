#!/usr/bin/env node
/**
 * edit-gate.cjs. PreToolUse hook. Два детерміновані гальма на правку файлу.
 *
 * НАВІЩО: правило прозою в CLAUDE.md модель виконує ймовірнісно, і воно деградує
 * з довжиною сесії. Те саме правило хуком спрацьовує завжди. Determinism over hope.
 *
 * ПРАВИЛО A (red-gate): не давати класти НОВУ правку прод-коду поверх ЧЕРВОНОГО
 * прогону тестів. Нове поверх зламаного це два баги замість одного. Правки у
 * файлах, причетних до падіння, дозволені завжди, інакше гейт стає дедлоком.
 *
 * ПРАВИЛО C (rules-lock): не давати МОДЕЛІ правити власні правила. Файл правил
 * ChatView (rules.md, і заводський rules.default.md поруч) міняється ЛИШЕ через
 * екран налаштувань застосунку. Причина проста до банальності: правила, які модель
 * може переписати собі сама, перестають бути правилами. Цей текст має вищий
 * пріоритет за проєктний CLAUDE.md і частину його правил прямо скасовує, тож одна
 * тиха правка тут міняє поведінку КОЖНОГО наступного ходу. Спека:
 * specs/chatview-rules-layer, критерій К6.
 *
 * ПРАВИЛО B (test-lock): не давати тихо ПОСЛАБЛЮВАТИ тести. Дві половини:
 *   B1 хеш-замок: файл у .claude/test-lock.json недоторканний без явного ритуалу.
 *   B2 евристика: правка, що ЗМЕНШУЄ силу тесту (менше тверджень, менше кейсів,
 *      більше skip, більше закоментованих assert), блокується. Ловимо ЗМЕНШЕННЯ,
 *      не зміну: додавання кейсів і рефактор проходять вільно.
 *
 * КОНТРАКТ ХУКА (звірено з https://code.claude.com/docs/en/hooks, 2026-07-29):
 *   stdin : { session_id, transcript_path, cwd, permission_mode,
 *             hook_event_name:"PreToolUse", tool_name, tool_input, tool_use_id }
 *   блок  : exit 0 + stdout
 *           {"hookSpecificOutput":{"hookEventName":"PreToolUse",
 *             "permissionDecision":"deny","permissionDecisionReason":"..."}}
 *   пропуск: exit 0 + ПОРОЖНІЙ stdout.
 *   JSON обробляється ТІЛЬКИ при exit 0. У PreToolUse немає полів верхнього рівня
 *   decision/reason (то інший івент). exit 2 теж блокує, але ми свідомо беремо
 *   JSON-варіант: тоді будь-який неочікуваний ненульовий код це «non-blocking
 *   error», тобто аварія хука ФІЗИЧНО не здатна заблокувати роботу.
 *   permissionDecision:"allow" не виводимо НІКОЛИ: це обхід дозволів користувача.
 *
 * ГОЛОВНА ВИМОГА: FAIL-OPEN. Брак файлу, битий JSON, перевищення бюджету часу,
 * будь-яка внутрішня помилка = ТИХИЙ ПРОПУСК (exit 0, порожній stdout).
 *
 * БЮДЖЕТ: хук біжить ПЕРЕД КОЖНОЮ правкою, тож мусить бути дешевий. 300 мс,
 * після них тихий пропуск. Читаємо тільки test-state.json, test-lock.json і сам
 * цільовий файл (для Write). Транскрипт НЕ читаємо, це дорого.
 *
 * ЕСКЕЙПИ (у цьому порядку):
 *   <repoRoot>/.claude/gates-off   файл-маркер, глушить обидва правила
 *   EDIT_GATE=off|0|false          глушить обидва правила
 *   RED_GATE=off|0|false           глушить тільки правило A
 *   TEST_LOCK=off|0|false          глушить тільки правило B
 *   RULES_LOCK=off|0|false         глушить тільки правило C (для міграцій тексту
 *                                  правил людиною, не для «мені зараз зручно»)
 * Файл-маркер потрібен, бо env-змінні хукам зсередини сесії не поставиш.
 *
 * ЛІЧИЛЬНИК: кожне рішення (включно з ескейпами) дописується у .claude/gates.jsonl.
 *
 * Крос-платформа: чистий node, без .sh, без шел-глобів, без хардкод-шляхів.
 */
'use strict';

const fs = require('fs');
const path = require('path');
const { repoRoot, norm, toRel, isProdFile, isTestFile } = require('./_scope.cjs');

// ── бюджети ─────────────────────────────────────────────────────────────────
const TIME_BUDGET_MS = 300;
const MAX_TARGET_BYTES = 4 * 1024 * 1024;   // більший файл не читаємо, це не тест

// Інструменти, що змінюють файл.
const EDIT_TOOLS = ['Edit', 'Write', 'MultiEdit', 'NotebookEdit'];

// ── сигнали сили тесту ──────────────────────────────────────────────────────
// Порівнюємо «до» і «після». Блокує тільки ПОГІРШЕННЯ лічильника.
//
// ЧОМУ ПАТЕРНИ ТАКІ ВУЗЬКІ. Хибна заборона тут дорожча за пропущене послаблення:
// вона зупиняє чесну роботу, і перший рефлекс людини на неї це вимкнути гейт.
// Тому кожен патерн мусить ловити ВЛАСНЕ твердження, а не будь-яку згадку слова:
//   - `\bassert\b` ловило рядок `import assert from 'node:assert/strict'` і
//     навіть слово «assert» у коментарі, тож прибрати непотрібний імпорт
//     читалось як видалення двох тверджень. Тепер тільки `assert` на початку
//     рядка і не як `assert.`: це python `assert x == 1` і js `assert(cond)`.
//   - `\btest\(` ловило `RE.test(s)`, будь-яку перевірку регуляркою. Тепер
//     lookbehind відсікає виклик-метод (`.test(`) і суфікс (`mytest(`).
//   - те саме для `match(`: `text.match(re)` це рядкова операція, а не assert.
//     Голий `match(` з деструктуризації лишається твердженням.
const SIGNALS = {
  assertions: [
    /^[ \t]*assert\b(?![.\w])/gm,
    /\bassert\.\w+\(/g,
    /\bexpect\(/g,
    /(?<![.\w$])(strictEqual|deepStrictEqual|notStrictEqual|throws|rejects|doesNotThrow|match)\s*\(/g,
    /self\.assert\w*\(/g,
    /\bpytest\.raises\b/g,
  ],
  declarations: [
    /(?<![.\w$])test\s*\(/g,
    /(?<![.\w$])it\s*\(/g,
    /(?<![.\w$])describe\s*\(/g,
    /^\s*(async\s+)?def\s+test_\w+/gm,
  ],
  skips: [
    /\.(skip|todo)\b/g,
    /\bxfail\b/g,
    /@pytest\.mark\.skip/g,
    /\bpytest\.skip\(/g,
  ],
  commented: [
    /^\s*(\/\/|#)\s*(assert|expect|self\.assert)/gm,
  ],
};

// ── правило C: файл правил ChatView ─────────────────────────────────────────
// Два імені: живий файл і заводський поруч із ним. Заводський теж під замком, бо
// інакше «повернути заводські» відновлювало б те, що модель туди й записала, тобто
// кнопка відкоту стала б декорацією.
const RULES_FILE_NAMES = ['rules.md', 'rules.default.md'];

/**
 * Чи це файл правил ChatView.
 *
 * Матчимо не по імені, а по ПАРІ (імʼя, тека): `rules.md` це занадто популярне імʼя,
 * щоб замикати його всюди, де воно трапиться. Дозволених тек рівно дві: сама тека
 * застосунку в репо і CHATVIEW_HOME пакованої збірки.
 */
function isRulesFile(filePath, cwd, env) {
  try {
    const abs = path.resolve(cwd || repoRoot(), String(filePath || ''));
    if (!RULES_FILE_NAMES.includes(path.basename(abs).toLowerCase())) return false;
    const dir = norm(path.dirname(abs)).toLowerCase();
    const dirs = [norm(path.join(repoRoot(), 'tools', 'viz', 'chat')).toLowerCase()];
    const home = env && env.CHATVIEW_HOME;
    if (home) dirs.push(norm(path.resolve(home)).toLowerCase());
    return dirs.includes(dir);
  } catch { return false; }            // fail-open, як і решта гейта
}

function buildRulesReason(rel) {
  return [
    'СТОП, замок правил ChatView (rules-lock).',
    '',
    `${rel} це правила поведінки самого застосунку. Вони мають вищий пріоритет за`,
    'проєктний CLAUDE.md і частину його правил прямо скасовують, тобто керують',
    'кожним твоїм наступним ходом. Правила, які модель може переписати собі сама,',
    'перестають бути правилами, тому редагувати їх з-під моделі не можна.',
    '',
    'Єдиний дозволений шлях: екран Налаштування в ChatView, картка «Правила',
    'застосунку». Там же кнопка «Повернути заводські», а попередній текст лишається',
    'копією в rules.prev.md.',
    '',
    'Якщо це справді міграція тексту правил, а не зручність, це рішення людини:',
    'скажи Vova словами або постав файл .claude/gates-off на час міграції.',
  ].join('\n');
}

// Людські назви метрик для тексту заборони.
const SIGNAL_LABELS = {
  assertions: 'тверджень',
  declarations: 'оголошень тестів',
  skips: 'маркерів пропуску',
  commented: 'закоментованих тверджень',
};

// ── утиліти ─────────────────────────────────────────────────────────────────

function logPath() {
  if (process.env.GATES_LOG) return process.env.GATES_LOG;
  return path.join(repoRoot(), '.claude', 'gates.jsonl');
}

/** Лічильник. Сам ніколи не кидає. */
function record(entry) {
  try {
    const p = logPath();
    fs.mkdirSync(path.dirname(p), { recursive: true });
    const line = JSON.stringify(Object.assign({
      ts: new Date().toISOString(),
      gate: 'edit-gate',
    }, entry, process.env.PROOF_GATE_TAG ? { tag: process.env.PROOF_GATE_TAG } : null));
    fs.appendFileSync(p, line + '\n');
  } catch { /* лічильник не сміє ламати гейт */ }
}

/** Вимкнено? Приймає off / 0 / false у будь-якому регістрі. */
function isOff(v) {
  const s = String(v == null ? '' : v).trim().toLowerCase();
  return s === 'off' || s === '0' || s === 'false';
}

/** Локальний час у стабільному вигляді. Без Intl, щоб не залежати від ICU. */
function localStamp(ms) {
  if (!Number.isFinite(ms)) return 'час невідомий';
  const d = new Date(ms);
  const p2 = (n) => String(n).padStart(2, '0');
  return `${d.getFullYear()}-${p2(d.getMonth() + 1)}-${p2(d.getDate())} ` +
         `${p2(d.getHours())}:${p2(d.getMinutes())}`;
}

/** «скільки тому» людською мовою. */
function agoText(ms, now) {
  if (!Number.isFinite(ms)) return 'давність невідома';
  const diff = Math.max(0, now - ms);
  const min = Math.floor(diff / 60000);
  if (min < 1) return 'щойно';
  if (min < 90) return `${min} хв тому`;
  const h = Math.floor(min / 60);
  if (h < 36) return `${h} год тому`;
  return `${Math.floor(h / 24)} дн тому`;
}

/** Момент прогону зі стану: epoch_ms надійніший, ts як фолбек. */
function stateMs(state) {
  if (state && Number.isFinite(state.epoch_ms)) return state.epoch_ms;
  const t = state && state.ts ? Date.parse(state.ts) : NaN;
  return Number.isFinite(t) ? t : NaN;
}

/** JSON з диска або null. Ніколи не кидає: брак файлу і битий JSON рівноцінні. */
function readJson(file) {
  try {
    const raw = fs.readFileSync(file, 'utf8');
    const o = JSON.parse(raw);
    return (o && typeof o === 'object') ? o : null;
  } catch { return null; }
}

// ── ядро: лічильники сигналів ───────────────────────────────────────────────

/**
 * Скільки сигналів кожного роду у тексті.
 * @returns {{assertions:number, declarations:number, skips:number, commented:number}}
 */
function countSignals(text) {
  const s = typeof text === 'string' ? text : '';
  const out = {};
  for (const key of Object.keys(SIGNALS)) {
    let n = 0;
    for (const re of SIGNALS[key]) {
      // String.match з глобальним патерном сам скидає lastIndex, тож стан не тече.
      const m = s.match(re);
      if (m) n += m.length;
    }
    out[key] = n;
  }
  return out;
}

/**
 * Чи послаблює правка тест.
 * Погіршення = менше тверджень, менше оголошень, більше skip, більше закоментованих.
 * @returns {{weak:boolean, before:object, after:object, worse:string[]}}
 */
function isWeakening(beforeText, afterText) {
  const before = countSignals(beforeText);
  const after = countSignals(afterText);
  const worse = [];
  if (after.assertions < before.assertions) worse.push('assertions');
  if (after.declarations < before.declarations) worse.push('declarations');
  if (after.skips > before.skips) worse.push('skips');
  if (after.commented > before.commented) worse.push('commented');
  return { weak: worse.length > 0, before, after, worse };
}

/**
 * Пара текстів «до / після» для інструмента.
 * @returns {{before:string, after:string}|{skip:string}}
 */
function editPair(toolName, toolInput, existing) {
  const ti = toolInput || {};
  if (toolName === 'Edit') {
    return { before: String(ti.old_string || ''), after: String(ti.new_string || '') };
  }
  if (toolName === 'MultiEdit') {
    const edits = Array.isArray(ti.edits) ? ti.edits : [];
    return {
      before: edits.map((e) => String((e && e.old_string) || '')).join('\n'),
      after: edits.map((e) => String((e && e.new_string) || '')).join('\n'),
    };
  }
  if (toolName === 'Write') {
    // Нема на диску означає новий тест: порівнювати нема з чим.
    if (!existing || !existing.exists) return { skip: 'new-test-file' };
    if (existing.tooBig) return { skip: 'target-too-big' };
    return { before: String(existing.content || ''), after: String(ti.content || '') };
  }
  return { skip: 'notebook-out-of-scope' };   // NotebookEdit поза скоупом
}

// ── тексти заборон ──────────────────────────────────────────────────────────

function buildRedReason(state, rel, now) {
  const argv = Array.isArray(state.argv) && state.argv.length ? ' ' + state.argv.join(' ') : '';
  const counts = (state && state.counts) || {};
  const failed = Number.isFinite(counts.failed) ? counts.failed : 0;
  const passed = Number.isFinite(counts.passed) ? counts.passed : 0;
  const ms = stateMs(state);
  const implicated = Array.isArray(state.implicated) ? state.implicated : [];
  const list = implicated.length
    ? implicated.slice(0, 8).map((f) => '  - ' + f).join('\n')
    : '  - (список порожній)';
  return [
    'СТОП, гейт червоного прогону (red-gate).',
    '',
    'Останній прогін тестів був ЧЕРВОНИЙ, а ця правка не стосується жодного файлу',
    'з падіння. Нове поверх зламаного це два баги замість одного.',
    '',
    `Прогін: node scripts/run-tests.cjs${argv} (${localStamp(ms)}, ${agoText(ms, now)})`,
    `Причина: ${state.reason || 'невідома'}, впало ${failed} кейс(ів) з ${passed + failed}`,
    'Падіння торкаються:',
    list,
    `Ти намагався правити: ${rel}`,
    '',
    'Що робити:',
    '  1. Полагодь падіння. Правки у файлах зі списку вище дозволені, гейт їх пропускає.',
    '  2. Прогони npm test. Зелений прогін знімає гейт сам, ніякої іншої дії не треба.',
    '  3. Якщо падіння не твоє і зараз не лагодиться, скажи Vova і постав файл .claude/gates-off.',
  ].join('\n');
}

function buildLockReason(rel, note) {
  const tail = note ? `: ${note}` : '';
  return [
    'СТОП, замок тест-файлу (test-lock).',
    '',
    `${rel} у списку замкнених${tail}. Це тест самого гейта: якщо його можна тихо`,
    'послабити, всі інші гейти стають декорацією.',
    '',
    'Змінити легально:',
    `  node scripts/test-lock.cjs unlock ${rel} --reason "навіщо"`,
    '  ... правка ...',
    `  node scripts/test-lock.cjs lock ${rel}`,
    '',
    'Обидві дії пишуться у .claude/gates.jsonl, тож зняття замка видно.',
  ].join('\n');
}

function buildWeakeningReason(rel, cmp) {
  const rows = cmp.worse.map(
    (k) => `  - ${SIGNAL_LABELS[k]}: ${cmp.before[k]} -> ${cmp.after[k]}`
  );
  return [
    'СТОП, гейт послаблення тесту (test-lock).',
    '',
    'Ця правка зменшує силу тесту, а не код під ним:',
    ...rows,
    '',
    `Файл: ${rel}`,
    '',
    'Підганяти тест під код замість коду під тест дає зелений прогін,',
    'який нічого не доводить.',
    '',
    'Якщо це чесний рефактор (винесення хелпера, злиття кейсів), скажи це Vova',
    'словами або постав файл .claude/gates-off на час рефактора.',
  ].join('\n');
}

// ── ядро: рішення ───────────────────────────────────────────────────────────

const skip = (why, rule) => ({ decision: 'skip', rule: rule || null, why, reason: '' });
const pass = (why, rule) => ({ decision: 'pass', rule: rule || null, why, reason: '' });
const deny = (why, rule, reason) => ({ decision: 'deny', rule, why, reason });

/**
 * Чиста функція рішення. Жодного I/O: усе, що з диска, приходить аргументами.
 *
 * @param {object} o
 * @param {string} o.toolName    tool_name з stdin
 * @param {object} o.toolInput   tool_input з stdin
 * @param {string} o.cwd         cwd з stdin
 * @param {object|null} o.state  розпарсений .claude/test-state.json
 * @param {object|null} o.lock   розпарсений .claude/test-lock.json
 * @param {object} o.env         оточення (process.env або підробка в тестах)
 * @param {number} o.now         Date.now()
 * @param {boolean} [o.gatesOff] чи існує файл-маркер .claude/gates-off
 * @param {object} [o.existing]  {exists, content, tooBig} цільового файлу, для Write
 * @returns {{decision:'deny'|'pass'|'skip', rule:string|null, why:string, reason:string}}
 */
function evaluate(o) {
  const opts = o || {};
  const env = opts.env || {};
  const toolInput = opts.toolInput || {};
  const cwd = opts.cwd || repoRoot();
  const now = Number.isFinite(opts.now) ? opts.now : Date.now();

  // ── ескейпи. Найперше і без жодної роботи ──
  if (opts.gatesOff) return skip('file-off');
  if (isOff(env.EDIT_GATE)) return skip('env-off');

  if (!EDIT_TOOLS.includes(opts.toolName)) return skip('tool-out-of-scope');

  const filePath = toolInput.file_path || toolInput.notebook_path;
  if (!filePath) return skip('no-file-path');

  const rel = norm(toRel(filePath, cwd));
  const redOff = isOff(env.RED_GATE);
  const lockOff = isOff(env.TEST_LOCK);

  // ── ПРАВИЛО C: файл правил. ПЕРШИМ, бо .md не є ні тестом, ні прод-файлом,
  // тобто після перевірок нижче він просто провалився б у pass ──
  if (isRulesFile(filePath, cwd, env)) {
    if (isOff(env.RULES_LOCK)) return skip('env-off-rules-lock', 'rules-lock');
    return deny('rules-file', 'rules-lock', buildRulesReason(rel));
  }

  // ── ПРАВИЛО B: тест-файли. Порядок фіксований: B1, потім B2, потім A ──
  if (isTestFile(filePath, cwd)) {
    if (lockOff) return skip('env-off-test-lock', 'test-lock');

    // B1: хеш-замок. Ніякої евристики, файл у списку значить недоторканний.
    const files = (opts.lock && opts.lock.files && typeof opts.lock.files === 'object')
      ? opts.lock.files : null;
    if (files) {
      const key = Object.keys(files).find((k) => norm(k).toLowerCase() === rel.toLowerCase());
      if (key) {
        const note = files[key] && files[key].note;
        return deny('locked-file', 'test-lock', buildLockReason(rel, note));
      }
    }

    // B2: евристика послаблення.
    const pair = editPair(opts.toolName, toolInput, opts.existing);
    if (pair.skip) return pass(pair.skip, 'weakening');
    const cmp = isWeakening(pair.before, pair.after);
    if (cmp.weak) return deny('weakening', 'weakening', buildWeakeningReason(rel, cmp));
    return pass('test-edit-ok', 'weakening');
  }

  // ── ПРАВИЛО A: red-gate. Тільки прод-код ──
  if (!isProdFile(filePath, cwd)) return pass('out-of-scope');
  if (redOff) return skip('env-off-red-gate', 'red-gate');

  const state = opts.state;
  // Нема стану / битий / чужа схема: нормальний стан на чистій машині.
  if (!state || state.schema !== 1) return pass('no-state', 'red-gate');
  if (state.verdict === 'green') return pass('last-run-green', 'red-gate');
  if (state.verdict !== 'red') return pass('no-state', 'red-gate');   // невідомий вердикт, fail-open

  // Лагодити падіння МОЖНА завжди, інакше гейт стає дедлоком.
  const implicated = Array.isArray(state.implicated) ? state.implicated : [];
  // Червоно, але звинувачувати нема кого: у гейта нема жодного доказу про прод,
  // і при забороні не лишається ЖОДНОГО файлу, правкою якого прогін можна
  // повернути в зелене. Це дедлок, тому тут fail-open.
  if (!implicated.length) return pass('red-but-no-blame', 'red-gate');
  const hit = implicated.some((f) => norm(f).toLowerCase() === rel.toLowerCase());
  if (hit) return pass('editing-implicated-file', 'red-gate');

  return deny('red-suite', 'red-gate', buildRedReason(state, rel, now));
}

// ── main ────────────────────────────────────────────────────────────────────

function main() {
  const deadline = Date.now() + TIME_BUDGET_MS;

  let input = {};
  try { input = JSON.parse(fs.readFileSync(0, 'utf8')); } catch { input = {}; }
  if (!input || typeof input !== 'object') input = {};

  const sessionId = String(input.session_id || '');
  const toolName = input.tool_name;
  const toolInput = (input.tool_input && typeof input.tool_input === 'object') ? input.tool_input : {};
  const cwd = input.cwd || repoRoot();

  // Найдешевший відсів: не наш інструмент означає нуль читань з диска.
  const inScope = EDIT_TOOLS.includes(toolName);
  const filePath = inScope ? (toolInput.file_path || toolInput.notebook_path) : null;

  let gatesOff = false;
  try { gatesOff = fs.existsSync(path.join(repoRoot(), '.claude', 'gates-off')); } catch { /* fail-open */ }

  // Читаємо РІВНО те, що знадобиться цьому рішенню.
  let state = null;
  let lock = null;
  let existing = null;
  if (inScope && filePath && !gatesOff && !isOff(process.env.EDIT_GATE)) {
    const dotClaude = path.join(repoRoot(), '.claude');
    if (isTestFile(filePath, cwd)) {
      lock = readJson(path.join(dotClaude, 'test-lock.json'));
      if (toolName === 'Write') {
        try {
          const st = fs.statSync(filePath);
          existing = st.size > MAX_TARGET_BYTES
            ? { exists: true, tooBig: true, content: '' }
            : { exists: true, tooBig: false, content: fs.readFileSync(filePath, 'utf8') };
        } catch { existing = { exists: false, tooBig: false, content: '' }; }
      }
    } else if (isProdFile(filePath, cwd)) {
      state = readJson(path.join(dotClaude, 'test-state.json'));
    }
  }

  // Бюджет часу: вийшли за нього означає тихий пропуск.
  if (Date.now() > deadline) {
    record({ decision: 'skip', why: 'time-budget', file: '', session_id: sessionId });
    return 0;
  }

  const res = evaluate({
    toolName, toolInput, cwd, state, lock,
    env: process.env, now: Date.now(), gatesOff, existing,
  });

  const rel = filePath ? norm(toRel(filePath, cwd)) : '';
  record({
    decision: res.decision,
    rule: res.rule || undefined,
    why: res.why,
    file: rel,
    session_id: sessionId,
  });

  if (res.decision === 'deny') {
    process.stdout.write(JSON.stringify({
      hookSpecificOutput: {
        hookEventName: 'PreToolUse',
        permissionDecision: 'deny',
        permissionDecisionReason: res.reason,
      },
    }));
  }
  return 0;
}

module.exports = {
  evaluate,
  countSignals,
  isWeakening,
  buildRedReason,
  buildLockReason,
  buildWeakeningReason,
  buildRulesReason,
  isRulesFile,
  editPair,
  isOff,
  main,
};

// Запускаємось як хук тільки коли нас викликали напряму: з тестів файл require-иться.
if (require.main === module) {
  let code = 0;
  try { code = main(); } catch { code = 0; }   // FAIL-OPEN, завжди
  process.exit(code);
}
