#!/usr/bin/env node
// CLI for the REFLECT self-learning inbox. Used by me during the DISTILL stage so the
// append-only JSONL is never hand-edited (which would corrupt it).
//
//   node learn.cjs list                         — pending signals, full detail
//   node learn.cjs stats                        — captured / distilled / dropped / pending
//   node learn.cjs resolve <id...> [--outcome]  — close signals (--distilled default | --merged | --dropped)
//
const store = require('./_learn-store.cjs');

const [, , cmd, ...rest] = process.argv;

function printSignal(s) {
  console.log(`• ${s.id}  [${s.kind}]  ${s.ts}`);
  console.log(`    signal: ${s.signal}`);
  if (s.prior_hint) console.log(`    я казав до цього: ${s.prior_hint}`);
  console.log('');
}

if (cmd === 'list') {
  const pend = store.pending();
  if (!pend.length) { console.log('inbox порожній — усі сигнали дистильовані ✓'); process.exit(0); }
  console.log(`${pend.length} pending signal(s):\n`);
  pend.forEach(printSignal);
} else if (cmd === 'stats') {
  const s = store.stats();
  console.log(JSON.stringify(s, null, 2));
} else if (cmd === 'resolve') {
  const ids = rest.filter(a => !a.startsWith('--'));
  let outcome = 'distilled';
  if (rest.includes('--merged')) outcome = 'merged';
  else if (rest.includes('--dropped')) outcome = 'dropped';
  else if (rest.includes('--distilled')) outcome = 'distilled';
  if (!ids.length) { console.error('usage: learn.cjs resolve <id...> [--distilled|--merged|--dropped]'); process.exit(1); }
  const n = store.resolve(ids, outcome);
  console.log(`resolved ${n} signal(s) as ${outcome}. remaining pending: ${store.pending().length}`);
} else {
  console.log('usage: learn.cjs <list|stats|resolve>');
  console.log('  list                          — pending signals');
  console.log('  stats                         — counters');
  console.log('  resolve <id...> [--outcome]   — --distilled (default) | --merged | --dropped');
}
