#!/usr/bin/env node
// Stop hook (cross-platform: Mac + Windows).
// When this Claude Code session finishes a turn, flip its bound channel's tab dot
// from WORKING (yellow) to DONE (green): delete cc-busy, write cc-done.
// Vova opening the tab clears cc-done via POST /api/channel-seen.
//
// stdin JSON = { session_id, ... }.
// Registered from .claude/settings.json with a portable ${CLAUDE_PROJECT_DIR} path.
// MUST never throw / never exit non-zero.

const fs = require('fs');
const path = require('path');

try {
  let input = {};
  try { input = JSON.parse(fs.readFileSync(0, 'utf8')); } catch {}
  const sessionId = input && input.session_id ? String(input.session_id) : '';
  if (!sessionId) process.exit(0);

  let mod = null;
  try { mod = require('./plan-state.cjs'); } catch {}
  if (!mod) process.exit(0);

  const boundId = mod.boundChannel(sessionId);
  if (!boundId) process.exit(0);

  // Only flip the dot for a MATERIALIZED channel. A reserved-but-empty channel has
  // no dir / no tab, so writing cc-done would create an orphan dir for no reason.
  const chDir = path.join(mod.CHANNELS_DIR, boundId);
  if (!fs.existsSync(chDir)) process.exit(0);
  try { fs.unlinkSync(path.join(chDir, 'cc-busy')); } catch {}
  try { fs.writeFileSync(path.join(chDir, 'cc-done'), new Date().toISOString()); } catch {}
  // «Процеси» panel: mark the turn end (Vova 2026-07-08).
  try { require('./_emit.cjs').emit(boundId, { kind: 'hook', name: 'Stop', phase: 'fire', detail: 'тан завершено' }); } catch {}
} catch {
  // never throw
}

process.exit(0);
