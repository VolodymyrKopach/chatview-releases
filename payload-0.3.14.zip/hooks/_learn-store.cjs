// Shared, append-only store for the REFLECT self-learning loop.
// Two files under <repo>/memory/_learn/:
//   inbox.jsonl    — every captured correction signal (append-only)
//   resolved.jsonl — {id, outcome, ts} per processed signal (append-only)
// Append-only by design so the capture hook and the CLI never race on a rewrite.
// MUST NEVER throw for the capture path: a throw in a UserPromptSubmit hook blocks
// prompt submission. Every exported fn is wrapped defensively. Cross-platform.
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');

const REPO = process.env.CLAUDE_PROJECT_DIR || path.resolve(__dirname, '../../../..');
const LEARN_DIR = path.join(REPO, 'memory', '_learn');
const INBOX = path.join(LEARN_DIR, 'inbox.jsonl');
const RESOLVED = path.join(LEARN_DIR, 'resolved.jsonl');

// A signal older than this that is still un-resolved is considered abandoned: it drops
// out of pending() so the nag can never haunt forever. It stays in the file for audit.
const PENDING_TTL_MS = 14 * 24 * 60 * 60 * 1000;
// Opportunistic rotation (mirrors _emit.cjs): keep the tail so the per-prompt parse and
// the file stay bounded even after months of appends.
const TRIM_AT_BYTES = 256 * 1024;
const KEEP_LINES = 400;

function ensureDir() {
  try { fs.mkdirSync(LEARN_DIR, { recursive: true }); } catch {}
}

// Rewrite to the last KEEP_LINES only when the file grew past TRIM_AT_BYTES, so the
// common path stays a cheap O(1) append.
function _trimIfBig(p) {
  try {
    const st = fs.statSync(p);
    if (st.size < TRIM_AT_BYTES) return;
    const lines = fs.readFileSync(p, 'utf8').split('\n').filter(Boolean);
    if (lines.length <= KEEP_LINES) return;
    fs.writeFileSync(p, lines.slice(-KEEP_LINES).join('\n') + '\n');
  } catch {}
}

function readLines(file) {
  try {
    return fs.readFileSync(file, 'utf8')
      .split('\n')
      .filter(Boolean)
      .map(l => { try { return JSON.parse(l); } catch { return null; } })
      .filter(Boolean);
  } catch { return []; }
}

// Append one captured signal. Returns the stored record (with id), or null on failure.
function append(rec) {
  try {
    ensureDir();
    _trimIfBig(INBOX);
    const id = crypto.randomBytes(5).toString('hex');
    const full = Object.assign({ id, ts: new Date().toISOString(), status: 'pending' }, rec);
    fs.appendFileSync(INBOX, JSON.stringify(full) + '\n');
    return full;
  } catch { return null; }
}

function resolvedIds() {
  return new Set(readLines(RESOLVED).map(r => r.id));
}

// Signals captured, not yet distilled/dropped, AND not older than the TTL (abandoned
// signals stop nagging but remain in the file for audit).
function pending() {
  const done = resolvedIds();
  const cutoff = Date.now() - PENDING_TTL_MS;
  return readLines(INBOX).filter(r => {
    if (done.has(r.id)) return false;
    const t = Date.parse(r.ts);
    if (!isNaN(t) && t < cutoff) return false;
    return true;
  });
}

// Mark ids as processed. outcome: 'distilled' | 'merged' | 'dropped'.
function resolve(ids, outcome) {
  if (!Array.isArray(ids)) ids = [ids];
  ensureDir();
  let n = 0;
  for (const id of ids) {
    try {
      fs.appendFileSync(RESOLVED, JSON.stringify({ id, outcome: outcome || 'distilled', ts: new Date().toISOString() }) + '\n');
      n++;
    } catch {}
  }
  return n;
}

function stats() {
  const inbox = readLines(INBOX);
  const res = readLines(RESOLVED);
  const byOutcome = {};
  for (const r of res) byOutcome[r.outcome || 'distilled'] = (byOutcome[r.outcome || 'distilled'] || 0) + 1;
  return {
    captured: inbox.length,
    resolved: res.length,
    pending: pending().length,
    distilled: byOutcome.distilled || 0,
    merged: byOutcome.merged || 0,
    dropped: byOutcome.dropped || 0,
  };
}

module.exports = { LEARN_DIR, INBOX, RESOLVED, ensureDir, readLines, append, pending, resolve, stats };
