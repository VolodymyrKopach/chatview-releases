#!/usr/bin/env node
/**
 * push-gate.cjs. PreToolUse hook. Детерміноване гальмо на `git push`.
 *
 * НАВІЩО ЗАМІСТЬ ask-ПРАВИЛА: у permissions був `Bash(git push:*)` у списку ask.
 * Він працює тільки там, де є жива людина біля терміналу. У сесії всередині
 * ChatView (Agent SDK,非-інтерактив) діалог показати нікому, тож ask вироджується
 * у глухий deny: пуш неможливий взагалі. Перекрити його вузьким allow не можна,
 * документація прямо каже (https://code.claude.com/docs/en/permissions):
 *   «Rules are evaluated in order: deny, then ask, then allow ... a matching ask
 *    rule prompts even when a more specific allow rule also matches the same call.»
 * Хук такого припущення про людину не робить: він або мовчить, або забороняє з
 * причиною, однаково в терміналі і в ChatView. Determinism over hope.
 *
 * ПРАВИЛА (в порядку перевірки, перша спрацьована виграє):
 *   P1 force    : --force / -f / --force-with-lease / +refspec        ЗАВЖДИ deny
 *   P2 delete   : --delete / -d / порожній src у refspec (`:branch`)  ЗАВЖДИ deny
 *   P3 broad    : --all / --mirror (виходить за межі однієї гілки)    ЗАВЖДИ deny
 *   P4 protected: цільова гілка master / main                         ЗАВЖДИ deny
 *   P5 unknown  : цільову гілку визначити не вдалось                  deny
 *   P6 approval : нема свіжого токена апруву саме на цю гілку         deny
 * P1..P4 токеном НЕ обходяться: це не «чекаю дозволу», це «ні».
 * `--dry-run` пропускається завжди (нічого не змінює на віддаленому боці).
 *
 * ТОКЕН АПРУВУ: .claude/push-approved.json = {branch, epoch_ms, note}.
 * Створюється ритуалом `node scripts/push-approve.cjs <branch> --note "..."`,
 * живе PUSH_APPROVAL_TTL_MIN хвилин (дефолт 30). Токен НЕ споживається пушем:
 * інакше мережевий збій вимагав би нового апруву на повтор тієї ж дії.
 * Чесно про межі: токен створює той самий агент, тож це тертя і журнал, а не
 * криптографічна стіна. Цінність у сліді, не в неможливості.
 *
 * КОНТРАКТ ХУКА (звірено з https://code.claude.com/docs/en/hooks, 2026-07-30):
 *   stdin : { session_id, cwd, hook_event_name:"PreToolUse", tool_name, tool_input }
 *   блок  : exit 0 + stdout
 *           {"hookSpecificOutput":{"hookEventName":"PreToolUse",
 *             "permissionDecision":"deny","permissionDecisionReason":"..."}}
 *   пропуск: exit 0 + ПОРОЖНІЙ stdout.
 *   JSON обробляється ТІЛЬКИ при exit 0. permissionDecision:"allow" не виводимо
 *   НІКОЛИ: це обхід системи дозволів користувача.
 *
 * FAIL-OPEN, але з одним свідомим винятком. Битий JSON, чужий інструмент, збій
 * розбору, вихід за бюджет часу = ТИХИЙ ПРОПУСК. Виняток P5: якщо команда це
 * очевидний push, а цільову гілку визначити не вдалось, ми забороняємо. Пропуск
 * тут означав би «не знаю куди пушу, але хай летить», а саме від цього гальмо.
 *
 * ЕСКЕЙПИ:
 *   <repoRoot>/.claude/gates-off   файл-маркер, глушить усі гейти
 *   PUSH_GATE=off|0|false          глушить цей гейт
 * Кожен ескейп теж пишеться у журнал.
 *
 * ЛІЧИЛЬНИК: кожне рішення дописується у .claude/gates.jsonl.
 *
 * Крос-платформа: чистий node, без .sh, без шел-глобів, без хардкод-шляхів.
 */
'use strict';

const fs = require('fs');
const path = require('path');
const { execFileSync } = require('child_process');
const { repoRoot } = require('./_scope.cjs');

// ── бюджети ─────────────────────────────────────────────────────────────────
const TIME_BUDGET_MS = 400;          // включно з одним викликом git rev-parse
const GIT_TIMEOUT_MS = 250;
const MAX_CMD_CHARS = 200 * 1024;    // довша команда це не рука людини, не розбираємо

// Інструменти, що виконують шел-команду.
const SHELL_TOOLS = ['Bash', 'PowerShell'];

// Гілки, у які пуш заборонений завжди, незалежно від апруву.
const PROTECTED = ['master', 'main'];

const DEFAULT_TTL_MIN = 30;

// ── утиліти ─────────────────────────────────────────────────────────────────

function logPath() {
  if (process.env.GATES_LOG) return process.env.GATES_LOG;
  return path.join(repoRoot(), '.claude', 'gates.jsonl');
}

/** Лічильник. Сам ніколи не кидає. */
function record(entry) {
  try {
    const p = logPath();
    fs.mkdirSync(path.dirname(p), { recursive: true });
    const line = JSON.stringify(Object.assign({
      ts: new Date().toISOString(),
      gate: 'push-gate',
    }, entry, process.env.PROOF_GATE_TAG ? { tag: process.env.PROOF_GATE_TAG } : null));
    fs.appendFileSync(p, line + '\n');
  } catch { /* лічильник не сміє ламати гейт */ }
}

function isOff(v) {
  const s = String(v == null ? '' : v).trim().toLowerCase();
  return s === 'off' || s === '0' || s === 'false';
}

function tokenPath() {
  if (process.env.PUSH_APPROVAL_FILE) return process.env.PUSH_APPROVAL_FILE;
  return path.join(repoRoot(), '.claude', 'push-approved.json');
}

function ttlMs() {
  const raw = Number(process.env.PUSH_APPROVAL_TTL_MIN);
  const min = Number.isFinite(raw) && raw > 0 ? raw : DEFAULT_TTL_MIN;
  return min * 60 * 1000;
}

function agoText(ms, now) {
  if (!Number.isFinite(ms)) return 'давність невідома';
  const diff = Math.max(0, now - ms);
  const m = Math.floor(diff / 60000);
  if (m < 1) return 'щойно';
  if (m < 90) return `${m} хв тому`;
  const h = Math.floor(m / 60);
  if (h < 36) return `${h} год тому`;
  return `${Math.floor(h / 24)} дн тому`;
}

// ── розбір команди ──────────────────────────────────────────────────────────

/**
 * Ріже складену команду на сегменти по && || ; | та переводу рядка.
 * Лапки і бекслеш поважає, щоб `echo "a && b"` не розʼїхався на два сегменти.
 */
function splitSegments(cmd) {
  const out = [];
  let cur = '';
  let quote = null;
  for (let i = 0; i < cmd.length; i++) {
    const c = cmd[i];
    if (quote) {
      cur += c;
      if (c === '\\' && quote === '"' && i + 1 < cmd.length) { cur += cmd[++i]; continue; }
      if (c === quote) quote = null;
      continue;
    }
    if (c === '"' || c === "'") { quote = c; cur += c; continue; }
    if (c === '\\' && i + 1 < cmd.length) { cur += c + cmd[++i]; continue; }
    if (c === '\n' || c === ';') { out.push(cur); cur = ''; continue; }
    if ((c === '&' || c === '|') && cmd[i + 1] === c) { out.push(cur); cur = ''; i++; continue; }
    if (c === '|') { out.push(cur); cur = ''; continue; }
    cur += c;
  }
  out.push(cur);
  return out.map((s) => s.trim()).filter(Boolean);
}

/** Ріже сегмент на токени, знімаючи лапки. */
function tokenize(seg) {
  const out = [];
  let cur = '';
  let has = false;
  let quote = null;
  for (let i = 0; i < seg.length; i++) {
    const c = seg[i];
    if (quote) {
      if (c === '\\' && quote === '"' && i + 1 < seg.length) { cur += seg[++i]; has = true; continue; }
      if (c === quote) { quote = null; continue; }
      cur += c; has = true; continue;
    }
    if (c === '"' || c === "'") { quote = c; has = true; continue; }
    if (c === '\\' && i + 1 < seg.length) { cur += seg[++i]; has = true; continue; }
    if (/\s/.test(c)) { if (has) { out.push(cur); cur = ''; has = false; } continue; }
    cur += c; has = true;
  }
  if (has) out.push(cur);
  return out;
}

/** Базове імʼя виконуваного файлу без шляху і без .exe. */
function exeName(tok) {
  const base = String(tok).replace(/\\/g, '/').split('/').pop() || '';
  return base.toLowerCase().replace(/\.exe$/, '');
}

// Прапорці рівня git (до підкоманди), що їдять наступний токен.
const GIT_OPTS_WITH_ARG = ['-C', '-c', '--git-dir', '--work-tree', '--namespace', '--exec-path'];

/**
 * Витягує аргументи push з сегмента, або null якщо це не `git push`.
 * Розуміє env-префікси (`GIT_SSH=... git push`), `git -C <dir> push`, `--no-pager`.
 */
function parsePushSegment(seg) {
  const toks = tokenize(seg);
  let i = 0;

  // env-присвоєння перед командою
  while (i < toks.length && /^[A-Za-z_][A-Za-z0-9_]*=/.test(toks[i])) i++;
  // обгортки, що не міняють семантику пуша
  while (i < toks.length && ['sudo', 'env', 'command', 'nohup', 'time'].includes(exeName(toks[i]))) i++;
  while (i < toks.length && /^[A-Za-z_][A-Za-z0-9_]*=/.test(toks[i])) i++;

  if (i >= toks.length || exeName(toks[i]) !== 'git') return null;
  i++;

  // прапорці рівня git до підкоманди
  while (i < toks.length && toks[i].startsWith('-')) {
    const t = toks[i];
    const eq = t.indexOf('=');
    const name = eq === -1 ? t : t.slice(0, eq);
    i++;
    if (eq === -1 && GIT_OPTS_WITH_ARG.includes(name)) i++;   // зʼїдає значення
  }

  if (i >= toks.length || toks[i] !== 'push') return null;
  return toks.slice(i + 1);
}

/** Розбирає refspec у {dst, force, del}. */
function parseRefspec(spec) {
  let s = String(spec);
  let force = false;
  if (s.startsWith('+')) { force = true; s = s.slice(1); }
  const idx = s.indexOf(':');
  if (idx === -1) return { dst: stripRef(s), force, del: false };
  const src = s.slice(0, idx);
  const dst = s.slice(idx + 1);
  return { dst: stripRef(dst), force, del: src.trim() === '' };
}

function stripRef(name) {
  return String(name).replace(/^refs\/heads\//, '').replace(/^refs\/remotes\/[^/]+\//, '');
}

/** Поточна гілка робочого дерева. null якщо не вдалось. */
function currentBranch(cwd) {
  try {
    const out = execFileSync('git', ['rev-parse', '--abbrev-ref', 'HEAD'], {
      cwd, timeout: GIT_TIMEOUT_MS, encoding: 'utf8', stdio: ['ignore', 'pipe', 'ignore'],
    });
    const b = String(out).trim();
    return b && b !== 'HEAD' ? b : null;
  } catch { return null; }
}

/**
 * Судить один push. Повертає {rule, why, branch} для заборони, або null для пропуску.
 * Читання з диска і виклик git тільки тут, і тільки коли це справді push.
 */
function judgePush(args, cwd, now) {
  const flags = [];
  const positional = [];
  for (const a of args) {
    if (a === '--') continue;
    if (a.startsWith('-')) flags.push(a); else positional.push(a);
  }

  const has = (...names) => flags.some((f) => names.includes(f.split('=')[0]));
  // короткі склеєні прапорці (-fu) теж ловимо
  const shortHas = (ch) => flags.some((f) => /^-[a-z]+$/i.test(f) && f.slice(1).includes(ch));

  if (has('--dry-run') || shortHas('n')) return null;      // нічого не змінює

  if (has('--force', '--force-with-lease', '--force-if-includes') || shortHas('f')) {
    return { rule: 'force', why: 'force-push переписує чужу історію на віддаленому боці' };
  }
  if (has('--delete') || shortHas('d')) {
    return { rule: 'delete', why: 'видалення віддаленої гілки' };
  }
  if (has('--all', '--mirror')) {
    return { rule: 'broad', why: 'пуш усіх посилань разом виходить за межі однієї гілки' };
  }

  // refspec-и: усе після remote
  const specs = positional.slice(1);
  for (const s of specs) {
    const r = parseRefspec(s);
    if (r.force) return { rule: 'force', why: `refspec «${s}» починається з +, це той самий force`, branch: r.dst };
    if (r.del) return { rule: 'delete', why: `refspec «${s}» з порожнім джерелом видаляє віддалену гілку`, branch: r.dst };
  }

  // цільова гілка
  let branch = null;
  if (specs.length > 0) {
    const r = parseRefspec(specs[0]);
    branch = r.dst;
    if (branch === 'HEAD' || branch === '') branch = currentBranch(cwd);
  } else {
    branch = currentBranch(cwd);
  }

  if (!branch) {
    return { rule: 'unknown-branch', why: 'цільову гілку визначити не вдалось, а пуш наосліп це не пуш' };
  }
  if (PROTECTED.includes(branch.toLowerCase())) {
    return { rule: 'protected', why: `гілка «${branch}» захищена, у неї пушать через PR`, branch };
  }

  // токен апруву
  let tok = null;
  try { tok = JSON.parse(fs.readFileSync(tokenPath(), 'utf8')); } catch { tok = null; }
  if (!tok || typeof tok !== 'object') {
    return { rule: 'no-approval', why: 'нема токена апруву', branch };
  }
  if (String(tok.branch || '') !== branch) {
    return { rule: 'approval-mismatch', why: `токен виданий на «${tok.branch}», а пуш у «${branch}»`, branch };
  }
  const age = now - Number(tok.epoch_ms);
  if (!Number.isFinite(age) || age < 0 || age > ttlMs()) {
    return { rule: 'approval-stale', why: `токен видано ${agoText(Number(tok.epoch_ms), now)}, це поза вікном ${Math.round(ttlMs() / 60000)} хв`, branch };
  }

  return null;   // пропуск
}

function denyText(v) {
  const branch = v.branch ? ` (гілка: ${v.branch})` : '';
  const head = `push-gate: заборонено${branch}. Причина: ${v.why}.`;
  const ritual = [
    '',
    'Легальний шлях:',
    '  1. Vova каже слово на конкретну гілку.',
    '  2. node scripts/push-approve.cjs <branch> --note "чому саме зараз"',
    '  3. git push origin <branch>',
    '',
    'Форс, видалення віддаленої гілки, --all/--mirror і пуш у master/main токеном НЕ відкриваються.',
    'Аварійний вихід: файл .claude/gates-off (пишеться у журнал).',
  ];
  return [head].concat(ritual).join('\n');
}

// ── головна ─────────────────────────────────────────────────────────────────

function main() {
  const deadline = Date.now() + TIME_BUDGET_MS;

  let input = {};
  try { input = JSON.parse(fs.readFileSync(0, 'utf8')); } catch { return; }
  if (!input || typeof input !== 'object') return;

  const toolName = input.tool_name;
  if (!SHELL_TOOLS.includes(toolName)) return;

  const toolInput = (input.tool_input && typeof input.tool_input === 'object') ? input.tool_input : {};
  const cmd = String(toolInput.command || '');
  if (!cmd || cmd.length > MAX_CMD_CHARS) return;

  // Найдешевший відсів: без слова push жодних читань з диска.
  if (!/(^|[^\w-])push([^\w-]|$)/.test(cmd)) return;

  const cwd = input.cwd || repoRoot();
  const sessionId = String(input.session_id || '');

  let pushes = [];
  try {
    pushes = splitSegments(cmd).map(parsePushSegment).filter(Boolean);
  } catch { return; }                       // збій розбору = тихий пропуск
  if (pushes.length === 0) return;

  // Ескейпи перевіряємо тільки коли вже точно знаємо, що це push.
  let gatesOff = false;
  try { gatesOff = fs.existsSync(path.join(repoRoot(), '.claude', 'gates-off')); } catch { /* fail-open */ }
  if (gatesOff || isOff(process.env.PUSH_GATE)) {
    record({ rule: 'escape', decision: 'pass', why: gatesOff ? 'gates-off' : 'PUSH_GATE=off', session_id: sessionId });
    return;
  }

  const now = Date.now();
  let verdict = null;
  try {
    for (const args of pushes) {
      verdict = judgePush(args, cwd, now);
      if (verdict) break;
      if (Date.now() > deadline) break;     // бюджет вичерпано, далі не судимо
    }
  } catch {
    return;                                 // будь-яка внутрішня аварія = пропуск
  }

  if (!verdict) {
    record({ rule: 'approved', decision: 'pass', session_id: sessionId, branch: pushToBranch(pushes, cwd) });
    return;
  }

  record({
    rule: verdict.rule, decision: 'deny', why: verdict.why,
    branch: verdict.branch || null, session_id: sessionId,
  });
  process.stdout.write(JSON.stringify({
    hookSpecificOutput: {
      hookEventName: 'PreToolUse',
      permissionDecision: 'deny',
      permissionDecisionReason: denyText(verdict),
    },
  }));
}

/** Тільки для журналу: яку гілку ми щойно пропустили. Ніколи не кидає. */
function pushToBranch(pushes, cwd) {
  try {
    const args = pushes[0] || [];
    const positional = args.filter((a) => !a.startsWith('-'));
    const specs = positional.slice(1);
    if (specs.length === 0) return currentBranch(cwd);
    const r = parseRefspec(specs[0]);
    return r.dst === 'HEAD' ? currentBranch(cwd) : r.dst;
  } catch { return null; }
}

if (require.main === module) {
  try { main(); } catch { /* fail-open: аварія хука не сміє блокувати роботу */ }
}

module.exports = { splitSegments, tokenize, parsePushSegment, parseRefspec, judgePush, exeName };
