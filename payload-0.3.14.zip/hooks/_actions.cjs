// Журнал ТИХИХ дій, S2 спеки `specs/quiet-permissions/spec.md`.
//
// Навіщо він існує. Спека прибрала питання наперед майже звідусіль (16.8% дій
// зупиняли людину, лишилось 1.2%). Сама по собі ця тиша була б погіршенням:
// людина перестала б знати, що взагалі сталося. Контроль тому не зникає, а
// переїжджає з «підтвердь наперед» у «подивись постфактум», і цей файл це та
// частина, без якої переїзд перетворюється на мовчазний ризик.
//
// Що сюди потрапляє. РІВНО те, що раніше зупинило б людину питанням, і нічого
// більше: рішення приймає класифікатор (`_irreversible.cjs`, поле `journal`), а
// не цей модуль. Читання, збірка, `git status` і правка всередині своєї теки не
// потрапляють: підсумок, у який зсипають усе підряд, читати перестають.
//
// Де лежить. `channels/<id>/actions-pending.jsonl`, один рядок на дію. Файл
// живе рівно до кінця ходу: коли раннер дописує бульбашку відповіді, він
// забирає накопичене в `NNNN.actions.json` поруч із повідомленням і чистить
// pending. Тобто журнал завжди прикріплений до конкретної бульбашки, а не
// висить окремою стрічкою, якої ніхто не читає.
//
// НІКОЛИ НЕ КИДАЄ. Модуль викликається з PreToolUse-хука, а виняток у хуку
// блокує дію користувача. Будь-яка проблема тут мусить коштувати рівно втрачений
// рядок журналу, а не зупинений хід.
//
// Крос-платформа: чистий node, без шел-викликів, без хардкод-шляхів.
const fs = require('fs');
const path = require('path');

const FILE = 'actions-pending.jsonl';
const MAX_RAW = 400;      // сира команда в журналі, довше просто нема сенсу показувати
const MAX_ROWS = 200;     // запобіжник від ходу-марафону: більше в підсумок і не влізе

function channelsDir() {
  try {
    return require('./plan-state.cjs').CHANNELS_DIR;
  } catch {
    return path.join(path.resolve(__dirname, '..'), 'channels');
  }
}

function filePath(channel) {
  return path.join(channelsDir(), channel, FILE);
}

/**
 * record(channel, {level, text}, {tool, raw}) -> void
 * level: 'plain' спокійний рядок, 'attention' фарбується в підсумку.
 * Мовчки нічого не робить, якщо теки каналу нема: створювати теку-сироту лише
 * заради журналу не можна, інакше в реєстрі зʼявляться канали-привиди.
 */
function record(channel, journal, meta) {
  try {
    if (!channel || /[\\/]|\.\./.test(channel)) return;
    if (!journal || !journal.text) return;
    const dir = path.join(channelsDir(), channel);
    if (!fs.existsSync(dir)) return;
    const p = filePath(channel);

    // Запобіжник довжини: рахуємо дешево, лише коли файл уже помітний.
    try {
      if (fs.existsSync(p) && fs.statSync(p).size > 120 * 1024) {
        const kept = fs.readFileSync(p, 'utf8').split('\n').filter(Boolean).slice(-MAX_ROWS);
        fs.writeFileSync(p, kept.join('\n') + '\n');
      }
    } catch { /* не вдалось підрізати, пишемо далі */ }

    const rec = {
      at: new Date().toISOString(),
      level: journal.level === 'attention' ? 'attention' : 'plain',
      text: String(journal.text).slice(0, 300),
      tool: String((meta && meta.tool) || ''),
      raw: String((meta && meta.raw) || '').slice(0, MAX_RAW),
    };
    fs.appendFileSync(p, JSON.stringify(rec) + '\n');
  } catch { /* журнал не сміє ламати хід */ }
}

/** Забрати накопичене і почистити. Повертає масив записів (можливо порожній). */
function drain(channel) {
  try {
    const p = filePath(channel);
    if (!fs.existsSync(p)) return [];
    const rows = fs.readFileSync(p, 'utf8').split('\n').filter(Boolean)
      .map((l) => { try { return JSON.parse(l); } catch { return null; } })
      .filter(Boolean);
    try { fs.unlinkSync(p); } catch {}
    return rows;
  } catch {
    return [];
  }
}

module.exports = { record, drain, filePath, FILE };
