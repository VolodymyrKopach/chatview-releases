#!/usr/bin/env node
// Idempotently register the REFLECT capture hook (learn-capture.cjs) as a second
// UserPromptSubmit hook in .claude/settings.json. Run via Bash:
//   node tools/viz/chat/hooks/install-learn-hook.cjs
// Safe to run repeatedly — it only adds the entry if missing. Cross-platform.
const fs = require('fs');
const path = require('path');

const REPO = process.env.CLAUDE_PROJECT_DIR || path.resolve(__dirname, '../../../..');
const SETTINGS = path.join(REPO, '.claude', 'settings.json');
const CMD = 'node "${CLAUDE_PROJECT_DIR}/tools/viz/chat/hooks/learn-capture.cjs"';

let raw;
try { raw = fs.readFileSync(SETTINGS, 'utf8'); }
catch (e) { console.error('cannot read', SETTINGS, e.message); process.exit(1); }

let data;
try { data = JSON.parse(raw); }
catch (e) { console.error('settings.json is not valid JSON, refusing to touch it:', e.message); process.exit(1); }

data.hooks = data.hooks || {};
data.hooks.UserPromptSubmit = data.hooks.UserPromptSubmit || [{ hooks: [] }];
const group = data.hooks.UserPromptSubmit[0] = data.hooks.UserPromptSubmit[0] || { hooks: [] };
group.hooks = group.hooks || [];

const already = group.hooks.some(h => h && typeof h.command === 'string' && h.command.includes('learn-capture.cjs'));
if (already) { console.log('learn-capture hook already registered — nothing to do ✓'); process.exit(0); }

group.hooks.push({ type: 'command', command: CMD });
fs.writeFileSync(SETTINGS, JSON.stringify(data, null, 2) + '\n');
console.log('registered learn-capture.cjs in UserPromptSubmit ✓');
console.log('UserPromptSubmit hooks now:', group.hooks.map(h => (h.command || '').split('/').pop().replace(/"$/, '')).join(', '));
