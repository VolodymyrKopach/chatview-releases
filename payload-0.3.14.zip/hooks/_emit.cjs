// Shared append-only event emitter for the ChatView «Процеси» (Processes) panel.
// One JSON line per event -> channels/<channel>/events.jsonl. Written by the hooks
// (hook fires) and mirrored by runner.py (tool/agent steps). The UI tails it via
// GET /api/events. MUST NEVER throw: the hooks depend on it and a throw would block
// prompt submission. Cross-platform (Mac + Windows), no deps beyond plan-state.
const fs = require('fs');
const path = require('path');

let CHANNELS_DIR, boundChannel;
try {
  ({ CHANNELS_DIR, boundChannel } = require('./plan-state.cjs'));
} catch {
  CHANNELS_DIR = path.join(path.resolve(__dirname, '..'), 'channels');
  boundChannel = () => null;
}

const MAX_LINES = 500;              // keep the tail this short after a trim
const TRIM_AT_BYTES = 220 * 1024;   // only bother rewriting the file past this size

function eventsPath(channel) {
  return path.join(CHANNELS_DIR, channel, 'events.jsonl');
}

// Opportunistic rotation: rewrite to the last MAX_LINES only when the file grew big,
// so the common path stays a cheap O(1) append.
function _trimIfBig(p) {
  try {
    const st = fs.statSync(p);
    if (st.size < TRIM_AT_BYTES) return;
    const lines = fs.readFileSync(p, 'utf8').split('\n').filter(Boolean);
    if (lines.length <= MAX_LINES) return;
    fs.writeFileSync(p, lines.slice(-MAX_LINES).join('\n') + '\n');
  } catch {}
}

// emit(channel, {kind, name, phase, detail, ...extra}). kind: hook|tool|agent|turn.
// phase: fire|start|tick|done|error. No-op (never throws) on any failure or when the
// channel dir does not exist yet (we never create an orphan dir just to log).
function emit(channel, ev) {
  try {
    if (!channel || /[\\/]|\.\./.test(channel)) return;
    if (!fs.existsSync(path.join(CHANNELS_DIR, channel))) return;
    const rec = Object.assign({ ts: new Date().toISOString() }, ev || {});
    const p = eventsPath(channel);
    fs.appendFileSync(p, JSON.stringify(rec) + '\n');
    _trimIfBig(p);
  } catch {}
}

// Resolve the channel for a hook's session id (env CHATVIEW_CHANNEL wins, handled
// inside boundChannel). Returns null when there is no binding.
function channelFor(sessionId) {
  try { return boundChannel(sessionId) || null; } catch { return null; }
}

module.exports = { emit, channelFor, eventsPath };
