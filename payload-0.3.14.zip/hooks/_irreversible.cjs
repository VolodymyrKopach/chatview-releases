'use strict';
/**
 * _irreversible.cjs. Класифікатор: чи ця дія НЕЗВОРОТНА.
 *
 * Закриває К8 спеки `specs/no-terminal-for-user/spec.md`: «ТАМ ДЕ дія незворотна
 * або зачіпає систему поза застосунком СИСТЕМА МУСИТЬ вимагати окремого явного
 * підтвердження, відмінного від звичайного дозволу». Модуль чистий: жодних
 * мережевих викликів, жодного стану, лише розбір виклику інструмента. Точку
 * виклику тримає `hooks/perm-gate.cjs`.
 *
 * ═══ ДЕ САМЕ ПРОХОДИТЬ МЕЖА І ЧОМУ ═══════════════════════════════════════════
 *
 * Межа коштує дорого в ОБИДВА боки, і саме тому вона тут описана словами, а не
 * лише регулярками.
 *
 *   Занадто ШИРОКА межа: підтвердження вилазить на кожну другу дію, людина за
 *   день привчається клікати не читаючи, і тоді картка перестає бути захистом.
 *   Це не теоретичний ризик: рівно так помирають усі «ви впевнені?» діалоги.
 *
 *   Занадто ВУЗЬКА межа: людина втрачає файли, і повернути їх нема звідки.
 *
 * Тому НЕЗВОРОТНИМ вважається тільки те, чого сам застосунок ВЖЕ НЕ ЗМОЖЕ
 * повернути тією інформацією, яка в нього лишилась:
 *
 *   1. Знищення даних: rm, shred, truncate, dd, форматування, `find -delete`.
 *   2. Права адміністратора (sudo, doas, su): дія виходить за межі застосунку
 *      і міняє машину, за яку застосунок не відповідає.
 *   3. Перезапис ІСНУЮЧОГО файла ПОЗА текою застосунку, і будь-який запис у
 *      системну теку: старого вмісту в застосунку нема, повернути нічим.
 *   4. Відкидання роботи в git: reset --hard, clean, branch -D, stash drop.
 *   5. Публікація і надсилання назовні: git push, npm publish, curl з POST/PUT/
 *      DELETE/PATCH або з даними, scp, ssh, gh pr merge, deploy. Опубліковане і
 *      надіслане не відкликається, навіть якщо вилучити його наступною дією.
 *   6. Знесення встановленого: brew uninstall, npm uninstall, pip uninstall,
 *      apt purge, docker rmi. Разом із програмою зникають її дані.
 *   7. Системні налаштування поза застосунком: crontab -r, defaults, launchctl,
 *      chmod -R, chown.
 *   8. Руйнівний SQL: DROP TABLE, TRUNCATE TABLE, DELETE FROM.
 *
 * А ось що НАВМИСНО лишається ЗВОРОТНИМ, попри спокусу перестрахуватись:
 *
 *   • ВСТАНОВЛЕННЯ (brew install, npm i -g, pip install). Уся спека написана
 *     заради того, щоб людина клікнула «хочу оцю штуку» і штука зʼявилась без
 *     термінала. Якби встановлення вимагало окремого підтвердження, S6 зʼїв би
 *     головний сценарій спеки. Встановлене знімається знесенням, а знесення
 *     якраз незворотне і підтвердження вимагає.
 *   • Правка файлів УСЕРЕДИНІ теки застосунку (і репозиторію). Це щоденна
 *     робота, вона лишає слід у стрічці і живе під git. Зробити її незворотною
 *     означає показувати картку майже щоходу, тобто вбити її сигнальну цінність.
 *   • СТВОРЕННЯ нового файла будь-де: нічого не втрачено, файл можна видалити.
 *   • Звичайний `>` у шелі. Так, він затирає файл, але в реальних командах це
 *     майже завжди новий лог (`node x.js > work/run.log`), і тримати його в
 *     переліку означало б хибну тривогу щодня. Явне обнулення (`truncate`) у
 *     переліку є.
 *   • Читання будь-чого, git status/diff/pull, збірка, тести.
 *
 * ═══ FAIL-SAFE, ПРОТИЛЕЖНИЙ ЗАГАЛЬНОМУ ПРИНЦИПУ ГЕЙТА ════════════════════════
 *
 * Гейт дозволів загалом fail-OPEN: будь-яка внутрішня помилка = allow, бо
 * заклинити асистента гірше, ніж пропустити виклик. ТУТ НАВПАКИ для того, що ми
 * не змогли ПРОЧИТАТИ: битий виклик, порожня команда, виняток = вважаємо дію
 * незворотною і йдемо питати. Причина проста: якщо форми виклику не видно,
 * перевірити перелік критичного неможливо, а отже неможливо виконати обіцянку
 * «критичне питає завжди».
 *
 * ═══ ЩО ЗМІНИЛА СПЕКА specs/quiet-permissions (2026-08-14) ═══════════════════
 *
 * Раніше тут діяло ще й правило «не впізнав ІНСТРУМЕНТ = вважаю незворотним».
 * Замір 43576 реальних викликів за 7 тижнів показав, що воно коштує 114
 * спрацювань (0.3%) і жодне з них не було небезпечним: це браузерні
 * MCP-інструменти (navigate, screenshot, console) і аналітика. Натомість 76%
 * усіх питань давали три речі, у яких відкат насправді Є:
 *
 *   • 5460 «перезапис» (74.5% усіх питань), з них 95.2% під git, і 4875 це
 *     сусідній репозиторій того самого проєкту. `workspaceRoots()` знав один
 *     корінь, тому щоденна правка другого репо вважалась незворотною;
 *   • 408 `curl POST`, з них 389 на 127.0.0.1, тобто розмова з власним сервером;
 *   • 1038 `rm`, з них ЖОДНОГО за межі домашньої теки: 581 у робочій теці,
 *     345 у /tmp.
 *
 * Тому додано три джерела відкату, і кожне перевіряється, а не припускається:
 *
 *   1. GIT. Файл усередині робочої копії git має копію старого вмісту в самому
 *      git, отже перезапис зворотний. Перевірка йде вгору по дереву до `.git` і
 *      кешується по теці (гейт стоїть перед КОЖНОЮ дією, тому ціна має значення).
 *   2. ТИМЧАСОВА ТЕКА (/tmp, /private/tmp, TMPDIR, /var/folders). Те, що там
 *      лежить, система і сама зітре при перезавантаженні.
 *   3. ЛОКАЛЬНА МЕРЕЖА (127.0.0.1, localhost, 0.0.0.0, [::1]). Це не публікація:
 *      назовні нічого не вийшло.
 *
 * І «не знаю» більше НЕ означає «критично»: невідоме виконується тихо, але
 * лишає слід у підсумку під бульбашкою з позначкою `attention`. Захист від
 * помилки тут не в питанні наперед, а в тому, що людина бачить дію постфактум.
 *
 * ═══ ПОЛЕ journal ═══════════════════════════════════════════════════════════
 *
 * Вердикт тепер несе `journal`: або null, або {level, text}. Туди потрапляє РІВНО
 * те, що раніше зупинило б людину питанням, і нічого більше. Читання, збірка,
 * git status і правка всередині своєї теки не потрапляють: підсумок, у який
 * зсипають усе підряд, читати перестають так само швидко, як «ви впевнені?».
 * level: 'plain' спокійний рядок, 'attention' фарбується в підсумку.
 *
 * Крос-платформа: чистий node, без шел-викликів, без хардкод-шляхів.
 */

const fs = require('fs');
const os = require('os');
const path = require('path');

// ── Відповідь класифікатора ─────────────────────────────────────────────────
// irreversible: чи вимагати окреме підтвердження.
// known:        чи це знання (true) чи здогад (false).
// reason:       людське речення для картки, без жаргону і без коду помилки.
// match:        що саме спрацювало (у лог і в розкриття картки).
// journal:      null або {level:'plain'|'attention', text}. Що показати людині
//               ПІСЛЯ ходу. Заповнюється лише там, де раніше було б питання.
const R = (reason, match) => ({ irreversible: true, known: true, reason, match, journal: null });
const OK = (match) => ({ irreversible: false, known: true, reason: '', match: match || null, journal: null });
const FAILSAFE = (reason, match) => ({ irreversible: true, known: false, reason, match: match || null, journal: null });

// Тихо, але видно постфактум. Саме сюди переїхало те, що раніше зупиняло людину.
const QUIET = (match, text, level) => ({
  irreversible: false, known: true, reason: '', match,
  journal: { level: level || 'plain', text },
});

// Тихо, але чесно позначено, що це не знання, а «не впізнав».
const UNSURE = (match, text) => ({
  irreversible: false, known: false, reason: '', match,
  journal: { level: 'attention', text },
});

// ── Три джерела відкату ─────────────────────────────────────────────────────

// Тимчасові теки: те, що там лежить, система зітре і сама.
const TMP_ROOTS = (() => {
  const r = ['/tmp', '/private/tmp', '/var/folders', '/private/var/folders'];
  try { r.push(path.resolve(os.tmpdir())); } catch { /* лишаємось на списку вище */ }
  if (process.env.TMPDIR) { try { r.push(path.resolve(process.env.TMPDIR)); } catch {} }
  return [...new Set(r)];
})();

function isScratch(abs) {
  const p = String(abs);
  return TMP_ROOTS.some((r) => p === r || p.startsWith(r + path.sep));
}

// Робоча копія git. Кеш по ТЕЦІ, бо гейт стоїть перед кожною дією, а походів
// угору по дереву інакше було б стільки ж, скільки викликів.
const _gitCache = new Map();
function gitRootOf(abs) {
  let dir = path.dirname(String(abs));
  const seen = [];
  for (let i = 0; i < 64 && dir && dir !== path.dirname(dir); i += 1) {
    if (_gitCache.has(dir)) {
      const hit = _gitCache.get(dir);
      for (const s of seen) _gitCache.set(s, hit);
      return hit;
    }
    seen.push(dir);
    let found = false;
    try { found = fs.existsSync(path.join(dir, '.git')); } catch { found = false; }
    if (found) {
      for (const s of seen) _gitCache.set(s, dir);
      return dir;
    }
    dir = path.dirname(dir);
  }
  for (const s of seen) _gitCache.set(s, null);
  return null;
}

// Локальні адреси: звернення туди нічого назовні не публікує.
const LOCAL_HOST = /^(127\.0\.0\.1|localhost|0\.0\.0\.0|\[::1\]|::1)$/i;
function allUrlsLocal(cmd) {
  const urls = String(cmd).match(/https?:\/\/[^\s'"`;|)]+/gi) || [];
  if (!urls.length) return false;                 // не бачимо адреси = не обіцяємо
  return urls.every((u) => {
    try { return LOCAL_HOST.test(new URL(u).hostname); } catch { return false; }
  });
}

const UNKNOWN_REASON =
  'Застосунок не впізнав цю дію, тому про всяк випадок вважає її незворотною і питає.';

// ── Розбір командного рядка ─────────────────────────────────────────────────

// Ланки конвеєра і ланцюжка: `cd work && rm -rf build` це ДВІ дії, і руйнівною
// може бути друга. Розбір навмисно грубий: нам треба знайти небезпеку, а не
// побудувати правильне дерево шелу.
function segments(cmd) {
  return String(cmd).split(/&&|\|\||[;\n|]/).map((s) => s.trim()).filter(Boolean);
}

function tokens(seg) {
  return seg.split(/\s+/).map((t) => t.replace(/^["'`(]+|["'`)]+$/g, '')).filter(Boolean);
}

// Слова, після яких далі йде ІНША команда. Без них `xargs rm` і `sh -c "rm -rf x"`
// пройшли б повз перелік, а `git commit -m "прибрав rm з коду"` навпаки давав би
// хибну тривогу: там `rm` стоїть у тексті, а не в позиції команди.
const WRAPPERS = new Set([
  'sudo', 'doas', 'su', 'env', 'time', 'nohup', 'nice', 'xargs', 'command', 'exec',
  'sh', 'bash', 'zsh', 'then', 'do', 'else', '-c', '-exec', '-execdir', '&&', '{',
]);

const atCommandPosition = (toks, i) => i === 0 || WRAPPERS.has(toks[i - 1]);

// Видалення розбирається ЗА ЦІЛЛЮ, а не за самим фактом виклику: `rm -rf dist`
// у робочій копії і `rm -rf ~/Documents/архів` це різні події, і замір це довів
// (1038 викликів, з них 0 за межі домашньої теки). Решта руйнівних команд нижче
// лишається безумовною: `shred` і `dd` за 7 тижнів дали 1 спрацювання разом,
// тому розбір цілі там не окупається, а ціна помилки та сама.
const DELETE_VERBS = {
  rm: 'Видалив',
  rmdir: 'Видалив теку',
  unlink: 'Видалив файл',
  trash: 'Прибрав у смітник',
};

// 1. Команди, руйнівні самим фактом виклику.
const ALWAYS = {
  shred: 'Затирає файл так, що відновити його неможливо.',
  srm: 'Затирає файл без можливості відновлення.',
  truncate: 'Обнуляє вміст файла.',
  dd: 'Пише напряму в диск або файл поверх наявних даних.',
  newfs: 'Створює файлову систему поверх наявних даних.',
  fdisk: 'Переписує розмітку диска.',
  shutdown: 'Вимикає компʼютер.',
  reboot: 'Перезавантажує компʼютер.',
  halt: 'Зупиняє компʼютер.',
  chown: 'Міняє власника файлів у системі.',
  scp: 'Копіює файли на іншу машину.',
  ssh: 'Виконує команду на іншій машині, і застосунок не бачить, що саме там станеться.',
  sendmail: 'Надсилає лист. Надіслане не відкликається.',
  mail: 'Надсилає лист. Надіслане не відкликається.',
  sudo: 'Виконується з правами адміністратора і міняє систему поза застосунком.',
  doas: 'Виконується з правами адміністратора і міняє систему поза застосунком.',
  su: 'Перемикається на іншого користувача системи.',
};

const ADMIN = 'Виконується з правами адміністратора і міняє систему поза застосунком.';
const PUBLISH = 'Надсилає або публікує щось назовні. Надіслане назад не забирається.';
const UNINSTALL = 'Зносить встановлену програму разом з її даними.';
const DISCARD = 'Відкидає зроблену роботу. Повернути її застосунок не зможе.';
const SYSTEM = 'Міняє налаштування системи поза застосунком.';

// 2. Команди, небезпечні лише в певному режимі.
//    Правило отримує (args, has, sub, verb):
//      args — усе після імені команди;
//      has(x) — чи є таке слово будь-де далі. ТІЛЬКИ для ПРАПОРЦІВ (--hard, -R):
//               прапорець неможливо сплутати з текстом;
//      sub  — перше слово-НЕ-прапорець, тобто справжня підкоманда;
//      verb(...w) — чи є хтось із w серед перших трьох слів (для `gh pr merge`).
//    Чому так: `git commit -m "прибрав rm з інструкції"` містить слово `rm`, і
//    наївна перевірка has('rm') робила з нього незворотну дію. Підкоманда це
//    позиція, а не наявність слова.
const SUBCOMMANDS = {
  git: (a, has, sub) => (
    sub === 'push' ? [PUBLISH, 'git push']
      : sub === 'reset' && has('--hard') ? [DISCARD, 'git reset --hard']
      : sub === 'clean' ? [DISCARD, 'git clean']
      : sub === 'branch' && (has('-D') || has('--delete')) ? [DISCARD, 'git branch -D']
      : sub === 'stash' && (has('drop') || has('clear')) ? [DISCARD, 'git stash drop']
      : sub === 'filter-branch' ? [DISCARD, 'git filter-branch']
      : sub === 'rm' ? ['Видаляє файли з репозиторію.', 'git rm']
      : (sub === 'checkout' || sub === 'restore') && (has('--') || has('.')) ? [DISCARD, 'git checkout --']
      : null),
  brew: (a, has, sub) => (['uninstall', 'remove', 'rm', 'cleanup'].includes(sub)
    ? [UNINSTALL, 'brew ' + sub] : null),
  npm: (a, has, sub) => (['publish', 'unpublish'].includes(sub) ? [PUBLISH, 'npm ' + sub]
    : ['uninstall', 'remove', 'rm', 'prune'].includes(sub) ? [UNINSTALL, 'npm ' + sub] : null),
  pnpm: (a, has, sub) => (['remove', 'uninstall'].includes(sub) ? [UNINSTALL, 'pnpm remove'] : null),
  yarn: (a, has, sub) => (sub === 'remove' ? [UNINSTALL, 'yarn remove'] : null),
  pip: (a, has, sub) => (sub === 'uninstall' ? [UNINSTALL, 'pip uninstall'] : null),
  pip3: (a, has, sub) => (sub === 'uninstall' ? [UNINSTALL, 'pip uninstall'] : null),
  gem: (a, has, sub) => (sub === 'uninstall' ? [UNINSTALL, 'gem uninstall'] : null),
  cargo: (a, has, sub) => (sub === 'uninstall' ? [UNINSTALL, 'cargo uninstall'] : null),
  apt: (a, has, sub) => (['remove', 'purge', 'autoremove'].includes(sub) ? [UNINSTALL, 'apt ' + sub] : null),
  'apt-get': (a, has, sub) => (['remove', 'purge', 'autoremove'].includes(sub) ? [UNINSTALL, 'apt-get ' + sub] : null),
  dnf: (a, has, sub) => (['remove', 'erase'].includes(sub) ? [UNINSTALL, 'dnf ' + sub] : null),
  yum: (a, has, sub) => (['remove', 'erase'].includes(sub) ? [UNINSTALL, 'yum ' + sub] : null),
  docker: (a, has, sub, verb) => (sub === 'push' ? [PUBLISH, 'docker push']
    : ['rm', 'rmi'].includes(sub) || verb('prune')
      ? ['Зносить образи або томи разом з їхніми даними.', 'docker rm'] : null),
  kubectl: (a, has, sub) => (sub === 'delete' ? ['Видаляє обʼєкт у кластері.', 'kubectl delete'] : null),
  gh: (a, has, sub, verb) => (verb('merge', 'delete', 'close', 'create')
    ? [PUBLISH, 'gh ' + sub] : null),
  vercel: (a, has, sub, verb) => (verb('deploy', 'rm', 'remove') || has('--prod')
    ? [PUBLISH, 'vercel deploy'] : null),
  netlify: (a, has, sub, verb) => (verb('deploy') ? [PUBLISH, 'netlify deploy'] : null),
  aws: (a, has, sub, verb) => (verb('rm', 'delete', 'terminate')
    ? ['Видаляє дані у хмарі.', 'aws delete'] : null),
  crontab: (a, has) => (has('-r') ? [SYSTEM, 'crontab -r'] : null),
  defaults: (a, has, sub) => (['delete', 'write'].includes(sub) ? [SYSTEM, 'defaults ' + sub] : null),
  launchctl: (a, has, sub) => (['unload', 'remove', 'bootout', 'disable'].includes(sub)
    ? [SYSTEM, 'launchctl ' + sub] : null),
  csrutil: () => [SYSTEM, 'csrutil'],
  nvram: () => [SYSTEM, 'nvram'],
  systemsetup: () => [SYSTEM, 'systemsetup'],
  chmod: (a, has) => (has('-R') || has('--recursive') ? ['Міняє права на цілому дереві файлів.', 'chmod -R'] : null),
  rsync: (a, has) => (has('--delete') ? ['Синхронізує з видаленням: зайве в цілі буде стерте.', 'rsync --delete'] : null),
  diskutil: (a, has, sub) => (/^(erase|partition|reformat|zerodisk)/i.test(sub || '')
    ? ['Стирає диск.', 'diskutil ' + sub] : null),
  find: (a, has) => (has('-delete') ? ['Видаляє знайдені файли.', 'find -delete'] : null),
  // Локальність перевіряється по ЦІЛОМУ рядку, а не по аргументах цієї ланки:
  // адреса часто приїжджає зі змінної або з наступної ланки конвеєра, а нам
  // важливо одне питання, чи вийшло щось за межі цієї машини.
  curl: (a, has, sub, verb, raw) => (
    a.some((t, i) => /^-X$/.test(t) && /^(POST|PUT|DELETE|PATCH)$/i.test(a[i + 1] || ''))
      || a.some((t) => /^(-d|--data(-raw|-binary|-urlencode)?|-F|--form|-T|--upload-file)$/.test(t))
      ? (allUrlsLocal(raw) ? null : [PUBLISH, 'curl POST']) : null),
  wget: (a, has, sub, verb, raw) => (a.some((t) => /^(--post-data|--post-file|--method=(POST|PUT|DELETE))/i.test(t))
    ? (allUrlsLocal(raw) ? null : [PUBLISH, 'wget POST']) : null),
};

// Куди вказує видалення. Повертає 'safe' (є звідки повернути), 'unsafe' або
// 'unknown' (цілі не видно, наприклад `xargs rm` чи нерозгорнута змінна).
function deleteTargetVerdict(args) {
  const targets = args.filter((w) => !w.startsWith('-'));
  if (!targets.length) return 'unknown';
  for (const t of targets) {
    if (/[$`]/.test(t)) return 'unknown';           // нерозгорнута змінна
    if (t.startsWith('..')) return 'unsafe';        // вихід угору з робочої теки
    if (!path.isAbsolute(t) && !t.startsWith('~')) continue;  // відносний = робоча тека
    const abs = t.startsWith('~')
      ? path.join(os.homedir(), t.slice(1))
      : path.resolve(t);
    if (isScratch(abs)) continue;
    if (gitRootOf(abs)) continue;
    return 'unsafe';
  }
  return 'safe';
}

// 3. Фрази, які видно лише в цілому рядку (аргумент до psql/mysql тощо).
const PHRASES = [
  [/\bdrop\s+(table|database|schema)\b/i, 'Видаляє таблицю або базу разом з усіма даними.', 'DROP TABLE'],
  [/\btruncate\s+table\b/i, 'Спорожняє таблицю.', 'TRUNCATE TABLE'],
  [/\bdelete\s+from\b/i, 'Видаляє рядки з таблиці.', 'DELETE FROM'],
];

function classifyBash(command) {
  const raw = String(command);
  for (const [re, reason, match] of PHRASES) if (re.test(raw)) return R(reason, match);

  // Тихий, але вартий підсумку слід. Накопичуємо і віддаємо в кінці: критичне в
  // будь-якій ланці має пріоритет над тихим у сусідній.
  let quiet = null;

  for (const seg of segments(raw)) {
    const toks = tokens(seg);
    for (let i = 0; i < toks.length; i += 1) {
      const t = toks[i];
      if (!atCommandPosition(toks, i)) continue;
      const base = path.basename(t);
      if (Object.prototype.hasOwnProperty.call(ALWAYS, base)) return R(ALWAYS[base], base);
      if (/^mkfs/.test(base)) return R('Створює файлову систему поверх наявних даних.', base);

      if (Object.prototype.hasOwnProperty.call(DELETE_VERBS, base)) {
        const args = toks.slice(i + 1);
        const where = deleteTargetVerdict(args);
        if (where !== 'safe') {
          return R(where === 'unknown'
            ? 'Видаляє файли, і застосунок не бачить, які саме, тому не обіцяє відкату.'
            : 'Видаляє файли або теки. Повернути їхній вміст застосунок не зможе.', base);
        }
        // Ціль у робочій копії або в тимчасовій теці. Тихо, але в підсумку видно:
        // видалення це не та дія, про яку людина має дізнаватись випадково.
        quiet = QUIET(base, `${DELETE_VERBS[base]}: ${args.filter((w) => !w.startsWith('-')).join(', ')}`, 'attention');
        continue;
      }

      const rule = SUBCOMMANDS[base];
      if (rule) {
        const args = toks.slice(i + 1);
        const has = (w) => args.includes(w);
        const sub = args.find((w) => !w.startsWith('-')) || '';
        const verb = (...w) => args.slice(0, 3).some((x) => w.includes(x));
        let hit = null;
        try { hit = rule(args, has, sub, verb, raw); } catch { hit = null; }
        if (hit) return R(hit[0], hit[1]);
      }
      if (base === 'sudo' || base === 'doas') return R(ADMIN, base);
    }
    // `find . -name '*.tmp' -exec rm {} \;` — rm тут стоїть після -exec, тобто
    // вже в позиції команди, і його ловить перевірка вище. Окремої гілки не треба.
  }
  return quiet || OK('bash');
}

// ── Файлові інструменти ─────────────────────────────────────────────────────

// Теки, запис у які міняє машину, а не застосунок. `/var` і `/private` навмисно
// НЕ тут: на macOS там живе тимчасова тека, і половина нормальної роботи стала б
// «незворотною».
const SYSTEM_DIRS = ['/etc', '/system', '/library', '/usr', '/bin', '/sbin', '/opt', '/boot', '/dev'];

function workspaceRoots(env) {
  const roots = [];
  for (const v of [env.CHATVIEW_HOME, env.CHATVIEW_WORKSPACE, env.CLAUDE_PROJECT_DIR]) {
    if (v) roots.push(path.resolve(v));
  }
  roots.push(path.resolve(__dirname, '..', '..', '..', '..'));   // корінь репозиторію
  // Власна тека Claude Code (памʼять, налаштування, транскрипти). Це така сама
  // «своя тека», як CHATVIEW_HOME: замір знайшов 184 питання на запис у
  // ~/.claude/projects/<проєкт>/memory, тобто застосунок питав дозволу писати у
  // власне сховище.
  try { roots.push(path.join(os.homedir(), '.claude')); } catch { /* без домівки лишаємось на списку */ }
  return roots;
}

const inside = (p, root) => p === root || p.startsWith(root + path.sep);

function classifyFile(input, env) {
  const target = input.file_path || input.notebook_path || input.path || '';
  if (!target) return FAILSAFE(UNKNOWN_REASON, 'без шляху');
  const abs = path.resolve(String(target));
  const low = abs.toLowerCase();

  for (const d of SYSTEM_DIRS) {
    if (low === d || low.startsWith(d + '/')) {
      return R('Пише в системну теку, тобто міняє машину поза застосунком.', d);
    }
  }
  if (/\/library\/launch(agents|daemons)\//i.test(abs)) {
    return R(SYSTEM, 'LaunchAgents');
  }
  if (workspaceRoots(env).some((r) => inside(abs, r))) return OK('своя тека');

  let exists = false;
  try { exists = fs.existsSync(abs); } catch { exists = true; }   // не знаємо = вважаємо, що є
  if (!exists) return OK('новий файл');

  // Головна поправка спеки quiet-permissions. Файл під git має копію старого
  // вмісту в самому git, отже перезапис зворотний. Саме ця гілка давала 5460
  // питань за 7 тижнів, з них 4875 на сусідній репозиторій того самого проєкту.
  const repo = gitRootOf(abs);
  if (repo) {
    return QUIET('перезапис під git',
      `Змінив ${path.basename(abs)} у репозиторії ${path.basename(repo)}`, 'plain');
  }
  return R('Перезаписує наявний файл поза текою застосунку. Копії старого вмісту нема.', 'перезапис');
}

// ── MCP: судимо за назвою, бо змісту чужого інструмента ми не знаємо ────────

// Тільки ЗНИЩЕННЯ і відкликання прав. `publish`, `send`, `deploy`, `merge`
// звідси прибрані свідомо (спека quiet-permissions, розділ 3.1): сама лише назва
// не доводить, що інструмент щось випустив назовні, а ціна питання висока. Вони
// переїхали в MCP_NOTABLE, тобто виконуються тихо, але видно постфактум.
const MCP_DESTRUCTIVE = ['delete', 'remove', 'drop', 'purge', 'destroy', 'erase', 'wipe',
  'uninstall', 'revoke'];
const MCP_NOTABLE = ['publish', 'send', 'deploy', 'merge'];
const MCP_READONLY = ['get', 'list', 'search', 'find', 'read', 'show', 'view', 'describe',
  'fetch', 'query', 'resolve', 'download', 'overview', 'count', 'diagnostics', 'initial', 'onboarding'];
const MCP_WRITE = ['create', 'update', 'add', 'set', 'write', 'edit', 'insert', 'rename',
  'replace', 'start', 'stop', 'attach', 'upload', 'move', 'sync', 'comment', 'tag', 'filter', 'request'];

function classifyMcp(tool) {
  const name = tool.replace(/^mcp__[^_]+__/, '').toLowerCase();
  const service = (tool.match(/^mcp__([^_]+)__/) || [, 'сервіс'])[1];
  const words = name.split(/[^a-z]+/).filter(Boolean);
  if (words.some((w) => MCP_DESTRUCTIVE.includes(w))) {
    return R('Незворотно міняє дані в зовнішньому сервісі.', words.find((w) => MCP_DESTRUCTIVE.includes(w)));
  }
  if (words.some((w) => MCP_NOTABLE.includes(w))) {
    return QUIET('mcp ' + words.find((w) => MCP_NOTABLE.includes(w)),
      `Дія в сервісі ${service}: ${name.replace(/_/g, ' ')}`, 'attention');
  }
  if (words.some((w) => MCP_READONLY.includes(w))) return OK('читання');
  if (words.some((w) => MCP_WRITE.includes(w))) return OK('запис');
  // Невідомий MCP більше не питає. Замір: усі 114 таких спрацювань це браузер і
  // аналітика, тобто дивитись і ходити по сторінках, а не нищити дані.
  return UNSURE(tool, `Не впізнав дію: ${name.replace(/_/g, ' ')} у сервісі ${service}`);
}

// Інструменти, які нічого не міняють. Гейт їх зазвичай і не бачить, але модуль
// має бути самодостатнім для повторного використання.
const READ_TOOLS = new Set(['Read', 'Glob', 'Grep', 'LS', 'NotebookRead', 'TodoWrite',
  'WebFetch', 'WebSearch', 'BashOutput', 'Skill', 'ExitPlanMode']);
const FILE_TOOLS = new Set(['Write', 'Edit', 'MultiEdit', 'NotebookEdit']);

/**
 * classify(call, env) -> {irreversible, known, reason, match}
 * call = {tool_name, tool_input} рівно в тому вигляді, як його дає PreToolUse.
 * НІКОЛИ не кидає: будь-яка несподіванка це fail-safe у бік «питати».
 */
function classify(call, env) {
  try {
    const e = env || process.env;
    if (!call || typeof call !== 'object') return FAILSAFE(UNKNOWN_REASON, 'битий виклик');
    const tool = String(call.tool_name || '');
    const input = call.tool_input && typeof call.tool_input === 'object' ? call.tool_input : null;
    if (!tool) return FAILSAFE(UNKNOWN_REASON, 'без назви інструмента');

    if (READ_TOOLS.has(tool)) return OK(tool);
    if (tool === 'Bash') {
      if (!input || typeof input.command !== 'string' || !input.command.trim()) {
        return FAILSAFE('Застосунок не зміг прочитати команду, тому питає окремо.', 'порожня команда');
      }
      return classifyBash(input.command);
    }
    if (FILE_TOOLS.has(tool)) {
      if (!input) return FAILSAFE(UNKNOWN_REASON, 'без аргументів');
      return classifyFile(input, e);
    }
    if (/^mcp__/.test(tool)) return classifyMcp(tool);
    // Невідомий інструмент виконується, але лишає слід. Форму виклику ми тут
    // прочитали (назва є), отже перелік критичного перевірено і збігу нема.
    return UNSURE(tool, `Не впізнав дію: ${tool}`);
  } catch (err) {
    return FAILSAFE('Застосунок не зміг розібрати цю дію, тому питає окремо.', 'виняток');
  }
}

/** Коротке «що саме станеться» для картки підтвердження. */
function describe(call) {
  try {
    const tool = String((call && call.tool_name) || '');
    const input = (call && call.tool_input) || {};
    if (tool === 'Bash' && input.command) return String(input.command).trim();
    if (input.file_path || input.notebook_path) return String(input.file_path || input.notebook_path);
    return tool;
  } catch { return ''; }
}

module.exports = { classify, describe, segments, tokens };
