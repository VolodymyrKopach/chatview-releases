#!/usr/bin/env node
'use strict';
/**
 * helper-detect.cjs — Stop hook. Детектор кристалізації помічників.
 *
 * НАВІЩО. Підхід, який ми виконуємо втретє, щоразу вигадується заново: та сама
 * послідовність команд, ті самі граблі, той самий час. Помічник (helpers/<name>/)
 * закріплює її раз і назавжди, але ЗАПРОПОНУВАТИ це має система, а не памʼять
 * людини. Тут детермінований, офлайновий, миттєвий детектор: він лише ПОМІЧАЄ і
 * ПРОПОНУЄ. Жодного автостворення, жодного LLM-виклику всередині.
 *
 * ДВА ТРИГЕРИ, більше нема (свідомо):
 *   СТВОРИТИ — та сама процедура з 3+ кроків трапилась у ТРЬОХ РІЗНИХ ходах,
 *              і жоден наявний helpers/<name>/SKILL.md її не покриває.
 *   ОНОВИТИ  — у ході кликали помічника X, і поруч зробили крок, якого в
 *              helpers/X/SKILL.md нема. Це випадок «працюємо з помічником,
 *              треба щоб він це розумів».
 * ОНОВИТИ важливіший за СТВОРИТИ: він конкретніший, тож при збігу виграє.
 *
 * АНТИСПАМ (без нього фічу зненавидять за день):
 *   · максимум ОДНА пропозиція на годину на канал;
 *   · відхилена сигнатура (чіп «Не треба») не вертається НІКОЛИ
 *     (work/helper-dismissed.json);
 *   · сигнатура, яку вже покриває якийсь SKILL.md, вимітається з леджера;
 *   · шумні голови (cd/ls/grep/git/…) і наша власна чат-сантехніка
 *     (render-message.cjs, agent-run.cjs…) кроками не рахуються взагалі.
 *
 * БЕЗПЕКА СИГНАТУРИ. У леджер їде тільки ФОРМА команди: голова, до двох
 * «безпечних» позиційних токенів (короткий підкоманд-word або базове імʼя
 * скрипта) і ІМЕНА прапорців. Значення, шляхи, URL, heredoc-тіла зрізаються ДО
 * токенізації, тож секрет фізично не має куди протекти.
 *
 * КОНТРАКТ ХУКА: ЗАВЖДИ exit 0, ЗАВЖДИ порожній stdout, нічого в stderr при
 * нормальній роботі. Будь-який виняток = тихий вихід. Зламаний детектор не сміє
 * блокувати хід.
 *
 * CLI (те, що прив'язано до чіпів картки):
 *   node helper-detect.cjs --dismiss <id|сигнатура>   назавжди прибрати пропозицію
 *   node helper-detect.cjs --forget  <id|сигнатура>   прибрати з леджера (помічника зроблено)
 *   node helper-detect.cjs --list                     що назбиралось
 *
 * Ескейп: HELPER_DETECT=off. Крос-платформа: чистий node, без .sh і хардкодів.
 */

const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const { spawnSync } = require('child_process');

// ── шляхи ───────────────────────────────────────────────────────────────────
const HOOKS_DIR = __dirname;                                   // tools/viz/chat/hooks
const CHAT_DIR = path.resolve(HOOKS_DIR, '..');                // tools/viz/chat
const REPO_ROOT = process.env.HELPER_DETECT_ROOT || path.resolve(CHAT_DIR, '..', '..', '..');
const WORK_DIR = process.env.HELPER_DETECT_WORK || path.join(REPO_ROOT, 'work');
const HELPERS_DIR = process.env.HELPER_DETECT_HELPERS || path.join(REPO_ROOT, 'helpers');
const SIGNALS_PATH = path.join(WORK_DIR, 'helper-signals.json');
const DISMISSED_PATH = path.join(WORK_DIR, 'helper-dismissed.json');

// ── бюджети (транскрипт буває на десятки МБ) ────────────────────────────────
const TIME_BUDGET_MS = 1200;
const MAX_TAIL_BYTES = 2 * 1024 * 1024;
const MAX_LINES = 12000;

const MIN_PROCEDURE_STEPS = 3;   // «процедура» починається з трьох кроків
const CREATE_AT_TURNS = 3;       // спрацьовує рівно на третьому РІЗНОМУ ході
const COOLDOWN_MS = 60 * 60 * 1000;
const MAX_PROCEDURES = 200;      // леджер не росте нескінченно
const MAX_PROPOSALS = 60;

// ── шум: що ніколи не є «кроком процедури» ──────────────────────────────────
// Навігація, читання, текстова обробка і VCS. Вони супроводжують БУДЬ-ЯКУ
// роботу, тож як частина сигнатури лише зашумлюють її і плодять фальшиві збіги.
// git тут свідомо: коміт це універсальна сантехніка, її не кристалізують.
const NOISE_HEADS = new Set([
  'cd', 'ls', 'cat', 'echo', 'pwd', 'head', 'tail', 'sed', 'awk', 'grep', 'rg',
  'find', 'mkdir', 'rm', 'cp', 'mv', 'which', 'export', 'source', 'sleep', 'wc',
  'chmod', 'touch', 'printf', 'true', 'false', 'date', 'env', 'open', 'clear',
  'kill', 'pkill', 'ps', 'lsof', 'sort', 'uniq', 'xargs', 'tee', 'realpath',
  'basename', 'dirname', 'stat', 'du', 'df', 'nvm', 'set', 'unset', 'test',
  'file', 'git', 'diff', 'less', 'more', 'jq', 'sudo', 'time', 'wait', 'exit',
]);

// Наша власна чат-сантехніка: вона вже канон, помічник із неї не робиться.
const NOISE_SCRIPTS = new Set([
  'render-message.cjs', 'render-message.sh', 'set-plan.cjs', 'set-plan.sh',
  'update-message.cjs', 'channel.cjs', 'channel.sh', 'agent-run.cjs',
  'watch.cjs', 'job.cjs', 'learn.cjs', 'helper-detect.cjs', 'install-helpers.sh',
]);

// Позиційний токен потрапляє в сигнатуру ЛИШЕ якщо він або короткий
// підкоманд-word, або базове імʼя скрипта. Усе інше (значення, URL, ключі,
// довгі рядки) відкидається, тому секрет не має куди протекти.
const SAFE_WORD = /^[a-z][a-z0-9-]{0,15}$/;
const SCRIPT_NAME = /^[A-Za-z0-9._-]{1,40}\.(cjs|mjs|js|py|sh|ts|tsx|rb|go)$/;
const FLAG_NAME = /^--?[A-Za-z][A-Za-z0-9-]{0,20}$/;

// ── дрібні утиліти ──────────────────────────────────────────────────────────

function readJson(p, fallback) {
  try { return JSON.parse(fs.readFileSync(p, 'utf8')); } catch { return fallback; }
}

/** tmp + rename, як усі наші писачі стану. Сам ніколи не кидає назовні. */
function writeJsonAtomic(p, obj) {
  try {
    fs.mkdirSync(path.dirname(p), { recursive: true });
    const tmp = p + '.tmp';
    fs.writeFileSync(tmp, JSON.stringify(obj, null, 2));
    fs.renameSync(tmp, p);
    return true;
  } catch { return false; }
}

function sigId(sig) {
  return crypto.createHash('sha1').update(String(sig)).digest('hex').slice(0, 10);
}

/** Хвіст файлу як текст, з відкиданням обрізаного першого рядка. */
function readTail(file) {
  const st = fs.statSync(file);
  const start = Math.max(0, st.size - MAX_TAIL_BYTES);
  const len = st.size - start;
  const fd = fs.openSync(file, 'r');
  try {
    const buf = Buffer.allocUnsafe(len);
    fs.readSync(fd, buf, 0, len, start);
    let text = buf.toString('utf8');
    if (start > 0) {
      const nl = text.indexOf('\n');
      text = nl >= 0 ? text.slice(nl + 1) : '';
    }
    return text;
  } finally { try { fs.closeSync(fd); } catch { /* ignore */ } }
}

// ── нормалізація сигнатури команди ──────────────────────────────────────────

/**
 * Зрізає тіла heredoc ДО будь-якого розбору. Саме там їдуть промпти агентів,
 * ключі й багаторядковий текст, тобто головний канал витоку.
 */
function stripHeredocs(cmd) {
  return String(cmd || '').replace(/<<-?\s*(['"]?)([A-Za-z_][A-Za-z0-9_]*)\1[\s\S]*$/, '<<HEREDOC');
}

/** Розбиття на токени з повагою до лапок. Лапковані токени вважаються ЗНАЧЕННЯМИ. */
function tokenize(seg) {
  const out = [];
  let cur = '';
  let quoted = false;
  let q = '';
  for (let i = 0; i < seg.length; i++) {
    const c = seg[i];
    if (q) {
      if (c === q) { q = ''; } else { cur += c; }
      continue;
    }
    if (c === '"' || c === "'") { q = c; quoted = true; continue; }
    if (/\s/.test(c)) {
      if (cur) { out.push({ t: cur, quoted }); cur = ''; quoted = false; }
      continue;
    }
    cur += c;
  }
  if (cur) out.push({ t: cur, quoted });
  return out;
}

function baseName(p) {
  const s = String(p).replace(/\\/g, '/');
  const i = s.lastIndexOf('/');
  return (i >= 0 ? s.slice(i + 1) : s).replace(/\.exe$/i, '');
}

/**
 * Одна ланка конвеєра -> нормалізована сигнатура або ''.
 * Формат: "<голова> [позиційний] [позиційний] --прапорець --прапорець"
 * Значень, шляхів, URL і лапкованих аргументів у результаті немає за побудовою.
 */
function normalizeSegment(seg) {
  const toks = tokenize(seg);
  let i = 0;
  // Префікс присвоєнь оточення: FOO=bar node script.cjs
  while (i < toks.length && !toks[i].quoted && /^[A-Za-z_][A-Za-z0-9_]*=/.test(toks[i].t)) i++;
  if (i >= toks.length) return '';

  const head = baseName(toks[i].t).toLowerCase();
  if (!head || !/^[a-z][a-z0-9._+-]{0,23}$/.test(head)) return '';
  i++;

  const positionals = [];
  const flags = new Set();
  let afterBareFlag = false;                    // попередній токен був прапорцем без «=»
  for (; i < toks.length; i++) {
    const { t, quoted } = toks[i];
    if (!quoted && t.startsWith('-')) {
      const name = t.split('=')[0];
      if (FLAG_NAME.test(name)) flags.add(name);
      afterBareFlag = t.indexOf('=') === -1;
      continue;
    }
    // Шелл не каже, чи прапорець бере значення, тож консервативно пропускаємо
    // токен одразу після голого прапорця: інакше «--model large» лишає «large»,
    // тобто ЗНАЧЕННЯ, а сигнатура зобовʼязана містити лише форму.
    if (afterBareFlag) { afterBareFlag = false; continue; }
    if (quoted) continue;                       // лапковане = значення, ніколи не в сигнатуру
    if (positionals.length >= 2) continue;
    const looksPath = /[\\/]/.test(t);
    const b = baseName(t);
    if (SCRIPT_NAME.test(b)) { positionals.push(b); continue; }
    if (looksPath) continue;                    // шлях без скриптового розширення = значення
    if (SAFE_WORD.test(t)) positionals.push(t);
  }

  const parts = [head].concat(positionals);
  const f = Array.from(flags).sort();
  return (parts.join(' ') + (f.length ? ' ' + f.slice(0, 8).join(' ') : '')).trim();
}

/** Команда -> впорядкований список нормалізованих ланок (без шуму). */
function commandSteps(rawCmd) {
  const cmd = stripHeredocs(rawCmd);
  if (!cmd.trim()) return [];
  // Розділювачі конвеєра/послідовності. Лапки тут не розбираємо навмисно:
  // хибне розбиття всередині лапок дає лише сміттєву ланку, яку зріже фільтр.
  const segs = cmd.split(/\|\||&&|;|\||\n/).slice(0, 12);
  const steps = [];
  for (const s of segs) {
    const sig = normalizeSegment(s);
    if (!sig) continue;
    const head = sig.split(' ')[0];
    if (NOISE_HEADS.has(head)) continue;
    const script = sig.split(' ').find((t) => SCRIPT_NAME.test(t));
    if (script && NOISE_SCRIPTS.has(script)) continue;
    steps.push(sig);
  }
  return steps;
}

/**
 * «Голка» кроку для звірки з SKILL.md: базове імʼя скрипта, якщо є, інакше
 * голова плюс перший позиційний. Прапорці не беруться: помічник рідко перелічує
 * їх усі, а нам треба знати, чи він узагалі знає ЦЮ команду.
 */
function stepNeedle(step) {
  const toks = step.split(' ').filter((t) => !t.startsWith('-'));
  const script = toks.find((t) => SCRIPT_NAME.test(t));
  if (script) return script.toLowerCase();
  return toks.slice(0, 2).join(' ').toLowerCase();
}

// ── читання транскрипту завершеного ходу ────────────────────────────────────

function userText(o) {
  if (!o || o.type !== 'user') return '';
  if (o.toolUseResult) return '';
  if (o.isMeta) return '';
  const c = o.message && o.message.content;
  if (typeof c === 'string') return c;
  if (Array.isArray(c)) {
    let out = '';
    for (const b of c) {
      if (b && b.type === 'tool_result') return '';
      if (b && b.type === 'text' && typeof b.text === 'string') out += b.text + '\n';
    }
    return out;
  }
  return '';
}

/** Імʼя помічника зі шляху під helpers/<name>/ або .claude/skills/<name>/. */
function helperFromPath(p) {
  const s = String(p || '').replace(/\\/g, '/');
  let m = /(?:^|\/)helpers\/([A-Za-z0-9._-]+)(?:\/|$)/.exec(s);
  if (m) return m[1];
  m = /(?:^|\/)\.claude\/skills\/([A-Za-z0-9._-]+)(?:\/|$)/.exec(s);
  if (m) return m[1];
  return '';
}

/**
 * Один прохід по хвосту транскрипту -> що сталось у ЗАВЕРШЕНОМУ ході.
 * @returns {{turnKey:string, steps:string[], helpers:string[], skillFilesTouched:string[]}}
 */
function scanTurn(transcriptPath, sessionId, deadline) {
  const lines = readTail(transcriptPath).split('\n');
  const from = Math.max(0, lines.length - MAX_LINES);

  // Перший прохід шукає межу ходу: останній СПРАВЖНІЙ промпт користувача.
  let turnStart = from;
  let turnUuid = '';
  for (let i = from; i < lines.length; i++) {
    if ((i & 255) === 0 && Date.now() > deadline) throw new Error('time budget');
    const raw = lines[i];
    if (!raw || raw.indexOf('"user"') === -1) continue;
    let o; try { o = JSON.parse(raw); } catch { continue; }
    if (userText(o)) { turnStart = i; turnUuid = String(o.uuid || i); }
  }

  const steps = [];
  const helpers = [];
  const skillFilesTouched = [];
  const seenStep = new Set();

  for (let i = turnStart; i < lines.length; i++) {
    if ((i & 255) === 0 && Date.now() > deadline) throw new Error('time budget');
    const raw = lines[i];
    if (!raw || raw.indexOf('"tool_use"') === -1) continue;
    let o; try { o = JSON.parse(raw); } catch { continue; }
    const content = o && o.message && o.message.content;
    if (!Array.isArray(content)) continue;

    for (const b of content) {
      if (!b || b.type !== 'tool_use') continue;
      const name = String(b.name || '');
      const input = b.input || {};

      if (name === 'Skill') {
        const sk = String(input.skill || input.name || '').split(':').pop().trim();
        if (sk && !helpers.includes(sk)) helpers.push(sk);
        continue;
      }

      if (name === 'Bash' || name === 'BashOutput') {
        const cmd = String(input.command || '');
        const h = helperFromPath(cmd);
        if (h && !helpers.includes(h)) helpers.push(h);
        for (const s of commandSteps(cmd)) {
          if (seenStep.has(s)) continue;          // процедура = впорядковані УНІКАЛЬНІ кроки
          seenStep.add(s);
          steps.push(s);
        }
        continue;
      }

      if (name === 'Edit' || name === 'Write' || name === 'Read' ||
          name === 'MultiEdit' || name === 'NotebookEdit') {
        const f = input.file_path || input.notebook_path || '';
        const h = helperFromPath(f);
        if (h) {
          if (!helpers.includes(h)) helpers.push(h);
          const rel = String(f).replace(/\\/g, '/');
          if (!skillFilesTouched.includes(rel)) skillFilesTouched.push(rel);
        }
      }
    }
  }

  return {
    turnKey: sessionId + ':' + turnUuid,
    steps: steps.slice(0, 12),
    helpers,
    skillFilesTouched,
  };
}

// ── знання про наявних помічників ───────────────────────────────────────────

/** {name -> увесь текст SKILL.md у нижньому регістрі}. Порожньо при будь-якій біді. */
function loadSkills() {
  const out = {};
  let names = [];
  try {
    names = fs.readdirSync(HELPERS_DIR, { withFileTypes: true })
      .filter((d) => d.isDirectory()).map((d) => d.name);
  } catch { return out; }
  for (const n of names) {
    try {
      const t = fs.readFileSync(path.join(HELPERS_DIR, n, 'SKILL.md'), 'utf8');
      out[n] = t.toLowerCase();
    } catch { /* тека без SKILL.md просто не помічник */ }
  }
  return out;
}

/** Чи покриває якийсь наявний помічник УСІ кроки процедури. */
function coveredByAnySkill(steps, skills) {
  const needles = steps.map(stepNeedle).filter(Boolean);
  if (!needles.length) return '';
  for (const [name, text] of Object.entries(skills)) {
    if (needles.every((n) => text.includes(n))) return name;
  }
  return '';
}

// ── леджери ─────────────────────────────────────────────────────────────────

function loadSignals() {
  const s = readJson(SIGNALS_PATH, null);
  if (!s || typeof s !== 'object') return { version: 1, procedures: {}, proposals: {}, suggested: {} };
  s.procedures = s.procedures && typeof s.procedures === 'object' ? s.procedures : {};
  s.proposals = s.proposals && typeof s.proposals === 'object' ? s.proposals : {};
  s.suggested = s.suggested && typeof s.suggested === 'object' ? s.suggested : {};
  s.version = 1;
  return s;
}

function loadDismissed() {
  const d = readJson(DISMISSED_PATH, null);
  return (d && typeof d === 'object') ? d : {};
}

/** Найстаріші записи геть, щоб леджер не ріс нескінченно. */
function capMap(map, limit, tsKey) {
  const keys = Object.keys(map);
  if (keys.length <= limit) return map;
  keys.sort((a, b) => String(map[a] && map[a][tsKey] || '').localeCompare(String(map[b] && map[b][tsKey] || '')));
  for (const k of keys.slice(0, keys.length - limit)) delete map[k];
  return map;
}

// ── картка ──────────────────────────────────────────────────────────────────

/** ISO -> «05.08 22:59» локальним часом. Сирий ISO у картці читати незручно. */
function humanTs(iso) {
  const d = new Date(iso);
  if (isNaN(d.getTime())) return String(iso || '');
  const p = (n) => String(n).padStart(2, '0');
  return `${p(d.getDate())}.${p(d.getMonth() + 1)} ${p(d.getHours())}:${p(d.getMinutes())}`;
}

function buildCard(proposal) {
  const isUpdate = proposal.kind === 'update';
  const stepsText = proposal.steps.join('  →  ');

  const lead = isUpdate
    ? `Помітив: у цьому ході працювали з помічником **${proposal.helper}**, але зробили кроки, яких у його SKILL.md нема. Помічник про них не знає, тож наступного разу їх знову доведеться згадувати руками.`
    : `Помітив: ця процедура повторилась утретє, і жоден наявний помічник її не покриває. Втретє вигадувати її заново означає втретє наступити на ті самі граблі.`;

  // Процедура окремим блоком, а не рядком у key-values. Причина не смак: у
  // key-values колонки рівної ширини, тому найдовше значення на картці діставало
  // пʼяту частину рядка і ламалось посеред прапорця («- -noconfirm»). Саме воно
  // тут головний факт, тож воно й отримує повну ширину і моноширинний шрифт.
  const unknown = new Set(isUpdate ? proposal.unknown : []);
  const stepBlock = proposal.steps.length
    ? proposal.steps
        .map((s, i) => `${i + 1}. ${s}${unknown.has(s) ? '     ← нове для ' + proposal.helper : ''}`)
        .join('\n')
    : '(нема)';

  const items = [
    { k: 'Кроків', v: String(proposal.steps.length), color: 'blue' },
  ];
  if (isUpdate) {
    // «Нове для нього» окремим полем більше нема: на картці ОНОВИТИ невідомими
    // здебільшого є ВСІ кроки, тож поле дослівно повторювало блок над собою.
    // Тепер це позначка біля самого кроку, у місці, де на нього дивляться.
    items.push({ k: 'Помічник', v: proposal.helper, color: 'yellow' });
    items.push({ k: 'Нових для нього', v: String(proposal.unknown.length), color: 'yellow' });
  } else {
    items.push({ k: 'Разів у різних ходах', v: String(proposal.count), color: 'yellow' });
    items.push({ k: 'Уперше', v: humanTs(proposal.first) });
  }
  items.push({ k: 'Канали', v: proposal.channels.join(', ') || '(невідомо)' });
  items.push({ k: 'ID пропозиції', v: proposal.id, color: 'slate' });

  const dismissCmd = `node tools/viz/chat/hooks/helper-detect.cjs --dismiss ${proposal.id}`;
  const forgetCmd = `node tools/viz/chat/hooks/helper-detect.cjs --forget ${proposal.id}`;

  const chips = [
    {
      icon: '📦',
      label: 'Зберегти помічником',
      prompt: `Заверни цю процедуру в нового помічника через скіл pomichnyk-builder.\nКроки: ${stepsText}\nПісля того як помічник створено і встановлено, виконай: ${forgetCmd}`,
    },
    {
      icon: '🔧',
      label: `Оновити ${proposal.helper || 'помічника'}`,
      prompt: proposal.helper
        ? `Онови помічника ${proposal.helper}: додай у helpers/${proposal.helper}/SKILL.md ці кроки, щоб він їх розумів.\nКроки: ${stepsText}\nПотім перевстанови (bash scripts/install-helpers.sh) і виконай: ${forgetCmd}`
        : `Підбери, якого з наявних помічників (helpers/) варто оновити цією процедурою, і онови його SKILL.md.\nКроки: ${stepsText}\nПотім виконай: ${forgetCmd}`,
    },
    {
      icon: '🚫',
      label: 'Не треба',
      prompt: `Не треба помічника для цього. Виконай рівно одну команду і більше нічого: ${dismissCmd}`,
    },
  ];

  return [
    { type: 'text', text: lead },
    {
      type: 'code-block',
      title: 'Процедура',
      code: stepBlock,
      // Свідомо БЕЗ lang: у леджері лежить не команда, а її форма (голова,
      // безпечні позиційні, імена прапорців). Підсвітити її як bash означало б
      // обіцяти, що рядок можна скопіювати і запустити. Не можна.
      note: 'Форма команд, а не самі команди: значення, шляхи і лапковані '
        + 'аргументи зрізані до запису в леджер.',
    },
    { type: 'key-values', title: '🔍 Свідчення', items },
    { type: 'suggestions', title: 'Що робимо', chips },
  ];
}

/** Постить картку наявним шляхом (render-message.cjs). Ніколи не кидає. */
function postCard(channel, widgets) {
  const out = process.env.HELPER_DETECT_CARD_OUT;
  if (out) { writeJsonAtomic(out, widgets); return true; }   // тестовий режим: не постимо
  try {
    const r = spawnSync(process.execPath,
      [path.join(CHAT_DIR, 'render-message.cjs'), '-', 'Детектор помічників', 'помічник', channel],
      { input: JSON.stringify(widgets), encoding: 'utf8', timeout: 8000 });
    return !!r && r.status === 0;
  } catch { return false; }
}

// ── CLI ─────────────────────────────────────────────────────────────────────

/** id або сама сигнатура -> {sig, proposal} з леджера. */
function resolveRef(signals, ref) {
  const r = String(ref || '').trim();
  if (!r) return null;
  if (signals.proposals[r]) return { sig: signals.proposals[r].sig, proposal: signals.proposals[r] };
  for (const [id, p] of Object.entries(signals.proposals)) {
    if (p && p.sig === r) return { sig: p.sig, proposal: Object.assign({ id }, p) };
  }
  if (signals.procedures[r]) return { sig: r, proposal: null };
  return { sig: r, proposal: null };
}

function cliDismiss(ref) {
  const signals = loadSignals();
  const hit = resolveRef(signals, ref);
  if (!hit || !hit.sig) { console.log('helper-detect: не знайшов пропозицію ' + ref); return 0; }
  const dismissed = loadDismissed();
  dismissed[hit.sig] = {
    id: sigId(hit.sig),
    ts: new Date().toISOString(),
    kind: (hit.proposal && hit.proposal.kind) || 'unknown',
  };
  writeJsonAtomic(DISMISSED_PATH, dismissed);
  delete signals.procedures[hit.sig];
  for (const [id, p] of Object.entries(signals.proposals)) if (p && p.sig === hit.sig) delete signals.proposals[id];
  writeJsonAtomic(SIGNALS_PATH, signals);
  console.log('helper-detect: відхилено назавжди — ' + hit.sig);
  return 0;
}

function cliForget(ref) {
  const signals = loadSignals();
  const hit = resolveRef(signals, ref);
  if (!hit || !hit.sig) { console.log('helper-detect: не знайшов ' + ref); return 0; }
  delete signals.procedures[hit.sig];
  for (const [id, p] of Object.entries(signals.proposals)) if (p && p.sig === hit.sig) delete signals.proposals[id];
  writeJsonAtomic(SIGNALS_PATH, signals);
  console.log('helper-detect: прибрано з леджера — ' + hit.sig);
  return 0;
}

function cliList() {
  const signals = loadSignals();
  const dismissed = loadDismissed();
  const procs = Object.entries(signals.procedures);
  console.log(`helper-detect: ${procs.length} процедур(и) у леджері, ${Object.keys(dismissed).length} відхилено.`);
  procs.sort((a, b) => (b[1].count || 0) - (a[1].count || 0));
  for (const [sig, e] of procs.slice(0, 30)) {
    console.log(`  ${sigId(sig)}  ×${e.count || 0}  [${(e.channels || []).join(',')}]  ${sig}`);
  }
  return 0;
}

// ── ядро ────────────────────────────────────────────────────────────────────

function decide(turn, signals, dismissed, skills, channel, nowIso) {
  const now = Date.parse(nowIso);

  // Кулдаун на канал перевіряємо ПІСЛЯ запису в леджер (нижче), але рішення
  // про картку блокуємо тут: лічильники мусять рости навіть у тиші.
  const lastAt = Date.parse(signals.suggested[channel] || '') || 0;
  const cooling = now - lastAt < COOLDOWN_MS;

  // ── ОНОВИТИ (пріоритетний: конкретніший за створення) ─────────────────────
  for (const h of turn.helpers) {
    const text = skills[h];
    if (text == null) continue;                       // такого помічника нема
    const unknown = turn.steps.filter((s) => !text.includes(stepNeedle(s)));
    if (!unknown.length) continue;
    const sig = 'update:' + h + ':' + unknown.join(' ; ');
    if (dismissed[sig]) continue;
    if (cooling) return null;
    return {
      kind: 'update', sig, id: sigId(sig), helper: h,
      steps: turn.steps, unknown, count: 1, first: nowIso, channels: [channel],
    };
  }

  // ── СТВОРИТИ ──────────────────────────────────────────────────────────────
  if (turn.steps.length < MIN_PROCEDURE_STEPS) return null;
  const sig = 'proc:' + turn.steps.join(' ; ');
  if (dismissed[sig]) return null;

  const e = signals.procedures[sig];
  if (!e || (e.count || 0) < CREATE_AT_TURNS) return null;
  const covered = coveredByAnySkill(turn.steps, skills);
  if (covered) { delete signals.procedures[sig]; return null; }   // вже закріплено
  if (cooling) return null;

  return {
    kind: 'create', sig, id: sigId(sig), helper: '',
    steps: turn.steps, unknown: [],
    count: e.count, first: e.first || nowIso, channels: (e.channels || [channel]).slice(0, 5),
  };
}

/** Сигнатури, які вже покриває якийсь SKILL.md, з леджера геть. */
function sweepCovered(signals, skills) {
  for (const [sig, e] of Object.entries(signals.procedures)) {
    const steps = Array.isArray(e && e.steps) ? e.steps : [];
    if (!steps.length) continue;
    if (coveredByAnySkill(steps, skills)) delete signals.procedures[sig];
  }
}

function runHook(input) {
  const deadline = Date.now() + TIME_BUDGET_MS;
  if (input && input.stop_hook_active === true) return;          // антицикл, без роботи

  const off = String(process.env.HELPER_DETECT || '').toLowerCase();
  if (off === 'off' || off === '0' || off === 'false') return;

  const sessionId = String((input && input.session_id) || '');
  const transcriptPath = input && input.transcript_path;
  if (!transcriptPath || !fs.existsSync(transcriptPath)) return;

  const turn = scanTurn(transcriptPath, sessionId, deadline);
  if (!turn.steps.length && !turn.helpers.length) return;

  let channel = process.env.HELPER_DETECT_CHANNEL || '';
  if (!channel) {
    try { channel = require('./_emit.cjs').channelFor(sessionId) || ''; } catch { /* нема звʼязки */ }
  }
  if (!channel) return;                                          // нема куди постити

  const signals = loadSignals();
  const dismissed = loadDismissed();
  const skills = loadSkills();
  const nowIso = new Date().toISOString();

  // Помічника щойно створили/оновили -> покриті сигнатури більше не сигнали.
  if (turn.skillFilesTouched.length) sweepCovered(signals, skills);

  // Лічильник процедури: рахуємо РІЗНІ ходи, не повтори того самого.
  if (turn.steps.length >= MIN_PROCEDURE_STEPS) {
    const sig = 'proc:' + turn.steps.join(' ; ');
    if (!dismissed[sig]) {
      const e = signals.procedures[sig] || { count: 0, first: nowIso, last: nowIso, channels: [], turns: [], steps: turn.steps };
      if (!Array.isArray(e.turns)) e.turns = [];
      if (!e.turns.includes(turn.turnKey)) {
        e.turns.push(turn.turnKey);
        if (e.turns.length > 10) e.turns = e.turns.slice(-10);
        e.count = (e.count || 0) + 1;
        e.last = nowIso;
        e.steps = turn.steps;
        if (!Array.isArray(e.channels)) e.channels = [];
        if (!e.channels.includes(channel)) e.channels.push(channel);
        signals.procedures[sig] = e;
      }
    }
  }

  const proposal = decide(turn, signals, dismissed, skills, channel, nowIso);

  if (proposal) {
    const posted = postCard(channel, buildCard(proposal));
    if (posted) {
      signals.suggested[channel] = nowIso;
      signals.proposals[proposal.id] = {
        sig: proposal.sig, kind: proposal.kind, helper: proposal.helper,
        steps: proposal.steps, ts: nowIso, channel,
      };
      try {
        require('./_emit.cjs').emit(channel, {
          kind: 'hook', name: 'HelperDetect', phase: 'fire',
          detail: proposal.kind === 'update' ? `пропозиція оновити ${proposal.helper}` : 'пропозиція нового помічника',
        });
      } catch { /* косметика */ }
    }
  }

  capMap(signals.procedures, MAX_PROCEDURES, 'last');
  capMap(signals.proposals, MAX_PROPOSALS, 'ts');
  writeJsonAtomic(SIGNALS_PATH, signals);
}

// ── main ────────────────────────────────────────────────────────────────────

function main() {
  const argv = process.argv.slice(2);
  if (argv[0] === '--dismiss') return cliDismiss(argv[1]);
  if (argv[0] === '--forget') return cliForget(argv[1]);
  if (argv[0] === '--list') return cliList();

  let input = {};
  try { input = JSON.parse(fs.readFileSync(0, 'utf8')); } catch { input = {}; }
  runHook(input);
  return 0;
}

// Чисті функції відкриті юнітам. Експорт ПЕРЕД запуском: інакше require() цього
// файлу вбив би процес тесту на process.exit().
module.exports = { normalizeSegment, commandSteps, stepNeedle, sigId, stripHeredocs, buildCard };

if (require.main === module) {
  let code = 0;
  try { code = main(); } catch { code = 0; }      // FAIL-SILENT, завжди
  process.exit(code || 0);
}
