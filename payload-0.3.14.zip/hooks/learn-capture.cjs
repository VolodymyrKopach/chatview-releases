#!/usr/bin/env node
// UserPromptSubmit hook — CAPTURE stage of the REFLECT self-learning loop.
// When THIS prompt looks like a correction / an explicit "remember this", it appends
// the signal (plus a hint of what I said right before) to memory/_learn/inbox.jsonl,
// so the lesson is never lost. On every turn where signals are still pending, it
// injects a nag into context so I distill them before finishing — the exact failure
// mode this kills is "agent forgets to write the lesson".
//
// Deterministic, 0 LLM, fast, SILENT when there is nothing to say. Registered second
// in .claude/settings.json UserPromptSubmit (after chat-view-reminder). Like every
// hook here it MUST NEVER throw / never exit non-zero.
const fs = require('fs');

let input = {};
try { input = JSON.parse(fs.readFileSync(0, 'utf8')); } catch {}
const prompt = input && input.prompt ? String(input.prompt) : '';
const sessionId = input && input.session_id ? String(input.session_id) : '';
const transcriptPath = input && input.transcript_path ? String(input.transcript_path) : '';

let store = null;
try { store = require('./_learn-store.cjs'); } catch {}

// --- correction / explicit-save detector (UA + EN) -------------------------------
// PRECISION over recall by design. This runs in a GENERAL assistant (business, copy,
// strategy), where bare one-shot content edits ("ні, переробимо слайд", "не туди")
// are ~90% about the DELIVERABLE, not about HOW I work — capturing those floods the
// inbox with junk and nags forever. So we only fire on markers of RECURRENCE / a
// standing RULE ("я ж казав", "скільки разів", "завжди роби Х", "більше так не") or an
// EXPLICIT "remember this". A genuinely durable lesson gets restated in these words
// and is caught then; a true one-off would have been dropped in DISTILL anyway.
// (JS `\b` is ASCII-only and silently fails on Cyrillic, so we never rely on it here.)
const MARKERS = [
  // EXPLICIT — "remember / make this a rule / from now on always|never / for the future"
  { kind: 'explicit', re: /запам'?ята|запамʼята|це в пам'?ять|це в памʼять|додай урок|запиши(?: це)? (?:в пам|правило)|нове правило|більше (?:так |цього )?не (?:роби|повторюй)|надалі (?:завжди|ніколи)|на майбутнє (?:запам|врахуй)|врахуй на майбутнє|remember this|make (?:it )?a rule|note to self|for future reference/iu },
  // RECURRENCE reproach — "I (already) told you / how many times / you (did it) again"
  { kind: 'correction', re: /я ж (?:тобі )?(?:казав|казала|просив|просила|говорив|говорила|пояснював|пояснювала)|(?:казав|казала) ж(?:е)?|скільки разів(?: тобі| вже)? (?:казати|повторювати)|ти знову (?:забув|не |зробив не)|знову (?:ти |)(?:забув|не так)|i told you|how many times/iu },
  // DIRECTIVE about recurring behavior — "always|never|constantly + a working verb"
  { kind: 'correction', re: new RegExp('(?:завжди|ніколи|постійно)\\s+(?:ти\\s+)?(?:роби|пиши|став|додавай|використовуй|кажи|давай|показуй|роз|не\\s+(?:роби|став|пиши|давай|додавай|забувай))', 'iu') },
  // HABIT reminders aimed at ME — "don't forget / stop doing / you constantly …"
  { kind: 'correction', re: /не забувай(?:те)?|перестань|припини|ти (?:постійно|завжди|знову) (?:забува|робиш|ставиш|пишеш|ігноруєш)|always (?:do|use|write|put|add|say|remember)|never (?:do|use|write|forget)|stop (?:doing|forgetting)|don'?t forget/iu },
];

function detect(text) {
  for (const m of MARKERS) { if (m.re.test(text)) return m; }
  return null;
}

// Best-effort: pull the last assistant text out of the transcript so DISTILL knows
// WHAT was being corrected. Transcript is JSONL; shapes vary across versions, so we
// scan defensively for the last assistant-role text and never fail the hook.
function lastAssistantHint(p) {
  if (!p) return '';
  try {
    const lines = fs.readFileSync(p, 'utf8').split('\n').filter(Boolean);
    for (let i = lines.length - 1; i >= 0; i--) {
      let o; try { o = JSON.parse(lines[i]); } catch { continue; }
      const msg = o && (o.message || o);
      const role = msg && (msg.role || o.role);
      if (role !== 'assistant') continue;
      let text = '';
      const c = msg && msg.content;
      if (typeof c === 'string') text = c;
      else if (Array.isArray(c)) text = c.filter(x => x && x.type === 'text').map(x => x.text).join(' ');
      text = (text || '').replace(/\s+/g, ' ').trim();
      if (text) return text.slice(0, 240);
    }
  } catch {}
  return '';
}

const out = [];

if (store) {
  const hit = prompt ? detect(prompt) : null;
  if (hit) {
    store.append({
      kind: hit.kind,
      marker: hit.re.source.slice(0, 60),
      signal: prompt.replace(/\s+/g, ' ').trim().slice(0, 600),
      prior_hint: lastAssistantHint(transcriptPath),
      session_id: sessionId,
    });
  }

  // Nag while anything is pending (self-silences the moment I resolve them).
  let pend = [];
  try { pend = store.pending(); } catch {}
  if (pend.length) {
    out.push([
      `━━ 📚 SELF-LEARN (REFLECT) — ${pend.length} сигнал(ів) чекають дистиляції ━━`,
      hit ? '↳ Цей хід зафіксовано новий сигнал-урок (правка/«запамʼятай»).' : '↳ У черзі лишились незакриті сигнали з попередніх ходів.',
      'BEFORE finishing this turn (at a natural break, not mid-edit): distill the inbox into memory.',
      'Follow memory/_learn/DISTILL.md — list → classify (error/preference/one-off) → atomic rule → grep-dedup vs MEMORY.md → write/update memory file → resolve.',
      'List them: node tools/viz/chat/hooks/learn.cjs list   ·   Close them: node tools/viz/chat/hooks/learn.cjs resolve <id...> --distilled|--merged|--dropped',
      'Not distilling when signals are pending = the exact bug this loop exists to kill. Do it, do not defer.',
    ].join('\n'));
  }
}

// Cosmetic «Процеси»-panel event; optional, never blocks.
try {
  const { emit, channelFor } = require('./_emit.cjs');
  const ch = channelFor(sessionId);
  const st = store ? store.stats() : { pending: 0 };
  emit(ch, { kind: 'hook', name: 'SelfLearn', phase: 'fire',
    detail: st.pending ? `${st.pending} урок(ів) у черзі` : 'сигналів нема' });
} catch {}

if (out.length) process.stdout.write(out.join('\n\n') + '\n');
