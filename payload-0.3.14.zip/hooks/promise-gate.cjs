#!/usr/bin/env node
/**
 * promise-gate.cjs — Stop hook. Обіцянка повернутись мусить мати живий слід.
 *
 * specs/agent-owner-channel, К7: «КОЛИ у відповіді дано обіцянку повернутись із
 * результатом СИСТЕМА МУСИТЬ мати за нею живий слід: агента, вартового або job у
 * ЦЬОМУ ж каналі, інакше обіцянка нічим не підкріплена».
 *
 * ПРИВІД. Найдорожча поломка цієї підсистеми не технічна, а обіцянкова. У відповіді
 * стоїть «запустив, повернусь із результатом», Vova закриває питання і чекає, а за
 * обіцянкою немає нічого: ані агента, ані вартового, ані job. Так уже було, і саме
 * тому зʼявився scripts/watch.cjs: вартовий на вільний слот пішов у фоновий Bash
 * мого ходу, хід закінчився, вартовий помер разом з ним, і про це не дізнався б
 * ніхто, бо в реєстрі його не існувало взагалі.
 *
 * ЧОМУ ХУК, А НЕ ПРАВИЛО ПРОЗОЮ. Прозою це виконується ймовірнісно і забувається
 * саме тоді, коли найдорожче: під кінець довгої сесії. Хуком воно спрацьовує
 * детерміновано. Той самий аргумент, що й у proof-gate.cjs.
 *
 * ЩО САМЕ ВВАЖАЄТЬСЯ СЛІДОМ (і чому саме це):
 *   • jobs/<id>.json зі станом running|queued|starting І channel === нашого каналу
 *     (сюди потрапляють і агенти містка, і вартові, і прості команди);
 *   • channels/<канал>/agents/<id>/status.json у тому ж стані.
 * Обидва реєстри читаються З ДИСКУ, а не через HTTP: хук мусить судити навіть тоді,
 * коли сервер ChatView лежить, інакше він мовчав би саме в найгіршій ситуації.
 *
 * ЧОМУ СЛІД У ЧУЖОМУ КАНАЛІ НЕ РАХУЄТЬСЯ. Обіцянка дана в цьому чаті, і чекають на
 * неї тут. Робота, що звітує в інший канал, для цього чату не існує; рівно ця
 * помилка й описана в спеці (агент c591fe пішов у `main` замість `chat-167`).
 *
 * КОНТРАКТ ХУКА (звірено з proof-gate.cjs, той самий подієвий тип):
 *   stdin : { session_id, transcript_path, hook_event_name:"Stop",
 *             stop_hook_active, last_assistant_message, ... }
 *   вихід : блок = exit 0 + stdout {"decision":"block","reason":"..."}.
 *           пропуск = exit 0 + порожній stdout.
 *   loop  : stop_hook_active === true → миттєвий пропуск, другого блоку не буває.
 *
 * FAIL-OPEN. Будь-яка внутрішня помилка, брак файлу, битий JSON = ТИХИЙ ПРОПУСК
 * (exit 0, порожній stdout). Хук, що ламається, не сміє паралізувати роботу.
 *
 * ЕСКЕЙПИ:
 *   PROMISE_GATE=off          повністю вимикає
 *   [skip-promise] у тексті   разовий пропуск
 *
 * Крос-платформа: чистий node, без .sh і хардкод-шляхів.
 */
'use strict';

const fs = require('fs');
const path = require('path');

// CHATVIEW_HOME задає паковану збірку; у дев-запуску це сама тека chat. Та сама
// одна відповідь на питання «де мої дані», що й у server.py.
const CHAT_DIR = process.env.CHATVIEW_HOME || path.resolve(__dirname, '..');
const CHANNELS_DIR = path.join(CHAT_DIR, 'channels');
const JOBS_DIR = path.join(CHAT_DIR, 'jobs');
const LIVE_STATES = new Set(['running', 'queued', 'starting']);

// ── ЩО Є ОБІЦЯНКОЮ ──────────────────────────────────────────────────────────
//
// Свідомо ВУЗЬКИЙ список: хибний блок коштує дорожче за пропущену обіцянку, бо
// зупиняє здачу готової роботи. Тому ловимо лише першу особу майбутнього про
// РЕЗУЛЬТАТ, а не будь-яку згадку слова «повернутись».
//
// Морфологія тут робить половину роботи: «повернусь» ловиться, «повернувся»
// (минуле) і «повернутись» (чужа дія, інфінітив) не ловляться, бо межа слова
// стоїть одразу після закінчення.
// Межі слова тут НЕ \b. У JavaScript \b означає межу класу [A-Za-z0-9_], тобто для
// кирилиці її просто не існує: /\bповернусь\b/ не збігається з «повернусь» ніколи.
// Спіймано першим же прогоном тесту, де хук мовчав на очевидній обіцянці. Тому межа
// будується явно через юнікодні властивості.
const NB = '(?<![\\p{L}\\p{N}])';
const NA = '(?![\\p{L}\\p{N}])';
const w = (body) => NB + '(?:' + body + ')' + NA;
const rx = (body) => new RegExp(body, 'iu');

const PROMISE_PATTERNS = [
  rx(w('поверну(сь|ся)')),
  rx(w('доповім|повідомлю|відзвітую|відпишу')),
  rx(w('дам знати')),
  rx(w('тримаю (тебе )?в курсі')),
  rx(w('простежу|постежу|стежу за|моніторю|буду моніторити')),
  // «як тільки завершиться, напишу» і дзеркальне «напишу, щойно завершиться».
  rx(w('як|коли|щойно|тільки') + '[^.!?]{0,60}' + w('напишу|скажу|покажу|принесу|кину')),
  rx(w('напишу|скажу|покажу|принесу|кину') + '[^.!?]{0,60}' + w('як|коли|щойно|тільки')),
  rx("(i'?ll (report back|let you know|update you|come back)|will let you know)"),
];

function isPromise(text) {
  return PROMISE_PATTERNS.some((re) => re.test(text));
}

// ── ДЕ МИ ───────────────────────────────────────────────────────────────────

/** Канал цього ходу. Раннер пінить його env-змінною; у сесії Claude Code звʼязок
 *  живе в мапі сесій. Немає ні того, ні того = судити нема про що. */
function channelOf(sessionId) {
  if (process.env.CHATVIEW_CHANNEL) return process.env.CHATVIEW_CHANNEL;
  if (!sessionId) return '';
  try {
    const map = JSON.parse(fs.readFileSync(path.join(CHANNELS_DIR, '.cc-sessions.json'), 'utf8'));
    return (map && map[sessionId]) || '';
  } catch {
    return '';
  }
}

// ── ЧИ Є ЖИВИЙ СЛІД ─────────────────────────────────────────────────────────

function readJson(p) {
  try {
    return JSON.parse(fs.readFileSync(p, 'utf8'));
  } catch {
    return null;                       // битий сусід не має права загасити пошук
  }
}

function liveJob(channel) {
  let names = [];
  try {
    names = fs.readdirSync(JOBS_DIR).filter((n) => n.endsWith('.json'));
  } catch {
    return null;
  }
  for (const n of names) {
    const j = readJson(path.join(JOBS_DIR, n));
    if (j && j.channel === channel && LIVE_STATES.has(String(j.state))) {
      return { kind: 'job', label: j.label || j.jobId || n };
    }
  }
  return null;
}

function liveAgent(channel) {
  const root = path.join(CHANNELS_DIR, channel, 'agents');
  let dirs = [];
  try {
    dirs = fs.readdirSync(root, { withFileTypes: true }).filter((d) => d.isDirectory()).map((d) => d.name);
  } catch {
    return null;
  }
  for (const d of dirs) {
    const st = readJson(path.join(root, d, 'status.json'));
    if (st && LIVE_STATES.has(String(st.state))) {
      return { kind: 'agent', label: st.label || st.agentId || d };
    }
  }
  return null;
}

const liveTrace = (channel) => liveJob(channel) || liveAgent(channel);

// ── ЛІЧИЛЬНИК ───────────────────────────────────────────────────────────────
// Той самий файл, що й у proof-gate: наприкінці тижня видно, скільки разів гейти
// спрацювали і на чому.
function record(row) {
  try {
    const { repoRoot } = require('./_scope.cjs');
    const p = path.join(repoRoot(), '.claude', 'gates.jsonl');
    fs.mkdirSync(path.dirname(p), { recursive: true });
    fs.appendFileSync(p, JSON.stringify({ gate: 'promise', when: new Date().toISOString(), ...row }) + '\n');
  } catch {}
}

// ── ТЕКСТ ВІДПОВІДІ ─────────────────────────────────────────────────────────

/** Останнє повідомлення асистента. Приходить у stdin; якщо ні, дочитуємо хвіст
 *  транскрипту. Не знайшли текст = мовчимо (судити нема про що). */
function assistantText(input) {
  const direct = input && input.last_assistant_message;
  if (typeof direct === 'string' && direct.trim()) return direct;
  const tp = input && input.transcript_path;
  if (!tp) return '';
  let lines = [];
  try {
    lines = fs.readFileSync(tp, 'utf8').split('\n').filter(Boolean);
  } catch {
    return '';
  }
  for (let i = lines.length - 1; i >= 0 && i > lines.length - 60; i -= 1) {
    let row = null;
    try { row = JSON.parse(lines[i]); } catch { continue; }
    const msg = row && row.message;
    if (!msg || msg.role !== 'assistant') continue;
    const content = Array.isArray(msg.content) ? msg.content : [];
    const text = content.filter((c) => c && c.type === 'text').map((c) => c.text).join('\n');
    if (text.trim()) return text;
  }
  return '';
}

const REASON = (channel) => [
  'У відповіді є обіцянка повернутись із результатом, але за нею немає живого сліду в цьому чаті',
  `(${channel}): ані агента, ані вартового, ані job.`,
  '',
  'Два виходи, обидва законні:',
  '1) Постав справжній слід, і обіцянка стане підкріпленою:',
  '   • агент  → node scripts/agent-run.cjs --channel ' + channel + ' --label "…" --spec … --task -',
  '   • очікування чогось → node scripts/watch.cjs --channel ' + channel + ' --until \'<перевірка>\' -- <дія>',
  '   • просто видима команда → node scripts/job.cjs --channel ' + channel + ' -- <команда>',
  '2) Прибери обіцянку: переформулюй у те, що вже сталось, або скажи прямо, що робота',
  '   не запущена і чекає слова.',
  '',
  'Причина правила: обіцянка без сліду виглядає як робота, якої немає. Людина закриває',
  'питання і чекає результату, якого ніхто не готує.',
  'Ескейпи: PROMISE_GATE=off або маркер [skip-promise] у тексті.',
].join('\n');

// ── ХІД ─────────────────────────────────────────────────────────────────────

function main(raw) {
  if ((process.env.PROMISE_GATE || '').toLowerCase() === 'off') return;

  let input = null;
  try { input = JSON.parse(raw); } catch { return; }
  if (!input) return;
  if (input.stop_hook_active === true) {
    record({ decision: 'skip', why: 'stop_hook_active' });
    return;
  }

  const text = assistantText(input);
  if (!text || /\[skip-promise\]/i.test(text)) return;
  if (!isPromise(text)) return;

  const channel = channelOf(input.session_id ? String(input.session_id) : '');
  if (!channel) {
    // Каналу не знаємо, отже не знаємо і де шукати слід. Блокувати наосліп означало б
    // карати за те, чого не перевірили.
    record({ decision: 'skip', why: 'no-channel' });
    return;
  }

  const trace = liveTrace(channel);
  if (trace) {
    record({ decision: 'pass', channel, trace: trace.kind, label: trace.label });
    return;
  }

  record({ decision: 'block', channel });
  process.stdout.write(JSON.stringify({ decision: 'block', reason: REASON(channel) }));
}

let buf = '';
process.stdin.on('data', (c) => { buf += c; });
process.stdin.on('end', () => {
  try { main(buf); } catch {}      // fail-open: аварія хука нічого не блокує
  process.exit(0);
});
process.stdin.on('error', () => process.exit(0));
