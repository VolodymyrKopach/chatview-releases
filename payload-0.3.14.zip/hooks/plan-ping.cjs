#!/usr/bin/env node
// PostToolUse hook (cross-platform). The "periodic self-ping" Vova asked for:
// during long autonomous work, nudge me to reconcile the plan so EVERYTHING I do
// stays tied to it — but smartly, without overloading.
//
// Mechanism: count "work" tool calls since the plan was last written. The moment
// the active plan's plan.json is updated, the counter auto-resets (detected via
// mtime), so the hook goes quiet as soon as I reconcile. It only speaks up after
// PING_EVERY actions WITHOUT a plan update.
//
// Output contract (confirmed): exit 0 + JSON {"additionalContext": "..."} injects
// text the model reads. NEVER exit non-zero (that would block the tool result).

const fs = require('fs');
const os = require('os');
const path = require('path');
const crypto = require('crypto');

const PING_EVERY = 8;            // actions-without-plan-update before a ping
const SILENT = () => process.exit(0);

function readInput() {
  try { return JSON.parse(fs.readFileSync(0, 'utf8')); } catch { return {}; }
}

let mod;
try { mod = require('./plan-state.cjs'); } catch { SILENT(); }

const input = readInput();
const tool = input && input.tool_name ? String(input.tool_name) : '';

// Don't let plan/todo bookkeeping count as "work" (avoid pinging right after I sync).
const META_TOOLS = new Set(['TodoWrite', 'ToolSearch']);
const isPlanWrite = tool === 'Bash'
  && input.tool_input && typeof input.tool_input.command === 'string'
  && /set-plan|channels\/[^/]+\/plan\.json/.test(input.tool_input.command);

let plan = null;
try { plan = mod.inspectActivePlan(); } catch {}
const planMtime = plan ? plan.planMtime : 0;

// State file in tmp (per chat dir). Resets across reboots — fine.
const key = crypto.createHash('md5').update(mod.CHAT_DIR).digest('hex').slice(0, 10);
const stateFile = path.join(os.tmpdir(), `cv-plan-ping-${key}.json`);

let state = { count: 0, lastPlanMtime: 0 };
try { state = JSON.parse(fs.readFileSync(stateFile, 'utf8')); } catch {}

function save() { try { fs.writeFileSync(stateFile, JSON.stringify(state)); } catch {} }

// Plan was updated since we last looked → reset and stay quiet.
if (planMtime > state.lastPlanMtime) {
  state.lastPlanMtime = planMtime;
  state.count = 0;
  save();
  SILENT();
}

// Plan writes + meta tools don't increment the work counter.
if (isPlanWrite || META_TOOLS.has(tool)) { save(); SILENT(); }

state.count += 1;

if (state.count < PING_EVERY) { save(); SILENT(); }

// Time to ping. Reset so it re-arms for the next PING_EVERY actions.
state.count = 0;
save();

// Surface the ping in the «Процеси» panel (only on an actual ping, so per-tool
// ticks never flood the event stream). Vova 2026-07-08.
try {
  const { emit, channelFor } = require('./_emit.cjs');
  const ch = channelFor(input && input.session_id) || (plan && plan.id) || null;
  emit(ch, { kind: 'hook', name: 'PostToolUse', phase: 'fire',
    detail: `plan-ping після ~${PING_EVERY} дій без апдейту плану` });
} catch {}

const snap = mod.snapshotLine(plan);
const msg = [
  `PLAN PING — ~${PING_EVERY} actions since the plan was last updated.`,
  `Reconcile the ACTIVE plan now so progress stays tied to it (this is rule #1). ${snap}`,
  `Flip done/progress/pending/blocked, add steps for anything new. Each step needs goal + substeps + expected result.`,
  `Update: node tools/viz/chat/set-plan.cjs <channel> plan.json (UI repolls every 2s). If nothing changed, a 1-line tweak/timestamp bump is enough to clear this.`,
].join(' ');

process.stdout.write(JSON.stringify({ additionalContext: msg }));
process.exit(0);
