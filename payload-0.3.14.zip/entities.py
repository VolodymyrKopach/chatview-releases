#!/usr/bin/env python3
"""Реєстр класів сутностей користувача (specs/user-owned-entities, К7).

ЩО ЦЕ. Одне місце, де записано, ЩО таке клас сутності: у якій теці під коренем
даних він живе, який файл робить теку (чи файл) сутністю саме цього класу, як
перевірити, що екземпляр придатний, як створити новий з нуля і звідки інтерфейс
бере перелік. Клас це ЗАПИС ДАНИХ, а не код, розсипаний по серверу.

ЧОМУ ЦЕ ВЗАГАЛІ ПОТРІБНО. Зараз шлях кожного класу існує рядком у десятку місць:
`os.path.join(DIR, 'channels', cid)` трапляється в server.py щонайменше
чотирнадцять разів, `os.path.join(DIR, 'apps')` шістнадцять. Поки клас один і той
самий, це просто повторення. Але додати НОВИЙ клас означає знайти всі ці місця і
не пропустити жодного, а пропущене місце не падає: воно тихо дивиться не туди.
Рівно так гаджети приїхали в теку, яку сервер не читає, а помічники ставились за
межі дому користувача. К7 вимагає, щоб новий клас коштував ОДИН запис, і цей
модуль це і є той один запис.

ОДИН ШЛЯХ, І ВІН ВИДАЄТЬСЯ ТУТ (specs/user-data-architecture, К2 і К3). Шлях під
клас видає РІВНО `path_for`; `root_of`, `manifest_of` і `path_of` це обгортки над
нею, а не другий спосіб дійти до того самого місця. Для класу, якого в реєстрі
нема, функція кидає виняток і НЕ створює теки: сироту нема як народити ані
помилкою в імені, ані записом EntityClass повз `register()`. Це не бюрократія, а
єдине, що тримає реєстр реєстром: доки корінь можна зібрати руками поруч, його
там і збиратимуть, і саме так уже зʼявились двадцять дві сироти з перепису.

ЩО ЦЕ НЕ РОБИТЬ. Не переписує двигуни і нічого в них не міняє: server.py далі
читає свої шляхи як читав. Модуль дає СПІЛЬНУ правду про шляхи і манифести, з
якої двигуни можна переводити по одному, кожен окремою задачею. Тому тут немає ні
http, ні імпорту server.py: реєстр мусить бути придатним до читання з тесту,
збірки і воротаря чистоти, а не лише з живого сервера.

ФОРМА ЗАПИСУ, девʼять полів. Шість перших це форма з попередньої спеки
(user-owned-entities, розділ 6.2), три останні додала specs/user-data-architecture:

    kind      'skill'                 імʼя класу, унікальне
    root      'skills'                тека класу ПІД КОРЕНЕМ ДАНИХ
    manifest  '{id}/SKILL.md'         шлях від root, що робить це сутністю класу
    validate  <функція>               мінімальна перевірка манифеста
    create    <функція>               створення з шаблону (або create_never)
    list_api  '/api/skills'           звідки UI бере перелік (None = переліку нема)
    drawer    'data'                  шухляда: data / cache / state
    why_lost  'втратить своїх ...'    що САМЕ втратить людина, якщо це стерти
    external  False                   сховищем володіє не ChatView

ЧОМУ ТРИ НОВІ ПОЛЯ, І ЧОМУ ДВА З НИХ БЕЗ ДЕФОЛТУ. `drawer` це правило життя:
шухляда відповідає на питання «що станеться, якщо це зникне», і саме з неї
виводяться чистка, бекап і експорт. `why_lost` це поле-ОБҐРУНТУВАННЯ, а не
коментар для краси: без нього класифікацію «це просто кеш» неможливо оскаржити,
бо вона ніде не записана словами, а помилка в ній коштує даних людини. Тому клас
без шухляди або без обґрунтування НЕ РЕЄСТРУЄТЬСЯ взагалі: дефолт тут це та сама
мовчазна втрата, від якої поле і захищає. `external` має дефолт False свідомо, бо
False це СУВОРІШИЙ бік: «сховище наше, отже на нього поширюються наші правила».
Помилковий True навпаки вивів би клас з-під правил мовчки.

Одна відмінність від прикладу в спеці, і вона свідома. Там `manifest: 'SKILL.md'`,
тобто імʼя файлу ВСЕРЕДИНІ теки екземпляра. Тут це ШАБЛОН ШЛЯХУ від кореня класу
з підстановкою `{id}`, бо два наші живі класи не мають теки взагалі: факт памʼяті
це один файл `memory/facts/<id>.md`, а канва це один файл стану. Прапорець «тека
чи файл» був би сьомим полем, яке треба памʼятати; шаблон дає ту саму інформацію
без окремого прапорця, бо наявність `/` у ньому і є відповідь.

ЧОМУ ШЛЯХИ САМЕ ТАКІ. Це не проєкт бажаного, а перепис ТОГО, ЩО Є, інакше реєстр
брехав би з першого дня. Кожен рядок звірений з кодом:

    channel   server.py:6453  os.path.join(DIR, 'channels', cid)
    canvas    server.py:3041  CANVAS_DATA_DIR -> canvas-data/canvas-state.json
    gadget    server.py:2620  os.path.join(DIR, 'apps')
    skill     server.py:1627  _claude_root() + '.claude/skills'
    spec      specs_board.resolve_root -> <корінь>/specs
    memory    memory_store.MEM_DIR + FACTS_DIR -> memory/facts/<id>.md

ДВА МІСЦЯ, ДЕ ДЕВ-РЕПО І ПАКОВАНА АПКА РОЗХОДЯТЬСЯ, і реєстр цього не приховує:

  * `.claude/skills` у пакованій апці лежить під домом (`CHATVIEW_HOME/.claude`), а
    в дев-репо на три теки вище `tools/viz/chat`, бо там уже живуть помічники
    власника
    і переїзду там бути не має (К6). Це рівно та сама відповідь, яку дає
    `server.py:_claude_root()`, і тут вона повторена однією гілкою, а не списком
    класів: базу міняє САМ ПРЕФІКС `.claude/`, тобто це властивість шляху, а не
    виняток для конкретного класу.
  * канва в пакованій апці це `<дім>/canvas-data`, а в дев-репо історично
    `tools/canvas-cmd/data` через `CANVAS_DATA_DIR`. Реєстр називає канонічний
    корінь під домом і НЕ вдає, що дев такий самий: змінна оточення лишається за
    двигуном канви, і переїзд це окрема задача.

Сторінки канви всередині `canvas-state.json` це НЕ окремі екземпляри: tldraw
тримає їх в одному сховищі. Реєстр каже правду (один екземпляр на клас) замість
зручної вигадки про `canvas/<page>/`.
"""
import io
import os
import re
import json
from collections import namedtuple

#: Дозволений ідентифікатор екземпляра. Він приходить із запиту і стає ШЛЯХОМ, тому
#: перевірка тут не косметична: без неї `../../keys.json` є валідним «іменем».
ID_RE = re.compile(r'^[a-z0-9][a-z0-9._-]*$', re.IGNORECASE)
ID_MAX = 100

#: Три шухляди даних (specs/user-data-architecture, К1). Питання, яке визначає
#: шухляду, рівно одне: ЩО СТАНЕТЬСЯ, ЯКЩО ЦЕ ЗНИКНЕ.
#:
#:   data   людина втратила своє назавжди (відновити нема звідки)
#:   cache  відбудується саме, максимум повільніше (гроші і час, не втрата)
#:   state  процес просто стартує заново (нічого свого людина не мала)
DRAWERS = ('data', 'cache', 'state')

#: Мінімальна довжина `why_lost`. Не косметика: відповідь «дані» це те саме
#: мовчання, від якого поле і захищає, тому одне слово не проходить.
WHY_LOST_MIN = 20

#: Клас сутності. namedtuple, бо запис мусить бути НЕЗМІННИМ: реєстр, який можна
#: підправити на льоту з чужого модуля, перестає бути єдиним джерелом правди рівно
#: тоді, коли хтось це зробить, і знайти автора вже неможливо. Дефолти трьох
#: останніх полів це НЕ робочі значення, а мітка «не заповнено»: register() і
#: _check_class на них падають (див. докстрінг модуля).
EntityClass = namedtuple('EntityClass',
                         'kind root manifest validate create list_api '
                         'drawer why_lost external',
                         defaults=(None, None, False))


# ── корінь даних ────────────────────────────────────────────────────────────

def data_root(env=None):
    """Корінь даних користувача. ТА САМА формула, що й `server.py:36`.

    Повторена, а не імпортована, свідомо: імпорт server.py тягне http-сервер,
    раннер, реєстр процесів і половину застосунку, тому воротар чистоти і збірка
    не змогли б прочитати реєстр взагалі. Формула це один рядок, і вона прибита
    тестом, який звіряє її з server.py дослівно."""
    env = os.environ if env is None else env
    return env.get('CHATVIEW_HOME') or os.path.dirname(os.path.abspath(__file__))


def claude_root(home=None, env=None):
    """Корінь, під яким живе `.claude/` для ЦІЄЇ збірки. Дзеркало `server.py:282`.

    У пакованій апці (`CHATVIEW_HOME` виставлений) це сам дім: помічник це сутність
    користувача, і місце для неї мусить бути детермінованим відносно дому. У
    дев-репо `.claude/` лежить у корені репозиторію, тобто на три теки вище
    `tools/viz/chat`, і там уже живуть помічники власника (К6)."""
    env = os.environ if env is None else env
    home = home or data_root(env)
    if env.get('CHATVIEW_HOME'):
        return home
    return os.path.dirname(os.path.dirname(os.path.dirname(home)))


def _base_for(cls, home, env=None):
    """База, від якої відлічується `root` класу.

    Гілка рівно одна і вона керується САМИМ ШЛЯХОМ, а не списком класів: корінь, що
    починається з `.claude/`, живе під `claude_root()`, решта під домом. Тому новий
    клас під `.claude/` не вимагає жодної правки тут, і в цьому весь сенс К7."""
    first = cls.root.replace('\\', '/').split('/', 1)[0]
    if first == '.claude':
        return claude_root(home, env)
    return home


# ── шляхи ───────────────────────────────────────────────────────────────────

def safe_id(entity_id):
    """Чи можна підставляти цей ідентифікатор у шлях."""
    return (isinstance(entity_id, str) and 0 < len(entity_id) <= ID_MAX
            and bool(ID_RE.match(entity_id)) and '..' not in entity_id)


def _registered(kind):
    """Запис класу З РЕЄСТРУ і лише з нього (К3).

    Відрізняється від `by_kind` рівно одним, і в цьому вся суть К3: готовий
    `EntityClass`, зібраний руками повз `register()`, тут НЕ приймається. Інакше
    сироту можна народити не помилкою в імені, а обхідним шляхом: склав неймтапл,
    попросив шлях, зробив теку, і на диску людини живе клас, якого не знає ані
    воротар чистоти, ані бекап, ані експорт. Запис, який не пройшов реєстрації,
    це не клас, а чернетка класу."""
    if isinstance(kind, EntityClass):
        known = REGISTRY.get(kind.kind)
        if known is not kind:
            raise KeyError(
                'клас «%s» не зареєстрований: запис EntityClass, зроблений повз '
                'register(), шляху не отримує (є: %s)'
                % (kind.kind, ', '.join(kinds())))
        return known
    return by_kind(kind)


def _segments(part):
    """Хвіст шляху -> перевірені сегменти. Виняток замість тихого виходу з кореня.

    Хвости приходять із запиту так само, як ідентифікатори (`{id}` у манифесті це
    вже підставлений хвіст), тому мірка тут та сама, що в `safe_id`: `..` і
    абсолютний шлях це не імʼя файлу, а вихід з-під кореня класу."""
    text = str(part).replace('\\', '/')
    if os.path.isabs(text) or text.startswith('/'):
        raise ValueError('хвіст шляху мусить бути відносним: %r' % (part,))
    segs = [s for s in text.split('/') if s and s != '.']
    if not segs or '..' in segs:
        raise ValueError('поганий хвіст шляху: %r' % (part,))
    return segs


def path_for(kind, *parts, drawer=None, home=None, env=None):
    """ЄДИНА функція видачі шляху під клас сутностей (К2). -> абсолютний шлях.

    Без хвоста це корінь класу, з хвостом шлях усередині нього:

        path_for('channel')                     -> <дім>/channels
        path_for('channel', 'alpha/index.json')  -> <дім>/channels/alpha/index.json

    ЧОМУ ОДНА, А НЕ ТРИ ЗРУЧНІ. Доти доки корінь класу можна зібрати ще десь,
    його там і збиратимуть: `os.path.join(DIR, 'jobs', ...)` коротший за імпорт
    реєстру. Саме так зʼявились двадцять дві сироти з перепису, і саме так канва
    отримала три незалежні шляхи доступу. Тому решта помічників (`root_of`,
    `manifest_of`, `path_of`) це ОБГОРТКИ над цією функцією, а не другий спосіб
    дійти до того самого місця.

    ЩО ЦЯ ФУНКЦІЯ НЕ РОБИТЬ: не створює теку. Ані для відомого класу, ані тим
    паче для невідомого (К3). Видача шляху це обчислення; функція, яка «про всяк
    випадок» робить `makedirs`, перетворює друкарську помилку в імені класу на
    теку на диску людини, і відрізнити її від справжніх даних уже нема як.

    ЧОМУ `drawer` ТУТ ВЗАГАЛІ Є, ЯКЩО ШЛЯХУ ВІН ЗАРАЗ НЕ МІНЯЄ. Це заява
    ВИКЛИКАЛЬНИКА про правило життя даних, звірена з реєстром. Модуль, який
    вважає канал кешем, мусить впертись у помилку в момент запиту шляху, а не
    дізнатись про свою помилку в день, коли прибиральник кешу зітре чати людини.
    Коли S5 фізично розкладе дім на три шухляди, сегмент шухляди зʼявиться рівно
    тут, в одному місці, і жоден виклик не доведеться правити."""
    cls = _registered(kind)
    if drawer is not None and drawer != cls.drawer:
        raise ValueError(
            'клас «%s» живе в шухляді «%s», а шлях просять як «%s». Шухляда це '
            'правило життя даних (що станеться, якщо це зникне), тому розбіжність '
            'тут це або помилка виклику, або помилка класифікації в реєстрі'
            % (cls.kind, cls.drawer, drawer))
    home = home or data_root(env)
    segs = list(cls.root.split('/'))
    for part in parts:
        segs.extend(_segments(part))
    return os.path.join(_base_for(cls, home, env), *segs)


def root_of(kind, home=None, env=None):
    """Абсолютна тека КЛАСУ. Обгортка над `path_for` без хвоста."""
    return path_for(kind, home=home, env=env)


def manifest_of(kind, entity_id, home=None, env=None):
    """Абсолютний шлях манифеста ЕКЗЕМПЛЯРА."""
    cls = _registered(kind)
    if not safe_id(entity_id):
        raise ValueError('поганий ідентифікатор сутності: %r' % (entity_id,))
    return path_for(cls, cls.manifest.format(id=entity_id), home=home, env=env)


def path_of(kind, entity_id, home=None, env=None):
    """Абсолютний шлях САМОГО екземпляра.

    Для класів-тек це тека (`channels/<id>`), для класів-файлів сам файл
    (`memory/facts/<id>.md`). Різницю дає наявність `/` у шаблоні манифеста, тому
    окремого поля «тека чи файл» не існує і розійтись йому нема з чим."""
    cls = _registered(kind)
    m = manifest_of(cls, entity_id, home, env)
    return os.path.dirname(m) if '/' in cls.manifest else m


def is_dir_shaped(kind):
    """Чи екземпляр цього класу це тека (а не одиночний файл)."""
    return '/' in by_kind(kind).manifest


# ── перевірка і створення: спільні замовчування ─────────────────────────────
#
# Клас, який поводиться звичайно, не мусить писати ані валідатора, ані творця: він
# бере ці два. Свій пишеться лише там, де формат справді інший, і тоді причина
# видно з самого запису класу, а не з чужого модуля.

def _read(path, limit=1 << 20):
    with io.open(path, encoding='utf-8', errors='replace') as fh:
        return fh.read(limit)


def validate_json(path):
    """Манифест-json: існує, парситься, це обʼєкт або список. -> None | причина."""
    if not os.path.isfile(path):
        return 'нема файлу манифеста %s' % os.path.basename(path)
    try:
        data = json.loads(_read(path) or 'null')
    except Exception as e:
        return 'манифест %s не читається як JSON: %s' % (os.path.basename(path), e)
    if data is None:
        return 'манифест %s порожній' % os.path.basename(path)
    return None


def validate_text(path):
    """Манифест-markdown: існує і не порожній. -> None | причина."""
    if not os.path.isfile(path):
        return 'нема файлу манифеста %s' % os.path.basename(path)
    if not (_read(path) or '').strip():
        return 'манифест %s порожній' % os.path.basename(path)
    return None


def validate_blob(path):
    """Двійковий екземпляр (кеш озвучки): існує і не порожній. -> None | причина.

    Формату не перевіряємо навмисно: усередині mp3 від чужого двигуна, і єдине
    твердження, яке ми можемо зробити чесно, це «файл є і він не нульовий».
    Порожній файл під живим хешем гірший за відсутній: застосунок вважав би його
    готовою озвучкою."""
    if not os.path.isfile(path):
        return 'нема файлу манифеста %s' % os.path.basename(path)
    if os.path.getsize(path) <= 0:
        return 'манифест %s порожній' % os.path.basename(path)
    return None


def validate_frontmatter(path):
    """Той самий текст, але з обовʼязковим YAML-фронтматером.

    Ворота якості скіла: без фронтматера це нотатка, а не скіл. Та сама вимога, що
    в `harvest-skills.parse_md` і в `skill_live`, тому встановлений з каталогу і
    покладений руками скіл судяться однією міркою."""
    bad = validate_text(path)
    if bad:
        return bad
    if not _read(path, 4096).lstrip().startswith('---'):
        return ('манифест %s без YAML-фронтматера: це нотатка, а не сутність класу'
                % os.path.basename(path))
    return None


def create_json(path, entity_id, body=None):
    """Шаблон-json. Порожній обʼєкт з ідентифікатором усередині це МІНІМУМ, який
    проходить власний валідатор класу: шаблон, який не проходить своєї ж перевірки,
    це створення мертвої сутності."""
    _ensure_parent(path)
    data = dict(body or {})
    data.setdefault('id', entity_id)
    with io.open(path, 'w', encoding='utf-8') as fh:
        json.dump(data, fh, ensure_ascii=False, indent=1)
        fh.write('\n')
    return path


def create_list(path, entity_id, body=None):
    """Шаблон-json, коренем якого є СПИСОК (індекс повідомлень каналу)."""
    _ensure_parent(path)
    with io.open(path, 'w', encoding='utf-8') as fh:
        json.dump(list(body or []), fh, ensure_ascii=False)
        fh.write('\n')
    return path


def create_text(path, entity_id, body=None):
    """Шаблон-markdown з заголовком-ідентифікатором."""
    _ensure_parent(path)
    text = body if body is not None else '# %s\n' % entity_id
    with io.open(path, 'w', encoding='utf-8') as fh:
        fh.write(text if text.endswith('\n') else text + '\n')
    return path


def create_frontmatter(path, entity_id, body=None):
    """Шаблон із фронтматером, щоб щойно створене проходило `validate_frontmatter`."""
    if body is None:
        body = ('---\nname: %s\ndescription: \n---\n\n# %s\n'
                % (entity_id, entity_id))
    return create_text(path, entity_id, body)


def create_never(path, entity_id, body=None):
    """Творець для класів, які застосунок пише САМ і тільки сам.

    Не «ще не реалізовано», а заборона з причиною. Шаблон під живим іменем
    екземпляра тут означає підкладену підробку: порожній mp3 під хешем озвучки
    застосунок вважатиме готовою озвучкою і більше ніколи не переспіває, а
    напівпорожній job-файл покаже в панелі процес, якого нема. Клас, у якого
    створення з шаблону не має сенсу, мусить це СКАЗАТИ, а не мовчки писати
    заглушку."""
    raise NotImplementedError(
        'екземпляр цього класу не створюється з шаблону: його пише сам '
        'застосунок у момент роботи (%s)' % path)


def _ensure_parent(path):
    d = os.path.dirname(path)
    if d:
        os.makedirs(d, exist_ok=True)


# ── сам реєстр ──────────────────────────────────────────────────────────────
#
# Порядок такий самий, як у розкладці кореня в спеці (розділ 6.1), щоб два описи
# читались поруч без перекладу.

_CLASSES = (
    EntityClass(
        kind='channel',
        root='channels',
        # Порожній індекс повідомлень = мітка часу створення каналу; без нього канал
        # має updatedAt=0 з усіма наслідками сортування (server.py:6457).
        manifest='{id}/index.json',
        validate=validate_json,
        create=create_list,
        list_api='/api/channels',
        drawer='data',
        why_lost='картки всіх чатів, плани каналів і файли, які людина сама '
                 'перетягнула в розмову',
        external=False,
    ),
    EntityClass(
        kind='canvas',
        # Пакована апка: `<дім>/canvas-data`. Дев-репо історично тримає теку в
        # tools/canvas-cmd/data через CANVAS_DATA_DIR, і це не приховано (докстрінг).
        root='canvas-data',
        manifest='{id}.json',
        validate=validate_json,
        create=create_json,
        list_api='/api/canvas/pages',
        drawer='data',
        why_lost='сторінки канви з усіма фігурами: розкладене руками не '
                 'відновлюється нізвідки',
        external=False,
    ),
    EntityClass(
        kind='gadget',
        root='apps',
        manifest='{id}/manifest.json',
        validate=validate_json,
        create=create_json,
        list_api='/api/gadgets',
        drawer='data',
        why_lost='гаджети людини разом з усім, що в них накопичено: задачі, '
                 'чернетки, картки клієнтів',
        external=False,
    ),
    EntityClass(
        kind='skill',
        # `.claude/` тут не випадковість і не спадок: саме цей префікс перемикає базу
        # на claude_root() (див. _base_for), тому пакована апка кладе помічника в дім,
        # а дев-репо в корінь репозиторію, де він уже живе.
        root='.claude/skills',
        manifest='{id}/SKILL.md',
        validate=validate_frontmatter,
        create=create_frontmatter,
        list_api='/api/skills',
        drawer='data',
        why_lost='встановлені помічники: написані руками зникнуть назавжди, решту '
                 'доведеться шукати і ставити наново',
        external=False,
    ),
    EntityClass(
        kind='spec',
        root='specs',
        manifest='{id}/spec.md',
        validate=validate_text,
        create=create_text,
        list_api='/api/specs-board',
        drawer='data',
        why_lost='специфікації задач: дослівні слова замовника, критерії приймання '
                 'і плани, яких у коді немає',
        external=False,
    ),
    EntityClass(
        kind='memory',
        # Клас-ФАЙЛ: факт це один markdown з фронтматером, теки в нього нема
        # (memory_store.MEM_DIR + FACTS_DIR).
        root='memory/facts',
        manifest='{id}.md',
        validate=validate_frontmatter,
        create=create_frontmatter,
        list_api='/api/memory',
        drawer='data',
        why_lost='факти памʼяті про людину і її справу: застосунок забуде все, що '
                 'про неї знав',
        external=False,
    ),
    # ── класи, знайдені переписом (inventory.md, розділ 3) ───────────────────
    #
    # Три теки, які роками зберігали екземпляри без жодного запису про себе: ані
    # правила життя, ані захисту воротаря чистоти, який виводиться з цього реєстру.
    # Усі три пише сам застосунок у момент роботи, тому творця з шаблону в них нема.
    EntityClass(
        kind='job',
        # jobs.py:44 JOBS_DIR. Екземпляр це пара job-<hex>.json + job-<hex>.cmd.
        root='jobs',
        manifest='{id}.json',
        validate=validate_json,
        create=create_never,
        list_api='/api/jobs',
        # STATE, а не data, і це видно з самого коду: завершений запис живе
        # KEEP_DONE_SEC = 10 хвилин і його прибирає prune (jobs.py:56). Те, що
        # застосунок сам стирає через десять хвилин, за визначенням не є тим, що
        # людина втрачає назавжди.
        drawer='state',
        why_lost='нічого назавжди: панель процесів втратить перелік запущених '
                 'задач і вартових, нові стартують з чистого',
        external=False,
    ),
    EntityClass(
        kind='pipeline',
        # server.py:13010 і server.py:18390: pipelines/<run>/state.json.
        root='pipelines',
        manifest='{id}/state.json',
        validate=validate_json,
        create=create_never,
        # Переліку по http нема: сторінка pipeline.html відкривається по одному
        # запуску (?run=<id>). None це чесна відсутність, а не мертва адреса.
        list_api=None,
        drawer='data',
        why_lost='відео-проєкти: стан монтажу, відібрані кліпи і рішення по '
                 'кожному ролику',
        external=False,
    ),
    EntityClass(
        kind='voice',
        # server.py:16361: voice-cache/<md5>.mp3, ключ рахується з тексту, голосу
        # і моделі. Перепис заміряв 2.8 ГБ.
        root='voice-cache',
        manifest='{id}.mp3',
        # Кеш-файл не має внутрішнього формату, який ми перевіряємо: сам факт
        # непорожнього файлу і є придатність.
        validate=validate_blob,
        create=create_never,
        list_api=None,
        # CACHE, і саме цей клас доводить, що шухляда «cache» не слово в докстрінгу.
        # Зникло означає переспівається з того самого тексту тим самим ключем.
        drawer='cache',
        why_lost='нічого назавжди: озвучка переспівається з того самого тексту, '
                 'витратить лише час і ключ людини',
        external=False,
    ),
)


def _check_class(cls):
    """Перевірка ЗАПИСУ класу. Спільна для реєстру і для register().

    Спільна навмисно: наші власні класи потрапляють у REGISTRY не через
    register(), а прямо з `_CLASSES`, і перевірка лише в register() означала б, що
    на них правила не поширюються. Тому будь-яка помилка в записі валить сам
    ІМПОРТ модуля, тобто збірку, тест і воротаря одночасно."""
    if not isinstance(cls, EntityClass):
        raise TypeError('клас сутностей мусить бути EntityClass')
    if not cls.kind or not ID_RE.match(cls.kind):
        raise ValueError('погане імʼя класу: %r' % (cls.kind,))
    if '{id}' not in cls.manifest:
        raise ValueError('шаблон манифеста мусить містити {id}: %r' % (cls.manifest,))
    if cls.drawer not in DRAWERS:
        raise ValueError(
            'клас «%s» без шухляди: drawer мусить бути одним з %s. Питання, яке '
            'дає відповідь: що станеться, якщо це зникне (втрачено назавжди = '
            'data, відбудується саме = cache, процес стартує заново = state)'
            % (cls.kind, ', '.join(DRAWERS)))
    if (not isinstance(cls.why_lost, str)
            or len(cls.why_lost.strip()) < WHY_LOST_MIN):
        raise ValueError(
            'клас «%s» без обґрунтування втрати: why_lost мусить одним реченням '
            'сказати, що САМЕ втратить людина, якщо це стерти. Дефолт тут це та '
            'сама мовчазна втрата, від якої поле і захищає' % (cls.kind,))
    if not isinstance(cls.external, bool):
        raise ValueError('клас «%s»: external мусить бути булевим (чи володіє '
                         'сховищем не ChatView)' % (cls.kind,))
    if cls.list_api is not None and not str(cls.list_api).startswith('/api/'):
        raise ValueError('клас «%s»: list_api це адреса переліку або None'
                         % (cls.kind,))
    return cls


REGISTRY = {c.kind: _check_class(c) for c in _CLASSES}


def kinds():
    """Імена класів у порядку оголошення."""
    return [c.kind for c in _CLASSES]


def by_kind(kind):
    """Запис класу або зрозуміла помилка (не KeyError з голим рядком)."""
    if isinstance(kind, EntityClass):
        return kind
    try:
        return REGISTRY[kind]
    except KeyError:
        raise KeyError('нема класу сутностей «%s»; є: %s'
                       % (kind, ', '.join(kinds())))


def register(cls):
    """Додати клас у реєстр. -> сам клас.

    Існує рівно заради К7: новий клас це ОДИН запис і нічого більше. Тому функція
    приймає готовий EntityClass і не має жодного знання про конкретні класи."""
    _check_class(cls)
    if cls.kind in REGISTRY:
        raise ValueError('клас «%s» уже є в реєстрі' % cls.kind)
    REGISTRY[cls.kind] = cls
    return cls


def unregister(kind):
    """Прибрати клас (для тестів). Мовчить, якщо його вже нема."""
    REGISTRY.pop(kind, None)


# ── дії над екземплярами ────────────────────────────────────────────────────

def validate(kind, entity_id, home=None, env=None):
    """Придатність екземпляра. -> None (усе гаразд) | причина українською.

    ПРИЧИНА, А НЕ БУЛЕВЕ (К5). Сутність, покладена руками і відхилена мовчки, дає
    людині порожній екран без жодної підказки, і це рівно та мовчазна деградація,
    яку спека називає ризиком. Тому невдача це РЯДОК, придатний до показу."""
    cls = by_kind(kind)
    return cls.validate(manifest_of(kind, entity_id, home, env))


def create(kind, entity_id, home=None, body=None, env=None):
    """Створити екземпляр із шаблону класу. -> шлях до створеного манифеста.

    Уже наявний манифест НЕ перетирається: створення це створення, а не мовчазне
    знищення чужої роботи однойменним ідентифікатором."""
    cls = by_kind(kind)
    path = manifest_of(kind, entity_id, home, env)
    if os.path.exists(path):
        raise FileExistsError('сутність %s/%s уже існує: %s'
                              % (kind, entity_id, path))
    return cls.create(path, entity_id, body)


def scan(kind, home=None, env=None):
    """Усі екземпляри класу на диску. -> [{id, path, manifest, ok, reason}]

    Показує і НЕПРИДАТНІ теж, з причиною: сканер, який мовчки пропускає биті,
    відповідає на питання «чому мого гаджета не видно» тишею (К5)."""
    cls = by_kind(kind)
    root = root_of(kind, home, env)
    out = []
    try:
        names = sorted(os.listdir(root))
    except OSError:
        return out
    dir_shaped = is_dir_shaped(kind)
    suffix = '' if dir_shaped else os.path.splitext(cls.manifest)[1]
    for name in names:
        # Не другий спосіб зібрати корінь: `root` уже виданий `path_for`, і тут до
        # нього дописується імʼя, яке щойно повернув `listdir` цього ж кореня.
        full = os.path.join(root, name)
        if dir_shaped:
            if not os.path.isdir(full):
                continue
            entity_id = name
        else:
            if not os.path.isfile(full) or (suffix and not name.endswith(suffix)):
                continue
            entity_id = name[:-len(suffix)] if suffix else name
        if not safe_id(entity_id):
            continue
        reason = validate(kind, entity_id, home, env)
        out.append({'kind': kind, 'id': entity_id,
                    'path': path_of(kind, entity_id, home, env),
                    'manifest': manifest_of(kind, entity_id, home, env),
                    'ok': reason is None, 'reason': reason})
    return out


def describe(home=None, env=None):
    """Реєстр у формі даних: для самоопису, тестів і воротаря чистоти."""
    home = home or data_root(env)
    return [{'kind': c.kind, 'root': c.root, 'manifest': c.manifest,
             'listApi': c.list_api, 'dir': is_dir_shaped(c.kind),
             'drawer': c.drawer, 'whyLost': c.why_lost, 'external': c.external,
             'path': root_of(c.kind, home, env)} for c in REGISTRY.values()]


if __name__ == '__main__':
    print(json.dumps(describe(), ensure_ascii=False, indent=1))
