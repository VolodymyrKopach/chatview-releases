#!/usr/bin/env python3
"""Механічна шапка підсумку пачки агентів: чиста функція, нуль моделі, нуль диска, нуль мережі.

specs/agent-batch-summary/spec.md, сабтаск S3, критерій К8, частково К2 (провал видно
окремим рядком і не рахується серед успішних). Вхід це готові словники з
`channels/<ch>/agents/<id>/status.json`, читає їх і збирає в один список викликач,
саме тому це тестується фікстурами без жодного процесу.

Поля живого запису (зняті з реального файлу): agentId, label, task, model, effort, sid,
state, progressPct, createdAt, jobId, pid, pgid, claudeJobId, startedAt, lastStep,
updatedAt, і лише на фініші summary + endedAt. Стани: queued, running, done, error,
stopped. Окремого стану "сирота" в даних немає: `_agent_settle_status` у server.py
закриває мертвий процес як state=error з summary="процес зник (orphan)", і саме цей
маркер тут єдиний спосіб відрізнити сироту від справжньої помилки.

`output.md` тут НЕ читається ніколи (12.5 КБ у середньому, 56 КБ максимум): шапка
збирається виключно з полів status.json, інакше картка сама стає простирадлом.
"""
from datetime import datetime

SUCCESS_STATE = 'done'
FAILED_STATES = ('error', 'stopped')
ORPHAN_MARKER = 'orphan'

SUMMARY_NOTE_LIMIT = 140
NO_SUMMARY_NOTE = 'агент не лишив підсумку'


def _is_orphan(record):
    """Сирота це error з маркером `_agent_settle_status`, не будь-яка помилка."""
    if record.get('state') != 'error':
        return False
    return ORPHAN_MARKER in (record.get('summary') or '').lower()


def _label(record):
    return record.get('label') or record.get('agentId') or '(без назви)'


def _parse_ts(value):
    if not value:
        return None
    try:
        return datetime.fromisoformat(value)
    except (TypeError, ValueError):
        return None


def _earliest_start(record):
    return _parse_ts(record.get('startedAt')) or _parse_ts(record.get('createdAt'))


def _latest_end(record):
    return _parse_ts(record.get('endedAt')) or _parse_ts(record.get('updatedAt'))


def _format_duration(seconds):
    total_minutes = max(0, int(round(seconds))) // 60
    if total_minutes < 60:
        return f'{total_minutes} хв'
    hours, minutes = divmod(total_minutes, 60)
    return f'{hours} год {minutes} хв'


def _batch_duration_label(records):
    """Від найранішого старту до найпізнішого фінішу. Записи без жодної мітки часу
    не рахуються, а не валять функцію: `?` чесніше за вигаданий нуль."""
    starts = [t for t in (_earliest_start(r) for r in records) if t]
    ends = [t for t in (_latest_end(r) for r in records) if t]
    if not starts or not ends:
        return '?'
    return _format_duration((max(ends) - min(starts)).total_seconds())


def _truncate_note(summary):
    text = (summary or '').strip()
    if not text:
        return NO_SUMMARY_NOTE
    if len(text) <= SUMMARY_NOTE_LIMIT:
        return text
    cut = text[:SUMMARY_NOTE_LIMIT]
    space = cut.rfind(' ')
    if space > 0:
        cut = cut[:space]
    return cut.rstrip() + '…'


def _checklist_state(record):
    state = record.get('state')
    if state == SUCCESS_STATE:
        return 'done'
    if state == 'stopped':
        return 'warning'
    if state == 'error':
        return 'warning' if _is_orphan(record) else 'no'
    return 'pending'


def _failure_text(failed_records):
    errored = [_label(r) for r in failed_records if r.get('state') == 'error' and not _is_orphan(r)]
    orphaned = [_label(r) for r in failed_records if r.get('state') == 'error' and _is_orphan(r)]
    stopped = [_label(r) for r in failed_records if r.get('state') == 'stopped']
    parts = []
    if errored:
        parts.append('впали: ' + ', '.join(errored))
    if stopped:
        parts.append('зупинені: ' + ', '.join(stopped))
    if orphaned:
        parts.append('визнані сиротою: ' + ', '.join(orphaned))
    return 'Не всі агенти пачки завершились успішно, ' + '; '.join(parts) + '.'


def _conclusion_text(total, succeeded, failed, tone):
    if tone == 'green':
        return f'Пачка завершена: усі {total} агентів впорались.'
    if tone == 'red':
        return f'Пачка переважно провалилась: лише {succeeded} з {total} агентів впорались.'
    return f'Пачка завершена: {succeeded} з {total} агентів впорались, {failed} впало.'


def build_batch_summary_widgets(records):
    """Побудувати масив chatui-віджетів механічної шапки підсумку пачки.

    Порядок фіксований контрактом спеки: stat-grid, опційний callout про провали,
    checklist по агенту, conclusion останнім. Детермінована: той самий вхід дає той
    самий вихід, жодного поточного часу всередині."""
    records = list(records or [])
    total = len(records)
    succeeded = sum(1 for r in records if r.get('state') == SUCCESS_STATE)
    failed_records = [r for r in records if r.get('state') in FAILED_STATES]
    failed = len(failed_records)

    widgets = [{
        'type': 'stat-grid',
        'cards': [
            {'value': total, 'label': 'агентів у пачці', 'color': 'slate'},
            {'value': succeeded, 'label': 'завершились успішно', 'color': 'green'},
            {'value': failed, 'label': 'впало', 'color': 'red'},
            {'value': _batch_duration_label(records), 'label': 'тривалість пачки', 'color': 'slate'},
        ],
    }]

    if failed_records:
        widgets.append({
            'type': 'callout',
            'variant': 'danger',
            'text': _failure_text(failed_records),
        })

    widgets.append({
        'type': 'checklist',
        'items': [
            {'text': _label(r), 'state': _checklist_state(r), 'note': _truncate_note(r.get('summary'))}
            for r in records
        ],
    })

    if total == 0 or failed == 0:
        tone = 'neutral' if total == 0 else 'green'
    elif failed > total / 2:
        tone = 'red'
    else:
        tone = 'yellow'

    conclusion = {
        'type': 'conclusion',
        'text': _conclusion_text(total, succeeded, failed, tone),
        'tone': tone,
    }
    if failed_records:
        conclusion['points'] = ['Провалились: ' + ', '.join(_label(r) for r in failed_records)]
    widgets.append(conclusion)

    return widgets
