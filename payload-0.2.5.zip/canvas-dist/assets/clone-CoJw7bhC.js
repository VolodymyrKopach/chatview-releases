import{b as r}from"./graph-BtOrYKwN.js";var e=4;function a(o){return r(o,e)}export{a as c};
