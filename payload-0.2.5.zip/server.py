#!/usr/bin/env python3
"""Vova chat view server. Serves chat HTML + channel messages with no-cache.
Supports POST /api/delete to remove a message from a channel."""
import http.server
import socketserver
import os
import sys
import json
import time
import threading
import stat as stat_module   # S_ISREG guard for the hot-file cache
import mimetypes             # content types for the V2 dist assets (D14)

# ---- Force UTF-8 mode (CRITICAL on Windows) --------------------------------
# Mirror runner.py's PEP 540 re-exec. Two reasons this MUST run before anything
# else in server.py:
#   1) Cyrillic correctness: on Windows the default locale is a legacy code page
#      (cp1251), so open()/json.load default encoding mangles the Cyrillic in
#      channels/messages/plans exactly like it did in the runner.
#   2) De-hijack: server.py later does `import runner`. runner.py has this SAME
#      re-exec at module top level (NOT under a __main__ guard). Without the line
#      below, importing runner on Windows (utf8 mode off) fires runner's os.execv
#      and REPLACES the server.py process with runner.py — so serve_forever() is
#      never reached and the HTTP server (with the Antigravity routes) never binds.
#      By re-exec'ing ourselves with PYTHONUTF8=1 FIRST, the later `import runner`
#      sees PYTHONUTF8=='1' and skips its own re-exec. No-op on POSIX and after the
#      first re-exec (utf8 already active).
if sys.platform == 'win32' and sys.flags.utf8_mode == 0 and os.environ.get('PYTHONUTF8') != '1':
    os.environ['PYTHONUTF8'] = '1'
    os.execv(sys.executable, [sys.executable, '-X', 'utf8', os.path.abspath(__file__)] + sys.argv[1:])

PORT = int(os.environ.get('VIZ_CHAT_PORT', '5555'))
# CHATVIEW_HOME: desktop build points DIR (served + data root) at a per-user writable
# home (e.g. ~/Library/Application Support/ChatView), so data survives app delete/update.
# Absent (dev/live server) -> identical original behavior (script dir). Safe, additive.
DIR = os.environ.get('CHATVIEW_HOME') or os.path.dirname(os.path.abspath(__file__))


def _remote_access_enabled():
    """Desk / remote-access (Tailscale tablet access) is SECURITY-SENSITIVE, so it
    defaults to DENY and must never reach end users of the packaged product. It is ON
    only for the developer's own run and OFF in a distributed desktop build. Explicit
    env vars are the build/runtime kill-switch (DISABLE wins, so a build can always
    force it off):
        CHATVIEW_DISABLE_REMOTE=1 -> force OFF (highest priority)
        CHATVIEW_ENABLE_REMOTE=1  -> force ON
        else: ON for a repo/dev run (no CHATVIEW_HOME), OFF for the packaged app
              (entry.py always sets CHATVIEW_HOME).
    """
    if os.environ.get('CHATVIEW_DISABLE_REMOTE') == '1':
        return False
    if os.environ.get('CHATVIEW_ENABLE_REMOTE') == '1':
        return True
    return not bool(os.environ.get('CHATVIEW_HOME'))


REMOTE_ACCESS = _remote_access_enabled()
os.makedirs(DIR, exist_ok=True)
os.chdir(DIR)


def _raise_fd_limit():
    """Підняти стелю відкритих дескрипторів для СЕБЕ.

    launchd віддає своїм дітям soft RLIMIT_NOFILE=256 (`launchctl limit maxfiles`),
    а сервер тримає по дескриптору на КОЖНЕ живе keep-alive з'єднання: одна вкладка
    ChatView це ~6 сокетів на хост, SSE-стрім ще один, і e2e-прогон, що піднімає
    десятки контекстів Chromium, впирався в стелю. Далі падало все підряд, аж до
    `os.getcwd()` у конструкторі хендлера (853 таких трасбеки в логу):
        OSError: [Errno 24] Too many open files
    Хард-ліміт на macOS далеко вищий (kern.maxfilesperproc), тож просто беремо його.
    Windows не має модуля resource — там ліміт інший і ця проблема не відтворюється.
    """
    try:
        import resource
    except ImportError:
        return None
    try:
        soft, hard = resource.getrlimit(resource.RLIMIT_NOFILE)
        want = min(hard, 8192) if hard != resource.RLIM_INFINITY else 8192
        if soft < want:
            resource.setrlimit(resource.RLIMIT_NOFILE, (want, hard))
            return (soft, want)
    except (ValueError, OSError):
        pass   # ліміт підняти не дали — працюємо як раніше
    return None


_FD_LIMIT_RAISED = _raise_fd_limit()


# --- Local Whisper (whisper.cpp) transcription config ------------------------
# PRIMARY engine for /api/transcribe. Free, offline, private. Built with Metal
# on Apple Silicon. Cloud OpenAI whisper-1 stays as automatic fallback.
def _first_existing(paths):
    for p in paths:
        if p and os.path.exists(p):
            return p
    return ''

# whisper-cli binary (env override > built-in build dir).
WHISPER_BIN = os.environ.get('WHISPER_CLI_BIN') or _first_existing([
    os.path.join(DIR, 'whisper', 'build', 'bin', 'whisper-cli'),
    '/opt/homebrew/bin/whisper-cli',
])
# large-v3 ggml model (env override > built-in models dir).
WHISPER_MODEL = os.environ.get('WHISPER_MODEL') or _first_existing([
    os.path.join(DIR, 'whisper', 'models', 'ggml-large-v3.bin'),
])
# ffmpeg for webm/opus -> 16kHz mono wav. PATH under launchd lacks /opt/homebrew.
FFMPEG_BIN = os.environ.get('FFMPEG_BIN') or _first_existing([
    '/opt/homebrew/bin/ffmpeg', '/usr/local/bin/ffmpeg',
]) or 'ffmpeg'
# Initial prompt nudges product-specific spelling. Cheap, only helps. Keep it a
# short comma-separated list (whisper initial_prompt degrades if it's a paragraph):
# product names + Vova's frequent UA/EN code-switch terms that whisper mangles.
WHISPER_PROMPT = ('SpeechDesk, ChatView, логопед, заняття, хоткей, промпт, деплой, '
                  'баг, фікс, канва, віджет, лендінг, воронка, фідбек, апрув, реліз, коміт.')


def _transcribe_local(blob, mime):
    """PRIMARY transcription via whisper.cpp large-v3 (Metal). Ukrainian.

    Decodes the incoming MediaRecorder audio (webm/opus etc.) to 16kHz mono WAV
    with ffmpeg, then runs whisper-cli. Returns the recognized text on success.
    Raises on ANY problem (missing binary/model/ffmpeg, non-zero exit, empty
    result) so the caller can fall back to the cloud path.
    """
    import subprocess, tempfile, time, sys as _sys
    if not WHISPER_BIN:
        raise RuntimeError('whisper-cli binary not found')
    if not WHISPER_MODEL:
        raise RuntimeError('whisper large-v3 model not found')
    t0 = time.time()
    tmpdir = tempfile.mkdtemp(prefix='whisper-')
    in_path = os.path.join(tmpdir, 'in')
    wav_path = os.path.join(tmpdir, 'audio.wav')
    try:
        with open(in_path, 'wb') as f:
            f.write(blob)
        # Decode -> 16kHz mono WAV (whisper.cpp requirement).
        ff = subprocess.run(
            [FFMPEG_BIN, '-y', '-i', in_path, '-ar', '16000', '-ac', '1',
             '-c:a', 'pcm_s16le', wav_path],
            capture_output=True, timeout=60)
        if ff.returncode != 0 or not os.path.exists(wav_path):
            raise RuntimeError(
                'ffmpeg failed: ' + ff.stderr.decode('utf-8', 'replace')[-300:])
        # Run whisper-cli: large-v3, uk, plain text to stdout (-nt = no timestamps).
        wr = subprocess.run(
            [WHISPER_BIN, '-m', WHISPER_MODEL, '-l', 'uk', '-nt', '-np',
             '--prompt', WHISPER_PROMPT, '-f', wav_path],
            capture_output=True, timeout=180)
        if wr.returncode != 0:
            raise RuntimeError(
                'whisper-cli exit %d: %s' % (
                    wr.returncode, wr.stderr.decode('utf-8', 'replace')[-300:]))
        text = wr.stdout.decode('utf-8', 'replace').strip()
        if not text:
            raise RuntimeError('whisper-cli empty result')
        dt = time.time() - t0
        print('[transcribe] engine=local took=%.2fs chars=%d' % (dt, len(text)),
              file=_sys.stderr, flush=True)
        return text
    finally:
        try:
            import shutil
            shutil.rmtree(tmpdir, ignore_errors=True)
        except Exception:
            pass


def _keys_file():
    """Path to the per-user BYOK store. Lives in CHATVIEW_HOME (== DIR), NOT the
    repo, so user-entered keys never get committed and survive app update."""
    return os.path.join(DIR, 'keys.json')


def _load_user_keys():
    """Read CHATVIEW_HOME/keys.json -> dict. Missing/malformed -> {} (never raises)."""
    try:
        with open(_keys_file(), encoding='utf-8') as f:
            data = json.load(f)
            return data if isinstance(data, dict) else {}
    except Exception:
        return {}


def _load_env_key(name):
    """Walk up from DIR to find `<name>=` in a .env file. Returns '' if absent.

    🔒 STRICT BYOK: disabled in a packaged desktop build (CHATVIEW_HOME set). A
    distributed app must NEVER read an ambient .env — keys come ONLY from the user's
    own keys.json (entered in Settings). This guarantees the owner's keys can never be
    used by someone they hand the app to, and no stray .env is ever trusted. In dev
    (repo run, no CHATVIEW_HOME) the fallback stays, so Vova's :5555 keeps using .env."""
    if os.environ.get('CHATVIEW_HOME'):
        return ''
    search_dir = DIR
    for _ in range(6):
        env_file = os.path.join(search_dir, '.env')
        if os.path.exists(env_file):
            with open(env_file) as f:
                for line in f:
                    if line.startswith(name + '='):
                        return line.split('=', 1)[1].strip()
        search_dir = os.path.dirname(search_dir)
    return ''


def _load_openai_key():
    """OpenAI key. BYOK store (CHATVIEW_HOME/keys.json) FIRST, then .env fallback."""
    return (_load_user_keys().get('openai') or '').strip() or _load_env_key('OPENAI_API_KEY')


def _load_gemini_key():
    """Gemini key. BYOK store (CHATVIEW_HOME/keys.json) FIRST, then .env fallback."""
    return (_load_user_keys().get('gemini') or '').strip() or _load_env_key('GEMINI_API_KEY')


def _load_xai_key():
    """xAI (Grok) key. BYOK store (CHATVIEW_HOME/keys.json) FIRST, then .env fallback.
    Powers Grok Voice TTS (default engine since Vova 2026-07-12)."""
    return (_load_user_keys().get('xai') or '').strip() or _load_env_key('XAI_API_KEY')


def _load_eleven_key():
    """ElevenLabs key. BYOK store (CHATVIEW_HOME/keys.json) FIRST, then .env fallback.
    Opt-in TTS engine only: it is the priciest per character, so nothing routes to it
    by default (see /api/voice engine chain)."""
    return (_load_user_keys().get('elevenlabs') or '').strip() or _load_env_key('ELEVENLABS_API_KEY')


# ── Retelling («Переказати») text generation ────────────────────────────────
# Powers POST /api/retell: turn a chat message into a friendly spoken RETELLING
# (пересказ), NOT a literal read of the on-screen text. A CHEAP FAST LLM does the
# transform; we voice THAT via the existing /api/voice TTS. Gemini Flash is the
# preferred model (cheap, fast, strong Ukrainian); on any Gemini error we fall
# back to a cheap OpenAI chat model so the feature still works. If BOTH are
# unavailable we raise so the endpoint can return a clean error (never hang).

# System/instruction prompt for the retelling. Conversational, listen-first, no
# markdown / em-dashes / bullet labels / preambles. Kept as a module constant so
# both the Gemini and OpenAI paths use the identical instruction.
_RETELL_SYSTEM = (
    'Ти переказуєш повідомлення чату голосом, як другу. Дай стислий природний '
    'переказ українською, щоб людина зрозуміла суть НЕ читаючи: про що це, ключові '
    'цифри, висновок, наступні кроки. Розмовно, без markdown, без тире, без вступів, '
    'без переліків з дефісами, суцільним живим текстом. Тільки переказ, нічого зайвого.'
)

# Default cheap/fast models. Gemini Flash first, OpenAI as the working fallback.
_RETELL_GEMINI_MODEL = 'gemini-3.1-flash-lite-preview'
_RETELL_OPENAI_MODEL = 'gpt-4o-mini'


def _gemini_generate(prompt, model=None, timeout=30):
    """Call Gemini generateContent (v1beta) with the BYOK/.env key and return the
    plain text. Raises on missing key / HTTP error / empty output so the caller
    can fall back. Mirrors how the TTS code reads keys and does a urllib POST."""
    import urllib.request, urllib.error
    key = _load_gemini_key()
    if not key:
        raise RuntimeError('no gemini key')
    model = model or _RETELL_GEMINI_MODEL
    url = ('https://generativelanguage.googleapis.com/v1beta/models/'
           f'{model}:generateContent?key={key}')
    payload = json.dumps({
        'contents': [{'parts': [{'text': prompt}]}],
        'generationConfig': {'temperature': 0.7, 'maxOutputTokens': 1024},
    }).encode('utf-8')
    req = urllib.request.Request(
        url, data=payload,
        headers={'Content-Type': 'application/json'}, method='POST')
    with urllib.request.urlopen(req, timeout=timeout) as resp:
        data = json.loads(resp.read().decode('utf-8'))
    cands = data.get('candidates') or []
    if not cands:
        raise RuntimeError('gemini: no candidates ' + json.dumps(data)[:200])
    parts = (cands[0].get('content') or {}).get('parts') or []
    text = ''.join(p.get('text', '') for p in parts).strip()
    if not text:
        raise RuntimeError('gemini: empty text')
    return text


def _openai_chat(system, user, model=None, timeout=45):
    """Cheap OpenAI Chat Completions call. Returns plain text. Raises on missing
    key / HTTP error / empty output. Used as the retelling fallback when Gemini
    is unavailable. Uses the SAME OpenAI key as the TTS path."""
    import urllib.request, urllib.error
    key = _load_openai_key()
    if not key:
        raise RuntimeError('no openai key')
    model = model or _RETELL_OPENAI_MODEL
    payload = json.dumps({
        'model': model,
        'messages': [
            {'role': 'system', 'content': system},
            {'role': 'user', 'content': user},
        ],
        'temperature': 0.7,
    }).encode('utf-8')
    req = urllib.request.Request(
        'https://api.openai.com/v1/chat/completions', data=payload,
        headers={'Authorization': f'Bearer {key}', 'Content-Type': 'application/json'},
        method='POST')
    with urllib.request.urlopen(req, timeout=timeout) as resp:
        data = json.loads(resp.read().decode('utf-8'))
    choices = data.get('choices') or []
    text = (((choices[0] or {}).get('message') or {}).get('content') or '').strip() if choices else ''
    if not text:
        raise RuntimeError('openai: empty text')
    return text


def _generate_retelling(content):
    """Produce a conversational Ukrainian RETELLING of the message `content`.
    Gemini Flash first, then OpenAI on ANY Gemini failure. Returns
    (retelling_text, engine_used). Raises RuntimeError only if BOTH providers
    fail, so the endpoint can return a clean error instead of hanging."""
    content = (content or '').strip()
    if not content:
        raise RuntimeError('empty content')
    prompt = _RETELL_SYSTEM + '\n\nОсь повідомлення для переказу:\n\n' + content
    errors = []
    # Primary: Gemini Flash (single combined prompt, generateContent has no roles).
    try:
        return _gemini_generate(prompt), 'gemini'
    except Exception as e:
        errors.append(f'gemini: {e}')
        print('[retell] gemini failed, falling back to openai:', e,
              file=sys.stderr, flush=True)
    # Fallback: cheap OpenAI chat (system + user split).
    try:
        return _openai_chat(_RETELL_SYSTEM, content), 'openai'
    except Exception as e:
        errors.append(f'openai: {e}')
        print('[retell] openai fallback failed:', e, file=sys.stderr, flush=True)
    raise RuntimeError('; '.join(errors))


def _strip_lone_surrogates(s):
    """Remove unpaired UTF-16 surrogates (U+D800..U+DFFF) from a string.

    When the front end slices a reply snippet mid-emoji, the value can carry a
    LONE surrogate. json.dumps(...).encode('utf-8') then raises
    UnicodeEncodeError ('surrogates not allowed') and the whole channel write /
    response crashes. The round-trip below drops any byte that won't encode,
    yielding clean UTF-8. Non-str input is returned unchanged."""
    if not isinstance(s, str):
        return s
    return s.encode('utf-8', 'ignore').decode('utf-8', 'ignore')


# ── Attachment classification (shared by /api/upload + /api/send) ───────────────
# Mirrors the front-end cvFileMeta() table in index.html. kind drives behaviour:
#   'image' → render thumbnail, Read tool "sees" it (pixels)
#   'text'  → readable plain text: content is inlined into the AI prompt on send
#   'doc'   → pdf/docx/binary office: accept + show a file chip, but CONTENT
#             PARSING is a SEPARATE stage (needs a pip lib → breaks stdlib-only),
#             so we DO NOT parse it here. See the TODO in /api/send.
_IMAGE_EXTS = {'png', 'jpg', 'jpeg', 'gif', 'webp', 'bmp', 'svg'}
# Extension → mime for text-readable files we inline. Code + data + plain docs.
_TEXT_EXTS = {
    'txt': 'text/plain', 'md': 'text/markdown', 'markdown': 'text/markdown',
    'csv': 'text/csv', 'tsv': 'text/tab-separated-values',
    'json': 'application/json', 'xml': 'application/xml',
    'yaml': 'text/yaml', 'yml': 'text/yaml', 'toml': 'text/plain',
    'log': 'text/plain', 'ini': 'text/plain', 'conf': 'text/plain', 'env': 'text/plain',
    'html': 'text/html', 'htm': 'text/html', 'css': 'text/css',
    'js': 'text/javascript', 'mjs': 'text/javascript', 'cjs': 'text/javascript',
    'jsx': 'text/javascript', 'ts': 'text/plain', 'tsx': 'text/plain',
    'py': 'text/x-python', 'sh': 'text/x-sh', 'bash': 'text/x-sh', 'zsh': 'text/x-sh',
    'rb': 'text/x-ruby', 'go': 'text/x-go', 'rs': 'text/x-rust', 'java': 'text/x-java',
    'c': 'text/x-c', 'h': 'text/x-c', 'cpp': 'text/x-c++', 'cc': 'text/x-c++',
    'sql': 'text/x-sql', 'php': 'text/x-php', 'swift': 'text/x-swift', 'kt': 'text/x-kotlin',
}
# Binary docs we accept (chip only). pdf/docx content parsing = separate stage.
_DOC_EXTS = {
    'pdf': 'application/pdf',
    'docx': 'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
    'doc': 'application/msword',
    'xlsx': 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
    'xls': 'application/vnd.ms-excel',
    'pptx': 'application/vnd.openxmlformats-officedocument.presentationml.presentation',
    'rtf': 'application/rtf', 'odt': 'application/vnd.oasis.opendocument.text',
}
# Max bytes per upload kind. Images/text small; docs a bit larger for PDFs.
_MAX_UPLOAD_BYTES = 25 * 1024 * 1024
# Cap how much text we inline into a single prompt so a huge log can't blow the
# context window. Front-end + runner both respect this; ~200k chars ≈ 50k tokens.
_MAX_INLINE_TEXT_CHARS = 200_000


def _classify_attachment(filename):
    """filename → (kind, ext_without_dot, mime). kind ∈ image|text|doc."""
    ext = (os.path.splitext(filename or '')[1].lstrip('.') or '').lower()
    if ext in _IMAGE_EXTS:
        # svg is text-on-disk but we treat it as an image attachment (thumbnail).
        mime = 'image/svg+xml' if ext == 'svg' else f'image/{"jpeg" if ext == "jpg" else ext}'
        return 'image', ext, mime
    if ext in _TEXT_EXTS:
        return 'text', ext, _TEXT_EXTS[ext]
    if ext in _DOC_EXTS:
        return 'doc', ext, _DOC_EXTS[ext]
    # Unknown extension: accept as a generic doc chip (no inlining, safest default).
    return 'doc', ext or 'bin', 'application/octet-stream'


def _widgets_snippet(widgets):
    """Server mirror of the front-end widgetsSnippet(): a short label for the
    «Збережені повідомлення» panel. Prefers title/question/subject/text/goal,
    else '[<type>]'. Used by GET /api/pinned so a pinned bubble gets a readable
    line even when it was never loaded into the browser's sliding window."""
    import re as _re
    for w in (widgets or []):
        if not isinstance(w, dict):
            continue
        for key in ('title', 'question', 'subject'):
            v = w.get(key)
            if v:
                return str(v)[:80]
        t = w.get('text')
        if t:
            return _re.sub(r'<[^>]+>', '', str(t)).strip()[:80]
        g = w.get('goal')
        if g:
            return str(g)[:80]
    if widgets and isinstance(widgets[0], dict):
        return '[' + str(widgets[0].get('type', 'message')) + ']'
    return '[повідомлення]'


def _read_text_attachment(path, max_chars=_MAX_INLINE_TEXT_CHARS):
    """Read a text-kind attachment as UTF-8 (lenient). Returns (text, truncated).

    stdlib-only. On any decode/IO error returns ('', False) so a send never
    crashes because of one unreadable file."""
    try:
        with open(path, 'rb') as f:
            raw = f.read(max_chars * 4 + 16)  # over-read so multibyte tail isn't clipped mid-char
        txt = raw.decode('utf-8', 'replace')
        if len(txt) > max_chars:
            return txt[:max_chars], True
        return txt, False
    except Exception:
        return '', False


def _transcribe_cloud(blob, mime):
    """FALLBACK transcription via OpenAI whisper-1. Returns recognized text."""
    import urllib.request, urllib.error, uuid as _uuid, time, sys as _sys
    t0 = time.time()
    api_key = _load_openai_key()
    if not api_key:
        raise RuntimeError('OPENAI_API_KEY not found')
    ext = 'webm'
    if 'mp4' in mime or 'm4a' in mime:
        ext = 'm4a'
    elif 'ogg' in mime:
        ext = 'ogg'
    elif 'wav' in mime:
        ext = 'wav'
    elif 'mpeg' in mime or 'mp3' in mime:
        ext = 'mp3'
    boundary = '----chatview' + _uuid.uuid4().hex
    CRLF = b'\r\n'
    parts = []
    def _field(name, value):
        parts.append(b'--' + boundary.encode())
        parts.append(f'Content-Disposition: form-data; name="{name}"'.encode())
        parts.append(b'')
        parts.append(str(value).encode('utf-8'))
    _field('model', 'whisper-1')
    _field('language', 'uk')
    _field('response_format', 'json')
    # Same vocabulary nudge as the local path (product names + UA/EN code-switch terms).
    _field('prompt', WHISPER_PROMPT)
    parts.append(b'--' + boundary.encode())
    parts.append(
        f'Content-Disposition: form-data; name="file"; filename="audio.{ext}"'.encode())
    parts.append(f'Content-Type: {mime}'.encode())
    parts.append(b'')
    multipart = CRLF.join(parts) + CRLF + blob + CRLF + b'--' + boundary.encode() + b'--' + CRLF
    req = urllib.request.Request(
        'https://api.openai.com/v1/audio/transcriptions',
        data=multipart,
        headers={
            'Authorization': f'Bearer {api_key}',
            'Content-Type': f'multipart/form-data; boundary={boundary}',
        },
        method='POST',
    )
    try:
        with urllib.request.urlopen(req, timeout=120) as resp:
            result = json.loads(resp.read().decode('utf-8'))
    except urllib.error.HTTPError as e:
        err_body = e.read().decode('utf-8', errors='replace')[:500]
        raise RuntimeError(f'OpenAI HTTP {e.code}: {err_body}')
    text = (result.get('text') or '').strip()
    dt = time.time() - t0
    print('[transcribe] engine=cloud took=%.2fs chars=%d' % (dt, len(text)),
          file=_sys.stderr, flush=True)
    return text


# ── Grok STT (test engine, Vova 2026-07-17) ─────────────────────────────────
# Vova wants to try xAI grok-stt as the transcription engine in his own flow and
# judge quality himself. Gated by STT_PRIMARY_GROK below. Our A/B test showed
# grok-stt mishears Ukrainian as Czech/Russian, so this is a TEST wiring with an
# easy revert (flip the flag). Local whisper.cpp + OpenAI stay as fallbacks so the
# dictaphone never fully breaks. See memory reference_stt_grok_vs_openai_ukrainian.
def _transcribe_grok(blob, mime):
    """Transcription via xAI grok-stt (https://api.x.ai/v1/stt). Returns text."""
    import urllib.request, urllib.error, uuid as _uuid, time, sys as _sys
    t0 = time.time()
    api_key = _load_xai_key()
    if not api_key:
        raise RuntimeError('XAI_API_KEY not found')
    ext = 'webm'
    if 'mp4' in mime or 'm4a' in mime:
        ext = 'm4a'
    elif 'ogg' in mime:
        ext = 'ogg'
    elif 'wav' in mime:
        ext = 'wav'
    elif 'mpeg' in mime or 'mp3' in mime:
        ext = 'mp3'
    boundary = '----chatview' + _uuid.uuid4().hex
    CRLF = b'\r\n'
    parts = []
    def _field(name, value):
        parts.append(b'--' + boundary.encode())
        parts.append(f'Content-Disposition: form-data; name="{name}"'.encode())
        parts.append(b'')
        parts.append(str(value).encode('utf-8'))
    _field('model', 'grok-stt')
    _field('language', 'uk')
    _field('format', 'json')
    parts.append(b'--' + boundary.encode())
    parts.append(
        f'Content-Disposition: form-data; name="file"; filename="audio.{ext}"'.encode())
    parts.append(f'Content-Type: {mime}'.encode())
    parts.append(b'')
    multipart = CRLF.join(parts) + CRLF + blob + CRLF + b'--' + boundary.encode() + b'--' + CRLF
    req = urllib.request.Request(
        'https://api.x.ai/v1/stt',
        data=multipart,
        headers={
            'Authorization': f'Bearer {api_key}',
            'Content-Type': f'multipart/form-data; boundary={boundary}',
        },
        method='POST',
    )
    try:
        with urllib.request.urlopen(req, timeout=120) as resp:
            result = json.loads(resp.read().decode('utf-8'))
    except urllib.error.HTTPError as e:
        err_body = e.read().decode('utf-8', errors='replace')[:500]
        raise RuntimeError(f'xAI HTTP {e.code}: {err_body}')
    text = (result.get('text') or '').strip()
    dt = time.time() - t0
    print('[transcribe] engine=grok took=%.2fs chars=%d lang=%s' % (
        dt, len(text), result.get('language', '?')),
        file=_sys.stderr, flush=True)
    return text


# TEST FLAG (Vova 2026-07-17): route the chat dictaphone through Grok STT first so
# Vova can judge Ukrainian quality live. REVERT = set this to False (one line) and
# the flow returns to local whisper.cpp -> OpenAI, exactly as before.
STT_PRIMARY_GROK = False


def _safe_pgid(pid):
    """pgid для killpg або None, якщо група чужа. Канон живе в
    chatview_platform.safe_pgid; тут тонка обгортка з інлайн-запасом, щоб
    server.py лишався робочим і при частковому чекауті.

    Коротко: сигнал групі дозволений лише коли pid САМ лідер своєї групи.
    Інакше це група раннера, і killpg клав движок усіх каналів одразу."""
    try:
        import chatview_platform as _p
        return _p.safe_pgid(pid)
    except Exception:
        pass
    if not hasattr(os, 'getpgid'):
        return None
    try:
        pid = int(pid)
        if pid <= 1:
            return None
        pgid = os.getpgid(pid)
    except (TypeError, ValueError, OSError):
        return None
    if pgid != pid or pgid == os.getpgrp():
        return None
    return pgid


def _atomic_write_json(path, obj, indent=2):
    """Write JSON atomically so the browser poller never reads a truncated half.

    `json.dump(obj, open(path, 'w'))` zeroes the file then streams bytes; a
    concurrent GET of index.json mid-write parses garbage and the UI flashes
    "connecting". Temp file + os.replace (atomic rename on POSIX) prevents it.
    pid + thread id in the temp name keeps two concurrent handler threads
    (ThreadingTCPServer) writing the same target from clobbering each other."""
    tmp = f'{path}.tmp.{os.getpid()}.{threading.get_ident()}'
    with open(tmp, 'w', encoding='utf-8') as f:
        json.dump(obj, f, ensure_ascii=False, indent=indent)
        f.flush()
        os.fsync(f.fileno())
    os.replace(tmp, path)


def _plan_summary(cid):
    """Compact {done, total} for a channel's plan.json, or None.

    Mirrors the JS planBadgeSummary (index.html ~8898): handles BOTH flat
    (plan.steps) and phased (plan.phases[].steps) shapes; a step counts done
    when step.state == 'done'. Defensive: missing file / bad JSON / no steps
    → None so the UI renders no badge (never "0/0"). stdlib-only."""
    try:
        pp = os.path.join(DIR, 'channels', cid, 'plan.json')
        if not os.path.exists(pp):
            return None
        with open(pp, encoding='utf-8') as f:
            plan = json.load(f)
        if not isinstance(plan, dict):
            return None
        phases = plan.get('phases')
        if isinstance(phases, list):
            steps = []
            for ph in phases:
                if isinstance(ph, dict):
                    steps += [s for s in (ph.get('steps') or []) if isinstance(s, dict)]
        else:
            steps = [s for s in (plan.get('steps') or []) if isinstance(s, dict)]
        total = len(steps)
        if not total:
            return None
        done = sum(1 for s in steps if s.get('state') == 'done')
        return {'done': done, 'total': total}
    except Exception:
        return None


# ── Per-model effort memory (Vova 2026-07-12) ───────────────────────────────
# One channel used to carry a SINGLE effort value shared by every model, so
# switching баланс(sonnet)→розумний(opus)→баланс lost sonnet's effort. We now
# remember effort PER model family in channels/<id>/effort-by-model.json =
# {"sonnet":"high","opus":"max",...}. The active channels/<id>/effort file stays
# the runner's source of truth (engine_sdk reads it unchanged); on a model switch
# we (1) record the outgoing model's effort into the map, (2) restore the incoming
# model's remembered effort into the active file. Keep families in sync with
# engine_sdk._MODEL_EFFORTS / CV_MODEL_EFFORT.
_EFFORT_VALID = {'low', 'medium', 'high', 'xhigh', 'max'}
_EFFORT_NO_SUPPORT = {'haiku'}   # ⚡ Швидкий — no effort knob, never remembered


def _effort_family(model):
    """Map a stored model alias / full id to an effort-memory family key."""
    m = (model or '').lower()
    for fam in ('opus', 'sonnet', 'haiku', 'fable'):
        if m == fam or ('claude-' + fam) in m or ('anthropic.claude-' + fam) in m:
            return fam
    return 'sonnet'


def _read_channel_file(ch_dir, name):
    """One-line channel config file (model / effort / permission). '' on any error."""
    try:
        with open(os.path.join(ch_dir, name), encoding='utf-8') as f:
            return f.read().strip()
    except Exception:
        return ''


def _effort_map_read(ch_dir):
    """channels/<id>/effort-by-model.json -> {family: level}. {} on any error."""
    try:
        with open(os.path.join(ch_dir, 'effort-by-model.json'), encoding='utf-8') as f:
            m = json.load(f)
        return m if isinstance(m, dict) else {}
    except Exception:
        return {}


def _effort_map_write(ch_dir, m):
    """Persist the per-model effort map (best-effort, never raises)."""
    try:
        _atomic_write_json(os.path.join(ch_dir, 'effort-by-model.json'), m)
    except Exception:
        pass


# ── GLOBAL effort default (Vova 2026-07-28) ─────────────────────────────────
# Effort used to have NO global layer: a channel with no channels/<id>/effort file
# silently fell back to the hardcoded 'medium' in engine_sdk. Every new chat is a new
# channel, so a level Vova consciously picks almost never (medium) was the standing
# default for every fresh conversation. The fallback chain is now
#   channels/<id>/effort  ->  channels/default-effort.json[family]  ->  [*]  ->  'high'
# The global file is written from the UI («Зробити дефолтом для нових чатів»); the map
# is keyed by model family (opus/sonnet/fable) plus '*' catch-all, so 'max' picked on
# Opus never lands verbatim on a model that cannot do it (_clamp_effort still guards).
# Keep this logic in sync with engine_sdk._default_effort — the runner reads the same
# file directly and must resolve identically.
_DEFAULT_EFFORT_PATH = os.path.join(DIR, 'channels', 'default-effort.json')
_EFFORT_HARD_DEFAULT = 'high'


def _default_effort_read():
    """channels/default-effort.json -> {family|'*': level}. {} on any error."""
    try:
        with open(_DEFAULT_EFFORT_PATH, encoding='utf-8') as f:
            m = json.load(f)
        return m if isinstance(m, dict) else {}
    except Exception:
        return {}


def _default_effort_write(m):
    """Persist the global default-effort map (best-effort, never raises)."""
    try:
        _atomic_write_json(_DEFAULT_EFFORT_PATH, m)
    except Exception:
        pass


def _default_effort_for(model):
    """Global default effort for a model: map[family] -> map['*'] -> hard default."""
    m = _default_effort_read()
    fam = _effort_family(model)
    for key in (fam, '*'):
        v = str(m.get(key, '')).strip().lower()
        if v in _EFFORT_VALID or v == 'ultra':
            return v
    return _EFFORT_HARD_DEFAULT


def _effective_effort(ch_dir, model=''):
    """Effort actually used for a channel: its own file, else the global default.
    Mirrors engine_sdk, so what the UI shows is what the turn runs with."""
    own = _read_channel_file(ch_dir, 'effort').lower()
    if own in _EFFORT_VALID or own == 'ultra':
        return own
    return _default_effort_for(model or _read_channel_file(ch_dir, 'model'))


def _merged_registry():
    """Merge the committed channel registry with this machine's local overlay.

    channels/index.json = curated, committed list of Vova's real topic tabs.
    channels/index.local.json = gitignored, auto cc-* session channels created
    by the SessionStart hook (per-machine runtime, must never pollute the repo).
    Committed entries come first, then any local entry whose id is not already
    present. Either file may be missing / malformed; we degrade gracefully."""
    out = []
    seen = set()
    ch_root = os.path.join(DIR, 'channels')
    for name in ('index.json', 'index.local.json'):
        fpath = os.path.join(ch_root, name)
        if not os.path.exists(fpath):
            continue
        try:
            with open(fpath, encoding='utf-8') as f:
                items = json.load(f)
        except Exception:
            items = []
        if not isinstance(items, list):
            continue
        for c in items:
            cid = c.get('id') if isinstance(c, dict) else None
            if not cid or cid in seen:
                continue
            seen.add(cid)
            # updatedAt = час останнього едіту каналу = mtime файлу повідомлень
            # channels/<id>/index.json (оновлюється на кожне нове/змінене
            # повідомлення). Клієнт сортує списки каналів за цим спадно, щоб
            # щойно активний чат був зверху. 0 = канал без жодного повідомлення.
            try:
                mp = os.path.join(ch_root, cid, 'index.json')
                c['updatedAt'] = os.path.getmtime(mp) if os.path.exists(mp) else 0
            except Exception:
                c['updatedAt'] = 0
            # plan progress for the per-chat badge in the switcher + launcher
            # list. {done,total} or None (UI hides the badge when null/total 0).
            c['plan'] = _plan_summary(cid)
            out.append(c)
    return out


# ===========================================================================
# HELPERS (Skill Store, "Помічники") — install/uninstall catalog skills into
# .claude/skills. Distinct namespace from /api/skills (the slash autocomplete).
#   catalog manifest = DIR/skills-library/index.json
#   catalog folders  = DIR/skills-library/<skill.path>/
#   install target   = REPO_ROOT/.claude/skills/<id>/
# ===========================================================================
import re as _re_helpers

_HELPERS_LIBRARY_DIR = os.path.join(DIR, 'skills-library')
_HELPERS_INSTALL_ROOT = os.path.join(
    os.path.dirname(os.path.dirname(os.path.dirname(DIR))),
    '.claude', 'skills')
_HELPER_ID_RE = _re_helpers.compile(r'^[a-z0-9][a-z0-9-]*$')


def _helpers_manifest():
    """Read skills-library/index.json. Returns dict with categories + skills."""
    with open(os.path.join(_HELPERS_LIBRARY_DIR, 'index.json'),
              encoding='utf-8') as f:
        return json.load(f)


# ── Помічники redesign: persona catalog (worker + toggleable capabilities) ──
_PERSONAS_CAT = os.path.join(_HELPERS_LIBRARY_DIR, 'personas-catalog.json')
# Port-scoped state: the LIVE server (:5555) owns personas-state.json. A test
# server on any other port (e.g. demo recording on :5599) gets its OWN file
# (personas-state.<port>.json), so wiping/recreating test state can NEVER touch
# the user's real team + custom помічники. This is the root-cause fix for custom
# helpers vanishing: the feature-demo skill used to `rm` the shared live file.
_PERSONAS_STATE = os.path.join(
    DIR, 'personas-state.json' if PORT == 5555 else f'personas-state.{PORT}.json')


def _personas_catalog():
    """Curated помічники catalog: personas + their capabilities (вміння)."""
    with open(_PERSONAS_CAT, encoding='utf-8') as f:
        return json.load(f)


# Backup sidecar (also *.json so .gitignore's tools/viz/chat/*.json covers it).
# Belt-and-suspenders: if the main file is ever deleted or truncated by some
# external tool, the next read self-heals from this backup so the user's team +
# custom помічники survive.
_PERSONAS_STATE_BAK = _PERSONAS_STATE[:-5] + '.bak.json' if _PERSONAS_STATE.endswith('.json') \
    else _PERSONAS_STATE + '.bak'


def _personas_state():
    """Per-persona enabled capabilities: {personaId: {capId: bool}}. Absent
    persona => use the capability's `popular` default. Self-heals from the
    backup if the live file went missing/empty (e.g. an external rm)."""
    try:
        with open(_PERSONAS_STATE, encoding='utf-8') as f:
            data = json.load(f)
        if data:                       # non-empty wins
            return data
    except Exception:
        pass
    # main missing/empty/corrupt → try the backup and restore it
    try:
        with open(_PERSONAS_STATE_BAK, encoding='utf-8') as f:
            bak = json.load(f)
        if bak:
            try:
                _personas_state_save(bak)   # restore the live file
            except Exception:
                pass
            return bak
    except Exception:
        pass
    return {}


def _personas_state_save(state):
    tmp = _PERSONAS_STATE + '.tmp'
    with open(tmp, 'w', encoding='utf-8') as f:
        json.dump(state, f, ensure_ascii=False, indent=1)
    os.replace(tmp, _PERSONAS_STATE)
    # keep a backup copy for self-heal (best-effort, never block the save)
    try:
        if state:
            with open(_PERSONAS_STATE_BAK, 'w', encoding='utf-8') as f:
                json.dump(state, f, ensure_ascii=False, indent=1)
    except Exception:
        pass


_PERSONAS_ONB = os.path.join(_HELPERS_LIBRARY_DIR, 'onboarding.json')


def _personas_onboarding():
    """Wizard config: roles (role -> default team) + acquisition sources."""
    with open(_PERSONAS_ONB, encoding='utf-8') as f:
        return json.load(f)


def _openai_key():
    """OPENAI_API_KEY from shared-knowledge/.env (walk up dirs).
    🔒 STRICT BYOK: off in a packaged build (CHATVIEW_HOME set) — see _load_env_key."""
    if os.environ.get('CHATVIEW_HOME'):
        return ''
    search = DIR
    for _ in range(6):
        ef = os.path.join(search, '.env')
        if os.path.exists(ef):
            with open(ef) as f:
                for line in f:
                    if line.startswith('OPENAI_API_KEY='):
                        return line.split('=', 1)[1].strip()
        search = os.path.dirname(search)
    return ''


def _personas_custom(state):
    c = state.get('_custom')
    return c if isinstance(c, list) else []


# ===== Real Claude Code agents → personas (Stage 1, read-only) =====
# The visual Помічники modal must reflect the REAL agents living in
# .claude/agents/*.md. We surface each agent file as a persona so it shows up
# ALONGSIDE the curated catalog + user custom personas. Read-only: we never
# touch the agent files here. id is prefixed "agent:" to avoid colliding with
# the 80 catalog ids. capabilities stay empty (Stage 4 wires вміння/skills).

def _agent_frontmatter(text):
    """Tiny YAML-frontmatter parser matching the repo's manual style (no pip
    deps). Reads the leading `---` ... `---` block and returns its `key: value`
    pairs, stripping surrounding quotes. Body (the system prompt) is ignored."""
    out = {}
    if not text.startswith('---'):
        return out
    rest = text[3:]
    end = rest.find('\n---')
    if end == -1:
        return out
    block = rest[:end]
    lines = block.splitlines()
    i = 0
    while i < len(lines):
        raw = lines[i]
        line = raw.strip()
        i += 1
        if not line or line.startswith('#') or ':' not in line:
            continue
        # Only treat a line as a key:value when the key is at column 0 (un-indented).
        # Indented lines are continuations of a block scalar, handled below.
        if raw[:1] in (' ', '\t'):
            continue
        key, val = line.split(':', 1)
        key = key.strip()
        val = val.strip()
        # YAML block scalar (folded `>` / literal `|`, with optional -/+ chomp):
        # gather the following indented lines and fold them into one string.
        if val and val[0] in '>|' and val.rstrip('+-') in ('>', '|'):
            folded = val[0] == '>'
            buf = []
            while i < len(lines) and (lines[i].strip() == '' or lines[i][:1] in (' ', '\t')):
                buf.append(lines[i].strip())
                i += 1
            val = (' ' if folded else '\n').join(b for b in buf if b != '').strip()
        elif len(val) >= 2 and val[0] in '"\'' and val[-1] == val[0]:
            val = val[1:-1]
        if key:
            out[key] = val
    return out


def _personas_from_agents():
    """Scan .claude/agents/*.md and map each → a persona object. repo_root is
    resolved from this file's location (tools/viz/chat -> shared-knowledge),
    never a hardcoded user path."""
    repo_root = os.path.dirname(os.path.dirname(os.path.dirname(DIR)))
    agents_dir = os.path.join(repo_root, '.claude', 'agents')
    out = []
    try:
        names = sorted(f for f in os.listdir(agents_dir) if f.endswith('.md'))
    except Exception:
        return out
    for fn in names:
        fp = os.path.join(agents_dir, fn)
        try:
            with open(fp, encoding='utf-8') as f:
                fm = _agent_frontmatter(f.read())
        except Exception:
            continue
        stem = fn[:-3]
        name = fm.get('name') or stem
        desc = fm.get('description') or ''
        # First sentence if the description is long, keep it scannable.
        oneliner = desc.strip()
        if len(oneliner) > 120:
            dot = oneliner.find('. ')
            oneliner = (oneliner[:dot + 1] if dot != -1 else oneliner[:117] + '…')
        out.append({
            'id': 'agent:' + stem,
            'name': name,
            'oneliner': oneliner,
            'cat': 'team',
            'emoji': '🤖',
            'capabilities': [],
            'source': 'agent',
            'agentFile': os.path.join('.claude', 'agents', fn),
        })
    return out


# The Помічники UI must also surface the REAL Claude Code skills living in
# .claude/skills/<name>/SKILL.md as вміння (capabilities). Read direction only:
# we display them, never mutate the files and never wire toggles here (that is a
# LATER write stage). Mirrors _personas_from_agents() exactly: same frontmatter
# parser, repo_root resolved from this file's location, id prefixed "skill:".

def _skill_examples(text):
    """Parse the «💡 Приклади використання» section from a SKILL.md body into a
    list of {say, does}. Each bullet is `- «фраза» → результат` (arrow may be →
    or ->). Powers the «як викликати» block in the Помічники UI. Returns [] when
    the skill has no examples section yet."""
    lines = text.splitlines()
    start = None
    for idx, ln in enumerate(lines):
        s = ln.strip()
        if s.startswith('#') and 'Приклади використання' in s:
            start = idx + 1
            break
    if start is None:
        return []
    out = []
    for ln in lines[start:]:
        s = ln.strip()
        if s.startswith('#'):          # next heading → section done
            break
        if not s.startswith('- '):
            continue
        item = s[2:].strip()
        arrow = '→' if '→' in item else ('->' if '->' in item else None)
        if arrow:
            say, does = item.split(arrow, 1)
        else:
            say, does = item, ''
        say = say.strip().strip('«»"\'').strip()
        does = does.strip()
        if say:
            out.append({'say': say, 'does': does})
    return out


def _skills_from_disk():
    """Scan .claude/skills/*/SKILL.md → list of skill objects. repo_root resolved
    from this file's location (tools/viz/chat -> shared-knowledge), never a
    hardcoded user path. Reuses _agent_frontmatter (no pip deps)."""
    repo_root = os.path.dirname(os.path.dirname(os.path.dirname(DIR)))
    skills_dir = os.path.join(repo_root, '.claude', 'skills')
    out = []
    try:
        names = sorted(d for d in os.listdir(skills_dir)
                       if os.path.isfile(os.path.join(skills_dir, d, 'SKILL.md')))
    except Exception:
        return out
    for dirname in names:
        fp = os.path.join(skills_dir, dirname, 'SKILL.md')
        try:
            with open(fp, encoding='utf-8') as f:
                raw = f.read()
            fm = _agent_frontmatter(raw)
        except Exception:
            continue
        name = fm.get('name') or dirname
        desc = (fm.get('description') or '').strip()
        # First sentence if the description is long, keep it scannable.
        oneliner = desc
        if len(oneliner) > 120:
            dot = oneliner.find('. ')
            oneliner = (oneliner[:dot + 1] if dot != -1 else oneliner[:117] + '…')
        out.append({
            'id': 'skill:' + dirname,
            'name': name,
            'desc': oneliner,
            'examples': _skill_examples(raw),
            'source': 'skill',
            'skillFile': os.path.join('.claude', 'skills', dirname, 'SKILL.md'),
        })
    return out


def _personas_find(pid, state):
    """Lookup a persona by id across the static catalog + user custom + real agents."""
    return next((p for p in (_personas_catalog().get('personas', [])
                             + _personas_custom(state)
                             + _personas_from_agents())
                 if p.get('id') == pid), None)


# ===== Bot avatar params (DiceBear bottts) — role -> personality =====
# Canonical VALID option names pulled straight from @dicebear/collection@9
# schema (verified, not guessed). DiceBear silently DROPS unknown values, so
# only the names below ever produce an on-theme bot; anything else degrades to
# a default-looking robot. The same registry is mirrored on the front end.
_BOTTTS_OPTS = {
    'eyes': ['bulging', 'dizzy', 'eva', 'frame1', 'frame2', 'glow', 'happy',
             'hearts', 'robocop', 'round', 'roundFrame01', 'roundFrame02',
             'sensor', 'shade01'],
    'top': ['antenna', 'antennaCrooked', 'bulb01', 'glowingBulb01',
            'glowingBulb02', 'horns', 'lights', 'pyramid', 'radar'],
    'mouth': ['bite', 'diagram', 'grill01', 'grill02', 'grill03', 'smile01',
              'smile02', 'square01', 'square02'],
    'sides': ['antenna01', 'antenna02', 'cables01', 'cables02', 'round',
              'square', 'squareAssymetric'],
    'texture': ['camo01', 'camo02', 'circuits', 'dirty01', 'dirty02', 'dots',
                'grunge01', 'grunge02'],
}
# Role vibe presets: category -> {baseColor + on-theme option arrays}. Colours
# match the front-end _BOTCOLOR table. Each set is curated so the bot READS as
# the role (analyst = sensors + radar + circuits, designer = bulbs, etc).
#
# Archetype design notes (характер бота читається по ролі):
#   marketing/sales — теплі, сміливі, усміхнені (помаранч/жовто-зел): glow/happy
#       очі, antenna/lights антена, усмішки smile01/02, легка texture dots.
#   content/design  — креативні, виразні (фіолет/рожевий): hearts/eva очі,
#       лампочки glowingBulb, груба texture grunge, усмішки/bite.
#   research/analyst — серйозні, технічні (синій): sensor/roundFrame/robocop очі,
#       radar/pyramid топ, circuits, рот-діаграма diagram/grill.
#   tech/build      — техно (зелений): frame/robocop/eva очі, antennaCrooked/horns,
#       circuits, grill/diagram рот.
#   strategy/business — сміливі лідери (індиго): robocop/shade очі, horns/pyramid,
#       circuits, square/grill рот.
#   productivity/learning/life — дружні, прості, теплі.
# Пули по 2-4 опції: реролл (новий seed) дає РІЗНИЙ бот, що лишається «в типажі».
_BOT_PRESETS = {
    'marketing':    {'baseColor': 'f97316', 'eyes': ['glow', 'happy', 'shade01'],     'top': ['antenna', 'lights', 'antennaCrooked'], 'texture': ['dots', 'camo01'],       'mouth': ['smile01', 'smile02', 'grill01']},
    'sales':        {'baseColor': '22c55e', 'eyes': ['happy', 'bulging', 'glow'],     'top': ['lights', 'antenna', 'bulb01'],         'texture': ['dots'],                  'mouth': ['smile01', 'smile02', 'grill01']},
    'content':      {'baseColor': 'a855f7', 'eyes': ['hearts', 'eva', 'roundFrame02'], 'top': ['glowingBulb01', 'glowingBulb02', 'bulb01'], 'texture': ['grunge01', 'grunge02'], 'mouth': ['smile02', 'bite', 'smile01']},
    'business':     {'baseColor': '6366f1', 'eyes': ['robocop', 'shade01', 'sensor'], 'top': ['pyramid', 'radar', 'horns'],           'texture': ['circuits'],              'mouth': ['grill02', 'square01', 'diagram']},
    'strategy':     {'baseColor': '6366f1', 'eyes': ['shade01', 'robocop', 'sensor'], 'top': ['radar', 'pyramid', 'horns'],           'texture': ['circuits', 'dots'],      'mouth': ['grill02', 'diagram', 'square02']},
    'research':     {'baseColor': '2563eb', 'eyes': ['sensor', 'roundFrame01', 'robocop'], 'top': ['radar', 'antenna', 'pyramid'],    'texture': ['circuits', 'dots'],      'mouth': ['diagram', 'grill01', 'grill02']},
    'tech':         {'baseColor': '10b981', 'eyes': ['frame1', 'frame2', 'eva'],      'top': ['antennaCrooked', 'antenna', 'lights'], 'texture': ['circuits'],              'mouth': ['diagram', 'grill03', 'grill02']},
    'build':        {'baseColor': '10b981', 'eyes': ['frame1', 'robocop', 'eva'],     'top': ['antennaCrooked', 'horns', 'antenna'],  'texture': ['circuits'],              'mouth': ['grill03', 'diagram', 'grill02']},
    'productivity': {'baseColor': '14b8a6', 'eyes': ['round', 'happy', 'frame2'],     'top': ['lights', 'antenna', 'radar'],          'texture': ['dots'],                  'mouth': ['smile01', 'grill01', 'square01']},
    'learning':     {'baseColor': '0ea5e9', 'eyes': ['happy', 'eva', 'round'],        'top': ['bulb01', 'glowingBulb01', 'antenna'],  'texture': ['dots'],                  'mouth': ['smile01', 'smile02']},
    'life':         {'baseColor': 'ec4899', 'eyes': ['hearts', 'happy', 'round'],     'top': ['bulb01', 'horns', 'glowingBulb02'],    'texture': ['grunge02', 'dots'],      'mouth': ['smile02', 'bite', 'smile01']},
}
# Keyword -> category, for the no-AI fallback (matched against the raw desc).
_BOT_KEYWORDS = [
    ('marketing', ['маркет', 'реклам', 'воронк', 'кампан', 'просуван', 'трафік', 'лід', 'ads', 'smm', 'таргет']),
    ('sales',     ['продаж', 'sales', 'клієнт', 'угод', 'pricing', 'оффер', 'комерц', 'перемовин', 'crm']),
    ('content',   ['контент', 'пост', 'instagram', 'інстаграм', 'відео', 'сторіз', 'reels', 'блог', 'презентац', 'дизайн', 'креатив', 'банер', 'візуал', 'логотип', 'обкладин']),
    ('research',  ['аналіз', 'аналітик', 'конкурент', 'дослідж', 'ресерч', 'звіт', 'метрик', 'дані', 'статистик', 'ринок', 'тренд']),
    ('tech',      ['код', 'розробк', 'програм', 'api', 'баг', 'скрипт', 'автоматизац', 'інтеграц', 'девелоп', 'бекенд', 'фронтенд', 'деплой', 'docker', 'sql', 'бот']),
    ('strategy',  ['стратег', 'бізнес', 'план', 'gtm', 'okr', 'масштаб', 'позиціонуван', 'модель']),
    ('learning',  ['навчан', 'курс', 'урок', 'освіт', 'репетит', 'пояснюва', 'вивч']),
    ('productivity', ['органайз', 'задач', 'розкла', 'нагадуван', 'продуктивн', 'таск', 'календар', 'планувальник']),
    ('life',      ['здоров', 'спорт', 'рецепт', 'подорож', 'фінанс', 'особист', 'хобі', 'настрій']),
]


def _bot_params_from_cat(cat, seed_salt=''):
    """Build a fully-valid avatarParams dict for a category. Always returns a
    dict the front end can render directly (never empty/None)."""
    preset = _BOT_PRESETS.get(cat) or _BOT_PRESETS['productivity']
    return {
        'baseColor': preset['baseColor'],
        'eyes': list(preset['eyes']),
        'top': list(preset['top']),
        'texture': list(preset['texture']),
        'mouth': list(preset['mouth']),
    }


def _bot_params_fallback(desc, cat=None):
    """No-AI fallback: pick a category by keyword match on the description,
    then return that category's preset params. `cat` (if the LLM already gave a
    valid one) takes priority over keyword matching."""
    if cat in _BOT_PRESETS:
        return _bot_params_from_cat(cat)
    low = (desc or '').lower()
    for c, kws in _BOT_KEYWORDS:
        if any(k in low for k in kws):
            return _bot_params_from_cat(c)
    return _bot_params_from_cat('productivity')


def _bot_params_sanitize(raw, desc, cat):
    """Take whatever the LLM returned for avatarParams and force it valid:
    keep only known option names, drop empties, fill any missing field from the
    category preset. Guarantees a renderable, on-theme dict."""
    base = _bot_params_from_cat(cat if cat in _BOT_PRESETS else None)
    if not isinstance(raw, dict):
        return _bot_params_fallback(desc, cat)
    out = {}
    # baseColor: accept a 6-hex string (with/without #), else preset colour.
    bc = raw.get('baseColor')
    if isinstance(bc, list) and bc:
        bc = bc[0]
    if isinstance(bc, str):
        bc = bc.lstrip('#').strip()
    out['baseColor'] = bc if (isinstance(bc, str) and len(bc) == 6
                              and all(ch in '0123456789abcdefABCDEF' for ch in bc)) else base['baseColor']
    for field in ('eyes', 'top', 'texture', 'mouth'):
        valid = _BOTTTS_OPTS[field]
        vals = raw.get(field)
        if isinstance(vals, str):
            vals = [vals]
        keep = [v for v in (vals or []) if v in valid]
        out[field] = keep if keep else list(base[field])
    return out


def _helpers_safe_target(skill_id):
    """Validate id and resolve the install target, guaranteeing it stays inside
    .claude/skills. Returns the absolute target dir or raises ValueError."""
    if not isinstance(skill_id, str) or not _HELPER_ID_RE.match(skill_id):
        raise ValueError('bad id')
    root = os.path.realpath(_HELPERS_INSTALL_ROOT)
    target = os.path.realpath(os.path.join(_HELPERS_INSTALL_ROOT, skill_id))
    if target != os.path.join(root, skill_id) and \
            not target.startswith(root + os.sep):
        raise ValueError('path traversal')
    if os.path.dirname(target) != root:
        raise ValueError('path traversal')
    return target


def _helpers_git_install(skill, target):
    """Install a REMOTE catalog skill into .claude/skills/<id>/. Files only, no
    code execution: single-file /blob/ skills fetched raw as SKILL.md, /tree/
    folders via git sparse-checkout, bare repo roots via shallow clone.

    install == 'npx' is davila7's distribution convenience, NOT a hard requirement.
    We NEVER run npx (it would execute external code). Every catalog npx skill
    points at a /blob/ .md or a /tree/ folder, so we fetch those files directly and
    they install safely. The npx guidance at the bottom only fires for a
    hypothetical npx skill with no fetchable file url.
    Returns a dict ready to JSON back to the client."""
    import urllib.request
    url = (skill or {}).get('url') or ''
    install = (skill or {}).get('install') or ''
    if '/blob/' in url:
        # github.com/OWNER/REPO/blob/BRANCH/PATH -> raw.githubusercontent.com/OWNER/REPO/BRANCH/PATH
        raw = url.replace('https://github.com/',
                          'https://raw.githubusercontent.com/', 1)
        raw = raw.replace('/blob/', '/', 1)
        try:
            req = urllib.request.Request(
                raw, headers={'User-Agent': 'chatview-skillstore'})
            with urllib.request.urlopen(req, timeout=20) as r:
                data = r.read()
        except Exception as e:
            return {'ok': False, 'remote': True, 'url': url,
                    'error': f'не вдалось завантажити: {e}'}
        if not data or len(data) < 20:
            return {'ok': False, 'remote': True, 'url': url,
                    'error': 'порожній або надто малий файл за URL'}
        os.makedirs(target, exist_ok=True)
        with open(os.path.join(target, 'SKILL.md'), 'wb') as f:
            f.write(data)
        return {'ok': True, 'installed': True, 'remote': True,
                'bytes': len(data), 'note': 'fetched single-file skill'}
    if '/tree/' in url:
        # github.com/OWNER/REPO/tree/BRANCH/SUBDIR -> sparse-checkout that subdir
        # of a (possibly huge) monorepo, then copy it into the install target.
        # No code runs; this only fetches files. Branch is assumed single-segment
        # (main/master), which holds for every catalog entry.
        import subprocess as _sp, tempfile as _tf, shutil as _sh, re as _re2
        m = _re2.match(
            r'https://github\.com/([^/]+)/([^/]+)/tree/([^/]+)/(.+)$', url)
        if not m:
            return {'ok': False, 'remote': True, 'url': url,
                    'error': 'не розпізнав github /tree/ URL'}
        owner, repo, branch, sub = m.group(1), m.group(2), m.group(3), m.group(4)
        repo_url = f'https://github.com/{owner}/{repo}.git'
        tmp = _tf.mkdtemp(prefix='skstore-')
        rd = os.path.join(tmp, 'repo')
        try:
            _sp.run(['git', 'clone', '--filter=blob:none', '--no-checkout',
                     '--depth', '1', '-b', branch, repo_url, rd],
                    check=True, capture_output=True, timeout=120)
            _sp.run(['git', '-C', rd, 'sparse-checkout', 'set', '--no-cone', sub],
                    check=True, capture_output=True, timeout=60)
            _sp.run(['git', '-C', rd, 'checkout'],
                    check=True, capture_output=True, timeout=60)
            srcdir = os.path.join(rd, sub)
            if not os.path.isdir(srcdir) or not os.listdir(srcdir):
                return {'ok': False, 'remote': True, 'url': url,
                        'error': 'підпапку не знайдено після sparse-checkout'}
            os.makedirs(target, exist_ok=True)
            _sh.copytree(srcdir, target, dirs_exist_ok=True)
            n = sum(len(fs) for _, _, fs in os.walk(target))
            return {'ok': True, 'installed': True, 'remote': True,
                    'files': n, 'note': 'sparse-checkout folder skill'}
        except _sp.TimeoutExpired:
            return {'ok': False, 'remote': True, 'url': url,
                    'error': 'git sparse-checkout перевищив таймаут'}
        except _sp.CalledProcessError as e:
            tail = (e.stderr or b'').decode('utf-8', 'replace')[:200]
            return {'ok': False, 'remote': True, 'url': url,
                    'error': f'git помилка: {tail}'}
        finally:
            _sh.rmtree(tmp, ignore_errors=True)
    import re as _re3
    _root = _re3.match(r'https://github\.com/([^/]+)/([^/]+?)(?:\.git)?/?$', url)
    if _root:
        # Bare repo root (whole repo IS the skill): shallow clone, drop .git,
        # copy everything into the install target. Files only, no code runs.
        import subprocess as _sp, tempfile as _tf, shutil as _sh
        owner, repo = _root.group(1), _root.group(2)
        repo_url = f'https://github.com/{owner}/{repo}.git'
        tmp = _tf.mkdtemp(prefix='skstore-')
        rd = os.path.join(tmp, 'repo')
        try:
            _sp.run(['git', 'clone', '--depth', '1', repo_url, rd],
                    check=True, capture_output=True, timeout=120)
            _sh.rmtree(os.path.join(rd, '.git'), ignore_errors=True)
            if not os.listdir(rd):
                return {'ok': False, 'remote': True, 'url': url,
                        'error': 'порожній репозиторій'}
            os.makedirs(target, exist_ok=True)
            _sh.copytree(rd, target, dirs_exist_ok=True)
            n = sum(len(fs) for _, _, fs in os.walk(target))
            return {'ok': True, 'installed': True, 'remote': True,
                    'files': n, 'note': 'cloned whole repo'}
        except _sp.TimeoutExpired:
            return {'ok': False, 'remote': True, 'url': url,
                    'error': 'git clone перевищив таймаут'}
        except _sp.CalledProcessError as e:
            tail = (e.stderr or b'').decode('utf-8', 'replace')[:200]
            return {'ok': False, 'remote': True, 'url': url,
                    'error': f'git помилка: {tail}'}
        finally:
            _sh.rmtree(tmp, ignore_errors=True)
    if install == 'npx':
        return {'ok': False, 'remote': True, 'url': url, 'install': install,
                'error': 'npx-скіл без файлового URL. Постав вручну (ми не запускаємо чужий код).'}
    return {'ok': False, 'remote': True, 'url': url, 'install': install,
            'error': 'Невідомий формат URL скіла.'}


def _helpers_ensure_skill_md(target, skill):
    """Guarantee target/SKILL.md exists so Claude can actually load the skill.
    Single-file installs already write a root SKILL.md (left untouched). For
    folder/repo installs whose SKILL.md sits deeper (or who ship agent .md files
    instead), synthesize a minimal root SKILL.md with frontmatter from the catalog
    that points at the fetched files. Multi-skill plugins keep their nested
    SKILL.md files; this only adds a discoverable root entry."""
    root_md = os.path.join(target, 'SKILL.md')
    if os.path.exists(root_md):
        return
    nested = []
    try:
        for dp, _dirs, fs in os.walk(target):
            for f in fs:
                if f == 'SKILL.md':
                    nested.append(os.path.relpath(os.path.join(dp, f), target))
    except Exception:
        pass
    sid = (skill or {}).get('id') or 'skill'
    name = (skill or {}).get('name') or sid
    desc = ((skill or {}).get('description') or name).replace('\n', ' ').strip()[:300]
    desc_yaml = desc.replace('"', '\\"')
    url = (skill or {}).get('url') or ''
    lines = ['---', f'name: {sid}', f'description: "{desc_yaml}"', '---', '',
             f'# {name}', '']
    if url:
        lines += [f'Джерело: {url}', '']
    if nested:
        lines.append('Скіли в цьому пакеті:')
        lines += [f'- {n}' for n in sorted(nested)]
    else:
        try:
            tops = sorted(os.listdir(target))[:20]
        except Exception:
            tops = []
        lines.append('Файли пакета:')
        lines += [f'- {t}' for t in tops]
    try:
        with open(root_md, 'w', encoding='utf-8') as f:
            f.write('\n'.join(lines) + '\n')
    except Exception:
        pass


# ===========================================================================
# CANVAS MERGE (Phase 1) — serve the built tldraw canvas + its data API from
# THIS server so it loads same-origin under /canvas/ inside ChatView. Ported
# faithfully from tools/canvas-cmd/server/index.ts (the Express data server).
#
# Layout (relative to this file = tools/viz/chat):
#   ../../canvas-cmd/dist   -> built SPA (vite base=/canvas/), served at /canvas/
#   CANVAS_DATA_DIR         -> canvas-state.json + data/*.json (env-overridable
#                              so tests point at a COPY, default canvas-cmd/data)
#   REPO_ROOT               -> shared-knowledge root, for file-preview/file-content
# ===========================================================================
REPO_ROOT = os.path.dirname(os.path.dirname(os.path.dirname(DIR)))

# CLAUDE_REPO_ROOT: the cwd claude actually runs in (runner.py spawns claude with
# cwd=this). It is what names the ~/.claude/projects/<encoded>/ folder, so the
# export/import re-encoding must use THIS, not the file-preview REPO_ROOT above.
# Mirror runner.py exactly: desktop (CHATVIEW_HOME set) -> the home itself;
# dev/live -> shared-knowledge root. In dev they coincide.
CLAUDE_REPO_ROOT = DIR if os.environ.get('CHATVIEW_HOME') else REPO_ROOT

# Re-use the runner's encoder so the ~/.claude/projects folder naming never drifts
# between resume-detection (runner) and export/import (transfer). runner.py is
# import-safe (no top-level side effects outside its __main__ guard).
try:
    import runner as _runner_mod
    _encode_project_dir = _runner_mod._encode_project_dir
except Exception:  # pragma: no cover - defensive; keeps server bootable standalone
    def _encode_project_dir(repo_root):
        enc = repo_root.replace('\\', '-').replace('/', '-').replace(':', '-')
        if sys.platform == 'win32' and enc:
            enc = enc[0].lower() + enc[1:]
        return enc

import transfer as _transfer


def _resolve_canvas_base():
    """Find the canvas-cmd dir, robust across the repo + the shareable archive.

    Two layouts ship this chat server:
      - Vova's repo:   tools/viz/chat -> canvas is at ../../canvas-cmd (2 up)
      - Shareable archive (FLAT): <root>/chat + <root>/canvas-cmd siblings,
                                  so canvas is at ../canvas-cmd (1 up)
    Honor an explicit CANVAS_DIST env override first; otherwise try the REPO
    candidate FIRST (so nothing changes for Vova), then the archive candidate.
    Return (dist_path, base_dir) where base_dir holds dist/ + data/."""
    env_dist = os.environ.get('CANVAS_DIST')
    if env_dist:
        return env_dist, os.path.dirname(env_dist)
    repo_base = os.path.join(os.path.dirname(os.path.dirname(DIR)), 'canvas-cmd')  # ../../canvas-cmd
    archive_base = os.path.join(os.path.dirname(DIR), 'canvas-cmd')                # ../canvas-cmd
    for base in (repo_base, archive_base):
        if os.path.isdir(os.path.join(base, 'dist')):
            return os.path.join(base, 'dist'), base
    # Neither built yet: default to the repo layout (preserves prior behavior).
    return os.path.join(repo_base, 'dist'), repo_base


CANVAS_DIST, _CANVAS_BASE = _resolve_canvas_base()
CANVAS_DATA_DIR = os.environ.get(
    'CANVAS_DATA_DIR',
    os.path.join(_CANVAS_BASE, 'data'),
)
CANVAS_FILE = os.path.join(CANVAS_DATA_DIR, 'canvas-state.json')
BOOKMARKS_FILE = os.path.join(CANVAS_DATA_DIR, 'bookmarks.json')

def _resolve_v2_dist():
    """Find the built V2 (React) bundle. D14 cutover: '/' serves V2 when this
    dist exists. Layouts, in order: explicit CHATVIEW_V2_DIST env; the repo
    sibling (~/WebstormProjects/{shared-knowledge,chatview}); a flat archive
    sibling (<root>/chatview); a bundle copied into the chat dir (v2-dist/)."""
    env_dist = os.environ.get('CHATVIEW_V2_DIST')
    if env_dist:
        return env_dist
    for cand in (
        os.path.join(os.path.dirname(REPO_ROOT), 'chatview', 'dist'),
        os.path.join(os.path.dirname(DIR), 'chatview', 'dist'),
        os.path.join(DIR, 'v2-dist'),
    ):
        if os.path.isfile(os.path.join(cand, 'index.html')):
            return cand
    return os.path.join(os.path.dirname(REPO_ROOT), 'chatview', 'dist')


V2_DIST = _resolve_v2_dist()
# Kill switch: CHATVIEW_V1=1 puts the vanilla page back on '/' without a code
# change. With V2 on, the vanilla page stays reachable at /v1 for a one-URL
# rollback.
V2_ON = not os.environ.get('CHATVIEW_V1')


def _v2_index_path():
    """Absolute path of the V2 entry html, or '' when V2 is off / not built."""
    if not V2_ON:
        return ''
    p = os.path.join(V2_DIST, 'index.html')
    return p if os.path.isfile(p) else ''


FRACTIONAL_INDEX_CJS = os.path.join(DIR, 'fractional-index.cjs')
CANVAS_NODE_MODULES = os.path.join(_CANVAS_BASE, 'node_modules')
ALLOWED_FILE_PREFIXES = ('projects/', 'processes/', 'decisions/', 'data/')

# Phase B — tool-permission gate. The PreToolUse hook (hooks/perm-gate.cjs) POSTs
# a request here; the UI shows an Allow/Deny card and POSTs the decision; the hook
# polls /api/perm-status. In-memory (one server process serves both hook + UI).
_perm = {}                       # requestId -> {channel, tool, input, decision}
_perm_lock = threading.Lock()

_canvas_lock = threading.Lock()


def _load_canvas_state():
    """Read canvas-state.json into the in-memory authoritative store.

    Mirrors server/index.ts startup: parse {store, schema}, default empty on any
    error. version starts at 1; we do NOT replicate the startup file backup or
    page-seeding (Phase 1 keeps it minimal — the live data already has its pages,
    and tests run against a copy)."""
    store, schema = {}, None
    try:
        if os.path.exists(CANVAS_FILE):
            with open(CANVAS_FILE, encoding='utf-8') as f:
                raw = f.read()
            if raw.strip():
                j = json.loads(raw)
                if isinstance(j, dict):
                    store = j.get('store') or {}
                    schema = j.get('schema')
    except Exception as e:
        print(f'[canvas] failed to parse canvas-state.json, starting empty: {e}')
    return {'store': store, 'schema': schema, 'version': 1}


_canvas = _load_canvas_state()
# Live-update queues polled by an open tldraw tab (parity with server/index.ts).
_pending_shapes = []
_pending_deletes = []


# ── Deletion tombstones ──────────────────────────────────────────────────────
# Canvas saves are full-snapshot, last-writer-wins (PUT /api/canvas). A browser
# tab that loaded an OLD store resurrects deleted pages on its next save — the
# recurring "deleted pages keep coming back" bug. Fix: a persistent tombstone
# set of deleted record ids. The server (a) strips tombstoned records — and any
# shape orphaned by a tombstoned page — from every incoming snapshot, and
# (b) emits the tombstones to open tabs (GET /api/canvas + pending-shapes) so
# they drop the records live within one poll. Deletion becomes irreversible even
# against a stale tab. Delete pages via POST /api/canvas/delete-pages.
CANVAS_TOMBSTONES_FILE = os.path.join(CANVAS_DATA_DIR, 'canvas-tombstones.json')


def _load_tombstones():
    try:
        if os.path.exists(CANVAS_TOMBSTONES_FILE):
            with open(CANVAS_TOMBSTONES_FILE, encoding='utf-8') as f:
                data = json.load(f)
            if isinstance(data, list):
                return set(str(x) for x in data)
    except Exception as e:
        print(f'[canvas] failed to load tombstones: {e}')
    return set()


_canvas_tombstones = _load_tombstones()


def _save_tombstones():
    """Persist the tombstone set (atomic). Caller should hold _canvas_lock."""
    try:
        tmp = f'{CANVAS_TOMBSTONES_FILE}.tmp.{os.getpid()}'
        with open(tmp, 'w', encoding='utf-8') as f:
            json.dump(sorted(_canvas_tombstones), f, ensure_ascii=False)
        os.replace(tmp, CANVAS_TOMBSTONES_FILE)
    except Exception as e:
        print(f'[canvas] failed to save tombstones: {e}')


def _apply_tombstones(store):
    """Strip tombstoned records from a store dict, plus any shape orphaned by a
    tombstoned page (parentId points at a tombstoned page). Mutates + returns
    store. Cheap: the tombstone set is tiny."""
    if not _canvas_tombstones or not isinstance(store, dict):
        return store
    tomb = _canvas_tombstones
    for rid in list(store.keys()):
        if rid in tomb:
            del store[rid]
    for rid in list(store.keys()):
        rec = store.get(rid)
        if isinstance(rec, dict) and rec.get('typeName') == 'shape' \
                and rec.get('parentId') in tomb:
            del store[rid]
    return store


def _canvas_persist():
    """Atomic write of {store, schema} (tmp + os.replace). Must hold _canvas_lock."""
    tmp = f'{CANVAS_FILE}.tmp.{os.getpid()}.{threading.get_ident()}'
    os.makedirs(CANVAS_DATA_DIR, exist_ok=True)
    with open(tmp, 'w', encoding='utf-8') as f:
        json.dump({'store': _canvas['store'], 'schema': _canvas['schema']},
                  f, ensure_ascii=False)
        f.flush()
        os.fsync(f.fileno())
    os.replace(tmp, CANVAS_FILE)


# ── Periodic snapshot backups ────────────────────────────────────────────────
# Startup-only backups once left a multi-day gap: a wipe between two restarts
# destroyed days of hand-written work with NO snapshot in between and no way to
# recover. Now we take a timestamped snapshot every few minutes whenever the
# store is non-empty AND changed since the last one, keeping the newest ~300.
# Filenames match the gitignored `canvas-state.json.backup-*` pattern (never
# committed). Named recovery backups (…-recovery.json, no 'T') are never pruned.
import time as _time
import hashlib as _hashlib
import glob as _glob
import re as _re

_BACKUP_INTERVAL_SEC = 300     # snapshot cadence
_BACKUP_INITIAL_SEC = 20       # first snapshot shortly after start (per-restart)
_BACKUP_KEEP = 300             # newest N timestamped snapshots retained
_last_backup_hash = [None]
_TS_RE = _re.compile(r'backup-\d{4}-\d{2}-\d{2}T')


def _canvas_backup_now():
    """Best-effort timestamped snapshot; only when non-empty and changed."""
    try:
        with _canvas_lock:
            store = _canvas['store']
            n = sum(1 for r in store.values()
                    if isinstance(r, dict) and r.get('typeName') == 'shape')
            if n == 0:
                return  # never snapshot an empty store
            payload = json.dumps({'store': store, 'schema': _canvas['schema']},
                                 ensure_ascii=False)
        h = _hashlib.md5(payload.encode('utf-8')).hexdigest()
        if h == _last_backup_hash[0]:
            return  # unchanged since last snapshot
        ts = _time.strftime('%Y-%m-%dT%H-%M-%S', _time.gmtime()) + 'Z'
        path = os.path.join(CANVAS_DATA_DIR, f'canvas-state.json.backup-{ts}')
        tmp = f'{path}.tmp.{os.getpid()}'
        with open(tmp, 'w', encoding='utf-8') as f:
            f.write(payload); f.flush(); os.fsync(f.fileno())
        os.replace(tmp, path)
        _last_backup_hash[0] = h
        # prune oldest timestamped snapshots beyond _BACKUP_KEEP
        snaps = sorted(p for p in _glob.glob(
            os.path.join(CANVAS_DATA_DIR, 'canvas-state.json.backup-*'))
            if _TS_RE.search(os.path.basename(p)))
        for old in snaps[:-_BACKUP_KEEP]:
            try: os.remove(old)
            except OSError: pass
        print(f'[canvas] snapshot backup written ({n} shapes): {os.path.basename(path)}')
    except Exception as e:
        print('[canvas] periodic backup failed:', e)


def _canvas_backup_loop():
    _time.sleep(_BACKUP_INITIAL_SEC)
    _canvas_backup_now()
    while True:
        _time.sleep(_BACKUP_INTERVAL_SEC)
        _canvas_backup_now()


threading.Thread(target=_canvas_backup_loop, daemon=True).start()


def _is_valid_index_key(idx):
    """tldraw-valid fractional index = non-empty string. The real validity check
    lives in the node bridge (generateJitteredKeyBetween throws on bad input);
    here we only need a cheap filter for computing the per-parent max key."""
    return isinstance(idx, str) and len(idx) > 0


def _resolve_node_bin():
    """Find a usable `node` binary. PATH may be minimal under launchd
    (/usr/local/bin:/usr/bin:/bin) and miss nvm-managed node, which broke
    the fractional-index bridge. Try PATH first, then common nvm install dirs."""
    import shutil, glob
    found = shutil.which('node')
    if found:
        return found
    candidates = []
    home = os.path.expanduser('~')
    candidates += sorted(glob.glob(os.path.join(home, '.nvm/versions/node/*/bin/node')), reverse=True)
    candidates += ['/opt/homebrew/bin/node', '/usr/local/bin/node']
    for c in candidates:
        if os.path.exists(c) and os.access(c, os.X_OK):
            return c
    return 'node'


_NODE_BIN = _resolve_node_bin()


def _resolve_agy_bin():
    """Find the Antigravity CLI (`agy`) generically, cross-platform.

    PATH lookup via shutil.which() FIRST — that already covers agy installed
    anywhere on PATH (brew, curl-installer, apt, a custom dir, Windows). Only if
    that misses do we probe a few well-known install locations as a LAST-RESORT
    fallback (some shells — launchd, non-login — don't have the install prefix on
    PATH). None of these paths is the sole hardcode; which() is the primary path.
    Returns '' if not installed anywhere."""
    import shutil
    found = shutil.which('agy') or shutil.which('agy.exe')
    if found:
        return found
    home = os.path.expanduser('~')
    fallbacks = [
        '/opt/homebrew/bin/agy',            # macOS Apple-silicon Homebrew
        '/usr/local/bin/agy',               # macOS Intel Homebrew / generic *nix
        '/usr/bin/agy',                     # Linux system install
        os.path.join(home, '.local/bin/agy'),   # curl-installer default (*nix)
        os.path.join(home, 'bin/agy'),
        # Windows: the official install.ps1 drops the binary at
        # %LOCALAPPDATA%\agy\bin\agy.exe and adds that dir to the *registry* User
        # PATH — but a server process started before the env broadcast (or from a
        # shell with a stale PATH) won't see it via which(). So probe the real
        # install dir explicitly. LOCALAPPDATA-based first, then a ~/AppData join
        # as a backstop, then the older guessed 'Antigravity' path for safety.
        os.path.join(os.environ.get('LOCALAPPDATA', os.path.join(home, 'AppData', 'Local')),
                     'agy', 'bin', 'agy.exe'),
        os.path.join(home, 'AppData', 'Local', 'agy', 'bin', 'agy.exe'),
        os.path.join(home, 'AppData', 'Local', 'Antigravity', 'agy.exe'),
    ]
    for c in fallbacks:
        try:
            if os.path.exists(c) and os.access(c, os.X_OK):
                return c
        except Exception:
            pass
    return ''


_AGY_BIN = _resolve_agy_bin()


# ── Desk Mode (iPad) ─────────────────────────────────────────────────────────
# Keeps the Mac awake + reachable so Vova can drive Chat View from an iPad over
# Tailscale. Three layered levers, by privilege:
#   1. caffeinate -dimsu  : user-level, blocks idle sleep while the lid is OPEN.
#   2. tailscale up/down  : user-level (App variant, no sudo), the remote tunnel.
#   3. /tmp/deskmode.state flag ("1"/"0"): watched by an OPTIONAL root LaunchDaemon
#      (com.vova.deskmode) that flips `pmset disablesleep` so the Mac keeps running
#      with the lid CLOSED. The daemon is installed once by deskmode-install.sh; the
#      server itself only ever writes the flag file (never needs root).
_DESKMODE_FLAG = '/tmp/deskmode.state'
_DESKMODE_PLIST = '/Library/LaunchDaemons/com.vova.deskmode.plist'
_TAILSCALE_BIN = '/usr/local/bin/tailscale'
_CAFFEINATE_ARGS = ['caffeinate', '-dimsu']


def _dm_run(cmd, timeout=8):
    """Best-effort subprocess.run; returns (rc, stdout, stderr). Never raises."""
    import subprocess as _sp
    try:
        r = _sp.run(cmd, capture_output=True, text=True, timeout=timeout)
        return r.returncode, (r.stdout or ''), (r.stderr or '')
    except Exception as e:
        return 127, '', str(e)


def _dm_caffeinate_running():
    # Anchor the pattern to the START of the command line so we only match the
    # real `caffeinate -dimsu` process (argv[0] == "caffeinate"), NOT any shell /
    # script whose command line merely CONTAINS the string "caffeinate -dimsu"
    # (e.g. connect-install.sh, or a terminal running this very check).
    rc, _, _ = _dm_run(['pgrep', '-f', '^caffeinate -dimsu'], timeout=5)
    return rc == 0


def _dm_start_caffeinate():
    """Start `caffeinate -dimsu` detached if not already up. Idempotent."""
    if _dm_caffeinate_running():
        return False
    import subprocess as _sp
    try:
        _sp.Popen(_CAFFEINATE_ARGS, stdout=_sp.DEVNULL, stderr=_sp.DEVNULL,
                  stdin=_sp.DEVNULL, start_new_session=True)
        return True
    except Exception:
        return False


def _dm_stop_caffeinate():
    # Anchored (see _dm_caffeinate_running): kill ONLY the real caffeinate, never a
    # shell/script that happens to mention "caffeinate -dimsu" on its command line.
    _dm_run(['pkill', '-f', '^caffeinate -dimsu'], timeout=5)


def _dm_write_flag(val):
    try:
        with open(_DESKMODE_FLAG, 'w') as f:
            f.write('1' if str(val) in ('1', 'on', 'true', 'True') else '0')
        return True
    except Exception:
        return False


def _dm_read_flag():
    try:
        with open(_DESKMODE_FLAG) as f:
            v = f.read().strip()
        return v if v in ('0', '1') else None
    except Exception:
        return None


def _dm_tailscale_state():
    """'up' if backend Running, else 'down'. Never raises."""
    rc, out, _ = _dm_run([_TAILSCALE_BIN, 'status', '--json'], timeout=8)
    if rc != 0 or not out.strip():
        return 'down'
    try:
        return 'up' if json.loads(out).get('BackendState') == 'Running' else 'down'
    except Exception:
        return 'down'


def _dm_tailscale_dnsname():
    rc, out, _ = _dm_run([_TAILSCALE_BIN, 'status', '--json'], timeout=8)
    if rc != 0 or not out.strip():
        return None
    try:
        name = ((json.loads(out).get('Self') or {}).get('DNSName') or '').strip().rstrip('.')
        return name or None
    except Exception:
        return None


def _dm_serve_configured():
    """True if `tailscale serve status` shows the :8443 -> 5555 mapping."""
    rc, out, _ = _dm_run([_TAILSCALE_BIN, 'serve', 'status'], timeout=8)
    if rc != 0:
        return False
    txt = out or ''
    return ('8443' in txt) and ('5555' in txt)


def _dm_disablesleep():
    """0/1 from `pmset -g` SleepDisabled line; None if unknown."""
    rc, out, _ = _dm_run(['pmset', '-g'], timeout=5)
    if rc != 0:
        return None
    for line in out.splitlines():
        if 'sleepdisabled' in line.lower():
            parts = line.strip().split()
            return 1 if parts and parts[-1] in ('1', 'true', 'True') else 0
    return None


def _dm_helper_installed():
    if os.path.exists(_DESKMODE_PLIST):
        return True
    rc, _, _ = _dm_run(['launchctl', 'print', 'system/com.vova.deskmode'], timeout=5)
    return rc == 0


def _dm_chatview_url():
    name = _dm_tailscale_dnsname()
    return f'https://{name}:8443/' if name else None


# ── Antigravity debug logging + single-process serialization ────────────────
# WHY: the login hang was a RACE — multiple `agy` processes (the live PTY-login
# agy + `agy models` status probes fired on every poll) fighting over the macOS
# Keychain / shared token cache mid-login, each blocking to its timeout. We now
# (1) log every step to a tail-able file so a live repro is watchable, and
# (2) NEVER let two `agy` processes run at once (a global lock any secondary agy
#     invocation must hold; the live login PTY holds it for its whole lifetime).
_AGY_DEBUG_LOG = '/tmp/agy_connect_debug.log'
# Serializes ALL `agy` process spawns. `agy models`/probe acquire it briefly. The
# login PTY now holds it ONLY for its active drive phase (spawn → OAuth-URL
# capture); once it reaches the human browser step it HANDS THE LOCK BACK, so
# status probes (the keychain = source of truth) work mid-login.
_AGY_PROC_LOCK = threading.Lock()
# How long the login PTY stays open waiting on the human browser step. Generous on
# purpose: the user must pick a Google account + copy the code. The old 180s reaped
# the PTY mid-auth and was a root cause of "the wizard reset while I was logging in".
_AGY_LOGIN_BUDGET_S = 420


def _agy_dbg(msg, tag='---'):
    """Append one ISO-timestamped, flushed line to the Antigravity debug log.
    Never raises (best-effort observability, must not break the login path)."""
    try:
        import datetime as _dt
        ts = _dt.datetime.now().isoformat(timespec='milliseconds')
        line = '%s [%s] %s\n' % (ts, tag, msg)
        with open(_AGY_DEBUG_LOG, 'a', encoding='utf-8', errors='replace') as _f:
            _f.write(line)
            _f.flush()
    except Exception:
        pass


def _agy_dbg_bytes(label, raw, tag='pty', limit=600):
    """Log a truncated, control-char-safe snapshot of raw PTY bytes so the actual
    TUI prompts around each keystroke are visible in the debug log."""
    try:
        clean = _agy_strip(raw if isinstance(raw, (bytes, bytearray)) else b'')
        clean = clean.replace('\n', '\\n').replace('\r', '\\r')
        if len(clean) > limit:
            clean = '…' + clean[-limit:]
        _agy_dbg('%s len=%d tail=%r' % (label, len(raw or b''), clean), tag)
    except Exception:
        pass


def _refresh_agy_bin():
    """Re-detect `agy` after an install and update the module-level path.
    Owns the `global` so call sites (e.g. do_POST) don't need one — which would
    otherwise conflict with their earlier reads of _AGY_BIN. Returns the path."""
    global _AGY_BIN
    _AGY_BIN = _resolve_agy_bin()
    return _AGY_BIN


# ═══════════════════════════════════════════════════════════════════════════
# Antigravity (`agy`) GUIDED CONNECTION WIZARD — server-side driver.
#
# ChatView runs locally on the user's machine, so the backend can drive the
# `agy` CLI on their behalf: detect state, install via brew, and (the hard part)
# log in by spawning `agy`'s interactive TUI inside a pseudo-terminal (PTY),
# scripting the exact keystrokes, and scraping the OAuth URL it prints. The user
# only does the irreducible browser step (pick the right Google account).
#
# EMPIRICALLY DECODED on this machine (agy 1.0.15, macOS, 2026-07-02):
#   • There is NO `agy login` subcommand and NO headless login. Login lives ONLY
#     in the bare TUI (`agy` with no args, needs a real TTY).
#   • `agy models` / `agy -p` HANG when logged out (no clean error) — never use
#     them for status. Use a fresh `--log-file` run instead and parse the log.
#   • Auth state is deterministic in the CLI log:
#       logged out → "You are not logged into Antigravity." +
#                    "quotaRefreshLoop: skipped (not logged in)"
#       logged in  → those strings ABSENT; account email appears in the TUI banner.
#   • A STALE keychain token makes a bare `/login` silently reuse a PREVIOUS
#     account instead of prompting. So the login flow must `/logout` FIRST to
#     force a fresh browser OAuth where the user picks the intended account.
#   • Keystroke recipe inside the TUI (each slash command = type it, TAB to
#     autocomplete the highlighted palette item, ENTER to submit):
#       1. "/logout"  + TAB + ENTER   → "You are currently not signed in."
#       2. "/login"   + TAB + ENTER   → "Select login method:" menu, with
#          "> 1. Google OAuth" pre-selected → ENTER → agy prints:
#          "Your browser should open automatically. If not:" then the URL.
#   • The visible URL is line-wrapped/truncated, BUT agy emits it as an OSC-8
#     hyperlink (ESC ] 8 ; id=auth-url ; <FULL-URL> BEL) — parse THAT for the
#     complete accounts.google.com/o/oauth2/auth?... PKCE URL.
#   • Success after browser: the log's "not logged in" strings disappear and the
#     TUI banner shows the signed-in email; agy also prints a success line.
# ═══════════════════════════════════════════════════════════════════════════

# ANSI / control / OSC scrubbers for turning raw TUI bytes into readable text.
_AGY_ANSI_RE = None
_AGY_CTRL_RE = None
_AGY_OSC8_RE = None


def _agy_regexes():
    """Lazily compile (and cache) the TUI-scrubbing regexes. bytes patterns."""
    global _AGY_ANSI_RE, _AGY_CTRL_RE, _AGY_OSC8_RE
    if _AGY_ANSI_RE is None:
        import re as _re
        # CSI/SGR/private sequences + OSC ...;... terminated by BEL or ST + charset selects.
        _AGY_ANSI_RE = _re.compile(
            rb'\x1b\[[0-9;?]*[ -/]*[@-~]'      # CSI (incl. private ?, intermediates)
            rb'|\x1b\][^\x07\x1b]*(?:\x07|\x1b\\)'  # OSC ... BEL/ST
            rb'|\x1b[=>()#][0-9A-Za-z]?')          # charset / keypad selects
        _AGY_CTRL_RE = _re.compile(rb'[\x00-\x08\x0b\x0c\x0e-\x1f\x7f]')
        # OSC-8 hyperlink: ESC ] 8 ; <params> ; <URI> (BEL | ST). Group 1 = URI.
        _AGY_OSC8_RE = _re.compile(rb'\x1b\]8;[^;]*;([^\x07\x1b]+)(?:\x07|\x1b\\)')
    return _AGY_ANSI_RE, _AGY_CTRL_RE, _AGY_OSC8_RE


def _agy_strip(raw_bytes):
    """Raw PTY bytes → clean UTF-8 text (ANSI/OSC/control removed)."""
    ansi, ctrl, _ = _agy_regexes()
    s = ansi.sub(b'', raw_bytes)
    s = ctrl.sub(b'', s)
    return s.decode('utf-8', 'replace')


def _agy_find_oauth_url(raw_bytes):
    """Return the FULL Google OAuth URL from raw PTY bytes, or None.

    Prefer the OSC-8 hyperlink (carries the untruncated URL); fall back to the
    first accounts.google.com match in the stripped text (may be wrapped)."""
    import re as _re
    _, _, osc8 = _agy_regexes()
    for m in osc8.finditer(raw_bytes):
        uri = m.group(1)
        if b'accounts.google' in uri or b'oauth2' in uri:
            return uri.decode('utf-8', 'replace')
    txt = _agy_strip(raw_bytes)
    m = _re.search(r'https?://accounts\.google\.com/o/oauth2/\S+', txt)
    return m.group(0) if m else None


def _agy_probe_status_log(block=False):
    """Run `agy` briefly under a fresh --log-file to read auth state WITHOUT
    hanging (agy models/-p hang when logged out). Returns (log_text, banner_text).

    Spawns the TUI in a PTY for ~5s, captures both the log file and the on-screen
    banner (which shows the signed-in email when logged in), then hard-kills it.
    Never raises — returns ('','') on any failure.

    RACE-SAFE: like _agy_models_list, this spawns a SECOND `agy`, so it must hold
    _AGY_PROC_LOCK. `block=False` → if a login PTY (or a probe) is live, skip and
    return ('','') rather than fight it over the Keychain."""
    import os as _os, pty as _pty, time as _time, struct as _struct
    import fcntl as _fcntl, termios as _termios, signal as _signal, tempfile as _tf
    if not _AGY_BIN:
        return '', ''
    if not _AGY_PROC_LOCK.acquire(blocking=block):
        _agy_dbg('probe-status SKIPPED (agy busy, proc-lock held)', 'probe')
        return '', ''
    log_path = _tf.mktemp(prefix='agy-status-', suffix='.log')
    raw = b''
    try:
        pid, fd = _pty.fork()
        if pid == 0:  # child: become agy in the PTY
            env = dict(_os.environ)
            env.update(TERM='xterm-256color', COLUMNS='120', LINES='40')
            try:
                _os.execvpe(_AGY_BIN, [_AGY_BIN, '--log-file', log_path], env)
            except Exception:
                _os._exit(1)
            _os._exit(1)
        # parent: set a window size so the TUI renders its banner, then drain.
        try:
            _fcntl.ioctl(fd, _termios.TIOCSWINSZ, _struct.pack('HHHH', 40, 120, 0, 0))
        except Exception:
            pass
        import select as _select
        deadline = _time.time() + 5.0
        while _time.time() < deadline:
            r, _, _ = _select.select([fd], [], [], 0.3)
            if r:
                try:
                    chunk = _os.read(fd, 16384)
                except OSError:
                    break
                if not chunk:
                    break
                raw += chunk
        try:
            _os.kill(pid, _signal.SIGKILL)
        except Exception:
            pass
        try:
            _os.close(fd)
        except Exception:
            pass
        try:
            _os.waitpid(pid, 0)
        except Exception:
            pass
    except Exception:
        pass
    log_text = ''
    try:
        with open(log_path, encoding='utf-8', errors='replace') as f:
            log_text = f.read()
    except Exception:
        pass
    finally:
        try:
            _os.remove(log_path)
        except Exception:
            pass
    try:
        _AGY_PROC_LOCK.release()
    except Exception:
        pass
    return log_text, _agy_strip(raw)


def _agy_account_from_banner(banner):
    """Extract the signed-in account email from the TUI banner text, or ''."""
    import re as _re
    # Banner prints the signed-in account email on its own line under the logo
    # (e.g. "user@example.com"). Grab the first email-looking token.
    m = _re.search(r'[A-Za-z0-9._%+\-]+@[A-Za-z0-9.\-]+\.[A-Za-z]{2,}', banner or '')
    return m.group(0) if m else ''


def _agy_account_from_log():
    """Best-effort signed-in email from the most recent agy CLI log
    (~/.gemini/antigravity-cli/log/cli-*.log). On every authenticated run agy
    writes 'OAuth: authenticated successfully as <email>' /
    'applyAuthResult: email=<email>', so this recovers the account cross-platform
    WITHOUT the PTY banner probe (which cannot run on Windows). Returns '' if
    unknown. Never raises."""
    import glob as _glob, re as _re
    try:
        log_dir = os.path.expanduser('~/.gemini/antigravity-cli/log')
        logs = sorted(_glob.glob(os.path.join(log_dir, 'cli-*.log')),
                      key=lambda p: os.path.getmtime(p), reverse=True)
        for p in logs[:5]:   # newest few (a freshly-rotated empty log shouldn't hide it)
            try:
                with open(p, encoding='utf-8', errors='replace') as f:
                    txt = f.read()
            except Exception:
                continue
            m = (_re.search(r'authenticated successfully as\s+([^\s,]+@[^\s,]+)', txt)
                 or _re.search(r'applyAuthResult:\s*email=([^\s,]+@[^\s,]+)', txt))
            if m:
                return m.group(1).strip().rstrip('.,')
    except Exception:
        pass
    return ''


def _agy_win_credential_present():
    """Windows-only RELIABLE auth signal: True iff agy's OAuth token exists in the
    Windows Credential Manager. agy (Go keyring / wincred) stores it under target
    'gemini:antigravity' — created on login, DELETED on logout, and auto-refreshed
    while present. Presence is therefore a robust 'logged in' check, unlike
    `agy models` which lists a static catalog even when logged out. Never raises;
    returns False on any error (fail-safe = not connected)."""
    if sys.platform != 'win32':
        return False
    import subprocess as _sp
    try:
        r = _sp.run(['cmdkey', '/list'], capture_output=True, text=True, timeout=10)
        blob = ((r.stdout or '') + (r.stderr or '')).lower()
        return 'gemini:antigravity' in blob
    except Exception as e:
        _agy_dbg('win credential check failed: %r' % e, 'auth')
        return False


def _agy_models_list(timeout=25, block=False):
    """BEHAVIOR-BASED auth probe. Run `agy models` with a HARD timeout and parse
    the model lines. Returns (models_list, rc, err_text).

    This is the robust logged-in signal across agy 1.0.x versions: `agy models`
    only returns a populated list when the CLI holds a valid token. It exits
    non-zero (or prints a 429/quota error) otherwise. We DON'T scrape TUI/log
    strings (which the 1.0.16 update polluted with false 'not logged in' cold-
    start lines even while authenticated).

    Timeout note: uses subprocess.run(timeout=...) — a pure-Python SIGKILL-on-
    expiry that needs NO `timeout` binary (which does not exist on this macOS).
    Never raises.

    RACE-SAFE: acquires the global _AGY_PROC_LOCK so it can never run concurrently
    with a live login PTY (or another probe). `block=False` (the mid-login default)
    means: if another agy process holds the lock, DON'T wait — return immediately
    with rc=125/'skipped (agy busy)'. This is what stops the poll-storm of stacked
    `agy models` calls that fought the login over the Keychain and froze the UI."""
    import subprocess as _sp
    import re as _re
    if not _AGY_BIN:
        return [], 127, 'agy CLI not installed'
    _t0 = time.time()
    got = _AGY_PROC_LOCK.acquire(blocking=block)
    if not got:
        _agy_dbg('models-list SKIPPED (agy busy, another process holds proc-lock)',
                 'models')
        return [], 125, 'skipped (agy busy)'
    try:
        _agy_dbg('models-list START timeout=%ss' % timeout, 'models')
        r = _sp.run([_AGY_BIN, 'models'], capture_output=True, text=True,
                    timeout=timeout)
    except _sp.TimeoutExpired:
        _agy_dbg('models-list END TIMEOUT after %.1fs' % (time.time() - _t0), 'models')
        return [], 124, 'agy models timed out'
    except Exception as e:
        _agy_dbg('models-list END EXC %r after %.1fs' % (e, time.time() - _t0), 'models')
        return [], 1, str(e)[:300]
    finally:
        try:
            _AGY_PROC_LOCK.release()
        except Exception:
            pass
    raw = (r.stdout or '')
    err = (r.stderr or '').strip()
    models = []
    for ln in raw.splitlines():
        s = _re.sub(r'^\s*[-*•>·]\s*', '', ln).strip()
        if not s:
            continue
        low = s.lower()
        # Drop obvious header / usage lines; keep real model rows.
        if low.startswith(('available', 'model', 'usage', 'these are', 'no models')):
            continue
        models.append(s)
    _agy_dbg('models-list END rc=%s models=%d after %.1fs%s'
             % (r.returncode, len(models), time.time() - _t0,
                (' err=%r' % err[:120]) if err else ''), 'models')
    return models, r.returncode, (err or raw.strip()[:300])


def _agy_status(block=True):
    """Detect Antigravity CLI install + auth state. Never raises.

    Returns dict: {installed, path, version, logged_in, account, quota_ok,
    quota_resets_in, models, detail}.

    `block` (default True) → wait for the agy proc-lock and give a real answer
    (used by the /status endpoint and boot). Set block=False for a best-effort,
    NON-blocking read that instantly reports signed-out if a login PTY is holding
    the lock (used mid-login so it can never race / hang).

    ── AUTH DETECTION IS BEHAVIOR-BASED, NOT LOG-STRING-BASED ──
    Logged-in ⇔ `agy models` returns a NON-EMPTY list (rc 0). That call only
    succeeds when the CLI holds a valid token, so it's robust across agy 1.0.x
    updates. This replaced the old log/banner scraping, which agy 1.0.16 broke:
    the bare-TUI log now prints false 'You are not logged into Antigravity' /
    'quotaRefreshLoop: skipped (not logged in)' cold-start lines EVEN WHEN
    authenticated (the token loads a few ms later, after those cache-miss logs).
    The old `any(marker in log_text)` check matched those and reported signed-out.

    `account` still comes from the TUI banner (that part of 1.0.16 is unchanged
    and reliable). We do the (cheap, non-hanging) banner probe ONLY to read the
    email, never to decide auth."""
    import subprocess as _sp
    import re as _re
    # Re-detect the binary LIVE every call (it may have been installed/uninstalled
    # since server boot; the boot-time _AGY_BIN cache would go stale otherwise).
    _refresh_agy_bin()
    out = {
        'installed': bool(_AGY_BIN), 'path': _AGY_BIN or None, 'version': None,
        'logged_in': False, 'account': None, 'quota_ok': None, 'models': [],
        'detail': '',
    }
    if not _AGY_BIN:
        out['detail'] = 'agy CLI not installed'
        return out
    # Version (fast, never hangs — prints usage to stderr with --version too).
    try:
        r = _sp.run([_AGY_BIN, '--version'], capture_output=True, text=True, timeout=10)
        out['version'] = (r.stdout or r.stderr or '').strip().split('\n')[0][:40] or None
    except Exception:
        pass

    # ── PRIMARY SIGNAL: does `agy models` return a populated list? ───────────
    models, rc, err = _agy_models_list(timeout=25, block=block)
    if rc == 125:  # skipped: a login PTY holds the proc-lock → report signed-out
        out['logged_in'] = False
        out['detail'] = 'busy (login in progress)'
        return out
    err_low = (err or '').lower()
    quota_error = any(k in err_low for k in (
        '429', 'quota reached', 'individual quota reached', 'resource_exhausted',
        'rate limit', 'too many requests', 'resets in'))
    # When agy prints a quota error it usually says WHEN it refills, e.g.
    # "... resets in 3h", "resets in 45m", "resets in 2h 30m". Surface that human
    # hint so the UI can show a reset countdown instead of a bare "exhausted".
    # Best-effort: never invent a value — left None unless agy actually printed one.
    quota_resets_in = None
    if quota_error:
        _m = _re.search(r'resets?\s+in\s+([0-9hms\s]+)', err_low)
        if _m:
            quota_resets_in = _m.group(1).strip().rstrip('.') or None

    # The model LIST is for the UI dropdown only — NOT an auth signal (see below).
    out['models'] = models if (models and rc == 0) else []

    if sys.platform == 'win32':
        # ── RELIABLE Windows auth signal (NOT `agy models`) ──────────────────
        # agy 1.0.16's `agy models` returns a STATIC model catalog even when
        # LOGGED OUT (verified: a fresh `agy models --log-file` shows no keyring
        # auth in its log), so a non-empty list would FALSE-report Connected.
        # Instead read the OS credential store: agy caches its OAuth token in the
        # Windows Credential Manager under target 'gemini:antigravity', created on
        # login and DELETED on logout, and auto-refreshes it while present — so its
        # presence is a robust logged-in signal. Verified on this box.
        out['logged_in'] = _agy_win_credential_present()
        out['quota_ok'] = ((not quota_error) if out['logged_in']
                           else (False if quota_error else None))
    else:
        # macOS/Linux: UNCHANGED behaviour-based detection (do not touch).
        if models and rc == 0:
            out['logged_in'] = True
            out['quota_ok'] = not quota_error
        else:
            out['logged_in'] = False
            out['quota_ok'] = False if quota_error else None

    # ── account email ────────────────────────────────────────────────────────
    # Prefer the agy CLI log ('OAuth: authenticated successfully as <email>') —
    # cross-platform, cheap, and the only source on Windows (the PTY banner probe
    # can't run there). Fall back to the TUI banner on macOS/Linux (unchanged).
    account = _agy_account_from_log() if out['logged_in'] else ''
    if not account and sys.platform != 'win32':
        try:
            _log_text, banner = _agy_probe_status_log(block=block)
        except Exception:
            _log_text, banner = '', ''
        account = _agy_account_from_banner(banner)
    out['account'] = account or None

    # Reset hint for the UI (only present when agy actually reported a quota wall
    # with a "resets in X" phrase). None otherwise — we never fabricate a time.
    out['quota_resets_in'] = quota_resets_in

    out['detail'] = ('signed in' if out['logged_in']
                     else ('quota exhausted' if quota_error else 'signed out'))
    return out


# ── PTY login session registry ─────────────────────────────────────────────
# A login = a live `agy` TUI in a PTY that we scripted to the OAuth URL and now
# hold open while the user completes the browser step. Keyed by session_id.
_AGY_LOGIN_SESSIONS = {}
_AGY_LOGIN_LOCK = threading.Lock()


class _AgyLoginSession:
    """Owns one PTY-driven `agy` login attempt. A background thread drives the
    keystrokes (/logout → /login → select Google OAuth), continuously drains the
    PTY into a buffer, captures the OAuth URL, and watches for success/failure.

    State machine (self.state): 'starting' → 'awaiting_url' → 'awaiting_browser'
    → 'success' | 'failed'. Thread-safe reads via the module lock."""

    def __init__(self):
        import uuid as _uuid
        self.id = _uuid.uuid4().hex[:12]
        self.pid = None
        self.fd = None
        self.raw = b''
        self.login_url = None
        self.account = None
        self.state = 'starting'
        self.detail = ''
        self.started = time.time()
        self._thread = None
        self._stop = False
        # Set when the user's OAuth code has been written to the PTY. The driver
        # then watches for agy's token-exchange result (success or a clear reject
        # like `oauth2: "invalid_grant" "Malformed auth code."`). code_error holds
        # a human message when agy rejects the pasted code so the UI can retry.
        self.code_submitted = False
        self.code_error = None
        # Byte offset into self.raw from which to scan for a code-exchange result
        # (set when a code is written, so a stale error from a prior attempt in the
        # cumulative buffer can't re-trigger).
        self._code_scan_from = 0
        # True while THIS session holds _AGY_PROC_LOCK. The live login PTY holds it
        # for its whole lifetime so status probes (`agy models`) never race it over
        # the Keychain — the root cause of the mid-login hang. Released in teardown.
        self._holds_proc_lock = False
        # True once the PTY stream itself shows the login completed (agy printed a
        # success line / returned to a ready banner). Lets poll() do a SINGLE short
        # confirm safely (no probe-storm) instead of hammering `agy models`.
        self.pty_success = False
        # Guards the release of _AGY_PROC_LOCK so a mid-flow release (once we reach
        # the browser step) and teardown() can never double-release.
        self._lock_release_guard = threading.Lock()
        # Set once teardown() has run so submit_code / poll can detect a dead PTY
        # WITHOUT probing os.kill on a reaped pid.
        self._torn_down = False

    def _release_proc_lock(self, why=''):
        """Release _AGY_PROC_LOCK exactly once, from anywhere (mid-drive handoff,
        teardown, GC). Idempotent + thread-safe. The KEY robustness change: the
        login PTY no longer squats the global lock for its whole lifetime — once
        the OAuth URL is captured and we're just WAITING on the human browser step,
        agy is idle on stdin and touches nothing, so we hand the lock back. That
        lets /status and /login/status run a REAL `agy models` (the keychain = the
        source of truth) even while the PTY is still open."""
        with self._lock_release_guard:
            if self._holds_proc_lock:
                self._holds_proc_lock = False
                try:
                    _AGY_PROC_LOCK.release()
                except Exception:
                    pass
                _agy_dbg('session=%s proc-lock RELEASED%s'
                         % (self.id, (' (%s)' % why) if why else ''), 'lock')

    # --- lifecycle -----------------------------------------------------------
    def start(self):
        import os as _os, pty as _pty, struct as _struct
        import fcntl as _fcntl, termios as _termios
        # Take the global agy process-lock only for the ACTIVE drive phase (spawn +
        # scripted keystrokes up to URL capture). We hand it back the instant we
        # reach the browser step (see _drive) so status probes work mid-login.
        self._holds_proc_lock = _AGY_PROC_LOCK.acquire(blocking=True)
        _agy_dbg('login/start session=%s acquired proc-lock=%s'
                 % (self.id, self._holds_proc_lock), 'start')
        pid, fd = _pty.fork()
        if pid == 0:  # child
            env = dict(_os.environ)
            env.update(TERM='xterm-256color', COLUMNS='120', LINES='40')
            try:
                _os.execvpe(_AGY_BIN, [_AGY_BIN], env)
            except Exception:
                _os._exit(1)
            _os._exit(1)
        self.pid = pid
        self.fd = fd
        try:
            _fcntl.ioctl(fd, _termios.TIOCSWINSZ, _struct.pack('HHHH', 40, 120, 0, 0))
        except Exception:
            pass
        self._thread = threading.Thread(target=self._drive, daemon=True)
        self._thread.start()

    def _write(self, data, why=''):
        try:
            os.write(self.fd, data)
            _agy_dbg('session=%s WROTE %r%s'
                     % (self.id, data, (' (%s)' % why) if why else ''), 'keystroke')
        except Exception as e:
            _agy_dbg('session=%s WRITE-FAIL %r err=%r' % (self.id, data, e), 'keystroke')

    def _send_slash(self, word):
        """Type a slash command and select it: '/word' + TAB (complete) + ENTER."""
        self._write(('/' + word).encode(), why='/%s type' % word)
        time.sleep(0.7)
        self._write(b'\t', why='/%s TAB-complete' % word)
        time.sleep(0.5)
        self._write(b'\r', why='/%s ENTER' % word)

    def _drive(self):
        """Background: script the login keystrokes, drain PTY, capture URL/state.

        Total budget ~180s (matches an OAuth attempt). Keystroke timeline is
        time-based (the TUI redraws whole frames, so we don't try to parse
        prompts before acting — we act on a schedule, then verify from output)."""
        import select as _select
        t0 = time.time()
        # PROMPT-DRIVEN choreography (agy 1.0.16). The OLD fixed-delay recipe
        # (/logout@3.5s → /login@10s → ENTER@13.5s) is BROKEN on 1.0.16 and was a
        # ROOT CAUSE of the hang: on a signed-out launch agy AUTO-STARTS Google
        # OAuth and reaches the "paste authorization code" prompt within ~1s —
        # BEFORE those delays fire. The scripted `/logout`/`/login` then land as
        # literal text INTO the code prompt (seen in the debug log as `/log in`),
        # which agy rejects as "Malformed auth code" and the flow wedges. So we no
        # longer type on a schedule; we WATCH the TUI and react to the real prompt:
        #   • signed-in banner (stale token) & not yet logged out → send /logout,
        #     forcing a fresh browser OAuth so the user re-picks the account;
        #   • "Select login method" menu → press ENTER once to confirm Google OAuth;
        #   • code prompt / URL → just capture and wait for the user's code.
        logout_sent = False
        method_confirmed = False
        _last_action = 0.0
        _last_auth_probe = 0.0   # throttle the post-code global `agy models` check
        _iter = 0
        _last_snapshot_len = 0
        _agy_dbg('session=%s _drive START (proc-lock held=%s, prompt-driven, agy 1.0.16)'
                 % (self.id, self._holds_proc_lock), 'drive')
        # Budget = _AGY_LOGIN_BUDGET_S (default 420s): the human needs time to pick
        # the Google account + copy the code. The OLD 180s reaped the PTY mid-auth.
        while not self._stop and (time.time() - t0) < _AGY_LOGIN_BUDGET_S:
            _iter += 1
            try:
                r, _, _ = _select.select([self.fd], [], [], 0.3)
            except Exception:
                _agy_dbg('session=%s select() FAILED, breaking' % self.id, 'drive')
                break
            if r:
                try:
                    chunk = os.read(self.fd, 16384)
                except OSError:
                    _agy_dbg('session=%s os.read() OSError (PTY closed)' % self.id, 'drive')
                    break
                if not chunk:
                    _agy_dbg('session=%s PTY EOF (empty read)' % self.id, 'drive')
                    break
                with _AGY_LOGIN_LOCK:
                    self.raw += chunk
                    _rawlen = len(self.raw)
                    _raw_now = self.raw
                # Log a fresh PTY snapshot whenever the buffer grew — this is what
                # lets us SEE the real prompts around each keystroke during a repro.
                if _rawlen - _last_snapshot_len >= 40:
                    _agy_dbg_bytes('session=%s iter=%d PTY grew to %d'
                                   % (self.id, _iter, _rawlen), _raw_now, 'drive')
                    _last_snapshot_len = _rawlen
            el = time.time() - t0
            with _AGY_LOGIN_LOCK:
                _view = _agy_strip(self.raw)
            _vlow = _view.lower()
            # Look only at the TAIL (current screen), so an early menu that already
            # scrolled off doesn't retrigger. 1.0.16 redraws whole frames.
            _tail = _vlow[-1200:]
            # ── (A) Stale token: agy shows a signed-in email banner (no "not signed
            #        in") and NO login menu → force a fresh OAuth via /logout once.
            _acct_hint = _agy_account_from_banner(_view[-1200:])
            _looks_signed_in = (bool(_acct_hint) and 'not signed in' not in _tail
                                and 'not logged in' not in _tail)
            _menu_showing = ('select login method' in _tail or 'google oauth' in _tail)
            if (not logout_sent and not self.code_submitted and self.login_url is None
                    and _looks_signed_in and not _menu_showing and el > 1.0
                    and (el - _last_action) > 1.5):
                _agy_dbg('session=%s el=%.1fs stale token (acct=%r) → sending /logout'
                         % (self.id, el, _acct_hint), 'drive')
                self._send_slash('logout')
                logout_sent = True
                _last_action = el
                continue
            # ── (B) "Select login method" menu is up (Google OAuth pre-selected as
            #        "> 1.") → a single ENTER confirms it. Fire ONCE, prompt-gated,
            #        never on a blind timer. Only before we have a URL.
            if (self.login_url is None and not method_confirmed and _menu_showing
                    and (el - _last_action) > 0.8):
                _agy_dbg('session=%s el=%.1fs "Select login method" seen → ENTER '
                         '(confirm Google OAuth)' % (self.id, el), 'drive')
                self._write(b'\r', why='confirm Google OAuth (prompt-driven)')
                method_confirmed = True
                _last_action = el
                continue
            # capture URL as soon as it appears.
            if self.login_url is None:
                with _AGY_LOGIN_LOCK:
                    url = _agy_find_oauth_url(self.raw)
                if url:
                    with _AGY_LOGIN_LOCK:
                        self.login_url = url
                        self.state = 'awaiting_browser'
                    _agy_dbg('session=%s CAPTURED OAuth URL (%d chars) → awaiting_browser'
                             % (self.id, len(url)), 'drive')
                    # HAND BACK the global lock: from here we only WAIT on the human
                    # browser step; agy sits idle on the code prompt and touches no
                    # keychain, so /status + /login/status can now run a real
                    # `agy models` and detect global auth = the source of truth.
                    self._release_proc_lock('reached browser step')
            # ── SUCCESS SIGNAL: read from the LOGIN PTY's OWN stream ─────────────
            # CRITICAL FIX (the hang): we do NOT run `agy models` here anymore.
            # Spawning a SECOND agy while this login agy is mid-token-exchange made
            # the two processes fight over the macOS Keychain; `agy models` blocked
            # to its timeout and froze this drive loop right after code submit. The
            # login agy itself prints its result to THIS PTY, so we watch the stream
            # (cheap, non-blocking) and set pty_success. A single, SHORT, serialized
            # `agy models` confirm happens later in poll() — after the PTY says done
            # and after teardown released the proc-lock, so never two agy at once.
            with _AGY_LOGIN_LOCK:
                txt = _agy_strip(self.raw)
            low = txt.lower()
            if any(s in low for s in (
                'successfully signed in', 'successfully logged in',
                'you are now signed in', "you're now signed in",
                'signed in as', 'login successful', 'authentication successful',
                'authentication complete', 'you are now logged in',
                'logged in as', 'auth succeeded')):
                acct = _agy_account_from_banner(txt)
                _agy_dbg('session=%s PTY SUCCESS marker seen (acct=%r) → success'
                         % (self.id, acct), 'drive')
                with _AGY_LOGIN_LOCK:
                    self.account = acct or self.account
                    self.pty_success = True
                    self.state = 'success'
                    self.detail = 'signed in'
                break
            # A REJECTED pasted code (token exchange failed). agy prints, verbatim
            # (decoded from a real PTY spike), e.g.:
            #   Got an error: token exchange failed: oauth2: "invalid_grant"
            #   "Malformed auth code."  → then "Press any key to go back."
            # This is NOT a fatal login failure: agy returns to the code prompt, so
            # we keep the session ALIVE, surface a clear message, and let the user
            # paste a fresh code. Only flip a fresh reject (after a code was sent).
            with _AGY_LOGIN_LOCK:
                delta_low = _agy_strip(self.raw[self._code_scan_from:]).lower()
            if self.code_submitted and self.code_error is None and any(s in delta_low for s in (
                    'token exchange failed', 'invalid_grant', 'malformed auth code',
                    'invalid auth code', 'invalid authorization code')):
                _agy_dbg('session=%s REJECTED code (token exchange failed) → retry'
                         % self.id, 'drive')
                # Nudge agy off the "press any key to go back" screen so it re-shows
                # the code prompt and is ready for another paste.
                self._write(b'\r', why='dismiss reject screen')
                with _AGY_LOGIN_LOCK:
                    self.code_error = ('Код не підійшов (застарів або неповний). '
                                       'Скопіюй свіжий код з браузера і встав ще раз.')
                    self.code_submitted = False  # allow another attempt
                    self.state = 'awaiting_browser'
                continue
            if any(s in low for s in (
                'login failed', 'authentication failed', 'sign-in failed',
                'error signing in')):
                _agy_dbg('session=%s PTY FAILURE marker seen → failed' % self.id, 'drive')
                with _AGY_LOGIN_LOCK:
                    self.state = 'failed'
                    self.detail = 'agy reported a login failure'
                break
            # ── GLOBAL-AUTH SUCCESS (keychain = source of truth) ─────────────────
            # After a code was submitted, the surest success signal is NOT a fragile
            # PTY string but the fact that agy is now authenticated globally. We hold
            # the lock (proc-lock is free during the browser step), do a bounded
            # `agy models`, and if it returns models → logged in, regardless of what
            # the TUI printed. Throttled to ~every 3s so we never storm the keychain.
            if self.code_submitted and (el - _last_auth_probe) > 3.0:
                _last_auth_probe = el
                models, rc, _ = _agy_models_list(timeout=8, block=True)
                if models and rc == 0:
                    _agy_dbg('session=%s GLOBAL AUTH confirmed via agy models (%d) → success'
                             % (self.id, len(models)), 'drive')
                    with _AGY_LOGIN_LOCK:
                        self.pty_success = True
                        self.state = 'success'
                        self.detail = 'signed in'
                    break
            # advance interim state so the UI shows "awaiting_url" while we drive.
            if self.login_url is None and self.state == 'starting' and el > 1.0:
                with _AGY_LOGIN_LOCK:
                    self.state = 'awaiting_url'
        # loop ended: settle terminal state.
        with _AGY_LOGIN_LOCK:
            if self.state not in ('success', 'failed'):
                if self.login_url:
                    # We got the URL and the browser step just didn't complete in
                    # our window — keep it as awaiting_browser (UI keeps polling
                    # via /status), don't mark failed.
                    self.detail = self.detail or 'awaiting browser completion'
                else:
                    self.state = 'failed'
                    self.detail = self.detail or 'timed out before capturing login URL'
            _final_state, _final_detail = self.state, self.detail
        # ROBUSTNESS: the drive loop is the ONLY owner of the PTY. Whenever it ends —
        # success, failure, or (the old zombie bug) the browser step simply outran
        # our window — GUARANTEE the PTY is reaped and the proc-lock is released.
        # The previous code left the PTY alive on timeout, so a stale `agy` kept the
        # in-process lock forever and hung EVERY later /status. Now that can't happen:
        # on non-success the driver tears its own PTY down; poll()/status fall back to
        # the global keychain signal, which survives the PTY dying.
        if _final_state != 'success':
            self.teardown()
        _agy_dbg('session=%s _drive END state=%s detail=%r (iters=%d, %.1fs)'
                 % (self.id, _final_state, _final_detail, _iter, time.time() - t0), 'drive')

    def submit_code(self, code):
        """Write the user's OAuth authorization code into the live PTY stdin, then
        press Enter so agy runs the token exchange. Returns (ok, message).

        The PTY-stdin plumbing is proven (a real spike showed `os.write(fd, ...)`
        reaches agy: it echoed the typed chars and ran the exchange). After the
        code lands, agy either logs in (global auth flips → /status success) or
        prints `oauth2: "invalid_grant" "Malformed auth code."`, which the driver
        loop catches and turns into a retryable code_error."""
        code = (code or '').strip()
        _agy_dbg('session=%s submit_code CALLED code_len=%d state=%s'
                 % (self.id, len(code), self.state), 'submit')
        if not code:
            _agy_dbg('session=%s submit_code EMPTY' % self.id, 'submit')
            return False, 'Порожній код. Скопіюй код з браузера і встав ще раз.'
        # The PTY/child must still be alive to receive the code.
        alive = False
        if self.fd is not None and self.pid is not None:
            try:
                os.kill(self.pid, 0)   # signal 0 = liveness probe, no-op
                alive = True
            except Exception:
                alive = False
        if not alive:
            _agy_dbg('session=%s submit_code but PTY DEAD (pid=%s) → check global auth'
                     % (self.id, self.pid), 'submit')
            # GLOBAL-AUTH-FIRST: the PTY may have died AFTER the token already
            # cached (server restart, budget reap right as auth completed). Before
            # telling the user to start over, ask the keychain. If already signed
            # in → surface success so the UI jumps straight to Connected. The
            # proc-lock is free (dead PTY released it in teardown), so this runs.
            try:
                st = _agy_status()
            except Exception:
                st = {'logged_in': False}
            if st.get('logged_in'):
                with _AGY_LOGIN_LOCK:
                    self.pty_success = True
                    self.state = 'success'
                    self.account = st.get('account') or self.account
                    self.detail = 'signed in'
                _agy_dbg('session=%s submit_code: PTY dead BUT global auth OK → success'
                         % self.id, 'submit')
                return True, 'Вхід вже завершено. Підключаю…'
            return False, ('Сесія входу закрилась. Натисни «Почати заново», '
                           'щоб увійти ще раз.')
        # Snapshot the current PTY so the log shows WHICH prompt the code lands on.
        with _AGY_LOGIN_LOCK:
            self.code_error = None
            self.code_submitted = True
            self._code_scan_from = len(self.raw)   # scan only what comes AFTER this
            _raw_before = self.raw
        _agy_dbg_bytes('session=%s PTY-BEFORE-code (should show a code prompt)'
                       % self.id, _raw_before, 'submit')
        _bytes = code.encode('utf-8', 'replace')
        # Type the code, a beat, then Enter — mirrors a human paste into the prompt.
        _agy_dbg('session=%s writing %d code bytes to PTY then ENTER'
                 % (self.id, len(_bytes)), 'submit')
        self._write(_bytes, why='paste OAuth code')
        time.sleep(0.4)
        self._write(b'\r', why='submit code ENTER')
        print('[connect] submit-code session=%s wrote %d chars into PTY stdin'
              % (self.id, len(code)), file=sys.stderr, flush=True)
        return True, 'Код надіслано у agy. Завершую вхід…'

    def poll(self):
        """Return a JSON-safe status snapshot.

        SUCCESS DETECTION = GLOBAL AUTH (the keychain), not session bookkeeping.
        Because the login PTY hands the proc-lock back once it reaches the browser
        step, `agy models` is now free to run mid-login and is the source of truth:
          • If _drive already flipped success (it does its own global-auth probe
            after the code lands) → report it + teardown + backfill the account.
          • Otherwise, once a code was sent / we're awaiting the browser → run a
            bounded `agy models`. If it returns models the user is authenticated —
            report SUCCESS even if the PTY object is gone / confused. This is what
            makes login survive session & PTY hiccups (dead PTY, server restart)."""
        with _AGY_LOGIN_LOCK:
            state = self.state
            url = self.login_url
            acct = self.account
            detail = self.detail
            code_err = self.code_error
            code_sent = self.code_submitted
            pty_ok = self.pty_success
        _agy_dbg('session=%s poll() state=%s pty_success=%s code_sent=%s acct=%r'
                 % (self.id, state, pty_ok, code_sent, acct), 'poll')

        # ── Path 1: _drive() already confirmed success from the PTY stream. ──────
        if state == 'success' or pty_ok:
            if not acct:
                # Backfill the signed-in email. teardown FIRST so the login PTY
                # releases the proc-lock, THEN one serialized (blocking, but the
                # lock is now free) confirm reads the account — never concurrent
                # with the login agy.
                _agy_dbg('session=%s poll: success, tearing down to backfill account'
                         % self.id, 'poll')
                self.teardown()
                st = _agy_status()   # safe now: login PTY gone, lock free
                with _AGY_LOGIN_LOCK:
                    self.state = 'success'
                    self.account = st.get('account') or self.account
                    self.detail = 'signed in'
                    state, acct, detail = 'success', self.account, self.detail
            else:
                self.teardown()
            _agy_dbg('session=%s poll → SUCCESS (account=%r)' % (self.id, acct), 'poll')

        # ── Path 2: still waiting → probe GLOBAL AUTH (keychain source of truth). ─
        # The proc-lock is free during the browser step, so this bounded blocking
        # `agy models` runs for real and detects a login that already completed —
        # even if the PTY died or the server was restarted mid-flow. block=True is
        # SAFE now precisely because the login PTY no longer squats the lock.
        elif state in ('awaiting_browser', 'awaiting_url') or code_sent:
            models, rc, _ = _agy_models_list(timeout=8, block=True)
            if models and rc == 0:
                _agy_dbg('session=%s poll: GLOBAL AUTH confirm SUCCEEDED (%d models)'
                         % (self.id, len(models)), 'poll')
                self.teardown()
                st = _agy_status()
                with _AGY_LOGIN_LOCK:
                    self.state = 'success'
                    self.account = st.get('account') or self.account
                    self.detail = 'signed in'
                    state, acct, detail = 'success', self.account, self.detail

        out_state = {'starting': 'pending', 'awaiting_url': 'pending',
                     'awaiting_browser': 'pending', 'success': 'success',
                     'failed': 'failed'}.get(state, 'pending')
        # code_error (a rejected paste) is retryable: report it but keep state
        # pending so the UI re-shows the code field with the message.
        return {'state': out_state, 'raw_state': state, 'login_url': url,
                'account': acct, 'detail': detail, 'code_error': code_err,
                'code_submitted': self.code_submitted}

    def teardown(self):
        """Kill the login PTY and RELEASE the global agy proc-lock. Idempotent —
        callable from _drive, poll(), the endpoint, GC, or logout without double-
        killing or double-releasing (guarded by _torn_down + _release_proc_lock)."""
        import signal as _signal
        self._stop = True
        if self._torn_down:
            # Already reaped — just make sure the lock is definitely free and bail.
            self._release_proc_lock('teardown (already torn)')
            return
        self._torn_down = True
        if self.pid is not None:
            try:
                os.kill(self.pid, _signal.SIGKILL)
            except Exception:
                pass
        if self.fd is not None:
            try:
                os.close(self.fd)
            except Exception:
                pass
        if self.pid is not None:
            try:
                os.waitpid(self.pid, 0)
            except Exception:
                pass
        # Release the process-lock (may already be free if we handed it back at the
        # browser step — the guard makes this safe either way).
        self._release_proc_lock('teardown')
        _agy_dbg('session=%s teardown → PTY killed' % self.id, 'teardown')


def _agy_login_gc():
    """Drop finished/stale login sessions (older than 10 min) from the registry."""
    now = time.time()
    with _AGY_LOGIN_LOCK:
        dead = [sid for sid, s in _AGY_LOGIN_SESSIONS.items()
                if (now - s.started) > 600]
    for sid in dead:
        try:
            _AGY_LOGIN_SESSIONS[sid].teardown()
        except Exception:
            pass
        _AGY_LOGIN_SESSIONS.pop(sid, None)


def _agy_logout():
    """Sign the user OUT of agy by driving `/logout` in a short-lived PTY.

    Reuses the same PTY + slash-command mechanism as login (good hygiene for ANY
    user with a stale/wrong-account session). Product use: "Відключити / Змінити
    акаунт" — clears the Keychain token so the next login opens a fresh browser
    OAuth where the user re-picks the account. Bounded (~8s) and never raises.
    Returns (ok, detail)."""
    import os as _os, pty as _pty, time as _time, struct as _struct
    import fcntl as _fcntl, termios as _termios, signal as _signal, select as _select
    if not _AGY_BIN:
        return False, 'agy CLI не встановлено'
    # Serialize: never run this logout PTY alongside a login PTY or a status probe
    # (Keychain contention). The logout endpoint already tore down login sessions,
    # so this acquires quickly.
    _held_lock = _AGY_PROC_LOCK.acquire(blocking=True)
    _agy_dbg('logout acquired proc-lock=%s' % _held_lock, 'logout')
    raw = b''
    pid = fd = None
    try:
        pid, fd = _pty.fork()
        if pid == 0:  # child: become the agy TUI
            env = dict(_os.environ)
            env.update(TERM='xterm-256color', COLUMNS='120', LINES='40')
            try:
                _os.execvpe(_AGY_BIN, [_AGY_BIN], env)
            except Exception:
                _os._exit(1)
            _os._exit(1)
        try:
            _fcntl.ioctl(fd, _termios.TIOCSWINSZ, _struct.pack('HHHH', 40, 120, 0, 0))
        except Exception:
            pass
        t0 = _time.time()
        sent_logout = False
        while (_time.time() - t0) < 8.0:
            try:
                r, _, _ = _select.select([fd], [], [], 0.3)
            except Exception:
                break
            if r:
                try:
                    chunk = _os.read(fd, 16384)
                except OSError:
                    break
                if chunk:
                    raw += chunk
            # Once the TUI is up (~3.5s, same timing as the login driver), type
            # "/logout" + TAB (autocomplete) + ENTER (submit).
            if not sent_logout and (_time.time() - t0) > 3.5:
                try:
                    _os.write(fd, b'/logout')
                    _time.sleep(0.7)
                    _os.write(fd, b'\t')
                    _time.sleep(0.5)
                    _os.write(fd, b'\r')
                except Exception:
                    pass
                sent_logout = True
    except Exception as e:
        return False, str(e)
    finally:
        try:
            if pid:
                _os.kill(pid, _signal.SIGKILL)
        except Exception:
            pass
        try:
            if fd is not None:
                _os.close(fd)
        except Exception:
            pass
        try:
            if pid:
                _os.waitpid(pid, 0)
        except Exception:
            pass
        # Release BEFORE the confirming _agy_status() below so its probe can spawn.
        if _held_lock:
            try:
                _AGY_PROC_LOCK.release()
            except Exception:
                pass
            _agy_dbg('logout released proc-lock', 'logout')
    low = _agy_strip(raw).lower()
    # agy prints "You are currently not signed in." after a successful /logout.
    signed_out = ('not signed in' in low or 'signed out' in low
                  or 'logged out' in low or 'you are currently not signed in' in low)
    # Definitive check: re-probe global auth state — logged_in must now be False.
    try:
        st = _agy_status()
        if st.get('logged_in') is False:
            signed_out = True
    except Exception:
        pass
    return (signed_out, 'signed out' if signed_out else
            'logout не підтверджено (спробуй ще раз)')


def _gen_index_keys(pairs):
    """Generate one fractional-index key per [below, above] bound via the node
    bridge (fractional-indexing-jittered, the exact lib tldraw validates with).
    Returns list[str]. Raises on bridge failure so the caller can flag it."""
    import subprocess
    payload = json.dumps({'between': pairs})
    r = subprocess.run(
        [_NODE_BIN, FRACTIONAL_INDEX_CJS],
        input=payload, capture_output=True, text=True, timeout=15,
        env={**os.environ, 'NODE_PATH': CANVAS_NODE_MODULES},
    )
    if r.returncode != 0:
        raise RuntimeError(f'fractional-index bridge failed: {r.stderr.strip() or r.stdout.strip()}')
    out = json.loads(r.stdout or '{}')
    if 'error' in out:
        raise RuntimeError(f'fractional-index bridge error: {out["error"]}')
    return out.get('keys', [])


def _safe_repo_path(raw_path):
    """Resolve a repo-relative path with the SAME security as server/index.ts:
    must start with an allowed prefix, no traversal outside REPO_ROOT.
    Returns absolute path or None if denied."""
    if not raw_path:
        return None
    normalized = os.path.normpath(raw_path).replace('\\', '/')
    if not any(normalized.startswith(p) for p in ALLOWED_FILE_PREFIXES):
        return None
    full = os.path.realpath(os.path.join(REPO_ROOT, normalized))
    repo_real = os.path.realpath(REPO_ROOT)
    if not (full == repo_real or full.startswith(repo_real + os.sep)):
        return None
    return full


# ===========================================================================
# Інтеграції — connected services. Surfaces the workspace's MCP servers as
# user-facing "сервіси" (NEVER the word "MCP"). See GET /api/integrations.
# ===========================================================================

# id -> (human Ukrainian name, one-line "що дає"). Unknown ids fall back to a
# title-cased id + a generic description (see _integration_meta).
_INTEGRATION_NAMES = {
    'github':            ('GitHub',          'репозиторій і код'),
    'clickup':           ('ClickUp',         'задачі й проєкти'),
    'posthog':           ('PostHog',         'аналітика продукту'),
    'sentry-speechdesk': ('Sentry',          'помилки в застосунку'),
    'serena':            ('Код-навігація',   'розуміння нашого коду'),
    'context7':          ('Документація',    'свіжі доки бібліотек'),
    'chrome-devtools':   ('Chrome',          'дебаг фронтенду'),
    'playwright':        ('Браузер',         'автоматизація браузера'),
}


def _integration_meta(sid):
    """Human (name, desc) for a server id. Falls back to a title-cased id for
    unknown servers, NEVER exposing the literal id verbatim if it is cryptic."""
    if sid in _INTEGRATION_NAMES:
        return _INTEGRATION_NAMES[sid]
    pretty = sid.replace('-', ' ').replace('_', ' ').strip().title()
    return (pretty or sid, 'підключений сервіс')


def _configured_mcp_ids():
    """Collect configured server ids from all three sources (de-duplicated):
    global ~/.claude.json mcpServers, the repo project's mcpServers, and the
    repo-local .mcp.json. Best-effort: any unreadable source is skipped."""
    ids = set()

    def _merge(d):
        if isinstance(d, dict):
            for k in d.keys():
                if isinstance(k, str) and k.strip():
                    ids.add(k.strip())

    # 1 + 2: ~/.claude.json (global mcpServers + projects[REPO].mcpServers)
    try:
        cfg = os.path.join(os.path.expanduser('~'), '.claude.json')
        if os.path.exists(cfg):
            with open(cfg, encoding='utf-8') as f:
                data = json.load(f)
            if isinstance(data, dict):
                _merge(data.get('mcpServers'))
                projs = data.get('projects')
                if isinstance(projs, dict):
                    proj = projs.get(REPO_ROOT)
                    if isinstance(proj, dict):
                        _merge(proj.get('mcpServers'))
    except Exception:
        pass

    # 3: repo-local .mcp.json (e.g. playwright, github, clickup)
    try:
        mcp_path = os.path.join(REPO_ROOT, '.mcp.json')
        if os.path.exists(mcp_path):
            with open(mcp_path, encoding='utf-8') as f:
                data = json.load(f)
            if isinstance(data, dict):
                _merge(data.get('mcpServers'))
    except Exception:
        pass

    return ids


def _live_mcp_status():
    """Map server id -> live status via `claude mcp list`, with a hard timeout
    and graceful degradation. Returns {} if the CLI is missing/slow/unparsable,
    so the caller falls back to 'configured' for every server.

    CLI line shape (per server):
        <id>: <url-or-cmd> - <symbol> <text>
    where <symbol> is ✔ Connected / ✘ Failed to connect / ! Needs authentication.
    """
    import subprocess
    # Canonical resolver (chatview_platform), not a local path list — see _claude_bin.
    claude_bin = _claude_bin() or 'claude'
    out = ''
    try:
        r = subprocess.run(
            [claude_bin, 'mcp', 'list'], env=_claude_env(),
            cwd=REPO_ROOT, capture_output=True, text=True, timeout=12)
        out = r.stdout or ''
    except Exception:
        # Timeout / missing CLI / any failure -> degrade to "configured".
        return {}

    status = {}
    for raw in out.splitlines():
        line = raw.strip()
        # Must look like "<id>: <...> - <status>". Skip headers/diagnostics.
        if ':' not in line or ' - ' not in line:
            continue
        sid = line.split(':', 1)[0].strip()
        if not sid or ' ' in sid:
            # Real server ids are single tokens; skip prose lines.
            continue
        tail = line.rsplit(' - ', 1)[1].lower()
        if '✔' in tail or 'connected' in tail:
            status[sid] = 'connected'
        elif 'authentication' in tail or 'needs auth' in tail:
            status[sid] = 'configured'   # wired but needs OAuth -> ⚪, not 🟢
        elif '✘' in tail or 'failed' in tail:
            status[sid] = 'off'
        else:
            status[sid] = 'configured'
    return status


def _build_integrations():
    """Build the {ok, integrations:[{id,name,desc,status}]} payload. Live status
    from the CLI when available; otherwise every configured server is reported as
    'configured'. Ordered to match the canonical coding-stack ordering, with any
    extras appended alphabetically by human name."""
    configured = _configured_mcp_ids()
    live = _live_mcp_status()  # {} if CLI unavailable -> graceful fallback

    # Servers we never want to surface as a user "сервіс" (internal/noise).
    _HIDE = {'claude.ai claude code remote', 'claude-code-remote'}

    items = []
    for sid in configured:
        if sid.lower() in _HIDE:
            continue
        name, desc = _integration_meta(sid)
        # Live status wins; if the server isn't in the CLI output (CLI absent or
        # server not listed) it is at least "configured" since it's in a config.
        status = live.get(sid, 'configured')
        items.append({'id': sid, 'name': name, 'desc': desc, 'status': status})

    # Preferred display order = the canonical coding stack, known services first.
    order = list(_INTEGRATION_NAMES.keys())
    rank = {sid: i for i, sid in enumerate(order)}
    items.sort(key=lambda it: (rank.get(it['id'], len(order)), it['name'].lower()))

    return {'ok': True, 'integrations': items}


# ── Gadgets ───────────────────────────────────────────────────────────────────
# A Gadget is a self-contained mini-app under apps/<id>/:
#   manifest.json  — {id, name, icon, stateSchema, actions[], aiInstructions}
#   state.json     — the single source of truth (polled by the view every ~2s)
#   view.html      — self-contained UI (served static, shown in an in-app modal)
# Actions declared in the manifest are the ONLY mutations. Two entry points:
#   /api/gadget-action  — apply ONE named action (used by buttons + the AI path)
#   /api/gadget-ai      — Operate mode: a cheap LLM picks the action from free text
# Same file+poll engine as channels/plan. Adding a gadget = drop a folder + a
# registry line in apps/index.json; NO server change UNLESS it needs custom
# compute (then add a handler to _GADGET_HANDLERS, like errors-monitor below).

def _gadget_dir(gid):
    if not gid or '/' in gid or '..' in gid or '\\' in gid:
        raise ValueError('bad gadget id')
    return os.path.join(DIR, 'apps', gid)


def _gadget_read_json(path):
    try:
        with open(path, encoding='utf-8') as f:
            return json.load(f)
    except Exception:
        return None


def _gadget_now_iso():
    import datetime
    return datetime.datetime.utcnow().replace(microsecond=0).isoformat() + 'Z'


def _gadget_load_state(gid):
    return _gadget_read_json(os.path.join(_gadget_dir(gid), 'state.json')) or {}


def _gadget_save_state(gid, state):
    with open(os.path.join(_gadget_dir(gid), 'state.json'), 'w', encoding='utf-8') as f:
        json.dump(state, f, ensure_ascii=False, indent=2)


# ── Sentry LIVE connector for the errors-monitor gadget ───────────────────────
# When SENTRY_API_TOKEN is in .env, the gadget pulls REAL unresolved issues for the
# chosen period; otherwise it falls back to the demo seed (state['source'] tells the
# UI which). Org/project/base are overridable via .env, with sensible defaults.
_SENTRY_PERIODS = {'today': '24h', 'week': '7d', '2weeks': '14d', 'month': '30d', '3months': '90d'}

def _sentry_cfg():
    # NO hardcoded company identity: org/project come ONLY from env (a gadget's own
    # config). Unset -> the connector reports no-config and the gadget shows its seed,
    # so the shipped product carries zero SpeechDesk-specific defaults.
    return {
        'token':   _load_env_key('SENTRY_API_TOKEN'),
        'org':     _load_env_key('SENTRY_ORG') or '',
        'project': _load_env_key('SENTRY_PROJECT') or '',
        'base':    (_load_env_key('SENTRY_BASE_URL') or 'https://sentry.io').rstrip('/'),
    }

def _sentry_permalink(cfg, sig):
    """Generic issue permalink derived from the configured org (never a hardcoded
    company). Sentry SaaS lives at https://<org>.sentry.io; a custom SENTRY_BASE_URL
    (self-hosted) is used as-is. Empty when org/sig missing."""
    org = (cfg.get('org') or '').strip()
    if not sig or not org:
        return ''
    base = cfg['base']
    if base == 'https://sentry.io':
        base = 'https://%s.sentry.io' % org
    return '%s/organizations/%s/issues/?query=%s' % (base, org, sig)


def _sentry_impact(level, users, count):
    lv = (level or '').lower()
    u = int(users or 0)
    if lv in ('fatal', 'error') and u >= 5:
        return 'critical'
    if lv in ('fatal', 'error'):
        return 'watch'
    if lv == 'warning':
        return 'watch' if u >= 3 else 'noise'
    return 'noise'

_SENTRY_IMPACT_TEXT = {
    'critical': 'Критично: бʼє по користувачах, лагодити першим',
    'watch': 'Під наглядом: не критично, але тримати в полі зору',
    'noise': 'Шум: низький пріоритет',
}

def _sentry_fetch_issues(period):
    """Pull unresolved issues for a period from Sentry. Returns (items, err):
    items=list on success, or (None, reason) when no token / HTTP / parse error."""
    cfg = _sentry_cfg()
    if not cfg['token']:
        return None, 'no-token'
    if not cfg['org'] or not cfg['project']:
        return None, 'no-config'   # org/project not set -> gadget shows its seed
    import urllib.request, urllib.parse, urllib.error
    stats = _SENTRY_PERIODS.get(period, '7d')
    qs = urllib.parse.urlencode({'query': 'is:unresolved', 'statsPeriod': stats,
                                 'sort': 'freq', 'limit': '50'})
    url = '%s/api/0/projects/%s/%s/issues/?%s' % (cfg['base'], cfg['org'], cfg['project'], qs)
    req = urllib.request.Request(url, headers={
        'Authorization': 'Bearer ' + cfg['token'], 'Accept': 'application/json'})
    try:
        with urllib.request.urlopen(req, timeout=15) as resp:
            data = json.loads(resp.read().decode('utf-8'))
    except urllib.error.HTTPError as e:
        return None, 'http-%s' % e.code
    except Exception as e:
        return None, str(e)[:120]
    items = []
    for it in (data or []):
        level = (it.get('level') or 'error')
        count = int(it.get('count') or 0)
        users = int(it.get('userCount') or 0)
        md = it.get('metadata') or {}
        title = it.get('title') or md.get('type') or md.get('value') or it.get('culprit') or '(без назви)'
        area = it.get('culprit') or md.get('function') or 'застосунок'
        if len(area) > 42:
            area = area[:42] + '…'
        imp = _sentry_impact(level, users, count)
        items.append({
            'sig': it.get('shortId') or it.get('id') or '',
            'title': title,
            'level': 'warning' if level in ('warning', 'info') else 'error',
            'area': area,
            'count': count,
            'users': users,
            'firstSeen': it.get('firstSeen') or '',
            'lastSeen': it.get('lastSeen') or '',
            'why': '',  # real data has no hand-written cause; the AI chat fills it on demand
            'impact': imp,
            'impactText': _SENTRY_IMPACT_TEXT.get(imp, ''),
            'permalink': it.get('permalink') or '',
        })
    return items, None

# ── Tokenless live path: pull Sentry via a headless `claude -p` run that has the
#    Sentry MCP (OAuth, machine-level). No API token needed; Sonnet does the tool
#    call and returns JSON. Slower (~25-35s) + costs a few cents, so it fires only
#    on the explicit "refresh" action and caches all 5 periods for instant switching.
def _claude_env():
    """Env for a spawned `claude` (backfills USER/LOGNAME/PATH). Without $USER the
    CLI cannot read its macOS Keychain credentials and behaves as signed out."""
    try:
        import chatview_platform as _p
        return _p.Platform.current().claude_env()
    except Exception:
        return dict(os.environ)


def _claude_bin():
    """Path to the `claude` CLI, or '' if not installed.

    Delegates to chatview_platform.Platform.find_claude() — the ONE resolver the
    whole app shares (it also owns the caching, so no second cache here). Server,
    runner and the onboarding card therefore always agree on whether Claude Code
    exists; they used to keep three different path lists and disagree."""
    try:
        import chatview_platform as _p
        return _p.Platform.current().find_claude() or ''
    except Exception:
        import shutil
        return shutil.which('claude') or ''

def _claude_pull_sentry_period(period):
    """One `claude -p` (Sonnet + Sentry MCP) call for a single period. Returns
    (items, None) on success or (None, reason)."""
    import subprocess, re
    binp = _claude_bin()
    if not binp:
        return None, 'no-claude'
    cfg = _sentry_cfg()
    stats = _SENTRY_PERIODS.get(period, '7d')
    prompt = (
        'Call the Sentry MCP tool search_issues with projectSlugOrId="%s", '
        'query="is:unresolved", period="%s", sort="freq", limit=50. Then output ONLY a '
        'compact JSON array (no prose, no code fence). Each element: '
        '{"sig","title","level","area","count","users","firstSeen","lastSeen"} where '
        'area=culprit, count=events, users=userCount, level="error" or "warning".'
        % (cfg['project'], stats))
    try:
        p = subprocess.run(
            [binp, '-p', prompt, '--model', 'sonnet',
             '--allowedTools', 'mcp__sentry-speechdesk__search_issues',
             '--output-format', 'json'], env=_claude_env(),
            capture_output=True, text=True, timeout=170, cwd=DIR)
    except subprocess.TimeoutExpired:
        return None, 'timeout'
    except Exception as e:
        return None, str(e)[:80]
    if p.returncode != 0:
        return None, 'exit-%s' % p.returncode
    try:
        env = json.loads(p.stdout)
        r = env.get('result', '') if isinstance(env, dict) else ''
        m = re.search(r'\[.*\]', r, re.S)
        arr = json.loads(m.group(0)) if m else []
    except Exception as e:
        return None, 'parse:' + str(e)[:50]
    items = []
    for it in arr:
        level = (it.get('level') or 'error')
        level = 'warning' if level in ('warning', 'info') else 'error'
        count = int(it.get('count') or 0)
        users = int(it.get('users') or 0)
        imp = _sentry_impact(level, users, count)
        sig = str(it.get('sig') or '')
        items.append({
            'sig': sig,
            'title': it.get('title') or '(без назви)',
            'level': level,
            'area': it.get('area') or 'застосунок',
            'count': count,
            'users': users,
            'firstSeen': it.get('firstSeen') or '',
            'lastSeen': it.get('lastSeen') or '',
            'why': '',
            'impact': imp,
            'impactText': _SENTRY_IMPACT_TEXT.get(imp, ''),
            'permalink': _sentry_permalink(cfg, sig),
        })
    return items, None

def _sentry_periods_via_claude():
    """Pull all 5 periods in parallel via Claude+MCP. Returns ({period: items}, err)
    with whatever succeeded, or (None, reason) if every period failed."""
    if not _claude_bin():
        return None, 'no-claude'
    from concurrent.futures import ThreadPoolExecutor
    out, errs = {}, []
    with ThreadPoolExecutor(max_workers=5) as ex:
        futs = {ex.submit(_claude_pull_sentry_period, p): p for p in _SENTRY_PERIODS}
        for f, p in futs.items():
            try:
                items, err = f.result()
            except Exception as e:
                items, err = None, str(e)[:50]
            if items is not None:
                out[p] = items
            else:
                errs.append('%s:%s' % (p, err))
    if not out:
        return None, (errs[0] if errs else 'empty')
    return out, ('; '.join(errs) if errs else '')


def _errors_monitor_action(state, action, params, gdir):
    """Custom compute for the errors-monitor gadget. Data source, in order: direct
    Sentry REST if a token is set (live), else Claude+MCP pull on refresh (live-mcp,
    cached in state['buckets']), else the curated MCP snapshot in seed (snapshot).
    Returns new state, or None if it does not handle the action."""
    seed = _gadget_read_json(os.path.join(gdir, 'seed.json')) or {}
    def _recompute(period):
        buckets = state.get('buckets') or {}
        if buckets.get(period) is not None:
            state['issues'] = buckets[period]           # cached live-mcp; keep state.source
        else:
            items, err = _sentry_fetch_issues(period)   # direct REST when a token exists
            if items is not None:
                state['source'] = 'live'
                state['sourceErr'] = ''
                state['issues'] = items
            else:
                items = seed.get(period, seed.get('week', seed.get('today', [])))
                # A curated real-data snapshot (pulled via MCP, no token) marks itself
                # in seed._meta.source; plain fabricated demo stays 'demo'.
                state['source'] = (seed.get('_meta') or {}).get('source', 'demo')
                state['sourceErr'] = '' if err == 'no-token' else (err or '')
                state['issues'] = items
        items = state['issues']
        state['todayCount'] = len(items)
        thr = int(state.get('threshold', 1) or 1)
        state['status'] = 'errors' if len(items) >= thr else 'clean'
    if action == 'refresh':
        if _sentry_cfg().get('token'):
            state['buckets'] = {}                        # token path: per-period REST
        else:
            buckets, err = _sentry_periods_via_claude()  # tokenless: Claude+MCP, all periods
            if buckets:
                state['buckets'] = {p: (buckets.get(p) if buckets.get(p) is not None
                                        else seed.get(p, [])) for p in _SENTRY_PERIODS}
                state['source'] = 'live-mcp'
                state['sourceErr'] = err or ''
            else:
                state['buckets'] = {}
                state['sourceErr'] = err or ''
        _recompute(state.get('period', 'week'))
        state['lastCheck'] = _gadget_now_iso()
    elif action == 'acknowledge':
        state['issues'] = []
        state['todayCount'] = 0
        state['status'] = 'clean'
        state['lastCheck'] = _gadget_now_iso()
    elif action == 'setThreshold':
        try:
            state['threshold'] = int(params.get('value'))
        except Exception:
            pass
        cnt = int(state.get('todayCount', 0) or 0)
        thr = int(state.get('threshold', 1) or 1)
        state['status'] = 'errors' if cnt >= thr else 'clean'
    elif action == 'filter':
        p = params.get('period')
        if p in _SENTRY_PERIODS:
            state['period'] = p
            _recompute(p)
        state['lastCheck'] = _gadget_now_iso()
    else:
        return None
    return state


def _today_pull_clickup():
    """Pull Vova's active (unfinished) ClickUp tasks via a headless `claude -p` run
    that uses the ClickUp MCP (tokenless, machine-level OAuth). Returns
    (items, None) on success or (None, reason). Each item: {cuId, text}."""
    import subprocess, re
    binp = _claude_bin()
    if not binp:
        return None, 'no-claude'
    prompt = (
        'Use the ClickUp MCP tools to get up to 40 of MY currently active tasks '
        '(assigned to me, status NOT done/closed/complete) across the workspace. '
        'For EACH task collect: id, name, due_date, description, and url. '
        'Then output ONLY a compact JSON array (no prose, no code fence). Each '
        'element: {"cuId": task id string, "text": task name, '
        '"due": due date as "YYYY-MM-DD" (convert from the ms timestamp; empty '
        'string "" if the task has no due date), '
        '"desc": first ~400 chars of the task description as plain text (empty '
        'string if none), "url": task url string}. If none, output [].'
    )
    try:
        p = subprocess.run(
            [binp, '-p', prompt, '--model', 'sonnet',
             '--allowedTools',
             'mcp__clickup__clickup_filter_tasks,mcp__clickup__clickup_search,'
             'mcp__clickup__clickup_get_workspace_hierarchy,'
             'mcp__clickup__clickup_resolve_assignees',
             '--output-format', 'json'],
            capture_output=True, text=True, timeout=170, cwd=DIR)
    except subprocess.TimeoutExpired:
        return None, 'timeout'
    except Exception as e:
        return None, str(e)[:80]
    if p.returncode != 0:
        return None, 'exit-%s' % p.returncode
    try:
        env = json.loads(p.stdout)
        r = env.get('result', '') if isinstance(env, dict) else ''
        m = re.search(r'\[.*\]', r, re.S)
        arr = json.loads(m.group(0)) if m else []
    except Exception as e:
        return None, 'parse:' + str(e)[:50]
    items = []
    for it in arr:
        if not isinstance(it, dict):
            continue
        txt = (it.get('text') or '').strip()
        if not txt:
            continue
        due = (it.get('due') or '').strip()[:10]
        # keep only well-formed YYYY-MM-DD, else drop to empty (→ «Все наступне»)
        if not re.match(r'^\d{4}-\d{2}-\d{2}$', due):
            due = ''
        items.append({
            'cuId': str(it.get('cuId') or ''),
            'text': txt,
            'due': due,
            'desc': (it.get('desc') or '').strip()[:600],
            'url': (it.get('url') or '').strip()[:400],
        })
    return items, None


def _today_action(state, action, params, gdir):
    """Custom handler for the 'today' gadget. Only pullClickUp needs server compute
    (live ClickUp via MCP); every other action falls through to the generic
    append/patch executor (return None)."""
    if action != 'pullClickUp':
        return None
    items, err = _today_pull_clickup()
    state['pulledAt'] = _gadget_now_iso()
    if err:
        state['pullError'] = {
            'no-claude': 'CLI недоступний на цій машині',
            'timeout': 'таймаут — спробуй ще раз',
        }.get(err, 'не вдалось (%s)' % err)
        return state
    tasks = state.get('tasks') or []
    by_cu = {t['cuId']: t for t in tasks if t.get('cuId')}
    for it in items:
        cu = it['cuId']
        if cu and cu in by_cu:
            # refresh live fields on the existing task (name/due/desc/url may
            # have changed in ClickUp); never touch done/wip/substeps/quadrant
            t = by_cu[cu]
            if it['text']:
                t['text'] = it['text']
            t['dueDate'] = it.get('due') or ''
            if it.get('desc'):
                t['desc'] = it['desc']
            if it.get('url'):
                t['url'] = it['url']
            continue
        nt = {
            'id': 'cu-' + (cu or _gadget_now_iso()),
            'text': it['text'],
            'done': False,
            'source': 'clickup',
            'cuId': cu or None,
            'dueDate': it.get('due') or '',
            'desc': it.get('desc') or '',
            'url': it.get('url') or '',
            'substeps': [],
            'createdAt': _gadget_now_iso(),
        }
        tasks.append(nt)
        if cu:
            by_cu[cu] = nt
    state['tasks'] = tasks
    state['pullError'] = ''
    return state


# Per-gadget custom handlers. Gadgets whose actions are pure declarative state
# patches need NO entry here (generic patch fallback handles them).
_GADGET_HANDLERS = {
    'errors-monitor': _errors_monitor_action,
    'today': _today_action,
}


def _gadget_apply_action(gid, action, params):
    """Apply one manifest-declared action to a gadget's state. Returns
    (ok, new_state_or_error_string)."""
    gdir = _gadget_dir(gid)
    manifest = _gadget_read_json(os.path.join(gdir, 'manifest.json'))
    if not manifest:
        return False, 'unknown gadget'
    declared = {a.get('name') for a in (manifest.get('actions') or [])}
    if action not in declared:
        return False, 'unknown action: %s' % action
    params = params if isinstance(params, dict) else {}
    state = _gadget_load_state(gid)
    handler = _GADGET_HANDLERS.get(gid)
    new_state = handler(dict(state), action, params, gdir) if handler else None
    if new_state is None:
        # Declarative op executor: builder-generated gadgets carry an `op` on each
        # action (set/increment/toggle/append/reset), so they need NO custom Python.
        spec = next((a for a in (manifest.get('actions') or []) if a.get('name') == action), {})
        new_state = _gadget_apply_op(dict(state), spec, params, manifest)
    _gadget_save_state(gid, new_state)
    return True, new_state


def _gadget_apply_op(state, spec, params, manifest):
    """Interpret a declarative action spec against state. Supported ops:
    set / increment / toggle / append / reset. Unknown -> generic {patch} merge."""
    op = (spec.get('op') or '').lower()
    field = spec.get('field')
    if op == 'set' and field:
        state[field] = params.get('value', spec.get('value'))
    elif op == 'increment' and field:
        try:
            by = float(params.get('by', spec.get('by', 1)))
        except Exception:
            by = 1.0
        try:
            cur = float(state.get(field, 0) or 0)
        except Exception:
            cur = 0.0
        v = cur + by
        v = int(v) if float(v).is_integer() else v
        mn, mx = spec.get('min'), spec.get('max')
        if isinstance(mn, (int, float)) and v < mn:
            v = mn
        if isinstance(mx, (int, float)) and v > mx:
            v = mx
        state[field] = v
    elif op == 'toggle' and field:
        state[field] = not state.get(field)
    elif op == 'append' and field:
        arr = state.get(field)
        arr = arr if isinstance(arr, list) else []
        arr.append(params.get('value', spec.get('value')))
        state[field] = arr
    elif op == 'reset':
        to = spec.get('reset')
        state = dict(to if isinstance(to, dict) else (manifest.get('initialState') or {}))
    else:
        patch = params.get('patch')
        if isinstance(patch, dict):
            state.update(patch)
    return state


def _gadget_extract_json(s):
    s = (s or '').strip()
    if s.startswith('```'):
        s = s.strip('`')
        if s[:4].lower() == 'json':
            s = s[4:]
    try:
        return json.loads(s)
    except Exception:
        pass
    import re
    m = re.search(r'\{.*\}', s, re.S)
    if m:
        try:
            return json.loads(m.group(0))
        except Exception:
            return None
    return None


def _gadget_keyword_fallback(text, action_names):
    """Deterministic command mapping used when no LLM key is available."""
    t = (text or '').lower()
    def has(*ws):
        return any(w in t for w in ws)
    if 'refresh' in action_names and has('онов', 'refresh', 'переч', 'заново'):
        return {'action': 'refresh', 'params': {}}
    if 'acknowledge' in action_names and has('прибр', 'очист', 'ack', 'побач', 'зчит', 'чист'):
        return {'action': 'acknowledge', 'params': {}}
    if 'filter' in action_names and has('тиж'):
        return {'action': 'filter', 'params': {'period': 'week'}}
    if 'filter' in action_names and has('сьогодн', 'today'):
        return {'action': 'filter', 'params': {'period': 'today'}}
    return None


def _gadget_pick_action(gid, text):
    """Operate mode: a cheap LLM (Gemini Flash -> OpenAI) picks ONE declared action
    from free text, given the manifest actions + current state. Falls back to a
    deterministic keyword map if no LLM key. Returns (chosen_or_None, reply_text)."""
    gdir = _gadget_dir(gid)
    manifest = _gadget_read_json(os.path.join(gdir, 'manifest.json')) or {}
    actions = manifest.get('actions') or []
    names = {a.get('name') for a in actions}
    state = _gadget_load_state(gid)
    sys_prompt = (manifest.get('aiInstructions', '') or '') + '\n\n' + (
        'Тобі дають список доступних дій гаджета і поточний стан. Обери РІВНО одну '
        'дію, що відповідає запиту, або жодної. Відповідай ЧИСТИМ JSON без markdown: '
        '{"action": "<name або null>", "params": {...}, "reply": "<коротка укр відповідь>"}. '
        'Якщо це питання про стан (напр. чи є помилки), постав action=null і дай '
        'відповідь у reply, дивлячись на стан.')
    user_prompt = ('Дії:\n' + json.dumps(actions, ensure_ascii=False)
                   + '\n\nСтан:\n' + json.dumps(state, ensure_ascii=False)
                   + '\n\nЗапит користувача: ' + text)
    raw = None
    try:
        raw = _gemini_generate(sys_prompt + '\n\n' + user_prompt)
    except Exception:
        try:
            raw = _openai_chat(sys_prompt, user_prompt)
        except Exception:
            raw = None
    if raw:
        parsed = _gadget_extract_json(raw)
        if isinstance(parsed, dict):
            act = parsed.get('action')
            reply = (parsed.get('reply') or '').strip()
            if act in names:
                return {'action': act, 'params': parsed.get('params') or {}}, reply
            return None, reply
    # No LLM (or unparseable) -> deterministic keyword fallback.
    kw = _gadget_keyword_fallback(text, names)
    if kw:
        return kw, 'Готово.'
    return None, 'Не зрозумів команди. Спробуй: онови, прибери, поріг N, за тиждень.'


# ── Chat mode (context-preserving) ────────────────────────────────────────────
# Unlike Operate (_gadget_pick_action, single-shot), Chat keeps a per-gadget
# conversation in apps/<id>/chat.json and feeds the recent turns + current state
# to the model, so the user can have a real back-and-forth. Model: Gemini 3.5
# Flash (Medium) via the Antigravity `agy` CLI (Vova's pick), with graceful
# degradation to the billed REST Gemini, then OpenAI, then a keyword fallback.

_GADGET_CHAT_MODEL = os.environ.get('GADGET_CHAT_MODEL', 'Gemini 3.5 Flash (Medium)')
# Models the in-app chat may pick (client sends a label; anything else -> default).
_GADGET_CHAT_MODELS = {'Gemini 3.5 Flash (Medium)', 'Gemini 3.5 Flash (High)'}
_GADGET_CHAT_MAX_TURNS = 24   # how many messages we persist (bounds file + prompt)
_GADGET_CHAT_CTX_TURNS = 12   # how many recent messages we send as context


def _gadget_chat_path(gid):
    return os.path.join(_gadget_dir(gid), 'chat.json')


def _gadget_chat_load(gid):
    d = _gadget_read_json(_gadget_chat_path(gid)) or {}
    msgs = d.get('messages')
    return msgs if isinstance(msgs, list) else []


def _gadget_chat_save(gid, messages):
    messages = messages[-_GADGET_CHAT_MAX_TURNS:]
    with open(_gadget_chat_path(gid), 'w', encoding='utf-8') as f:
        json.dump({'messages': messages}, f, ensure_ascii=False, indent=2)
    return messages


def _agy_generate(prompt, model=None, timeout=90):
    """Single-shot generation via the Antigravity `agy` CLI (subscription BYOK).
    Mirrors scripts/gemini.sh core: `agy -p PROMPT --model MODEL`. agy can exit 0
    with empty stdout on quota, so empty output is treated as failure. Raises so
    the caller can fall back."""
    import subprocess
    if not _AGY_BIN:
        raise RuntimeError('agy not installed')
    r = subprocess.run([_AGY_BIN, '-p', prompt, '--model', model or _GADGET_CHAT_MODEL],
                       capture_output=True, text=True, timeout=timeout)
    out = (r.stdout or '').strip()
    if not out:
        raise RuntimeError('agy empty (rc=%s) %s' % (r.returncode, (r.stderr or '')[:160]))
    return out


def _gadget_chat_llm(prompt, model=None):
    """agy (chosen Gemini model) -> REST Gemini (billed) -> OpenAI.
    Returns (text_or_None, engine_label)."""
    model = model or _GADGET_CHAT_MODEL
    try:
        return _agy_generate(prompt, model), 'agy:' + model
    except Exception:
        pass
    try:
        return _gemini_generate(prompt), 'gemini-rest'
    except Exception:
        pass
    try:
        return _openai_chat('Ти асистент гаджета. Відповідай українською, стисло.', prompt), 'openai'
    except Exception:
        return None, None


def _gadget_chat(gid, text, model=None):
    """One chat turn with memory. Loads history, sends recent turns + state to the
    model, applies an action if the model asked for one, persists both messages."""
    model = model if model in _GADGET_CHAT_MODELS else _GADGET_CHAT_MODEL
    gdir = _gadget_dir(gid)
    manifest = _gadget_read_json(os.path.join(gdir, 'manifest.json')) or {}
    actions = manifest.get('actions') or []
    names = {a.get('name') for a in actions}
    state = _gadget_load_state(gid)
    history = _gadget_chat_load(gid)

    sys_prompt = (
        (manifest.get('aiInstructions', '') or '')
        + '\n\nТи асистент-помічник ВСЕРЕДИНІ цього гаджета. Веди живий діалог: '
          'памʼятай попередні репліки і відповідай у контексті. Користувач може '
          'питати будь-що про дані гаджета. Відповідай українською, стисло і по суті '
          '(1-4 речення), без markdown-заголовків.\n'
          'Якщо користувач ЯВНО просить виконати дію гаджета (онови / прибери / '
          'постав поріг N / за тиждень чи сьогодні) — додай її; інакше action=null.\n'
          'Поверни РІВНО ОДИН чистий JSON без markdown-огорожі: '
          '{"reply":"<відповідь українською>","action":"<name або null>","params":{...}}.'
    )
    ctx = history[-_GADGET_CHAT_CTX_TURNS:]
    convo = '\n'.join(
        ('Користувач: ' if m.get('role') == 'user' else 'Асистент: ') + (m.get('text') or '')
        for m in ctx)
    user_prompt = (
        'Доступні дії:\n' + json.dumps(actions, ensure_ascii=False)
        + '\n\nПоточні дані гаджета (state):\n' + json.dumps(state, ensure_ascii=False)
        + (('\n\nІсторія розмови (для контексту):\n' + convo) if convo else '')
        + '\n\nНове повідомлення користувача: ' + text)

    raw, engine = _gadget_chat_llm(sys_prompt + '\n\n' + user_prompt, model)

    reply = ''
    chosen = None
    if raw:
        parsed = _gadget_extract_json(raw)
        if isinstance(parsed, dict):
            reply = (parsed.get('reply') or '').strip()
            act = parsed.get('action')
            if act in names:
                chosen = {'action': act, 'params': parsed.get('params') or {}}
        else:
            reply = raw.strip()
    if not reply and not chosen:
        kw = _gadget_keyword_fallback(text, names)
        if kw:
            chosen, reply = kw, 'Готово.'
        else:
            reply = 'Не вдалося відповісти зараз. Спробуй ще раз.'

    new_state = state
    if chosen:
        ok, result = _gadget_apply_action(gid, chosen['action'], chosen.get('params') or {})
        if ok:
            new_state = result

    now = _gadget_now_iso()
    history.append({'role': 'user', 'text': text, 'ts': now})
    history.append({'role': 'assistant', 'text': reply, 'ts': now,
                    'action': (chosen['action'] if chosen else None)})
    messages = _gadget_chat_save(gid, history)
    return {'reply': reply, 'messages': messages, 'state': new_state,
            'engine': engine, 'action': (chosen['action'] if chosen else None)}


# ── Builder mode ──────────────────────────────────────────────────────────────
# Describe a gadget in words -> a cheap LLM returns a SAFE declarative SPEC (no
# code): name, icon, initialState, actions (with an `op`), and a `view` of blocks
# from a fixed vocabulary. The generic runtime view (apps/_runtime/view.html)
# renders any such spec; the declarative op executor runs its actions. Zero code
# execution, so a generated gadget can never break out of its data.

_GADGET_OPS = {'set', 'increment', 'toggle', 'append', 'reset'}
_GADGET_VIEW_KINDS = {'traffic', 'stat', 'list', 'counter', 'toggle', 'text', 'buttons'}
_TRANSLIT = {
    'а':'a','б':'b','в':'v','г':'h','ґ':'g','д':'d','е':'e','є':'ie','ж':'zh','з':'z',
    'и':'y','і':'i','ї':'i','й':'i','к':'k','л':'l','м':'m','н':'n','о':'o','п':'p',
    'р':'r','с':'s','т':'t','у':'u','ф':'f','х':'kh','ц':'ts','ч':'ch','ш':'sh',
    'щ':'shch','ь':'','ю':'iu','я':'ia',"'":'',
}


def _gadget_slugify(s):
    import re
    s = (s or '').strip().lower()
    out = ''.join(_TRANSLIT.get(ch, ch) for ch in s)
    out = re.sub(r'[^a-z0-9]+', '-', out).strip('-')
    return out or 'gadget'


def _gadget_unique_id(base):
    base = _gadget_slugify(base)
    apps_dir = os.path.join(DIR, 'apps')
    cand, n = base, 2
    while os.path.exists(os.path.join(apps_dir, cand)):
        cand = '%s-%d' % (base, n); n += 1
    return cand


_GADGET_BUILD_SYSTEM = (
    'Ти конструктор гаджетів для ChatView. За описом користувача поверни РІВНО один '
    'JSON-обʼєкт (без markdown, без пояснень) що описує маленький гаджет ДЕКЛАРАТИВНО. '
    'Схема:\n'
    '{"id":"ascii-slug","name":"Коротка укр назва","icon":"один емодзі",'
    '"description":"одне речення","initialState":{...початкові поля...},'
    '"actions":[{"name":"ascii-slug","description":"укр","op":"set|increment|toggle|append|reset",'
    '"field":"поле стану","by":1,"value":...,"reset":{...},"min":0,"max":100}],'
    '"aiInstructions":"як маппити фрази у дії, укр",'
    '"view":[{"kind":"traffic|stat|list|counter|toggle|text|buttons",...}]}\n'
    'Блоки view: '
    'traffic {label, field, goodValue} світлофор по полю; '
    'stat {label, field, unit?} велике число; '
    'counter {label, field, actions:[{label, action}]} лічильник з кнопками; '
    'list {label, field} список з масиву; '
    'toggle {label, field, action}; text {label, field}; '
    'buttons {actions:[{label, action}]}. '
    'Кожен action у view МУСИТЬ існувати в actions. op=increment для +/- (field, by), '
    'op=reset повертає initialState (reset:{...}), op=set ставить value, op=toggle булеве, '
    'op=append додає у масив. Ніякого коду, тільки ці поля. Українською для людських рядків.'
)

_GADGET_BUILD_EXAMPLE = (
    '{"id":"water","name":"Склянки води","icon":"💧","description":"Лічильник води за день.",'
    '"initialState":{"count":0,"goal":8},'
    '"actions":[{"name":"add","description":"Додати склянку","op":"increment","field":"count","by":1,"min":0},'
    '{"name":"reset","description":"Скинути","op":"reset","reset":{"count":0,"goal":8}}],'
    '"aiInstructions":"випив/додай -> add; скинь/обнули -> reset.",'
    '"view":[{"kind":"counter","label":"Випито","field":"count","actions":[{"label":"+1 склянка","action":"add"}]},'
    '{"kind":"stat","label":"Ціль","field":"goal","unit":"скл"},'
    '{"kind":"buttons","actions":[{"label":"Скинути день","action":"reset"}]}]}'
)


def _gadget_generate_spec(description):
    prompt_sys = _GADGET_BUILD_SYSTEM + '\n\nПриклад коректної відповіді:\n' + _GADGET_BUILD_EXAMPLE
    user = 'Опис гаджета від користувача: ' + description + '\n\nПоверни ТІЛЬКИ JSON.'
    raw = None
    try:
        raw = _gemini_generate(prompt_sys + '\n\n' + user)
    except Exception:
        try:
            raw = _openai_chat(prompt_sys, user)
        except Exception as e:
            return False, 'LLM недоступний: %s' % e
    spec = _gadget_extract_json(raw)
    if not isinstance(spec, dict):
        return False, 'LLM повернув не-JSON'
    return True, spec


def _gadget_validate_spec(spec):
    name = (spec.get('name') or '').strip()
    if not name:
        return False, 'спек без name'
    icon = (spec.get('icon') or '🧩').strip()[:4] or '🧩'
    init = spec.get('initialState') if isinstance(spec.get('initialState'), dict) else {}
    # Actions: keep only valid ops + slug names.
    actions = []
    for a in (spec.get('actions') or []):
        if not isinstance(a, dict):
            continue
        op = (a.get('op') or '').lower()
        nm = _gadget_slugify(a.get('name') or op or 'action')
        if op not in _GADGET_OPS or not nm:
            continue
        clean = {'name': nm, 'description': (a.get('description') or '').strip(), 'op': op}
        for k in ('field', 'by', 'value', 'reset', 'min', 'max'):
            if k in a:
                clean[k] = a[k]
        actions.append(clean)
    if not actions:
        return False, 'спек без валідних actions'
    act_names = {a['name'] for a in actions}
    # View: keep only known kinds; drop button/action refs to missing actions.
    view = []
    for b in (spec.get('view') or []):
        if not isinstance(b, dict) or b.get('kind') not in _GADGET_VIEW_KINDS:
            continue
        if isinstance(b.get('actions'), list):
            b['actions'] = [x for x in b['actions'] if isinstance(x, dict) and x.get('action') in act_names]
        if b.get('action') and b['action'] not in act_names:
            b.pop('action', None)
        view.append(b)
    if not view:
        return False, 'спек без валідного view'
    gid = _gadget_unique_id(spec.get('id') or name)
    manifest = {
        'id': gid, 'name': name, 'icon': icon,
        'description': (spec.get('description') or '').strip(),
        'initialState': init, 'actions': actions,
        'aiInstructions': (spec.get('aiInstructions') or '').strip(),
        'view': view, 'builtBy': 'builder',
    }
    return True, manifest


_APP_PLACEHOLDER_HTML = (
    '<!doctype html><html lang="uk"><head><meta charset="utf-8">'
    '<meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">'
    '<style>html,body{margin:0;height:100%}body{display:flex;align-items:center;justify-content:center;'
    'font:15px/1.5 -apple-system,BlinkMacSystemFont,"Segoe UI",Roboto,sans-serif;background:#f6f7fb;color:#6b7280;'
    'text-align:center;padding:24px}@media(prefers-color-scheme:dark){body{background:#0f1420;color:#94a0b8}}'
    '.b{max-width:320px}.e{font-size:40px;margin-bottom:10px}</style></head>'
    '<body><div class="b"><div class="e">\U0001f9e9</div>'
    '<div>Апка ще порожня.<br>'
    'Опиши в чаті, який додаток зробити, і я його зберу.</div></div></body></html>'
)

_APP_BUILDER_INSTRUCTIONS = '''# Режим: КОНСТРУКТОР ДОДАТКА (app-builder)

Ти будуєш ChatView-додаток `{app_id}`. Файли: `tools/viz/chat/apps/{app_id}/`. Канал: `{channel}`.
Кожне повідомлення Vova = запит створити або змінити цей додаток.

Цикл на КОЖНЕ повідомлення:
1. Створи/онови `apps/{app_id}/view.html` — самодостатній HTML+CSS+JS. Світла/темна тема через `data-theme` (читай `?theme=` з URL), поля вводу `font-size:16px`, адаптив під мобільний sheet.
2. Онови `apps/{app_id}/manifest.json` (name, icon), якщо змінилась суть.
3. Скрін + картка: `node tools/viz/chat/app-shot.cjs {app_id} {channel}`.
4. Коротка відповідь 1-2 рядки що змінив (render-message.cjs, картка text). Без стін тексту.

Правила:
- Будуй якісно (Opus). Vova може перемкнути модель каналу на Sonnet для дрібниць.
- Ітеруй скільки треба, тримай контекст попередніх правок.
- Коли Vova каже «Готово» — зареєструй: `node tools/viz/chat/app-register.cjs {app_id} "<Назва>" "<іконка>" "<опис>"`, потім підтвердь.
- НЕ чіпай файли поза `apps/{app_id}/`.
'''

_APP_WELCOME_WIDGETS = [
    {"type": "header", "title": "\U0001f9e9 Конструктор додатка", "subtitle": "Опиши словами — я зберу і покажу скрін"},
    {"type": "text", "text": "Напиши, який додаток тобі потрібен. Наприклад: «лічильник склянок води з ціллю 8» або «список покупок з галочками».\n\nЯ збиратиму його крок за кроком і після кожної зміни кидатиму скрін. Пиши скільки треба, доводимо разом."},
    {"type": "checklist", "title": "Як це працює", "items": [
        {"text": "Опиши додаток словами — я збираю (Opus) і кидаю скрін", "state": "pending"},
        {"text": "Кажеш правки — міняю і надсилаю новий скрін", "state": "pending"},
        {"text": "Модель перемикається у \u2699 каналу: Розумний (Opus) \u2194 Баланс (Sonnet)", "state": "pending"},
        {"text": "Кажеш «Готово» — додаток зʼявляється у списку Додатків", "state": "pending"}
    ]},
    {"type": "suggestions", "chips": [
        {"label": "Лічильник води з ціллю 8", "prompt": "Зроби лічильник склянок води за день з ціллю 8, кнопкою +1 і скиданням."},
        {"label": "Список покупок", "prompt": "Зроби список покупок: додавання пунктів, галочки, видалення."},
        {"label": "Трекер звички", "prompt": "Зроби трекер звички на тиждень: 7 днів, відмічаю виконано, показує серію."},
        {"label": "Готово \u2713", "prompt": "Готово, зареєструй цей додаток у списку Додатків."}
    ]}
]


def _app_post_card(ch_dir, widgets, from_, tag):
    # Append a message card (widgets) into a channel dir (render-message.cjs format).
    import re as _re, time as _time
    from datetime import datetime as _dt
    idx_path = os.path.join(ch_dir, 'index.json')
    try:
        items = json.load(open(idx_path)) if os.path.exists(idx_path) else []
    except Exception:
        items = []
    if not isinstance(items, list):
        items = []
    max_id = 0
    for it in items:
        if isinstance(it, dict) and isinstance(it.get('id'), int):
            max_id = max(max_id, it['id'])
    try:
        for fn in os.listdir(ch_dir):
            m = _re.match(r'^(\d+)\.json$', fn)
            if m:
                max_id = max(max_id, int(m.group(1)))
    except Exception:
        pass
    nid = max_id + 1
    fname = '%04d.json' % nid
    with open(os.path.join(ch_dir, fname), 'w', encoding='utf-8') as f:
        json.dump(widgets, f, ensure_ascii=False)
    ts = _time.strftime('%H:%M:%S')
    items = [it for it in items if not (isinstance(it, dict) and it.get('file') == fname)]
    items.append({'id': nid, 'file': fname, 'timestamp': ts,
                  'iso': _dt.now().astimezone().isoformat(), 'from': from_, 'tag': tag})
    items.sort(key=lambda x: x.get('id', 0) if isinstance(x, dict) else 0)
    _atomic_write_json(idx_path, items)


def _gadget_build(description):
    description = (description or '').strip()
    if not description:
        return False, 'порожній опис'
    ok, spec = _gadget_generate_spec(description)
    if not ok:
        return False, spec
    ok, manifest = _gadget_validate_spec(spec)
    if not ok:
        return False, manifest
    gid = manifest['id']
    gdir = os.path.join(DIR, 'apps', gid)
    os.makedirs(gdir, exist_ok=True)
    with open(os.path.join(gdir, 'manifest.json'), 'w', encoding='utf-8') as f:
        json.dump(manifest, f, ensure_ascii=False, indent=2)
    with open(os.path.join(gdir, 'state.json'), 'w', encoding='utf-8') as f:
        json.dump(manifest.get('initialState') or {}, f, ensure_ascii=False, indent=2)
    # Register in apps/index.json (dedupe by id).
    idx_path = os.path.join(DIR, 'apps', 'index.json')
    idx = _gadget_read_json(idx_path) or {}
    gadgets = idx.get('gadgets') if isinstance(idx.get('gadgets'), list) else []
    gadgets = [g for g in gadgets if g.get('id') != gid]
    gadgets.append({'id': gid, 'name': manifest['name'], 'icon': manifest['icon'],
                    'description': manifest['description']})
    with open(idx_path, 'w', encoding='utf-8') as f:
        json.dump({'gadgets': gadgets}, f, ensure_ascii=False, indent=2)
    return True, {'id': gid, 'name': manifest['name'], 'icon': manifest['icon']}


def _gadget_set_pin(gid, pinned):
    """Toggle a gadget's pinned flag in apps/index.json (persists + syncs across
    devices). Returns (ok, gadgets_or_error)."""
    idx_path = os.path.join(DIR, 'apps', 'index.json')
    idx = _gadget_read_json(idx_path) or {}
    gadgets = idx.get('gadgets') if isinstance(idx.get('gadgets'), list) else []
    found = False
    for g in gadgets:
        if g.get('id') == gid:
            if pinned:
                g['pinned'] = True
            else:
                g.pop('pinned', None)
            found = True
    if not found:
        return False, 'unknown gadget'
    with open(idx_path, 'w', encoding='utf-8') as f:
        json.dump({'gadgets': gadgets}, f, ensure_ascii=False, indent=2)
    return True, gadgets


def _gadget_delete(gid):
    """Remove a gadget: drop it from apps/index.json and rm -rf apps/<id>.
    Returns (ok, gadgets_or_error)."""
    import shutil
    idx_path = os.path.join(DIR, 'apps', 'index.json')
    idx = _gadget_read_json(idx_path) or {}
    gadgets = idx.get('gadgets') if isinstance(idx.get('gadgets'), list) else []
    kept = [g for g in gadgets if g.get('id') != gid]
    if len(kept) == len(gadgets):
        return False, 'unknown gadget'
    with open(idx_path, 'w', encoding='utf-8') as f:
        json.dump({'gadgets': kept}, f, ensure_ascii=False, indent=2)
    # Best-effort remove the gadget's own folder (guard against path escapes:
    # only a plain basename that equals the id is allowed).
    try:
        safe = os.path.basename(gid)
        if safe and safe == gid:
            d = os.path.join(DIR, 'apps', safe)
            if os.path.isdir(d):
                shutil.rmtree(d, ignore_errors=True)
    except Exception:
        pass
    return True, kept


# ── Canvas page pins ──────────────────────────────────────────────────────────
# Third pinnable entity next to chats (index.json -> pinned) and gadgets
# (apps/index.json -> pinned): a tldraw PAGE of the canvas (Vova 2026-07-28,
# «як мені запинити канву?»). Pages themselves live inside the canvas app and reach
# ChatView only through the postMessage bridge, so the pin (id + human name at pin
# time) is stored HERE — the rail must render the chip even when the canvas iframe is
# closed and the bridge silent. Name refreshes on every re-pin / rename that passes by.
CANVAS_PINS_FILE = os.path.join(DIR, 'canvas-pins.json')


def _canvas_pins_read():
    """List of pinned canvas pages: [{id, name}]. Missing/corrupt file -> []."""
    try:
        with open(CANVAS_PINS_FILE, encoding='utf-8') as f:
            data = json.load(f)
    except Exception:
        return []
    pins = data.get('pins') if isinstance(data, dict) else data
    if not isinstance(pins, list):
        return []
    out = []
    for p in pins:
        if isinstance(p, dict) and p.get('id'):
            out.append({'id': str(p['id']), 'name': str(p.get('name') or p['id'])})
    return out


def _canvas_set_pin(page_id, name=None, pinned=None):
    """Toggle (or set) a canvas page's pin. Returns the new full list of pins."""
    pins = _canvas_pins_read()
    have = next((p for p in pins if p['id'] == page_id), None)
    want = (not have) if pinned is None else bool(pinned)
    if want:
        if have:
            if name:
                have['name'] = str(name)
        else:
            pins.append({'id': str(page_id), 'name': str(name or page_id)})
    else:
        pins = [p for p in pins if p['id'] != page_id]
    _atomic_write_json(CANVAS_PINS_FILE, {'pins': pins})
    return pins


# ── Live server-push (SSE) ────────────────────────────────────────────────────
# ChatView historically polled /channels/<id>/index.json + plan.json + channel-state
# every 1.2-2s. /api/sse gives the client an instant push instead: one long-lived
# text/event-stream per channel that fires a `change` event the moment a watched file
# in channels/<id>/ changes mtime (new/edited message, plan, live/turn state). The 2s
# pollers stay as a silent fallback (client just backs their cadence off while SSE is
# healthy), so nothing breaks if SSE is unavailable behind a proxy or capped out.
_SSE_LOCK = threading.Lock()
_SSE_COUNT = 0
_SSE_MAX = 48   # hard ceiling on concurrent streams; over it → 503 → client polls.


# ── Hot-file cache (channels/<id>/*.json) ────────────────────────────────────
# Every poll re-read these from DISK: index.json (80 KB on a long channel), plan.json
# and message NNNN.json — once per column, per 2s, per client. With ~10 columns open
# that is a firehose of open()/read() that CPython serialises on the GIL: sampling the
# server showed every worker thread parked in take_gil + open/stat while requests timed
# out (Vova: "лаги, чат вю є причиною"). Keyed by (mtime_ns, size) so ANY write bumps
# the key and stale data is impossible — a poll then costs one os.stat() plus a memory
# read instead of hitting the disk. Vova 2026-07-15.
_FILE_CACHE = {}
_FILE_CACHE_LOCK = threading.Lock()
_FILE_CACHE_MAX_FILES = 600           # bounded so a huge channel set cannot grow it forever
_FILE_CACHE_MAX_BYTES = 512 * 1024    # skip big files; they are not on the poll path


def _cached_file_bytes(path):
    """(data, mtime_ns) for `path`, from RAM when the file is unchanged on disk.
    Returns (None, None) when missing / too large / unreadable so the caller can fall
    back to normal static serving. Never raises."""
    try:
        st = os.stat(path)
    except OSError:
        return None, None
    if not stat_module.S_ISREG(st.st_mode) or st.st_size > _FILE_CACHE_MAX_BYTES:
        return None, None
    stamp = (st.st_mtime_ns, st.st_size)
    with _FILE_CACHE_LOCK:
        hit = _FILE_CACHE.get(path)
        if hit is not None and hit[0] == stamp:
            return hit[1], st.st_mtime_ns
    try:
        with open(path, 'rb') as f:
            data = f.read()
    except OSError:
        return None, None
    with _FILE_CACHE_LOCK:
        # Cheap bound: the hot set refills within one poll cycle, so a flush is far
        # cheaper than tracking true LRU on every request.
        if len(_FILE_CACHE) >= _FILE_CACHE_MAX_FILES:
            _FILE_CACHE.clear()
        _FILE_CACHE[path] = (stamp, data)
    return data, st.st_mtime_ns


class Handler(http.server.SimpleHTTPRequestHandler):
    # HTTP/1.1 => KEEP-ALIVE. The default (HTTP/1.0) closes the socket after every
    # response, so each poll paid a fresh TCP handshake. Chrome allows only ~6 sockets
    # per host, so ~15 polls/s (10 columns) queued behind that churn: measured from the
    # browser the median request took 157ms and the worst 1193ms, while the very same
    # request over curl took 0.8ms — i.e. the time was queueing, not work. With
    # keep-alive the sockets are reused and the queue collapses. Vova 2026-07-15.
    #
    # SAFETY: HTTP/1.1 has no message framing without Content-Length, so a body sent
    # without it would make the client hang waiting for more. end_headers() below
    # detects that case and forces Connection: close, which restores exactly the old
    # HTTP/1.0 behaviour for those responses. So keep-alive is opt-in per response:
    # only handlers that declare Content-Length get it.
    protocol_version = 'HTTP/1.1'

    # LEAK GUARD до keep-alive вище. Без timeout сервер НІКОЛИ не закриває з'єднання
    # сам: виміряно на ізольованій копії — 60 кинутих keep-alive сокетів висіли всі
    # 60 і через 35 секунд простою. Кожна закрита вкладка / завершений контекст
    # Playwright лишав по кілька таких, і два e2e-прогони підряд з'їдали стелю
    # дескрипторів. socketserver ставить це значення сокету через settimeout(), а
    # BaseHTTPRequestHandler.handle_one_request ловить socket.timeout і закриває
    # з'єднання. Таймер тікає лише на СОКЕТ-операції: довга обробка запиту (agy,
    # рендер, subprocess) його не чіпає, бо в цей час сервер нічого не читає.
    # 65с з запасом більші за 2-секундний полінг клієнта, тож живі вкладки нічого
    # не помічають, а кинуте з'єднання вмирає само. Env лише щоб регресійний тест
    # не чекав хвилину; у бою значення не чіпаємо.
    timeout = int(os.environ.get('CHATVIEW_IDLE_TIMEOUT') or 65)

    def send_header(self, keyword, value):
        if keyword.lower() == 'content-length':
            self._has_content_length = True
        super().send_header(keyword, value)

    def end_headers(self):
        # Audio responses set their own Cache-Control ('public, max-age=3600') and
        # must NOT get the no-store anti-cache headers: 'no-store' tells the browser
        # not to keep the media buffer, which makes <audio> re-fetch on every
        # scrubber drag and breaks smooth seeking. Skip the no-cache block for them.
        if not getattr(self, '_skip_no_cache', False):
            self.send_header('Cache-Control', 'no-cache, no-store, must-revalidate')
            self.send_header('Pragma', 'no-cache')
            self.send_header('Expires', '0')
        # HTTP/1.1 framing guard (see protocol_version above). A response whose length
        # the client cannot know (no Content-Length, not a 204/304) has no end marker
        # under keep-alive, so the browser would wait forever. Closing the connection
        # IS the end marker — this is precisely what HTTP/1.0 did for every response,
        # so such handlers behave exactly as before. Handlers that DO send
        # Content-Length (static files, _json, the cached JSON path) keep the socket
        # alive and skip the next handshake.
        code = getattr(self, '_cv_status', None)
        if not getattr(self, '_has_content_length', False) and code not in (204, 304):
            self.send_header('Connection', 'close')
            self.close_connection = True
        super().end_headers()

    def send_response(self, code, message=None):
        # Reset per-response state (handlers are reused across keep-alive requests, so
        # a stale _has_content_length from the previous request would wrongly keep a
        # length-less response alive and hang the client).
        self._has_content_length = False
        self._cv_status = code
        super().send_response(code, message)

    def _strip_proxy_prefix(self):
        # code-server reverse proxy: /absproxy/<port>/... -> strip the prefix so
        # the backend resolves files normally. Remember the prefix so that, for
        # the HTML page, we can patch in-browser fetch() to re-add it (the page
        # uses absolute fetch('/channels'), '/api' which would otherwise hit the
        # code-server root on :8080 instead of the chat server).
        import re as _re
        self.proxy_prefix = ''
        m = _re.match(r'^(/absproxy/\d+)(/.*)?$', self.path)
        if m:
            self.proxy_prefix = m.group(1)
            self.path = m.group(2) or '/'

    def _json_cors(self, code, payload):
        """JSON response with permissive CORS (canvas agent endpoints may be
        called cross-origin, mirroring server/index.ts's app.use CORS block)."""
        self._send_json_raw(code, json.dumps(payload, ensure_ascii=False).encode())

    def _send_json_raw(self, code, raw):
        """Same response as _json_cors, but from ALREADY-serialized bytes.

        Lets a handler build its payload inside a lock and hand the socket write
        out here, outside it. Writing to a socket blocks for as long as the peer
        wants (a client that stalls or vanishes mid-transfer), so a lock held
        across the write is a lock the whole server can lose forever."""
        self.send_response(code)
        self.send_header('Content-Type', 'application/json')
        self.send_header('Access-Control-Allow-Origin', '*')
        self.send_header('Access-Control-Allow-Methods', 'GET,POST,PUT,DELETE,OPTIONS')
        self.send_header('Access-Control-Allow-Headers', 'Content-Type')
        self.end_headers()
        self.wfile.write(raw)

    def do_OPTIONS(self):
        self._strip_proxy_prefix()
        self.send_response(204)
        self.send_header('Access-Control-Allow-Origin', '*')
        self.send_header('Access-Control-Allow-Methods', 'GET,POST,PUT,DELETE,OPTIONS')
        self.send_header('Access-Control-Allow-Headers', 'Content-Type')
        self.end_headers()

    # ---- Canvas GET routes (Phase 1 merge) -------------------------------
    def _canvas_do_GET(self, path_only):
        """Handle canvas static + API GETs. Returns True if handled."""
        import re as _re
        # 1) Static SPA at /canvas/ (built with vite base=/canvas/).
        if path_only == '/canvas' :
            self.send_response(301)
            self.send_header('Location', (self.proxy_prefix or '') + '/canvas/')
            self.end_headers()
            return True
        if path_only == '/canvas/' or path_only.startswith('/canvas/'):
            rel = path_only[len('/canvas/'):]  # '' or 'assets/foo.js'
            # SPA fallback: empty path or a non-file path -> index.html.
            if rel == '':
                fpath = os.path.join(CANVAS_DIST, 'index.html')
            else:
                cand = os.path.normpath(os.path.join(CANVAS_DIST, rel))
                if not cand.startswith(os.path.realpath(CANVAS_DIST)) and not cand.startswith(CANVAS_DIST):
                    self.send_error(403); return True
                fpath = cand if os.path.isfile(cand) else os.path.join(CANVAS_DIST, 'index.html')
            if not os.path.isfile(fpath):
                self.send_error(404, 'canvas dist missing — run `npm run build` in tools/canvas-cmd')
                return True
            ctype = self._guess_ctype(fpath)
            try:
                with open(fpath, 'rb') as f:
                    body = f.read()
            except Exception as e:
                self.send_error(500, str(e)); return True
            self.send_response(200)
            self.send_header('Content-Type', ctype)
            self.send_header('Content-Length', str(len(body)))
            self.end_headers()
            self.wfile.write(body)
            return True

        # 2) Canvas data API (ROOT-relative, called by the canvas app).
        if path_only == '/api/canvas':
            # Serialize under the lock, write the socket outside it. The store is
            # ~2 MB: json.dumps costs tens of ms, but pushing those bytes to a
            # client that stalls or disappears mid-transfer blocks indefinitely —
            # and while that write sat inside `with _canvas_lock`, ONE dead client
            # froze every canvas endpoint until restart (measured: /api/canvas and
            # pending-shapes both http=000 after 120 s, lock-free routes ~6 ms).
            with _canvas_lock:
                raw = json.dumps({
                    'store': _canvas['store'], 'schema': _canvas['schema'],
                    'version': _canvas['version'],
                    'tombstones': [{'id': i} for i in _canvas_tombstones],
                }, ensure_ascii=False).encode()
            self._send_json_raw(200, raw)
            return True
        if path_only == '/api/canvas/bookmarks':
            if not os.path.exists(BOOKMARKS_FILE):
                self._json_cors(200, []); return True
            try:
                with open(BOOKMARKS_FILE, encoding='utf-8') as f:
                    self._json_cors(200, json.load(f))
            except Exception:
                self._json_cors(200, [])
            return True
        if path_only == '/api/canvas/pending-shapes':
            with _canvas_lock:
                to_send = list(_pending_shapes)
                _pending_shapes.clear()
                ver = _canvas['version']
                tombs = [{'id': i} for i in _canvas_tombstones]
            self._json_cors(200, {'shapes': to_send, 'version': ver, 'tombstones': tombs})
            return True
        if path_only == '/api/canvas/pending-deletes':
            with _canvas_lock:
                to_send = list(_pending_deletes)
                _pending_deletes.clear()
            self._json_cors(200, {'ids': to_send})
            return True
        m = _re.match(r'^/api/data/([^/]+)$', path_only)
        if m:
            filename = _re.sub(r'[^a-zA-Z0-9_-]', '', m.group(1))
            fpath = os.path.join(CANVAS_DATA_DIR, f'{filename}.json')
            if not os.path.exists(fpath):
                self._json_cors(404, {'error': f'File not found: {filename}.json'})
                return True
            try:
                with open(fpath, encoding='utf-8') as f:
                    self._json_cors(200, json.load(f))
            except Exception:
                self._json_cors(500, {'error': 'Failed to parse JSON'})
            return True
        if path_only == '/api/file-preview':
            import urllib.parse as _up
            qs = _up.parse_qs(self.path.split('?', 1)[1] if '?' in self.path else '')
            raw_path = (qs.get('path') or [''])[0]
            if not raw_path:
                self._json_cors(400, {'error': 'path required'}); return True
            full = _safe_repo_path(raw_path)
            if full is None:
                self._json_cors(403, {'error': 'Access denied. Only projects/, processes/, decisions/, data/ allowed.'})
                return True
            if not os.path.exists(full):
                self._json_cors(404, {'error': f'File not found: {raw_path}'}); return True
            try:
                with open(full, encoding='utf-8') as f:
                    content = f.read()
                self.send_response(200)
                self.send_header('Content-Type', 'text/plain; charset=utf-8')
                self.send_header('Access-Control-Allow-Origin', '*')
                self.end_headers()
                self.wfile.write(content.encode('utf-8'))
            except Exception as e:
                self._json_cors(500, {'error': str(e)})
            return True
        return False

    def _guess_ctype(self, fpath):
        ext = os.path.splitext(fpath)[1].lower()
        return {
            '.html': 'text/html; charset=utf-8',
            '.js': 'text/javascript; charset=utf-8',
            '.mjs': 'text/javascript; charset=utf-8',
            '.css': 'text/css; charset=utf-8',
            '.json': 'application/json; charset=utf-8',
            '.svg': 'image/svg+xml',
            '.png': 'image/png',
            '.jpg': 'image/jpeg', '.jpeg': 'image/jpeg',
            '.gif': 'image/gif', '.webp': 'image/webp',
            '.ico': 'image/x-icon',
            '.woff': 'font/woff', '.woff2': 'font/woff2', '.ttf': 'font/ttf',
            '.map': 'application/json',
        }.get(ext, 'application/octet-stream')

    def _serve_sse(self):
        """Long-lived Server-Sent Events stream for ONE channel. Watches the
        channel's files by mtime and pushes a `change` event (grouped: msgs / plan /
        state) the instant one changes, so the UI updates near-instantly instead of
        waiting for the 2s poll. Sends a heartbeat comment every ~15s so a dead socket
        is noticed and EventSource auto-reconnects. Silent no-op on client disconnect."""
        global _SSE_COUNT
        import urllib.parse as _up
        qs = _up.parse_qs(self.path.split('?', 1)[1] if '?' in self.path else '')
        channel = (qs.get('channel') or ['main'])[0]
        if not channel or '/' in channel or '..' in channel:
            self.send_response(400)
            self.end_headers()
            return
        ch_dir = os.path.join(DIR, 'channels', channel)
        # Cap concurrent streams; over the ceiling reply 503 so the client keeps its
        # 2s polling fallback instead of piling up daemon threads. The refusal is
        # DECIDED under the lock but WRITTEN outside it — same rule as the canvas
        # routes (see _send_json_raw): a socket write blocks for as long as the peer
        # wants, so a lock held across one is a lock the server can lose forever.
        # Here that would freeze every new stream AND the `finally` decrement of
        # every stream still running.
        with _SSE_LOCK:
            over_cap = _SSE_COUNT >= _SSE_MAX
            if not over_cap:
                _SSE_COUNT += 1
        if over_cap:
            self.send_response(503)
            self.send_header('Retry-After', '10')
            self.end_headers()
            return
        try:
            self._skip_no_cache = True   # keep a single clean Cache-Control (below)
            self.send_response(200)
            self.send_header('Content-Type', 'text/event-stream; charset=utf-8')
            self.send_header('Cache-Control', 'no-cache')
            self.send_header('Connection', 'keep-alive')
            self.send_header('X-Accel-Buffering', 'no')   # disable proxy buffering
            self.send_header('Access-Control-Allow-Origin', '*')
            self.end_headers()
            # Grouped watch set → client maps each group to the matching poll:
            #   msgs  → _poll (new / rev-bumped message; index.json is rewritten on both)
            #   plan  → _pollPlan
            #   state → _pollState (busy / live turn stream / perm gate / usage / model …)
            groups = {
                'msgs': ('index.json',),
                'plan': ('plan.json',),
                'state': ('live.json', 'perm-pending.json', 'busy', 'cc-busy',
                          'cc-done', 'usage.json', 'model', 'permission',
                          'voice-auto', 'autocompact', 'effort', 'session-id',
                          'queue'),
            }

            def _sig(names):
                acc = []
                for n in names:
                    try:
                        acc.append(os.stat(os.path.join(ch_dir, n)).st_mtime_ns)
                    except OSError:
                        acc.append(0)
                return tuple(acc)

            last = {g: _sig(names) for g, names in groups.items()}
            # `hello` tells the client SSE is live so it flips its pollers to the slow
            # safety cadence. Any write failure here means the socket is already gone.
            self.wfile.write(b'event: hello\ndata: {"ok":true}\n\n')
            self.wfile.flush()
            beat = 0
            while True:
                time.sleep(0.5)
                changed = [g for g, names in groups.items()
                           if _sig(names) != last[g]]
                if changed:
                    for g in changed:
                        last[g] = _sig(groups[g])
                    self.wfile.write(
                        ('event: change\ndata: '
                         + json.dumps({'changed': changed}) + '\n\n').encode())
                    self.wfile.flush()
                    beat = 0
                else:
                    beat += 1
                    if beat >= 30:   # ~15s with no change → heartbeat
                        self.wfile.write(b': ping\n\n')
                        self.wfile.flush()
                        beat = 0
        except (BrokenPipeError, ConnectionResetError, OSError, ValueError):
            pass   # client went away / socket closed → end the stream quietly
        finally:
            with _SSE_LOCK:
                _SSE_COUNT -= 1

    def _serve_v2_index(self, fpath):
        """Serve the V2 entry html, with the absproxy fetch shim when needed."""
        try:
            html = open(fpath, 'rb').read()
            if self.proxy_prefix:
                shim = (
                    "<script>(function(){var P=" + json.dumps(self.proxy_prefix) +
                    ";var of=window.fetch;window.fetch=function(u,o){"
                    "if(typeof u==='string'&&u.charAt(0)==='/'&&u.indexOf(P)!==0)"
                    "u=P+u;return of(u,o);};})();</script>"
                ).encode()
                html = html.replace(b'<head>', b'<head>' + shim, 1)
                # the bundle's own <script src="/assets/..."> needs the prefix too
                html = html.replace(b'"/assets/', b'"' + self.proxy_prefix.encode() + b'/assets/')
            self.send_response(200)
            self.send_header('Content-Type', 'text/html; charset=utf-8')
            self.send_header('Content-Length', str(len(html)))
            self.end_headers()
            self.wfile.write(html)
        except (BrokenPipeError, ConnectionResetError):
            pass
        except Exception as e:
            self._json(500, {'error': str(e)})

    def _serve_v2_asset(self, fpath):
        """Serve one file out of the V2 dist (hash-named js/css/fonts/images)."""
        try:
            ctype = mimetypes.guess_type(fpath)[0] or 'application/octet-stream'
            with open(fpath, 'rb') as f:
                blob = f.read()
            self.send_response(200)
            self.send_header('Content-Type', ctype)
            self.send_header('Content-Length', str(len(blob)))
            self.end_headers()
            self.wfile.write(blob)
        except (BrokenPipeError, ConnectionResetError):
            pass
        except Exception as e:
            self._json(500, {'error': str(e)})

    def do_GET(self):
        self._strip_proxy_prefix()
        path_only = self.path.split('?')[0]
        if self._canvas_do_GET(path_only):
            return
        if path_only == '/api/sse':
            self._serve_sse()
            return
        # ── Hot poll path: channels/<id>/*.json straight from the mtime cache ──
        # These three (index.json / plan.json / NNNN.json) are what every column polls
        # every ~2s. Default static serving re-open()s and re-read()s them each time,
        # which is what pinned the GIL and made the server time out with many columns
        # open. Here: one os.stat(), body from RAM, plus an ETag so a revalidating
        # client gets a 304 with NO body at all (80 KB -> ~0). Cache-Control is
        # 'no-cache' (revalidate every time) and NOT the global 'no-store', because
        # no-store forbids the browser from keeping a copy, which would make the 304
        # path impossible. Correctness is preserved: the ETag is (mtime_ns, size), so
        # any write invalidates it instantly. Vova 2026-07-15.
        if path_only.startswith('/channels/') and path_only.endswith('.json'):
            fpath = self.translate_path(self.path)   # sanitised; strips query/fragment
            data, mtime_ns = _cached_file_bytes(fpath)
            if data is not None:
                etag = 'W/"%x-%x"' % (mtime_ns, len(data))
                self._skip_no_cache = True
                if self.headers.get('If-None-Match') == etag:
                    self.send_response(304)
                    self.send_header('ETag', etag)
                    self.send_header('Cache-Control', 'no-cache')
                    self.end_headers()
                    return
                self.send_response(200)
                self.send_header('Content-Type', 'application/json; charset=utf-8')
                self.send_header('Content-Length', str(len(data)))
                self.send_header('ETag', etag)
                self.send_header('Cache-Control', 'no-cache')
                self.end_headers()
                try:
                    self.wfile.write(data)
                except (BrokenPipeError, ConnectionResetError):
                    pass          # client navigated away mid-write; harmless
                return
            # miss (missing/too big) → fall through to normal static serving
        # Media files (audio + video): serve with HTTP Range so <audio>/<video>
        # can seek. Python's SimpleHTTPRequestHandler returns 200 with the full
        # body and no Accept-Ranges, which breaks scrubbing. We handle media here.
        media_ct = {
            '.mp3': 'audio/mpeg', '.m4a': 'audio/mp4', '.ogg': 'audio/ogg',
            '.mp4': 'video/mp4', '.m4v': 'video/mp4', '.webm': 'video/webm',
            '.mov': 'video/quicktime', '.ogv': 'video/ogg',
        }.get(os.path.splitext(path_only)[1].lower())
        if media_ct:
            # Let end_headers() keep a single clean Cache-Control for media (see above).
            self._skip_no_cache = True
            try:
                fpath = os.path.normpath(os.path.join(DIR, path_only.lstrip('/')))
                # Block path traversal outside the served dir.
                if not (fpath == DIR or fpath.startswith(DIR + os.sep)):
                    self.send_error(403)
                    return
                if not os.path.isfile(fpath):
                    self.send_error(404)
                    return
                size = os.path.getsize(fpath)
                range_hdr = self.headers.get('Range')
                if range_hdr and range_hdr.startswith('bytes='):
                    try:
                        spec = range_hdr[6:].split('-', 1)
                        start = int(spec[0]) if spec[0] else 0
                        end = int(spec[1]) if len(spec) > 1 and spec[1] else size - 1
                        end = min(end, size - 1)
                        if start > end or start >= size:
                            self.send_response(416)
                            self.send_header('Content-Range', f'bytes */{size}')
                            self.end_headers()
                            return
                        length = end - start + 1
                        self.send_response(206)
                        self.send_header('Content-Type', media_ct)
                        self.send_header('Accept-Ranges', 'bytes')
                        self.send_header('Content-Range', f'bytes {start}-{end}/{size}')
                        self.send_header('Content-Length', str(length))
                        self.send_header('Cache-Control', 'public, max-age=3600')
                        self.end_headers()
                        with open(fpath, 'rb') as f:
                            f.seek(start)
                            remaining = length
                            while remaining > 0:
                                chunk = f.read(min(65536, remaining))
                                if not chunk: break
                                self.wfile.write(chunk)
                                remaining -= len(chunk)
                        return
                    except (ValueError, ConnectionResetError, BrokenPipeError):
                        pass
                # No Range header: full file but still advertise Accept-Ranges.
                self.send_response(200)
                self.send_header('Content-Type', media_ct)
                self.send_header('Accept-Ranges', 'bytes')
                self.send_header('Content-Length', str(size))
                self.send_header('Cache-Control', 'public, max-age=3600')
                self.end_headers()
                with open(fpath, 'rb') as f:
                    while True:
                        chunk = f.read(65536)
                        if not chunk: break
                        self.wfile.write(chunk)
                return
            except (BrokenPipeError, ConnectionResetError):
                # Клієнт закрив плеєр посеред віддачі. Відповідати вже нікому:
                # send_error нижче сам би писав у мертвий сокет і кидав ДРУГИЙ
                # BrokenPipe уже поза do_GET, а socketserver друкував би повний
                # трасбек. Саме цим був розкачаний viz-chat.error.log до 23 МБ.
                self.close_connection = True
                return
            except Exception as e:
                self.send_error(500, str(e))
                return
        # Offline EXPORT: stream a .zip with chatview-data/ + claude-sessions/ +
        # manifest.json so the user can move chats + Claude context to another
        # machine. See transfer.py. Binary attachment download.
        if path_only == '/api/export':
            try:
                fname, blob = _transfer.build_export_zip(
                    DIR, CLAUDE_REPO_ROOT, _encode_project_dir, log=print)
                self.send_response(200)
                self.send_header('Content-Type', 'application/zip')
                self.send_header('Content-Disposition',
                                 f'attachment; filename="{fname}"')
                self.send_header('Content-Length', str(len(blob)))
                self.send_header('Access-Control-Allow-Origin', '*')
                self.end_headers()
                self.wfile.write(blob)
            except Exception as e:
                self._json(500, {'error': str(e)})
            return
        # code version for client auto-reload (mtime of index.html)
        if path_only == '/api/version':
            try:
                st = os.stat(_v2_index_path() or os.path.join(DIR, 'index.html'))
                self._json(200, {'version': st.st_mtime_ns})
            except Exception as e:
                self._json(500, {'error': str(e)})
            return
        # Account info — just the signed-in Claude account email. Read from
        # ~/.claude.json -> oauthAccount.emailAddress. Minimal, email only.
        if path_only == '/api/account':
            try:
                cfg = os.path.join(os.path.expanduser('~'), '.claude.json')
                email = ''
                if os.path.exists(cfg):
                    with open(cfg, encoding='utf-8') as f:
                        data = json.load(f)
                    acct = data.get('oauthAccount') if isinstance(data, dict) else None
                    if isinstance(acct, dict):
                        email = (acct.get('emailAddress') or '').strip()
                self._json(200, {'email': email})
            except Exception as e:
                # Never crash the UI over a missing/garbled config — empty email.
                self._json(200, {'email': '', 'error': str(e)})
            return
        # BYOK status — which keys are configured, masked. Never returns the raw
        # secret, only set/unset + a masked tail so the UI can show "•••• 1a2b".
        if path_only == '/api/keys':
            try:
                def _mask(v):
                    v = (v or '').strip()
                    if not v:
                        return ''
                    return ('•' * 4) + ' ' + v[-4:] if len(v) >= 4 else '•' * len(v)
                oa = _load_openai_key()
                gm = _load_gemini_key()
                self._json(200, {
                    'openai': {'set': bool(oa), 'masked': _mask(oa)},
                    'gemini': {'set': bool(gm), 'masked': _mask(gm)},
                })
            except Exception as e:
                self._json(500, {'error': str(e)})
            return
        # Desk Mode status: everything the Settings panel needs to render the
        # "Доступ з планшета" row + the "Режим стола" toggle. Read-only, quiet on
        # error (never blocks the panel). See _dm_* helpers above.
        if path_only == '/api/desk-mode':
            # Feature-gated: in a distributed build REMOTE_ACCESS is off, so the panel
            # gets enabled:false and hides the whole "Доступ з планшета" row.
            if not REMOTE_ACCESS:
                self._json(200, {'ok': True, 'enabled': False})
                return
            try:
                self._json(200, {
                    'ok': True,
                    'enabled': True,
                    'tailscale': _dm_tailscale_state(),
                    'caffeinate': _dm_caffeinate_running(),
                    'disablesleep': _dm_disablesleep(),
                    'helper_installed': _dm_helper_installed(),
                    'flag': _dm_read_flag(),
                    'serve_configured': _dm_serve_configured(),
                    'chatview_url': _dm_chatview_url(),
                })
            except Exception as e:
                self._json(500, {'ok': False, 'error': str(e)})
            return
        # Connected services ("Інтеграції"). Lists the MCP servers wired into
        # this workspace as user-facing "сервіси" with human Ukrainian names +
        # a one-line "що дає". NEVER leaks the word "MCP" into user-facing fields.
        # Sources merged (later wins only for presence, names come from the map):
        #   1. ~/.claude.json -> mcpServers            (global / user scope)
        #   2. ~/.claude.json -> projects[REPO].mcpServers (project scope)
        #   3. REPO_ROOT/.mcp.json -> mcpServers       (repo-local, e.g. playwright)
        # Live status comes from `claude mcp list` (CLI) when it answers quickly;
        # otherwise we degrade to "configured" (⚪) so the endpoint never hangs/500s.
        if path_only == '/api/integrations':
            try:
                self._json(200, _build_integrations())
            except Exception as e:
                # Never break the panel — empty list + the error for debugging.
                self._json(200, {'ok': False, 'integrations': [], 'error': str(e)})
            return
        # Antigravity CLI — available models on this subscription. Feeds the future
        # UI model-switcher. Best-effort: parse `agy models` output into a list; if
        # the format is unfamiliar we return the raw text so nothing is lost.
        if path_only == '/api/antigravity/models':
            try:
                import subprocess
                if not _AGY_BIN:
                    self._json(503, {'ok': False, 'error': 'agy CLI not installed'})
                    return
                r = subprocess.run([_AGY_BIN, 'models'],
                                   capture_output=True, text=True, timeout=60)
                raw = (r.stdout or '').strip()
                if r.returncode != 0:
                    self._json(502, {'ok': False,
                                     'error': (r.stderr or raw or 'agy models failed').strip()[:500]})
                    return
                # Heuristic parse: keep non-empty lines, strip common list bullets /
                # ANSI-ish decoration, drop obvious header lines. Fall back to raw.
                import re as _re_agy
                models = []
                for ln in raw.splitlines():
                    s = _re_agy.sub(r'^\s*[-*•>•]\s*', '', ln).strip()
                    if not s:
                        continue
                    low = s.lower()
                    if low.startswith(('available', 'model', 'usage', 'these are')):
                        continue
                    models.append(s)
                self._json(200, {'ok': True, 'models': models, 'raw': raw})
            except subprocess.TimeoutExpired:
                self._json(504, {'ok': False, 'error': 'agy models timed out'})
            except Exception as e:
                self._json(500, {'ok': False, 'error': str(e)})
            return
        # ── Guided Connection Wizard: Antigravity STATUS ──────────────────────
        # Detect install + auth + account + quota. Robust: never hangs (the probe
        # uses a bounded PTY + fresh log, never `agy models` which hangs logged-out),
        # never 500s (any failure degrades to installed:false / logged_in:false).
        if path_only == '/api/connect/antigravity/status':
            try:
                # _agy_status() is now behavior-based: it derives logged_in from
                # `agy models` returning a populated list, and already carries that
                # same list in st['models'] — so the UI gets account + models from
                # ONE source of truth, robust across agy version bumps.
                st = _agy_status()
                st.setdefault('models', [])
                st['ok'] = True
                self._json(200, st)
            except Exception as e:
                # Never break the wizard — return a safe "unknown" shape.
                self._json(200, {'ok': False, 'installed': bool(_AGY_BIN),
                                 'logged_in': False, 'account': None,
                                 'quota_ok': None, 'models': [], 'error': str(e)})
            return
        # ── Guided Connection Wizard: LOGIN poll ─────────────────────────────
        # Poll a live PTY login session by ?session_id=. Returns
        # {state: pending|success|failed, ...}. On success the PTY is torn down.
        if path_only == '/api/connect/antigravity/login/status':
            try:
                import urllib.parse as _up
                qs = _up.parse_qs(self.path.split('?', 1)[1] if '?' in self.path else '')
                sid = (qs.get('session_id') or [''])[0]
                _agy_login_gc()
                sess = _AGY_LOGIN_SESSIONS.get(sid)
                if not sess:
                    # Session gone (expired / server restarted / already reaped on
                    # success). GLOBAL-AUTH-FIRST: the token may already be cached,
                    # so check the keychain before declaring failure. If signed in →
                    # report success so the UI jumps straight to Connected instead of
                    # confusingly resetting. Else → a RECOVERY signal (state=expired)
                    # that the UI turns into "почни заново" WITHOUT wiping the code.
                    try:
                        st = _agy_status()
                    except Exception:
                        st = {'logged_in': False}
                    if st.get('logged_in'):
                        self._json(200, {'ok': True, 'state': 'success',
                                         'account': st.get('account'),
                                         'detail': 'signed in'})
                        return
                    self._json(200, {'ok': False, 'state': 'expired',
                                     'detail': 'сесія входу завершилась'})
                    return
                snap = sess.poll()
                snap['ok'] = True
                if snap.get('state') in ('success', 'failed'):
                    # Session finished — drop it so we don't leak PTYs.
                    _AGY_LOGIN_SESSIONS.pop(sid, None)
                self._json(200, snap)
            except Exception as e:
                self._json(500, {'ok': False, 'state': 'failed', 'detail': str(e)})
            return
        # «Процеси» panel: tail of the channel's events.jsonl (hook fires + tool/agent
        # steps, written by hooks/_emit.cjs + runner.emit_event). Optional ?since=<iso>
        # returns only newer events so the poller pulls just the tail. Vova 2026-07-08.
        if path_only == '/api/events':
            try:
                import urllib.parse as _up
                from datetime import datetime as _dt
                qs = _up.parse_qs(self.path.split('?', 1)[1] if '?' in self.path else '')
                channel = (qs.get('channel') or ['main'])[0]
                since = (qs.get('since') or [''])[0]
                if '/' in channel or '..' in channel:
                    raise ValueError('bad channel')
                p = os.path.join(DIR, 'channels', channel, 'events.jsonl')
                items = []
                if os.path.exists(p):
                    with open(p, encoding='utf-8') as f:
                        for ln in f:
                            ln = ln.strip()
                            if not ln:
                                continue
                            try:
                                rec = json.loads(ln)
                            except Exception:
                                continue
                            if since and (rec.get('ts') or '') <= since:
                                continue
                            items.append(rec)
                items = items[-300:]   # cap payload
                self._json(200, {'ok': True, 'items': items,
                                 'now': _dt.now().isoformat()})
            except Exception as e:
                self._json(500, {'ok': False, 'error': str(e)})
            return
        # «Процеси» panel → 🤖 Агенти section: list this channel's detached agents
        # (channels/<id>/agents/*/status.json). Orphan-reconcile: a 'running' agent whose
        # pid is dead is flipped to 'error' so it never hangs forever. Vova #0047-51 Phase 2.
        if path_only == '/api/agents':
            try:
                import urllib.parse as _up
                from datetime import datetime as _dt
                qs = _up.parse_qs(self.path.split('?', 1)[1] if '?' in self.path else '')
                channel = (qs.get('channel') or ['main'])[0]
                if '/' in channel or '..' in channel:
                    raise ValueError('bad channel')
                agents_root = os.path.join(DIR, 'channels', channel, 'agents')
                items = []
                if os.path.isdir(agents_root):
                    for aid in os.listdir(agents_root):
                        sp = os.path.join(agents_root, aid, 'status.json')
                        try:
                            st = json.load(open(sp, encoding='utf-8'))
                        except Exception:
                            continue
                        if st.get('state') == 'running':
                            pid = st.get('pid')
                            alive = False
                            try:
                                if pid:
                                    os.kill(int(pid), 0)
                                    alive = True
                            except Exception:
                                alive = False
                            if not alive:
                                st['state'] = 'error'
                                st['summary'] = st.get('summary') or 'процес зник (orphan)'
                                st['updatedAt'] = _dt.now().isoformat()
                                try:
                                    _atomic_write_json(sp, st)
                                except Exception:
                                    pass
                        items.append(st)
                items.sort(key=lambda x: x.get('createdAt') or '', reverse=True)
                self._json(200, {'ok': True, 'items': items[:20]})
            except Exception as e:
                self._json(500, {'ok': False, 'error': str(e)})
            return
        # Expanded agent card: full status + tailed progress stream + final output.
        if path_only.startswith('/api/agent/'):
            try:
                import urllib.parse as _up
                aid = path_only[len('/api/agent/'):]
                qs = _up.parse_qs(self.path.split('?', 1)[1] if '?' in self.path else '')
                channel = (qs.get('channel') or ['main'])[0]
                if '/' in channel or '..' in channel or '/' in aid or '..' in aid:
                    raise ValueError('bad id')
                a_dir = os.path.join(DIR, 'channels', channel, 'agents', aid)
                st = json.load(open(os.path.join(a_dir, 'status.json'), encoding='utf-8'))
                prog = []
                pp = os.path.join(a_dir, 'progress.jsonl')
                if os.path.exists(pp):
                    for ln in open(pp, encoding='utf-8'):
                        ln = ln.strip()
                        if ln:
                            try:
                                prog.append(json.loads(ln))
                            except Exception:
                                pass
                out = ''
                op = os.path.join(a_dir, 'output.md')
                if os.path.exists(op):
                    out = open(op, encoding='utf-8').read()
                self._json(200, {'ok': True, 'status': st, 'progress': prog[-100:], 'output': out})
            except Exception as e:
                self._json(500, {'ok': False, 'error': str(e)})
            return
        # Saved (pinned) messages for a channel — read STRAIGHT from the channel's
        # index.json on DISK so ALL pins show after a fresh ChatView boot, not just
        # the ones inside the loaded window. The pinned panel used to derive its list
        # from the in-memory metaById sliding window (last PAGE_SIZE msgs), so any pin
        # older than that vanished on reload — «відкриваєш збережені, там нема нічого»
        # (Vova 2026-07-08). This endpoint is the source of truth for the panel.
        if path_only == '/api/pinned':
            # «Збережені повідомлення» panel data. Reads the FULL channel index (not the
            # browser's sliding window), so pins older than the loaded messages still show
            # after a fresh ChatView boot. Two modes:
            #   ?channel=<id>  -> only that channel's saved messages.
            #   (no channel, or channel=* / all) -> GLOBAL: every saved message across ALL
            #   channels, each tagged with its channel id/label/icon. This is the Telegram
            #   «Saved Messages» model Vova expects: one place, everything, survives restart.
            try:
                import urllib.parse as _up
                qs = _up.parse_qs(self.path.split('?', 1)[1] if '?' in self.path else '')
                channel = (qs.get('channel') or [''])[0]
                ch_root = os.path.join(DIR, 'channels')
                # id -> (label, icon) from the registry for readable channel names.
                reg_path = os.path.join(ch_root, 'index.json')
                labels = {}
                if os.path.exists(reg_path):
                    try:
                        for c in json.load(open(reg_path, encoding='utf-8')):
                            if isinstance(c, dict) and c.get('id'):
                                labels[c['id']] = (c.get('label') or c['id'], c.get('icon') or '💬')
                    except Exception:
                        labels = {}
                # Which channels to scan.
                if channel and channel not in ('*', 'all'):
                    if '/' in channel or '..' in channel:
                        raise ValueError('bad channel')
                    targets = [channel]
                else:
                    targets = []
                    try:
                        for name in sorted(os.listdir(ch_root)):
                            # skip hidden + archived/closed dirs (_closed_*) + the registry file
                            if name.startswith('_') or name.startswith('.'):
                                continue
                            if os.path.isdir(os.path.join(ch_root, name)) and \
                               os.path.exists(os.path.join(ch_root, name, 'index.json')):
                                targets.append(name)
                    except Exception:
                        targets = list(labels.keys())
                out_items = []
                for ch in targets:
                    ch_dir = os.path.join(ch_root, ch)
                    idx_path = os.path.join(ch_dir, 'index.json')
                    if not os.path.exists(idx_path):
                        continue
                    try:
                        idx = json.load(open(idx_path, encoding='utf-8'))
                    except Exception:
                        idx = []
                    lbl, icon = labels.get(ch, (ch, '💬'))
                    for m in idx:
                        if not m.get('pinned'):
                            continue
                        snippet = ''
                        f = m.get('file')
                        if f:
                            fp = os.path.join(ch_dir, f)
                            if os.path.exists(fp):
                                try:
                                    obj = json.load(open(fp, encoding='utf-8'))
                                    widgets = obj if isinstance(obj, list) else (obj.get('widgets') or [])
                                    snippet = _widgets_snippet(widgets)
                                except Exception:
                                    snippet = ''
                        out_items.append({'channel': ch, 'channelLabel': lbl, 'channelIcon': icon,
                                          'id': m.get('id'),
                                          'from': m.get('from') or 'Claude',
                                          'timestamp': m.get('timestamp') or '',
                                          'snippet': snippet or '[повідомлення]'})
                # Group by channel label, newest id first within each channel.
                out_items.sort(key=lambda x: (x.get('channelLabel') or '', -(x.get('id') or 0)))
                self._json(200, {'ok': True, 'items': out_items})
            except Exception as e:
                self._json(500, {'ok': False, 'error': str(e)})
            return
        # Stage 5A: file autocomplete — returns up to 20 repo paths matching ?q=
        if path_only == '/api/files':
            try:
                import urllib.parse as _up
                qs = _up.parse_qs(self.path.split('?', 1)[1] if '?' in self.path else '')
                q = (qs.get('q') or [''])[0].strip().lower()
                import subprocess as _sp
                # REPO_ROOT = parent of DIR (tools/viz/chat -> shared-knowledge)
                repo_root = os.path.dirname(os.path.dirname(os.path.dirname(DIR)))
                # tracked files
                r1 = _sp.run(['git', 'ls-files'],
                    cwd=repo_root, capture_output=True, text=True, timeout=5)
                tracked = r1.stdout.splitlines()
                # untracked (but not ignored) files
                r2 = _sp.run(['git', 'ls-files', '--others', '--exclude-standard'],
                    cwd=repo_root, capture_output=True, text=True, timeout=5)
                untracked = r2.stdout.splitlines()
                all_files = tracked + untracked
                if q:
                    all_files = [l for l in all_files if q in l.lower()]
                # deduplicate, preserve order
                seen_f = set()
                deduped = []
                for f in all_files:
                    if f not in seen_f:
                        seen_f.add(f); deduped.append(f)
                self._json(200, {'files': deduped[:20]})
            except Exception as e:
                self._json(500, {'error': str(e)})
            return

        # Stage 5C: skills autocomplete — scans .claude/skills/*/SKILL.md
        if path_only == '/api/skills':
            try:
                import glob as _glob
                import re as _re
                repo_root = os.path.dirname(os.path.dirname(os.path.dirname(DIR)))
                pattern = os.path.join(repo_root, '.claude', 'skills', '*', 'SKILL.md')
                skills = []
                for skill_path in sorted(_glob.glob(pattern)):
                    skill_name = os.path.basename(os.path.dirname(skill_path))
                    desc = ''
                    try:
                        with open(skill_path, encoding='utf-8') as sf:
                            for line in sf:
                                m = _re.match(r'^description:\s*(.+)', line)
                                if m:
                                    raw = m.group(1).strip().strip('"\'')
                                    # first sentence only (up to 80 chars)
                                    desc = raw[:80]
                                    break
                    except Exception:
                        pass
                    skills.append({'name': skill_name, 'description': desc})
                self._json(200, {'skills': skills})
            except Exception as e:
                self._json(500, {'error': str(e)})
            return

        if path_only == '/api/skills-catalog':
            # READ-only display feed for the Помічники UI: real .claude/skills/*
            # surfaced as вміння. SEPARATE endpoint on purpose — /api/skills above
            # is the slash-autocomplete contract ({name,description}) and must not
            # change shape. Here we return full objects (id "skill:"+dir, source).
            try:
                self._json(200, {'skills': _skills_from_disk()})
            except Exception as e:
                self._json(500, {'error': str(e)})
            return

        if path_only == '/api/effort-default':
            # Global effort default (see _default_effort_read): the map itself plus the
            # level resolved for ?model=<alias>, so the UI can label «дефолт для нових
            # чатів» without duplicating the family/'*'/hard-default chain.
            try:
                import urllib.parse as _up
                q = _up.parse_qs(self.path.split('?', 1)[1] if '?' in self.path else '')
                model = (q.get('model') or [''])[0]
                self._json(200, {'map': _default_effort_read(),
                                 'effort': _default_effort_for(model),
                                 'hardDefault': _EFFORT_HARD_DEFAULT})
            except Exception as e:
                self._json(500, {'error': str(e)})
            return

        # Pinned canvas pages (third pin kind next to chats and gadgets). Read from
        # canvas-pins.json, so the rail has chips even with the canvas iframe closed.
        if path_only == '/api/canvas-pins':
            try:
                self._json(200, {'ok': True, 'pins': _canvas_pins_read()})
            except Exception as e:
                self._json(500, {'ok': False, 'error': str(e)})
            return

        if path_only == '/api/usage-stats':
            # Usage panel: real Claude-limit status (from the SDK -> rate-limit.json)
            # + cost/token spend aggregated from usage-history.jsonl (per day/week/channel).
            try:
                import datetime as _dt
                # Pull the REAL per-window utilization from Anthropic's usage
                # endpoint (the SDK stream never carries it in steady state).
                # TTL-cached + best-effort; on failure we fall back to whatever
                # rate-limit.json already holds.
                try:
                    import usage_api
                    usage_api.refresh()
                except Exception:
                    pass
                rl_limits = []
                rlp = os.path.join(DIR, 'rate-limit.json')
                if os.path.exists(rlp):
                    try:
                        _rlraw = json.load(open(rlp, encoding='utf-8'))
                        if isinstance(_rlraw, dict) and isinstance(_rlraw.get('limits'), dict):
                            rl_limits = [v for v in _rlraw['limits'].values()
                                         if isinstance(v, dict)]
                        elif isinstance(_rlraw, dict) and _rlraw.get('utilization') is not None:
                            rl_limits = [_rlraw]   # legacy flat shape
                    except Exception:
                        rl_limits = []

                # Discount windows whose reset time already passed. A rate-limit
                # window resets at `resetsAt` (UNIX SECONDS — a string at the entry
                # top level, an int in `raw`); once that moment is in the PAST the
                # cap has lifted, so a stale "rejected" left over from a prior window
                # must NOT read as exhausted. Mark it expired + neutralise status so
                # the binding limit and every downstream consumer see reality. Only a
                # window with status "rejected" AND resetsAt in the FUTURE is a real
                # active cap.
                _now_s = time.time()
                def _reset_in_past(w):
                    ra = w.get('resetsAt')
                    if ra is None:
                        return False           # no reset info → cannot expire it
                    try:
                        return float(ra) <= _now_s
                    except (TypeError, ValueError):
                        return False           # unparseable → keep as-is (don't hide a cap)
                for _w in rl_limits:
                    if str(_w.get('status', '')).lower() == 'rejected' and _reset_in_past(_w):
                        _w['expired'] = True
                        _w['status'] = 'allowed'   # window already reset → in-range

                def _util(x):
                    try:
                        return float(x.get('utilization') or 0)
                    except Exception:
                        return 0.0
                # binding limit = a genuinely active cap first (rejected + future
                # reset), then the highest utilization (closest to its cap).
                def _bind_key(x):
                    active_reject = 1 if str(x.get('status', '')).lower() == 'rejected' else 0
                    return (active_reject, _util(x))
                rl_limits.sort(key=_bind_key, reverse=True)
                rl = rl_limits[0] if rl_limits else None
                hist = []
                hp = os.path.join(DIR, 'usage-history.jsonl')
                if os.path.exists(hp):
                    with open(hp, encoding='utf-8') as f:
                        for line in f:
                            line = line.strip()
                            if not line:
                                continue
                            try:
                                hist.append(json.loads(line))
                            except Exception:
                                pass
                now = _dt.datetime.now()
                today = now.date().isoformat()
                wk_start = (now - _dt.timedelta(days=now.weekday())).date().isoformat()
                mon_start = now.replace(day=1).date().isoformat()
                day_of = lambda r: str(r.get('ts', ''))[:10]
                tok = lambda r: int(r.get('in', 0) or 0) + int(r.get('out', 0) or 0)
                by_ch = {}
                tok_in = tok_out = 0
                for r in hist:
                    by_ch[r.get('channel', '?')] = by_ch.get(r.get('channel', '?'), 0) + tok(r)
                    tok_in += int(r.get('in', 0) or 0)
                    tok_out += int(r.get('out', 0) or 0)
                self._json(200, {
                    'rateLimit': rl,                       # binding ліміт (back-compat)
                    'rateLimits': rl_limits,               # ВСІ відомі ліміти (binding зверху)
                    'tokensToday': sum(tok(r) for r in hist if day_of(r) == today),
                    'tokensWeek': sum(tok(r) for r in hist if day_of(r) >= wk_start),
                    'tokensMonth': sum(tok(r) for r in hist if day_of(r) >= mon_start),
                    'turns': len(hist),
                    'tokensIn': tok_in, 'tokensOut': tok_out,
                    'byChannel': [{'channel': c, 'tokens': v} for c, v in
                                  sorted(by_ch.items(), key=lambda kv: -kv[1])[:8]],
                })
            except Exception as e:
                self._json(500, {'error': str(e)})
            return

        # Helpers (Skill Store) — manifest + installed flag per skill.
        # SEPARATE from /api/skills above (which powers slash autocomplete).
        if path_only == '/api/project-state':
            # Phase A of the Project Context Layer: one read-only snapshot of the
            # ecosystem (chats + canvas pages + helpers) for the UI and for the
            # runner per-chat awareness injection (Phase B).
            try:
                import project_state
                self._json(200, project_state.build_project_state(DIR, REPO_ROOT))
            except Exception as e:
                self._json(500, {'ok': False, 'error': str(e)})
            return

        if path_only == '/api/desktop/status':
            # Desktop-shell status backing (a) the update card and (b) the "install
            # Claude Code" onboarding card. Cheap + best-effort; never raises.
            #   version  = the payload version actually running (captured at boot)
            #   claude   = resolved CLI path (BYOK model requires it installed)
            #   update   = a newer payload staged on disk by the background updater,
            #              which applies on the NEXT launch (restart to apply)
            try:
                out = {'desktop': bool(os.environ.get('CHATVIEW_HOME'))}
                running = os.environ.get('CHATVIEW_RUNNING_VERSION')
                try:
                    import chatview_updater as _u
                    if not running:
                        running = _u.read_version(os.path.join(DIR, 'payload'))
                        if running in (None, '', '0.0.0'):
                            running = _u.read_version(DIR)   # dev run: DIR/VERSION
                    staged = _u.read_version(os.path.join(DIR, 'payload'))
                    out['version'] = running
                    out['update'] = {'staged': staged,
                                     'available': _u.is_newer(staged, running or '0.0.0')}
                except Exception:
                    out['version'] = running
                    out['update'] = {'staged': None, 'available': False}
                try:
                    import chatview_platform as _p
                    import chatview_onboarding as _ob
                    out['claude'] = _ob.status_snapshot(_p.Platform.current())
                except Exception:
                    out['claude'] = {'found': False, 'path': None, 'authed': None}
                self._json(200, out)
            except Exception as e:
                self._json(500, {'error': str(e)})
            return

        if path_only == '/api/helpers':
            try:
                manifest = _helpers_manifest()
                out_skills = []
                for sk in manifest.get('skills', []):
                    sid = sk.get('id')
                    installed = bool(sid) and os.path.isdir(
                        os.path.join(_HELPERS_INSTALL_ROOT, sid))
                    # remote = catalog entry that lives in an external repo
                    # (has a url, no local bundle/path folder). Install for
                    # these is git-based, wired separately from the copytree path.
                    remote = bool(sk.get('url')) and not bool(sk.get('bundled')) \
                        and not os.path.isdir(
                            os.path.join(_HELPERS_LIBRARY_DIR,
                                         sk.get('path', '') or '\0'))
                    out_skills.append({
                        'id': sid,
                        'name': sk.get('name'),
                        'category': sk.get('category'),
                        'description': sk.get('description'),
                        'icon': sk.get('icon'),
                        'tags': sk.get('tags', []),
                        'bundled': bool(sk.get('bundled')),
                        'installed': installed,
                        'badge': sk.get('badge'),
                        'source': sk.get('source'),
                        'url': sk.get('url'),
                        'license': sk.get('license'),
                        'install': sk.get('install'),
                        'remote': remote,
                        # Phase 2 enrichment (skill-store onboarding):
                        'hasCode': bool(sk.get('hasCode')),
                        'kind': sk.get('kind'),
                        'professions': sk.get('professions', []),
                    })
                self._json(200, {
                    'categories': manifest.get('categories', []),
                    'skills': out_skills,
                })
            except Exception as e:
                self._json(500, {'error': str(e)})
            return

        if path_only == '/api/personas':
            # Помічники redesign: personas + capabilities. Each cap's `on` flag is
            # the saved override or the `popular` default. Membership (_team),
            # onboarding state and the wizard config travel along.
            try:
                cat = _personas_catalog()
                state = _personas_state()
                caps_state = state.get('caps') if isinstance(state.get('caps'), dict) else {}
                team = state.get('_team') if isinstance(state.get('_team'), list) else []
                cat['personas'] = cat.get('personas', []) + _personas_custom(state)
                # Surface the REAL Claude Code agents alongside catalog + custom,
                # skipping any id already present (defensive against collisions).
                _seen = {p.get('id') for p in cat['personas']}
                cat['personas'] += [a for a in _personas_from_agents()
                                    if a.get('id') not in _seen]
                for p in cat['personas']:
                    pst = caps_state.get(p['id'])
                    active = 0
                    for c in p.get('capabilities', []):
                        on = (pst.get(c['id'], bool(c.get('popular'))) if isinstance(pst, dict)
                              else bool(c.get('popular')))
                        c['on'] = bool(on)
                        active += 1 if c['on'] else 0
                    p['activeCount'] = active
                    p['inTeam'] = p['id'] in team
                cat['onboarded'] = bool(state.get('_onboarded'))
                cat['source'] = state.get('_source')
                cat['teamCount'] = len(team)
                try:
                    cat['onboarding'] = _personas_onboarding()
                except Exception:
                    cat['onboarding'] = {}
                self._json(200, cat)
            except Exception as e:
                self._json(500, {'error': str(e)})
            return

        # Approved testimonial captions (for the "Опис за бест-практиками"
        # button in library.html). Read-only: returns the raw content of
        # content-marketing/polina-descriptions.json. repo_root = three levels
        # up from DIR (tools/viz/chat -> shared-knowledge).
        if path_only == '/api/captions':
            try:
                repo_root = os.path.dirname(os.path.dirname(os.path.dirname(DIR)))
                cap_path = os.path.join(repo_root, 'content-marketing', 'polina-descriptions.json')
                with open(cap_path, encoding='utf-8') as cf:
                    data = json.load(cf)
                self._json(200, data)
            except Exception as e:
                self._json(500, {'error': str(e)})
            return

        # Video Library routes (catalog / thumb / video / publish proxies).
        # Ported from server.cjs so library.html works when server.py holds 5555.
        if self._handle_library_get(path_only):
            return

        # Merged channel registry for the UI tab list: committed index.json +
        # this machine's local cc-* overlay (index.local.json). The static
        # /channels/index.json only has the committed tabs, so the UI fetches
        # this instead to also see auto session channels without polluting the repo.
        if path_only == '/api/channels' or path_only.startswith('/api/channels?'):
            try:
                self._json(200, _merged_registry())
            except Exception as e:
                self._json(500, {'error': str(e)})
            return

        # busy/queued стан УСІХ каналів одним запитом — для статус-крапок на табах.
        # Легкий: тільки існування файлу `busy` + розмір черги, без usage/live.
        if path_only == '/api/channels-state' or path_only.startswith('/api/channels-state?'):
            try:
                out = {}
                ch_root = os.path.join(DIR, 'channels')
                ids = []
                try:
                    for c in _merged_registry():
                        if c.get('id'):
                            ids.append(c['id'])
                except Exception:
                    ids = []
                if not ids and os.path.isdir(ch_root):
                    ids = [d for d in os.listdir(ch_root)
                           if os.path.isdir(os.path.join(ch_root, d))]
                for cid in ids:
                    if not cid or '/' in cid or '..' in cid:
                        continue
                    cd = os.path.join(ch_root, cid)
                    busy = os.path.exists(os.path.join(cd, 'busy'))
                    qd = os.path.join(cd, 'queue')
                    queued = 0
                    if os.path.isdir(qd):
                        queued = len([f for f in os.listdir(qd) if f.endswith('.json')])
                    # native Claude Code activity (hooks write cc-busy / cc-done):
                    # cc_busy = working (yellow dot), cc_done = finished (green dot).
                    cc_busy = os.path.exists(os.path.join(cd, 'cc-busy'))
                    cc_done = os.path.exists(os.path.join(cd, 'cc-done'))
                    out[cid] = {'busy': busy, 'queued': queued,
                                'cc_busy': cc_busy, 'cc_done': cc_done}
                self._json(200, out)
            except Exception as e:
                self._json(500, {'error': str(e)})
            return

        # Global agents bar (Vova 2026-07-13): aggregate RUNNING/QUEUED detached
        # agents across ALL channels for the composer bubble над інпутом (cross-chat
        # awareness). Same orphan-reconcile as /api/agents (a 'running' agent whose pid
        # is dead is flipped to 'error' on disk and skipped). Each surviving item is
        # tagged with its channel + human label + icon so the bubble can stop it and
        # jump to its chat.
        if path_only == '/api/agents-all' or path_only.startswith('/api/agents-all?'):
            try:
                from datetime import datetime as _dt
                labels = {}
                try:
                    for c in _merged_registry():
                        if c.get('id'):
                            labels[c['id']] = {'label': c.get('label') or c['id'],
                                               'icon': c.get('icon') or '💬'}
                except Exception:
                    labels = {}
                ch_root = os.path.join(DIR, 'channels')
                items = []
                if os.path.isdir(ch_root):
                    for cid in os.listdir(ch_root):
                        if not cid or '/' in cid or '..' in cid:
                            continue
                        agents_root = os.path.join(ch_root, cid, 'agents')
                        if not os.path.isdir(agents_root):
                            continue
                        for aid in os.listdir(agents_root):
                            sp = os.path.join(agents_root, aid, 'status.json')
                            try:
                                st = json.load(open(sp, encoding='utf-8'))
                            except Exception:
                                continue
                            if st.get('state') not in ('running', 'queued'):
                                continue
                            if st.get('state') == 'running':
                                pid = st.get('pid')
                                alive = False
                                try:
                                    if pid:
                                        os.kill(int(pid), 0)
                                        alive = True
                                except Exception:
                                    alive = False
                                if not alive:
                                    st['state'] = 'error'
                                    st['summary'] = st.get('summary') or 'процес зник (orphan)'
                                    st['updatedAt'] = _dt.now().isoformat()
                                    try:
                                        _atomic_write_json(sp, st)
                                    except Exception:
                                        pass
                                    continue
                            meta = labels.get(cid) or {}
                            st['channel'] = cid
                            st['channelLabel'] = meta.get('label') or cid
                            st['channelIcon'] = meta.get('icon') or '💬'
                            items.append(st)
                items.sort(key=lambda x: x.get('createdAt') or '', reverse=True)
                self._json(200, {'ok': True, 'items': items[:30]})
            except Exception as e:
                self._json(500, {'ok': False, 'error': str(e)})
            return

        # Реєстр живих процесів (jobs.py): що саме зараз крутиться і чи воно
        # ізольоване. ?channel=<id> звужує до одного каналу, ?all=1 показує і
        # щойно завершені. Джерело для смужки потоків і для діагностики
        # «звідки взявся цей claude».
        if path_only == '/api/jobs' or path_only.startswith('/api/jobs?'):
            try:
                import urllib.parse as _up
                import jobs as _jobs
                qs = _up.parse_qs(self.path.split('?', 1)[1] if '?' in self.path else '')
                channel = (qs.get('channel') or [''])[0].strip()
                show_all = (qs.get('all') or [''])[0] in ('1', 'true', 'yes')
                if channel and ('/' in channel or '..' in channel):
                    raise ValueError('bad channel')
                items = _jobs.list_jobs(channel=channel or None,
                                        running_only=not show_all)
                self._json(200, {'ok': True, 'items': items[:60]})
            except Exception as e:
                self._json(500, {'ok': False, 'error': str(e)})
            return

        # App-builder LIVE preview: the constructor column polls this for the
        # max mtime of the app's files. When it changes (Claude just edited
        # apps/<id>/view.html), the column reloads its preview iframe. Cheap:
        # a shallow walk over one small app dir. Returns {rev: <float mtime>}.
        if path_only == '/api/app-rev' or path_only.startswith('/api/app-rev?'):
            try:
                import urllib.parse as _up
                qs = _up.parse_qs(self.path.split('?', 1)[1] if '?' in self.path else '')
                aid = (qs.get('id') or [''])[0]
                rev = 0.0
                if aid and '/' not in aid and '..' not in aid and '\\' not in aid:
                    adir = os.path.join(DIR, 'apps', aid)
                    if os.path.isdir(adir):
                        for root, _dirs, files in os.walk(adir):
                            for fn in files:
                                try:
                                    m = os.path.getmtime(os.path.join(root, fn))
                                    if m > rev:
                                        rev = m
                                except Exception:
                                    pass
                self._json(200, {'rev': rev})
            except Exception as e:
                self._json(500, {'error': str(e)})
            return

        # Phase B perm gate: the PreToolUse hook polls this for the user's decision.
        if path_only == '/api/perm-status':
            try:
                import urllib.parse as _up
                qs = _up.parse_qs(self.path.split('?', 1)[1] if '?' in self.path else '')
                rid = (qs.get('requestId') or [''])[0]
                with _perm_lock:
                    entry = _perm.get(rid)
                    dec = entry.get('decision') if entry else None
                self._json(200, {'decision': dec or 'pending'})
            except Exception as e:
                self._json(500, {'error': str(e)})
            return

        # per-channel live state: is the runner currently working on it?
        if path_only.startswith('/api/channel-state/'):
            try:
                channel = path_only[len('/api/channel-state/'):]
                if '/' in channel or '..' in channel:
                    raise ValueError('bad channel')
                ch_dir = os.path.join(DIR, 'channels', channel)
                busy = os.path.exists(os.path.join(ch_dir, 'busy'))
                q_dir = os.path.join(ch_dir, 'queue')
                queued = 0
                # Ordered queue contents (same order the runner drains: sorted by
                # numeric stem). Each entry = {id (filename stem), userMsgId} so the
                # front-end can map bubble → queue item, show positions, and cancel
                # the right one. queue[0] = the head (the item being processed when
                # busy). Bad/partial files are skipped, never crash the status poll.
                queue_list = []
                if os.path.isdir(q_dir):
                    import re as _qre
                    qfiles = sorted([f for f in os.listdir(q_dir)
                                     if _qre.match(r'\d+\.json$', f)])
                    queued = len(qfiles)
                    for qf in qfiles:
                        stem = qf[:-len('.json')]
                        umid = None
                        try:
                            with open(os.path.join(q_dir, qf), encoding='utf-8') as _qfh:
                                _qj = json.load(_qfh)
                            umid = _qj.get('user_msg_id')
                        except Exception:
                            umid = None
                        queue_list.append({'id': stem, 'userMsgId': umid})
                # native Claude Code activity dots (hooks write cc-busy / cc-done)
                cc_busy = os.path.exists(os.path.join(ch_dir, 'cc-busy'))
                cc_done = os.path.exists(os.path.join(ch_dir, 'cc-done'))
                # usage/cost meter (written by runner.py after each turn)
                usage = None
                up = os.path.join(ch_dir, 'usage.json')
                if os.path.exists(up):
                    try:
                        usage = json.load(open(up))
                    except Exception:
                        usage = None
                # live turn state (Stage 3): tool steps + streaming text while
                # the runner is mid-turn. Deleted by the runner when done.
                live = None
                lp = os.path.join(ch_dir, 'live.json')
                if os.path.exists(lp):
                    try:
                        live = json.load(open(lp))
                    except Exception:
                        live = None
                # Stage 4: current per-channel model + permission (the exact files
                # the runner reads). The global default is a SINGLE source of
                # truth: env CHAT_RUNNER_MODEL (same var runner.py reads), so the
                # UI shows the real effective model before Vova flips a switch.
                # Was hardcoded 'opus' here vs 'sonnet' in runner.py — now unified.
                model = os.environ.get('CHAT_RUNNER_MODEL', 'sonnet')
                mp = os.path.join(ch_dir, 'model')
                if os.path.exists(mp):
                    try:
                        v = open(mp).read().strip()
                        if v:
                            model = v
                    except Exception:
                        pass
                permission = 'acceptEdits'
                pp = os.path.join(ch_dir, 'permission')
                if os.path.exists(pp):
                    try:
                        v = open(pp).read().strip()
                        if v:
                            permission = v
                    except Exception:
                        pass
                # auto-compact toggle (channels/<id>/autocompact = 1|0).
                # Default ON when the file is absent (mirrors runner.py).
                autocompact = True
                ap = os.path.join(ch_dir, 'autocompact')
                if os.path.exists(ap):
                    try:
                        autocompact = open(ap).read().strip() not in (
                            '0', 'false', 'no', 'off')
                    except Exception:
                        pass
                # forward-context auto-sync toggle (channels/<id>/ctx-autosync
                # = 1|0). Default ON when the file is absent (mirrors runner.py).
                ctx_autosync = True
                cap = os.path.join(ch_dir, 'ctx-autosync')
                if os.path.exists(cap):
                    try:
                        ctx_autosync = open(cap).read().strip() not in (
                            '0', 'false', 'no', 'off')
                    except Exception:
                        pass
                # per-channel auto-voice toggle (channels/<id>/voice-auto = 1|0).
                # Default OFF when the file is absent (opt-in: card posts only get
                # an auto audio widget once Vova flips this on for the channel).
                voice_auto = False
                vap = os.path.join(ch_dir, 'voice-auto')
                if os.path.exists(vap):
                    try:
                        voice_auto = open(vap).read().strip() in (
                            '1', 'true', 'yes', 'on')
                    except Exception:
                        pass
                # per-channel «is thinking on» toggle (channels/<id>/thinking-on
                # = 1|0). Default ON when the file is absent: engine_sdk sends
                # thinking={'type':'adaptive','display':'summarized'} and streams the
                # thought text into live.json. An explicit 0 sends {'type':'disabled'},
                # i.e. no extended thinking at all, which also kills effort.
                # File renamed from `thinking` on 2026-07-29 together with the meaning
                # flip (it used to gate only the DISPLAY): a stale `thinking` = 0 meant
                # «do not show», and reading it under the new semantics would have
                # silently disabled thinking on that channel. See engine_sdk.
                thinking = True
                tkp = os.path.join(ch_dir, 'thinking-on')
                if os.path.exists(tkp):
                    try:
                        thinking = open(tkp).read().strip().lower() not in (
                            '0', 'false', 'no', 'off')
                    except Exception:
                        pass
                # per-channel auto-approve toggle (channels/<id>/perm-auto = 1|0).
                # Default ON when the file is absent (ChatView = 0 prompts, like the
                # Claude Code extension). Review is OPT-IN: only an explicit
                # 0/false/no/off turns the approval gate back on for the channel.
                perm_auto = True
                pap = os.path.join(ch_dir, 'perm-auto')
                if os.path.exists(pap):
                    try:
                        perm_auto = open(pap).read().strip().lower() not in (
                            '0', 'false', 'no', 'off')
                    except Exception:
                        pass
                # Effort level ACTUALLY in force for this channel: its own
                # channels/<id>/effort when set, else the global default map
                # (channels/default-effort.json). Never '' anymore — a channel that
                # was never touched used to report '' while the runner quietly ran
                # 'medium', so the UI showed a level nobody had chosen. Only the SDK
                # engine honors it; the warm engine ignores it.
                effort = _effective_effort(ch_dir, model)
                # Is this channel riding the global default (no own file)? The UI
                # greys the «зробити дефолтом» hint accordingly.
                effort_is_default = not _read_channel_file(ch_dir, 'effort')
                # Phase B: pending tool-permission request (perm-gate.cjs wrote it)
                perm = None
                permf = os.path.join(ch_dir, 'perm-pending.json')
                if os.path.exists(permf):
                    try:
                        perm = json.load(open(permf))
                    except Exception:
                        perm = None
                # current runner session id (channels/<id>/session-id), '' if
                # absent. Used by the UI for the REVERSE handoff command line.
                runner_session_id = ''
                sidp = os.path.join(ch_dir, 'session-id')
                if os.path.exists(sidp):
                    try:
                        runner_session_id = open(sidp).read().strip()
                    except Exception:
                        runner_session_id = ''
                # Has this channel ALREADY inherited the terminal context? The
                # one-shot guard runner.py drops after its first (and only)
                # seed-fork. Once it exists, ctx-autosync can never fire again,
                # so the UI greys the toggle out instead of letting it pretend
                # it still decides anything.
                context_seeded = os.path.exists(
                    os.path.join(ch_dir, '.context-seeded'))
                self._json(200, {'busy': busy, 'queued': queued,
                                 'queue': queue_list,
                                 'cc_busy': cc_busy, 'cc_done': cc_done,
                                 'usage': usage, 'live': live,
                                 'model': model, 'permission': permission,
                                 'autocompact': autocompact,
                                 'ctxAutosync': ctx_autosync,
                                 'contextSeeded': context_seeded,
                                 'voiceAuto': voice_auto,
                                 'thinking': thinking,
                                 'permAuto': perm_auto, 'perm': perm,
                                 'effort': effort,
                                 'effortIsDefault': effort_is_default,
                                 'runnerSessionId': runner_session_id})
            except Exception as e:
                self._json(500, {'error': str(e)})
            return
        # ── D14 cutover: the React bundle owns '/' ──────────────────────
        # Root and /index.html serve V2; /assets/<hashed> comes out of the V2
        # dist (a miss falls through to the legacy assets/ dir, whose files are
        # never hash-named, so the two cannot collide). /v1 keeps the vanilla
        # page one URL away, and CHATVIEW_V1=1 flips '/' back wholesale.
        _v2_idx = _v2_index_path()
        if _v2_idx:
            if path_only in ('', '/', '/index.html'):
                self._serve_v2_index(_v2_idx)
                return
            if path_only.startswith('/assets/'):
                cand = os.path.normpath(os.path.join(V2_DIST, path_only[1:]))
                if cand.startswith(os.path.abspath(V2_DIST)) and os.path.isfile(cand):
                    self._serve_v2_asset(cand)
                    return
        if path_only == '/v1':
            self.path = '/index.html'          # vanilla rollback, always V1
        elif self.path == '/' or self.path == '':
            self.path = '/index.html'
        # When the index page is served through code-server absproxy, inject a
        # tiny shim so absolute fetch() calls keep the /absproxy/<port> prefix.
        if self.proxy_prefix and self.path == '/index.html':
            try:
                html = open(os.path.join(DIR, 'index.html'), 'rb').read()
                shim = (
                    "<script>(function(){var P=" + json.dumps(self.proxy_prefix) +
                    ";var of=window.fetch;window.fetch=function(u,o){"
                    "if(typeof u==='string'&&u.charAt(0)==='/'&&u.indexOf(P)!==0)"
                    "u=P+u;return of(u,o);};})();</script>"
                ).encode()
                html = html.replace(b'<head>', b'<head>' + shim, 1)
                self.send_response(200)
                self.send_header('Content-Type', 'text/html; charset=utf-8')
                self.send_header('Content-Length', str(len(html)))
                self.end_headers()
                self.wfile.write(html)
                return
            except Exception:
                pass
        # Graceful 200 for missing optional JSON files so the browser never
        # logs 404s for channels that exist but have no plan / message index yet.
        import re as _re
        # /channels/<id>/plan.json -> {} when file absent
        m = _re.match(r'^/channels/([^/]+)/plan\.json(\?.*)?$', path_only)
        if m:
            ch = m.group(1)
            fpath = os.path.join(DIR, 'channels', ch, 'plan.json')
            if not os.path.exists(fpath):
                self._json(200, {})
                return
        # /channels/<id>/index.json -> [] when file absent (new empty channel)
        m = _re.match(r'^/channels/([^/]+)/index\.json(\?.*)?$', path_only)
        if m:
            ch = m.group(1)
            fpath = os.path.join(DIR, 'channels', ch, 'index.json')
            if not os.path.exists(fpath):
                self._json(200, [])
                return
        # /apps/index.json -> порожній реєстр, коли теки apps/ ще нема.
        # Пакована десктоп-збірка НЕ везе apps/ (гаджети юзера це дані, не payload),
        # тому у свіжому домі файлу нема і лаунчер валив 404 у консоль на кожен фетч.
        if path_only == '/apps/index.json':
            if not os.path.exists(os.path.join(DIR, 'apps', 'index.json')):
                self._json(200, {'gadgets': []})
                return
        return super().do_GET()

    def _read_body(self):
        length = int(self.headers.get('Content-Length', 0))
        return json.loads(self.rfile.read(length) or b'{}')

    def _json(self, code, payload):
        body = json.dumps(payload, ensure_ascii=False).encode()
        self.send_response(code)
        self.send_header('Content-Type', 'application/json')
        # Content-Length is what lets HTTP/1.1 keep the connection ALIVE for the next
        # request (see protocol_version above). Without it end_headers() has to fall
        # back to Connection: close, i.e. a fresh TCP handshake per poll.
        self.send_header('Content-Length', str(len(body)))
        self.end_headers()
        try:
            self.wfile.write(body)
        except (BrokenPipeError, ConnectionResetError):
            pass

    # ================= Video Library (parity with server.cjs) =================
    # library.html is served from THIS chat server (5555), but the video-library
    # catalog + publish endpoints were originally added only to server.cjs (Node).
    # When server.py holds 5555 those routes were missing -> unknown POST returned
    # an EMPTY body -> the browser threw "Unexpected end of JSON input". These
    # methods port the same surface: catalog/thumb/video served locally, publish
    # proxied to Post Studio (5566). Every branch returns valid JSON on error.

    def _studio_request(self, method, studio_path, payload=None, timeout=25):
        """Call Post Studio (5566). Returns (status:int, json_or_None).
        Raises urllib.error.URLError (not HTTPError) when the studio is down."""
        import urllib.request, urllib.error
        host = os.environ.get('POST_STUDIO_HOST', '127.0.0.1')
        port = os.environ.get('POST_STUDIO_PORT', '5566')
        data = None
        headers = {}
        if payload is not None:
            data = json.dumps(payload, ensure_ascii=False).encode()
            headers['Content-Type'] = 'application/json'
        req = urllib.request.Request(
            'http://%s:%s%s' % (host, port, studio_path),
            data=data, headers=headers, method=method)
        try:
            with urllib.request.urlopen(req, timeout=timeout) as resp:
                raw = resp.read()
                try:
                    return resp.status, json.loads(raw or b'{}')
                except Exception:
                    return resp.status, None
        except urllib.error.HTTPError as e:
            raw = e.read()
            try:
                return e.code, json.loads(raw or b'{}')
            except Exception:
                return e.code, None

    def _read_library(self):
        """pipelines/library.json as a dict. Raises on missing/broken."""
        lib_path = os.path.join(DIR, 'pipelines', 'library.json')
        with open(lib_path, encoding='utf-8-sig') as f:
            return json.load(f)

    @staticmethod
    def _library_file_set(lib):
        allowed = set()
        for cat in (lib.get('categories') or {}).values():
            for f in (cat.get('files') or []):
                allowed.add(f)
        return allowed

    def _resolve_library_file(self, source_folder, basename):
        """Absolute path of a library video by basename, searched recursively
        under source_folder (root wins). Skips trash/work/system dirs."""
        if not source_folder or not basename:
            return None
        target = os.path.basename(basename).lower()
        skip = ('_кошик', 'edits', 'thumbs', '_closed_', 'node_modules')
        for root, dirs, files in os.walk(source_folder):
            dirs[:] = [d for d in dirs
                       if not (d.startswith('.') or d.lower() in skip
                               or d.startswith('$RECYCLE') or d.startswith('System Volume'))]
            for f in files:
                if f.lower() == target:
                    return os.path.join(root, f)
        return None

    def _handle_library_get(self, path_only):
        """Video Library GET routes. Returns True if it handled the request."""
        # 1) catalog
        if path_only == '/api/library':
            try:
                self._json(200, self._read_library())
            except Exception as e:
                self._json(500, {'ok': False, 'error': str(e)})
            return True

        # 2) poster thumbnail (pipelines/thumbs/<slug>.jpg via index.json whitelist)
        if path_only == '/api/thumb':
            try:
                import urllib.parse as _up, re as _re
                qs = _up.parse_qs(self.path.split('?', 1)[1] if '?' in self.path else '')
                name = os.path.basename((qs.get('name') or [''])[0].replace('\\', '/'))
                map_path = os.path.join(DIR, 'pipelines', 'thumbs', 'index.json')
                m = {}
                try:
                    with open(map_path, encoding='utf-8-sig') as f:
                        m = json.load(f)
                except Exception:
                    m = {}
                entry = m.get(name)
                if not entry or not entry.get('thumb'):
                    self.send_response(404); self.end_headers(); self.wfile.write(b'No thumb'); return True
                thumb_file = os.path.basename(str(entry['thumb']))
                if not _re.match(r'^[a-z0-9\-]+\.jpg$', thumb_file, _re.I):
                    self.send_response(400); self.end_headers(); self.wfile.write(b'bad thumb'); return True
                thumb_path = os.path.join(DIR, 'pipelines', 'thumbs', thumb_file)
                if not os.path.exists(thumb_path):
                    self.send_response(404); self.end_headers(); self.wfile.write(b'thumb missing'); return True
                with open(thumb_path, 'rb') as f:
                    data = f.read()
                self.send_response(200)
                self.send_header('Content-Type', 'image/jpeg')
                self.send_header('Cache-Control', 'public, max-age=86400')
                self.send_header('Content-Length', str(len(data)))
                self.end_headers(); self.wfile.write(data)
            except Exception as e:
                self._json(500, {'ok': False, 'error': str(e)})
            return True

        # 3) video stream with HTTP Range
        if path_only == '/api/video':
            self._serve_library_video()
            return True

        # 4) which publish channels have keys (proxy 5566; degrade to all-false)
        if path_only == '/api/channels-ready':
            try:
                status, j = self._studio_request('GET', '/api/channels-ready')
                self._json(status or 200, j if j is not None else {'ok': False, 'error': 'empty reply'})
            except Exception:
                self._json(200, {'ok': True, 'ready': {'youtube': False, 'instagram': False, 'tiktok': False}})
            return True

        # 5) live publish progress (proxy 5566)
        if path_only == '/api/publish-progress':
            try:
                import urllib.parse as _up
                qs = _up.parse_qs(self.path.split('?', 1)[1] if '?' in self.path else '')
                job = (qs.get('job') or [''])[0]
                if not job:
                    self._json(400, {'ok': False, 'error': 'job is required'}); return True
                status, j = self._studio_request('GET', '/api/publish-progress?job=' + _up.quote(job))
                self._json(status or 200, j if j is not None else {'ok': False, 'error': 'empty reply'})
            except Exception:
                self._json(200, {'ok': False, 'error': 'Post Studio (5566) не запущений.'})
            return True

        # 6) generated cover / uploaded image bytes (proxy stream from 5566)
        if path_only.startswith('/uploads/'):
            self._proxy_studio_upload(path_only)
            return True

        return False

    def _serve_library_video(self):
        try:
            import urllib.parse as _up
            qs = _up.parse_qs(self.path.split('?', 1)[1] if '?' in self.path else '')
            name = os.path.basename((qs.get('name') or [''])[0].replace('\\', '/'))
            lib = self._read_library()
            allowed = self._library_file_set(lib)
            if not name or name not in allowed:
                self.send_response(404); self.end_headers(); self.wfile.write('Video not in library'.encode()); return
            file_path = self._resolve_library_file(lib.get('source_folder') or '', name)
            if not file_path or not os.path.isfile(file_path):
                self.send_response(404); self.end_headers(); self.wfile.write('File missing on disk'.encode()); return
            total = os.path.getsize(file_path)
            ext = os.path.splitext(name)[1].lower()
            mime = {'.mp4': 'video/mp4', '.mov': 'video/quicktime', '.webm': 'video/webm',
                    '.m4v': 'video/x-m4v', '.mkv': 'video/x-matroska'}.get(ext, 'application/octet-stream')
            rng = self.headers.get('Range')
            if rng:
                import re as _re
                m = _re.search(r'bytes=(\d*)-(\d*)', rng)
                start = int(m.group(1)) if m and m.group(1) else 0
                end = int(m.group(2)) if m and m.group(2) else total - 1
                if start < 0:
                    start = 0
                if end >= total:
                    end = total - 1
                if start > end or start >= total:
                    self.send_response(416)
                    self.send_header('Content-Range', 'bytes */%d' % total)
                    self.end_headers(); return
                length = end - start + 1
                self.send_response(206)
                self.send_header('Content-Type', mime)
                self.send_header('Accept-Ranges', 'bytes')
                self.send_header('Content-Range', 'bytes %d-%d/%d' % (start, end, total))
                self.send_header('Content-Length', str(length))
                self.end_headers()
                with open(file_path, 'rb') as f:
                    f.seek(start)
                    remaining = length
                    while remaining > 0:
                        chunk = f.read(min(65536, remaining))
                        if not chunk:
                            break
                        self.wfile.write(chunk)
                        remaining -= len(chunk)
            else:
                self.send_response(200)
                self.send_header('Content-Type', mime)
                self.send_header('Accept-Ranges', 'bytes')
                self.send_header('Content-Length', str(total))
                self.end_headers()
                with open(file_path, 'rb') as f:
                    while True:
                        chunk = f.read(65536)
                        if not chunk:
                            break
                        self.wfile.write(chunk)
        except (BrokenPipeError, ConnectionResetError):
            pass
        except Exception as e:
            try:
                self._json(500, {'ok': False, 'error': str(e)})
            except Exception:
                pass

    def _proxy_studio_upload(self, path_only):
        import urllib.request, urllib.error, urllib.parse as _up
        raw = path_only[len('/uploads/'):]
        name = os.path.basename(_up.unquote(raw).replace('\\', '/'))
        if not name:
            self.send_response(404); self.end_headers(); self.wfile.write(b'No file'); return
        host = os.environ.get('POST_STUDIO_HOST', '127.0.0.1')
        port = os.environ.get('POST_STUDIO_PORT', '5566')
        url = 'http://%s:%s/uploads/%s' % (host, port, _up.quote(name))
        try:
            with urllib.request.urlopen(url, timeout=15) as up:
                ct = up.headers.get('Content-Type', 'application/octet-stream')
                data = up.read()
                self.send_response(up.status)
                self.send_header('Content-Type', ct)
                self.send_header('Cache-Control', 'no-cache, no-store, must-revalidate')
                self.send_header('Content-Length', str(len(data)))
                self.end_headers(); self.wfile.write(data)
        except urllib.error.HTTPError as e:
            self.send_response(e.code); self.end_headers()
            try:
                self.wfile.write(e.read())
            except Exception:
                pass
        except Exception:
            self.send_response(502)
            self.send_header('Content-Type', 'text/plain; charset=utf-8')
            self.end_headers()
            self.wfile.write('Контент-фабрика (5566) недоступна'.encode())

    def _handle_library_post(self):
        """Video Library POST routes. Returns True if it handled the request."""
        # soft-delete a single video -> move into <source_folder>/_Кошик
        if self.path == '/api/library-delete':
            try:
                body = self._read_body()
                name = os.path.basename(str(body.get('name') or '').replace('\\', '/'))
                if not name:
                    self._json(400, {'ok': False, 'error': 'name is required'}); return True
                lib_path = os.path.join(DIR, 'pipelines', 'library.json')
                lib = self._read_library()
                source_folder = lib.get('source_folder') or ''
                if not source_folder:
                    self._json(500, {'ok': False, 'error': 'no source_folder in library.json'}); return True
                cats = lib.get('categories') or {}
                if not any(name in (c.get('files') or []) for c in cats.values()):
                    self._json(404, {'ok': False, 'error': 'video not in library'}); return True
                src_path = self._resolve_library_file(source_folder, name)
                if not src_path or not os.path.exists(src_path):
                    self._json(404, {'ok': False, 'error': 'file missing on disk'}); return True
                trash_dir = os.path.join(source_folder, '_Кошик')
                os.makedirs(trash_dir, exist_ok=True)
                dest_name = name
                dest_path = os.path.join(trash_dir, dest_name)
                if os.path.exists(dest_path):
                    import time as _t
                    stem, ext = os.path.splitext(name)
                    dest_name = '%s_%d%s' % (stem, int(_t.time() * 1000), ext)
                    dest_path = os.path.join(trash_dir, dest_name)
                try:
                    os.replace(src_path, dest_path)
                except OSError:
                    import shutil as _sh
                    _sh.copy2(src_path, dest_path); os.remove(src_path)
                for cid in list(cats.keys()):
                    cat = cats[cid]
                    files = cat.get('files') or []
                    if name in files:
                        cat['files'] = [f for f in files if f != name]
                        cat['count'] = len(cat['files'])
                    if not cat.get('files'):
                        del cats[cid]
                if isinstance(lib.get('total'), int) and lib['total'] > 0:
                    lib['total'] = lib['total'] - 1
                with open(lib_path, 'w', encoding='utf-8') as f:
                    json.dump(lib, f, ensure_ascii=False, indent=2)
                self._json(200, {'ok': True, 'moved_to': '_Кошик/' + dest_name, 'total': lib.get('total')})
            except Exception as e:
                self._json(500, {'ok': False, 'error': str(e)})
            return True

        # create a new reels-pipeline run for one chosen video
        if self.path == '/api/pipeline-create':
            try:
                body = self._read_body()
                file = str(body.get('file') or '')
                category = str(body.get('category') or '')
                route = str(body.get('route') or 'cut')
                label = str(body.get('label') or '')
                if not file:
                    raise ValueError('file is required')
                lib = self._read_library()
                source_folder = lib.get('source_folder') or ''
                video_path = os.path.join(source_folder, file) if source_folder else file
                translit = {
                    'а':'a','б':'b','в':'v','г':'h','ґ':'g','д':'d','е':'e','є':'ye','ж':'zh','з':'z',
                    'и':'y','і':'i','ї':'yi','й':'y','к':'k','л':'l','м':'m','н':'n','о':'o','п':'p',
                    'р':'r','с':'s','т':'t','у':'u','ф':'f','х':'kh','ц':'ts','ч':'ch','ш':'sh',
                    'щ':'shch','ь':'','ю':'yu','я':'ya',"'":'','ʼ':''}
                import re as _re, time as _t
                base = _re.sub(r'\.[^.]+$', '', file)
                slug = ''.join(translit.get(ch, ch) for ch in base.lower())
                slug = _re.sub(r'[^a-z0-9]+', '-', slug).strip('-')[:40] or 'video'
                run_id = slug + '-' + format(int(_t.time() * 1000), 'x')
                if route == 'brand':
                    stages = [
                        {'id': 'branding', 'label': 'Брендинг (лого+слоган)', 'type': 'auto', 'status': 'pending', 'current': True, 'stub': True},
                        {'id': 'subtitles', 'label': 'Субтитри', 'type': 'auto', 'status': 'pending', 'stub': True},
                        {'id': 'finalize', 'label': 'Фінал', 'type': 'gate', 'status': 'pending'}]
                elif route in ('review', 'asset'):
                    stages = [
                        {'id': 'review', 'label': 'Перегляд', 'type': 'gate', 'status': 'needs-review', 'current': True, 'stub': True},
                        {'id': 'branding', 'label': 'Брендинг (за потреби)', 'type': 'auto', 'status': 'pending', 'stub': True},
                        {'id': 'finalize', 'label': 'Фінал', 'type': 'gate', 'status': 'pending'}]
                else:
                    stages = [
                        {'id': 'transcribe', 'label': 'Транскрипт', 'type': 'auto', 'status': 'pending', 'current': True},
                        {'id': 'select', 'label': 'Вибір кліпів', 'type': 'gate', 'status': 'pending'},
                        {'id': 'refine', 'label': 'Межі + хук', 'type': 'auto', 'status': 'pending'},
                        {'id': 'build', 'label': 'CapCut-драфти', 'type': 'auto', 'status': 'pending'},
                        {'id': 'finalize', 'label': 'Фінал', 'type': 'gate', 'status': 'pending'}]
                import datetime as _dt
                new_state = {
                    'run_id': run_id, 'source': 'library', 'video_path': video_path,
                    'video_file': file, 'category': category, 'route': route,
                    'target_count': 'auto', 'language': 'uk', 'video_title': label or base,
                    'video_hook': '', 'export_approved': False,
                    'autopost': {'enabled': False, 'handled_externally': True},
                    'transcript': [],
                    'created_at': _dt.datetime.utcnow().strftime('%Y-%m-%dT%H:%M:%S.000Z'),
                    'stages': stages, 'items': [], 'killed': []}
                run_dir = os.path.join(DIR, 'pipelines', run_id)
                os.makedirs(run_dir, exist_ok=True)
                with open(os.path.join(run_dir, 'state.json'), 'w', encoding='utf-8') as f:
                    json.dump(new_state, f, ensure_ascii=False, indent=2)
                    f.write('\n')
                self._json(200, {'ok': True, 'run': run_id, 'route': route,
                                 'url': '/pipeline.html?run=' + run_id})
            except Exception as e:
                self._json(500, {'ok': False, 'error': str(e)})
            return True

        # publish one library video to platforms -> proxy Post Studio (5566)
        if self.path == '/api/publish-video':
            try:
                body = self._read_body()
                file = os.path.basename(str(body.get('file') or '').replace('\\', '/'))
                caption = str(body.get('caption') or '')
                platforms = body.get('platforms') if isinstance(body.get('platforms'), list) else []
                seen = set(); norm = []
                for p in platforms:
                    p = str(p or '').lower()
                    if p and p not in seen:
                        seen.add(p); norm.append(p)
                if not file:
                    self._json(400, {'ok': False, 'error': 'file is required'}); return True
                if not norm:
                    self._json(400, {'ok': False, 'error': 'no platforms selected'}); return True
                lib = self._read_library()
                if file not in self._library_file_set(lib):
                    self._json(404, {'ok': False, 'error': 'video not in library'}); return True
                payload = {'file': file, 'platforms': norm, 'caption': caption}
                if body.get('thumbnail'):
                    payload['thumbnail'] = body['thumbnail']
                if body.get('dryRun'):
                    payload['dryRun'] = True
                try:
                    status, j = self._studio_request('POST', '/api/publish-video', payload, timeout=60)
                except Exception:
                    self._json(200, {'ok': False,
                                     'error': 'Post Studio (5566) не запущений. Запусти його: tools/viz/post-studio/start.sh'})
                    return True
                self._json(status or 200, j if j is not None else {'ok': False, 'error': 'empty reply'})
            except Exception as e:
                self._json(500, {'ok': False, 'error': str(e)})
            return True

        # generate a branded cover for one video -> proxy Post Studio (5566)
        if self.path == '/api/generate-cover':
            try:
                body = self._read_body()
                payload = {
                    'file': str(body.get('file') or ''),
                    'hook': str(body.get('hook') or ''),
                    'title': str(body.get('title') or ''),
                    'highlight': str(body.get('highlight') or ''),
                    'icon': str(body.get('icon') or '')}
                for k in ('kind', 'mode', 'id'):
                    if body.get(k):
                        payload[k] = str(body[k])
                if body.get('frameIndex') is not None:
                    try:
                        payload['frameIndex'] = int(body['frameIndex'])
                    except Exception:
                        payload['frameIndex'] = 0
                try:
                    status, j = self._studio_request('POST', '/api/generate-cover', payload, timeout=120)
                except Exception:
                    self._json(200, {'ok': False, 'error': 'Контент-фабрика вимкнена'}); return True
                self._json(status or 200, j if j is not None else {'ok': False, 'error': 'empty reply'})
            except Exception as e:
                self._json(500, {'ok': False, 'error': str(e)})
            return True

        return False

    def _channel_index(self, channel):
        if '/' in channel or '..' in channel:
            raise ValueError('bad channel')
        ch_dir = os.path.join(DIR, 'channels', channel)
        idx_path = os.path.join(ch_dir, 'index.json')
        items = json.load(open(idx_path)) if os.path.exists(idx_path) else []
        return ch_dir, idx_path, items

    @staticmethod
    def _snippet_label(raw, max_len=36):
        """Trim free text into a concise tab label. Mirrors render-message.cjs
        snippetLabel(): strip HTML, collapse whitespace, cut to ~max_len at a
        word boundary, append '…' if truncated. Returns '' if empty."""
        import re as _re
        s = '' if raw is None else str(raw)
        s = _re.sub(r'<[^>]*>', ' ', s)   # strip HTML tags
        s = _re.sub(r'\s+', ' ', s).strip()  # collapse whitespace
        if not s:
            return ''
        if len(s) <= max_len:
            return s
        cut = s[:max_len]
        sp = cut.rfind(' ')
        if sp > 12:                       # prefer a word boundary if not too early
            cut = cut[:sp]
        return cut.rstrip() + '…'

    @classmethod
    def _is_default_label(cls, label, channel):
        """A channel label is auto/default (safe to overwrite) when it is empty,
        the literal 'Новий чат', equals the channel id, or matches the
        'Code HH:MM' time-fallback. A custom (user-set) label is never matched."""
        import re as _re
        s = (label or '').strip()
        if not s:
            return True
        if s == 'Новий чат':
            return True
        if s == channel:
            return True
        if _re.match(r'^Code \d{1,2}:\d{2}$', s):
            return True
        return False

    def _maybe_autoname_channel(self, channel, text):
        """Auto-name a freshly-created chat from its first user message.

        Called from /api/send AFTER the first user bubble is appended. Only acts
        when (a) this is the channel's first message (the just-written bubble is
        the only NNNN.json) AND (b) the current registry label is still a
        default/auto one. Writes the snippet via the same registry path
        /api/channel-rename uses (_registry_for_channel + _atomic_write_json),
        so it persists in index.json OR the cc-* overlay index.local.json. Never
        overwrites a custom label; never fires on the 2nd+ message. Graceful: any
        error is swallowed so a naming hiccup never breaks the send."""
        try:
            import glob
            import re as _re
            ch_dir = os.path.join(DIR, 'channels', channel)
            # "first message" = exactly one NNNN.json bubble file exists (the one
            # we just wrote). 2nd+ messages have 2+ and are skipped.
            msg_files = [f for f in glob.glob(os.path.join(ch_dir, '[0-9]*.json'))
                         if _re.match(r'\d+\.json$', os.path.basename(f))]
            if len(msg_files) != 1:
                return None
            snippet = self._snippet_label(text)
            if not snippet:
                return None
            reg_path, reg = self._registry_for_channel(channel)
            if reg_path is None:
                return None
            cur = next((c for c in reg
                        if isinstance(c, dict) and c.get('id') == channel), None)
            if cur is None:
                return None
            if not self._is_default_label(cur.get('label'), channel):
                return None   # custom label -> leave it alone
            cur['label'] = snippet
            cur['autoNamed'] = True   # provisional -> _maybe_llm_rename may upgrade it
            _atomic_write_json(reg_path, reg)
            return snippet
        except Exception:
            return None

    # How many user+assistant bubbles must accumulate before we ask an LLM for a
    # proper title. The 1st-message snippet is a provisional placeholder; by the
    # Nth bubble the topic is clear enough to name well.
    AUTONAME_AT = 5

    # Bubbles to wait before RETRYING a title that never landed. The old code
    # fired only when the count was exactly AUTONAME_AT, so one bad moment (a
    # dead naming key, or a 5th bubble that happened to be the assistant's)
    # stranded a tab on its 1st-message snippet forever. Now a failed attempt is
    # simply retried every AUTONAME_EVERY bubbles until it succeeds.
    AUTONAME_EVERY = 6

    # Naming engines, tried in order, mirroring the grok → openai degrade chain
    # /api/voice already uses. Each is scripts/<name>.sh taking
    # (user_prompt, system_prompt) on argv and printing the answer on stdout.
    # grok.sh goes first: the OpenAI key has run dry before and, as the only
    # engine, silently killed every rename (it exits 1 with an empty stdout).
    _NAMER_ENGINES = (('grok.sh', 'grok-4.5'), ('openai.sh', 'gpt-5-mini'))

    def _scripts_root(self):
        """Directory holding scripts/*.sh. Normally <repo>/tools/viz/chat/../../..,
        but a packaged desktop build points DIR at a CHATVIEW_HOME payload with no
        scripts/ — fall back to this file's real location so the namer is found."""
        here = os.path.dirname(os.path.abspath(__file__))
        cands = [os.path.normpath(os.path.join(DIR, '..', '..', '..')),
                 os.path.normpath(os.path.join(here, '..', '..', '..'))]
        for c in cands:
            if os.path.isdir(os.path.join(c, 'scripts')):
                return c
        return cands[0]

    @staticmethod
    def _clean_llm_name(raw):
        """Raw engine stdout -> usable tab title, or '' when unusable.

        Guards a failing engine from BECOMING the tab label: empty output, an
        error line ('ERROR: You exceeded your current quota…' is exactly how
        openai.sh degrades) or a traceback all return ''."""
        name = next((ln.strip() for ln in (raw or '').splitlines() if ln.strip()), '')
        name = name.strip().strip('"').strip("'").strip()
        name = ' '.join(name.split())[:40].strip()
        if not name:
            return ''
        low = name.lower()
        if low.startswith(('error', 'traceback', 'usage:', '❌')):
            return ''
        for bad in ('quota', 'rate limit', 'api key', 'unauthorized', 'exceeded'):
            if bad in low:
                return ''
        return name

    def _llm_name_from_convo(self, convo):
        """First clean 3-5 word Ukrainian title from the engine chain ('' if all down)."""
        import subprocess
        sys_prompt = (
            'Ти називаєш чати. Дай коротку назву 3-5 слів '
            'українською, яка передає суть розмови. Виведи ЛИШЕ '
            'назву, без лапок, без пояснень, без emoji, максимум '
            '40 символів.')
        root = self._scripts_root()
        for script, model in self._NAMER_ENGINES:
            namer = os.path.join(root, 'scripts', script)
            if not os.path.exists(namer):
                continue
            try:
                out = subprocess.run(
                    ['bash', namer, convo, sys_prompt],
                    capture_output=True, text=True, timeout=25,
                    env=dict(os.environ, MODEL=model))
            except Exception:
                continue          # timeout / bash missing -> next engine
            if out.returncode != 0:
                continue          # engine failed (dead key, network) -> next
            name = self._clean_llm_name(out.stdout)
            if name:
                return name
        return ''

    # Keyword -> emoji map mirrored from render-message.cjs ICON_RULES (keep the
    # two in sync). First match wins; returns None when nothing matches so the
    # caller can keep the default '🆕'.
    _ICON_RULES = [
        (r'гро[шж]|оплат|комунал|payment|підписк|білінг|invoice|рахунок', '💰'),
        (r'баг|fix|фікс|помилк|bug|debug|зламал|crash|exception', '🛠'),
        (r'код|code|деплой|deploy|рефактор|refactor|api\b|docker|сервер|backend', '💻'),
        (r'дизайн|design|\bui\b|\bux\b|макет|figma|mockup|wireframe', '🎨'),
        (r'відео|reels|рілс|кліп|video|youtube|монтаж', '🎬'),
        (r'маркетинг|реклам|\bads?\b|кампан|campaign|воронк|funnel', '📣'),
        (r'аналітик|метрик|\bsql\b|дашборд|analytics|metric|dashboard|конверс', '📊'),
        (r'іде[яї]|брейншторм|brainstorm|гіпотез', '💡'),
        (r'чат[- ]?в|chatview|chat[- ]?view|інтерфейс|widget|віджет', '🪟'),
        (r'контент|пост\b|статт|copy|копірайт|article', '✍️'),
        (r'дослід|research|конкурент|competitor|ресерч', '🔬'),
        (r'план|roadmap|стратег|strategy|спрінт|sprint', '🗺️'),
        (r'лист\b|email|розсилк|drip|newsletter|імейл', '📨'),
    ]

    def _derive_icon_from_text(self, text):
        """Pick a topical emoji from free text via _ICON_RULES. None if no match."""
        import re as _re
        s = (text or '').strip()
        if not s:
            return None
        for pat, emoji in self._ICON_RULES:
            if _re.search(pat, s, _re.IGNORECASE):
                return emoji
        return None

    def _maybe_llm_rename_channel(self, channel):
        """Upgrade a still-auto label (and default 🆕 icon) once the topic is clear.

        Fires from /api/send. Acts only when (a) the channel has at least
        AUTONAME_AT bubbles and no attempt ran in the last AUTONAME_EVERY of them
        AND (b) the current registry label is still overwritable (a default/auto
        one OR carries autoNamed:true from the 1st-message snippet). A manual
        rename clears autoNamed (see /api/channel-rename), so user-set titles are
        never touched, and a landed LLM title sets llmNamed so we stop retrying.

        The icon is derived here SYNCHRONOUSLY from plain regex
        (_derive_icon_from_text) rather than inside the LLM thread: it needs no
        network, and hanging it off the LLM meant a dead naming key also left the
        tab on the default 🆕 forever. The LLM title itself runs in a daemon
        thread so /api/send never blocks; if every engine is down the provisional
        snippet simply stays and the next milestone tries again."""
        try:
            import glob
            import re as _re
            ch_dir = os.path.join(DIR, 'channels', channel)
            msg_files = sorted(
                f for f in glob.glob(os.path.join(ch_dir, '[0-9]*.json'))
                if _re.match(r'\d+\.json$', os.path.basename(f)))
            count = len(msg_files)
            if count < self.AUTONAME_AT:
                return None
            reg_path, reg = self._registry_for_channel(channel)
            if reg_path is None:
                return None
            cur = next((c for c in reg
                        if isinstance(c, dict) and c.get('id') == channel), None)
            if cur is None:
                return None
            if cur.get('llmNamed'):
                return None   # already properly titled -> done
            # Overwritable = default/auto label OR provisional autoNamed snippet.
            if not (self._is_default_label(cur.get('label'), channel)
                    or cur.get('autoNamed')):
                return None   # manual title -> never touch
            # Throttle: at most one naming call per AUTONAME_EVERY bubbles. Stamped
            # BEFORE the thread starts so two quick sends cannot double-fire.
            tried = cur.get('llmNameTriedAt')
            if isinstance(tried, int) and count < tried + self.AUTONAME_EVERY:
                return None

            # Collect the FIRST AUTONAME_AT bubbles as plain text for the prompt.
            # First ones, not latest, even on a long channel we are rescuing: the
            # topic is set at the start and this keeps the prompt small.
            parts = []
            for f in msg_files[:self.AUTONAME_AT]:
                try:
                    blocks = json.load(open(f, encoding='utf-8'))
                except Exception:
                    continue
                if not isinstance(blocks, list):
                    continue
                txt = ' '.join(b.get('text', '') for b in blocks
                               if isinstance(b, dict) and b.get('text'))
                txt = txt.strip()
                if txt:
                    parts.append(txt[:300])
            if not parts:
                return None
            convo = '\n'.join(parts)

            # Stamp the attempt + upgrade the icon in ONE synchronous write. The
            # icon is regex-only, so it lands even when every naming engine is down.
            cur['llmNameTriedAt'] = count
            if (cur.get('icon') or '🆕') == '🆕':
                _ic0 = self._derive_icon_from_text(convo)
                if _ic0:
                    cur['icon'] = _ic0
            _atomic_write_json(reg_path, reg)

            def _worker():
                try:
                    name = self._llm_name_from_convo(convo)
                    if not name:
                        return    # every engine down -> snippet stays, retry later
                    # Re-read the registry inside the thread (it may have changed)
                    # and re-check the overwritable guard before writing.
                    rp, rg = self._registry_for_channel(channel)
                    if rp is None:
                        return
                    c2 = next((c for c in rg if isinstance(c, dict)
                               and c.get('id') == channel), None)
                    if c2 is None:
                        return
                    if not (self._is_default_label(c2.get('label'), channel)
                            or c2.get('autoNamed')):
                        return
                    c2['label'] = name
                    c2['autoNamed'] = True
                    c2['llmNamed'] = True   # landed -> stop retrying
                    # Upgrade a still-default 🆕 icon to a topical one derived
                    # from the generated name + first messages. Never overwrite a
                    # custom icon the user/card already picked.
                    if (c2.get('icon') or '🆕') == '🆕':
                        _ic = self._derive_icon_from_text(name + ' ' + convo)
                        if _ic:
                            c2['icon'] = _ic
                    _atomic_write_json(rp, rg)
                except Exception:
                    return

            import threading
            threading.Thread(target=_worker, daemon=True).start()
            return True
        except Exception:
            return None

    def _registry_for_channel(self, cid):
        """Find which channel registry file actually holds `cid`.

        Tabs live in EITHER channels/index.json (committed, curated tabs) OR
        channels/index.local.json (gitignored, auto cc-* session overlay). The
        UI shows the MERGED list, so a hide/rename that only writes index.json
        misses cc-* channels and the next poll reverts it. We probe the committed
        file first (curated wins on id collision, matching _merged_registry), then
        the local overlay. Returns (path, parsed_list) for the owning file, or
        (None, []) if `cid` is in neither (caller then no-ops without crashing)."""
        ch_root = os.path.join(DIR, 'channels')
        for name in ('index.json', 'index.local.json'):
            fpath = os.path.join(ch_root, name)
            if not os.path.exists(fpath):
                continue
            try:
                with open(fpath, encoding='utf-8') as f:
                    reg = json.load(f)
            except Exception:
                continue
            if not isinstance(reg, list):
                continue
            if any(isinstance(c, dict) and c.get('id') == cid for c in reg):
                return fpath, reg
        return None, []

    # ---- Two-way chat helpers (shared by /api/send and runner.py) ----
    def _append_message(self, channel, widgets, frm='Claude', tag=None):
        """Append a message bubble to a channel. Mirrors render-message.sh so the
        front end renders it identically. Returns the new message id."""
        import glob
        import re as _re
        from datetime import datetime
        import fcntl
        ch_dir, idx_path, items = self._channel_index(channel)
        os.makedirs(ch_dir, exist_ok=True)
        # HARD lock: prevent concurrent appends from using the same message id.
        # Race condition: two POST /api/send to the same channel calculate
        # max_id identically and both write to the same NNNN.json. File lock
        # ensures only one thread recalculates and writes per channel.
        lock_file = os.path.join(ch_dir, '.append.lock')
        with open(lock_file, 'w') as lf:
            fcntl.flock(lf.fileno(), fcntl.LOCK_EX)
            try:
                # Re-read after acquiring lock so we see any just-written files
                items = []
                try:
                    with open(idx_path, encoding='utf-8') as f:
                        items = json.load(f) or []
                except Exception:
                    items = []
                if not isinstance(items, list):
                    items = []
                ids = [i.get('id', 0) for i in items]
                for f in glob.glob(os.path.join(ch_dir, '[0-9]*.json')):
                    m = _re.match(r'(\d+)', os.path.basename(f))
                    if m:
                        ids.append(int(m.group(1)))
                nxt = (max(ids) + 1) if ids else 1
                fname = f'{nxt:04d}.json'
                _atomic_write_json(os.path.join(ch_dir, fname), widgets)
                items = [i for i in items if i.get('file') != fname]
                items.append({
                    'id': nxt, 'file': fname,
                    'timestamp': datetime.now().strftime('%H:%M:%S'),
                    'iso': datetime.now().astimezone().isoformat(),
                    'from': frm, 'tag': tag or None,
                })
                items.sort(key=lambda i: i['id'])
                _atomic_write_json(idx_path, items)
                return nxt
            finally:
                fcntl.flock(lf.fileno(), fcntl.LOCK_UN)

    def _mark_messages_stopped(self, channel, msg_ids):
        """Flag user bubbles whose turn never ran to completion.

        A prompt can die two ways: Vova hits Стоп mid-turn (/api/stop), or he
        drops a still-waiting item from the queue (/api/queue/cancel). Either
        way the bubble stays in the log while its answer never arrives, and
        until now nothing on screen said so — the queue dot simply vanished and
        the message looked delivered.

        We do NOT post a "Зупинено" bubble from Claude for this (Vova
        2026-07-29: a whole assistant message shouting STOPPED is noise). The
        fact belongs ON the user's own bubble, so we persist it as a flag in
        index.json and let the UI draw one small mark.

        Takes the same .append.lock as _append_message: index.json has exactly
        one writer at a time. Best-effort — a failure here must never break the
        stop itself, which is the whole point of the button."""
        import fcntl
        ids = {int(i) for i in msg_ids if i is not None}
        if not ids:
            return 0
        ch_dir = os.path.join(DIR, 'channels', channel)
        idx_path = os.path.join(ch_dir, 'index.json')
        if not os.path.exists(idx_path):
            return 0
        marked = 0
        lock_file = os.path.join(ch_dir, '.append.lock')
        with open(lock_file, 'w') as lf:
            fcntl.flock(lf.fileno(), fcntl.LOCK_EX)
            try:
                with open(idx_path, encoding='utf-8') as f:
                    items = json.load(f) or []
                if not isinstance(items, list):
                    return 0
                for it in items:
                    if isinstance(it, dict) and it.get('id') in ids and not it.get('stopped'):
                        it['stopped'] = True
                        marked += 1
                if marked:
                    _atomic_write_json(idx_path, items)
            finally:
                fcntl.flock(lf.fileno(), fcntl.LOCK_UN)
        return marked

    def _channel_session_id(self, channel, create=False):
        """Read (or create) the claude session UUID bound to a channel.
        Stored at channels/<id>/session-id (one line)."""
        import uuid
        if '/' in channel or '..' in channel:
            raise ValueError('bad channel')
        ch_dir = os.path.join(DIR, 'channels', channel)
        sid_path = os.path.join(ch_dir, 'session-id')
        if os.path.exists(sid_path):
            sid = open(sid_path).read().strip()
            if sid:
                return sid
        if create:
            os.makedirs(ch_dir, exist_ok=True)
            sid = str(uuid.uuid4())
            with open(sid_path, 'w') as f:
                f.write(sid + '\n')
            return sid
        return None

    # ---- Canvas PUT routes (Phase 1 merge) -------------------------------
    def do_PUT(self):
        self._strip_proxy_prefix()
        import re as _re
        path_only = self.path.split('?')[0]
        if path_only == '/api/canvas':
            # Full-snapshot replace (Phase 1). The canvas UI's normal save sends a
            # complete {store, schema}. We do NOT implement the per-record merge /
            # tombstone reconciliation from server/index.ts (CAVEAT, see report):
            # baseVersion is ignored, incoming store fully replaces the in-memory
            # store. Adequate for single-tab use; concurrent agent inserts during
            # an open tab could be overwritten (same risk the merge path mitigated).
            try:
                body = self._read_body()
                incoming_store = body.get('store')
                if not isinstance(incoming_store, dict):
                    self._json_cors(400, {'error': 'body.store required'}); return
                # Tombstone guard: strip any record a stale tab tries to resurrect
                # (deleted pages + their orphaned shapes) BEFORE it replaces the
                # store. This is what makes deletion stick against old open tabs.
                incoming_store = _apply_tombstones(incoming_store)
                # Wipe guard (HARD): never let a client that loaded empty replace a
                # store that HAS shapes with one that has ZERO shapes. This is the
                # recurring data-loss bug — a canvas that mounts empty (server just
                # (re)started with stale in-memory state, iframe warm-mount race)
                # then autosaves its empty editor and clobbers every widget on disk.
                def _n_shapes(s):
                    return sum(1 for r in s.values()
                               if isinstance(r, dict) and r.get('typeName') == 'shape')
                # Same rule as GET /api/canvas: the refusal echoes the whole store
                # back, so it is serialized here and written to the socket after the
                # lock is released (see _send_json_raw).
                refused = None
                with _canvas_lock:
                    if _n_shapes(incoming_store) == 0 and _n_shapes(_canvas['store']) > 0:
                        print('[canvas] REFUSED empty-store overwrite (wipe guard): '
                              f"incoming 0 shapes vs server {_n_shapes(_canvas['store'])}")
                        refused = json.dumps({
                            'ok': True, 'version': _canvas['version'], 'merged': True,
                            'store': _canvas['store'], 'schema': _canvas['schema'],
                            'refusedEmpty': True,
                        }, ensure_ascii=False).encode()
                    else:
                        _canvas['store'] = dict(incoming_store)
                        if 'schema' in body:
                            _canvas['schema'] = body.get('schema')
                        _canvas['version'] += 1
                        _canvas_persist()
                        ver = _canvas['version']
                if refused is not None:
                    self._send_json_raw(200, refused)
                    return
                self._json_cors(200, {'ok': True, 'version': ver, 'merged': False})
            except Exception as e:
                self._json_cors(500, {'error': str(e)})
            return
        if path_only == '/api/canvas/bookmarks':
            try:
                body = self._read_body()
                os.makedirs(CANVAS_DATA_DIR, exist_ok=True)
                with open(BOOKMARKS_FILE, 'w', encoding='utf-8') as f:
                    json.dump(body, f, ensure_ascii=False, indent=2)
                self._json_cors(200, {'ok': True})
            except Exception as e:
                self._json_cors(500, {'error': str(e)})
            return
        m = _re.match(r'^/api/data/([^/]+)$', path_only)
        if m:
            filename = _re.sub(r'[^a-zA-Z0-9_-]', '', m.group(1))
            fpath = os.path.join(CANVAS_DATA_DIR, f'{filename}.json')
            if not os.path.exists(fpath):
                self._json_cors(404, {'error': f'File not found: {filename}.json'}); return
            try:
                body = self._read_body()
                with open(fpath, 'w', encoding='utf-8') as f:
                    json.dump(body, f, ensure_ascii=False, indent=2)
                self._json_cors(200, {'ok': True})
            except Exception as e:
                self._json_cors(500, {'error': str(e)})
            return
        if path_only == '/api/file-content':
            import urllib.parse as _up
            qs = _up.parse_qs(self.path.split('?', 1)[1] if '?' in self.path else '')
            raw_path = (qs.get('path') or [''])[0]
            if not raw_path:
                self._json_cors(400, {'error': 'path required'}); return
            try:
                body = self._read_body()
            except Exception as e:
                self._json_cors(400, {'error': str(e)}); return
            content = body.get('content')
            if not isinstance(content, str):
                self._json_cors(400, {'error': 'body.content (string) required'}); return
            full = _safe_repo_path(raw_path)
            if full is None:
                self._json_cors(403, {'error': 'Access denied. Only projects/, processes/, decisions/, data/ allowed.'})
                return
            if not os.path.exists(full):
                self._json_cors(404, {'error': f'File not found: {raw_path}'}); return
            try:
                with open(full, 'w', encoding='utf-8') as f:
                    f.write(content)
                self._json_cors(200, {'ok': True})
            except Exception as e:
                self._json_cors(500, {'error': str(e)})
            return
        self.send_response(404)
        self.end_headers()

    def _canvas_normalize_shape(self, s):
        """Port of the props normalization in server/index.ts add-shapes:
        widget->html-widget alias, html-widget/geo/arrow default props,
        richText synthesis from a plain `text` for geo shapes."""
        s = dict(s)
        if s.get('type') == 'widget':
            s['type'] = 'html-widget'
        shape_type = s.get('type') or 'html-widget'
        in_props = s.get('props') or {}
        if shape_type == 'html-widget':
            html_props = {k: v for k, v in in_props.items() if k not in ('html_content', 'html')}
            sid = s.get('id', '')
            props = {
                'dataFile': '',
                'widgetType': html_props.get('widgetType') or str(sid).replace('shape:', ''),
                'collapsed': False,
                'expandedH': html_props.get('h', 420),
            }
            props.update(html_props)
        elif shape_type == 'geo':
            rest = {k: v for k, v in in_props.items() if k != 'text'}
            rt = rest.get('richText')
            if rt is None:
                t = in_props.get('text')
                if t:
                    content = []
                    for line in str(t).split('\n'):
                        if line.strip():
                            content.append({'type': 'paragraph', 'attrs': {'dir': 'auto'},
                                            'content': [{'type': 'text', 'text': line}]})
                        else:
                            content.append({'type': 'paragraph', 'attrs': {'dir': 'auto'}})
                    rt = {'type': 'doc', 'content': content}
                else:
                    rt = {'type': 'doc', 'content': [{'type': 'paragraph', 'attrs': {'dir': 'auto'}}]}
            props = {'scale': 1, 'labelColor': 'black'}
            props.update(rest)
            props['richText'] = rt
        elif shape_type == 'arrow':
            props = {'scale': 1, 'kind': 'arc', 'elbowMidPoint': 0.5}
            props.update(in_props)
        else:
            props = in_props
        s['type'] = shape_type
        s['props'] = props
        return s

    def do_POST(self):
        self._strip_proxy_prefix()
        # Video Library POST routes (delete / pipeline-create / publish / cover).
        # Ported from server.cjs; must run before the canvas/chat dispatch so an
        # unknown-route fallthrough never returns an empty body to library.html.
        if self._handle_library_post():
            return
        if self.path == '/api/desktop/update-check':
            # Manual "check for updates": poll the release channel NOW and, if a newer
            # payload exists, download+verify+stage it (applies on the NEXT launch). The
            # on-demand twin of the launch-time background updater (entry.py _bg_update);
            # best-effort, never hot-swaps a running process. Only meaningful in the
            # desktop shell (needs a writable payload home = CHATVIEW_HOME).
            try:
                _u = _updater()
                home = os.environ.get('CHATVIEW_HOME')
                running = os.environ.get('CHATVIEW_RUNNING_VERSION') \
                    or (_u.read_version(os.path.join(home, 'payload')) if home else None) \
                    or '0.0.0'
                if not home:
                    # web/dev (no desktop shell) -> nothing to self-update
                    self._json(200, {'ok': True, 'status': 'current',
                                     'running': running, 'desktop': False}); return
                # Same flow as the launch-time and periodic checks: chatview_updater owns
                # the channel URL, the "up to date vs unreachable" distinction (a network
                # failure must never render as the green «найновіша версія») and staging.
                out = _u.check_and_stage(home, running, log=_desktop_log)
                out['ok'] = True
                self._json(200, out); return
            except Exception as e:
                self._json(500, {'ok': False, 'error': str(e)})
            return

        if self.path == '/api/desktop/relaunch':
            # "Restart to update" (Chrome/VSCode «Relaunch» pattern): spawn a FRESH app
            # instance pinned to the SAME port (browser suppressed), reply, then tear
            # THIS process down so the port frees. The fresh boot applies the staged
            # payload (choose_code_dir) and the open tab reloads in place once the new
            # server answers. Desktop shell only (needs CHATVIEW_HOME); web/dev no-ops.
            try:
                home = os.environ.get('CHATVIEW_HOME')
                if not home:
                    self._json(200, {'ok': False, 'status': 'web'}); return
                port = os.environ.get('VIZ_CHAT_PORT') or str(PORT)
                staged = None
                try:
                    import chatview_updater as _u
                    staged = _u.read_version(os.path.join(home, 'payload'))
                except Exception:
                    pass
                # Reply BEFORE relaunching so the UI gets its 200 and can start polling.
                self._json(200, {'ok': True, 'status': 'relaunching',
                                 'port': port, 'staged': staged})

                def _go():
                    try:
                        import chatview_platform as _p
                        _p.Platform.current().relaunch(port=port)
                    except Exception:
                        return  # spawn failed -> keep running, do NOT kill ourselves
                    # Give the child a beat to start waiting on the port, then hard-exit
                    # so the old server frees it (os._exit skips atexit/thread joins).
                    time.sleep(0.8)
                    os._exit(0)

                threading.Timer(0.6, _go).start()
            except Exception as e:
                self._json(500, {'ok': False, 'error': str(e)})
            return

        if self.path == '/api/desktop/install-claude':
            # Install the local Claude Code CLI FOR the user (official installer), in
            # the background. Idempotent: 'already' if present. The UI polls
            # /api/desktop/status to see claude.found flip true (or claude.installError).
            try:
                import chatview_platform as _p
                import chatview_onboarding as _ob
                self._json(200, _ob.start_install(_p.Platform.current()))
            except Exception as e:
                self._json(500, {'ok': False, 'error': str(e)})
            return

        if self.path == '/api/desktop/claude-login':
            # Sign the user in: launch `claude auth login` (opens the browser itself).
            # Idempotent ('already' if signed in), single-flight. Success is observed
            # via /api/desktop/status -> claude.authed. Optional body {"console":true}
            # switches to Anthropic Console (API billing) instead of the subscription.
            try:
                import chatview_platform as _p
                import chatview_onboarding as _ob
                try:
                    body = self._read_body() or {}
                except Exception:
                    body = {}
                res = _ob.start_login(_p.Platform.current(),
                                      console=bool(body.get('console')))
                self._json(200, res)
            except Exception as e:
                self._json(500, {'ok': False, 'error': str(e)})
            return
        # ── Gadgets: generic action executor + Operate AI router ──────────────
        if self.path == '/api/gadget-action':
            try:
                body = self._read_body()
                gid = (body.get('gadgetId') or '').strip()
                action = (body.get('action') or '').strip()
                ok, result = _gadget_apply_action(gid, action, body.get('params') or {})
                if not ok:
                    self._json(400, {'ok': False, 'error': result}); return
                self._json(200, {'ok': True, 'state': result})
            except Exception as e:
                self._json(500, {'ok': False, 'error': str(e)})
            return
        if self.path == '/api/gadget-ai':
            try:
                body = self._read_body()
                gid = (body.get('gadgetId') or '').strip()
                text = (body.get('text') or '').strip()
                if not gid or not text:
                    self._json(400, {'ok': False, 'error': 'gadgetId and text required'}); return
                chosen, reply = _gadget_pick_action(gid, text)
                if not chosen:
                    self._json(200, {'ok': True, 'state': _gadget_load_state(gid),
                                     'chosen': None, 'reply': reply}); return
                ok, result = _gadget_apply_action(gid, chosen.get('action'), chosen.get('params') or {})
                if not ok:
                    self._json(200, {'ok': True, 'state': _gadget_load_state(gid),
                                     'chosen': chosen, 'reply': result}); return
                self._json(200, {'ok': True, 'state': result, 'chosen': chosen, 'reply': reply})
            except Exception as e:
                self._json(500, {'ok': False, 'error': str(e)})
            return
        if self.path == '/api/gadget-chat':
            try:
                body = self._read_body()
                gid = (body.get('gadgetId') or '').strip()
                if not gid:
                    self._json(400, {'ok': False, 'error': 'gadgetId required'}); return
                if body.get('reset'):
                    _gadget_chat_save(gid, [])
                    self._json(200, {'ok': True, 'messages': [], 'state': _gadget_load_state(gid)}); return
                text = (body.get('text') or '').strip()
                if not text:
                    self._json(400, {'ok': False, 'error': 'text required'}); return
                res = _gadget_chat(gid, text, (body.get('model') or '').strip() or None)
                self._json(200, dict({'ok': True}, **res))
            except Exception as e:
                self._json(500, {'ok': False, 'error': str(e)})
            return
        if self.path == '/api/gadget-build':
            try:
                body = self._read_body()
                ok, result = _gadget_build(body.get('description') or '')
                if not ok:
                    self._json(400, {'ok': False, 'error': result}); return
                self._json(200, {'ok': True, 'gadget': result})
            except Exception as e:
                self._json(500, {'ok': False, 'error': str(e)})
            return
        if self.path == '/api/gadget-pin':
            try:
                body = self._read_body()
                gid = (body.get('gadgetId') or '').strip()
                ok, result = _gadget_set_pin(gid, bool(body.get('pinned')))
                if not ok:
                    self._json(400, {'ok': False, 'error': result}); return
                self._json(200, {'ok': True, 'gadgets': result})
            except Exception as e:
                self._json(500, {'ok': False, 'error': str(e)})
            return
        if self.path == '/api/gadget-delete':
            try:
                body = self._read_body()
                gid = (body.get('gadgetId') or '').strip()
                ok, result = _gadget_delete(gid)
                if not ok:
                    self._json(400, {'ok': False, 'error': result}); return
                self._json(200, {'ok': True, 'gadgets': result})
            except Exception as e:
                self._json(500, {'ok': False, 'error': str(e)})
            return
        if self.path == '/api/canvas/delete-pages':
            # Durable page deletion. Removes each page + its descendant shapes +
            # their bindings from the store, records every removed id as a
            # tombstone (so a stale tab can never resurrect them), persists, and
            # bumps version. Open tabs drop the pages live via the tombstones
            # emitted on pending-shapes. Body: {"pageIds": ["page:x", ...]}.
            try:
                body = self._read_body()
                page_ids = body.get('pageIds') or []
                if not isinstance(page_ids, list) or not page_ids:
                    self._json_cors(400, {'error': 'pageIds (non-empty array) required'}); return
                page_set = set(page_ids)
                removed_pages = removed_shapes = 0
                with _canvas_lock:
                    store = _canvas['store']
                    # descendant shapes (direct + nested via parentId chains)
                    shape_ids = set()
                    for rid, rec in store.items():
                        if isinstance(rec, dict) and rec.get('typeName') == 'shape' \
                                and rec.get('parentId') in page_set:
                            shape_ids.add(rid)
                    changed = True
                    while changed:
                        changed = False
                        for rid, rec in store.items():
                            if isinstance(rec, dict) and rec.get('typeName') == 'shape' \
                                    and rid not in shape_ids and rec.get('parentId') in shape_ids:
                                shape_ids.add(rid); changed = True
                    bind_ids = set()
                    for rid, rec in store.items():
                        if isinstance(rec, dict) and rec.get('typeName') == 'binding' \
                                and (rec.get('fromId') in shape_ids or rec.get('toId') in shape_ids):
                            bind_ids.add(rid)
                    for rid in list(page_set) + list(shape_ids) + list(bind_ids):
                        if rid in store:
                            del store[rid]
                            if rid in shape_ids:
                                removed_shapes += 1
                            elif rid in page_set:
                                removed_pages += 1
                        _canvas_tombstones.add(rid)
                    _save_tombstones()
                    _canvas['version'] += 1
                    _canvas_persist()
                    ver = _canvas['version']
                self._json_cors(200, {'ok': True, 'removedPages': removed_pages,
                                      'removedShapes': removed_shapes, 'version': ver,
                                      'tombstoneCount': len(_canvas_tombstones)})
            except Exception as e:
                self._json_cors(500, {'error': str(e)})
            return
        if self.path == '/api/canvas/add-shapes':
            # Port of POST /api/canvas/add-shapes: normalize props, queue for live
            # tldraw polling, AND insert into the authoritative in-memory store with
            # per-parent fractional indexes (generated via the node bridge).
            try:
                body = self._read_body()
                shapes = body.get('shapes')
                if not isinstance(shapes, list):
                    self._json_cors(400, {'error': 'shapes must be array'}); return
                normalized = [self._canvas_normalize_shape(s) for s in shapes]
                persist_error = None
                persisted = 0
                with _canvas_lock:
                    _pending_shapes.extend(normalized)
                    try:
                        store = _canvas['store']
                        # highest existing index per parent
                        highest = {}
                        for rec in store.values():
                            if not isinstance(rec, dict) or rec.get('typeName') != 'shape':
                                continue
                            idx = rec.get('index')
                            if not _is_valid_index_key(idx):
                                continue
                            parent = rec.get('parentId') or 'page:page'
                            cur = highest.get(parent)
                            if cur is None or idx > cur:
                                highest[parent] = idx
                        # shapes that are genuinely new (by id)
                        to_add = [s for s in shapes if not store.get(s.get('id'))]
                        new_indexes = []
                        # Generate one key per shape, threading the previous key as the
                        # new `below` so multiple inserts under the same parent stay
                        # strictly increasing (matches server/index.ts loop).
                        for s in to_add:
                            parent = s.get('parentId') or 'page:page'
                            below = highest.get(parent)
                            key = _gen_index_keys([[below, None]])[0]
                            new_indexes.append(key)
                            highest[parent] = key
                        # insert normalized records
                        ni = 0
                        for shape in normalized:
                            sid = shape.get('id')
                            if not sid or store.get(sid):
                                continue
                            rec = dict(shape)
                            rec.setdefault('rotation', 0)
                            rec.setdefault('isLocked', False)
                            rec.setdefault('opacity', 1)
                            rec.setdefault('meta', {})
                            rec['parentId'] = shape.get('parentId') or 'page:page'
                            rec['index'] = new_indexes[ni] if ni < len(new_indexes) else _gen_index_keys([[None, None]])[0]
                            rec['typeName'] = shape.get('typeName') or 'shape'
                            store[sid] = rec
                            ni += 1
                            persisted += 1
                        if persisted > 0:
                            _canvas['version'] += 1
                            _canvas_persist()
                    except Exception as e:
                        persist_error = str(e)
                    ver = _canvas['version']
                resp = {'ok': True, 'queued': len(shapes), 'persisted': persisted, 'version': ver}
                if persist_error:
                    resp['persistError'] = persist_error
                self._json_cors(200, resp)
            except Exception as e:
                self._json_cors(500, {'error': str(e)})
            return
        if self.path == '/api/canvas/remove-shapes':
            try:
                body = self._read_body()
                ids = body.get('ids')
                if not isinstance(ids, list):
                    self._json_cors(400, {'error': 'ids must be array'}); return
                with _canvas_lock:
                    _pending_deletes.extend(ids)
                    removed_mem = 0
                    for i in ids:
                        if _canvas['store'].get(i) is not None:
                            del _canvas['store'][i]
                            removed_mem += 1
                    if removed_mem > 0:
                        _canvas['version'] += 1
                        _canvas_persist()
                    ver = _canvas['version']
                self._json_cors(200, {'ok': True, 'queued': len(ids),
                                      'removedMem': removed_mem, 'version': ver})
            except Exception as e:
                self._json_cors(500, {'error': str(e)})
            return
        if self.path == '/api/canvas/update-positions':
            try:
                body = self._read_body()
                positions = body.get('positions')
                if not isinstance(positions, list):
                    self._json_cors(400, {'error': 'positions must be array'}); return
                updated = 0
                missing = []
                with _canvas_lock:
                    store = _canvas['store']
                    for p in positions:
                        if not isinstance(p, dict) or not isinstance(p.get('id'), str):
                            continue
                        rec = store.get(p['id'])
                        if not isinstance(rec, dict) or rec.get('typeName') != 'shape':
                            missing.append(p.get('id')); continue
                        if isinstance(p.get('x'), (int, float)):
                            rec['x'] = p['x']
                        if isinstance(p.get('y'), (int, float)):
                            rec['y'] = p['y']
                        updated += 1
                    if updated > 0:
                        _canvas['version'] += 1
                        _canvas_persist()
                    ver = _canvas['version']
                self._json_cors(200, {'ok': True, 'updated': updated,
                                      'missing': missing, 'version': ver})
            except Exception as e:
                self._json_cors(500, {'error': str(e)})
            return
        if self.path == '/api/queue/cancel':
            # Cancel a STILL-WAITING queued prompt before the runner picks it up.
            # Body: {channel, id} where id = the queue filename stem ('0001').
            # Race-safe: we only delete the file if it is NOT the head being
            # processed right now. The runner drains files[0] (lowest stem) and
            # leaves it on disk until the turn ends, so while `busy` the head ==
            # the running item — we must NEVER remove it (that would not stop the
            # turn, just orphan it). Returns {ok, cancelled}: cancelled=False if the
            # item already started/left the queue (idempotent, no error).
            try:
                body = self._read_body()
                channel = body.get('channel', 'main')
                qid = str(body.get('id') or '').strip()
                if '/' in channel or '..' in channel:
                    raise ValueError('bad channel')
                # id must be a bare numeric stem — refuse anything path-like so a
                # crafted id can't escape the queue dir.
                import re as _cre
                if not _cre.match(r'^\d+$', qid):
                    raise ValueError('bad id')
                q_dir = os.path.join(DIR, 'channels', channel, 'queue')
                target = os.path.join(q_dir, f'{qid}.json')
                busy = os.path.exists(
                    os.path.join(DIR, 'channels', channel, 'busy'))
                cancelled = False
                if os.path.isdir(q_dir) and os.path.exists(target):
                    files = sorted([f for f in os.listdir(q_dir)
                                    if _cre.match(r'\d+\.json$', f)])
                    is_head = bool(files) and files[0] == f'{qid}.json'
                    # The head is the running item only while busy. Don't touch it.
                    if not (busy and is_head):
                        try:
                            with open(target, encoding='utf-8') as jf:
                                dropped_id = (json.load(jf) or {}).get('user_msg_id')
                        except Exception:
                            dropped_id = None
                        try:
                            os.remove(target)
                            cancelled = True
                        except OSError:
                            # vanished between stat and unlink (runner grabbed it):
                            # treat as already-gone, not an error.
                            cancelled = False
                        # Same fate as a stopped turn: this prompt will never run,
                        # so its bubble says so instead of silently losing its dot.
                        if cancelled:
                            try:
                                self._mark_messages_stopped(channel, [dropped_id])
                            except Exception:
                                pass
                self._json(200, {'ok': True, 'cancelled': cancelled})
            except Exception as e:
                self._json(500, {'ok': False, 'error': str(e)})
            return
        if self.path == '/api/send':
            # Two-way chat: Vova types a prompt in the web view. We (1) render an
            # optimistic user bubble immediately, (2) enqueue the prompt for the
            # runner, (3) mark the channel busy so the UI shows "Claude друкує".
            try:
                body = self._read_body()
                channel = body.get('channel', 'main')
                # Strip lone surrogates: a half-emoji in the prompt would crash the
                # channel file write (json.dump -> utf-8 with ensure_ascii=False).
                text = _strip_lone_surrogates((body.get('text') or '').strip())
                attachments = body.get('attachments') or []
                # attachments = list of {path, url, name, kind, ...} (returned by
                # /api/upload) or bare path strings (legacy / direct API). Normalize
                # to {path, url, name, kind, ext, mime, bytes} so the user bubble can
                # show a thumbnail (image) OR a file chip (text/doc), and the runner
                # can Read the file (path). kind is re-derived from the name if the
                # client didn't send it, so old clients still get the right widget.
                norm_att = []
                for a in attachments:
                    p = a.get('path') if isinstance(a, dict) else a
                    if not p:
                        continue
                    url = a.get('url') if isinstance(a, dict) else None
                    if not url:
                        # derive a DIR-relative URL if the file lives under DIR
                        try:
                            rel = os.path.relpath(p, DIR)
                            url = '/' + rel if not rel.startswith('..') else None
                        except Exception:
                            url = None
                    meta = a if isinstance(a, dict) else {}
                    name = meta.get('name') or os.path.basename(str(p))
                    kind = meta.get('kind')
                    ext = meta.get('ext')
                    mime = meta.get('mime')
                    if not kind or not ext or not mime:
                        k2, e2, m2 = _classify_attachment(name)
                        kind = kind or k2
                        ext = ext or e2
                        mime = mime or m2
                    nbytes = meta.get('bytes')
                    if nbytes is None:
                        try:
                            nbytes = os.path.getsize(p)
                        except Exception:
                            nbytes = 0
                    norm_att.append({'path': p, 'url': url, 'name': name,
                                     'kind': kind, 'ext': ext, 'mime': mime,
                                     'bytes': nbytes})
                if not text and not norm_att:
                    raise ValueError('empty text')
                if '/' in channel or '..' in channel:
                    raise ValueError('bad channel')
                # Reply target (Vova 2026-06-29): {id, author, snippet}. We (a) show a
                # small quote on the user bubble, and (b) prefix the AI's prompt with the
                # quoted context so it knows which message Vova is replying to.
                reply = body.get('replyTo') if isinstance(body.get('replyTo'), dict) else None
                reply_snip = ''
                reply_author = ''
                if reply:
                    # Slicing a reply snippet to [:280] can cut mid-emoji, leaving a
                    # LONE UTF-16 surrogate. With ensure_ascii=False the channel
                    # write (json.dump -> utf-8) then raises and the send 500s.
                    # Strip unpaired surrogates so a half-emoji never crashes encode.
                    reply_snip = _strip_lone_surrogates((str(reply.get('snippet') or '')).strip()[:280])
                    reply_author = _strip_lone_surrogates((str(reply.get('author') or '')).strip()[:40])
                # 1) user bubble (renders right-aligned via from=Я). Optional reply quote
                # on top, then text + photo thumbnails so Vova sees what he sent.
                user_widgets = []
                if reply and reply_snip:
                    user_widgets.append({'type': 'reply', 'refId': reply.get('id'),
                                         'author': reply_author, 'snippet': reply_snip})
                if text:
                    user_widgets.append({'type': 'text', 'text': text})
                if norm_att:
                    # Each item carries enough for the renderer to branch:
                    # image → thumbnail (needs url); text/doc → file chip
                    # (name + kind + ext + size; url for download if present).
                    user_widgets.append({'type': 'attachments',
                                         'items': [{'url': a.get('url'), 'name': a.get('name'),
                                                    'kind': a.get('kind'), 'ext': a.get('ext'),
                                                    'bytes': a.get('bytes')} for a in norm_att]})
                msg_id = self._append_message(channel, user_widgets, frm='Я')
                # Text the AI actually receives: prefix the quoted context (the chosen
                # "quote-prefix in text" solution), keep the user bubble text clean above.
                queue_text = text
                if reply and reply_snip:
                    who = reply_author or 'повідомлення'
                    queue_text = (f'[Контекст: я відповідаю на це повідомлення ({who}): '
                                  f'«{reply_snip}»]\n\n{text}')
                # Inline TEXT-file attachment content directly into the prompt the AI
                # receives (stdlib only). This is the DETERMINISTIC path: the model
                # gets the file body even before reaching for the Read tool.
                #   text → read + embed in a fenced block (truncated at the char cap)
                #   doc  → pdf/docx/binary: NOT parsed here. We note the attached path
                #          and tell the model to try the Read tool (it can open PDFs).
                # TODO(doc-parsing): real pdf/docx text extraction is a SEPARATE stage
                #   — it needs a pip library (pdfminer.six / python-docx) which would
                #   break the stdlib-only design. Do NOT add pip deps for this; when we
                #   relax that rule, parse here and inline like text files below.
                inline_blocks = []
                doc_notes = []
                for a in norm_att:
                    if a.get('kind') == 'text':
                        content, truncated = _read_text_attachment(a['path'])
                        if content:
                            fence = '```'
                            # avoid a stray ``` inside the file closing our fence
                            while fence in content:
                                fence += '`'
                            cut = ' (обрізано — файл завеликий)' if truncated else ''
                            inline_blocks.append(
                                f'Вміст прикріпленого файлу «{a.get("name")}»{cut}:\n'
                                f'{fence}\n{content}\n{fence}')
                    elif a.get('kind') == 'doc':
                        doc_notes.append(a['path'])
                extra = []
                if inline_blocks:
                    extra.append('\n\n'.join(inline_blocks))
                if doc_notes:
                    listing = '\n'.join(doc_notes)
                    extra.append(
                        'Прикріплені документи (бінарні — PDF/Office). Спробуй '
                        'відкрити через Read tool (PDF підтримується параметром pages):\n'
                        + listing)
                if extra:
                    queue_text = (queue_text + '\n\n' + '\n\n'.join(extra)) if queue_text else '\n\n'.join(extra)
                # Auto-name a fresh chat from its FIRST user message: if this is
                # the channel's first bubble and its label is still a default/auto
                # one ('Новий чат' / 'Code HH:MM' / empty / == id), set the tab
                # label to a snippet of this text. No-op on 2nd+ msgs or custom
                # labels. Graceful (swallows its own errors).
                self._maybe_autoname_channel(channel, text)
                # At the Nth bubble, upgrade a still-auto label to a proper
                # LLM-generated title (runs in a background thread, never blocks).
                self._maybe_llm_rename_channel(channel)
                # ensure the channel has a bound claude session id
                sid = self._channel_session_id(channel, create=True)
                ch_dir = os.path.join(DIR, 'channels', channel)
                # 2) busy flag FIRST (before enqueue) so the runner never sees a
                # queued item without busy. Otherwise its stop-guard reads the
                # missing busy as a Стоп and silently drains the message.
                from datetime import datetime
                with open(os.path.join(ch_dir, 'busy'), 'w') as f:
                    f.write(datetime.now().isoformat())
                # 3) enqueue
                q_dir = os.path.join(ch_dir, 'queue')
                os.makedirs(q_dir, exist_ok=True)
                import glob
                import re as _re
                qids = [0]
                for f in glob.glob(os.path.join(q_dir, '[0-9]*.json')):
                    m = _re.match(r'(\d+)', os.path.basename(f))
                    if m:
                        qids.append(int(m.group(1)))
                qn = max(qids) + 1
                # Stable queue-item id = the filename stem ('0001'). Stored INSIDE
                # the job too (qid) and returned to the client so the front-end can
                # map this just-sent bubble → its queue file and later cancel it.
                qid = f'{qn:04d}'
                from datetime import datetime
                with open(os.path.join(q_dir, f'{qid}.json'), 'w', encoding='utf-8') as f:
                    json.dump({'text': queue_text, 'session_id': sid, 'user_msg_id': msg_id,
                               'qid': qid, 'attachments': norm_att,
                               'ts': datetime.now().isoformat()}, f, ensure_ascii=False)
                self._json(200, {'ok': True, 'id': msg_id, 'session_id': sid,
                                 'qid': qid})
            except Exception as e:
                self._json(500, {'ok': False, 'error': str(e)})
            return
        if self.path == '/api/import':
            # Offline IMPORT: accept a raw .zip in the request body (produced by
            # /api/export on another machine). Restores channels + canvas data
            # (merge) and drops each session .jsonl into THIS machine's re-encoded
            # ~/.claude/projects/<enc(CLAUDE_REPO_ROOT)>/ dir. See transfer.py.
            try:
                length = int(self.headers.get('Content-Length', 0))
                if length <= 0:
                    raise ValueError('empty body (expected a .zip)')
                blob = self.rfile.read(length)
                report = _transfer.import_zip(
                    blob, DIR, CLAUDE_REPO_ROOT, _encode_project_dir, log=print)
                self._json(200, {'ok': True, **report})
            except Exception as e:
                self._json(500, {'ok': False, 'error': str(e)})
            return
        if self.path == '/api/upload':
            # Upload for two-way chat attachments — IMAGES *and* DOCUMENTS.
            # Accepts JSON: {channel, filename, data} where data is base64
            # (optionally a data: URL). Saves to channels/<id>/uploads/<unique>.<ext>.
            # Returns the attachment meta schema:
            #   {ok, path  — absolute, for the runner's Read tool
            #       url   — DIR-relative, for the front-end thumbnail / chip
            #       name  — original filename (display + download)
            #       ext   — extension w/o dot (drives the icon family)
            #       kind  — 'image' | 'text' | 'doc'  (see _classify_attachment)
            #       mime  — content type
            #       bytes — saved size}
            # Images render thumbnails; text/doc render a file chip. Text content
            # is inlined into the AI prompt later, in /api/send.
            try:
                import base64
                import uuid
                import re as _re
                body = self._read_body()
                channel = body.get('channel', 'main')
                if '/' in channel or '..' in channel:
                    raise ValueError('bad channel')
                raw = body.get('data') or ''
                filename = body.get('filename') or 'file.bin'
                # strip data URL prefix if present
                m = _re.match(r'^data:([^;]+);base64,(.*)$', raw, _re.DOTALL)
                if m:
                    raw = m.group(2)
                try:
                    blob = base64.b64decode(raw, validate=False)
                except Exception as e:
                    raise ValueError(f'bad base64: {e}')
                if not blob:
                    raise ValueError('empty file')
                if len(blob) > _MAX_UPLOAD_BYTES:
                    raise ValueError('file too large (>25MB)')
                kind, ext, mime = _classify_attachment(filename)
                # Sanitize the on-disk extension (alnum, ≤8 chars) so a crafted
                # filename can't smuggle a path/dot into the uploads dir name.
                safe_ext = _re.sub(r'[^a-z0-9]', '', ext)[:8] or 'bin'
                up_dir = os.path.join(DIR, 'channels', channel, 'uploads')
                os.makedirs(up_dir, exist_ok=True)
                unique = uuid.uuid4().hex[:12] + '.' + safe_ext
                fpath = os.path.join(up_dir, unique)
                with open(fpath, 'wb') as f:
                    f.write(blob)
                url = f'/channels/{channel}/uploads/{unique}'
                # Keep just the basename for display (drop any client path/dirs).
                disp_name = os.path.basename(str(filename)) or ('file.' + safe_ext)
                self._json(200, {'ok': True, 'path': os.path.abspath(fpath),
                                 'url': url, 'name': disp_name, 'ext': ext,
                                 'kind': kind, 'mime': mime, 'bytes': len(blob)})
            except Exception as e:
                self._json(500, {'ok': False, 'error': str(e)})
            return
        if self.path == '/api/app-create':
            # App-builder: scaffold apps/<appId>, create a twoway channel in
            # mode=app-builder bound to it, seed instructions.md + a welcome card.
            # NOT registered in apps/index.json until the user hits "Готово".
            try:
                reg_path = os.path.join(DIR, 'channels', 'index.json')
                reg = json.load(open(reg_path)) if os.path.exists(reg_path) else []
                n = 1
                while os.path.isdir(os.path.join(DIR, 'apps', 'app-%d' % n)):
                    n += 1
                app_id = 'app-%d' % n
                cid = app_id
                k = 2
                while any(c.get('id') == cid for c in reg) or os.path.isdir(os.path.join(DIR, 'channels', cid)):
                    cid = '%s-%d' % (app_id, k); k += 1
                adir = os.path.join(DIR, 'apps', app_id)
                os.makedirs(adir, exist_ok=True)
                with open(os.path.join(adir, 'manifest.json'), 'w', encoding='utf-8') as f:
                    json.dump({'id': app_id, 'name': 'Новий додаток', 'icon': '\U0001f9e9',
                               'description': 'Збирається у чаті'}, f, ensure_ascii=False, indent=2)
                vp = os.path.join(adir, 'view.html')
                if not os.path.exists(vp):
                    with open(vp, 'w', encoding='utf-8') as f:
                        f.write(_APP_PLACEHOLDER_HTML)
                ch_dir = os.path.join(DIR, 'channels', cid)
                os.makedirs(ch_dir, exist_ok=True)
                mi = os.path.join(ch_dir, 'index.json')
                if not os.path.exists(mi):
                    try: _atomic_write_json(mi, [])
                    except Exception: pass
                with open(os.path.join(ch_dir, 'instructions.md'), 'w', encoding='utf-8') as f:
                    f.write(_APP_BUILDER_INSTRUCTIONS.format(app_id=app_id, channel=cid))
                reg.append({'id': cid, 'label': '\U0001f9e9 Новий додаток', 'icon': '\U0001f9e9',
                            'twoway': True, 'model': 'opus', 'mode': 'app-builder', 'permission': 'acceptEdits', 'appId': app_id})
                _atomic_write_json(reg_path, reg)
                sid = self._channel_session_id(cid, create=True)
                try:
                    _app_post_card(ch_dir, _APP_WELCOME_WIDGETS, 'Конструктор', 'app-builder')
                except Exception:
                    pass
                self._json(200, {'ok': True, 'id': cid, 'appId': app_id, 'session_id': sid})
            except Exception as e:
                self._json(500, {'ok': False, 'error': str(e)})
            return
        if self.path == '/api/app-open':
            # Open an EXISTING app (apps/<appId>) as a COLUMN: find the app-builder
            # channel bound to it, or create one on the fly, so a finished gadget
            # becomes a real column with a live preview (not the legacy modal).
            # Idempotent: at most ONE app-builder channel per appId.
            try:
                body = self._read_body()
                app_id = str(body.get('appId') or '').strip()
                if not app_id or not all(ch.isalnum() or ch in '-_' for ch in app_id):
                    self._json(400, {'ok': False, 'error': 'bad appId'}); return
                adir = os.path.join(DIR, 'apps', app_id)
                if not os.path.isdir(adir):
                    self._json(404, {'ok': False, 'error': 'no such app'}); return
                reg_path = os.path.join(DIR, 'channels', 'index.json')
                reg = json.load(open(reg_path)) if os.path.exists(reg_path) else []
                existing = next((c for c in reg if c.get('mode') == 'app-builder'
                                 and c.get('appId') == app_id and not c.get('hidden')), None)
                if existing:
                    self._json(200, {'ok': True, 'id': existing.get('id'), 'appId': app_id}); return
                man = {}
                try: man = json.load(open(os.path.join(adir, 'manifest.json')))
                except Exception: man = {}
                name = man.get('name') or 'Додаток'
                icon = man.get('icon') or '\U0001f9e9'
                cid = app_id
                k = 2
                while any(c.get('id') == cid for c in reg) or os.path.isdir(os.path.join(DIR, 'channels', cid)):
                    cid = '%s-%d' % (app_id, k); k += 1
                ch_dir = os.path.join(DIR, 'channels', cid)
                os.makedirs(ch_dir, exist_ok=True)
                mi = os.path.join(ch_dir, 'index.json')
                if not os.path.exists(mi):
                    try: _atomic_write_json(mi, [])
                    except Exception: pass
                try:
                    with open(os.path.join(ch_dir, 'instructions.md'), 'w', encoding='utf-8') as f:
                        f.write(_APP_BUILDER_INSTRUCTIONS.format(app_id=app_id, channel=cid))
                except Exception:
                    pass
                reg.append({'id': cid, 'label': ('%s %s' % (icon, name)).strip(), 'icon': icon,
                            'twoway': True, 'model': 'opus', 'mode': 'app-builder',
                            'permission': 'acceptEdits', 'appId': app_id})
                _atomic_write_json(reg_path, reg)
                self._json(200, {'ok': True, 'id': cid, 'appId': app_id})
            except Exception as e:
                self._json(500, {'ok': False, 'error': str(e)})
            return
        if self.path == '/api/new-chat':
            # Create a fresh channel + bind a new claude session id. Returns the
            # channel id so the front end can switch to it.
            try:
                body = self._read_body()
                label = (body.get('label') or '').strip() or 'Новий чат'
                # Fresh-chat baseline = '🆕' (lively), never the dull gray '💬'.
                # The caller may still send any icon to override this default.
                icon = body.get('icon') or '🆕'
                import re as _re
                # ASCII slug; Cyrillic labels collapse to empty -> 'chat' base.
                base = _re.sub(r'[^a-z0-9]+', '-', label.lower()).strip('-') or 'chat'
                reg_path = os.path.join(DIR, 'channels', 'index.json')
                reg = json.load(open(reg_path)) if os.path.exists(reg_path) else []
                cid = base
                n = 2
                while any(c.get('id') == cid for c in reg) or os.path.isdir(os.path.join(DIR, 'channels', cid)):
                    cid = f'{base}-{n}'
                    n += 1
                ch_dir = os.path.join(DIR, 'channels', cid)
                os.makedirs(ch_dir, exist_ok=True)
                # Seed an empty messages index so the channel has a CREATION mtime.
                # _merged_registry() derives updatedAt from this file's mtime; without
                # it a brand-new chat reports updatedAt=0 and sortChannelsByLastEdit()
                # buries it at the BOTTOM of the launcher / ▼ switcher (below every
                # channel that ever got a message) — so the user "creates a chat and it
                # disappears". A just-created index.json stamps it as the most-recent
                # channel, so it sorts to the TOP and stays visible. Never clobber an
                # existing file (ids are unique above, but stay defensive on reuse).
                msg_idx = os.path.join(ch_dir, 'index.json')
                if not os.path.exists(msg_idx):
                    try:
                        _atomic_write_json(msg_idx, [])
                    except Exception:
                        pass
                reg.append({'id': cid, 'label': label, 'icon': icon, 'twoway': True})
                _atomic_write_json(reg_path, reg)
                sid = self._channel_session_id(cid, create=True)
                self._json(200, {'ok': True, 'id': cid, 'label': label, 'session_id': sid})
            except Exception as e:
                self._json(500, {'ok': False, 'error': str(e)})
            return
        if self.path == '/api/channel-seen':
            # Vova opened a tab => clear its "done" (green) marker server-side so the
            # green dot does not reappear on the next poll. Body: {channel}.
            try:
                body = self._read_body()
                channel = (body.get('channel') or '').strip()
                if not channel or '/' in channel or '..' in channel:
                    raise ValueError('bad channel')
                done_path = os.path.join(DIR, 'channels', channel, 'cc-done')
                existed = os.path.exists(done_path)
                if existed:
                    try:
                        os.remove(done_path)
                    except Exception:
                        pass
                self._json(200, {'ok': True, 'cleared': existed})
            except Exception as e:
                self._json(500, {'ok': False, 'error': str(e)})
            return
        if self.path == '/api/transcribe':
            # Ukrainian speech-to-text. Body JSON: {audio: base64 (optional
            # data: URL prefix), mime: "audio/webm"}.
            # PRIMARY = local whisper.cpp large-v3 (Metal, free, offline).
            # FALLBACK = OpenAI whisper-1 if local fails for ANY reason.
            # Returns {ok, text, engine: "local"|"cloud"}.
            import sys as _sys
            try:
                import base64
                import re as _re
                body = self._read_body()
                raw = body.get('audio') or ''
                mime = (body.get('mime') or 'audio/webm').strip()
                # Strip any data:URL prefix. Chrome's MediaRecorder yields
                # "data:audio/webm;codecs=opus;base64,..." (TWO semicolons), so a
                # strict ^data:([^;]+);base64,$ regex fails to match and we'd try
                # to b64decode the whole thing. Split on the literal "base64," to
                # be robust to any number of header params (codecs=opus etc).
                if raw.startswith('data:'):
                    _idx = raw.find('base64,')
                    if _idx != -1:
                        _hdr = raw[5:_idx]  # e.g. "audio/webm;codecs=opus;"
                        _mt = _hdr.split(';', 1)[0].strip()
                        if _mt and (not mime or mime == 'audio/webm'):
                            mime = _mt
                        raw = raw[_idx + len('base64,'):]
                # Defensive: drop whitespace/newlines that break b64decode length.
                raw = ''.join(raw.split())
                try:
                    blob = base64.b64decode(raw, validate=False)
                except Exception as e:
                    self._json(400, {'ok': False, 'error': f'bad base64: {e}'})
                    return
                if not blob:
                    self._json(400, {'ok': False, 'error': 'empty audio'})
                    return
                if len(blob) > 25 * 1024 * 1024:
                    self._json(400, {'ok': False, 'error': 'audio too large (>25MB)'})
                    return
                import time as _time
                # --- TEST PRIMARY: Grok STT (Vova 2026-07-17, flag STT_PRIMARY_GROK) ---
                # When on, Vova's dictaphone hits grok-stt first so he can judge UA
                # quality live. Garbage still returns as text (that IS the test). On
                # ANY Grok error we fall through to local whisper.cpp -> OpenAI.
                if STT_PRIMARY_GROK:
                    try:
                        _t0 = _time.time()
                        text = _transcribe_grok(blob, mime)
                        if text:
                            self._json(200, {'ok': True, 'text': text, 'engine': 'grok',
                                             'took': round(_time.time() - _t0, 2)})
                            return
                        print('[transcribe] grok empty, falling back',
                              file=_sys.stderr, flush=True)
                    except Exception as e:
                        print('[transcribe] grok FAILED, falling back: %s' % e,
                              file=_sys.stderr, flush=True)
                # --- PRIMARY: local whisper.cpp ---
                local_err = None
                try:
                    _t0 = _time.time()
                    text = _transcribe_local(blob, mime)
                    self._json(200, {'ok': True, 'text': text, 'engine': 'local',
                                     'took': round(_time.time() - _t0, 2)})
                    return
                except Exception as e:
                    local_err = str(e)
                    print('[transcribe] local FAILED, falling back to cloud: %s'
                          % local_err, file=_sys.stderr, flush=True)
                # --- FALLBACK: OpenAI cloud ---
                try:
                    _t0 = _time.time()
                    text = _transcribe_cloud(blob, mime)
                    self._json(200, {'ok': True, 'text': text, 'engine': 'cloud',
                                     'took': round(_time.time() - _t0, 2),
                                     'local_err': local_err})
                except Exception as e:
                    self._json(502, {'ok': False, 'engine': 'cloud',
                                     'error': f'local failed ({local_err}); cloud failed ({e})'})
            except Exception as e:
                self._json(500, {'ok': False, 'error': str(e)})
            return
        if self.path == '/api/keys':
            # Save user-supplied BYOK keys to CHATVIEW_HOME/keys.json (NOT the repo).
            # Body: {"openai": "sk-...", "gemini": "AIza..."} — any subset. An empty
            # string for a provider clears it (lets the user delete a stored key).
            # Keys present in .env still work as a fallback (see _load_*_key()).
            try:
                body = self._read_body()
                keys = _load_user_keys()
                for prov in ('openai', 'gemini'):
                    if prov in body:
                        val = (str(body.get(prov) or '')).strip()
                        if val:
                            keys[prov] = val
                        else:
                            keys.pop(prov, None)  # empty => remove stored key
                _atomic_write_json(_keys_file(), keys)
                self._json(200, {'ok': True,
                                 'openai': bool(keys.get('openai')),
                                 'gemini': bool(keys.get('gemini'))})
            except Exception as e:
                self._json(500, {'ok': False, 'error': str(e)})
            return
        if self.path == '/api/antigravity':
            # Blocking one-shot call to the Antigravity CLI (Vova's Gemini
            # subscription, creds in macOS Keychain). Body: {prompt, model?}.
            # prompt is passed as a subprocess ARG (list form) — never shell=True /
            # string interpolation — so there is no injection surface.
            try:
                import subprocess, time
                body = self._read_body()
                prompt = (body.get('prompt') or '').strip()
                model = (body.get('model') or '').strip()
                if not prompt:
                    self._json(400, {'ok': False, 'error': 'empty prompt'})
                    return
                if not _AGY_BIN:
                    self._json(503, {'ok': False, 'error': 'agy CLI not installed'})
                    return
                cmd = [_AGY_BIN, '-p', prompt]
                if model:
                    cmd += ['--model', model]
                t0 = time.time()
                # 300s matches agy's default --print-timeout 5m so we never hang forever.
                r = subprocess.run(cmd, capture_output=True, text=True, timeout=300)
                dt = time.time() - t0
                if r.returncode != 0:
                    err = (r.stderr or r.stdout or 'agy exited non-zero').strip()[:500]
                    print('[antigravity] exit=%d took=%.2fs err=%s'
                          % (r.returncode, dt, err[:120]), file=sys.stderr, flush=True)
                    self._json(502, {'ok': False, 'error': err})
                    return
                text = (r.stdout or '').strip()
                print('[antigravity] ok took=%.2fs chars=%d model=%s'
                      % (dt, len(text), model or 'default'), file=sys.stderr, flush=True)
                self._json(200, {'ok': True, 'text': text, 'model': model or 'default'})
            except subprocess.TimeoutExpired:
                self._json(504, {'ok': False, 'error': 'agy timed out (300s)'})
            except Exception as e:
                self._json(500, {'ok': False, 'error': str(e)})
            return

        # ── Guided Connection Wizard: INSTALL agy (cross-platform aware) ─────
        # macOS + Homebrew → one-click `brew install --cask antigravity-cli`.
        # Anything else (Linux, Windows, or macOS without brew) → we DON'T fire a
        # broken command; we return ok:false with a clear per-OS manual
        # instruction (`manual` + `install_cmd`) so the UI can guide the user
        # instead of crashing opaquely. Full one-click Win/Linux is a later pass.
        if self.path == '/api/connect/antigravity/install':
            try:
                import subprocess as _sp, shutil as _sh, time as _t, platform as _pf
                if _AGY_BIN:
                    # Already installed — no-op success (idempotent).
                    self._json(200, {'ok': True, 'already': True,
                                     'path': _AGY_BIN, 'log': 'already installed'})
                    return
                osname = _pf.system()   # 'Darwin' | 'Linux' | 'Windows'
                curl_cmd = 'curl -fsSL https://antigravity.google/cli/install.sh | bash'
                if osname == 'Darwin':
                    brew = _sh.which('brew') or (
                        '/opt/homebrew/bin/brew' if os.path.exists('/opt/homebrew/bin/brew')
                        else ('/usr/local/bin/brew' if os.path.exists('/usr/local/bin/brew') else ''))
                    if not brew:
                        # macOS без brew → офіційний curl-інсталер (не крашимо).
                        self._json(200, {'ok': False, 'manual': True,
                                         'os': 'mac', 'install_cmd': curl_cmd,
                                         'error': 'Homebrew не знайдено. Встанови agy офіційним інсталером '
                                                  '(команда в install_cmd) і натисни «Перевірити ще раз».'})
                        return
                    t0 = _t.time()
                    r = _sp.run([brew, 'install', '--cask', 'antigravity-cli'],
                                capture_output=True, text=True, timeout=600)
                    # brew writes progress to stderr; merge tails for the UI.
                    tail = ((r.stdout or '') + '\n' + (r.stderr or '')).strip()[-1200:]
                    # Re-detect: brew symlinks `agy` into the prefix.
                    _refresh_agy_bin()
                    ok = bool(_AGY_BIN)
                    print('[connect] install brew rc=%d took=%.1fs agy=%s'
                          % (r.returncode, _t.time() - t0, _AGY_BIN or 'MISSING'),
                          file=sys.stderr, flush=True)
                    self._json(200, {'ok': ok, 'path': _AGY_BIN or None,
                                     'returncode': r.returncode, 'log': tail,
                                     'error': None if ok else 'agy not on PATH after install'})
                    return
                if osname == 'Linux':
                    # Try the official curl installer on Linux (best-effort, bounded).
                    if not _sh.which('curl') and not _sh.which('bash'):
                        self._json(200, {'ok': False, 'manual': True, 'os': 'linux',
                                         'install_cmd': curl_cmd,
                                         'error': 'Постав agy офіційним інсталером (команда в install_cmd) '
                                                  'і натисни «Перевірити ще раз».'})
                        return
                    t0 = _t.time()
                    r = _sp.run(['bash', '-lc', curl_cmd],
                                capture_output=True, text=True, timeout=600)
                    tail = ((r.stdout or '') + '\n' + (r.stderr or '')).strip()[-1200:]
                    _refresh_agy_bin()
                    ok = bool(_AGY_BIN)
                    print('[connect] install linux rc=%d took=%.1fs agy=%s'
                          % (r.returncode, _t.time() - t0, _AGY_BIN or 'MISSING'),
                          file=sys.stderr, flush=True)
                    self._json(200, {'ok': ok, 'path': _AGY_BIN or None,
                                     'returncode': r.returncode, 'log': tail,
                                     'os': 'linux', 'install_cmd': curl_cmd,
                                     'error': None if ok else 'agy не знайдено після інсталера. '
                                              'Спробуй вручну (команда в install_cmd).'})
                    return
                # Windows or anything else → manual, no broken auto-install.
                win_cmd = 'irm https://antigravity.google/cli/install.ps1 | iex'
                self._json(200, {'ok': False, 'manual': True,
                                 'os': ('windows' if osname == 'Windows' else 'other'),
                                 'install_cmd': (win_cmd if osname == 'Windows' else curl_cmd),
                                 'error': ('Автовстановлення для цієї ОС поки не підтримується. '
                                           'Постав agy офіційним інсталером (команда нижче), '
                                           'тоді натисни «Перевірити ще раз».')})
            except subprocess.TimeoutExpired:
                self._json(200, {'ok': False, 'error': 'встановлення перевищило ліміт часу (10 хв)'})
            except Exception as e:
                self._json(200, {'ok': False, 'error': str(e)})
            return

        # ── Guided Connection Wizard: LOGIN start (PTY) ──────────────────────
        # Spawn `agy` in a PTY, script /logout → /login → confirm Google OAuth,
        # capture the OAuth URL, keep the session alive. Returns {session_id,
        # login_url, ...}. The user opens login_url and picks the right account;
        # the front end then polls /login/status.
        if self.path == '/api/connect/antigravity/login/start':
            try:
                if not _AGY_BIN:
                    self._json(503, {'ok': False, 'error': 'agy CLI not installed'})
                    return
                _agy_login_gc()
                # GLOBAL-AUTH-FIRST (case 6 + race guard): if the token is already
                # cached, don't spawn a PTY / reopen the browser — just report
                # success so the UI shows Connected. Cheap `agy models` probe.
                try:
                    _pre = _agy_status()
                except Exception:
                    _pre = {'logged_in': False}
                if _pre.get('logged_in'):
                    _agy_dbg('login/start: already logged in (%s) → skip PTY, success'
                             % _pre.get('account'), 'start')
                    self._json(200, {'ok': True, 'already_logged_in': True,
                                     'state': 'success', 'account': _pre.get('account')})
                    return
                # ── WINDOWS: no PTY-driven auto-login ────────────────────────
                # The macOS wizard scripts agy's TUI inside a pseudo-terminal
                # (pty.fork), which does not exist on Windows — spawning the PTY
                # session here would just hang ~30s in a dead thread and return a
                # confusing "no login URL". Instead, since agy's interactive login
                # needs a real console anyway, we (best-effort) open `agy` in its
                # OWN visible console so Vova can run /login and pick his Google
                # account there, and return a crisp instruction. Auth detection is
                # behavior-based (`agy models`), so /status + /login/status flip to
                # Connected on their own once sign-in completes — nothing to paste
                # back. Reached ONLY when NOT already logged in (checked above), so
                # on this machine (agy already authenticated) it never fires.
                if sys.platform == 'win32':
                    opened = False
                    try:
                        import subprocess as _sp
                        _sp.Popen([_AGY_BIN], creationflags=_sp.CREATE_NEW_CONSOLE)
                        opened = True
                    except Exception as _e:
                        _agy_dbg('login/start win: could not open agy console: %r' % _e, 'start')
                    instr = (('Відкрилось вікно терміналу з Antigravity. У ньому набери /login, '
                              'натисни Enter, обери Google-акаунт із підпискою і заверши вхід у '
                              'браузері. Щойно ввійдеш — статус тут оновиться сам.')
                             if opened else
                             ('Відкрий термінал (PowerShell або Windows Terminal), набери agy і '
                              'натисни Enter. У вікні agy набери /login, обери Google-акаунт із '
                              'підпискою і заверши вхід. Далі статус тут оновиться сам.'))
                    self._json(200, {'ok': False, 'manual': True, 'os': 'windows',
                                     'state': 'awaiting_terminal', 'opened_terminal': opened,
                                     'instruction': instr, 'error': instr})
                    return
                # CONCURRENT-START GUARD (case 11: double-click / two tabs): if a
                # live session already has a URL and is awaiting the browser, REUSE
                # it instead of spawning a rival PTY that would fight for the lock.
                with _AGY_LOGIN_LOCK:
                    _existing = next(
                        (s for s in _AGY_LOGIN_SESSIONS.values()
                         if s.login_url and s.state in ('awaiting_browser', 'awaiting_url')
                         and not s._torn_down), None)
                    _ex_id = _existing.id if _existing else None
                    _ex_url = _existing.login_url if _existing else None
                if _existing:
                    _agy_dbg('login/start: reusing live session=%s (concurrent guard)'
                             % _ex_id, 'start')
                    self._json(200, {'ok': True, 'session_id': _ex_id,
                                     'login_url': _ex_url, 'state': 'awaiting_browser',
                                     'reused': True})
                    return
                sess = _AgyLoginSession()
                sess.start()
                with _AGY_LOGIN_LOCK:
                    _AGY_LOGIN_SESSIONS[sess.id] = sess
                # Wait (bounded) for the driver thread to capture the OAuth URL.
                import time as _t
                deadline = _t.time() + 30
                while _t.time() < deadline:
                    with _AGY_LOGIN_LOCK:
                        url = sess.login_url
                        state = sess.state
                    if url or state == 'failed':
                        break
                    _t.sleep(0.4)
                with _AGY_LOGIN_LOCK:
                    url = sess.login_url
                    state = sess.state
                    detail = sess.detail
                if not url:
                    # Couldn't capture the URL in time — tear down, report clearly.
                    sess.teardown()
                    _AGY_LOGIN_SESSIONS.pop(sess.id, None)
                    self._json(200, {'ok': False, 'session_id': None,
                                     'error': detail or 'agy did not print a login URL '
                                              '(TUI may have changed)'})
                    return
                print('[connect] login/start session=%s url_captured=%s'
                      % (sess.id, url[:60]), file=sys.stderr, flush=True)
                self._json(200, {'ok': True, 'session_id': sess.id,
                                 'login_url': url, 'state': 'awaiting_browser'})
            except Exception as e:
                self._json(500, {'ok': False, 'error': str(e)})
            return

        # ── Guided Connection Wizard: SUBMIT the OAuth code ──────────────────
        # After the browser login, antigravity's OAuth returns a one-time CODE
        # (redirect_uri=antigravity.google/oauth-callback). agy waits for it on
        # the PTY prompt ("paste the authorization code below"). This writes that
        # code into the live session's PTY stdin + Enter; the driver then detects
        # success (auth flips) or a rejected code, surfaced via /login/status.
        # Body: {session_id, code}.
        if self.path == '/api/connect/antigravity/login/submit-code':
            try:
                body = self._read_body() or {}
                sid = (body.get('session_id') or '').strip()
                code = (body.get('code') or '').strip()
                if not sid:
                    self._json(400, {'ok': False, 'error': 'session_id відсутній'})
                    return
                if not code:
                    self._json(400, {'ok': False,
                                     'error': 'Порожній код. Скопіюй код з браузера і встав ще раз.'})
                    return
                _agy_login_gc()
                sess = _AGY_LOGIN_SESSIONS.get(sid)
                if not sess:
                    # GLOBAL-AUTH-FIRST: session gone, but the token may already be
                    # cached (login finished right as the session was reaped, or the
                    # server restarted). Check the keychain before telling the user
                    # to restart — if signed in, return success so the UI jumps to
                    # Connected; else a recovery signal that KEEPS the code onscreen.
                    try:
                        st = _agy_status()
                    except Exception:
                        st = {'logged_in': False}
                    if st.get('logged_in'):
                        self._json(200, {'ok': True, 'state': 'success',
                                         'account': st.get('account'),
                                         'detail': 'Вхід уже завершено. Підключаю…'})
                        return
                    self._json(404, {'ok': False, 'state': 'expired',
                                     'error': 'Сесія входу завершилась. '
                                              'Натисни «Почати заново».'})
                    return
                ok, msg = sess.submit_code(code)
                # ok=True → code written to PTY (or PTY was dead but global auth was
                # already OK → submit_code flipped success). The client keeps polling
                # /login/status which resolves to success or a retryable code_error.
                snap = sess.poll()   # cheap; surfaces an already-flipped success now
                self._json(200 if ok else 409, {'ok': ok, 'detail': msg,
                                                 'session_id': sid,
                                                 'state': snap.get('state')})
            except Exception as e:
                self._json(500, {'ok': False, 'error': str(e)})
            return

        # ── Guided Connection Wizard: LOGOUT / switch account ────────────────
        # Product feature: "Відключити / Змінити акаунт". Clears the agy Keychain
        # token via the same PTY `/logout` mechanism so the next login opens a
        # fresh browser OAuth. Any live login PTY sessions are torn down too.
        if self.path == '/api/connect/antigravity/logout':
            try:
                if not _AGY_BIN:
                    self._json(503, {'ok': False, 'error': 'agy CLI не встановлено'})
                    return
                # Kill any in-flight login PTYs first (they hold the TUI open).
                with _AGY_LOGIN_LOCK:
                    sids = list(_AGY_LOGIN_SESSIONS.keys())
                for sid in sids:
                    try:
                        _AGY_LOGIN_SESSIONS[sid].teardown()
                    except Exception:
                        pass
                    _AGY_LOGIN_SESSIONS.pop(sid, None)
                ok, detail = _agy_logout()
                print('[connect] logout ok=%s detail=%s' % (ok, detail),
                      file=sys.stderr, flush=True)
                self._json(200, {'ok': ok, 'detail': detail})
            except Exception as e:
                self._json(200, {'ok': False, 'error': str(e)})
            return

        if self.path == '/api/retell':
            # Turn a chat message into a friendly spoken RETELLING (пересказ) via a
            # cheap fast LLM (Gemini Flash → OpenAI fallback). Body: {"content": "..."}
            # where content is the message text OR its widget JSON stringified. The
            # frontend then feeds `retelling` into /api/voice for TTS. On total LLM
            # failure we return a clean non-500 error (ok:false) so the UI can revert
            # the button and show an inline error instead of hanging.
            try:
                body = self._read_body()
                content = body.get('content')
                if isinstance(content, (dict, list)):
                    content = json.dumps(content, ensure_ascii=False)
                content = (content or '').strip()
                if not content:
                    self._json(200, {'ok': False, 'error': 'empty',
                                     'hint': 'Нема тексту для переказу'})
                    return
                try:
                    retelling, engine = _generate_retelling(content)
                except Exception as e:
                    self._json(200, {'ok': False, 'error': 'llm_failed',
                                     'hint': 'Не вдалося згенерувати переказ (Gemini і OpenAI недоступні). Перевір ключі у Налаштуваннях.',
                                     'detail': str(e)[:300]})
                    return
                self._json(200, {'ok': True, 'retelling': retelling, 'engine': engine})
            except Exception as e:
                self._json(500, {'ok': False, 'error': str(e)})
            return
        if self.path == '/api/voice':
            # Synthesize Ukrainian voice and return MP3 url.
            # Body: {"text": "...", "engine": "openai" | "grok" | "lesya", "voice": "onyx"}
            # - openai (DEFAULT, Vova 2026-07-28): gpt-4o-mini-tts + voice `onyx`. Won the
            #   blind A/B on INTONATION: it pauses before the turns of an argument and
            #   before numbers, so Vova catches the meaning by ear without re-reading.
            #   The `instructions` field is what buys that (Grok has only crude tags).
            #   ~$0.90/hour of audio, i.e. $2-3/month more than Grok at Vova's volume,
            #   so price no longer decides. Fallback chain: openai -> grok -> lesya.
            # - grok: xAI /v1/tts, voice `sal`, cheap ($0.23/hour) but 12 kHz ceiling and
            #   no fine tone control. Now the middle rung of the chain, not the default.
            # - lesya: macOS `say`, instant, $0, robotic (last-resort).
            try:
                import subprocess, hashlib, urllib.request, urllib.error
                body = self._read_body()
                text = (body.get('text') or '').strip()
                engine = (body.get('engine') or 'openai').lower()
                # Per-engine default voice. ElevenLabs needs a real voice_id here, so a
                # single 'onyx'-for-everything default 404s that engine before it starts.
                voice = body.get('voice') or {
                    'grok': 'sal', 'openai': 'onyx', 'lesya': None,
                    'eleven': 'pFZP5JQG7iQjIQuC4Bku', 'elevenlabs': 'pFZP5JQG7iQjIQuC4Bku',
                }.get(engine, 'onyx')
                # Base instructions for gpt-4o-mini-tts, generalized from the exact prompt
                # that won the 2026-07-28 blind A/B. Deliberately IN ENGLISH: measured on
                # the same text, an English instruction moves the read (+29% duration on a
                # slow-down directive) while the Ukrainian translation of it barely does.
                # The job is meaning-by-ear, not drama: pauses at the turns of the argument
                # and stress on numbers. Theatrical emotion made earlier takes worse.
                instructions = body.get('instructions') or (
                    'Speak in Ukrainian as a calm business partner explaining things one on one '
                    'at a whiteboard. The listener must be able to follow the argument by ear '
                    'alone, without re-reading the text.\n'
                    'Rules: put clear stress on every number and on the word that carries the '
                    'contrast. Make a real pause before every turn in the argument and before a '
                    'conclusion, so the structure is audible. Say numbers slightly slower and very '
                    'distinctly. Let the sentence that changes the decision land, then drop the '
                    'tone on the final sentence.\n'
                    'Natural conversational pace, slightly slower than average. No announcer '
                    'voice, no theatrics, no artificial excitement.'
                )
                if not text:
                    self._json(400, {'ok': False, 'error': 'empty text'})
                    return
                # xAI has no `uk` in its 18 language codes, so `auto` (its own detector)
                # is the correct value for Ukrainian text. Sending `uk` risked a 400.
                language = (body.get('language') or 'auto')
                voice_dir = os.path.join(DIR, 'voice-cache')
                os.makedirs(voice_dir, exist_ok=True)

                # Cache key includes engine + voice so different settings produce different files.
                def _cache(eng, vc):
                    hh = hashlib.md5(f'{eng}:{vc}:{text}'.encode('utf-8')).hexdigest()[:12]
                    return hh, os.path.join(voice_dir, f'{hh}.mp3')

                # ElevenLabs renders the same voice_id very differently per model
                # (multilingual_v2 vs v3 vs turbo) and per voice_settings, so those belong
                # in the cache key or an A/B silently replays the first take. Salt is empty
                # for the other engines so their existing cache entries stay valid.
                def _salt(eng):
                    if eng == 'openai':
                        # Same reason as ElevenLabs: on gpt-4o-mini-tts the `instructions`
                        # change the read completely, so tone tweaks must not replay the
                        # first take from cache.
                        return ':' + (body.get('model') or 'gpt-4o-mini-tts') + ':' + \
                            hashlib.md5(instructions.encode('utf-8')).hexdigest()[:6]
                    if eng != 'eleven':
                        return ''
                    extra = json.dumps(body.get('voice_settings'), sort_keys=True) if body.get('voice_settings') else ''
                    return ':' + (body.get('model') or 'eleven_multilingual_v2') + (':' + extra if extra else '')

                # ---- per-engine synthesizers: (out_mp3, vc) -> (ok, err); writes mp3 on ok ----
                def _synth_lesya(out_mp3, vc=None):
                    if not os.path.exists('/usr/bin/say'):
                        return (False, 'lesya_unavailable (non-macOS)')
                    aiff_path = out_mp3[:-4] + '.aiff'
                    ffmpeg_bin = '/opt/homebrew/bin/ffmpeg' if os.path.exists('/opt/homebrew/bin/ffmpeg') else 'ffmpeg'
                    try:
                        subprocess.run(['/usr/bin/say', '-v', 'Lesya', '-o', aiff_path, text], check=True)
                        subprocess.run([ffmpeg_bin, '-y', '-loglevel', 'quiet', '-i', aiff_path, '-codec:a', 'libmp3lame', '-q:a', '4', out_mp3], check=True)
                    except Exception as e:
                        return (False, f'lesya_failed: {e}')
                    finally:
                        try: os.remove(aiff_path)
                        except: pass
                    return (True, None)

                def _synth_openai(out_mp3, vc):
                    api_key = _load_openai_key()
                    if not api_key:
                        return (False, 'no_openai_key')
                    # gpt-4o-mini-tts (Vova 2026-07-28 A/B winner): the only OpenAI TTS
                    # model that honours `instructions`, which is exactly what won it.
                    openai_model = body.get('model') or 'gpt-4o-mini-tts'
                    payload_dict = {'model': openai_model, 'input': text, 'voice': vc or 'onyx', 'response_format': 'mp3'}
                    if openai_model == 'gpt-4o-mini-tts':
                        payload_dict['instructions'] = instructions
                    req = urllib.request.Request(
                        'https://api.openai.com/v1/audio/speech',
                        data=json.dumps(payload_dict).encode('utf-8'),
                        headers={'Authorization': f'Bearer {api_key}', 'Content-Type': 'application/json'},
                        method='POST')
                    try:
                        with urllib.request.urlopen(req, timeout=120) as r2:
                            data = r2.read()
                    except urllib.error.HTTPError as e:
                        return (False, f'OpenAI HTTP {e.code}: ' + e.read().decode('utf-8', errors='replace')[:300])
                    except Exception as e:
                        return (False, f'OpenAI request failed: {e}')
                    with open(out_mp3, 'wb') as out:
                        out.write(data)
                    return (True, None)

                def _synth_grok(out_mp3, vc):
                    key = _load_xai_key()
                    if not key:
                        return (False, 'no_xai_key')
                    payload = json.dumps({'model': 'grok-tts', 'voice': vc or 'sal',
                                          'text': text, 'language': language}).encode('utf-8')
                    req = urllib.request.Request(
                        'https://api.x.ai/v1/tts', data=payload,
                        headers={'Authorization': f'Bearer {key}', 'Content-Type': 'application/json'},
                        method='POST')
                    try:
                        with urllib.request.urlopen(req, timeout=120) as r2:
                            data = r2.read()
                    except urllib.error.HTTPError as e:
                        return (False, f'Grok HTTP {e.code}: ' + e.read().decode('utf-8', errors='replace')[:300])
                    except Exception as e:
                        return (False, f'Grok request failed: {e}')
                    # xAI returns raw audio bytes: validate MP3 frame-sync / ID3 / RIFF before caching.
                    if not (len(data) > 2 and ((data[0] == 0xFF and (data[1] & 0xE0) == 0xE0)
                                               or data[:3] == b'ID3' or data[:4] == b'RIFF')):
                        return (False, 'grok_not_audio: ' + repr(data[:80]))
                    with open(out_mp3, 'wb') as out:
                        out.write(data)
                    return (True, None)

                def _synth_eleven(out_mp3, vc):
                    # Opt-in only ({"engine":"eleven"}). Priciest per character of the four,
                    # so it never sits in another engine's fallback chain.
                    key = _load_eleven_key()
                    if not key:
                        return (False, 'no_elevenlabs_key')
                    model = body.get('model') or 'eleven_multilingual_v2'
                    # Settings tuned for Ukrainian on 2026-06-17 (see decisions/2026-06-17-tts-model-verdict.md).
                    vs = body.get('voice_settings') or {
                        'stability': 0.45, 'similarity_boost': 0.88, 'style': 0.35, 'use_speaker_boost': True}
                    payload = json.dumps({'text': text, 'model_id': model, 'voice_settings': vs}).encode('utf-8')
                    req = urllib.request.Request(
                        'https://api.elevenlabs.io/v1/text-to-speech/%s' % (vc or 'EXAVITQu4vr4xnSDxMaL'),
                        data=payload,
                        headers={'xi-api-key': key, 'Content-Type': 'application/json', 'Accept': 'audio/mpeg'},
                        method='POST')
                    try:
                        with urllib.request.urlopen(req, timeout=180) as r2:
                            data = r2.read()
                    except urllib.error.HTTPError as e:
                        return (False, f'ElevenLabs HTTP {e.code}: ' + e.read().decode('utf-8', errors='replace')[:300])
                    except Exception as e:
                        return (False, f'ElevenLabs request failed: {e}')
                    if not (len(data) > 2 and ((data[0] == 0xFF and (data[1] & 0xE0) == 0xE0)
                                               or data[:3] == b'ID3')):
                        return (False, 'eleven_not_audio: ' + repr(data[:120]))
                    with open(out_mp3, 'wb') as out:
                        out.write(data)
                    return (True, None)

                SYNTH = {'grok': _synth_grok, 'openai': _synth_openai, 'lesya': _synth_lesya,
                         'eleven': _synth_eleven}
                # Lily scored best on Ukrainian in the 2026-06-17 blind test.
                DEFVOICE = {'grok': 'sal', 'openai': 'onyx', 'lesya': None, 'eleven': 'pFZP5JQG7iQjIQuC4Bku'}

                # Ordered fallback chain by requested engine (Vova 2026-07-28: OpenAI onyx
                # is the default; each engine degrades to the next on failure, never a 500).
                # `openai` used to skip straight to the robotic Lesya, which turned one dead
                # OpenAI key into macOS `say` even though Grok was alive. Grok is the middle
                # rung now, so a paid-engine outage degrades to another paid engine first.
                if engine == 'openai':
                    chain = ['openai', 'grok', 'lesya']
                elif engine == 'grok':
                    chain = ['grok', 'openai', 'lesya']
                elif engine in ('eleven', 'elevenlabs'):
                    engine = 'eleven'
                    chain = ['eleven', 'grok', 'openai', 'lesya']
                else:
                    chain = ['lesya']

                used_engine = None; used_voice = None; h = None; fell_back = False; last_err = None
                for eng in chain:
                    vc = voice if eng == engine else DEFVOICE[eng]
                    hh, path_ = _cache(eng, (vc or '') + _salt(eng))
                    if os.path.exists(path_):
                        used_engine, used_voice, h, fell_back = eng, vc, hh, (eng != engine)
                        break
                    ok, err = SYNTH[eng](path_, vc)
                    if ok:
                        used_engine, used_voice, h, fell_back = eng, vc, hh, (eng != engine)
                        break
                    last_err = err
                    print(f'[voice] {eng} TTS failed: {err}', file=sys.stderr, flush=True)
                    try:
                        if os.path.exists(path_): os.remove(path_)
                    except: pass

                if used_engine is None:
                    self._json(200, {'ok': False, 'error': 'tts_failed',
                                     'hint': 'Жоден голосовий рушій не спрацював (Grok/OpenAI/Lesya). Перевір ключі у Налаштуваннях.',
                                     'detail': last_err})
                    return

                resp = {'ok': True, 'url': f'/voice-cache/{h}.mp3', 'engine': used_engine, 'voice': used_voice or ''}
                if fell_back:
                    resp['fell_back'] = True
                    resp['hint'] = f'Основний рушій ({engine}) не спрацював, озвучено через {used_engine}.'
                self._json(200, resp)
            except Exception as e:
                self._json(500, {'ok': False, 'error': str(e)})
            return
        if self.path == '/api/delete':
            try:
                body = self._read_body()
                channel = body.get('channel', 'main')
                msg_id = body.get('id')
                ch_dir, idx_path, items = self._channel_index(channel)
                target = next((i for i in items if i.get('id') == msg_id), None)
                items = [i for i in items if i.get('id') != msg_id]
                _atomic_write_json(idx_path, items)
                if target and target.get('file'):
                    fpath = os.path.join(ch_dir, target['file'])
                    if os.path.exists(fpath):
                        os.remove(fpath)
                self._json(200, {'ok': True, 'remaining': len(items)})
            except Exception as e:
                self._json(500, {'ok': False, 'error': str(e)})
            return
        if self.path == '/api/pin':
            try:
                body = self._read_body()
                channel = body.get('channel', 'main')
                msg_id = body.get('id')
                ch_dir, idx_path, items = self._channel_index(channel)
                pinned_now = None
                for i in items:
                    if i.get('id') == msg_id:
                        i['pinned'] = not i.get('pinned', False)
                        pinned_now = i['pinned']
                _atomic_write_json(idx_path, items)
                self._json(200, {'ok': True, 'pinned': pinned_now})
            except Exception as e:
                self._json(500, {'ok': False, 'error': str(e)})
            return
        if self.path == '/api/channel-create':
            try:
                body = self._read_body()
                label = body.get('label', '').strip()
                if not label:
                    raise ValueError('empty label')
                icon = body.get('icon', '💬')
                # derive a safe id from label
                import re as _re
                base = _re.sub(r'[^a-z0-9]+', '-', label.lower()).strip('-') or 'chat'
                reg_path = os.path.join(DIR, 'channels', 'index.json')
                reg = json.load(open(reg_path)) if os.path.exists(reg_path) else []
                cid = base
                n = 2
                while any(c.get('id') == cid for c in reg):
                    cid = f'{base}-{n}'; n += 1
                os.makedirs(os.path.join(DIR, 'channels', cid), exist_ok=True)
                reg.append({'id': cid, 'label': label, 'icon': icon})
                _atomic_write_json(reg_path, reg)
                self._json(200, {'ok': True, 'id': cid, 'label': label})
            except Exception as e:
                self._json(500, {'ok': False, 'error': str(e)})
            return
        if self.path == '/api/channel-hide':
            try:
                body = self._read_body()
                cid = body.get('id')
                hidden = bool(body.get('hidden', True))
                # The channel may live in the committed registry (index.json) OR in
                # this machine's local cc-* overlay (index.local.json). Update it
                # in whichever file actually contains it, so hiding/unhiding an auto
                # session channel persists (the UI lists the MERGED registry, so a
                # write that misses the overlay is silently reverted on the next poll).
                reg_path, reg = self._registry_for_channel(cid)
                if reg_path is None:
                    self._json(200, {'ok': True, 'id': cid, 'hidden': hidden,
                                     'found': False})
                    return
                for c in reg:
                    if c.get('id') == cid:
                        if hidden:
                            c['hidden'] = True
                        else:
                            c.pop('hidden', None)
                _atomic_write_json(reg_path, reg)
                self._json(200, {'ok': True, 'id': cid, 'hidden': hidden})
            except Exception as e:
                self._json(500, {'ok': False, 'error': str(e)})
            return
        # Toggle (or set) a CHANNEL's pinned flag. Mirrors /api/channel-hide: the
        # channel may live in the committed registry (index.json) or in this
        # machine's cc-* overlay (index.local.json); we write to whichever file
        # actually contains it so the merged registry (what the UI polls) sticks.
        # The mobile pinned-rail + «Обрані» sheet section key off this flag.
        if self.path == '/api/channel-pin':
            try:
                body = self._read_body()
                cid = body.get('id')
                reg_path, reg = self._registry_for_channel(cid)
                if reg_path is None:
                    self._json(200, {'ok': True, 'id': cid, 'pinned': None,
                                     'found': False})
                    return
                pinned_now = None
                for c in reg:
                    if c.get('id') == cid:
                        # explicit override if provided, else toggle
                        if 'pinned' in body:
                            pinned_now = bool(body.get('pinned'))
                        else:
                            pinned_now = not bool(c.get('pinned', False))
                        if pinned_now:
                            c['pinned'] = True
                        else:
                            c.pop('pinned', None)
                _atomic_write_json(reg_path, reg)
                self._json(200, {'ok': True, 'id': cid, 'pinned': pinned_now})
            except Exception as e:
                self._json(500, {'ok': False, 'error': str(e)})
            return
        # Pin / unpin a CANVAS PAGE. Body {id, name?, pinned?}: without `pinned` it
        # toggles, `name` refreshes the label stored with the pin. Answers with the FULL
        # new list, so the UI paints the rail without a second read.
        if self.path == '/api/canvas-pin':
            try:
                body = self._read_body()
                pid = (body.get('id') or '').strip()
                if not pid:
                    self._json(400, {'ok': False, 'error': 'missing id'})
                    return
                pins = _canvas_set_pin(pid, body.get('name'),
                                       body.get('pinned') if 'pinned' in body else None)
                self._json(200, {'ok': True, 'pins': pins})
            except Exception as e:
                self._json(500, {'ok': False, 'error': str(e)})
            return
        # Spawn a DETACHED background agent (Phase 2, Vova #0047-51): a separate
        # agent_worker.py process (own session/pgid) runs one `claude -p <task>` that
        # survives the main turn / a new message / a ChatView restart. Cap 4 concurrent
        # per channel (each detached agent = a separate billed claude session).
        if self.path == '/api/agent-spawn':
            try:
                import subprocess as _sp, secrets as _secrets, uuid as _uuid
                from datetime import datetime as _dt
                body = self._read_body()
                channel = (body.get('channel') or '').strip()
                task = (body.get('task') or '').strip()
                label = (body.get('label') or 'Агент').strip()
                model = body.get('model')
                if not channel or '/' in channel or '..' in channel:
                    raise ValueError('bad channel')
                if not task:
                    raise ValueError('empty task')
                agents_root = os.path.join(DIR, 'channels', channel, 'agents')
                AGENT_CAP = 4
                running = 0
                if os.path.isdir(agents_root):
                    for aid in os.listdir(agents_root):
                        try:
                            st = json.load(open(os.path.join(agents_root, aid, 'status.json'),
                                                encoding='utf-8'))
                            if st.get('state') in ('queued', 'running'):
                                running += 1
                        except Exception:
                            pass
                if running >= AGENT_CAP:
                    self._json(200, {'ok': False,
                                     'error': f'ліміт {AGENT_CAP} паралельних агентів досягнуто'})
                    return
                agent_id = _secrets.token_hex(3)
                a_dir = os.path.join(agents_root, agent_id)
                os.makedirs(a_dir, exist_ok=True)
                _atomic_write_json(os.path.join(a_dir, 'status.json'), {
                    'agentId': agent_id, 'label': label, 'task': task, 'model': model,
                    # claude --session-id must be a valid UUID (not agent-<hex>).
                    'sid': str(_uuid.uuid4()), 'state': 'queued', 'progressPct': 0,
                    'createdAt': _dt.now().isoformat()})
                # Спавн іде через гейт jobs.spawn: власна сесія + запис у реєстр,
                # тож воркер видно в /api/jobs і зупинити його можна тільки
                # через перевірки гейта, а не по голому pid.
                import jobs as _jobs
                job, err = _jobs.spawn('agent', {'channel': channel, 'agentId': agent_id},
                                       label=label, channel=channel)
                if err:
                    raise RuntimeError(err)
                if job:
                    st = json.load(open(os.path.join(a_dir, 'status.json'), encoding='utf-8'))
                    st['jobId'] = job['jobId']
                    _atomic_write_json(os.path.join(a_dir, 'status.json'), st)
                self._json(200, {'ok': True, 'agentId': agent_id,
                                 'jobId': (job or {}).get('jobId')})
            except Exception as e:
                self._json(500, {'ok': False, 'error': str(e)})
            return
        # Stop ONE agent: mark stopped (so the worker bails) + SIGTERM its claude pgid.
        # Only touches this agent's group — other agents + the main turn are untouched.
        if self.path == '/api/agent-stop':
            try:
                import signal as _signal
                from datetime import datetime as _dt
                body = self._read_body()
                channel = (body.get('channel') or '').strip()
                agent_id = (body.get('agentId') or '').strip()
                if ('/' in channel or '..' in channel or '/' in agent_id or '..' in agent_id):
                    raise ValueError('bad id')
                sp = os.path.join(DIR, 'channels', channel, 'agents', agent_id, 'status.json')
                st = json.load(open(sp, encoding='utf-8'))
                pid = st.get('pid')
                st['state'] = 'stopped'
                st['updatedAt'] = _dt.now().isoformat()
                _atomic_write_json(sp, st)
                # Основний шлях: обидва job-и через гейт (claude агента сидить у
                # СВОЇЙ групі, воркер у своїй, тож треба два стопи).
                import jobs as _jobs
                gated = []
                for key in ('claudeJobId', 'jobId'):
                    jid = st.get(key)
                    if jid:
                        gated.append(dict(_jobs.stop(jid), jobId=jid))
                if not gated and pid and sys.platform != 'win32':
                    # Запас для агентів, запущених до появи реєстру: pgid беремо
                    # ЖИВИЙ через гарду, а не записаний при спавні (той міг
                    # застаріти або вести в спільну групу).
                    pgid = _safe_pgid(pid)
                    try:
                        if pgid is not None:
                            os.killpg(pgid, _signal.SIGTERM)
                        else:
                            os.kill(int(pid), _signal.SIGTERM)
                    except Exception:
                        pass
                self._json(200, {'ok': True, 'agentId': agent_id, 'state': 'stopped',
                                 'gated': gated})
            except Exception as e:
                self._json(500, {'ok': False, 'error': str(e)})
            return
        # Запустити фоновий процес ЧЕРЕЗ ГЕЙТ. Тіло дає ТИП і параметри
        # ({kind, args, label, channel}), не команду: сервер слухає localhost, а
        # localhost це і будь-яка вкладка браузера, тож endpoint «виконай що
        # передали» був би дірою. Дозволені типи живуть у jobs.SPAWN_KINDS.
        if self.path == '/api/job-spawn':
            try:
                import jobs as _jobs
                body = self._read_body()
                kind = (body.get('kind') or '').strip()
                channel = (body.get('channel') or '').strip()
                if channel and ('/' in channel or '..' in channel):
                    raise ValueError('bad channel')
                job, err = _jobs.spawn(kind, body.get('args') or {},
                                       label=(body.get('label') or '').strip(),
                                       channel=channel)
                if err:
                    self._json(400, {'ok': False, 'error': err,
                                     'allowed': sorted(_jobs.SPAWN_KINDS)})
                    return
                self._json(200, {'ok': True, 'job': job})
            except Exception as e:
                self._json(500, {'ok': False, 'error': str(e)})
            return
        # Зупинити job з реєстру. Приймає jobId (НЕ pid): вбити можна лише те,
        # що ми самі запускали, і лише поки це той самий процес. Причина відмови
        # повертається в reason, щоб гейт не мовчав.
        if self.path == '/api/job-stop':
            try:
                import jobs as _jobs
                body = self._read_body()
                job_id = (body.get('jobId') or '').strip()
                channel = (body.get('channel') or '').strip()
                if job_id:
                    res = _jobs.stop(job_id)
                elif channel:
                    if '/' in channel or '..' in channel:
                        raise ValueError('bad channel')
                    res = {'ok': True, 'results': _jobs.stop_channel(channel)}
                else:
                    raise ValueError('need jobId or channel')
                self._json(200 if res.get('ok') else 400, res)
            except Exception as e:
                self._json(500, {'ok': False, 'error': str(e)})
            return
        if self.path == '/api/channel-rename':
            try:
                body = self._read_body()
                cid = body.get('id')
                new_label = body.get('label', '').strip()
                # `icon` is optional (Vova 2026-07-12: "зміни іконку і назву") — a plain
                # emoji string. Blank/missing leaves the current icon untouched, same as
                # label is required but icon is not.
                new_icon = (body.get('icon') or '').strip()
                if not new_label:
                    raise ValueError('empty label')
                # Same overlay-aware lookup as channel-hide: a cc-* tab renamed in
                # the UI must persist in index.local.json, not silently no-op.
                reg_path, reg = self._registry_for_channel(cid)
                if reg_path is None:
                    self._json(200, {'ok': True, 'label': new_label,
                                     'found': False})
                    return
                for c in reg:
                    if c.get('id') == cid:
                        c['label'] = new_label
                        if new_icon:
                            c['icon'] = new_icon
                        # Manual rename freezes the title: drop the autoNamed
                        # flag so the LLM auto-renamer never overwrites it.
                        c.pop('autoNamed', None)
                _atomic_write_json(reg_path, reg)
                self._json(200, {'ok': True, 'label': new_label, 'icon': new_icon or None})
            except Exception as e:
                self._json(500, {'ok': False, 'error': str(e)})
            return
        if self.path == '/api/channel-delete':
            # PERMANENT delete of a channel (from the Archive panel trash button).
            # Unlike /api/channel-hide (which only flips a flag) this:
            #   1) removes the entry from whichever registry actually holds it
            #      (committed index.json OR local cc-* overlay index.local.json),
            #   2) rm -rf the channel dir channels/<id>/ (messages, plan, settings),
            #   3) prunes any channels/.cc-sessions.json mapping entry pointing to it
            #      so a future native session does not "resurrect" the same tab.
            import shutil
            try:
                body = self._read_body()
                cid = body.get('id')
                if not cid or '/' in cid or '..' in cid:
                    raise ValueError('bad channel')
                # 1) Remove from the owning registry (overlay-aware, same lookup
                #    used by channel-hide/rename). No-op gracefully if absent.
                reg_path, reg = self._registry_for_channel(cid)
                removed_from_registry = False
                if reg_path is not None:
                    new_reg = [c for c in reg
                               if not (isinstance(c, dict) and c.get('id') == cid)]
                    if len(new_reg) != len(reg):
                        removed_from_registry = True
                    _atomic_write_json(reg_path, new_reg)
                # 2) rm -rf the channel directory.
                ch_dir = os.path.join(DIR, 'channels', cid)
                dir_deleted = False
                if os.path.isdir(ch_dir):
                    shutil.rmtree(ch_dir, ignore_errors=True)
                    dir_deleted = not os.path.exists(ch_dir)
                # 3) Prune the .cc-sessions.json session->channel mapping.
                map_path = os.path.join(DIR, 'channels', '.cc-sessions.json')
                mapping_pruned = 0
                if os.path.exists(map_path):
                    try:
                        with open(map_path, encoding='utf-8') as f:
                            cmap = json.load(f)
                    except Exception:
                        cmap = None
                    if isinstance(cmap, dict):
                        before = len(cmap)
                        cmap = {k: v for k, v in cmap.items() if v != cid}
                        mapping_pruned = before - len(cmap)
                        if mapping_pruned:
                            _atomic_write_json(map_path, cmap)
                self._json(200, {'ok': True, 'id': cid,
                                 'removedFromRegistry': removed_from_registry,
                                 'dirDeleted': dir_deleted,
                                 'mappingPruned': mapping_pruned})
            except Exception as e:
                self._json(500, {'ok': False, 'error': str(e)})
            return
        if self.path == '/api/pull-context':
            # REVERSE handoff trigger (OPT-IN). Seed this channel's NEXT runner
            # turn with the full context of the terminal Claude session bound to
            # it. Reverse-lookup .cc-sessions.json (key whose value === channel)
            # for the owning terminal session id, rotate the channel runner
            # session to a fresh uuid (so the fork seeds cleanly on the next
            # turn), and drop a one-shot channels/<id>/seed-from marker that
            # runner.py consumes.
            try:
                import uuid
                body = self._read_body()
                channel = body.get('channel', '')
                if not channel or '/' in channel or '..' in channel:
                    raise ValueError('bad channel')
                map_path = os.path.join(DIR, 'channels', '.cc-sessions.json')
                term_id = None
                if os.path.exists(map_path):
                    try:
                        with open(map_path, encoding='utf-8') as f:
                            cmap = json.load(f)
                    except Exception:
                        cmap = None
                    if isinstance(cmap, dict):
                        for k, v in cmap.items():
                            if v == channel:
                                term_id = k
                                break
                if not term_id:
                    self._json(200, {'ok': False,
                                     'error': 'no bound terminal session'})
                    return
                # rotate the channel runner session id to a fresh uuid so the
                # fork seed applies on the next turn (reuses _channel_session_id
                # write pattern: channels/<id>/session-id one line).
                ch_dir = os.path.join(DIR, 'channels', channel)
                os.makedirs(ch_dir, exist_ok=True)
                new_sid = str(uuid.uuid4())
                with open(os.path.join(ch_dir, 'session-id'), 'w') as f:
                    f.write(new_sid + '\n')
                # one-shot seed marker holding the terminal session id.
                with open(os.path.join(ch_dir, 'seed-from'), 'w') as f:
                    f.write(term_id)
                self._json(200, {'ok': True, 'termId': term_id,
                                 'channel': channel})
            except Exception as e:
                self._json(500, {'ok': False, 'error': str(e)})
            return
        if self.path == '/api/settings':
            try:
                body = self._read_body()
                channel = body.get('channel', 'main')
                text = body.get('text', '')
                if '/' in channel or '..' in channel:
                    raise ValueError('bad channel')
                ch_dir = os.path.join(DIR, 'channels', channel)
                os.makedirs(ch_dir, exist_ok=True)
                with open(os.path.join(ch_dir, 'instructions.md'), 'w') as f:
                    f.write(text)
                self._json(200, {'ok': True, 'len': len(text)})
            except Exception as e:
                self._json(500, {'ok': False, 'error': str(e)})
            return

        # Desk Mode toggle. body {"action":"on"|"off","tailscale":bool(default true)}.
        #   ON : bring Tailscale up (unless tailscale:false) + ensure caffeinate +
        #        write flag "1" (the root daemon, if installed, flips disablesleep).
        #   OFF: write flag "0" + kill caffeinate, REPLY FIRST, then drop the tunnel
        #        deferred (so an iPad client on the tunnel still gets this response).
        if self.path == '/api/desk-mode':
            # Hard security gate (defense in depth): even if a client hits this POST
            # directly, a distributed build (REMOTE_ACCESS off) refuses to bring up any
            # tunnel. The UI hide is cosmetic; THIS is what actually protects users.
            if not REMOTE_ACCESS:
                self._json(403, {'ok': False, 'error': 'remote access disabled'})
                return
            try:
                body = self._read_body()
                action = (body.get('action') or '').strip().lower()
                use_ts = body.get('tailscale', True) is not False
                if action == 'on':
                    if use_ts:
                        _dm_run([_TAILSCALE_BIN, 'up'], timeout=30)
                    _dm_start_caffeinate()
                    _dm_write_flag('1')
                    self._json(200, {
                        'ok': True, 'action': 'on',
                        'tailscale': _dm_tailscale_state() if use_ts else 'skipped',
                        'caffeinate': _dm_caffeinate_running(),
                        'flag': _dm_read_flag(),
                        'helper_installed': _dm_helper_installed(),
                        'chatview_url': _dm_chatview_url(),
                    })
                    return
                if action == 'off':
                    _dm_write_flag('0')
                    _dm_stop_caffeinate()
                    self._json(200, {
                        'ok': True, 'action': 'off',
                        'tailscale': 'stopping' if use_ts else 'skipped',
                        'caffeinate': _dm_caffeinate_running(),
                        'flag': _dm_read_flag(),
                    })
                    # Push the reply out BEFORE tailscale down so the iPad client
                    # (which may be on this very tunnel) receives it first.
                    try:
                        self.wfile.flush()
                    except Exception:
                        pass
                    if use_ts:
                        def _deferred_down():
                            time.sleep(1.5)
                            _dm_run([_TAILSCALE_BIN, 'down'], timeout=30)
                        threading.Thread(target=_deferred_down, daemon=True).start()
                    return
                self._json(400, {'ok': False, 'error': 'action must be on|off'})
            except Exception as e:
                self._json(500, {'ok': False, 'error': str(e)})
            return

        # Helpers (Skill Store) — install a catalog skill into .claude/skills.
        if self.path == '/api/helpers/install':
            try:
                import shutil as _shutil
                body = self._read_body()
                sid = body.get('id')
                target = _helpers_safe_target(sid)  # validates id + traversal
                manifest = _helpers_manifest()
                skill = next((s for s in manifest.get('skills', [])
                              if s.get('id') == sid), None)
                if skill is None:
                    self._json(404, {'ok': False, 'error': 'unknown helper'})
                    return
                src = os.path.join(_HELPERS_LIBRARY_DIR, skill.get('path', sid))
                bundled = bool(skill.get('bundled'))
                if bundled and os.path.isdir(target):
                    # Real bundle already lives at the target — do NOT overwrite.
                    self._json(200, {'ok': True, 'installed': True,
                                     'note': 'bundled'})
                    return
                # Remote catalog entry (external repo, no local folder to copy).
                # Single-file GitHub skills are fetched raw; folder/npx installs
                # stay soft-failed with guidance (see _helpers_git_install).
                if not os.path.isdir(src) and skill.get('url'):
                    res = _helpers_git_install(skill, target)
                    if res.get('ok'):
                        _helpers_ensure_skill_md(target, skill)
                    self._json(200, res)
                    return
                # Copy the catalog folder (best effort for bundled w/o target).
                _shutil.copytree(src, target, dirs_exist_ok=True)
                self._json(200, {'ok': True, 'installed': True})
            except ValueError as ve:
                self._json(400, {'ok': False, 'error': str(ve)})
            except Exception as e:
                self._json(500, {'ok': False, 'error': str(e)})
            return

        # Helpers (Skill Store) — uninstall (protects bundled skills).
        if self.path == '/api/helpers/uninstall':
            try:
                import shutil as _shutil
                body = self._read_body()
                sid = body.get('id')
                target = _helpers_safe_target(sid)  # validates id + traversal
                manifest = _helpers_manifest()
                skill = next((s for s in manifest.get('skills', [])
                              if s.get('id') == sid), None)
                if skill is None:
                    self._json(404, {'ok': False, 'error': 'unknown helper'})
                    return
                if skill.get('bundled'):
                    self._json(200, {'ok': False,
                                     'error': 'Цей помічник вбудований і не видаляється'})
                    return
                if os.path.isdir(target):
                    _shutil.rmtree(target)
                self._json(200, {'ok': True, 'installed': False})
            except ValueError as ve:
                self._json(400, {'ok': False, 'error': str(ve)})
            except Exception as e:
                self._json(500, {'ok': False, 'error': str(e)})
            return

        if self.path == '/api/personas/toggle':
            # Помічники: enable/disable one capability of one persona.
            try:
                body = self._read_body()
                pid = body.get('personaId')
                cid = body.get('capId')
                on = bool(body.get('on'))
                state = _personas_state()
                persona = _personas_find(pid, state)
                if persona is None:
                    self._json(404, {'ok': False, 'error': 'unknown persona'})
                    return
                cap = next((c for c in persona.get('capabilities', [])
                            if c.get('id') == cid), None)
                if cap is None:
                    self._json(404, {'ok': False, 'error': 'unknown capability'})
                    return
                caps_state = state.get('caps')
                if not isinstance(caps_state, dict):
                    caps_state = {}
                pst = caps_state.get(pid)
                if not isinstance(pst, dict):
                    # First touch: seed from popular defaults so untouched caps keep theirs.
                    pst = {c['id']: bool(c.get('popular'))
                           for c in persona.get('capabilities', [])}
                pst[cid] = on
                caps_state[pid] = pst
                state['caps'] = caps_state
                _personas_state_save(state)
                active = sum(1 for c in persona.get('capabilities', [])
                             if pst.get(c['id']))
                self._json(200, {'ok': True, 'on': on, 'activeCount': active})
            except Exception as e:
                self._json(500, {'ok': False, 'error': str(e)})
            return

        if self.path == '/api/personas/team':
            # Add / remove a persona from the user's team (membership).
            try:
                body = self._read_body()
                pid = body.get('personaId')
                in_team = bool(body.get('inTeam'))
                state = _personas_state()
                if _personas_find(pid, state) is None:
                    self._json(404, {'ok': False, 'error': 'unknown persona'})
                    return
                team = state.get('_team')
                if not isinstance(team, list):
                    team = []
                if in_team and pid not in team:
                    team.append(pid)
                elif not in_team:
                    team = [x for x in team if x != pid]
                state['_team'] = team
                _personas_state_save(state)
                self._json(200, {'ok': True, 'inTeam': in_team, 'teamCount': len(team)})
            except Exception as e:
                self._json(500, {'ok': False, 'error': str(e)})
            return

        if self.path == '/api/personas/onboard':
            # Finish the wizard: set the role's default team + record source.
            try:
                body = self._read_body()
                role = body.get('role')
                source = body.get('source')
                onb = _personas_onboarding()
                role_def = next((r for r in onb.get('roles', [])
                                 if r.get('key') == role), None)
                state = _personas_state()
                team = list(state.get('_team') or []) if isinstance(state.get('_team'), list) else []
                added = []
                if role_def:
                    for pid in role_def.get('team', []):
                        if pid not in team:
                            team.append(pid)
                            added.append(pid)
                state['_team'] = team
                state['_onboarded'] = True
                if source:
                    state['_source'] = source
                _personas_state_save(state)
                self._json(200, {'ok': True, 'team': team, 'added': added,
                                 'role': role, 'source': source})
            except Exception as e:
                self._json(500, {'ok': False, 'error': str(e)})
            return

        if self.path == '/api/personas/create-custom':
            # Custom помічник from a free-text description: an LLM assembles a
            # persona (name / role / human-named capabilities) -> saved + added to team.
            try:
                import urllib.request  # do_POST has a local urllib import elsewhere
                import urllib.error
                body = self._read_body()
                desc = (body.get('description') or '').strip()
                if len(desc) < 4:
                    self._json(400, {'ok': False, 'error': 'опис закороткий'})
                    return
                CATS = ['marketing', 'sales', 'content', 'business', 'research',
                        'tech', 'productivity', 'learning', 'life']
                ICONS = ['rocket', 'megaphone', 'film', 'code', 'trending-up', 'users',
                         'search', 'pen', 'palette', 'target', 'mail', 'book', 'flask',
                         'bot', 'chef-hat', 'dumbbell', 'plane', 'heart', 'calculator',
                         'globe', 'mic', 'camera', 'lightbulb', 'shopping-cart']
                # The bot's look is driven by avatarParams. We let the LLM pick the
                # vibe from a CLOSED set of valid bottts options (anything else is
                # dropped by _bot_params_sanitize and refilled from the category
                # preset), and a free hex colour.
                EYES = _BOTTTS_OPTS['eyes']
                TOP = _BOTTTS_OPTS['top']
                TEX = _BOTTTS_OPTS['texture']
                MOU = _BOTTTS_OPTS['mouth']
                key = _openai_key()
                gen = None
                used_ai = False
                if key:
                    try:
                        sysmsg = (
                            'Ти конструюєш AI-помічника під опис користувача. Поверни СТРОГО JSON-обʼєкт '
                            'українською без markdown: {"name": коротка людська назва ролі (до 4 слів), '
                            '"oneliner": одне речення що він робить, "cat": одне з [' + ', '.join(CATS) + '], '
                            '"icon": одне з [' + ', '.join(ICONS) + '], "capabilities": масив 3-5 елементів '
                            '{"name": людська назва вміння, "desc": коротко що дає (до 9 слів), "popular": '
                            'true для 2 головних}, "avatarParams": вигляд робота-чудіка ПІД РОЛЬ '
                            '{"baseColor": hex-колір 6 символів без решітки, '
                            '"eyes": 1-2 з [' + ', '.join(EYES) + '], "top": 1-2 з [' + ', '.join(TOP) + '], '
                            '"texture": 1-2 з [' + ', '.join(TEX) + '], "mouth": 1-2 з [' + ', '.join(MOU) + ']}}. '
                            'СПОЧАТКУ визнач АРХЕТИП ролі з опису, тоді СВІДОМО (не випадково) добери baseColor '
                            'І характер (очі/верх/текстура/рот) під цей архетип так, щоб чудік ВІЗУАЛЬНО читався '
                            'як ця роль. Орієнтири архетипів: '
                            'аналітик/дослідник/фінанси -> baseColor 2563eb (синій), eyes sensor/roundFrame01/robocop, '
                            'top radar/antenna/pyramid, texture circuits, mouth diagram/grill01; '
                            'дизайн/контент/копірайтинг/креатив -> baseColor a855f7 (фіолет), eyes hearts/eva/roundFrame02, '
                            'top glowingBulb01/glowingBulb02/bulb01, texture grunge01, mouth smile02/bite; '
                            'маркетинг/SMM/реклама -> baseColor f97316 (помаранч), eyes glow/happy/shade01, '
                            'top antenna/lights, texture dots, mouth smile01/smile02; '
                            'продажі/клієнти -> baseColor 22c55e (зелений), eyes happy/bulging/glow, '
                            'top lights/antenna, mouth smile01/smile02 (теплий); '
                            'розробка/тех -> baseColor 10b981 (зелений), eyes frame1/frame2/eva, '
                            'top antennaCrooked/antenna, texture circuits, mouth diagram/grill03; '
                            'стратегія/бізнес -> baseColor 6366f1 (індиго), eyes robocop/shade01/sensor, '
                            'top horns/pyramid/radar, texture circuits, mouth grill02/square01. '
                            'Назви ЛЮДСЬКІ, прості, БЕЗ тех-жаргону.')
                        payload = json.dumps({
                            'model': 'gpt-4o-mini',
                            'messages': [{'role': 'system', 'content': sysmsg},
                                         {'role': 'user', 'content': desc}],
                            'response_format': {'type': 'json_object'},
                            'temperature': 0.5,
                        }).encode('utf-8')
                        req = urllib.request.Request(
                            'https://api.openai.com/v1/chat/completions', data=payload,
                            headers={'Authorization': f'Bearer {key}',
                                     'Content-Type': 'application/json'}, method='POST')
                        with urllib.request.urlopen(req, timeout=60) as r:
                            resp = json.loads(r.read())
                        gen = json.loads(resp['choices'][0]['message']['content'])
                        used_ai = True
                    except Exception:
                        gen = None  # any AI failure -> keyword fallback below
                if not isinstance(gen, dict):
                    # No key, or the call failed: assemble a minimal persona from
                    # the raw description + keyword-matched category preset.
                    fb_catname = next((c for c, kws in _BOT_KEYWORDS
                                       if any(k in (desc or '').lower() for k in kws)),
                                      'productivity')
                    gen = {
                        'name': 'Мій помічник',
                        'oneliner': desc[:110],
                        'cat': fb_catname,
                        'icon': 'bot',
                        'capabilities': [
                            {'name': 'Виконує задачу', 'desc': desc[:60], 'popular': True},
                            {'name': 'Пише і оформлює результат', 'desc': 'готовий текст або файл', 'popular': True},
                            {'name': 'Підказує наступний крок', 'desc': 'що робити далі', 'popular': False},
                        ],
                    }
                state = _personas_state()
                custom = _personas_custom(state)
                cid = 'custom-' + str(len(custom) + 1)
                caps = []
                for i, c in enumerate((gen.get('capabilities') or [])[:6]):
                    caps.append({'id': cid + '-' + str(i),
                                 'name': str(c.get('name', ''))[:60],
                                 'desc': str(c.get('desc', ''))[:120],
                                 'popular': bool(c.get('popular'))})
                final_cat = gen.get('cat') if gen.get('cat') in CATS else \
                    next((c for c, kws in _BOT_KEYWORDS
                          if any(k in (desc or '').lower() for k in kws)), 'productivity')
                # Force avatarParams valid: keep only known bottts option names,
                # refill any missing field from the category preset. ALWAYS valid.
                avatar_params = _bot_params_sanitize(gen.get('avatarParams'), desc, final_cat)
                newp = {
                    'id': cid,
                    'cat': final_cat,
                    'icon': gen.get('icon') if gen.get('icon') in ICONS else 'bot',
                    'name': str(gen.get('name') or 'Мій помічник')[:40],
                    'oneliner': str(gen.get('oneliner') or '')[:110],
                    'custom': True,
                    'capabilities': caps,
                    'avatarParams': avatar_params,
                    'avatarSeed': cid,  # base seed; the 🎲 reroll bumps it client-side
                }
                custom.append(newp)
                state['_custom'] = custom
                team = state.get('_team') if isinstance(state.get('_team'), list) else []
                if cid not in team:
                    team.append(cid)
                state['_team'] = team
                _personas_state_save(state)
                self._json(200, {'ok': True, 'persona': newp, 'aiUsed': used_ai})
            except Exception as e:
                self._json(500, {'ok': False, 'error': str(e)})
            return

        if self.path == '/api/channel-config':
            # Stage 4: per-channel model + permission mode. Vova flips these in
            # the UI. We persist BOTH:
            #   channels/<id>/model        (one line: opus|sonnet|haiku or full id)
            #   channels/<id>/permission   (one line: acceptEdits | plan)
            # which the runner reads, AND mirror them into channels/index.json so
            # the UI can render the current state without an extra read. Only the
            # provided field(s) are touched (partial update).
            # Model allowlist is VERSION-FREE on purpose: we accept the three
            # human aliases (opus/sonnet/haiku/fable) + 'auto'. The CLI resolves each
            # alias to the NEWEST release, so nothing here goes stale. A full id
            # (claude-<opus|sonnet|haiku|fable>-<anything>) is also accepted via the
            # pattern below, so a future model needs zero code edits. Fable (Геній,
            # flagship — above Opus) added Vova 2026-07-12. See runner.MODEL_ALIASES.
            VALID_MODEL_ALIASES = {'opus', 'sonnet', 'haiku', 'fable', 'auto'}
            FULL_ID_RE = _re_helpers.compile(r'^claude-(opus|sonnet|haiku|fable)-')

            def _model_ok(m):
                return m in VALID_MODEL_ALIASES or bool(FULL_ID_RE.match(m))
            VALID_PERMS = {'acceptEdits', 'plan'}
            # 'ultra' = our sixth pill (xhigh + the CLI's session-scoped ultracode mode).
            # Stored like any other level; engine_sdk resolves it to xhigh + settings.
            VALID_EFFORTS = {'low', 'medium', 'high', 'xhigh', 'max', 'ultra'}
            try:
                body = self._read_body()
                channel = body.get('channel', 'main')
                if '/' in channel or '..' in channel:
                    raise ValueError('bad channel')
                ch_dir = os.path.join(DIR, 'channels', channel)
                os.makedirs(ch_dir, exist_ok=True)
                model = body.get('model')
                perm = body.get('permission')
                eff = body.get('effort')
                restored_effort = None  # effort the incoming model remembers (model switch)
                # --- effort explicitly changed: persist active effort AND remember it
                # under the channel's CURRENT model family, so a later switch restores it.
                if eff is not None:
                    eff = str(eff).strip().lower()
                    if eff and eff not in VALID_EFFORTS:
                        raise ValueError(f'bad effort: {eff}')
                    with open(os.path.join(ch_dir, 'effort'), 'w') as f:
                        f.write(eff + '\n')
                    cur_model = model if model is not None else _read_channel_file(ch_dir, 'model')
                    fam = _effort_family(cur_model)
                    if eff and fam not in _EFFORT_NO_SUPPORT:
                        emap = _effort_map_read(ch_dir)
                        emap[fam] = eff
                        _effort_map_write(ch_dir, emap)
                    # «Зробити дефолтом для нових чатів»: same POST, extra flag. Writes
                    # BOTH the family key (so Opus keeps its own level) and '*' (so a
                    # brand-new channel on any model inherits something Vova chose).
                    if eff and body.get('makeDefault'):
                        dmap = _default_effort_read()
                        if fam not in _EFFORT_NO_SUPPORT:
                            dmap[fam] = eff
                        dmap['*'] = eff
                        _default_effort_write(dmap)
                # --- model switch: record the OUTGOING model's effort, then restore the
                # INCOMING model's remembered effort into the active file (per-model memory).
                if model is not None:
                    model = str(model).strip()
                    if not _model_ok(model):
                        raise ValueError(f'bad model: {model}')
                    old_model = _read_channel_file(ch_dir, 'model')
                    cur_effort = _read_channel_file(ch_dir, 'effort').lower()
                    old_fam = _effort_family(old_model) if old_model else None
                    new_fam = _effort_family(model)
                    emap = _effort_map_read(ch_dir)
                    # 1) remember where we are leaving from (so coming back restores it)
                    if (old_fam and old_fam != new_fam and old_fam not in _EFFORT_NO_SUPPORT
                            and cur_effort in _EFFORT_VALID):
                        emap[old_fam] = cur_effort
                    # 2) write the new model
                    with open(os.path.join(ch_dir, 'model'), 'w') as f:
                        f.write(model + '\n')
                    # 2b) model actually CHANGED -> evict this channel's WARM claude so the
                    # next turn cold-respawns with the new --model. Conversation is preserved
                    # (--resume from the session .jsonl, see runner.recycle_channel). Without
                    # this the warm engine keeps the OLD model and the picker is a silent
                    # no-op in an active chat. Same 'recycle' marker /api/engine-restart drops;
                    # runner.poll_once consumes it before the next turn.
                    if (old_model or '').strip() != model:
                        open(os.path.join(ch_dir, 'recycle'), 'w').close()
                    # 3) restore the incoming model's remembered effort (or seed it from
                    # the current value the first time we ever see this model).
                    if new_fam not in _EFFORT_NO_SUPPORT:
                        remembered = emap.get(new_fam)
                        if remembered in _EFFORT_VALID:
                            restored_effort = remembered
                        elif cur_effort in _EFFORT_VALID:
                            emap[new_fam] = cur_effort   # seed baseline
                            restored_effort = cur_effort
                        if restored_effort:
                            with open(os.path.join(ch_dir, 'effort'), 'w') as f:
                                f.write(restored_effort + '\n')
                    _effort_map_write(ch_dir, emap)
                if perm is not None:
                    perm = str(perm).strip()
                    if perm not in VALID_PERMS:
                        raise ValueError(f'bad permission: {perm}')
                    with open(os.path.join(ch_dir, 'permission'), 'w') as f:
                        f.write(perm + '\n')
                # mirror into the registry so the front end sees current values
                reg_path = os.path.join(DIR, 'channels', 'index.json')
                reg = json.load(open(reg_path)) if os.path.exists(reg_path) else []
                for c in reg:
                    if c.get('id') == channel:
                        if model is not None:
                            c['model'] = model
                        if perm is not None:
                            c['permission'] = perm
                _atomic_write_json(reg_path, reg)
                self._json(200, {'ok': True, 'channel': channel,
                                 'model': model, 'permission': perm,
                                 'effort': restored_effort})
            except Exception as e:
                self._json(500, {'ok': False, 'error': str(e)})
            return
        # Phase B perm gate: the PreToolUse hook asks permission for a tool call.
        if self.path == '/api/perm-request':
            try:
                body = self._read_body()
                rid = body.get('requestId')
                channel = body.get('channel', '')
                if not rid or '/' in channel or '..' in channel:
                    raise ValueError('bad request')
                with _perm_lock:
                    _perm[rid] = {'channel': channel, 'tool': body.get('tool', ''),
                                  'input': body.get('input'), 'decision': None}
                ch_dir = os.path.join(DIR, 'channels', channel)
                os.makedirs(ch_dir, exist_ok=True)
                with open(os.path.join(ch_dir, 'perm-pending.json'), 'w') as f:
                    json.dump({'requestId': rid, 'tool': body.get('tool', ''),
                               'input': body.get('input')}, f, ensure_ascii=False)
                self._json(200, {'ok': True})
            except Exception as e:
                self._json(500, {'ok': False, 'error': str(e)})
            return

        # Phase B perm gate: the UI card sends the user's decision here.
        if self.path == '/api/perm-decide':
            try:
                body = self._read_body()
                rid = body.get('requestId')
                decision = body.get('decision')   # allow | session | deny
                channel = ''
                with _perm_lock:
                    entry = _perm.get(rid)
                    if entry is not None:
                        entry['decision'] = decision
                        channel = entry.get('channel', '')
                if not channel:
                    channel = body.get('channel', '')
                if channel and '/' not in channel and '..' not in channel:
                    try:
                        os.remove(os.path.join(DIR, 'channels', channel, 'perm-pending.json'))
                    except OSError:
                        pass
                self._json(200, {'ok': True})
            except Exception as e:
                self._json(500, {'ok': False, 'error': str(e)})
            return

        if self.path == '/api/stop':
            # Kill-switch: abort the runner's in-flight claude turn for a channel
            # and clear its queue so nothing else runs. Reads channels/<id>/pid
            # (written by runner.py around its Popen). Signals the process GROUP
            # (claude is started with start_new_session=True, i.e. its own pgid)
            # so claude AND its child subprocesses die: SIGTERM, then SIGKILL ~0.5s
            # later if still alive. Then clears queue/busy/live/pid so the runner
            # exits its turn quietly and never re-drains the emptied queue.
            try:
                import signal as _signal
                import time as _time
                import glob as _glob
                body = self._read_body()
                channel = body.get('channel', 'main')
                if '/' in channel or '..' in channel:
                    raise ValueError('bad channel')
                ch_dir = os.path.join(DIR, 'channels', channel)
                pid_file = os.path.join(ch_dir, 'pid')

                # ORDER MATTERS. Clear the queue + busy + live FIRST, while the
                # turn is still alive. This closes the race where the runner's
                # turn dies, its worker frees up, and the poller re-spawns a new
                # worker that re-drains a not-yet-cleared queue (observed bug:
                # a second `claude stream (resume)` fired the same second as the
                # stop). With the queue gone and busy removed before the kill,
                # there is nothing left to re-pick.
                cleared = 0
                # Bubbles whose turn dies here. The queue job carries the id of
                # the user bubble that produced it (user_msg_id, written by
                # /api/send), and the RUNNING item's file stays on disk until its
                # turn ends — so this one sweep catches both the in-flight prompt
                # and everything still waiting behind it. Read before unlink.
                stopped_ids = []
                q_dir = os.path.join(ch_dir, 'queue')
                if os.path.isdir(q_dir):
                    for qf in _glob.glob(os.path.join(q_dir, '*.json')):
                        try:
                            with open(qf, encoding='utf-8') as jf:
                                stopped_ids.append((json.load(jf) or {}).get('user_msg_id'))
                        except Exception:
                            pass
                        try:
                            os.remove(qf)
                            cleared += 1
                        except OSError:
                            pass
                # busy gone = runner's per-item guard sees "stopped" and bails.
                for fn in ('busy', 'live.json', 'live.json.tmp'):
                    fp = os.path.join(ch_dir, fn)
                    if os.path.exists(fp):
                        try:
                            os.remove(fp)
                        except OSError:
                            pass

                # Read the bound session id so we can safety-net orphaned headless
                # turns for THIS channel only (never VSCode sessions).
                sid = None
                sid_file = os.path.join(ch_dir, 'session-id')
                if os.path.exists(sid_file):
                    try:
                        sid = open(sid_file).read().strip()
                    except Exception:
                        sid = None

                killed = False
                pid = None
                if os.path.exists(pid_file):
                    try:
                        pid = int(open(pid_file).read().strip())
                    except Exception:
                        pid = None
                # Remove the pid file before killing: runner.py treats a vanished
                # pid file as the "stopped" signal and suppresses the error bubble.
                if os.path.exists(pid_file):
                    try:
                        os.remove(pid_file)
                    except OSError:
                        pass

                # Windows: no killpg/pgrep. claude was spawned with
                # CREATE_NEW_PROCESS_GROUP, so `taskkill /F /T` kills the whole tree.
                # Then neutralize the POSIX block below (pid=None makes it a no-op).
                # On macOS/Linux this branch is skipped, so the POSIX path is unchanged.
                if sys.platform == 'win32' and pid:
                    try:
                        import subprocess as _sp
                        _sp.run(['taskkill', '/F', '/T', '/PID', str(pid)],
                                capture_output=True, timeout=5)
                    except Exception:
                        pass
                    pid = None

                def _alive(p):
                    try:
                        os.kill(p, 0)
                        return True
                    except OSError:
                        return False

                if pid and _alive(pid):
                    # Kill the whole process group (claude + its Bash/zsh/tool
                    # subprocesses) — але ТІЛЬКИ якщо claude сам лідер своєї
                    # групи. SDK-двигун спавнив його без start_new_session, тож
                    # група була раннерова, і цей killpg клав движок усіх
                    # каналів. Чужа група -> pgid=None -> точковий kill нижче
                    # плюс pkill -P по дітях.
                    pgid = _safe_pgid(pid)
                    try:
                        if pgid is not None:
                            os.killpg(pgid, _signal.SIGTERM)
                        else:
                            os.kill(pid, _signal.SIGTERM)
                    except OSError:
                        pass
                    try:
                        import subprocess as _sp
                        _sp.run(['pkill', '-TERM', '-P', str(pid)],
                                capture_output=True, timeout=3)
                    except Exception:
                        pass
                    # claude ignores/handles SIGTERM mid-turn, so escalate fast.
                    _time.sleep(0.4)
                    if _alive(pid):
                        try:
                            if pgid is not None:
                                os.killpg(pgid, _signal.SIGKILL)
                            else:
                                os.kill(pid, _signal.SIGKILL)
                        except OSError:
                            pass
                        try:
                            import subprocess as _sp
                            _sp.run(['pkill', '-KILL', '-P', str(pid)],
                                    capture_output=True, timeout=3)
                        except Exception:
                            pass
                    killed = True

                # Safety net: SIGKILL any orphaned HEADLESS `claude -p ... --session-id <sid>`
                # left for this channel. Strictly `-p` headless turns matched by the
                # exact bound session id — this can never hit VSCode/interactive
                # Claude Code sessions (those have no `-p` and a different sid).
                if sid:
                    try:
                        import subprocess as _sp
                        r = _sp.run(['pgrep', '-f', f'claude -p .*--session-id {sid}'],
                                    capture_output=True, text=True, timeout=3)
                        for line in (r.stdout or '').split():
                            try:
                                opid = int(line.strip())
                            except ValueError:
                                continue
                            if opid == os.getpid():
                                continue
                            # double-check the cmdline really is a headless -p turn
                            ps = _sp.run(['ps', '-p', str(opid), '-o', 'command='],
                                         capture_output=True, text=True, timeout=3)
                            cmd_s = (ps.stdout or '')
                            if ' -p ' in cmd_s and sid in cmd_s and '/extensions/' not in cmd_s:
                                try:
                                    os.kill(opid, _signal.SIGKILL)
                                    killed = True
                                except OSError:
                                    pass
                    except Exception:
                        pass

                # The abort is shown ON the prompts that died, not as a separate
                # Claude bubble (that badge-row said «Зупинено» and nothing else,
                # which is a whole message spent on one word — Vova 2026-07-29).
                marked = 0
                try:
                    marked = self._mark_messages_stopped(channel, stopped_ids)
                except Exception:
                    pass

                self._json(200, {'ok': True, 'killed': killed,
                                 'clearedQueue': cleared, 'marked': marked})
            except Exception as e:
                self._json(500, {'ok': False, 'error': str(e)})
            return
        if self.path == '/api/engine-restart':
            # "Хард рефреш" двигуна каналу. Unlike /api/stop it does NOT clear the
            # queue: any pending user messages stay and re-run on a FRESH engine. It
            # (1) kills the channel's active/wedged claude by pid (SIGTERM pgroup ->
            # SIGKILL, same as stop) so a hung turn dies, (2) clears busy/live/pid so
            # the UI unsticks and the runner's per-item guard bails, (3) drops a
            # `recycle` marker the runner consumes to EVICT the warm engine (the
            # idle-between-turns case, warm fallback mode). Next turn cold-respawns and
            # re-reads .mcp.json / CLAUDE.md / skills; --resume restores context.
            # In SDK mode (default) every turn is already fresh, so this mainly unsticks
            # a wedged turn. Vova 2026-07-14.
            try:
                import signal as _signal
                import time as _time
                body = self._read_body()
                channel = body.get('channel', 'main')
                if '/' in channel or '..' in channel:
                    raise ValueError('bad channel')
                ch_dir = os.path.join(DIR, 'channels', channel)
                os.makedirs(ch_dir, exist_ok=True)
                pid_file = os.path.join(ch_dir, 'pid')

                pid = None
                if os.path.exists(pid_file):
                    try:
                        pid = int(open(pid_file).read().strip())
                    except Exception:
                        pid = None
                    # Vanished pid file = runner's "stopped" signal (suppresses the
                    # scary error bubble on the aborted turn).
                    try:
                        os.remove(pid_file)
                    except OSError:
                        pass
                # busy/live gone => runner's per-item guard bails, UI drops the spinner.
                for fn in ('busy', 'live.json', 'live.json.tmp'):
                    fp = os.path.join(ch_dir, fn)
                    if os.path.exists(fp):
                        try:
                            os.remove(fp)
                        except OSError:
                            pass

                def _alive(p):
                    try:
                        os.kill(p, 0)
                        return True
                    except OSError:
                        return False

                killed = False
                if sys.platform == 'win32' and pid:
                    try:
                        import subprocess as _sp
                        _sp.run(['taskkill', '/F', '/T', '/PID', str(pid)],
                                capture_output=True, timeout=5)
                        killed = True
                    except Exception:
                        pass
                    pid = None
                if pid and _alive(pid):
                    # Та сама гарда, що і в /api/stop: група лише коли pid її
                    # лідер, інакше точково по pid (див. _safe_pgid).
                    pgid = _safe_pgid(pid)
                    try:
                        if pgid is not None:
                            os.killpg(pgid, _signal.SIGTERM)
                        else:
                            os.kill(pid, _signal.SIGTERM)
                    except OSError:
                        pass
                    _time.sleep(0.4)
                    if _alive(pid):
                        try:
                            if pgid is not None:
                                os.killpg(pgid, _signal.SIGKILL)
                            else:
                                os.kill(pid, _signal.SIGKILL)
                        except OSError:
                            pass
                    killed = True

                # Marker the runner polls (works even with an empty queue) to evict its
                # in-memory warm engine for this channel.
                try:
                    open(os.path.join(ch_dir, 'recycle'), 'w').close()
                except OSError:
                    pass

                # Visible confirmation bubble in the channel. A tiny 1.3s icon flash on
                # the button alone read as "nothing happened" (Vova: "хард рефреш не
                # спрацьовує") — a real bubble makes the refresh unmistakable.
                try:
                    label = ('Движок перезапущено (завислий хід зупинено)' if killed
                             else 'Движок скинуто, наступне повідомлення піде свіжим')
                    self._append_message(
                        channel,
                        [{'type': 'badge-row',
                          'badges': [{'label': label, 'icon': '♻️', 'color': 'blue'}]}],
                        frm='Claude', tag='status')
                except Exception:
                    pass

                self._json(200, {'ok': True, 'killed': killed})
            except Exception as e:
                self._json(500, {'ok': False, 'error': str(e)})
            return
        if self.path == '/api/compact':
            # Manual context compaction: drop a marker file the runner polls.
            # The runner summarizes the session, rotates the session id, stashes
            # the summary for the next prompt, and posts a bubble. Works even
            # when the channel queue is empty (summary just waits as pending).
            try:
                body = self._read_body()
                channel = body.get('channel', 'main')
                if '/' in channel or '..' in channel:
                    raise ValueError('bad channel')
                ch_dir = os.path.join(DIR, 'channels', channel)
                os.makedirs(ch_dir, exist_ok=True)
                # Refuse to queue a compact while the channel is mid-turn: the
                # runner cannot summarize a session that is being resumed right
                # now. The UI button is also disabled while busy.
                if os.path.exists(os.path.join(ch_dir, 'busy')):
                    self._json(200, {'ok': False, 'busy': True,
                                     'error': 'channel busy'})
                    return
                with open(os.path.join(ch_dir, 'compact-request'), 'w') as f:
                    f.write('1')
                self._json(200, {'ok': True, 'channel': channel})
            except Exception as e:
                self._json(500, {'ok': False, 'error': str(e)})
            return
        if self.path == '/api/autocompact':
            # Per-channel auto-compact toggle. Persists channels/<id>/autocompact
            # (1|0) which runner.py honors. Default ON when the file is absent.
            try:
                body = self._read_body()
                channel = body.get('channel', 'main')
                if '/' in channel or '..' in channel:
                    raise ValueError('bad channel')
                enabled = bool(body.get('enabled', True))
                ch_dir = os.path.join(DIR, 'channels', channel)
                os.makedirs(ch_dir, exist_ok=True)
                with open(os.path.join(ch_dir, 'autocompact'), 'w') as f:
                    f.write('1' if enabled else '0')
                self._json(200, {'ok': True, 'channel': channel,
                                 'enabled': enabled})
            except Exception as e:
                self._json(500, {'ok': False, 'error': str(e)})
            return
        if self.path == '/api/ctx-autosync':
            # Per-channel forward-context auto-sync toggle. Persists
            # channels/<id>/ctx-autosync (1|0) which runner.py honors.
            # Default ON when the file is absent.
            try:
                body = self._read_body()
                channel = body.get('channel', 'main')
                if '/' in channel or '..' in channel:
                    raise ValueError('bad channel')
                # Accept either {on} (spec) or {enabled} (mirrors autocompact).
                if 'on' in body:
                    enabled = bool(body.get('on'))
                else:
                    enabled = bool(body.get('enabled', True))
                ch_dir = os.path.join(DIR, 'channels', channel)
                os.makedirs(ch_dir, exist_ok=True)
                with open(os.path.join(ch_dir, 'ctx-autosync'), 'w') as f:
                    f.write('1' if enabled else '0')
                self._json(200, {'ok': True, 'channel': channel,
                                 'enabled': enabled})
            except Exception as e:
                self._json(500, {'ok': False, 'error': str(e)})
            return
        if self.path == '/api/thinking':
            # Per-channel «is thinking on» toggle. Persists
            # channels/<id>/thinking-on (1|0): '1' -> engine_sdk sends
            # thinking={'type':'adaptive','display':'summarized'}, '0' -> a real
            # {'type':'disabled'}. Default ON (file absent), and the reasoning is
            # streamed whenever it is on — showing it is no longer a separate
            # opt-in. Turning it OFF also neuters «Рівень зусиль» (effort only
            # guides the DEPTH of adaptive thinking), which the UI greys out.
            try:
                body = self._read_body()
                channel = body.get('channel', 'main')
                if '/' in channel or '..' in channel:
                    raise ValueError('bad channel')
                # Accept either {on} (spec) or {enabled} (mirrors autocompact).
                if 'on' in body:
                    enabled = bool(body.get('on'))
                else:
                    enabled = bool(body.get('enabled', True))
                ch_dir = os.path.join(DIR, 'channels', channel)
                os.makedirs(ch_dir, exist_ok=True)
                with open(os.path.join(ch_dir, 'thinking-on'), 'w') as f:
                    f.write('1' if enabled else '0')
                self._json(200, {'ok': True, 'channel': channel,
                                 'enabled': enabled})
            except Exception as e:
                self._json(500, {'ok': False, 'error': str(e)})
            return
        if self.path == '/api/voice-auto':
            # Per-channel auto-voice toggle. Persists channels/<id>/voice-auto
            # (1|0). When '1', render-message.cjs also generates an audio widget
            # for every card posted to the channel. Default OFF (file absent).
            try:
                body = self._read_body()
                channel = body.get('channel', 'main')
                if '/' in channel or '..' in channel:
                    raise ValueError('bad channel')
                # Accept either {on} (spec) or {enabled} (mirrors autocompact).
                if 'on' in body:
                    enabled = bool(body.get('on'))
                else:
                    enabled = bool(body.get('enabled', False))
                ch_dir = os.path.join(DIR, 'channels', channel)
                os.makedirs(ch_dir, exist_ok=True)
                with open(os.path.join(ch_dir, 'voice-auto'), 'w') as f:
                    f.write('1' if enabled else '0')
                self._json(200, {'ok': True, 'channel': channel,
                                 'enabled': enabled})
            except Exception as e:
                self._json(500, {'ok': False, 'error': str(e)})
            return
        if self.path == '/api/perm-auto':
            # Per-channel auto-approve toggle. Persists channels/<id>/perm-auto
            # (1|0). When '1', perm-gate.cjs allows ALL gated tools for the
            # channel instantly (no card, no poll). Default OFF (file absent).
            try:
                body = self._read_body()
                channel = body.get('channel', 'main')
                if '/' in channel or '..' in channel:
                    raise ValueError('bad channel')
                # Accept either {on} (spec) or {enabled} (mirrors autocompact).
                if 'on' in body:
                    enabled = bool(body.get('on'))
                else:
                    enabled = bool(body.get('enabled', False))
                ch_dir = os.path.join(DIR, 'channels', channel)
                os.makedirs(ch_dir, exist_ok=True)
                with open(os.path.join(ch_dir, 'perm-auto'), 'w') as f:
                    f.write('1' if enabled else '0')
                self._json(200, {'ok': True, 'channel': channel,
                                 'enabled': enabled})
            except Exception as e:
                self._json(500, {'ok': False, 'error': str(e)})
            return
        if self.path == '/api/pipeline-save':
            # Reels Pipeline: persist a run's full state.json (UI -> state bridge).
            try:
                body = self._read_body()
                run = body.get('run', '')
                new_state = body.get('state')
                if not run or '/' in run or '..' in run:
                    raise ValueError('bad run')
                if not isinstance(new_state, dict):
                    raise ValueError('state must be an object')
                run_dir = os.path.join(DIR, 'pipelines', run)
                os.makedirs(run_dir, exist_ok=True)
                state_path = os.path.join(run_dir, 'state.json')
                # pretty JSON, UTF-8 no BOM, no ASCII escaping (keep Cyrillic)
                with open(state_path, 'w', encoding='utf-8') as f:
                    json.dump(new_state, f, ensure_ascii=False, indent=2)
                    f.write('\n')
                self._json(200, {'ok': True, 'run': run})
            except Exception as e:
                self._json(500, {'ok': False, 'error': str(e)})
            return
        self.send_response(404)
        self.end_headers()

    def log_message(self, format, *args):
        if os.environ.get('VIZ_CHAT_DEBUG'):
            super().log_message(format, *args)


socketserver.ThreadingTCPServer.allow_reuse_address = True
socketserver.ThreadingTCPServer.daemon_threads = True


class _ChatServer(socketserver.ThreadingTCPServer):
    """ThreadingTCPServer, який не вважає інцидентом зниклого клієнта.

    Закрита вкладка, зупинений плеєр, убитий Playwright і спрацьований idle-timeout
    (Handler.timeout) приходять сюди як BrokenPipe / ConnectionReset / Timeout, і
    базовий handle_error друкував на кожен повний трасбек. Саме цей шум роздув
    viz-chat.error.log до 23 МБ і ховав у собі справжні помилки. Все інше
    друкується як раніше.
    """

    def handle_error(self, request, client_address):
        exc = sys.exc_info()[1]
        if isinstance(exc, (BrokenPipeError, ConnectionResetError, TimeoutError)):
            return
        super().handle_error(request, client_address)


_UPDATER_MOD = []          # tiny cache: [module] once resolved


def _updater():
    """The chatview_updater that MATCHES this server.py.

    Both files ship inside the SAME auto-update payload, so the sibling next to this
    one is by definition the right version. A plain `import chatview_updater` would
    instead return whatever the launcher already put in sys.modules — the FROZEN
    BUNDLE's copy, which can be many releases older than the payload and therefore
    missing functions this file calls. That mismatch is precisely how a payload update
    could break the update button it was shipped to fix. Falls back to the ordinary
    import when the sibling is absent (repo/dev run, or running straight from the
    bundle)."""
    if _UPDATER_MOD:
        return _UPDATER_MOD[0]
    here = os.path.dirname(os.path.abspath(__file__))
    path = os.path.join(here, 'chatview_updater.py')
    mod = None
    if os.path.exists(path):
        try:
            import importlib.util
            spec = importlib.util.spec_from_file_location('chatview_updater_local', path)
            cand = importlib.util.module_from_spec(spec)
            spec.loader.exec_module(cand)
            if hasattr(cand, 'check_and_stage'):
                mod = cand
        except Exception:
            mod = None
    if mod is None:
        import chatview_updater as fallback
        mod = fallback
    _UPDATER_MOD.append(mod)
    return mod


def _desktop_log(msg):
    """Append to the desktop shell's chatview.log (same file entry.py writes), so the
    update trail is ONE timeline instead of "launcher logs, button is silent". The
    manual update-check used to pass no logger at all, which is why a staged payload
    left zero trace and looked like nothing happened. No-op outside the desktop shell."""
    home = os.environ.get('CHATVIEW_HOME')
    if not home:
        return
    try:
        import datetime as _dt   # not a module-level import in server.py
        with open(os.path.join(home, 'chatview.log'), 'a', encoding='utf-8') as fh:
            fh.write('%s %s' % (_dt.datetime.now().isoformat(timespec='seconds'), msg))
    except Exception:
        pass


def _start_periodic_update_check():
    """Re-check the release channel every few hours WHILE the app runs.

    entry.py only checks once, at launch. An app left open for days therefore never
    noticed a release until it happened to be restarted — the user's experience was
    "it never updates itself". This loop lives in server.py ON PURPOSE: server.py is
    part of the auto-update payload, so the polling behaviour itself ships without a
    new installer. Staging only; a running process is never hot-swapped, the new
    payload applies on the next launch (or the «Перезапустити зараз» button).

    CHATVIEW_UPDATE_INTERVAL (seconds) tunes it; 0/negative disables the loop."""
    home = os.environ.get('CHATVIEW_HOME')
    if not home:
        return  # web/dev: nothing to self-update
    try:
        interval = float(os.environ.get('CHATVIEW_UPDATE_INTERVAL') or 6 * 3600)
    except ValueError:
        interval = 6 * 3600
    if interval <= 0:
        return

    def _loop():
        while True:
            time.sleep(interval)
            try:
                _u = _updater()
                running = os.environ.get('CHATVIEW_RUNNING_VERSION') or \
                    _u.read_version(os.path.join(home, 'payload')) or '0.0.0'
                out = _u.check_and_stage(home, running, log=_desktop_log)
                if out.get('status') == 'staged':
                    _desktop_log('[update] periodic check staged %s (restart to apply)\n'
                                 % out.get('staged'))
            except Exception as e:
                _desktop_log('[update] periodic check failed: %s\n' % e)

    threading.Thread(target=_loop, daemon=True).start()


def _bind_server():
    """Bind the HTTP server. On a "Restart to update" relaunch the outgoing instance
    reuses THIS port and may still hold it for a moment, so when CHATVIEW_BIND_WAIT is
    set we retry the bind for a short budget instead of crashing. Default (flag unset)
    binds once, unchanged behaviour."""
    budget = 12.0 if os.environ.get('CHATVIEW_BIND_WAIT') else 0.0
    waited = 0.0
    while True:
        try:
            return _ChatServer(('127.0.0.1', PORT), Handler)
        except OSError:
            if waited >= budget:
                raise
            time.sleep(0.25)
            waited += 0.25


try:
    with _bind_server() as httpd:
        print(f'Vova Chat View serving at http://localhost:{PORT}')
        _start_periodic_update_check()
        if _FD_LIMIT_RAISED:
            print(f'fd limit raised: {_FD_LIMIT_RAISED[0]} -> {_FD_LIMIT_RAISED[1]}')
        httpd.serve_forever()
except KeyboardInterrupt:
    print('\nStopped.')
    sys.exit(0)
except OSError as e:
    if 'Address already in use' in str(e):
        print(f'Port {PORT} already in use. Server probably already running.')
        sys.exit(0)
    raise
