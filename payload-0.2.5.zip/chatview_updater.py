#!/usr/bin/env python3
"""ChatView self-update — the updatable PAYLOAD, thin-launcher model.

The frozen .app/.exe is a THIN launcher that rarely changes. The code it runs
(server.py, runner.py, index.html, canvas SPA ...) is a PAYLOAD that lives in the
user's writable data home and can be replaced in place by a newer download —
WITHOUT touching the signed binary (so Gatekeeper/SmartScreen never re-trip) and
WITHOUT ever touching user DATA (channels/, canvas-data/ live in the home, NOT in
the payload dir). Same flow on Mac and Windows; only relaunch differs (delegated
to chatview_platform).

Design (patterns named in code):
  * Strategy       - `UpdateSource` interface; `GitHubReleaseSource` (public manifest)
                     and `BrokerSource` (private payloads behind signed URLs) are two
                     interchangeable impls, exactly the OCP seam this file promised.
  * Composite      - `ChainSource` tries sources in order, so a broker outage falls
                     back to the legacy public manifest instead of stranding the app.
  * Template Method - `Updater.update()` fixes the algorithm (check -> download ->
                     verify -> stage -> atomic swap) and defers the "where do I
                     look" step to the injected source (Dependency Inversion).

Pure stdlib (urllib, hashlib, zipfile) so it imports identically frozen and in dev.
"""
import os
import abc
import json
import shutil
import hashlib
import zipfile
import tempfile
import urllib.parse
import urllib.request


# --- where updates come from -------------------------------------------------
#
# TWO channels, tried in order, because closing the source must not brick the fleet.
#
# 1. BROKER (primary, private code). A tiny serverless endpoint that holds a read-only
#    GitHub token for the PRIVATE payload repo and hands the app a freshly minted,
#    short-lived signed URL for the zip. The token never leaves the server; the app
#    only carries APP_GATE_KEY, which is a revocable throttle/telemetry handle, NOT a
#    secret (anything shipped in a binary is extractable by definition). What the
#    broker genuinely buys: the payload zips stop being clonable/indexable off a public
#    repo, every fetch is logged and attributable, and access can be cut off per key.
# 2. LEGACY public manifest (fallback, forever). The address every already-installed
#    app was born knowing. It stays reachable and frozen at the bridge release so an
#    app that predates the broker can still self-update ONTO the broker. Deleting it
#    is the one move that would actually strand users, so it is never deleted.
#
# Env overrides for dev/staging: CHATVIEW_BROKER_URL, CHATVIEW_APP_KEY,
# CHATVIEW_UPDATE_URL (the last one pins a single plain manifest and skips the chain).
LEGACY_UPDATE_URL = ('https://raw.githubusercontent.com/'
                     'VolodymyrKopach/chatview-releases/main/version.json')

# Kept under the original name: entry.py imports DEFAULT_UPDATE_URL and ships inside the
# frozen binary, so it can only change with a new .dmg. Pointing it at the legacy channel
# keeps old shells working; check_and_stage() upgrades that value to the full chain.
DEFAULT_UPDATE_URL = LEGACY_UPDATE_URL

DEFAULT_BROKER_URL = 'https://chatview-updates.vercel.app/api/version'

# Gate key, not a credential. Rotating = add the new key to the broker's CHATVIEW_APP_KEYS
# and ship it here; the broker accepts a LIST so old apps keep working indefinitely.
APP_GATE_KEY = 'cvk1_a44f34c72a00ff7413227fed74e86cab'


# Files that make up the payload (everything the launcher runs from the home).
# Single source of truth; the build ships these and the updater swaps these.
PAYLOAD_FILES = (
    'VERSION',
    'server.py',
    'runner.py',
    'chatview_updater.py',      # the updater ships ITSELF: entry.py prefers the payload
                                # copy for update checks, so a fix to the update logic
                                # lands via a normal payload instead of a new .dmg.
    'chatview_platform.py',
    'chatview_onboarding.py',   # onboarding (install/login Claude Code); server.py imports it
    'jobs.py',                  # process registry + kill/spawn gates; server.py + runner.py import it
    'agent_worker.py',          # detached background agent; jobs.spawn runs it (entry.py --agent-worker)
    'project_state.py',
    'transfer.py',
    'usage_api.py',
    'index.html',
    'fractional-index.cjs',
)
PAYLOAD_DIRS = (
    'canvas-dist',
    'assets',           # V2 React SPA bundle (index-*.js / index-*.css). Present only in
                        # V2 builds; a missing dir in the bundle is a harmless no-op (V1).
    'skills-library',   # помічники/персони catalog served from the home
    # apps/ intentionally excluded: user-created gadgets are DATA, not payload. Auto-update
    # must never carry/overwrite them. Add back only with the built-in-vs-user split.
)


# ---- version helpers --------------------------------------------------------

def parse_version(s):
    """'1.2.3' -> (1,2,3). Non-numeric / missing parts degrade to 0 so a bad file
    never crashes the launcher; it just compares as an older version."""
    parts = []
    for chunk in str(s or '').strip().split('.'):
        num = ''.join(ch for ch in chunk if ch.isdigit())
        parts.append(int(num) if num else 0)
    while len(parts) < 3:
        parts.append(0)
    return tuple(parts[:3])


def read_version(code_dir):
    try:
        with open(os.path.join(code_dir, 'VERSION'), encoding='utf-8') as fh:
            return fh.read().strip()
    except Exception:
        return '0.0.0'


def is_newer(candidate, current):
    return parse_version(candidate) > parse_version(current)


# ---- update source (Strategy) ----------------------------------------------

class UpdateInfo:
    __slots__ = ('version', 'url', 'sha256')

    def __init__(self, version, url, sha256=None):
        self.version = version
        self.url = url
        self.sha256 = (sha256 or '').lower() or None

    def __repr__(self):
        return 'UpdateInfo(v=%s, url=%s, sha256=%s)' % (
            self.version, self.url, (self.sha256 or '')[:12])


class UpdateSource(abc.ABC):
    """Where a new payload is discovered. Swap the impl to change channels
    (public GitHub Releases vs a private HTTPS endpoint) with zero updater edits.

    CONTRACT — `latest()` returning None is ambiguous on its own, so every impl MUST
    also set `last_error`:
        None returned, last_error is None  -> authoritative "nothing newer exists"
        None returned, last_error is set   -> could not find out (offline/5xx/bad JSON)
    ChainSource and check_and_stage both branch on that difference; collapsing the two
    is what once made a network failure render as a green «у вас найновіша версія»."""

    last_error = None

    @abc.abstractmethod
    def latest(self, since=None) -> 'UpdateInfo':
        """Return the newest available UpdateInfo (or None).

        `since` is the version the caller already holds (running or staged, whichever is
        newer). A dumb manifest ignores it; the broker uses it to answer "nothing newer"
        without minting a signed download URL, which keeps the 99% no-op poll to a single
        upstream call."""


class GitHubReleaseSource(UpdateSource):
    """Reads a small `version.json` manifest published on the release channel:
        {"version": "0.2.0", "url": "https://.../payload.zip", "sha256": "<hex>"}
    A plain JSON manifest (not the GitHub API) keeps it rate-limit-free and lets a
    private server serve the exact same shape."""

    def __init__(self, manifest_url, timeout=8):
        self.manifest_url = manifest_url
        self.timeout = timeout
        # Set by latest() on any failure so a caller (the on-demand /api/desktop/
        # update-check handler) can tell "genuinely current" apart from "couldn't
        # even reach the manifest" — both used to collapse into the same silent
        # None, which made the UI show the misleading green "найновіша версія"
        # on a network/TLS failure instead of "не вдалося перевірити".
        self.last_error = None

    def latest(self, since=None):
        self.last_error = None
        try:
            req = urllib.request.Request(self.manifest_url,
                                         headers={'User-Agent': 'ChatView-Updater'})
            with urllib.request.urlopen(req, timeout=self.timeout) as r:
                data = json.loads(r.read().decode('utf-8'))
            v = data.get('version')
            url = data.get('url')
            if not v or not url:
                self.last_error = 'malformed manifest'
                return None
            return UpdateInfo(v, url, data.get('sha256'))
        except Exception as e:
            self.last_error = str(e)
            return None  # offline / unreachable -> just no update this launch


class BrokerSource(UpdateSource):
    """Private-payload channel: asks a broker endpoint what the newest version is and
    gets back a SHORT-LIVED signed URL for the zip, minted per request.

    Wire format (deliberately a superset of the plain manifest, so both sources feed the
    identical UpdateInfo and the download path below stays untouched):
        GET <endpoint>?v=<version we already hold>
        Authorization: Bearer <APP_GATE_KEY>
      -> 200 {"version": "0.2.6", "current": true}                  nothing newer
      -> 200 {"version": "0.2.6", "url": "https://...?token=...", "sha256": "<hex>"}
      -> 401 unauthorized / 5xx upstream  -> last_error set, chain falls through

    The returned URL is a real GitHub signed object URL: it serves the private zip
    anonymously for a few minutes, supports Range (so a dropped download resumes), and
    404s the moment the signature is stripped or expires. The updater never sees a
    credential, which is the whole point."""

    def __init__(self, endpoint, app_key, timeout=8):
        self.endpoint = endpoint
        self.app_key = app_key
        self.timeout = timeout
        self.last_error = None

    def latest(self, since=None):
        self.last_error = None
        url = self.endpoint
        if since:
            sep = '&' if '?' in url else '?'
            url = url + sep + urllib.parse.urlencode({'v': since})
        try:
            req = urllib.request.Request(url, headers={
                'User-Agent': 'ChatView-Updater',
                'Authorization': 'Bearer %s' % self.app_key,
                'Accept': 'application/json',
            })
            with urllib.request.urlopen(req, timeout=self.timeout) as r:
                data = json.loads(r.read().decode('utf-8'))
        except Exception as e:
            self.last_error = str(e)
            return None
        if data.get('current'):
            return None  # authoritative: broker says we already hold the newest
        v, dl = data.get('version'), data.get('url')
        if not v or not dl:
            self.last_error = 'malformed broker reply'
            return None
        return UpdateInfo(v, dl, data.get('sha256'))


class ChainSource(UpdateSource):
    """Composite: ask each source in turn, first ANSWER wins — where an answer is either
    an UpdateInfo or an authoritative "nothing newer" (None with no last_error).

    Only a genuine failure falls through to the next source. That distinction is what
    stops a healthy broker's "you are current" from being second-guessed by a stale
    legacy manifest, while still letting a dead broker hand over cleanly.

    last_error is set only when EVERY source failed, so check_and_stage still tells
    «не вдалося перевірити» apart from «у вас найновіша версія»."""

    def __init__(self, *sources):
        self.sources = [s for s in sources if s is not None]
        self.last_error = None

    def latest(self, since=None):
        self.last_error = None
        errors = []
        for src in self.sources:
            info = src.latest(since)
            if info:
                return info
            if not src.last_error:
                return None            # authoritative "nothing newer" -> stop here
            errors.append('%s: %s' % (type(src).__name__, src.last_error))
        self.last_error = '; '.join(errors) or 'no sources configured'
        return None


def default_source():
    """The shipped chain: private broker first, legacy public manifest as the permanent
    safety net. Env overrides exist so a dev box can point at a local broker."""
    broker = BrokerSource(
        os.environ.get('CHATVIEW_BROKER_URL') or DEFAULT_BROKER_URL,
        os.environ.get('CHATVIEW_APP_KEY') or APP_GATE_KEY)
    return ChainSource(broker, GitHubReleaseSource(LEGACY_UPDATE_URL))


# ---- updater (Template Method) ---------------------------------------------

class Updater:
    def __init__(self, source: UpdateSource, home: str, current_version: str,
                 log=lambda *_: None):
        self.source = source
        self.home = home
        self.current_version = current_version
        self.payload_dir = os.path.join(home, 'payload')
        self.log = log

    # -- individual steps (each independently testable) --

    def staged_version(self):
        """Version of the payload sitting in the home RIGHT NOW. Can be newer than the
        running one: a previous check may have staged an update that only applies on the
        next launch."""
        if os.path.isdir(self.payload_dir):
            return read_version(self.payload_dir)
        return '0.0.0'

    def baseline(self):
        """The version a candidate must strictly beat = the NEWER of what runs now and
        what is already staged on disk.

        Comparing against the RUNNING version alone caused two real bugs:
          * downgrade — a second, older instance (or an old app opened after a new one)
            saw the channel as "newer than me" and overwrote a NEWER staged payload with
            an older one. Observed in chatview.log: payload 0.2.1 clobbered by 0.1.19.
          * re-download loop — once checks run periodically, an already-staged version
            stays "newer than running" forever, so every poll re-downloaded it."""
        staged = self.staged_version()
        return staged if is_newer(staged, self.current_version) else self.current_version

    def check(self):
        """Return UpdateInfo if a strictly-newer payload is available, else None.

        The baseline is handed to the source as a hint (`since`) AND re-checked here:
        a source may ignore the hint, and a broker must never be trusted to gate our
        own downgrade protection."""
        base = self.baseline()
        info = self.source.latest(base)
        if info and is_newer(info.version, base):
            return info
        return None

    def _download(self, info):
        fd, tmp = tempfile.mkstemp(prefix='cv-payload-', suffix='.zip')
        os.close(fd)
        req = urllib.request.Request(info.url, headers={'User-Agent': 'ChatView-Updater'})
        with urllib.request.urlopen(req, timeout=60) as r, open(tmp, 'wb') as out:
            shutil.copyfileobj(r, out)
        return tmp

    @staticmethod
    def _sha256(path):
        h = hashlib.sha256()
        with open(path, 'rb') as fh:
            for block in iter(lambda: fh.read(65536), b''):
                h.update(block)
        return h.hexdigest()

    def _stage_and_swap(self, zip_path):
        """Extract into payload.new, then atomically replace payload/ with it.
        User DATA is never inside payload/, so it is untouched. Old payload kept as
        payload.bak until the swap succeeds (rollback safety)."""
        staging = self.payload_dir + '.new'
        backup = self.payload_dir + '.bak'
        shutil.rmtree(staging, ignore_errors=True)
        os.makedirs(staging, exist_ok=True)
        with zipfile.ZipFile(zip_path) as zf:
            # guard against zip-slip: reject entries that escape the staging dir
            for member in zf.namelist():
                dest = os.path.realpath(os.path.join(staging, member))
                if not dest.startswith(os.path.realpath(staging) + os.sep) \
                   and dest != os.path.realpath(staging):
                    raise ValueError('unsafe zip entry: %s' % member)
            zf.extractall(staging)
        # atomic-ish swap
        shutil.rmtree(backup, ignore_errors=True)
        if os.path.isdir(self.payload_dir):
            os.rename(self.payload_dir, backup)
        os.rename(staging, self.payload_dir)
        shutil.rmtree(backup, ignore_errors=True)

    # -- the algorithm (Template Method) --

    def update(self):
        """check -> download -> verify -> stage -> swap. Returns the new version
        string if a payload was installed, else None. Any failure rolls forward to
        None (the launcher keeps running the current payload)."""
        info = self.check()
        if not info:
            return None
        self.log('[update] newer payload %s available\n' % info.version)
        tmp = None
        try:
            tmp = self._download(info)
            if info.sha256:
                got = self._sha256(tmp)
                if got.lower() != info.sha256.lower():
                    self.log('[update] sha256 mismatch (%s != %s); aborting\n'
                             % (got[:12], info.sha256[:12]))
                    return None
            self._stage_and_swap(tmp)
            self.log('[update] installed payload %s\n' % info.version)
            return info.version
        except Exception as e:
            self.log('[update] failed: %s\n' % e)
            return None
        finally:
            if tmp and os.path.exists(tmp):
                try:
                    os.remove(tmp)
                except OSError:
                    pass


# ---- one shared entry point for every caller --------------------------------

def check_and_stage(home, running_version, url=None, log=lambda *_: None):
    """Poll the channel and, if it offers something newer, download+verify+stage it.

    The SINGLE flow behind all three callers — the launch-time background check
    (entry.py), the periodic in-session check and the manual "Перевірити оновлення"
    button (both server.py). They used to each hand-roll the Updater wiring, which is
    how the manual path ended up with no logging and a subtly different notion of
    "current". Returns a dict the HTTP endpoint can serialise as-is:

        {'status': 'current' | 'staged' | 'error',
         'running': <version running now>,
         'staged':  <version now on disk, only when status == 'staged'>,
         'error':   <reason, only when status == 'error'>}

    'error' covers BOTH an unreachable channel and a failed download/verify; it never
    raises, so a caller can fire it blind on a timer.
    """
    running = running_version or '0.0.0'
    # A caller that names a SPECIFIC manifest (tests, dev, staging) gets exactly that and
    # nothing else. But entry.py lives in the frozen shell and always passes the legacy
    # default it was compiled with, so treat that one value as "no preference" and give it
    # the chain — otherwise the launch-time check would keep polling the frozen public
    # channel until the user installs a new .dmg, which is the trap this whole design
    # exists to avoid.
    pinned = url or os.environ.get('CHATVIEW_UPDATE_URL')
    if pinned and pinned != LEGACY_UPDATE_URL:
        src = GitHubReleaseSource(pinned)
    else:
        src = default_source()
    up = Updater(src, home, running, log)
    info = up.check()
    if not info:
        # A fetch/parse failure must NOT look identical to "genuinely up to date", else
        # the UI shows a green "найновіша версія" on a silent network error.
        if src.last_error:
            return {'status': 'error', 'running': running,
                    'error': 'unreachable: %s' % src.last_error}
        # Already holding this version (running or staged) -> report the staged one so
        # the UI can still offer "Перезапустити зараз" for a pending update.
        staged = up.staged_version()
        if is_newer(staged, running):
            return {'status': 'staged', 'running': running, 'staged': staged}
        return {'status': 'current', 'running': running}
    newv = up.update()
    if newv:
        return {'status': 'staged', 'running': running, 'staged': newv}
    return {'status': 'error', 'running': running, 'error': 'download or verify failed'}


# ---- payload selection (used by the launcher) ------------------------------

def seed_payload_from_bundle(bundle_dir, home, log=lambda *_: None):
    """Populate home/payload from the frozen bundle when it is missing or the
    bundle is newer (i.e. the user installed a fresh .app). This is the baseline
    the online updater then upgrades. Never overwrites a home payload that is
    already newer than the bundle."""
    payload = os.path.join(home, 'payload')
    bundle_v = read_version(bundle_dir)
    home_v = read_version(payload) if os.path.isdir(payload) else '0.0.0'
    # Keep the home payload ONLY if it is STRICTLY newer than the bundle — i.e. the
    # online updater installed a newer version. Otherwise (bundle newer OR SAME
    # version) re-seed from the bundle. Same-version re-seed matters: reinstalling /
    # relaunching a rebuilt .app of the same version must refresh the code, else the
    # launcher keeps running a stale payload from an earlier build (observed bug).
    if os.path.isdir(payload) and is_newer(home_v, bundle_v):
        return payload  # online-updated payload is newer -> keep it
    os.makedirs(payload, exist_ok=True)
    for name in PAYLOAD_FILES:
        src = os.path.join(bundle_dir, name)
        if os.path.exists(src):
            try:
                shutil.copy2(src, os.path.join(payload, name))
            except Exception as e:
                log('[update] seed %s failed: %s\n' % (name, e))
    for name in PAYLOAD_DIRS:
        src = os.path.join(bundle_dir, name)
        if os.path.isdir(src):
            try:
                shutil.copytree(src, os.path.join(payload, name), dirs_exist_ok=True)
            except Exception as e:
                log('[update] seed dir %s failed: %s\n' % (name, e))
    log('[update] seeded payload %s from bundle\n' % bundle_v)
    return payload


def choose_code_dir(bundle_dir, home, log=lambda *_: None):
    """Return the dir the launcher should run server.py/runner.py from: the home
    payload (updatable) if it is valid and >= the bundle, else the bundle itself
    (safe fallback). Seeds the home payload from the bundle first."""
    payload = seed_payload_from_bundle(bundle_dir, home, log)
    if os.path.exists(os.path.join(payload, 'server.py')) \
       and not is_newer(read_version(bundle_dir), read_version(payload)):
        return payload
    return bundle_dir
