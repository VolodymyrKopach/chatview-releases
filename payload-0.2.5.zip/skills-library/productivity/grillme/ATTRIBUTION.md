# Grill Me: походження і ліцензії

Помічник `grillme` це кураторський порт двох MIT-скілів з GitHub, зведених в один і перекладених українською під наш воркфлоу (ChatView, AskUserQuestion, plan.json).

| Джерело | Що взято | Ліцензія |
|---|---|---|
| [mattpocock/skills](https://github.com/mattpocock/skills) (`skills/productivity/grill-me` + `skills/productivity/grilling`) | базовий протокол: одне питання за раз, своя рекомендована відповідь, факти шукає агент а не питає, не діяти до підтвердженої спільної картини | MIT (файл `LICENSE-mattpocock`) |
| [Jekudy/grillme-skill](https://github.com/Jekudy/grillme-skill) | хвилі питань 1/2/3+, пул лінз аналізу, проміжні саммарі, перевірка покриття, фінальний шаблон | MIT (заявлено в README репо, окремого файлу LICENSE у репо нема) |

Наші додатки поверх джерел: українська мова, тригери під мову Vova, віддача фінального саммарі карткою в ChatView, перенос результату в `plan.json` каналу.

Дата порту: 2026-07-26.
