#!/usr/bin/env python3
"""Detached background AGENT worker for the «Процеси» panel (Phase 2, Vova 2026-07-10).

Spawned DETACHED by /api/agent-spawn (own session + process group) so it survives the
main turn, a new message, and even a ChatView restart. It runs ONE `claude -p <task>`
in its own --session-id + pgid, mirrors run_claude_stream's stream-json parse, and
writes per-agent state to disk:

  channels/<ch>/agents/<id>/status.json     live status (state,pid,pgid,progress,lastStep…)
  channels/<ch>/agents/<id>/progress.jsonl  append-only step/text stream
  channels/<ch>/agents/<id>/output.md       final result (written on done)

On done it auto-posts output as a card to the channel and emits an agent/done event so
the panel + feed reflect the result. Reattach/orphan-reconcile lives in server.py (it
scans status.json); this worker just runs one agent to completion.

Usage:  python agent_worker.py <channel> <agentId>
The spawn spec (task,label,model,sid) is read from the pre-written status.json.
Set AGENT_CLAUDE_BIN to override the claude binary (used by the cheap plumbing test).
"""
import os
import sys
import json
import time
import uuid
import tempfile
import subprocess
from datetime import datetime

import runner  # safe to import: runner guards its worker loop behind __main__
import jobs    # реєстр процесів + гейти на вбивство/спавн


def _agent_dir(channel, agent_id):
    return os.path.join(runner.CHANNELS_DIR, channel, 'agents', agent_id)


def _now():
    return datetime.now().isoformat()


def _close_jobs(channel, agent_id, claude_job, state):
    """Зняти з реєстру обидва job-и агента: його claude і сам воркер.

    Свій jobId читаємо зі status.json НАПРИКІНЦІ, а не на старті: сервер
    дописує його вже після спавну, тож на старті файл його ще не має."""
    try:
        if claude_job:
            jobs.finish(claude_job.get('jobId'), state)
    except Exception:
        pass
    try:
        own = _read_status(channel, agent_id).get('jobId')
        if own:
            jobs.finish(own, state)
    except Exception:
        pass


def _read_status(channel, agent_id):
    try:
        return json.load(open(os.path.join(_agent_dir(channel, agent_id), 'status.json'),
                              encoding='utf-8')) or {}
    except Exception:
        return {}


def _write_status(channel, agent_id, patch):
    """Merge patch into status.json atomically (never raises)."""
    try:
        d = _agent_dir(channel, agent_id)
        os.makedirs(d, exist_ok=True)
        p = os.path.join(d, 'status.json')
        cur = _read_status(channel, agent_id)
        cur.update(patch)
        cur['updatedAt'] = _now()
        tmp = p + '.tmp'
        with open(tmp, 'w', encoding='utf-8') as f:
            json.dump(cur, f, ensure_ascii=False, indent=2)
        os.replace(tmp, p)
        return cur
    except Exception as e:
        runner.log(f'agent {agent_id}: status write failed: {e}')
        return {}


def _progress(channel, agent_id, rec):
    try:
        d = _agent_dir(channel, agent_id)
        os.makedirs(d, exist_ok=True)
        rec = dict(rec)
        rec.setdefault('ts', _now())
        with open(os.path.join(d, 'progress.jsonl'), 'a', encoding='utf-8') as f:
            f.write(json.dumps(rec, ensure_ascii=False) + '\n')
    except Exception:
        pass


def _post_card(channel, widgets, from_name, tag='agent'):
    """Append a result card to the channel so the agent's output shows up like any
    other bubble.

    Preferred path is render-message.cjs (the same one the hooks use: it also
    lazily registers a brand-new channel as a tab and can voice the card). A packaged
    desktop ships neither that script nor a guaranteed node, so it degrades to
    runner.append_message — literally the function the runner writes its own bubbles
    with. Without this fallback a detached agent finished silently in the desktop:
    the work was done, the result never reached the chat."""
    script = os.path.join(runner.DIR, 'render-message.cjs')
    node = runner._resolve_node()
    if os.path.exists(script) and os.path.isabs(node) and os.path.exists(node):
        tmp = None
        try:
            fd, tmp = tempfile.mkstemp(suffix='.json')
            os.close(fd)
            with open(tmp, 'w', encoding='utf-8') as f:
                json.dump(widgets, f, ensure_ascii=False)
            r = subprocess.run([node, script, tmp, from_name, tag, channel],
                               cwd=runner.DIR, timeout=25,
                               stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
            if r.returncode == 0:
                return
            runner.log(f'agent: render-message exited {r.returncode}, writing card directly')
        except Exception as e:
            runner.log(f'agent: post card via node failed: {e}, writing card directly')
        finally:
            if tmp:
                try:
                    os.remove(tmp)
                except OSError:
                    pass
    try:
        runner.append_message(channel, widgets, from_name, tag)
    except Exception as e:
        runner.log(f'agent: post card failed: {e}')


def run(channel, agent_id):
    spec = _read_status(channel, agent_id)
    task = (spec.get('task') or '').strip()
    label = spec.get('label') or 'Агент'
    # claude --session-id must be a valid UUID; the server writes one, this is the fallback.
    sid = spec.get('sid') or str(uuid.uuid4())
    if not task:
        _write_status(channel, agent_id, {'state': 'error', 'summary': 'порожня задача'})
        return

    claude_bin = os.environ.get('AGENT_CLAUDE_BIN', runner.CLAUDE_BIN)
    model_name = spec.get('model') or runner.channel_model(channel, task)
    cmd = [claude_bin, '-p', task,
           *runner._resolve_model_args(model_name),
           '--disallowedTools', *runner.DISALLOWED_TOOLS,
           '--output-format', 'stream-json', '--verbose',
           '--include-partial-messages',
           '--session-id', sid,
           # A detached agent has no interactive permission UI, so it must not block on
           # a prompt; it runs autonomously (still bounded by --disallowedTools).
           '--permission-mode', 'bypassPermissions']

    env = runner._child_env(channel)
    try:
        proc = subprocess.Popen(
            cmd, cwd=runner.REPO_ROOT, stdout=subprocess.PIPE, stderr=subprocess.PIPE,
            text=True, bufsize=1, env=env, **runner._PROC_GROUP_KW)
    except Exception as e:
        _write_status(channel, agent_id, {'state': 'error', 'summary': f'spawn failed: {e}'})
        return

    try:
        pgid = os.getpgid(proc.pid)
    except Exception:
        pgid = proc.pid
    # Реєструємо claude агента окремим job: воркер сидить у своїй групі, а його
    # claude у СВОЇЙ, тож сигнал групі воркера claude не накриє. Стоп агента
    # б'є обидва job-и через гейт (jobs.stop), а не по голому pid з диска.
    claude_job = jobs.register('agent-claude', channel, proc.pid, label=label,
                               meta={'agentId': agent_id, 'sid': sid})
    _write_status(channel, agent_id, {'state': 'running', 'pid': proc.pid, 'pgid': pgid,
                                      'claudeJobId': (claude_job or {}).get('jobId'),
                                      'sid': sid, 'startedAt': _now(),
                                      'progressPct': 3, 'lastStep': 'старт'})
    runner.emit_event(channel, {'kind': 'agent', 'phase': 'start', 'name': label,
                                'agentId': agent_id, 'detail': task[:80]})

    steps_done = 0
    text = ''
    try:
        for line in iter(proc.stdout.readline, ''):
            # An external stop flips status→stopped; bail promptly so we don't overwrite it.
            if steps_done % 1 == 0 and _read_status(channel, agent_id).get('state') == 'stopped':
                break
            line = line.strip()
            if not line:
                continue
            try:
                ev = json.loads(line)
            except Exception:
                continue
            t = ev.get('type')
            if t == 'assistant':
                for b in (ev.get('message', {}) or {}).get('content', []):
                    if b.get('type') == 'tool_use':
                        name = b.get('name', '')
                        lbl = runner._tool_label(name, b.get('input'))
                        steps_done += 1
                        last_step = (f'{name}: {lbl}' if lbl else name)[:140]
                        _progress(channel, agent_id, {'phase': 'step', 'tool': name, 'step': last_step})
                        _write_status(channel, agent_id, {'lastStep': last_step,
                                      'progressPct': min(95, 5 + steps_done * 7)})
            elif t == 'stream_event':
                inner = ev.get('event', {}) or {}
                if inner.get('type') == 'content_block_delta':
                    d = inner.get('delta', {}) or {}
                    if d.get('type') == 'text_delta' and d.get('text'):
                        text += d['text']
            elif t == 'result':
                text = ev.get('result') or text
    except Exception as e:
        runner.log(f'agent {agent_id}: parse error: {e}')

    err_txt = ''
    try:
        err_txt = (proc.stderr.read() or '').strip()
    except Exception:
        err_txt = ''
    try:
        rc = proc.wait(timeout=10)
    except Exception:
        rc = proc.returncode

    # If /api/agent-stop marked us stopped, leave that state as-is.
    if _read_status(channel, agent_id).get('state') == 'stopped':
        _close_jobs(channel, agent_id, claude_job, 'stopped')
        runner.emit_event(channel, {'kind': 'agent', 'phase': 'stopped', 'name': label,
                                    'agentId': agent_id})
        return

    body = (text or '').strip()
    # claude failed (bad args / auth / overload): surface the real error, never fake "done".
    if not body and rc not in (0, None):
        msg = (err_txt or f'agent exited rc={rc}')[:300]
        _write_status(channel, agent_id, {'state': 'error', 'progressPct': 100,
                      'summary': msg, 'endedAt': _now()})
        _close_jobs(channel, agent_id, claude_job, 'error')
        runner.emit_event(channel, {'kind': 'agent', 'phase': 'error', 'name': label,
                                    'agentId': agent_id, 'detail': msg})
        _post_card(channel, [
            {'type': 'callout', 'variant': 'danger', 'icon': '🤖',
             'title': f'{label} · агент впав', 'text': msg},
        ], from_name=label, tag='agent')
        return

    out = body or '(агент завершив без тексту)'
    try:
        with open(os.path.join(_agent_dir(channel, agent_id), 'output.md'), 'w',
                  encoding='utf-8') as f:
            f.write(out)
    except Exception:
        pass
    _write_status(channel, agent_id, {'state': 'done', 'progressPct': 100,
                                      'summary': out[:220], 'endedAt': _now()})
    _close_jobs(channel, agent_id, claude_job, 'done')
    runner.emit_event(channel, {'kind': 'agent', 'phase': 'done', 'name': label,
                                'agentId': agent_id})
    # Заголовок через title, а НЕ сирим HTML у body: V2 свідомо екранує розмітку
    # (див. widgets/Text.tsx), тож старий HTML-рядок доїжджав у чат як голий тег.
    # title розуміють обидва UI однаково.
    _post_card(channel, [
        {'type': 'text', 'title': f'🤖 {label} · агент завершив', 'text': out},
    ], from_name=label, tag='agent')


if __name__ == '__main__':
    if len(sys.argv) < 3:
        sys.stderr.write('usage: agent_worker.py <channel> <agentId>\n')
        sys.exit(2)
    run(sys.argv[1], sys.argv[2])
