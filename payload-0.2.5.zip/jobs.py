#!/usr/bin/env python3
"""Реєстр живих процесів ChatView плюс два гейти: на вбивство і на спавн.

НАВІЩО. Досі кожен, хто щось спавнив, сам вирішував як це вбивати, і вбивав по
голому pid з диска. Звідси клас багів «стоп поклав не те»: pid у status.json
міг застаріти, pgid міг вести в групу раннера (див. chatview_platform.safe_pgid),
а API приймав будь-який pid, який йому передали.

Тут одна точка правди. Кожен спавн реєструється файлом jobs/<jobId>.json, і
вбити можна ЛИШЕ зареєстрований job, ЛИШЕ якщо це досі той самий процес.

ГЕЙТ НА ВБИВСТВО, чотири перевірки поспіль:
  1. job існує в реєстрі. Довільний pid ззовні вбити неможливо в принципі.
  2. pid не в захищеному списку (сам сервер, раннер, init).
  3. процес ТОЙ САМИЙ: збігається час старту, знятий при реєстрації. Закриває
     pid-reuse, коли ОС видала номер небіжчика новому процесу.
  4. killpg лише коли safe_pgid підтвердив, що pid сам лідер своєї групи.

ГЕЙТ НА СПАВН: /api/job-spawn не запускає довільну команду з тіла запиту, лише
іменований тип з SPAWN_KINDS. Сервер слухає localhost, але localhost це і
кожна вкладка браузера, тому endpoint «виконай що передали» був би дірою.

Чистий stdlib, без залежностей: модуль однаково імпортується в dev і в
замороженому PyInstaller-білді.
"""
import os
import sys
import json
import time
import signal
import subprocess
import threading
import uuid

DIR = os.environ.get('CHATVIEW_HOME') or os.path.dirname(os.path.abspath(__file__))
JOBS_DIR = os.path.join(DIR, 'jobs')

# Тека з КОДОМ, свідомо окремо від DIR. DIR це дім ДАНИХ: у пакованій збірці він
# вказує на ~/Library/Application Support/ChatView, тоді як самі модулі лежать
# глибше, у payload/. Шлях до воркера, який ми спавнимо, треба брати від себе
# самого, інакше десктоп шукав би agent_worker.py у теці даних і не знаходив.
CODE_DIR = os.path.dirname(os.path.abspath(__file__))

# Скільки завершений job лежить у реєстрі, перш ніж його приберуть. Треба, щоб
# UI встиг показати «щойно завершилось», але тека не росла вічно.
KEEP_DONE_SEC = 10 * 60
# Стеля на кількість файлів у реєстрі: захист від нескінченного росту, якщо
# prune десь не спрацював.
MAX_FILES = 500

_LOCK = threading.Lock()

# Імена процесів, які не можна вбивати ЖОДНИМ шляхом через цей модуль.
PROTECTED_NAMES = ('runner.py', 'server.py', 'launchd', 'systemd')

try:
    from chatview_platform import safe_pgid as _safe_pgid
except Exception:                                    # частковий чекаут
    def _safe_pgid(pid):
        if not hasattr(os, 'getpgid'):
            return None
        try:
            pid = int(pid)
            if pid <= 1:
                return None
            pgid = os.getpgid(pid)
        except (TypeError, ValueError, OSError):
            return None
        if pgid != pid or pgid == os.getpgrp():
            return None
        return pgid


# ── ідентичність процесу ─────────────────────────────────────────────────────

def _proc_start(pid):
    """Час старту процесу як рядок, або '' якщо не дізнались.

    Це відбиток, за яким ми впізнаємо, що pid досі НАШ. Номери pid ОС переюзує,
    і без такої перевірки стоп через хвилину після смерті агента міг би влучити
    у чужий свіжий процес з тим самим номером."""
    if os.name == 'nt':
        return ''
    try:
        r = subprocess.run(['ps', '-o', 'lstart=', '-p', str(int(pid))],
                           capture_output=True, text=True, timeout=5)
        return (r.stdout or '').strip()
    except Exception:
        return ''


def _proc_cmd(pid):
    if os.name == 'nt':
        return ''
    try:
        r = subprocess.run(['ps', '-o', 'command=', '-p', str(int(pid))],
                           capture_output=True, text=True, timeout=5)
        return (r.stdout or '').strip()
    except Exception:
        return ''


def is_alive(pid):
    """Живий = існує і не зомбі. Зомбі відповідає на сигнальну пробу, тому
    os.kill(pid, 0) тут брехав би."""
    try:
        pid = int(pid)
    except (TypeError, ValueError):
        return False
    if pid <= 1:
        return False
    if os.name == 'nt':
        try:
            os.kill(pid, 0)
            return True
        except OSError:
            return False
    try:
        r = subprocess.run(['ps', '-o', 'stat=', '-p', str(pid)],
                           capture_output=True, text=True, timeout=5)
        st = (r.stdout or '').strip()
        return bool(st) and not st.startswith('Z')
    except Exception:
        try:
            os.kill(pid, 0)
            return True
        except OSError:
            return False


def _protected(pid):
    """True якщо цей pid чіпати заборонено: ми самі, наш батько, init, або
    процес, чия командна стрічка виглядає як сам движок."""
    try:
        pid = int(pid)
    except (TypeError, ValueError):
        return True
    if pid <= 1 or pid == os.getpid() or pid == os.getppid():
        return True
    cmd = _proc_cmd(pid)
    return any(n in cmd for n in PROTECTED_NAMES)


# ── зберігання ───────────────────────────────────────────────────────────────

def _path(job_id):
    return os.path.join(JOBS_DIR, f'{job_id}.json')


def _write(job):
    os.makedirs(JOBS_DIR, exist_ok=True)
    p = _path(job['jobId'])
    tmp = f'{p}.{os.getpid()}.tmp'
    with open(tmp, 'w', encoding='utf-8') as f:
        json.dump(job, f, ensure_ascii=False, indent=2)
    os.replace(tmp, p)
    return job


def _read(job_id):
    try:
        with open(_path(job_id), encoding='utf-8') as f:
            return json.load(f)
    except Exception:
        return None


def _valid_id(job_id):
    return bool(job_id) and all(c.isalnum() or c in '-_' for c in str(job_id))


# ── реєстрація ───────────────────────────────────────────────────────────────

def register(kind, channel, pid, label='', meta=None):
    """Записати живий процес у реєстр. Повертає job dict (ніколи не кидає).

    isolated=False означає, що процес сидить у чужій групі, тобто стоп зможе
    вбити лише його самого плюс прямих дітей, не все дерево. Це видно у
    /api/jobs, щоб деградація не була мовчазною."""
    try:
        pgid = _safe_pgid(pid)
        job = {
            'jobId': f'job-{uuid.uuid4().hex[:12]}',
            'kind': str(kind or 'proc'),
            'channel': str(channel or ''),
            'label': str(label or ''),
            'pid': int(pid),
            'pgid': pgid,
            'isolated': pgid is not None,
            'startMark': _proc_start(pid),
            'state': 'running',
            'startedAt': time.time(),
            'meta': meta or {},
        }
        with _LOCK:
            _write(job)
            _prune_locked()
        return job
    except Exception:
        return None


def finish(job_id, state='done', detail=''):
    """Позначити job завершеним. Файл лишається ще KEEP_DONE_SEC, щоб UI встиг
    показати завершення, потім його прибирає prune."""
    if not _valid_id(job_id):
        return None
    with _LOCK:
        job = _read(job_id)
        if not job:
            return None
        job['state'] = state
        job['detail'] = str(detail or '')
        job['endedAt'] = time.time()
        try:
            return _write(job)
        except Exception:
            return None


def _prune_locked():
    """Прибрати завершені старші за KEEP_DONE_SEC і ті, чий процес зник."""
    try:
        names = [n for n in os.listdir(JOBS_DIR) if n.endswith('.json')]
    except OSError:
        return
    now = time.time()
    rows = []
    for n in names:
        job = _read(n[:-5])
        if not job:
            try:
                os.remove(os.path.join(JOBS_DIR, n))
            except OSError:
                pass
            continue
        if job.get('state') == 'running' and not is_alive(job.get('pid')):
            job['state'] = 'gone'
            job['endedAt'] = now
            try:
                _write(job)
            except Exception:
                pass
        if job.get('state') != 'running' and (now - (job.get('endedAt') or 0)) > KEEP_DONE_SEC:
            try:
                os.remove(os.path.join(JOBS_DIR, n))
            except OSError:
                pass
            continue
        rows.append(job)
    # Стеля: найстаріші завершені йдуть першими.
    if len(rows) > MAX_FILES:
        done = sorted((r for r in rows if r.get('state') != 'running'),
                      key=lambda r: r.get('endedAt') or 0)
        for r in done[:len(rows) - MAX_FILES]:
            try:
                os.remove(_path(r['jobId']))
            except OSError:
                pass


def list_jobs(channel=None, running_only=False):
    """Знімок реєстру, свіжий: спершу звіряємо живість, потім віддаємо."""
    with _LOCK:
        _prune_locked()
        try:
            names = [n for n in os.listdir(JOBS_DIR) if n.endswith('.json')]
        except OSError:
            names = []
        out = []
        for n in names:
            job = _read(n[:-5])
            if not job:
                continue
            if channel and job.get('channel') != channel:
                continue
            if running_only and job.get('state') != 'running':
                continue
            out.append(job)
    out.sort(key=lambda j: j.get('startedAt') or 0, reverse=True)
    return out


# ── гейт на вбивство ─────────────────────────────────────────────────────────

def stop(job_id, grace=0.4):
    """Зупинити зареєстрований job. Повертає {ok, reason, killed, pgid}.

    Кожна відмова має причину в reason, щоб з логу було видно, який саме гейт
    спрацював, а не глухе «нічого не сталось»."""
    if not _valid_id(job_id):
        return {'ok': False, 'reason': 'bad-id'}
    job = _read(job_id)
    if not job:                                   # гейт 1: тільки зареєстроване
        return {'ok': False, 'reason': 'unknown-job'}
    pid = job.get('pid')
    # Гейт 2 стоїть ПЕРШИМ навмисно: «цей pid чіпати не можна» важливіше за
    # «він уже завершився». Інакше відповідь на спробу вбити движок залежала б
    # від того, чи встиг prune переписати стан запису, і причина відмови
    # плавала б між protected-pid і already-finished.
    if _protected(pid):                           # гейт 2: захищені процеси
        return {'ok': False, 'reason': 'protected-pid'}
    if job.get('state') != 'running':
        return {'ok': True, 'reason': 'already-finished', 'killed': False}
    if not is_alive(pid):
        finish(job_id, 'gone')
        return {'ok': True, 'reason': 'already-dead', 'killed': False}
    mark = job.get('startMark') or ''
    if mark and _proc_start(pid) != mark:         # гейт 3: той самий процес?
        finish(job_id, 'gone', 'pid переюзаний ОС')
        return {'ok': False, 'reason': 'pid-reused'}

    if os.name == 'nt':
        try:
            subprocess.run(['taskkill', '/F', '/T', '/PID', str(pid)],
                           capture_output=True, timeout=5)
        except Exception:
            pass
        finish(job_id, 'stopped')
        return {'ok': True, 'reason': 'taskkill', 'killed': True, 'pgid': None}

    pgid = _safe_pgid(pid)                        # гейт 4: група лише своя
    try:
        if pgid is not None:
            os.killpg(pgid, signal.SIGTERM)
        else:
            os.kill(int(pid), signal.SIGTERM)
    except OSError:
        pass
    time.sleep(grace)
    if is_alive(pid):
        try:
            if pgid is not None:
                os.killpg(pgid, signal.SIGKILL)
            else:
                os.kill(int(pid), signal.SIGKILL)
        except OSError:
            pass
    if pgid is None:
        # Група була чужа, сигнал її не накрив: добиваємо прямих дітей окремо.
        try:
            subprocess.run(['pkill', '-KILL', '-P', str(pid)],
                           capture_output=True, timeout=3)
        except Exception:
            pass
    finish(job_id, 'stopped')
    return {'ok': True, 'reason': 'killed', 'killed': True, 'pgid': pgid}


def stop_channel(channel):
    """Зупинити всі живі jobs каналу. Повертає список результатів."""
    return [dict(stop(j['jobId']), jobId=j['jobId'])
            for j in list_jobs(channel=channel, running_only=True)]


# ── гейт на спавн ────────────────────────────────────────────────────────────

def _agent_argv(args):
    """agent: agent_worker.py <channel> <agentId>. Обидва аргументи мусять бути
    простими іменами: жодних слешів, крапок-крапок і порожнечі.

    Дві форми запуску, бо в пакованій збірці sys.executable це САМ ChatView, а не
    python: віддати йому .py неможливо, він просто підняв би другий сервер. Тому
    заморожений лаунчер має режим --agent-worker, який виконує той самий
    agent_worker.py з активного payload. У dev усе лишається як було."""
    channel = str(args.get('channel') or '').strip()
    agent_id = str(args.get('agentId') or '').strip()
    for v in (channel, agent_id):
        if not v or '/' in v or '\\' in v or '..' in v:
            raise ValueError('bad channel/agentId')
    if getattr(sys, 'frozen', False):
        return [sys.executable, '--agent-worker', channel, agent_id]
    return [sys.executable, os.path.join(CODE_DIR, 'agent_worker.py'), channel, agent_id]


# Білий список: іменований тип -> будівник argv. Тіло запиту дає ПАРАМЕТРИ, а
# не команду, тож через HTTP не можна запустити нічого, чого тут не написано.
SPAWN_KINDS = {
    'agent': _agent_argv,
}


def spawn(kind, args=None, label='', channel=''):
    """Запустити процес з білого списку у ВЛАСНІЙ сесії і зареєструвати його.

    Повертає (job, error). Довільний argv не приймається принципово: див.
    SPAWN_KINDS."""
    args = args or {}
    build = SPAWN_KINDS.get(str(kind))
    if build is None:
        return None, f'kind не дозволений: {kind}'
    try:
        argv = build(args)
    except Exception as e:
        return None, str(e)
    kw = ({'creationflags': subprocess.CREATE_NEW_PROCESS_GROUP}
          if os.name == 'nt' else {'start_new_session': True})
    try:
        proc = subprocess.Popen(argv, cwd=DIR, stdout=subprocess.DEVNULL,
                                stderr=subprocess.DEVNULL, **kw)
    except Exception as e:
        return None, f'spawn failed: {e}'
    job = register(kind, channel or args.get('channel') or '', proc.pid,
                   label=label, meta={'argv': argv[1:], 'args': args})
    return job, None
