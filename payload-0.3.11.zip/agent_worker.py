#!/usr/bin/env python3
"""Detached background AGENT worker for the «Процеси» panel (Phase 2, Vova 2026-07-10).

Spawned DETACHED by /api/agent-spawn (own session + process group) so it survives the
main turn, a new message, and even a ChatView restart. It runs ONE `claude -p <task>`
in its own --session-id + pgid, mirrors run_claude_stream's stream-json parse, and
writes per-agent state to disk:

  channels/<ch>/agents/<id>/status.json     live status (state,pid,pgid,progress,lastStep…)
  channels/<ch>/agents/<id>/progress.jsonl  append-only step/text stream
  channels/<ch>/agents/<id>/output.md       final result (written on done)

On done it auto-posts output as a card to the channel and emits an agent/done event so
the panel + feed reflect the result. Reattach/orphan-reconcile lives in server.py (it
scans status.json); this worker just runs one agent to completion.

Usage:  python agent_worker.py <channel> <agentId>
The spawn spec (task,label,model,sid) is read from the pre-written status.json.
Set AGENT_CLAUDE_BIN to override the claude binary (used by the cheap plumbing test).
"""
import os
import sys
import json
import time
import uuid
import tempfile
import subprocess
from datetime import datetime

import runner  # safe to import: runner guards its worker loop behind __main__
import jobs    # реєстр процесів + гейти на вбивство/спавн
import batch_publish  # S5 (specs/agent-batch-summary): спроба підсумку пачки


def _agent_dir(channel, agent_id):
    return os.path.join(runner.CHANNELS_DIR, channel, 'agents', agent_id)


def _now():
    return datetime.now().isoformat()


def _close_jobs(channel, agent_id, claude_job, state):
    """Зняти з реєстру обидва job-и агента: його claude і сам воркер.

    Свій jobId читаємо зі status.json НАПРИКІНЦІ, а не на старті: сервер
    дописує його вже після спавну, тож на старті файл його ще не має."""
    try:
        if claude_job:
            jobs.finish(claude_job.get('jobId'), state)
    except Exception:
        pass
    try:
        own = _read_status(channel, agent_id).get('jobId')
        if own:
            jobs.finish(own, state)
    except Exception:
        pass


def _read_status(channel, agent_id):
    try:
        return json.load(open(os.path.join(_agent_dir(channel, agent_id), 'status.json'),
                              encoding='utf-8')) or {}
    except Exception:
        return {}


def _write_status(channel, agent_id, patch):
    """Merge patch into status.json atomically (never raises)."""
    try:
        d = _agent_dir(channel, agent_id)
        os.makedirs(d, exist_ok=True)
        p = os.path.join(d, 'status.json')
        cur = _read_status(channel, agent_id)
        cur.update(patch)
        cur['updatedAt'] = _now()
        tmp = p + '.tmp'
        with open(tmp, 'w', encoding='utf-8') as f:
            json.dump(cur, f, ensure_ascii=False, indent=2)
        os.replace(tmp, p)
        return cur
    except Exception as e:
        runner.log(f'agent {agent_id}: status write failed: {e}')
        return {}


def _progress(channel, agent_id, rec):
    try:
        d = _agent_dir(channel, agent_id)
        os.makedirs(d, exist_ok=True)
        rec = dict(rec)
        rec.setdefault('ts', _now())
        with open(os.path.join(d, 'progress.jsonl'), 'a', encoding='utf-8') as f:
            f.write(json.dumps(rec, ensure_ascii=False) + '\n')
    except Exception:
        pass


def _post_card(channel, widgets, from_name, tag='agent'):
    """Append a result card to the channel so the agent's output shows up like any
    other bubble.

    Preferred path is render-message.cjs (the same one the hooks use: it also
    lazily registers a brand-new channel as a tab and can voice the card). A packaged
    desktop ships neither that script nor a guaranteed node, so it degrades to
    runner.append_message — literally the function the runner writes its own bubbles
    with. Without this fallback a detached agent finished silently in the desktop:
    the work was done, the result never reached the chat."""
    script = os.path.join(runner.DIR, 'render-message.cjs')
    node = runner._resolve_node()
    if os.path.exists(script) and os.path.isabs(node) and os.path.exists(node):
        tmp = None
        try:
            fd, tmp = tempfile.mkstemp(suffix='.json')
            os.close(fd)
            with open(tmp, 'w', encoding='utf-8') as f:
                json.dump(widgets, f, ensure_ascii=False)
            r = subprocess.run([node, script, tmp, from_name, tag, channel],
                               cwd=runner.DIR, timeout=25,
                               stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
            if r.returncode == 0:
                return
            runner.log(f'agent: render-message exited {r.returncode}, writing card directly')
        except Exception as e:
            runner.log(f'agent: post card via node failed: {e}, writing card directly')
        finally:
            if tmp:
                try:
                    os.remove(tmp)
                except OSError:
                    pass
    try:
        runner.append_message(channel, widgets, from_name, tag)
    except Exception as e:
        runner.log(f'agent: post card failed: {e}')


def _result_widgets(label, out, lang):
    """Фінальний текст агента у віджети, тією ж функцією, що й основний потік чату.

    Було: увесь вивід їхав ОДНИМ text-віджетом, тож навіть бездоганні ```chatui```
    блоки приїжджали в канал сирим JSON, а таблиця стіною тексту. Заголовок тепер
    окремий віджет і не зʼїдає вивід. ```plan``` вирізаємо: план каналу не агентова
    справа, і показувати його як текст теж не треба. Будь-яка поломка деградує у той
    самий один text-віджет, що був раніше, тобто гірше не стає ніколи.

    Заголовок і заглушка мовно залежні (specs/i18n-interface, К18): раніше тут стояв
    голий український рядок, і англійський інтерфейс бачив картку завершеного агента
    з украЇнським підписом усередині, попри обрану мову.

    `lang`, а НЕ `channel` (латання оберту 3, Ревізор 3: «ламає навмисно»). Було:
    цей заголовок читав current_lang(channel) У МОМЕНТ ЗАВЕРШЕННЯ ходу, а тіло
    `out` уже несло мову, запечену в промпт агента на СТАРТІ (agent_task_with_
    contract). Перемикання мови ПОСЕРЕД ходу агента (живо відтворено: заголовок
    англійською, тіло українською в одній картці) означало, що дві половини
    картки могли розійтись по мові. `lang` тепер той самий знімок, зафіксований
    ОДИН раз на старті run(), що й бачив сам двигун — картка або цілком стара
    мова, або цілком нова, ніколи мішанка."""
    head = {'type': 'header', 'title': runner._lang_text({'uk': f'🤖 {label} · агент завершив',
                                                            'en': f'🤖 {label} · agent finished'}, lang)}
    empty = {'type': 'text', 'text': runner._lang_text({'uk': '(агент завершив без тексту)',
                                                         'en': '(agent finished with no text)'}, lang)}
    body = (out or '').strip()
    if not body:
        return [head, empty]
    try:
        clean, _plan = runner.extract_plan_block(body)
        clean = (clean or '').strip()
    except Exception as e:
        runner.log(f'agent: plan strip failed ({e}), keeping raw output')
        clean = body
    # Вивід був самим лише планом: показувати нема чого, але й вивалювати план
    # у стрічку текстом теж не можна.
    if not clean:
        return [head, empty]
    try:
        widgets = runner.reply_to_widgets(clean)
    except Exception as e:
        runner.log(f'agent: reply_to_widgets failed ({e}), degrading to plain text')
        widgets = None
    return [head] + (widgets or [{'type': 'text', 'text': clean}])


def _summary_from(widgets, fallback):
    """Рядок для панелі «Процеси»: перша ЗМІСТОВНА проза, а не сирий JSON.

    Раніше сюди летіли перші 220 символів фінального тексту. Щойно агент почав
    відповідати віджетами, у панелі опинявся шматок JSON-блоку."""
    for w in widgets:
        if w.get('type') == 'text':
            t = (w.get('text') or '').strip()
            if t:
                return t[:220]
    for w in widgets:
        for key in ('text', 'title'):
            t = (w.get(key) or '').strip() if isinstance(w.get(key), str) else ''
            if t:
                return t[:220]
    return (fallback or '')[:220]


def _try_batch_summary(channel, agent_id):
    """S5 (specs/agent-batch-summary, К1/К2): спроба опублікувати підсумок пачки ПІСЛЯ
    того, як власний запис агента вже ліг на диск у термінальному стані, і ПІСЛЯ власної
    картки — виклик тут єдина спільна точка для КОЖНОГО шляху _run_impl() до
    термінального стану (порожня задача, провал спавну, зовнішній стоп, помилка ходу,
    успіх), а не копія виклику в пʼятьох місцях. Саме тому підсумок не зникає разом із
    тим шляхом, яким саме останній агент пачки дійшов до кінця: провал чи стоп лишають
    підсумок так само, як і успіх (К2). Жоден виняток звідси не сміє завалити воркер:
    агент, який упав через підсумок, гірший за відсутній підсумок."""
    try:
        record = _read_status(channel, agent_id)
        agents_dir = os.path.join(runner.CHANNELS_DIR, channel, 'agents')
        batch_publish.try_publish_batch_summary(
            runner.CHANNELS_DIR, channel, agents_dir, record, _post_card, log=runner.log)
    except Exception as e:
        runner.log(f'agent {agent_id}: batch summary attempt failed: {e}')


def run(channel, agent_id):
    """Тонка обгортка над _run_impl: `finally` гарантує, що спроба підсумку пачки
    відбудеться РІВНО ОДИН раз на кожен запуск воркера, вже ПІСЛЯ того, як _run_impl
    дописав термінальний стан і власну картку (усі його return роблять це ДО виходу)."""
    try:
        _run_impl(channel, agent_id)
    finally:
        _try_batch_summary(channel, agent_id)


def _run_impl(channel, agent_id):
    # К18 (латання оберту 3, Ревізор 3): мова ФІКСУЄТЬСЯ тут, ОДИН раз, на самому
    # старті ходу, і несеться крізь усю функцію тією самою змінною `lang`, а не
    # перечитується per-виклик через current_lang(channel). Було: заголовок і
    # службові підписи карти читали поточну мову В МОМЕНТ ЗАВЕРШЕННЯ, а тіло, яке
    # пише сам двигун, уже отримало мову, запечену в промпт на СТАРТІ (нижче,
    # agent_task_with_contract). Перемикання мови ПОСЕРЕД ходу давало картку з
    # заголовком однією мовою і тілом іншою в тому самому повідомленні.
    lang = runner.current_lang(None)
    spec = _read_status(channel, agent_id)
    task = (spec.get('task') or '').strip()
    label = spec.get('label') or runner._lang_text({'uk': 'Агент', 'en': 'Agent'}, lang)
    # claude --session-id must be a valid UUID; the server writes one, this is the fallback.
    sid = spec.get('sid') or str(uuid.uuid4())
    if not task:
        _write_status(channel, agent_id, {'state': 'error',
                      'summary': runner._lang_text({'uk': 'порожня задача', 'en': 'empty task'}, lang)})
        return

    claude_bin = os.environ.get('AGENT_CLAUDE_BIN', runner.CLAUDE_BIN)
    model_name = spec.get('model') or runner.channel_model(channel, task)
    # Рівень зусиль приходить зі спеки (agent-run.cjs --effort). Haiku не має цього
    # параметра взагалі, тому для нього прапор просто не додаємо.
    effort = (spec.get('effort') or '').strip()
    if effort and 'haiku' in (model_name or '').lower():
        effort = ''
    # Контракт віджетів клеїться ТУТ, на боці сервера, а не в agent-run.cjs: так він
    # діє для всіх способів спавну (місток, /api/agent-spawn з UI, майбутні клієнти).
    # Без нього агент бачить лише голу задачу і фізично не знає, що віджети існують.
    cmd = [claude_bin, '-p', runner.agent_task_with_contract(task, lang),
           *runner._resolve_model_args(model_name),
           *(['--effort', effort] if effort else []),
           '--disallowedTools', *runner.DISALLOWED_TOOLS,
           '--output-format', 'stream-json', '--verbose',
           '--include-partial-messages',
           '--session-id', sid,
           # A detached agent has no interactive permission UI, so it must not block on
           # a prompt; it runs autonomously (still bounded by --disallowedTools).
           '--permission-mode', 'bypassPermissions']

    env = runner._child_env(channel)
    # Маркер для agent-detach-gate.cjs. Гейт жене довгі задачі з Agent tool у
    # цей самий місток, але ВСЕРЕДИНІ detached-агента він зайвий: цей хід не
    # вмирає від нового повідомлення Vova, тож субагент тут безпечний. Без
    # маркера гейт не відрізнить detached-агента від звичайного канального ходу
    # (у обох CHATVIEW_RUNNER=1) і зациклив би агента на самого себе.
    env['CHATVIEW_DETACHED_AGENT'] = '1'
    try:
        proc = subprocess.Popen(
            cmd, cwd=runner.REPO_ROOT, stdout=subprocess.PIPE, stderr=subprocess.PIPE,
            text=True, bufsize=1, env=env, **runner._PROC_GROUP_KW)
    except Exception as e:
        _write_status(channel, agent_id, {'state': 'error', 'summary': f'spawn failed: {e}'})
        return

    try:
        pgid = os.getpgid(proc.pid)
    except Exception:
        pgid = proc.pid
    # Реєструємо claude агента окремим job: воркер сидить у своїй групі, а його
    # claude у СВОЇЙ, тож сигнал групі воркера claude не накриє. Стоп агента
    # б'є обидва job-и через гейт (jobs.stop), а не по голому pid з диска.
    claude_job = jobs.register('agent-claude', channel, proc.pid, label=label,
                               meta={'agentId': agent_id, 'sid': sid})
    # 'model' дописуємо РЕЗОЛВНУТИЙ, а не той, що прийшов у спеці. Спавн без --model клав
    # у status.json null, і панель агентів не мала що показати, хоча модель насправді відома:
    # її щойно вибрав channel_model() з налаштувань каналу (а для 'auto' ще й зі складності
    # задачі). Пишемо саме тут, у момент справжнього старту процесу, тому бейдж у UI показує
    # те, що реально крутиться, а не те, що попросили.
    _write_status(channel, agent_id, {'state': 'running', 'pid': proc.pid, 'pgid': pgid,
                                      'claudeJobId': (claude_job or {}).get('jobId'),
                                      'sid': sid, 'startedAt': _now(), 'model': model_name,
                                      'progressPct': 3, 'lastStep': 'старт'})
    runner.emit_event(channel, {'kind': 'agent', 'phase': 'start', 'name': label,
                                'agentId': agent_id, 'detail': task[:80]})

    steps_done = 0
    text = ''
    # Помилка ходу, оголошена самим CLI у фінальній події (`result.is_error`). Раніше
    # її тут не читали взагалі: `text = ev.get('result')` брав рядок за будь-якої
    # ознаки, тож «You've hit your session limit · resets 12:20am (Europe/Kiev)»
    # ставав «виводом агента» і публікувався карткою «· агент завершив». Гейт нижче
    # (`not body and rc not in (0, None)`) на це не спрацьовував саме тому, що body
    # був НЕ порожній: у ньому лежав текст помилки.
    result_err = ''
    try:
        for line in iter(proc.stdout.readline, ''):
            # An external stop flips status→stopped; bail promptly so we don't overwrite it.
            if steps_done % 1 == 0 and _read_status(channel, agent_id).get('state') == 'stopped':
                break
            line = line.strip()
            if not line:
                continue
            try:
                ev = json.loads(line)
            except Exception:
                continue
            t = ev.get('type')
            if t == 'assistant':
                for b in (ev.get('message', {}) or {}).get('content', []):
                    if b.get('type') == 'tool_use':
                        name = b.get('name', '')
                        lbl = runner._tool_label(name, b.get('input'))
                        steps_done += 1
                        last_step = (f'{name}: {lbl}' if lbl else name)[:140]
                        _progress(channel, agent_id, {'phase': 'step', 'tool': name, 'step': last_step})
                        _write_status(channel, agent_id, {'lastStep': last_step,
                                      'progressPct': min(95, 5 + steps_done * 7)})
            elif t == 'stream_event':
                inner = ev.get('event', {}) or {}
                if inner.get('type') == 'content_block_delta':
                    d = inner.get('delta', {}) or {}
                    if d.get('type') == 'text_delta' and d.get('text'):
                        text += d['text']
            elif t == 'result':
                if ev.get('is_error'):
                    result_err = (ev.get('result') or 'unknown error')
                else:
                    text = ev.get('result') or text
    except Exception as e:
        runner.log(f'agent {agent_id}: parse error: {e}')

    err_txt = ''
    try:
        err_txt = (proc.stderr.read() or '').strip()
    except Exception:
        err_txt = ''
    try:
        rc = proc.wait(timeout=10)
    except Exception:
        rc = proc.returncode

    # If /api/agent-stop marked us stopped, leave that state as-is.
    if _read_status(channel, agent_id).get('state') == 'stopped':
        _close_jobs(channel, agent_id, claude_job, 'stopped')
        runner.emit_event(channel, {'kind': 'agent', 'phase': 'stopped', 'name': label,
                                    'agentId': agent_id})
        return

    body = (text or '').strip()
    # claude failed (limit / bad args / auth / overload): surface the real reason, never
    # fake "done" and never dump the CLI's raw English into the feed.
    #
    # Два різні провали, один вихід. `result_err` = CLI сам сказав «цей хід помилковий»
    # (сюди потрапляє вичерпаний ліміт: процес при цьому виходить штатно і навіть несе
    # текст). `rc != 0` без тексту = процес впав, не дійшовши до фінальної події.
    # Обидва йдуть через ті самі класифікатори чату, тож формулювання про ліміт у
    # стрічці одне, звідки б він не прилетів.
    fail_err = result_err or ('' if body else (err_txt or (
        f'agent exited rc={rc}' if rc not in (0, None) else '')))
    if fail_err:
        try:
            msg = runner.classify_failure(fail_err, False, channel)['text']
        except Exception:
            msg = runner._lang_text({'uk': 'Агент не довіз результат',
                                      'en': 'Agent did not deliver a result'}, lang)
        _write_status(channel, agent_id, {'state': 'error', 'progressPct': 100,
                      'summary': msg[:300], 'endedAt': _now()})
        _close_jobs(channel, agent_id, claude_job, 'error')
        runner.emit_event(channel, {'kind': 'agent', 'phase': 'error', 'name': label,
                                    'agentId': agent_id, 'detail': msg[:300]})
        runner.log(f'agent {agent_id}: failed ({msg}) raw={fail_err[:120]!r}')
        cards = runner.agent_failure_widgets(label, fail_err, channel)
        # Ліміт може вдарити ПОСЕРЕД ходу, і тоді агент устиг щось написати. Викидати
        # це разом із помилкою = втратити готову роботу мовчки, тому недописане їде
        # окремим блоком під карткою, підписане як недописане.
        if body:
            # `body` тут це недописаний вивід ДВИГУНА: він уже несе мову, запечену
            # на старті (як і в _result_widgets), тому підпис до нього бере ту саму
            # заморожену `lang`, а не поточну current_lang(channel).
            cards.append({'type': 'text', 'detail': True,
                          'title': runner._lang_text(
                              {'uk': 'Що агент устиг написати до обриву',
                               'en': 'What the agent wrote before it broke off'}, lang),
                          'text': body})
        _post_card(channel, cards, from_name=label, tag='agent')
        return

    out = body or runner._lang_text({'uk': '(агент завершив без тексту)',
                                      'en': '(agent finished with no text)'}, lang)
    try:
        with open(os.path.join(_agent_dir(channel, agent_id), 'output.md'), 'w',
                  encoding='utf-8') as f:
            f.write(out)
    except Exception:
        pass
    widgets = _result_widgets(label, out, lang)
    _write_status(channel, agent_id, {'state': 'done', 'progressPct': 100,
                                      'summary': _summary_from(widgets, out),
                                      'endedAt': _now()})
    _close_jobs(channel, agent_id, claude_job, 'done')
    runner.emit_event(channel, {'kind': 'agent', 'phase': 'done', 'name': label,
                                'agentId': agent_id})
    # Заголовок окремим віджетом, а НЕ сирим HTML і не title поверх усього виводу:
    # V2 свідомо екранує розмітку (див. widgets/Text.tsx), а вивід тепер розібраний
    # на віджети, тож йому потрібна своя шапка, а не обгортка.
    _post_card(channel, widgets, from_name=label, tag='agent')


if __name__ == '__main__':
    if len(sys.argv) < 3:
        sys.stderr.write('usage: agent_worker.py <channel> <agentId>\n')
        sys.exit(2)
    run(sys.argv[1], sys.argv[2])
