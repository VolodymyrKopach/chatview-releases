#!/usr/bin/env python3
"""Розповзання: дані класу переїжджають під корінь свого класу (К5).

ЩО ЦЕ. Перепис (`specs/user-data-architecture/inventory.md`, розділ 4) знайшов три
місця, де дані ОДНОГО класу лежать не під його коренем, а під чужим:

    <дім>/assets/media       ->  <дім>/channels/_media        медіа з повідомлень
    <дім>/apps/<id>/state*   ->  <дім>/apps/_state/<id>/       накопичене в гаджеті
    <дім>/canvas-cmd/data    ->  <дім>/canvas-data             сторінки канви

Кожен рядок це відповідь на конкретну аварію, а не наведення краси:

  * `assets/` заявлена застосунком як READ-ONLY актив і копіюється з бандла на
    КОЖНОМУ старті (`desktop/entry.py:367`, `seed_readonly_assets`). Туди ж
    `media_normalize.py` кладе всі картинки, відео і файли з чатів людини:
    заміряно 585 МБ, 1446 файлів. Тобто щостарту застосунок ллє свій бандл поверх
    теки, у якій лежить уся візуальна історія людини. Сьогодні `copytree` лише
    доливає і нічого не стирає, тому втрати ще не сталось; але воротар чистоти
    ПРЯМО дозволяє `assets` з розширеннями картинок (`clean_guard.py:129`), і це
    вже не потенційна, а справжня дірка: медіа автора має право поїхати в
    роздавальний артефакт під виглядом теки застосунку.
  * тека гаджета тримає одночасно КОД (`manifest.json`, `view.html`, `skills/`,
    `_lib`) і НАКОПИЧЕНЕ людиною (`state.json`, журнал знімків, чат гаджета,
    вкладення). Оновлення гаджета це заміна коду, і поки код і стан в одній теці,
    кожне оновлення проходить упритул до даних людини. Розділені шляхом, вони
    більше не можуть зачепити одне одного помилково.
  * канва мала ТРИ незалежні дороги до тих самих даних: реєстр казав
    `canvas-data`, `server.py` брав `CANVAS_DATA_DIR` (у деві це
    `tools/canvas-cmd/data`, 701 МБ), а `project_state.py` йшов туди ж третім
    власним `join(dir, '..', '..', 'canvas-cmd', 'data', ...)`. Три дороги на одні
    дані вже давали розбіжність: перелік сторінок лишався порожнім, поки запис
    шапок ішов успішно.

КУДИ САМЕ ЇДЕ, І ЧОМУ БЕЗ НОВИХ КЛАСІВ У РЕЄСТРІ. Обидва нові корені це ХВІСТ під
коренем УЖЕ наявного класу, виданий тією самою `entities.path_for`:

    media_root()        = path_for('channel', '_media')
    gadget_state_root() = path_for('gadget',  '_state')

Так вирішено свідомо. Медіа це «файли, які людина сама перетягнула в розмову»,
тобто дослівно те, що реєстр записав у `why_lost` класу `channel`; накопичене в
гаджеті це дослівно `why_lost` класу `gadget` («задачі, чернетки, картки
клієнтів»). Окремий клас під це не потрібен, а коштував би дорого: клас, доданий
через `register()` з чужого модуля, існує лише поки той модуль хтось імпортував,
тому воротар чистоти, бекап і тест порожнечі бачили б його ЧЕРЕЗ РАЗ. Хвіст під
наявним коренем натомість успадковує все і одразу: заборону воротаря (`channels/`
і `apps/` заборонені цілком), переїзд у шухляду (S5 везе корінь класу разом з
усім, що під ним), експорт і бекап. Підкреслено ще й іменем: `_media` і `_state`
починаються з підкреслення, тому `entities.safe_id` їх відкидає і жоден сканер
класу не сплутає їх з екземпляром (та сама вже вживана в `apps/` домовленість, що
й `_lib`, `_runtime`).

ЯК ЦЕ ПЕРЕЇЖДЖАЄ. Механізм переносу НЕ пишеться тут заново: береться той самий,
що S5 (`home_migrate`), і його докстрінг прямо каже, що S6 ним скористається.
Звідти три правила, які тут не повторюються, а викликаються: rename де можливо
(атомарно), інакше повна копія зі звіркою «файлів і байтів увійшло / вийшло» і
видаленням оригіналу ОСТАННІМ; недоробка лишається під `PARTIAL_MARK` і
підмітається наступним стартом; мітка `running` до першого переносу відрізняє нашу
обірвану роботу від чужих файлів під тим самим іменем. Своя тут лише мітка
(`data/.spread`), бо це окрема, незалежна від шухляд подія: розповзання лікується
і на старій розкладці дому, і на новій.

ДЕВ-ЗАПУСК З РЕПО НЕ ЧІПАЄМО, І ЦЕ НЕ-ЦІЛЬ ЗІ СПЕКИ, А НЕ НЕДОРОБКА. Канва в
дев-репо лежить у `tools/canvas-cmd/data`, тобто ПОЗА домівкою (`tools/viz/chat`).
`canvas_root()` там і далі віддає історичну теку, а переїзд її не бачить рівно тим
самим правилом, яким S5 не бачить нічого поза домівкою. Один корінь тут означає
«одна функція, яка дає відповідь», а не «одна тека в обох світах»: до цієї правки
відповідей було три і вони розходились, тепер вона одна і її видно.

СТАРА АДРЕСА В БРАУЗЕРІ. У 15 663 збережених повідомленнях автора вже стоїть
`/assets/media/<hash>-<name>`, а в стані гаджетів `/apps/<id>/uploads/<file>`.
Файли переїхали, і ці адреси мусять і далі відкриватись, інакше «переїзд» на екрані
людини нічим не відрізняється від втрати. Тому `legacy_static_path()` віддає для
такої адреси шлях у НОВОМУ корені (і лише якщо файл там справді є). Це друга
АДРЕСА, а не друге сховище: тека одна, і читає її одна функція. Повідомлення, яке
пройде нормалізацію ще раз, перепишеться на канонічну адресу саме через цей місток.
"""
import io
import os
import json
import time

import entities
import home_migrate as hm

#: Версія розкладки «дані класу під коренем свого класу». Пишеться в `data/.spread`.
SPREAD_VERSION = 1

#: Мітка. Лежить поруч з міткою шухляд (`data/.schema`), бо описує ту саму домівку,
#: але окремим файлом: розповзання і шухляди це дві незалежні події, і спільна мітка
#: означала б, що одна з них мовчки скасовує іншу.
MARK_FILE = '.spread'

RUNNING = hm.RUNNING
DONE = hm.DONE

#: Хвости під коренями наявних класів. Підкреслення тут несе роботу, а не стиль:
#: `entities.safe_id` відкидає імена, що починаються з нього, тому сканер класу
#: ніколи не візьме цю теку за екземпляр.
MEDIA_LEAF = '_media'
STATE_LEAF = '_state'

#: Що саме в теці гаджета є НАКОПИЧЕНИМ, а не кодом. `seed.json` тут навмисно нема:
#: це куратований знімок, який їде РАЗОМ з гаджетом (`_errors_monitor_action` читає
#: його як запасне джерело даних), тобто частина застосунку, а не людини.
GADGET_STATE_NAMES = ('state.json', 'state.history.json', 'chat.json', 'uploads')

#: Стара тека медіа під коренем застосунку і стара адреса до неї.
LEGACY_MEDIA_REL = ('assets', 'media')
LEGACY_MEDIA_URL = '/assets/media/'

#: Хвіст старої адреси вкладень гаджета: `/apps/<id>/uploads/<file>`.
LEGACY_APPS_URL = '/apps/'
UPLOADS_MARK = '/uploads/'


# ── корені класів ───────────────────────────────────────────────────────────

def media_root(home=None, env=None):
    """Єдина тека медіа з повідомлень. -> абсолютний шлях.

    Береться з `entities.path_for`, а не складається поруч: доти доки корінь можна
    зібрати ще десь, його там і збиратимуть, і саме так медіа опинились у теці
    застосунку."""
    return entities.path_for('channel', MEDIA_LEAF, home=home, env=env)


def gadget_state_root(home=None, env=None):
    """Тека, під якою лежить НАКОПИЧЕНЕ в гаджетах, окремо від їхнього коду."""
    return entities.path_for('gadget', STATE_LEAF, home=home, env=env)


def gadget_state_dir(gid, home=None, env=None):
    """Тека стану ОДНОГО гаджета. Той самий контроль ідентифікатора, що й у сервера.

    Помилка замість тихої підстановки навмисно: ідентифікатор приходить із запиту і
    стає шляхом, тому «поганий gid» мусить впертись тут, а не створити теку з іменем
    `..` десь вище кореня."""
    if not entities.safe_id(gid):
        raise ValueError('поганий ідентифікатор гаджета: %r' % (gid,))
    return entities.path_for('gadget', STATE_LEAF, gid, home=home, env=env)


def legacy_canvas_dir(home=None, env=None):
    """Історична тека даних канви поруч з репозиторієм, або ''.

    Два кандидати і той самий порядок, що в `server._resolve_canvas_base`: спершу
    розкладка репозиторію (`tools/canvas-cmd` на дві теки вище чату), потім плаский
    архів (`<корінь>/canvas-cmd` поруч з чатом). Порядок повторено дослівно, бо
    інакше дві функції відповідали б на одне питання по-різному, а це рівно та
    хвороба, від якої цей модуль."""
    home = home or entities.data_root(env)
    for base in (os.path.join(os.path.dirname(os.path.dirname(home)), 'canvas-cmd'),
                 os.path.join(os.path.dirname(home), 'canvas-cmd')):
        cand = os.path.join(base, 'data')
        if os.path.isdir(cand):
            return cand
    return ''


def canvas_root(home=None, env=None):
    """ЄДИНА відповідь на питання «де лежать дані канви». -> абсолютний шлях.

    Три гілки, кожна названа:

      1. `CANVAS_DATA_DIR` у оточенні. Це не спадок: саме ним пакована апка
         (`desktop/entry.py:916`) прибиває канву до `<дім>/canvas-data`. Явна воля
         запуску сильніша за будь-яку нашу здогадку.
      2. Дев-запуск з репозиторію (`CHATVIEW_HOME` не виставлений) з наявною
         історичною текою: віддаємо її. Не-ціль спеки сказана дослівно:
         «`tools/canvas-cmd/data` у деві лишається де лежить, поки цього не
         попросять окремо». 701 МБ канви автора не переїжджає тому, що комусь
         захотілось симетрії.
      3. Решта: корінь класу з реєстру. Саме сюди дивиться пакована збірка, якщо
         її підняли без лаунчера, і саме цим ця функція краща за старий фолбек, який
         у такому разі показував на `~/Library/canvas-cmd/data`, тобто в нікуди."""
    env = os.environ if env is None else env
    override = (env.get('CANVAS_DATA_DIR') or '').strip()
    if override:
        return override
    if not env.get('CHATVIEW_HOME'):
        legacy = legacy_canvas_dir(home, env)
        if legacy:
            return legacy
    return entities.path_for('canvas', home=home, env=env)


# ── адреси в браузері ───────────────────────────────────────────────────────

def url_for(path, home=None, env=None):
    """Абсолютний шлях під домівкою -> адреса, за якою його віддає сервер.

    Адреса ВИВОДИТЬСЯ зі шляху, а не пишеться поруч константою. Константа поруч це
    другий опис того самого місця, і розходиться він мовчки: спершу файл переїжджає,
    потім місяцями ніхто не бачить, що картинки не відкриваються."""
    home = home or entities.data_root(env)
    rel = os.path.relpath(path, home).replace('\\', '/')
    if rel.startswith('..') or os.path.isabs(rel):
        raise ValueError('шлях %r лежить поза домівкою %r: адреси для нього немає'
                         % (path, home))
    return '/' + rel


def media_url(home=None, env=None):
    """Адресний префікс медіа, з косою в кінці: `/channels/_media/`."""
    return url_for(media_root(home, env), home, env) + '/'


def _safe_child(root, tail):
    """`root` + перевірений хвіст, або '' якщо хвіст виводить з-під кореня."""
    try:
        segs = entities._segments(tail)
    except ValueError:
        return ''
    return os.path.join(root, *segs)


def legacy_static_path(url, home=None, env=None):
    """Стара адреса -> файл у НОВОМУ корені, або '' якщо це не наш випадок.

    Повертає шлях ЛИШЕ коли файл там справді лежить. Порожній рядок означає «віддавай
    як завжди», тому до переїзду все працює старим шляхом, а після переїзду тим самим
    посиланням віддається новий файл. Проміжного стану, у якому картинка зникає, не
    існує ні на мить."""
    if not isinstance(url, str) or not url.startswith('/'):
        return ''
    home = home or entities.data_root(env)
    target = ''
    if url.startswith(LEGACY_MEDIA_URL):
        target = _safe_child(media_root(home, env), url[len(LEGACY_MEDIA_URL):])
    elif url.startswith(LEGACY_APPS_URL) and UPLOADS_MARK in url:
        gid, _, tail = url[len(LEGACY_APPS_URL):].partition(UPLOADS_MARK)
        if entities.safe_id(gid) and tail:
            target = _safe_child(gadget_state_dir(gid, home, env),
                                 'uploads/' + tail)
    if target and os.path.isfile(target):
        return target
    return ''


# ── мітка переїзду ──────────────────────────────────────────────────────────

def mark_path(home):
    """`<дім>/data/.spread`."""
    return os.path.join(home, 'data', MARK_FILE)


def read_mark(home):
    """Мітка або None. Нечитабельна мітка це теж None: ціна повторного проходу
    нульова (усі кроки ідемпотентні), а падати на одному зіпсованому байті означало б
    застосунок, який не стартує."""
    try:
        with io.open(mark_path(home), encoding='utf-8') as fh:
            data = json.loads(fh.read() or 'null')
    except Exception:
        return None
    return data if isinstance(data, dict) else None


def _write_mark(home, status, extra=None):
    path = mark_path(home)
    hm._ensure_dir(os.path.dirname(path))
    body = {'version': SPREAD_VERSION, 'status': status, 'at': time.time()}
    body.update(extra or {})
    tmp = path + '.tmp'
    with io.open(tmp, 'w', encoding='utf-8') as fh:
        json.dump(body, fh, ensure_ascii=False, indent=1)
        fh.write('\n')
        fh.flush()
        os.fsync(fh.fileno())
    os.replace(tmp, path)
    hm._sync_dir(os.path.dirname(path))
    return body


# ── план переїзду ───────────────────────────────────────────────────────────

def _gadget_ids(home, env=None):
    """Ідентифікатори гаджетів на диску. Службові теки (`_lib`, `_runtime`) і
    реєстр (`index.json`) відкидає той самий `safe_id`, що й сканер класу."""
    root = entities.path_for('gadget', home=home, env=env)
    try:
        names = sorted(os.listdir(root))
    except OSError:
        return []
    return [n for n in names
            if entities.safe_id(n) and os.path.isdir(os.path.join(root, n))]


def plan(home=None, env=None):
    """Що і куди їде. -> (moves, skipped).

    `moves` це [{case, what, src, dst, present}], `skipped` це [{case, src, why}].
    Джерело шляхів одне на обидва списки: функції-корені вище."""
    env = os.environ if env is None else env
    home = home or entities.data_root(env)
    moves, skipped = [], []

    # 1. Медіа з повідомлень: з теки застосунку під корінь свого класу.
    src = os.path.join(home, *LEGACY_MEDIA_REL)
    moves.append({'case': 'media', 'what': '/'.join(LEGACY_MEDIA_REL),
                  'src': src, 'dst': media_root(home, env),
                  'present': os.path.exists(src)})

    # 2. Накопичене в гаджетах: з теки коду гаджета під корінь стану.
    for gid in _gadget_ids(home, env):
        gdir = entities.path_for('gadget', gid, home=home, env=env)
        for name in GADGET_STATE_NAMES:
            src = os.path.join(gdir, name)
            moves.append({'case': 'gadget-state', 'what': '%s/%s' % (gid, name),
                          'src': src,
                          'dst': os.path.join(gadget_state_dir(gid, home, env), name),
                          'present': os.path.exists(src)})

    # 3. Канва: історична тека -> єдиний корінь. Гейт тут не «чи під домівкою», а
    #    «чи єдиний корінь УСЕ ЩЕ показує сюди»: рівно це і означає «старий шлях
    #    лишається читабельним лише через міграцію». У дев-запуску з репо
    #    `canvas_root()` свідомо віддає ту саму історичну теку (не-ціль спеки), тому
    #    src == dst і не рухається НІЧОГО. У пакованій збірці корінь показує в дім,
    #    тому стрей-тека, яку колись зробив старий фолбек, приїжджає під клас.
    legacy = legacy_canvas_dir(home, env)
    dst = canvas_root(home, env)
    same = legacy and os.path.realpath(legacy) == os.path.realpath(dst)
    if legacy and not same:
        moves.append({'case': 'canvas', 'what': legacy,
                      'src': legacy, 'dst': dst,
                      'present': os.path.exists(legacy)})
    elif same:
        skipped.append({
            'case': 'canvas', 'src': legacy,
            'why': 'єдиний корінь канви і є ця тека (%s): дев-запуск з репозиторію '
                   'це не-ціль спеки, і рухати там нема чого' % legacy})
    return moves, skipped


# ── сам переїзд ─────────────────────────────────────────────────────────────

def _move_one(src, dst, resumed, say):
    """Перенести один вузол. -> ('rename'|'copy'|'merge'|'kept', [конфлікти]).

    Уся небезпечна робота лежить у `home_migrate`: rename де можливо, інакше копія
    зі звіркою і видаленням оригіналу останнім. Тут лише розбір випадку «ціль уже
    існує», і він свідомо різний для теки і для файла: теки можна доробити
    поелементно, а два файли під одним іменем це або наша обірвана робота (мітка
    `running` це доводить), або чужий файл, якого ми не чіпаємо."""
    hm._ensure_dir(os.path.dirname(dst))
    if not os.path.exists(dst):
        return hm._move(src, dst), []
    if os.path.isdir(src) and os.path.isdir(dst):
        return 'merge', hm._merge_into(src, dst, resumed, say)
    if resumed:
        # Під фінальним іменем ціль зʼявляється ЛИШЕ після повного переносу, тому це
        # наш власний, доведений до кінця крок, обірваний перед прибиранням.
        hm._drop(src)
        return 'kept', []
    return 'kept', [{'src': src, 'dst': dst,
                     'why': 'обидві копії існують, а мітки обірваного переїзду нема: '
                            'це не наша недоробка, тому не чіпаємо'}]


def unspread(home=None, env=None, log=None):
    """Звести розповзання: три випадки під корінь свого класу. -> звіт (dict).

    Ідемпотентна: другий виклик на вже зведеній домівці не робить нічого і каже про
    це в `reason`. Обірваний виклик доводиться наступним стартом, а не починається з
    нуля."""
    env = os.environ if env is None else env
    home = home or entities.data_root(env)
    say = log or (lambda _m: None)

    was = read_mark(home)
    if was and was.get('version') == SPREAD_VERSION and was.get('status') == DONE:
        return {'moved': False, 'resumed': False, 'version': SPREAD_VERSION,
                'reason': 'розповзання вже зведене (data/.spread, версія %d)'
                          % SPREAD_VERSION,
                'moves': [], 'skipped': [], 'conflicts': [],
                'filesIn': 0, 'bytesIn': 0, 'filesOut': 0, 'bytesOut': 0}

    resumed = bool(was and was.get('status') == RUNNING)
    moves, skipped = plan(home, env)
    todo = [m for m in moves if m['present']]
    _write_mark(home, RUNNING, {'cases': sorted({m['case'] for m in todo})})

    # Підмести недоробки минулого обриву в кожній цільовій теці. Під іменем з
    # PARTIAL_MARK за побудовою не існує нічого завершеного.
    for parent in sorted({os.path.dirname(m['dst']) for m in todo}):
        if os.path.isdir(parent):
            hm.sweep_partials(parent)

    done, conflicts = [], []
    files_in = bytes_in = files_out = bytes_out = 0
    say('зведення розповзання %s: вузлів до переносу %d%s'
        % (home, len(todo), ', продовжуємо обірваний' if resumed else ''))
    for m in todo:
        src, dst = m['src'], m['dst']
        was_files, was_bytes = hm.weigh(src)
        how, got = _move_one(src, dst, resumed, say)
        conflicts.extend(got)
        out_files, out_bytes = hm.weigh(dst)
        files_in += was_files
        bytes_in += was_bytes
        files_out += out_files
        bytes_out += out_bytes
        done.append({'case': m['case'], 'what': m['what'], 'src': src, 'dst': dst,
                     'how': how, 'files': was_files, 'bytes': was_bytes,
                     'filesAfter': out_files, 'bytesAfter': out_bytes})
        say('  %-13s %-6s %s -> %s (%d файлів, %d Б)'
            % (m['case'], how, m['what'], os.path.relpath(dst, home),
               was_files, was_bytes))
    for item in skipped:
        say('  поза домівкою: %-8s %s' % (item['case'], item['why']))

    _write_mark(home, DONE, {'cases': sorted({m['case'] for m in done})})
    return {'moved': bool(done), 'resumed': resumed, 'version': SPREAD_VERSION,
            'reason': '', 'moves': done, 'skipped': skipped, 'conflicts': conflicts,
            'filesIn': files_in, 'bytesIn': bytes_in,
            'filesOut': files_out, 'bytesOut': bytes_out}


def unspread_on_start(home=None, env=None, log=None):
    """Точка старту. Викликається ПЕРЕД переїздом у шухляди (`home_migrate`).

    Порядок саме такий, бо S5 везе КОРІНЬ КЛАСУ цілком: усе, що ця функція встигла
    завести під корінь, їде в шухляду разом з ним одним rename. Зворотний порядок
    працював би теж (обидві функції беруть шляхи з `path_for`, тобто вже з шухлядою),
    але лишав би зайвий прохід по щойно перенесеній домівці.

    Гейта тут НЕМА, на відміну від S5, і це не забудькуватість. S5 чекає, поки читачі
    навчаться шухлядам, бо інакше дані поїдуть з-під них. Тут читач уже перевчений
    цією ж правкою: усі, хто читає медіа і стан гаджета, беруть шлях з функцій вище,
    а стара адреса лишається живою через `legacy_static_path`. Чекати нема на що."""
    env = os.environ if env is None else env
    home = home or entities.data_root(env)
    try:
        return unspread(home, env, log)
    except Exception as e:
        # Розповзання це давня хвороба, а не аварія: застосунок жив з ним роками.
        # Тому збій переїзду мусить лишити людину з робочим застосунком і гучним
        # рядком у лозі, а не з вікном, яке не відкривається.
        (log or (lambda _m: None))('зведення розповзання не вдалось: %s' % e)
        return {'moved': False, 'resumed': False, 'version': SPREAD_VERSION,
                'reason': 'збій: %s' % e, 'moves': [], 'skipped': [],
                'conflicts': [], 'filesIn': 0, 'bytesIn': 0,
                'filesOut': 0, 'bytesOut': 0}


if __name__ == '__main__':
    import sys
    target = sys.argv[1] if len(sys.argv) > 1 else None
    report = unspread(target, env={'CHATVIEW_HOME': target} if target else None,
                      log=lambda m: print(m))
    print(json.dumps({k: v for k, v in report.items() if k != 'moves'},
                     ensure_ascii=False, indent=1))
