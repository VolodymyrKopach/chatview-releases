#!/usr/bin/env python3
"""ChatView cross-platform service layer.

ONE place for every OS-specific quirk that used to be scattered across entry.py,
runner.py and server.py as inline `sys.platform` checks. The rest of the codebase
depends on the abstract `Platform` interface (Dependency Inversion), never on
`sys.platform` directly, so adding/adjusting an OS is a local change here.

Patterns:
  * Strategy      - MacPlatform / WindowsPlatform / LinuxPlatform each own only
                    their own OS behaviour (Single Responsibility).
  * Factory Method - `Platform.current()` returns the right strategy for the host.
                    Adding an OS = a new subclass, zero caller edits (Open/Closed).

Pure stdlib so it imports identically in dev and in the frozen PyInstaller build.
"""
import os
import sys
import abc
import shutil
import signal
import subprocess


class Platform(abc.ABC):
    """Interface every concrete platform implements. Callers hold a Platform, not
    a `sys.platform` string, so behaviour is swappable and testable."""

    name = 'base'

    # --- writable per-user data home (survives app delete/update/reinstall) ---
    @abc.abstractmethod
    def data_home(self) -> str:
        """OS-standard writable dir for ChatView user data, OUTSIDE the app bundle."""

    # --- process management for the spawned `claude` tree ---
    @abc.abstractmethod
    def process_group_kwargs(self) -> dict:
        """Popen kwargs that put a spawned child in its OWN process group, so the
        whole tree (claude + its children) can be killed together."""

    @abc.abstractmethod
    def kill_process_tree(self, pid: int) -> bool:
        """Kill `pid` AND its children. Returns True if a kill was attempted.
        Best-effort: a already-dead pid is not an error."""

    # --- locating the user's already-installed Claude Code CLI (BYOK model) ---
    def find_claude(self):
        """Resolve the `claude` executable the app drives. Order:
        CLAUDE_BIN env -> PATH (shutil.which) -> common per-OS install dirs.
        Returns an absolute path, or None if Claude Code is not installed."""
        env_bin = os.environ.get('CLAUDE_BIN')
        if env_bin and os.path.exists(env_bin):
            return env_bin
        found = shutil.which('claude')
        if found:
            return found
        for cand in self._claude_candidates():
            if cand and os.path.exists(cand):
                return cand
        return None

    def _claude_candidates(self):
        """Per-OS well-known install locations. Overridden by subclasses."""
        return []

    # --- opening the UI (kept behind the interface for a future native webview) ---
    def open_url(self, url: str) -> None:
        import webbrowser
        try:
            webbrowser.open(url)
        except Exception:
            pass

    # --- factory ---------------------------------------------------------------
    @staticmethod
    def current() -> 'Platform':
        """Return the Platform strategy for the host OS (Factory Method)."""
        if sys.platform == 'darwin':
            return MacPlatform()
        if os.name == 'nt' or sys.platform == 'win32':
            return WindowsPlatform()
        return LinuxPlatform()


class _PosixPlatform(Platform):
    """Shared POSIX behaviour (Mac + Linux): own session per child, kill via
    process-group signal. OS-specific paths stay in the leaf subclasses."""

    def process_group_kwargs(self) -> dict:
        # start_new_session=True -> child becomes a session/group leader; we kill
        # the whole group with killpg(-pgid).
        return {'start_new_session': True}

    def kill_process_tree(self, pid: int) -> bool:
        try:
            pgid = os.getpgid(pid)
        except (ProcessLookupError, PermissionError, OSError):
            pgid = None
        try:
            if pgid is not None:
                os.killpg(pgid, signal.SIGTERM)
            else:
                os.kill(pid, signal.SIGTERM)
        except (ProcessLookupError, PermissionError, OSError):
            return False
        # escalate to SIGKILL if still alive (caller may also re-invoke later)
        try:
            if pgid is not None:
                os.killpg(pgid, signal.SIGKILL)
            else:
                os.kill(pid, signal.SIGKILL)
        except (ProcessLookupError, PermissionError, OSError):
            pass
        return True


class MacPlatform(_PosixPlatform):
    name = 'mac'

    def data_home(self) -> str:
        base = os.path.expanduser('~/Library/Application Support')
        return os.path.join(base, 'ChatView')

    def _claude_candidates(self):
        home = os.path.expanduser('~')
        return [
            os.path.join(home, '.claude', 'local', 'claude'),
            os.path.join(home, '.local', 'bin', 'claude'),
            '/opt/homebrew/bin/claude',
            '/usr/local/bin/claude',
        ]


class LinuxPlatform(_PosixPlatform):
    name = 'linux'

    def data_home(self) -> str:
        base = os.environ.get('XDG_DATA_HOME') or os.path.expanduser('~/.local/share')
        return os.path.join(base, 'ChatView')

    def _claude_candidates(self):
        home = os.path.expanduser('~')
        return [
            os.path.join(home, '.claude', 'local', 'claude'),
            os.path.join(home, '.local', 'bin', 'claude'),
            '/usr/local/bin/claude',
            '/usr/bin/claude',
        ]


class WindowsPlatform(Platform):
    name = 'windows'

    def data_home(self) -> str:
        base = os.environ.get('APPDATA') or os.path.expanduser(r'~\AppData\Roaming')
        return os.path.join(base, 'ChatView')

    def process_group_kwargs(self) -> dict:
        # CREATE_NEW_PROCESS_GROUP so `taskkill /T` (or CTRL_BREAK) reaches children.
        # Attribute only exists on Windows, so read it dynamically to stay import-safe.
        flags = getattr(subprocess, 'CREATE_NEW_PROCESS_GROUP', 0)
        return {'creationflags': flags}

    def kill_process_tree(self, pid: int) -> bool:
        try:
            subprocess.run(['taskkill', '/F', '/T', '/PID', str(pid)],
                           stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
                           check=False)
            return True
        except Exception:
            return False

    def _claude_candidates(self):
        appdata = os.environ.get('APPDATA', '')
        localapp = os.environ.get('LOCALAPPDATA', '')
        cands = []
        if appdata:
            cands.append(os.path.join(appdata, 'npm', 'claude.cmd'))
            cands.append(os.path.join(appdata, 'npm', 'claude.exe'))
        if localapp:
            cands.append(os.path.join(localapp, 'Programs', 'claude', 'claude.exe'))
        return cands


# Convenience singleton: `from chatview_platform import PLATFORM`
PLATFORM = Platform.current()


if __name__ == '__main__':
    p = Platform.current()
    print('platform :', p.name)
    print('data_home:', p.data_home())
    print('claude   :', p.find_claude())
    print('proc_kw  :', p.process_group_kwargs())
