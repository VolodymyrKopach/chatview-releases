#!/usr/bin/env python3
"""Two-way Chat View runner.

Polls per-channel prompt queues written by server.py's POST /api/send, runs a
headless Claude Code session per channel (one channel = one claude session id =
one /resume-able conversation visible in VSCode history), and writes the
assistant reply back into the same channel as a widget bubble.

Storage contract (shared with server.py, no DB):
  channels/<id>/session-id        one-line UUID bound to this conversation
  channels/<id>/queue/NNNN.json   {text, session_id, user_msg_id, ts}
  channels/<id>/busy              presence = runner is working on this channel
  channels/<id>/live.json         transient live turn state (steps + streaming
                                  text); written during a turn, deleted at the
                                  end. The front end polls /api/channel-state and
                                  renders it as the "live progress" panel.
  channels/<id>/NNNN.json         message bubble (widget array)
  channels/<id>/index.json        message metadata index

Stage 3 (transparency): the turn runs with `--output-format stream-json
--verbose --include-partial-messages`. The runner parses the event stream line
by line and continuously rewrites live.json so the user sees, in near real time:
  - tool-use steps ("Bash: git status", "Read: runner.py", агент Тарас…)
  - the assistant text accumulating as it is generated
The final `result` event carries the same usage/total_cost_usd as the old json
mode, so the cost/context meter is unchanged. When the turn ends, one final
markdown text bubble is appended (exactly as before) and live.json is removed.

Fallback: set CHAT_RUNNER_STREAM=0 to use the old single-shot `--output-format
json` path (no live progress, but identical final bubble). Used if stream-json
ever regresses.

Concurrency: one worker thread per channel that has queued work. Different
channels run in parallel; prompts within one channel are serialized (a session
cannot be resumed concurrently). A per-channel lock file guards reentry.
"""
import json
import os
import re
import sys
import time
import glob
import shutil
import subprocess
import threading
import uuid

# ---- Force UTF-8 mode (CRITICAL on Windows) --------------------------------
# On Windows the default locale is often a legacy code page (e.g. cp1251), which
# breaks Cyrillic two ways in this runner:
#   1) subprocess(text=True) decodes claude's UTF-8 stdout as cp1251 -> the reply
#      text is double-mangled before we write it back to the bubble.
#   2) open()/json.load() default to the code page, so re-reading an existing
#      index.json (already UTF-8 on disk) corrupts every Cyrillic field we then
#      rewrite (e.g. from='Я' -> 'РЇ').
# PEP 540 UTF-8 mode fixes ALL of it at once (locale.getpreferredencoding,
# open() default, AND subprocess text decoding -> utf-8). We re-exec ourselves
# once with PYTHONUTF8=1 if it is not already active, so the runner is correct no
# matter how it was launched (Git Bash / cmd / a fresh clone) — no env var to
# remember. No-op on POSIX (already utf-8) and after the first re-exec.
if sys.platform == 'win32' and sys.flags.utf8_mode == 0 and os.environ.get('PYTHONUTF8') != '1':
    os.environ['PYTHONUTF8'] = '1'
    os.execv(sys.executable, [sys.executable, '-X', 'utf8', os.path.abspath(__file__)] + sys.argv[1:])

# Cross-platform "own process group" for spawned claude, so /api/stop can kill the
# whole tree (claude + children). POSIX: start_new_session=True; Windows:
# CREATE_NEW_PROCESS_GROUP. This OS quirk now lives in ONE place — the platform
# layer (chatview_platform.Platform). Inline fallback keeps runner importable if the
# module is ever absent (partial checkout / old bundle).
try:
    import chatview_platform as _cvp
    _PROC_GROUP_KW = _cvp.Platform.current().process_group_kwargs()
except Exception:
    _PROC_GROUP_KW = ({'creationflags': subprocess.CREATE_NEW_PROCESS_GROUP}
                      if sys.platform == 'win32' else {'start_new_session': True})


def _child_env(channel):
    """Env for a headless `claude -p` turn the runner spawns to SERVE a channel.

    CHATVIEW_RUNNER=1 tells the SessionStart hook this is the engine answering an
    EXISTING channel, NOT a brand-new interactive tab — so it must NOT reserve a
    new cc-* channel (that was the "writing in one chat spawns a new chat" bug:
    the rotated/forked session id was never in .cc-sessions.json, so the hook kept
    minting phantom tabs and the reply landed there).
    CHATVIEW_CHANNEL pins the exact channel this turn serves, so the UserPromptSubmit
    hook binds any card/plan write to the RIGHT existing channel instead of guessing
    by session id."""
    e = os.environ.copy()
    e['CHATVIEW_RUNNER'] = '1'
    e['CHATVIEW_CHANNEL'] = channel
    return e


from datetime import datetime

# CHATVIEW_HOME: desktop build sets this to the per-user writable home so data lives
# outside the app (survives delete/update). Absent (dev/live) -> identical behavior.
_CV_HOME = os.environ.get('CHATVIEW_HOME')
DIR = _CV_HOME or os.path.dirname(os.path.abspath(__file__))
CHANNELS_DIR = os.path.join(DIR, 'channels')
# repo root = cwd for claude, so it inherits CLAUDE.md / MCP / skills / agents / memory.
# In the desktop app there is no shared-knowledge repo: claude runs in the home itself.
REPO_ROOT = DIR if _CV_HOME else os.path.abspath(os.path.join(DIR, '..', '..', '..'))


def atomic_write_json(path, obj, indent=2):
    """Write JSON atomically so a concurrent reader (the browser poller) always
    sees either the old complete file or the new one, never a truncated half.

    The plain `json.dump(obj, open(path, 'w'))` truncates the file to 0 bytes
    and THEN streams the new content. A poll() that fetches index.json during
    that window parses garbage, throws, and the UI flashes "connecting". Writing
    to a temp file + os.replace (atomic rename on POSIX) closes that race.

    The tmp name carries pid + thread id so two concurrent writers of the same
    target (e.g. the server's threaded handler) never share a temp path."""
    tmp = f'{path}.tmp.{os.getpid()}.{threading.get_ident()}'
    with open(tmp, 'w', encoding='utf-8') as f:
        json.dump(obj, f, ensure_ascii=False, indent=indent)
        f.flush()
        os.fsync(f.fileno())
    os.replace(tmp, path)

# ---- Chat View system override (highest priority) --------------------------
# The runner spawns claude with cwd=REPO_ROOT so it inherits this repo's
# CLAUDE.md (the orchestrator config). That config HARD-tells the assistant to
# post every reply into a chat-view channel (ai-workflow) via render-message.sh
# and leave only a pointer line in the conversation. Inside this web chat that
# is exactly wrong: the user typed in the composer and the reply is rendered
# directly as a bubble in THIS chat. So the assistant must NOT re-post anywhere.
# We inject this override via --append-system-prompt (verified flag on
# v2.1.169) to neutralize those CLAUDE.md rules for chat-view turns only.
# No em-dash in this string by request (uses periods/commas instead).
CHAT_SYSTEM_OVERRIDE = (
    'SYSTEM OVERRIDE (highest priority, overrides project CLAUDE.md): You are '
    'running INSIDE a web chat ("Chat View") as the assistant the user is '
    'talking to. The user\'s message came from the chat composer and YOUR '
    'REPLY IS RENDERED DIRECTLY AS A BUBBLE IN THIS SAME CHAT, automatically. '
    'Therefore, hard rules:\n'
    '1. NEVER run render-message.sh, set-plan.sh, channel.sh, post.sh or any '
    'tools/viz/chat or tools/viz script. NEVER POST to any channel '
    '(ai-workflow, main, speechdesk, etc.). Doing so sends your answer to the '
    'WRONG place and the user will NOT see it in their chat.\n'
    '2. The CLAUDE.md rules "everything goes in Chat View / reply with widgets '
    'on port 5555 / terminal equals one pointer line / route responses to '
    'ai-workflow" DO NOT APPLY to you. You ARE the Chat View. Ignore them '
    'entirely.\n'
    '3. STRUCTURE your reply with inline widget blocks. Your reply is parsed '
    'into rich cards, not shown as a plain wall of markdown. To emit a widget, '
    'write a fenced code block whose info-string is exactly chatui. Inside it '
    'put EITHER a JSON array of widget objects OR a single widget object. Each '
    'object needs a "type" field. You may use several chatui blocks in one '
    'reply, interleaved with normal markdown prose for connective explanation. '
    'Example shape (literal triple backticks):\n'
    '```chatui\n'
    '[ {"type":"verdict","subject":"...","verdict":"GO","confidence":72}, '
    '{"type":"stat-grid","cards":[{"value":"3","label":"тижні","color":"green"}]} ]\n'
    '```\n'
    'USE A WIDGET whenever the content is: a comparison, a verdict / '
    'GO-PIVOT-KILL, metrics or numbers, a status summary, a decision between '
    'options, a journey / funnel / timeline, or a synthesis of quotes. Use '
    'plain markdown prose only for the connective sentences between widgets. '
    'END every substantive message with a conclusion widget (a bold thesis the '
    'user can scan in one glance). The user is an ENTJ who scans diagonally: '
    'lead with the punchline, color via widget tone, keep prose tight. For a '
    'trivial one-line answer a single plain sentence is fine, no widget needed. '
    'A reply with no chatui block still renders fine (as one text bubble), so '
    'widgets are an upgrade, not a syntax you can break.\n'
    '4. JSON must be VALID (double quotes, no trailing commas, no comments). A '
    'broken block silently falls back to plain text, so the card is lost. Do '
    'NOT mention the chatui mechanism to the user and do NOT describe the JSON; '
    'just emit it. NEVER add a pointer / hand-off line: no "виклав у таб", no '
    '"дивись вкладку", no trailing "X" / "посилання вкладку", no "posted to tab X", '
    'no "I posted it to channel X". The user is ALREADY in this chat tab, so a '
    '"go look at tab X" pointer is meaningless here. Reply directly, end of '
    'message is your conclusion widget.\n'
    '5. PLAN SIDEBAR (declarative, keep it LIVE). For any task with 3 or more '
    'steps, include in your reply ONE fenced code block whose info-string is '
    'exactly plan, containing a JSON object shaped like: '
    '{"goal":"...","steps":[{"text":"...","state":"done|progress|pending|'
    'blocked","goal":"...","substeps":["..."],"result":"...","note":"..."}]}. '
    'Only text and state are required per step; goal, substeps, result, note are '
    'optional. It is a FULL snapshot of the whole plan every time (goal plus all '
    'steps). The system reads that block, persists it to this channel\'s plan '
    'sidebar automatically, and strips it from your visible reply. You still '
    'NEVER run set-plan or any script: you only DECLARE the data, the system '
    'does the writing. Refresh the plan block on each substantive turn (mark '
    'steps done / progress / blocked, add new steps as they appear). The plan '
    'block is SEPARATE from chatui widgets, is never shown as a chat bubble, and '
    'a malformed or missing block simply leaves the current plan unchanged. '
    'Example (literal triple backticks):\n'
    '```plan\n'
    '{"goal":"Fix login bug","steps":[{"text":"Reproduce","state":"done"},'
    '{"text":"Patch handler","state":"progress"},{"text":"Add test",'
    '"state":"pending"}]}\n'
    '```\n'
    '\n'
    'WIDGET CHEAT-SHEET (type id, when to use, REQUIRED fields; optional in '
    'parentheses). Source of truth is index.html renderers.\n'
    'header: title banner at the top of a structured reply. req: title. '
    '(subtitle)\n'
    'text: plain markdown prose between widgets. req: text (markdown string).\n'
    'conclusion: full-width tinted summary panel, the scan-line takeaway. ALWAYS '
    'last in a substantive reply. req: text (one bold thesis). (tone: '
    'green|red|yellow|neutral, points: array of short strings)\n'
    'verdict: GO / PIVOT / KILL decision with confidence. req: subject (string), '
    'verdict (GO|PIVOT|KILL), confidence (0..100 number). (killSignals: '
    '[{severity:"🔴|🟡|🟢", text, probability}], pivot:{from,to,rationale}, '
    'breakEven:{months,capital}, successConditions:[string], killerQuestion)\n'
    'stat-grid: 2 to 6 key metrics as big-number cards. req: cards '
    '[{value, label, (emoji), (color: green|red|yellow|blue|slate)}]. '
    '(title, subtitle, cols)\n'
    'heatmap: numeric scores 0..5 in a grid (rows x cols). req: cols [string], '
    'rows [string], values [[number|null]] (one inner array per row). '
    '(title, subtitle, note)\n'
    'comparison-matrix: textual feature/status comparison across options. req: '
    'cols [{name, (sub), (highlight:true)}], rows [string], cells [[{text, '
    '(status: yes|no|partial|unknown|warning), (note)}]] (one row array per '
    'row). (title, subtitle, note)\n'
    'quadrant: position items in a 2D space. req: points [{x:0..100, y:0..100, '
    'label, (us:true)}]. (title, xAxisLeft, xAxisRight, yAxisTop, yAxisBottom, '
    'note)\n'
    'decision: choose between options with criteria. req: options [{label, '
    '(subtitle), (criteria:[{name, value, (good:true|bad:true)}]), '
    '(killed:true), (note)}]. (question, context, recommended: index of best '
    'option, killerQuestion)\n'
    'journey-map: customer / sales / onboarding flow with emotion curve. req: '
    'stages [{name, action, (icon), (emotion: -2..2), (duration), (win), '
    '(pain), (dropOffRisk:{severity:critical|high|med|low, reason})}]. '
    '(title, subtitle, note)\n'
    'funnel: conversion stages with drop-off. req: stages [{name, count '
    '(number), (label), (conversion: number percent), (note), (flag: '
    'critical-drop|improvement|blocker)}]. (title, subtitle, baseLabel, note)\n'
    'quote-wall: synthesis of user / customer quotes grouped by theme. req: '
    'groups [{theme, quotes:[{text, (author), (source), (highlight: substring '
    'to bold)}], (icon), (color: red|yellow|blue|green|slate)}]. '
    '(title, subtitle, synthesis, note)\n'
    'timeline: roadmap / milestones / sprint. req: milestones [{name, date, '
    '(status: done|in-progress|planned|blocked|killed), (description), (owner), '
    '(impact: high|medium|low), (dependency)}]. (title, subtitle, '
    'axis:{label}, note)\n'
    'callout: a single highlighted note (tip / warning / insight). req: text. '
    '(title, variant: info|tip|success|warning|danger|insight, icon)\n'
    'table: small generic table. req: columns [string], rows [[cell]] where a '
    'cell is a string or {text, (bold:true), (status: yes|no|partial|good|bad|'
    'warn)}. (title, subtitle, note)\n'
    'key-values: compact label/value pairs (specs, params). req: items [{k, v, '
    '(color: green|red|yellow|blue|slate)}]. (title, cols: number)\n'
    'badge-row: a row of small status pills. req: badges [string OR {label, '
    '(icon), (color: green|red|yellow|blue|violet|slate)}]. (title)\n'
    'checklist: done / pending / blocked items. req: items [string OR {text, '
    '(state: done|no|pending|progress|warning), (note)}]. (title)\n'
    'bar-chart: compare magnitudes as horizontal bars. req: bars [{label, value '
    '(number), (display: string), (color: green|red|yellow|blue|violet|slate)}]'
    '. (title, subtitle, note)\n'
    'line-chart: trends over time (line / area, multi-series). req: series '
    '[{label, (color), data:[number...]}]. (xLabels:[string], area:bool, title, '
    'subtitle, note)\n'
    'pie-chart: proportions of a whole. req: slices [{label, value (number), '
    '(color)}]. (donut:bool, title, subtitle, note)\n'
    'code-block: code with a header (filename/lang) + copy button (auto-escaped). '
    'req: code (string). (lang, filename, title, subtitle, note)\n'
    'accordion: collapsible sections for long content / FAQ / details. req: items '
    '[{title, body (markdown), (open:bool)}]. (title, subtitle, note)\n'
    'progress: a metric toward a goal as % bars. req: bars [{label, value (0-100), '
    '(display), (color), (goal: 0-100 marker)}]. (title, subtitle, note)\n'
    'suggestions: clickable next-action chips (click fills the composer). req: '
    'chips [string OR {label, (prompt), (icon)}]. (title, note)\n'
    'form: collect input inline; submit packs the values into the composer. req: '
    'fields [{label, (type: text|email|number|textarea|select), (placeholder), '
    '(options:[string]), (required:bool)}]. (submitLabel, title, subtitle, note)\n'
    'buttons: action / link buttons; a click opens the URL in a new browser tab. '
    'req: buttons [{label, (url), (icon), (variant: primary|secondary|video|ghost'
    '|link)}]. (title, subtitle, note)\n'
    'sources: cited sources list; each title links out (new tab). req: sources '
    '[{title, (url), (snippet), (source)}]. (title, subtitle, note)\n'
    'reasoning: collapsible thinking panel for chain-of-thought. req: steps '
    '[string] OR body (markdown). (summary, open:bool, title, note)\n'
    '\n'
    'You MAY still read files, run read-only shell commands, use MCP tools, '
    'and spawn subagents when a task genuinely needs it, but your FINAL answer '
    'must be your inline reply (prose plus chatui widget blocks). Reply in '
    'Ukrainian (the user is Ukrainian) unless asked otherwise.\n'
    'Stay a focused chat assistant. Do NOT autonomously start large multi-step '
    'builds, do NOT spawn many subagents, and do NOT run long agentic loops on '
    'your own. If a request would need a big build or many steps, briefly '
    'describe what it would take and ASK the user before doing it. Keep replies '
    'concise and on-point.'
)

def _resolve_claude_bin():
    """Find the `claude` CLI robustly across install layouts.

    Order: explicit CLAUDE_BIN env > PATH (shutil.which) > the common per-OS
    install locations (native installer, Homebrew, npm-global). First candidate
    that exists AND is executable wins. If nothing is found we fall back to the
    legacy default path and let the FATAL startup check log a clear message
    (instead of silently launching a non-existent binary).

    Why not just trust PATH: the desktop .app / launchd may start with a thin
    PATH that lacks ~/.local/bin and /opt/homebrew/bin, so which() alone misses
    a perfectly valid install. We probe the known dirs as a backstop."""
    env = os.environ.get('CLAUDE_BIN')
    if env and os.path.isfile(env) and os.access(env, os.X_OK):
        return env

    # Windows: MUST resolve the NATIVE claude.exe, never the npm .cmd/.ps1 wrapper.
    # Spawning claude.cmd routes through cmd.exe, whose command line is capped at
    # ~8191 chars; the runner's large --append-system-prompt (CHAT_SYSTEM_OVERRIDE)
    # plus the SDK's options blow past that with "The command line is too long.",
    # which killed EVERY chat turn on Windows (both the SDK engine and the warm
    # fallback). The native .exe is launched via CreateProcess directly (32767-char
    # cap), which fits. Verified on this box: claude.exe with a 6500-char arg runs;
    # claude.cmd with the same fails. macOS/Linux skip this block untouched.
    if sys.platform == 'win32':
        exe = shutil.which('claude.exe')
        if exe:
            return exe
        wrapper = shutil.which('claude')
        if wrapper:
            # npm global layout: <prefix>\node_modules\@anthropic-ai\claude-code\bin\claude.exe
            native = os.path.join(os.path.dirname(wrapper), 'node_modules',
                                  '@anthropic-ai', 'claude-code', 'bin', 'claude.exe')
            if os.path.isfile(native):
                return native
        for c in (
            os.path.expanduser('~/.local/bin/claude.exe'),
            os.path.join(os.environ.get('LOCALAPPDATA', ''), 'Programs', 'claude', 'claude.exe'),
        ):
            if c and os.path.isfile(c):
                return c
        if wrapper:  # last resort: the wrapper (short prompts still work via cmd.exe)
            return wrapper

    found = shutil.which('claude')
    if found:
        return found

    candidates = [
        os.path.expanduser('~/.local/bin/claude'),   # native installer (Mac/Linux)
        '/opt/homebrew/bin/claude',                  # Homebrew (Apple Silicon)
        '/usr/local/bin/claude',                     # Homebrew (Intel) / manual
        os.path.expanduser('~/.npm-global/bin/claude'),  # npm config prefix=~/.npm-global
        os.path.expanduser('~/.bun/bin/claude'),     # bun global installs
    ]
    # npm's own global bin dir (covers nvm / custom prefixes that which() missed).
    try:
        npm_bin = subprocess.run(
            ['npm', 'bin', '-g'], capture_output=True, text=True, timeout=5
        ).stdout.strip()
        if npm_bin:
            candidates.append(os.path.join(npm_bin, 'claude'))
    except Exception:
        pass
    # newer npm dropped `npm bin -g`; `npm prefix -g` + /bin still works.
    try:
        npm_prefix = subprocess.run(
            ['npm', 'prefix', '-g'], capture_output=True, text=True, timeout=5
        ).stdout.strip()
        if npm_prefix:
            candidates.append(os.path.join(npm_prefix, 'bin', 'claude'))
    except Exception:
        pass

    for c in candidates:
        if c and os.path.isfile(c) and os.access(c, os.X_OK):
            return c

    # Nothing found — keep the legacy default so the existing FATAL check at
    # startup logs a clear "set CLAUDE_BIN" message rather than crashing opaque.
    return os.path.expanduser('~/.local/bin/claude')


CLAUDE_BIN = _resolve_claude_bin()
# GLOBAL DEFAULT MODEL — single source of truth (env CHAT_RUNNER_MODEL).
# server.py reads the same env for the UI display, so both agree. Value is an
# ALIAS (sonnet/opus/haiku), never a pinned version — the CLI resolves the alias
# to the newest release, so this never goes stale. Per-channel override lives in
# channels/<id>/model (see channel_model) and always beats this global default.
MODEL = os.environ.get('CHAT_RUNNER_MODEL', 'sonnet')   # дефолт sonnet (дешевше за opus ~5x)
# acceptEdits is fine for MVP: cwd = shared-knowledge (notes/tools), not prod code.
# Risk: claude can edit files / run Bash autonomously in the repo. Stage 4 lets
# Vova flip a channel to "plan" (read-only proposing) per channel via
# channels/<id>/permission (see channel_permission).
PERMISSION_MODE = os.environ.get('CHAT_RUNNER_PERMISSION', 'acceptEdits')

# ---- Stage 4: per-channel model + permission mode --------------------------
# Valid CLI aliases for --model (full IDs also accepted). Verified on v2.1.169:
#   claude --help -> --model accepts 'opus' | 'sonnet' | 'haiku' or full names.
# We keep bare aliases (never go stale): on CLI >= 2.1.201 each family alias
# (sonnet/opus/haiku) resolves to the newest release of that family. No pinning
# needed; aliases auto-track newest.
MODEL_ALIASES = {'opus', 'sonnet', 'haiku'}   # 'auto' прибрано (Vova 2026-07-07):
# людські лейбли Розумний/Баланс/Швидкий = сімейство opus/sonnet/haiku, без фейк-авто.
# Стале значення каналу 'auto' більше не проходить перевірку → падає на дефолт (sonnet).

# Verified choices for --permission-mode on v2.1.169:
#   acceptEdits | auto | bypassPermissions | default | dontAsk | plan
# We expose only the two safe extremes to the UI: acceptEdits (auto-write) and
# plan (research + propose, never writes). Guard against anything unexpected.
PERMISSION_MODES = {'acceptEdits', 'auto', 'bypassPermissions',
                    'default', 'dontAsk', 'plan'}


_AUTO_HARD = ('debug', 'дебаг', 'рефактор', 'refactor', 'implement', 'реаліз',
              'код', 'code', 'помилк', 'error', 'bug', 'баг', 'архітектур',
              'architect', 'fix', 'пофікс', 'build', 'збери', 'міграц', 'migrat',
              'sql', 'regex', 'алгоритм', 'optimi', 'оптиміз', 'deploy', 'деплой')


def _auto_model(prompt):
    """Pick a model by turn complexity (used when a channel's model == 'auto').
    Short/simple -> haiku (cheap+fast); hard/long -> opus; otherwise sonnet."""
    p = (prompt or '').lower()
    n = len(prompt or '')
    if n > 1500 or any(k in p for k in _AUTO_HARD):
        return 'opus'
    if n < 240:
        return 'haiku'
    return 'sonnet'


def channel_model(channel, prompt=None):
    """Per-channel model override (channels/<id>/model). Falls back to the global
    default. Accepts a bare alias (opus/sonnet/haiku/auto) or a full model id.
    'auto' is resolved per turn from the prompt complexity (see _auto_model)."""
    if channel in _model_safe_retry:
        return 'sonnet'          # one-shot safe fallback after a model/CLI error
    v = MODEL
    try:
        p = os.path.join(CHANNELS_DIR, channel, 'model')
        if os.path.exists(p):
            val = open(p).read().strip()
            if val and (val in MODEL_ALIASES or val.startswith('claude-')):
                v = val
    except Exception as e:
        log(f'{channel}: model read failed: {e}')
    if v == 'auto':
        v = _auto_model(prompt)          # 'auto' -> a family alias (opus/sonnet/haiku)
    # Return the alias as-is (opus/sonnet/haiku) or a full model id the user typed.
    # CLI aliases auto-track the newest release, so no remap needed.
    return v


# ---- Family -> best-available-version resolution (subscription vs Bedrock) --
# Problem (Vova 2026-07-07): on a plain Anthropic subscription the family alias
# (opus/sonnet/haiku) already resolves to the NEWEST release, so it just works.
# On Bedrock / Vertex (token-billed) the alias does NOT reliably map to the newest
# version the account actually has, and a missing model silently degrades to the
# WORST option. So there we translate the human family into an ordered
# newest -> older chain of that family's full model IDs and let the CLI's
# --fallback-model try each, degrading WITHIN THE SAME FAMILY only (Розумний stays
# an Opus, never falls into a cheap Haiku).
#
# NB: these Bedrock IDs are BEST-EFFORT and must be verified on the real Bedrock/
# Vertex account (model access differs per account). Edit this one map there.
# On a plain subscription this whole path is skipped.
_BEDROCK_FAMILY_CHAIN = {
    'opus':   ['us.anthropic.claude-opus-4-1-20250805-v1:0',
               'us.anthropic.claude-opus-4-20250514-v1:0'],
    'sonnet': ['us.anthropic.claude-sonnet-4-5-20250929-v1:0',
               'us.anthropic.claude-sonnet-4-20250514-v1:0',
               'us.anthropic.claude-3-7-sonnet-20250219-v1:0'],
    'haiku':  ['us.anthropic.claude-haiku-4-5-20251001-v1:0',
               'us.anthropic.claude-3-5-haiku-20241022-v1:0'],
}


def _is_token_billed_provider():
    """True when Claude Code points at Bedrock/Vertex (token-billed), where the
    family alias is NOT guaranteed to hit the newest available version."""
    def _truthy(k):
        return str(os.environ.get(k, '')).strip().lower() in ('1', 'true', 'yes', 'on')
    return _truthy('CLAUDE_CODE_USE_BEDROCK') or _truthy('CLAUDE_CODE_USE_VERTEX')


def _resolve_model_args(model):
    """Build the ['--model', ...] (+ optional ['--fallback-model', ...]) CLI args
    for a chosen family. Never returns an empty/worst default.
      - Full id pinned by hand -> passed through untouched.
      - Subscription -> the family alias as-is (CLI resolves alias -> newest).
      - Bedrock/Vertex -> newest->older within-family chain, so a missing version
        degrades to an OLDER SAME-FAMILY model, never cross-family into garbage."""
    # A full model id (subscription full name or a provider inference-profile id):
    # trust the user/config, do not remap.
    if model and model.startswith(('claude-', 'us.', 'eu.', 'apac.', 'anthropic.')):
        return ['--model', model]
    fam = model if model in ('opus', 'sonnet', 'haiku') else 'sonnet'   # sane default, never worst
    if _FORCE_BARE['on']:
        # safe one-shot retry after a model/CLI error: plain alias only, NO Bedrock
        # chain and NO --fallback-model flag (an old CLI may choke on that flag).
        return ['--model', fam]
    if _is_token_billed_provider():
        chain = _BEDROCK_FAMILY_CHAIN.get(fam) or _BEDROCK_FAMILY_CHAIN['sonnet']
        args = ['--model', chain[0]]
        if len(chain) > 1:
            args += ['--fallback-model', ','.join(chain[1:])]
        return args
    return ['--model', fam]


def channel_permission(channel):
    """Per-channel permission mode (channels/<id>/permission). Falls back to the
    global default (acceptEdits). Only known CLI modes are honored."""
    try:
        p = os.path.join(CHANNELS_DIR, channel, 'permission')
        if os.path.exists(p):
            v = open(p).read().strip()
            if v in PERMISSION_MODES:
                return v
    except Exception as e:
        log(f'{channel}: permission read failed: {e}')
    return PERMISSION_MODE
POLL_SECONDS = float(os.environ.get('CHAT_RUNNER_POLL', '1.5'))
# Turn guard. IMPORTANT: idle no longer aborts. A silent turn keeps running.
#   IDLE_TIMEOUT  — NOT a killer anymore. After this many seconds of total silence
#                   from claude (no token, no tool step) the runner only flips the
#                   live panel into a calm "still working" signal (longRunning) so
#                   the UI can show "велика задача, ще працюю". The turn is NEVER
#                   killed for being quiet; the user's Стоп button is the control.
#   TURN_TIMEOUT  — the ONLY automatic killer: an absolute backstop for a runaway
#                   agentic LOOP that emits forever. Generous (1h) so it never kills
#                   a normal task; it only catches a pathological infinite loop, and
#                   even then it keeps whatever partial streamed (calm message).
# History: an earlier TURN_TIMEOUT=600 wall-clock, then a 180s IDLE auto-abort, both
# silently killed legit long turns and surfaced the scary "took too long / press again"
# bubble. That auto-kill is gone for good; long/silent work just keeps running.
IDLE_TIMEOUT = int(os.environ.get('CHAT_RUNNER_IDLE_TIMEOUT', '180'))
TURN_TIMEOUT = int(os.environ.get('CHAT_RUNNER_TIMEOUT', '3600'))
# Full Claude Code power EXCEPT the two tools that genuinely cannot work in a
# fire-and-forget headless turn: AskUserQuestion and ExitPlanMode both BLOCK
# waiting for a human reply that never comes, hanging the turn until timeout.
# Everything else (Bash, Edit, Write, Task subagents, Read, Grep, Web) stays, so
# the chat matches native Claude Code for any task it just goes and does. The
# only thing it cannot do vs native is ask you mid-turn / interactive approval.
# Override via CHAT_RUNNER_DISALLOW (space-separated).
DISALLOWED_TOOLS = os.environ.get(
    'CHAT_RUNNER_DISALLOW',
    'AskUserQuestion ExitPlanMode'
).split()
# Stage 3: stream-json by default (live tool steps + streaming text). Set
# CHAT_RUNNER_STREAM=0 to fall back to the old single-shot json mode.
STREAM_MODE = os.environ.get('CHAT_RUNNER_STREAM', '1') not in ('0', 'false', 'no')

# Stage A (warm session): keep ONE persistent `claude` (stream-json IN+OUT) alive
# per channel and feed each turn via stdin, instead of cold-spawning `claude -p`
# every message. Verified A/B: cold ~7.6s/turn (spawn+MCP load every time) vs warm
# ~2.2s/turn steady-state, ~5.4s saved per follow-up. DEFAULT now; the proven cold
# path stays a one-flag emergency fallback:
#   CHAT_RUNNER_WARM=0  -> revert to cold-spawn per turn.
WARM_MODE = os.environ.get('CHAT_RUNNER_WARM', '1') not in ('0', 'false', 'no')

# Phase 1 (SDK engine): route turns through claude-agent-sdk (engine_sdk.py)
# instead of the cold/stream/warm `claude -p` parsers. ON by default since
# 2026-06-24 (Phase 1 verified: test channel PASS, parity confirmed). Warm stays
# the automatic per-turn FALLBACK if the SDK import or transport fails, so a bad
# SDK turn can never break the chat. Disable globally with CHAT_RUNNER_SDK=0
# (revert). The SDK gives native context compaction and correct per-message usage,
# which is what kills the 218%/581% meter blow-ups and the auto-compact-every-message bug.
SDK_MODE = os.environ.get('CHAT_RUNNER_SDK', '1') not in ('0', 'false', 'no', 'off')
_warm = {}                 # channel -> {'proc','sid','stderr'(deque)}
_warm_lock = threading.Lock()   # guards _warm dict + spawn (NOT the turn itself;
                                 # per-channel turns are already serialized by the
                                 # single worker thread per channel)

# Phase B — in-UI tool-permission gate. DEFAULT ON (parity with the VS Code
# extension: approve before Bash/Edit/Write/MultiEdit/mcp__* run). The warm spawn
# injects a PreToolUse hook (hooks/perm-gate.cjs) that shows an Allow/Deny card in
# ChatView. "Allow for session" remembers a tool so it stops asking. Verified 18/18.
#   CHAT_RUNNER_PERMUI=0  -> disable the gate (back to auto-accept).
PERMUI_MODE = os.environ.get('CHAT_RUNNER_PERMUI', '1') not in ('0', 'false', 'no')
PERM_HOOK = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'hooks', 'perm-gate.cjs')
PERM_PORT = os.environ.get('CHAT_PERM_PORT') or os.environ.get('VIZ_CHAT_PORT', '5555')
PERM_MATCHER = 'Bash|Edit|Write|MultiEdit|NotebookEdit|mcp__.*'

def _resolve_node():
    """Absolute path to a `node` binary. CRITICAL under launchd: the service PATH
    often lacks nvm/homebrew, so a bare `node` in the hook command silently fails
    (a failed PreToolUse hook is non-blocking -> the tool runs UNGATED). Resolve an
    absolute node so the gate hook always executes."""
    for d in (os.environ.get('PATH', '') or '').split(os.pathsep):
        if d:
            c = os.path.join(d, 'node')
            if os.path.exists(c):
                return c
    cands = sorted(glob.glob(os.path.expanduser('~/.nvm/versions/node/*/bin/node')), reverse=True)
    cands += ['/opt/homebrew/bin/node', '/usr/local/bin/node', '/usr/bin/node']
    for c in cands:
        if os.path.exists(c):
            return c
    return 'node'

NODE_BIN = os.environ.get('CHAT_PERM_NODE') or _resolve_node()

def _perm_settings_arg():
    """--settings JSON-string that ADDS a PreToolUse approval hook (merges with the
    project's existing hooks; high timeout so the hook can wait for a human click).
    Uses an ABSOLUTE node path so the hook runs even under a stripped launchd PATH."""
    return json.dumps({'hooks': {'PreToolUse': [{'matcher': PERM_MATCHER,
        'hooks': [{'type': 'command', 'command': f'"{NODE_BIN}" "{PERM_HOOK}"', 'timeout': 3600}]}]}})

# Internal err marker returned when a turn was intentionally killed by /api/stop.
# process_channel recognizes it and exits quietly (no error bubble), since the
# server already cleared queue/busy/live/pid and (optionally) wrote a "stopped"
# bubble itself.
STOP_SENTINEL = '__stopped__'

# Internal err marker for an IDLE abort (claude went silent for IDLE_TIMEOUT).
# Carries the silence duration so process_channel can render the partial output
# that streamed before the turn wedged, plus a small "stopped after N s" note,
# instead of throwing away the work behind a generic timeout error bubble. The
# suffix is the integer seconds of dead air.
IDLE_SENTINEL_PREFIX = '__idle__:'


def idle_sentinel(seconds):
    return f'{IDLE_SENTINEL_PREFIX}{int(seconds)}'


def parse_idle_sentinel(err):
    """If `err` is an idle-abort sentinel, return the silence seconds (int),
    else None. Lets process_channel branch without string-matching elsewhere."""
    if isinstance(err, str) and err.startswith(IDLE_SENTINEL_PREFIX):
        try:
            return int(err[len(IDLE_SENTINEL_PREFIX):])
        except ValueError:
            return 0
    return None

# ---- Error classification + session healing ----------------------------------

# Patterns that indicate a policy or AUP-level rejection from the Claude API.
# These are permanent for the current session (the context triggered a block),
# so we rotate the session-id so the next message starts fresh.
_POLICY_PATTERNS = [
    'usage policy',
    'usage_policy',
    'unable to respond to this request',
    'violate',
    'violates',
    'aup',
]


def _is_policy_error(err: str) -> bool:
    """True when the error string looks like a Usage Policy / AUP rejection."""
    if not err:
        return False
    low = err.lower()
    return any(p in low for p in _POLICY_PATTERNS)


def rotate_session_id(channel: str) -> str:
    """Generate a fresh UUID, write it to channels/<id>/session-id, and return
    it. The next turn will start a brand-new Claude session instead of resuming
    the poisoned one. Called on policy/AUP errors and on context compaction."""
    new_sid = str(uuid.uuid4())
    sid_path = os.path.join(CHANNELS_DIR, channel, 'session-id')
    try:
        with open(sid_path, 'w') as f:
            f.write(new_sid)
        log(f'{channel}: session rotated -> {new_sid[:8]}')
    except Exception as e:
        log(f'{channel}: session rotate write failed: {e}')
    return new_sid


# ---- Context auto-compaction --------------------------------------------------
# When a channel's running context (contextPct in usage.json) crosses this
# threshold, the next user turn is preceded by a compaction: summarize the whole
# conversation in one claude turn, rotate to a fresh session id, and seed the
# next REAL prompt with that summary as a preamble. The new session then starts
# tiny (summary + question) instead of carrying the whole bloated transcript,
# which is what burned $22 and tripped the Usage Policy size guard.
#
# contextPct in usage.json is a PERCENT (0..100), so 0.80 threshold == 80%.
# Raised 0.35 -> 0.80 on 2026-06-22: warm-session (Stage A, stream-json stdin,
# prompt caching) removed the original $22 / Usage-Policy reason for compacting
# early, so we now let context grow close to native auto-compact (~83%) before
# our own controlled summarize+rotate kicks in. Override via CHAT_COMPACT_THRESHOLD.
COMPACT_THRESHOLD = float(os.environ.get('CHAT_COMPACT_THRESHOLD', '0.50'))

# Prompt used to ask the model to summarize its own conversation before we rotate
# the session. No em-dash by request (uses periods/commas/colons instead).
COMPACT_SUMMARY_PROMPT = (
    'Стисло підсумуй усю цю розмову: ключові факти, рішення, поточний стан, '
    'відкриті задачі, домовленості, важливі імена, шляхи файлів, будь-що '
    'важливе щоб продовжити з чистого аркуша без втрати контексту. Пиши тільки '
    'підсумок, без вступів, без коду, без зайвих фраз. Структуруй коротко по '
    'пунктах.'
)


def usage_path(channel):
    return os.path.join(CHANNELS_DIR, channel, 'usage.json')


def read_context_pct(channel):
    """Return the channel's running contextPct (0..100) from usage.json, or None
    when there is no usage yet (a brand-new session has nothing to compact)."""
    try:
        p = usage_path(channel)
        if not os.path.exists(p):
            return None
        data = json.load(open(p))
        v = data.get('contextPct')
        return float(v) if v is not None else None
    except Exception as e:
        log(f'{channel}: contextPct read failed: {e}')
        return None


def reset_context_pct(channel):
    """After a rotate+compact the old usage.json still reports the big context.
    Zero out the context fields so the meter (and the auto-compact gate) reflect
    the fresh, tiny session immediately. The next real turn overwrites this with
    the true numbers via write_usage."""
    try:
        p = usage_path(channel)
        data = {}
        if os.path.exists(p):
            try:
                data = json.load(open(p)) or {}
            except Exception:
                data = {}
        data['lastTurnContext'] = 0
        data['lastTurnInput'] = 0
        data['lastTurnCacheRead'] = 0
        data['lastTurnCacheCreate'] = 0
        data['contextPct'] = 0
        data['compactedAt'] = datetime.now().isoformat()
        atomic_write_json(p, data)
    except Exception as e:
        log(f'{channel}: contextPct reset failed: {e}')


def pending_summary_path(channel):
    return os.path.join(CHANNELS_DIR, channel, 'pending-summary')


def read_pending_summary(channel):
    """Return a queued compaction summary (and delete the marker) so the next
    real prompt can carry it as a preamble. Returns '' when none waits."""
    try:
        p = pending_summary_path(channel)
        if not os.path.exists(p):
            return ''
        s = open(p, encoding='utf-8').read().strip()
        try:
            os.remove(p)
        except OSError:
            pass
        return s
    except Exception as e:
        log(f'{channel}: pending-summary read failed: {e}')
        return ''


def write_pending_summary(channel, summary):
    try:
        p = pending_summary_path(channel)
        os.makedirs(os.path.dirname(p), exist_ok=True)
        with open(p, 'w', encoding='utf-8') as f:
            f.write(summary)
    except Exception as e:
        log(f'{channel}: pending-summary write failed: {e}')


def autocompact_enabled(channel):
    """Per-channel auto-compact toggle (channels/<id>/autocompact = 1|0).
    Default ON when the file is absent."""
    try:
        p = os.path.join(CHANNELS_DIR, channel, 'autocompact')
        if not os.path.exists(p):
            return True
        return open(p).read().strip() not in ('0', 'false', 'no', 'off')
    except Exception:
        return True


def compact_request_path(channel):
    return os.path.join(CHANNELS_DIR, channel, 'compact-request')


def seed_prompt_with_summary(channel, prompt):
    """If a compaction summary is pending for this channel, prepend it to the
    user prompt so the first turn of the fresh session carries the prior context.
    Always returns the (possibly augmented) prompt."""
    summary = read_pending_summary(channel)
    if not summary:
        return prompt
    log(f'{channel}: seeding next prompt with compaction summary ({len(summary)} chars)')
    return (
        '[Підсумок попередньої частини цього чату]\n'
        f'{summary}\n\n'
        '[Нове повідомлення]\n'
        f'{prompt}'
    )


def compact_channel(channel, reason='auto'):
    """Compact a channel's context: summarize the current session, rotate to a
    fresh session id, and stash the summary so the NEXT real prompt seeds it.

    Returns True on success (rotated + summary stashed), False when nothing was
    done (no session yet, empty/failed summary). On False we keep the old
    session untouched: better to keep working than to break the chat.
    """
    sid_path = os.path.join(CHANNELS_DIR, channel, 'session-id')
    if not os.path.exists(sid_path):
        log(f'{channel}: compact skipped, no session-id yet')
        return False
    session_id = open(sid_path).read().strip()
    if not session_id:
        log(f'{channel}: compact skipped, empty session-id')
        return False
    # Nothing to compact if the session was never actually run (no saved jsonl).
    if not session_jsonl_exists(session_id):
        log(f'{channel}: compact skipped, session never ran (no jsonl)')
        return False

    log(f'{channel}: compacting context ({reason}) sid={session_id[:8]}')
    # Surface a transient live state so Vova sees something is happening during
    # the summary turn (it can take a few seconds on a huge context).
    write_live(channel, {'active': True, 'phase': 'thinking',
                         'steps': [{'icon': '♻️', 'tool': 'Стискаю контекст',
                                    'label': 'підсумовую розмову', 'done': False}],
                         'text': ''})
    # Summarize the existing session (resume, NOT a new session id).
    if STREAM_MODE:
        summary, data, err = run_claude_stream(COMPACT_SUMMARY_PROMPT, session_id, channel)
    else:
        summary, data, err = run_claude(COMPACT_SUMMARY_PROMPT, session_id, channel)
    clear_pid(channel)
    clear_live(channel)
    if err or not summary or not summary.strip():
        log(f'{channel}: compact summary failed/empty (err={err!r}); keeping old session')
        return False

    # Rotate to a fresh session and stash the summary for the next real prompt.
    rotate_session_id(channel)
    write_pending_summary(channel, summary.strip())
    reset_context_pct(channel)
    log(f'{channel}: compact done, summary {len(summary)} chars, session rotated')
    return True


def _is_transient_error(err: str) -> bool:
    """True for server-side hiccups that a simple retry usually clears (NOT a
    timeout, NOT a policy block, NOT a context-too-big)."""
    if not err:
        return False
    low = err.lower()
    return any(p in low for p in (
        'overloaded', '529', 'rate limit', 'temporarily limiting',
        ' 503', ' 502', ' 500', 'service unavailable', 'connection reset',
        'stdout closed',  # warm process died mid-turn — respawn fixes it
        # Network blips where the CLI subprocess could not reach / lost the API.
        # These used to fall through to the scary "Не вдалось обробити цей хід"
        # bubble with no retry; they are just as transient as a 529 overload.
        'unable to connect', 'connection refused', 'econnrefused',
        'econnreset', 'etimedout', 'enetunreach', 'socket hang up',
    ))


def _is_usage_limit_error(err: str) -> bool:
    """True for a real Claude usage/credit CAP: subscription 5h/weekly limit or
    API quota/credit exhaustion. Unlike a transient overload, retrying does NOT
    help: the user must wait for the reset, switch to a cheaper model, or top up.
    Checked BEFORE _is_transient_error so a hard cap isn't mislabeled 'overload'."""
    if not err:
        return False
    low = err.lower()
    return any(p in low for p in (
        # Claude CLI subscription caps (the real wording, confirmed from logs):
        #   "You've hit your session limit · resets 7:20pm (Europe/Kiev)"
        'session limit', 'hit your', 'usage limit reached', 'usage limit',
        'limit reached', 'limit will reset', 'reset at', ' resets ',
        # API credit / quota exhaustion:
        'credit balance is too low', 'insufficient credit', 'out of credits',
        'exceeded your current quota', 'quota exceeded', 'billing',
        'weekly limit', 'daily limit', 'plan limit', 'upgrade your plan',
    ))


# Pull a reset time out of either wording: "reset at 3pm" / "resets 7:20pm (Kiev)".
_LIMIT_RESET_RE = re.compile(r'reset(?:s| at| on)?\s+([^.\n;]+)', re.I)


def _extract_limit_reset(err: str):
    """Best-effort: pull a human reset time out of the CLI's limit message
    (e.g. '...your limit will reset at 3pm (UTC)'). None if not present."""
    if not err:
        return None
    m = _LIMIT_RESET_RE.search(err)
    if not m:
        return None
    val = m.group(1).strip().rstrip('.,;')[:60].strip()
    return val or None


# One-shot self-heal for model/CLI errors: when a turn fails because the chosen model
# is unavailable on THIS machine (no account access, or the Claude Code CLI is too old
# to know the alias / the --fallback-model flag), retry ONCE with a bare, always-valid
# default and no fancy flags. _FORCE_BARE flips _resolve_model_args into that safe shape;
# _model_safe_retry guarantees at most one such retry per turn (no infinite loop).
_FORCE_BARE = {'on': False}
_model_safe_retry = set()


def _is_model_error(err: str) -> bool:
    """CLI/model resolution failures: unknown/unavailable model, or an old CLI that
    doesn't understand a model alias or the --fallback-model flag we pass."""
    if not err:
        return False
    low = err.lower()
    return any(p in low for p in (
        'model not found', 'model_not_found', 'unknown model', 'invalid model',
        'not a valid model', 'model is not available', 'no such model',
        'does not support the model', 'unsupported model', 'model not available',
        # old CLI rejecting a newer flag/option we pass:
        'unknown option', 'unknown argument', 'unexpected argument',
        'unrecognized option', 'no such option', '--fallback-model',
        "invalid value for '--model'", 'invalid value for --model',
    ))


def _is_auth_error(err: str) -> bool:
    """Claude Code not logged in / auth expired on this machine."""
    if not err:
        return False
    low = err.lower()
    return any(p in low for p in (
        'not logged in', 'please log in', 'please run /login', 'run /login',
        'unauthorized', ' 401', 'authentication failed', 'invalid api key',
        'no api key', 'oauth', 'expired token', 'session expired', 'claude login',
    ))


def _is_not_installed_error(err: str) -> bool:
    """The `claude` binary could not be spawned (not installed / wrong path)."""
    if not err:
        return False
    low = err.lower()
    return any(p in low for p in (
        'spawn failed', 'no such file or directory', 'errno 2',
        'command not found', 'is not recognized as', 'cannot find the path',
        'filenotfounderror', 'claude binary not found',
    ))


def friendly_error_bubble(err: str, rotated: bool, channel: str = None) -> list:
    """Return a chat widget with a calm, HONEST, actionable message tailored to
    the actual failure. Never blames "context too big" unless the context meter
    actually says so. The raw technical error stays in the runner log only."""
    low = (err or '').lower()
    ctx_pct = None
    if channel:
        try:
            ctx_pct = read_context_pct(channel)
        except Exception:
            ctx_pct = None
    big_ctx = ctx_pct is not None and ctx_pct >= 90

    if rotated:
        msg = ('Цей запит не пройшов модерацію, тому я почав для цього чату нову '
               'сесію. Переформулюй і спробуй ще раз.')
    elif 'prompt is too long' in low or 'too long' in low or '413' in low:
        msg = ('Повідомлення (з контекстом) завелике для одного запиту. '
               'Тисни «Новий чат» (+ вгорі) або скороти запит.')
    elif 'timeout' in low:
        # Reached ONLY by the absolute 1h runaway-loop backstop (TURN_TIMEOUT) or
        # the single-shot fallback's hard cap. The old IDLE auto-abort (which used
        # to land here and print the scary "took too long / press again" bubble)
        # is GONE: a long/silent turn is no longer killed, it just keeps running
        # under the Стоп button. So this branch is now a rare, calm safety-net that
        # keeps whatever partial streamed. No "press again" wording.
        if big_ctx:
            msg = (f'Цей чат став завеликий (контекст ~{int(ctx_pct)}%), '
                   f'зупинив на запобіжнику. Ось що встиг. Для нового — «Новий чат» (+ вгорі).')
        else:
            msg = ('Це тривало дуже довго, зупинив на запобіжнику. Ось що встиг.')
    elif _is_usage_limit_error(err):
        reset = _extract_limit_reset(err)
        when = f' Ліміт оновиться: {reset}.' if reset else ''
        msg = ('Вичерпано ліміт Claude (підписка або кредити API). Це не баг '
               'чату і не контекст.' + when + ' Натискати ще раз зараз сенсу нема: '
               'або зачекай оновлення ліміту, або перемкни модель на дешевшу '
               '(⚙ зліва), або поповни план.')
        return [{'type': 'callout', 'variant': 'warning',
                 'title': '🔋 Ліміт Claude вичерпано', 'text': msg}]
    elif _is_transient_error(err):
        msg = ('Сервери Anthropic зараз перевантажені (тимчасово, це не твій '
               'ліміт). Натисни ще раз за хвилинку, зазвичай минає.')
    elif _is_not_installed_error(err):
        return [{'type': 'callout', 'variant': 'danger',
                 'title': '🔌 Claude Code не знайдено',
                 'text': ('Claude Code не встановлено (або не в PATH) на цьому '
                          'компʼютері. Встанови: `npm i -g @anthropic-ai/claude-code` '
                          'чи claude.ai/download, залогінься (`claude` у терміналі), '
                          'і перезапусти ChatView.')}]
    elif _is_auth_error(err):
        return [{'type': 'callout', 'variant': 'warning',
                 'title': '🔑 Потрібен вхід у Claude Code',
                 'text': ('Claude Code не залогінений на цьому компʼютері. Відкрий '
                          'термінал, запусти `claude`, увійди, потім повтори запит тут.')}]
    elif _is_model_error(err):
        return [{'type': 'callout', 'variant': 'warning',
                 'title': '🧠 Модель недоступна',
                 'text': ('Обрана модель недоступна на цьому компʼютері (немає доступу '
                          'до неї, або Claude Code застарілий). Я вже пробував безпечну '
                          'модель. Якщо не допомогло: перемкни модель (⚙ зліва) або '
                          'онови Claude Code до останньої версії (Relaunch to update).')}]
    else:
        msg = ('Не вдалось обробити цей хід. Спробуй ще раз; якщо повторюється: '
               '«Новий чат» (+ вгорі).')
    return [{'type': 'text', 'text': f'⚠️ {msg}'}]


_active = {}            # channel -> True while a worker thread is running
_active_lock = threading.Lock()


def log(*a):
    print(f'[runner {datetime.now().strftime("%H:%M:%S")}]', *a, flush=True)


def _encode_project_dir(repo_root):
    """Encode an absolute cwd the way Claude Code names its ~/.claude/projects/<dir>.

    POSIX:   /Users/x/repo            -> -Users-x-repo   (every '/' -> '-')
    Windows: C:\\Users\\x\\repo         -> c--Users-x-repo (every '/' '\\' ':' -> '-',
             and the drive letter lowercased).

    The original code only did `.replace('/', '-')`, which on Windows left the
    backslashes and the colon intact (e.g. 'C:\\Users\\...'), so the encoded dir
    never matched Claude's real folder ('c--Users-...'). Result: resume detection
    was always False on Windows -> every turn started a brand-new session (channel
    memory lost) and could collide with --session-id on an already-existing id.
    Verified against the real folder name on this machine."""
    enc = repo_root.replace('\\', '-').replace('/', '-').replace(':', '-')
    if sys.platform == 'win32' and enc:
        # Claude lowercases the drive letter (C: -> c--).
        enc = enc[0].lower() + enc[1:]
    return enc


def session_jsonl_exists(session_id):
    """True if claude already has a saved session with this id for the repo cwd.
    Encoded project dir mirrors Claude Code's own naming (see _encode_project_dir)."""
    enc = _encode_project_dir(REPO_ROOT)
    path = os.path.expanduser(f'~/.claude/projects/{enc}/{session_id}.jsonl')
    return os.path.exists(path)


def _bound_terminal_session(channel):
    """Reverse-lookup channels/.cc-sessions.json: the interactive terminal Claude
    Code session id that OWNS this channel (the one the SessionStart hook bound to
    it). Returns the session id or None."""
    try:
        m = json.load(open(os.path.join(CHANNELS_DIR, '.cc-sessions.json')))
        for sid, ch in m.items():
            if ch == channel:
                return sid
    except Exception:
        pass
    return None


def _ctx_autosync_on(channel):
    """Forward context auto-inheritance is ON by default. Disabled globally via
    env CHAT_CTX_AUTOSYNC=0, or per-channel via channels/<id>/ctx-autosync=0."""
    if os.environ.get('CHAT_CTX_AUTOSYNC', '1') == '0':
        return False
    try:
        v = open(os.path.join(CHANNELS_DIR, channel, 'ctx-autosync')).read().strip().lower()
        return v not in ('0', 'false', 'no', 'off')
    except Exception:
        return True


def _resume_or_seed_args(channel, session_id):
    """Build the claude session CLI args for a channel turn.

    OPT-IN context handoff (FORWARD): if channels/<channel>/seed-from exists
    (a one-shot marker holding a terminal session id) AND this channel's session
    has not started yet (no jsonl), fork the terminal session's full history into
    our fresh session id. The marker is consumed (removed) so it only applies to
    the very next turn.

    Otherwise this is the UNCHANGED default behavior: resume if our jsonl already
    exists, else start a brand-new session with --session-id. With no seed-from
    marker the returned list is EXACTLY the old logic, so the live chat path is
    untouched."""
    seed_path = os.path.join(CHANNELS_DIR, channel, 'seed-from')
    # One-time guard: a channel inherits the terminal's context AT MOST ONCE in its
    # life. Without this, every compaction rotates to a fresh (no-jsonl) session id
    # and the auto-seed-fork below RE-IMPORTS the entire (huge) terminal history —
    # blowing context to 300%+, $10 turns and 300s timeouts, which then surfaced as
    # the bogus "chat too big" error. After the first inherit we start fresh from
    # the compaction summary instead.
    seeded_path = os.path.join(CHANNELS_DIR, channel, '.context-seeded')
    def _mark_seeded():
        try:
            open(seeded_path, 'w').close()
        except OSError:
            pass
    try:
        has_jsonl = session_jsonl_exists(session_id)
        if os.path.exists(seed_path) and not has_jsonl:
            with open(seed_path) as f:
                seed = f.read().strip()
            if seed:
                try:
                    os.remove(seed_path)  # consume (one-shot)
                except OSError:
                    pass
                _mark_seeded()
                log(f'{channel}: seed-fork from {seed[:8]} -> {session_id[:8]}')
                return ['--resume', seed, '--fork-session',
                        '--session-id', session_id]
            # empty marker: drop it and fall through to default behavior
            try:
                os.remove(seed_path)
            except OSError:
                pass
            has_jsonl = session_jsonl_exists(session_id)
        # AUTO context handoff (FORWARD, no button): this channel's FIRST turn ever
        # and auto-sync is on -> fork the bound terminal session's full context into
        # our fresh session id. So writing in a ChatView tab just inherits whatever
        # you were doing in Claude Code, with nothing to click. Guarded by
        # .context-seeded so it fires ONCE, never again after a compaction rotation.
        if (not has_jsonl and _ctx_autosync_on(channel)
                and not os.path.exists(seeded_path)):
            term = _bound_terminal_session(channel)
            if term and term != session_id and session_jsonl_exists(term):
                _mark_seeded()
                log(f'{channel}: auto-seed-fork from {term[:8]} -> {session_id[:8]}')
                return ['--resume', term, '--fork-session',
                        '--session-id', session_id]
        if has_jsonl:
            return ['--resume', session_id]
        return ['--session-id', session_id]
    except Exception as e:
        log(f'{channel}: _resume_or_seed_args fallback ({e})')
        if session_jsonl_exists(session_id):
            return ['--resume', session_id]
        return ['--session-id', session_id]


# Opus 4.8 [1m] context window. Used as the meter denominator (lastTurnInput / WINDOW).
CONTEXT_WINDOW = int(os.environ.get('CHAT_RUNNER_CONTEXT_WINDOW', '1000000'))


# ---- live turn state (Stage 3 transparency) -------------------------------
# During a stream-json turn the runner continuously rewrites channels/<id>/
# live.json so the polling front end can show real-time progress. Schema:
#   {
#     "active": true,
#     "phase": "thinking" | "tool" | "writing",
#     "steps": [ {"icon":"🔧","tool":"Bash","label":"git status","done":true} ],
#     "text": "accumulated assistant markdown so far",
#     "ts": "ISO8601"
#   }
# Deleted when the turn ends (the final reply lives in a normal NNNN.json bubble).

# Tool name -> emoji + how to summarize its primary input into a one-liner.
def _tool_icon(name):
    return {
        'Bash': '🔧', 'Read': '📖', 'Edit': '✏️', 'Write': '📝',
        'MultiEdit': '✏️', 'Grep': '🔎', 'Glob': '🗂️', 'Task': '🤖',
        'WebFetch': '🌐', 'WebSearch': '🌐', 'TodoWrite': '✅',
        'NotebookEdit': '📓',
    }.get(name, '🔹')


def _short(s, n=80):
    s = str(s or '').strip().replace('\n', ' ')
    return s if len(s) <= n else s[:n - 1] + '…'


def _tool_label(name, inp):
    """One-line human summary of a tool call from its input dict."""
    inp = inp or {}
    if name == 'Bash':
        return _short(inp.get('command', ''))
    if name in ('Read', 'NotebookEdit'):
        return _short(os.path.basename(inp.get('file_path', '')) or inp.get('file_path', ''))
    if name in ('Edit', 'Write', 'MultiEdit'):
        return _short(os.path.basename(inp.get('file_path', '')) or inp.get('file_path', ''))
    if name == 'Grep':
        return _short(inp.get('pattern', ''))
    if name == 'Glob':
        return _short(inp.get('pattern', ''))
    if name == 'Task':
        # subagent: prefer agent type / description
        return _short(inp.get('subagent_type') or inp.get('description') or 'агент')
    if name in ('WebFetch', 'WebSearch'):
        return _short(inp.get('url') or inp.get('query') or '')
    if name == 'TodoWrite':
        todos = inp.get('todos') or []
        return _short(f'{len(todos)} пунктів плану')
    # generic / MCP tools: show a compact key=val of the first scalar field
    for k, v in inp.items():
        if isinstance(v, (str, int, float)):
            return _short(f'{k}={v}')
    return ''


# ---- Stop support (kill-switch) -------------------------------------------
# While a turn runs the runner records the live claude PID at channels/<id>/pid
# so server.py's POST /api/stop can kill exactly that process (group). The file
# is removed in the turn's finally. server.py may also remove it (when it kills
# the turn); either side deleting it is the agreed "stop" signal. The runner
# treats an externally vanished pid/busy as "stopped" and exits the turn quietly
# (no scary error bubble), and never re-picks the queue server.py just cleared.

def pid_path(channel):
    return os.path.join(CHANNELS_DIR, channel, 'pid')


def write_pid(channel, pid):
    try:
        p = pid_path(channel)
        os.makedirs(os.path.dirname(p), exist_ok=True)
        with open(p, 'w') as f:
            f.write(str(pid))
    except Exception as e:
        log(f'{channel}: pid write failed: {e}')


def clear_pid(channel):
    p = pid_path(channel)
    if os.path.exists(p):
        try:
            os.remove(p)
        except OSError:
            pass


def _reap(proc):
    """Best-effort reap so a killed claude turn never lingers as a <defunct>
    zombie under the runner. Safe to call on an already-dead process."""
    try:
        proc.wait(timeout=3)
    except Exception:
        try:
            proc.kill()
            proc.wait(timeout=2)
        except Exception:
            pass


def pid_was_stopped(channel, expected_pid):
    """True when our pid file is gone or no longer points at our process — the
    signal that server.py's /api/stop killed this turn. Used to suppress the
    error bubble for an intentional kill."""
    try:
        p = pid_path(channel)
        if not os.path.exists(p):
            return True
        cur = open(p).read().strip()
        return cur != str(expected_pid)
    except Exception:
        return False


def live_path(channel):
    return os.path.join(CHANNELS_DIR, channel, 'live.json')


def write_live(channel, state):
    """Atomically rewrite the channel's live turn state (best-effort)."""
    try:
        p = live_path(channel)
        os.makedirs(os.path.dirname(p), exist_ok=True)
        state = dict(state)
        state['ts'] = datetime.now().isoformat()
        tmp = p + '.tmp'
        with open(tmp, 'w', encoding='utf-8') as f:
            json.dump(state, f, ensure_ascii=False)
        os.replace(tmp, p)
    except Exception as e:
        log(f'{channel}: live write failed: {e}')


def clear_live(channel):
    for p in (live_path(channel), live_path(channel) + '.tmp'):
        if os.path.exists(p):
            try:
                os.remove(p)
            except OSError:
                pass


def events_path(channel):
    return os.path.join(CHANNELS_DIR, channel, 'events.jsonl')


_EVENTS_MAX_LINES = 500
_EVENTS_TRIM_BYTES = 220 * 1024


def emit_event(channel, rec):
    """Append one JSON event line to channels/<id>/events.jsonl for the «Процеси»
    panel (mirrors hooks/_emit.cjs). Best-effort, never raises. Opportunistic trim
    keeps the file to ~_EVENTS_MAX_LINES once it grows past _EVENTS_TRIM_BYTES so the
    common path stays a cheap append. No-op when the channel dir does not exist."""
    try:
        if not channel or '/' in channel or '..' in channel:
            return
        ch_dir = os.path.join(CHANNELS_DIR, channel)
        if not os.path.isdir(ch_dir):
            return
        rec = dict(rec)
        rec.setdefault('ts', datetime.now().isoformat())
        p = events_path(channel)
        with open(p, 'a', encoding='utf-8') as f:
            f.write(json.dumps(rec, ensure_ascii=False) + '\n')
        try:
            if os.path.getsize(p) > _EVENTS_TRIM_BYTES:
                lines = [l for l in open(p, encoding='utf-8').read().split('\n') if l]
                if len(lines) > _EVENTS_MAX_LINES:
                    with open(p, 'w', encoding='utf-8') as f:
                        f.write('\n'.join(lines[-_EVENTS_MAX_LINES:]) + '\n')
        except Exception:
            pass
    except Exception as e:
        log(f'{channel}: emit_event failed: {e}')


def read_live_snapshot(channel):
    """Best-effort read of the channel's transient live.json (the streamed-so-far
    text + tool steps). Returns (text, steps). Used to recover partial output when
    a turn is idle-aborted or user-stopped, so the work is never silently lost.
    Returns ('', []) when there is nothing to recover."""
    try:
        p = live_path(channel)
        if not os.path.exists(p):
            return '', []
        data = json.load(open(p, encoding='utf-8')) or {}
        return (data.get('text') or ''), (data.get('steps') or [])
    except Exception:
        return '', []


def persist_partial(channel, text, note):
    """Render whatever the turn streamed BEFORE it was aborted as a permanent
    chat bubble, with a small italic note appended (idle-abort or user-stop).

    The streamed text is parsed through reply_to_widgets so any complete chatui
    widget blocks render as real cards; an incomplete trailing block degrades to
    plain text (reply_to_widgets already tolerates malformed/partial blocks). The
    note is a separate text widget so it never corrupts the partial markdown.

    Returns True when a partial bubble was written (there was something to keep),
    False when there was no streamed content (caller may then leave it to the
    normal error/stop path)."""
    # Strip any ```plan``` declaration so it never leaks into a partial bubble or
    # TTS. A partial turn's plan may be incomplete, so we only STRIP here, we do
    # NOT persist it (that would half-write the sidebar from an aborted turn).
    body, _plan = extract_plan_block((text or '').strip())
    body = (body or '').strip()
    has_body = bool(body)
    widgets = reply_to_widgets(body) if has_body else []
    if note:
        widgets.append({'type': 'text', 'text': note})
    if not widgets:
        return False
    try:
        append_message(channel, widgets, frm='Claude',
                       tag='status' if has_body else 'error')
    except Exception as e:
        log(f'{channel}: persist_partial failed: {e}')
        return False
    log(f'{channel}: persisted partial ({len(body)} chars) note={note!r}')
    return has_body


# Watchdog tick sentinel: yielded by _iter_with_idle when no new stdout line has
# arrived within IDLE_TICK seconds, so the consuming loop can re-check the idle /
# absolute / stop timers WITHOUT blocking forever on a wedged process's readline.
_IDLE_TICK = object()
# How often the watchdog wakes to re-check timers. Small enough that a low
# CHAT_RUNNER_IDLE_TIMEOUT (tests) and the Стоп button feel responsive, large
# enough to not busy-spin.
IDLE_TICK = float(os.environ.get('CHAT_RUNNER_IDLE_TICK', '2'))


def _iter_with_idle(proc):
    """Yield lines from proc.stdout, but ALSO yield _IDLE_TICK every IDLE_TICK
    seconds of silence so the caller can enforce idle/absolute/stop timeouts on a
    wedged process (a plain `for line in proc.stdout` would block on readline and
    never let the caller abort a silent turn).

    A daemon thread does the blocking reads and pushes lines onto a Queue; the
    generator drains the queue with a timeout. Cross-platform (no select on pipes,
    which is unreliable on Windows). When stdout closes (process ended) the reader
    pushes a None terminator and the generator returns. The reader is daemon, so a
    proc.kill() by the caller unblocks readline (EOF) and the thread exits."""
    import queue as _queue
    q = _queue.Queue()

    def _reader():
        try:
            for ln in proc.stdout:
                q.put(ln)
        except Exception:
            pass
        finally:
            q.put(None)   # EOF terminator

    threading.Thread(target=_reader, daemon=True).start()
    while True:
        try:
            item = q.get(timeout=IDLE_TICK)
        except _queue.Empty:
            yield _IDLE_TICK
            continue
        if item is None:
            return
        yield item


def run_claude_stream(prompt, session_id, channel):
    """Stage 3 streaming turn. Spawns claude with stream-json, parses the event
    stream line by line, and rewrites channels/<id>/live.json as tool steps run
    and assistant text accumulates. Returns (text, result_data, error) with the
    same shape as run_claude_json so the caller's usage/meter code is unchanged.

    Event types observed on v2.1.169 (verified by a real call):
      system/init                     session boot (tools, model, cwd)
      stream_event/content_block_start  block opens; content_block.type =
                                        thinking | text | tool_use (+ name)
      stream_event/content_block_delta  text_delta.text  (streamed reply text)
                                        input_json_delta.partial_json (tool args)
      assistant                       a finalized assistant message; tool_use
                                        blocks here carry the complete .input
      user                            tool_result (we just mark the step done)
      result/success                  final; .result + .usage + .total_cost_usd
    """
    resume = session_jsonl_exists(session_id)
    model = channel_model(channel, prompt)
    perm = channel_permission(channel)
    cmd = [CLAUDE_BIN, '-p', prompt,
           *_resolve_model_args(model),
           '--append-system-prompt', _sys_prompt(channel),
           '--disallowedTools', *DISALLOWED_TOOLS,
           '--output-format', 'stream-json', '--verbose',
           '--include-partial-messages',
           '--permission-mode', perm]
    cmd += _resume_or_seed_args(channel, session_id)
    log(f'claude stream ({"resume" if resume else "new"}) sid={session_id[:8]} '
        f'model={model} perm={perm} prompt={prompt[:60]!r}')

    steps = []            # list of {icon, tool, label, done}
    text = ''             # accumulated final-answer text (text_delta only)
    cur_block = None      # type of the currently open streamed block
    result_data = None
    final_text = None
    last_ctx_usage = None  # last assistant message's usage = true context size

    def flush(phase):
        write_live(channel, {'active': True, 'phase': phase,
                             'steps': steps, 'text': text})

    flush('thinking')
    try:
        # start_new_session=True puts claude (and any subprocesses it spawns)
        # into its own process group so /api/stop can kill the whole tree with
        # one signal to -pid, not just the claude parent.
        proc = subprocess.Popen(
            cmd, cwd=REPO_ROOT, stdout=subprocess.PIPE, stderr=subprocess.PIPE,
            text=True, bufsize=1, **_PROC_GROUP_KW, env=_child_env(channel),
        )
    except Exception as e:
        return None, None, f'spawn failed: {e}'
    # record the live PID so server.py /api/stop can kill exactly this turn
    write_pid(channel, proc.pid)

    start = time.time()
    last_activity = start   # reset on EVERY line from claude (any sign of life)
    try:
        # iter(readline,'') instead of `for line in proc.stdout`: the watchdog
        # wakes us every IDLE_TICK seconds of silence so we can still react to the
        # Стоп button and the absolute backstop on a quiet turn. We do NOT abort on
        # idle anymore: a long, silent turn (big build, deep think) keeps running.
        # Only TURN_TIMEOUT (runaway-loop guard) or /api/stop ends it early.
        for line in _iter_with_idle(proc):
            if line is _IDLE_TICK:
                # watchdog woke us with no new output. Check ONLY the absolute
                # backstop and the user's Стоп. NO idle auto-abort.
                now = time.time()
                if now - last_activity > IDLE_TIMEOUT:
                    # Calm "still working" UI signal, NOT a kill: the turn is just
                    # quiet (thinking / long tool). Keep the streamed text + steps.
                    write_live(channel, {'active': True, 'phase': 'thinking',
                                         'steps': steps, 'text': text,
                                         'longRunning': True})
                if now - start > TURN_TIMEOUT:
                    proc.kill(); _reap(proc)
                    return None, None, f'timeout after {TURN_TIMEOUT}s'
                if pid_was_stopped(channel, proc.pid):
                    _reap(proc)
                    return text, result_data, STOP_SENTINEL
                continue
            last_activity = time.time()   # got real output -> reset idle clock
            # External stop (server.py /api/stop removed our pid file): bail out
            # quietly. The kill itself usually closes stdout first, but this
            # catches the rare case where claude buffers output post-signal.
            # Return the streamed-so-far text so the partial is preserved.
            if pid_was_stopped(channel, proc.pid):
                _reap(proc)
                return text, result_data, STOP_SENTINEL
            line = line.strip()
            if not line:
                continue
            try:
                ev = json.loads(line)
            except Exception:
                continue
            t = ev.get('type')

            if t == 'stream_event':
                inner = ev.get('event', {}) or {}
                et = inner.get('type')
                if et == 'content_block_start':
                    cb = inner.get('content_block', {}) or {}
                    cur_block = cb.get('type')
                    if cur_block == 'tool_use':
                        # partial start: show the tool name immediately; the
                        # full input arrives in the matching assistant event.
                        name = cb.get('name', '')
                        steps.append({'icon': _tool_icon(name), 'tool': name,
                                      'label': '', 'done': False})
                        flush('tool')
                elif et == 'content_block_delta':
                    d = inner.get('delta', {}) or {}
                    if d.get('type') == 'text_delta' and d.get('text'):
                        text += d['text']
                        flush('writing')
                elif et == 'content_block_stop':
                    cur_block = None

            elif t == 'assistant':
                # finalized message: tool_use blocks now have complete .input.
                # Capture this message's OWN usage. The last assistant message of
                # the turn carries the true context occupancy (its input side),
                # unlike the result event whose usage SUMS cache reads over every
                # agentic step. See write_usage for why that matters.
                _mu = (ev.get('message', {}) or {}).get('usage')
                if _mu:
                    last_ctx_usage = _mu
                for b in (ev.get('message', {}) or {}).get('content', []):
                    if b.get('type') == 'tool_use':
                        name = b.get('name', '')
                        label = _tool_label(name, b.get('input'))
                        # backfill the most recent unlabeled step for this tool,
                        # else append (covers tools without a partial start).
                        slot = next((s for s in reversed(steps)
                                     if s['tool'] == name and not s['label']
                                     and not s['done']), None)
                        if slot:
                            slot['label'] = label
                        else:
                            steps.append({'icon': _tool_icon(name), 'tool': name,
                                          'label': label, 'done': False})
                        # «Процеси» panel timeline: a Task tool is a sub-agent launch,
                        # everything else is a tool step (Vova 2026-07-08).
                        if name == 'Task':
                            emit_event(channel, {'kind': 'agent', 'phase': 'start',
                                'name': (b.get('input') or {}).get('subagent_type') or 'agent',
                                'detail': label})
                        else:
                            emit_event(channel, {'kind': 'tool', 'phase': 'start',
                                'name': name, 'detail': label})
                        flush('tool')

            elif t == 'user':
                # tool_result: mark the oldest not-done step as completed.
                slot = next((s for s in steps if not s['done']), None)
                if slot:
                    slot['done'] = True
                    emit_event(channel, {
                        'kind': 'agent' if slot.get('tool') == 'Task' else 'tool',
                        'phase': 'done', 'name': slot.get('tool') or '',
                        'detail': slot.get('label') or ''})
                    flush('tool')

            elif t == 'result':
                result_data = ev
                if last_ctx_usage:
                    ev['contextUsage'] = last_ctx_usage
                if ev.get('is_error'):
                    err = ev.get('result') or 'unknown error'
                    return None, ev, f'claude error: {err}'
                final_text = (ev.get('result') or '').strip()

        proc.wait(timeout=10)
    except Exception as e:
        if pid_was_stopped(channel, proc.pid):
            _reap(proc)
            return text, result_data, STOP_SENTINEL
        try:
            proc.kill()
        except Exception:
            pass
        _reap(proc)
        return None, result_data, f'stream parse failed: {e}'

    # Intentional kill via /api/stop: stdout closed, process died on a signal,
    # and our pid file is gone. Report the stop sentinel, not a crash. Carry the
    # streamed-so-far text so process_channel can keep the partial.
    if pid_was_stopped(channel, proc.pid):
        _reap(proc)
        return text, result_data, STOP_SENTINEL

    if proc.returncode not in (0, None):
        tail = (proc.stderr.read() if proc.stderr else '') or ''
        tail = tail.strip()[-500:]
        if not final_text:
            return None, result_data, f'claude exited {proc.returncode}: {tail}'

    # Prefer the result event's text; fall back to streamed text if missing.
    out = final_text if final_text is not None else text.strip()
    return out, result_data, None


def _warm_get(channel, session_id, prompt):
    """Return a LIVE persistent claude (stream-json in+out) for this channel,
    spawning/respawning if missing, dead, or bound to a different (rotated) sid.
    Caller must hold _warm_lock. Drains stderr in a daemon thread so the pipe
    never fills and deadlocks the long-lived process. `prompt` is the current
    user turn text, used to resolve an 'auto' channel model per turn complexity
    (same as the stream/SDK branches); without it channel_model(auto) NameErrors."""
    from collections import deque
    e = _warm.get(channel)
    if e is not None:
        proc = e['proc']
        if proc.poll() is None and e['sid'] == session_id:
            return e
        # dead, or the session was rotated (compaction): tear the old one down.
        try:
            if proc.poll() is None:
                proc.kill()
        except Exception:
            pass
        _warm.pop(channel, None)
    model = channel_model(channel, prompt)
    perm = channel_permission(channel)
    resume = session_jsonl_exists(session_id)
    cmd = [CLAUDE_BIN, '-p',
           '--input-format', 'stream-json',
           '--output-format', 'stream-json', '--verbose',
           '--include-partial-messages',
           *_resolve_model_args(model),
           '--append-system-prompt', _sys_prompt(channel),
           '--disallowedTools', *DISALLOWED_TOOLS,
           '--permission-mode', perm]
    cmd += _resume_or_seed_args(channel, session_id)
    spawn_env = _child_env(channel)
    if PERMUI_MODE:
        cmd += ['--settings', _perm_settings_arg()]
        spawn_env['CHAT_PERM_CHANNEL'] = channel
        spawn_env['CHAT_PERM_PORT'] = str(PERM_PORT)
        # Ensure the gate hook (and any node-based tool subprocess) can find node
        # even when launchd gave us a stripped PATH.
        _nd = os.path.dirname(NODE_BIN)
        if _nd and _nd not in spawn_env.get('PATH', ''):
            spawn_env['PATH'] = _nd + os.pathsep + spawn_env.get('PATH', '')
    log(f'{channel}: claude WARM spawn ({"resume" if resume else "new"}) '
        f'sid={session_id[:8]} model={model} perm={perm} permui={PERMUI_MODE}')
    proc = subprocess.Popen(
        cmd, cwd=REPO_ROOT, stdin=subprocess.PIPE,
        stdout=subprocess.PIPE, stderr=subprocess.PIPE,
        text=True, bufsize=1, **_PROC_GROUP_KW, env=spawn_env)
    buf = deque(maxlen=300)
    def _drain():
        try:
            for ln in proc.stderr:
                buf.append(ln)
        except Exception:
            pass
    threading.Thread(target=_drain, daemon=True).start()
    # ONE persistent stdout reader for the LIFETIME of this warm process, pushing
    # every line onto a shared Queue. All turns of this process drain the SAME
    # queue, so no line is ever lost between turns (a per-turn reader thread would
    # leak across the result-boundary `break` and steal the next turn's first
    # line). The turn loop reads with a timeout to detect idle/wedged turns; on
    # EOF the reader pushes None so a dead process is noticed.
    import queue as _queue
    stdout_q = _queue.Queue()
    def _read_stdout():
        try:
            for ln in proc.stdout:
                stdout_q.put(ln)
        except Exception:
            pass
        finally:
            stdout_q.put(None)
    threading.Thread(target=_read_stdout, daemon=True).start()
    e = {'proc': proc, 'sid': session_id, 'stderr': buf, 'stdout_q': stdout_q}
    _warm[channel] = e
    return e


def run_claude_warm(prompt, session_id, channel):
    """Warm-session turn (CHAT_RUNNER_WARM=1): feed the prompt to a PERSISTENT
    claude over stdin and read its stream-json events until this turn's `result`,
    leaving the process ALIVE for the next turn (no cold start). Same return
    contract as run_claude_stream: (text, result_data, error). On stop/timeout/
    crash the warm proc is torn down; the next turn respawns and --resume restores
    full context from claude's own session .jsonl, so nothing is lost."""
    with _warm_lock:
        try:
            e = _warm_get(channel, session_id, prompt)
        except Exception as ex:
            return None, None, f'warm spawn failed: {ex}'
    proc = e['proc']
    write_pid(channel, proc.pid)
    # Send the user turn as a stream-json user message line.
    try:
        msg = json.dumps({'type': 'user', 'message': {'role': 'user',
              'content': [{'type': 'text', 'text': prompt}]}}, ensure_ascii=False)
        proc.stdin.write(msg + '\n')
        proc.stdin.flush()
    except Exception as ex:
        with _warm_lock:
            _warm.pop(channel, None)
        try:
            proc.kill()
        except Exception:
            pass
        return None, None, f'warm stdin write failed: {ex}'

    steps = []
    text = ''
    cur_block = None
    result_data = None
    final_text = None
    last_ctx_usage = None  # last assistant message's usage = true context size

    def flush(phase):
        write_live(channel, {'active': True, 'phase': phase,
                             'steps': steps, 'text': text})

    def _drop_warm():
        with _warm_lock:
            if _warm.get(channel) is e:
                _warm.pop(channel, None)
        try:
            proc.kill()
        except Exception:
            pass

    import queue as _queue
    stdout_q = e['stdout_q']   # ONE persistent reader for the warm proc lifetime
    proc_eof = False
    flush('thinking')
    start = time.time()
    last_activity = start   # reset on EVERY line from claude (any sign of life)
    try:
        while True:
            try:
                line = stdout_q.get(timeout=IDLE_TICK)
            except _queue.Empty:
                # watchdog tick: no new output. Check ONLY the absolute backstop
                # and the user's Стоп. NO idle auto-abort anymore: a long, silent
                # turn (deep think / long tool) keeps running under the Стоп button.
                now = time.time()
                if now - last_activity > IDLE_TIMEOUT:
                    # Calm "still working" UI signal, NOT a kill. Keep the warm proc
                    # alive and the streamed text + steps intact.
                    write_live(channel, {'active': True, 'phase': 'thinking',
                                         'steps': steps, 'text': text,
                                         'longRunning': True})
                if now - start > TURN_TIMEOUT:
                    _drop_warm(); _reap(proc)
                    return None, None, f'timeout after {TURN_TIMEOUT}s'
                if pid_was_stopped(channel, proc.pid):
                    _drop_warm(); _reap(proc)
                    return text, result_data, STOP_SENTINEL
                continue
            if line is None:
                proc_eof = True   # reader hit EOF -> process died
                break
            last_activity = time.time()   # got real output -> reset idle clock
            # External stop: carry the streamed-so-far text so the partial stays.
            if pid_was_stopped(channel, proc.pid):
                _drop_warm(); _reap(proc)
                return text, result_data, STOP_SENTINEL
            line = line.strip()
            if not line:
                continue
            try:
                ev = json.loads(line)
            except Exception:
                continue
            t = ev.get('type')

            if t == 'stream_event':
                inner = ev.get('event', {}) or {}
                et = inner.get('type')
                if et == 'content_block_start':
                    cb = inner.get('content_block', {}) or {}
                    cur_block = cb.get('type')
                    if cur_block == 'tool_use':
                        name = cb.get('name', '')
                        steps.append({'icon': _tool_icon(name), 'tool': name,
                                      'label': '', 'done': False})
                        flush('tool')
                elif et == 'content_block_delta':
                    d = inner.get('delta', {}) or {}
                    if d.get('type') == 'text_delta' and d.get('text'):
                        text += d['text']
                        flush('writing')
                elif et == 'content_block_stop':
                    cur_block = None

            elif t == 'assistant':
                _mu = (ev.get('message', {}) or {}).get('usage')
                if _mu:
                    last_ctx_usage = _mu
                for b in (ev.get('message', {}) or {}).get('content', []):
                    if b.get('type') == 'tool_use':
                        name = b.get('name', '')
                        label = _tool_label(name, b.get('input'))
                        slot = next((s for s in reversed(steps)
                                     if s['tool'] == name and not s['label']
                                     and not s['done']), None)
                        if slot:
                            slot['label'] = label
                        else:
                            steps.append({'icon': _tool_icon(name), 'tool': name,
                                          'label': label, 'done': False})
                        flush('tool')

            elif t == 'user':
                slot = next((s for s in steps if not s['done']), None)
                if slot:
                    slot['done'] = True
                    flush('tool')

            elif t == 'result':
                result_data = ev
                if last_ctx_usage:
                    ev['contextUsage'] = last_ctx_usage
                if ev.get('is_error'):
                    err = ev.get('result') or 'unknown error'
                    # A turn error does NOT necessarily kill the process; but to be
                    # safe (avoid a wedged session) drop it so the next turn resumes.
                    _drop_warm()
                    return None, ev, f'claude error: {err}'
                final_text = (ev.get('result') or '').strip()
                break   # turn boundary: keep the process ALIVE for the next turn
        if proc_eof:
            # stdout reached EOF -> the persistent process died. If /api/stop already
            # removed our pid file, this EOF IS the stop (server SIGKILLed the warm
            # proc): report STOP_SENTINEL, NOT a transient "stdout closed" error.
            # Otherwise the drain loop treats 'stdout closed' as transient, RETRIES,
            # respawns warm and re-runs the same prompt, i.e. the turn "continues"
            # right after Stop. That was the intermittent "зупиняє і продовжує" bug.
            if pid_was_stopped(channel, proc.pid):
                _drop_warm()
                return text, result_data, STOP_SENTINEL
            tail = (''.join(e['stderr']) or '').strip()[-400:]
            _drop_warm()
            if final_text is None:
                return None, result_data, f'warm process ended: {tail or "stdout closed"}'
    except Exception as ex:
        if pid_was_stopped(channel, proc.pid):
            _drop_warm(); _reap(proc)
            return text, result_data, STOP_SENTINEL
        _drop_warm()
        return None, result_data, f'warm stream failed: {ex}'

    out = final_text if final_text is not None else text.strip()
    return out, result_data, None


def _project_map(channel):
    """Phase B: compact ecosystem snapshot injected into EVERY chat so it knows
    what else exists in this ChatView project (canvas pages, helpers, other chats).
    Never raises. On any error returns '' so awareness injection can never break a
    turn. Built fresh at spawn via the shared project_state aggregator."""
    try:
        import project_state
        st = project_state.build_project_state(DIR, REPO_ROOT)
        cv, ch, hp = st['canvases'], st['chats'], st['helpers']
        cv_s = ', '.join(f"{c['title']} ({c['id']})" for c in cv[:40])
        ch_s = ', '.join(c['label'] for c in ch[:40])
        inst = ', '.join(hp['installed'][:20])
        cat = hp.get('catalog', {})
        return (
            '\n\n[ChatView екосистема цього проєкту. Ти не один: ось що поруч, '
            'ти знаєш про це і можеш діяти]\n'
            f"Канви ({len(cv)}): {cv_s}.\n"
            f"Чати ({len(ch)}): {ch_s}.\n"
            f"Помічники: встановлено {len(hp['installed'])} ({inst}); "
            f"каталог {cat.get('local', 0)} локальних + {cat.get('remote', 0)} зовнішніх.\n"
            'Коли користувач згадує канву, сторінку, помічника чи інший чат, ти '
            'знаєш що воно існує. Свіжий стан + як діяти (додати на канву, '
            'поставити помічника) у відповіді: GET /api/project-state.'
        )
    except Exception:
        return ''


def _sys_prompt(channel):
    """CHAT_SYSTEM_OVERRIDE + the live ecosystem map (Phase B awareness)."""
    return CHAT_SYSTEM_OVERRIDE + _project_map(channel)


def _sdk_deps(channel):
    """Bundle the runner helpers/constants engine_sdk needs into one namespace,
    so engine_sdk stays decoupled (no `import runner`, which would re-run this
    module under its real name and double-spawn everything)."""
    import types
    return types.SimpleNamespace(
        REPO_ROOT=REPO_ROOT, CLAUDE_BIN=CLAUDE_BIN,
        CHAT_SYSTEM_OVERRIDE=_sys_prompt(channel),
        DISALLOWED_TOOLS=DISALLOWED_TOOLS, CHANNELS_DIR=CHANNELS_DIR,
        STOP_SENTINEL=STOP_SENTINEL,
        channel_model=channel_model, channel_permission=channel_permission,
        child_env=_child_env, write_live=write_live, clear_live=clear_live,
        write_pid=write_pid, clear_pid=clear_pid, pid_was_stopped=pid_was_stopped,
        tool_icon=_tool_icon, tool_label=_tool_label,
        session_jsonl_exists=session_jsonl_exists, log=log,
    )


def _sdk_enabled(channel):
    """Per-channel SDK opt-in (channels/<id>/engine == 'sdk') overrides the global
    SDK_MODE, so we can A/B the SDK engine on ONE channel while every other channel
    stays on the proven warm engine. Read live each turn (no restart to flip)."""
    try:
        p = os.path.join(CHANNELS_DIR, channel, 'engine')
        if os.path.exists(p):
            return open(p).read().strip().lower() == 'sdk'
    except Exception:
        pass
    return SDK_MODE


def run_claude_sdk_turn(prompt, session_id, channel):
    """SDK engine dispatch with a safety net: if the SDK module fails to import or
    hits a transport-level error, fall back to the proven warm engine for this
    turn (a normal `claude error` or a user stop is passed through, NOT retried)."""
    try:
        import engine_sdk
    except Exception as e:
        log(f'{channel}: SDK engine import failed ({e}); using warm')
        return run_claude_warm(prompt, session_id, channel)
    text, data, err = engine_sdk.run_claude_sdk(prompt, session_id, channel, _sdk_deps(channel))
    if err and isinstance(err, str) and err.startswith('sdk'):
        log(f'{channel}: SDK engine error ({err}); falling back to warm')
        return run_claude_warm(prompt, session_id, channel)
    return text, data, err


def run_claude(prompt, session_id, channel):
    """Single-shot json turn (Stage 1/2 fallback, CHAT_RUNNER_STREAM=0). First
    turn for a session uses --session-id (creates it), later turns use --resume
    (continues with full context). Returns (text, data_or_None, error_or_None)
    where data is the full parsed JSON result so the caller can read .usage /
    .total_cost_usd for the context+cost meter."""
    resume = session_jsonl_exists(session_id)
    model = channel_model(channel, prompt)
    perm = channel_permission(channel)
    cmd = [CLAUDE_BIN, '-p', prompt,
           *_resolve_model_args(model),
           '--append-system-prompt', _sys_prompt(channel),
           '--disallowedTools', *DISALLOWED_TOOLS,
           '--output-format', 'json',
           '--permission-mode', perm]
    cmd += _resume_or_seed_args(channel, session_id)
    log(f'claude turn ({"resume" if resume else "new"}) sid={session_id[:8]} '
        f'model={model} perm={perm} prompt={prompt[:60]!r}')
    # Popen (not subprocess.run) so we can record the PID for /api/stop and kill
    # the whole process group. start_new_session gives claude its own group.
    try:
        proc = subprocess.Popen(
            cmd, cwd=REPO_ROOT, stdout=subprocess.PIPE, stderr=subprocess.PIPE,
            text=True, **_PROC_GROUP_KW, env=_child_env(channel),
        )
    except Exception as e:
        return None, None, f'spawn failed: {e}'
    write_pid(channel, proc.pid)
    try:
        # Single-shot mode has no event stream, so there is no idle signal to act
        # on: only the absolute backstop (TURN_TIMEOUT, default 1h) guards against
        # a runaway. There is no partial to preserve here (the reply only exists
        # once the whole turn finishes). This path is the CHAT_RUNNER_STREAM=0
        # emergency fallback; the default warm/stream paths are idle-based.
        out_s, err_s = proc.communicate(timeout=TURN_TIMEOUT)
    except subprocess.TimeoutExpired:
        proc.kill()
        return None, None, f'timeout after {TURN_TIMEOUT}s'
    # Intentional kill via /api/stop -> quiet stop, not an error bubble.
    if pid_was_stopped(channel, proc.pid):
        return None, None, STOP_SENTINEL
    if proc.returncode != 0:
        tail = (err_s or out_s or '').strip()[-500:]
        return None, None, f'claude exited {proc.returncode}: {tail}'
    try:
        data = json.loads(out_s)
    except Exception as e:
        return None, None, f'bad json output: {e}; raw={out_s[:300]}'
    if data.get('is_error'):
        return None, data, f'claude error: {data.get("result")}'
    return (data.get('result') or '').strip(), data, None


def write_usage(channel, data):
    """Persist a cumulative usage/cost summary for the channel meter.

    v2.1.169 fields used (verified against a real `claude -p ... --output-format
    json` call):
      data.total_cost_usd                      cumulative cost of this turn
      data.usage.input_tokens                  non-cached input this turn
      data.usage.cache_read_input_tokens       cached prompt read this turn
      data.usage.cache_creation_input_tokens   cache written this turn
      data.modelUsage[MODEL].contextWindow     1_000_000 for opus-4-8[1m]

    "Context load" = the full prompt that actually went to the model this turn =
    input_tokens + cache_read + cache_creation. (input_tokens alone is only the
    non-cached slice; in Claude Code most of the context is served from cache.)
    The meter is that sum / contextWindow.
    """
    try:
        u = (data or {}).get('usage', {}) or {}
        out = int(u.get('output_tokens', 0) or 0)
        # Context occupancy = the LAST assistant call's input side, NOT the
        # turn-aggregated usage. The result event's `usage` SUMS
        # cache_read_input_tokens across every agentic step of the turn, so a
        # multi-tool turn reports 100% to 500%+ of the window (that is read
        # throughput, not occupancy) and trips the auto-compact gate almost every
        # message. `contextUsage` is the final assistant message's own usage,
        # which is the real prompt size at turn end. Fall back to the aggregate
        # only when contextUsage is absent (rare non-stream json fallback path).
        cu = (data or {}).get('contextUsage') or u
        inp = int(cu.get('input_tokens', 0) or 0)
        cache_read = int(cu.get('cache_read_input_tokens', 0) or 0)
        cache_create = int(cu.get('cache_creation_input_tokens', 0) or 0)
        full_context = inp + cache_read + cache_create
        # contextWindow + actual model id: modelUsage is keyed by the real model
        # that ran this turn (e.g. "claude-haiku-4-5-20251001"). We take the
        # context window from whichever model has the largest one (the active
        # model), so the meter denominator follows the per-channel model. The
        # key itself is the ground-truth proof of which model executed.
        ctx_window = CONTEXT_WINDOW
        active_model = None
        mu = (data or {}).get('modelUsage', {}) or {}
        best_window = 0
        for name, m in mu.items():
            if not isinstance(m, dict):
                continue
            cw = int(m.get('contextWindow') or 0)
            if cw > best_window:
                best_window = cw
                ctx_window = cw
                active_model = name
        if active_model is None and mu:
            active_model = next(iter(mu.keys()))
        turn_cost = float((data or {}).get('total_cost_usd', 0) or 0)

        path = os.path.join(CHANNELS_DIR, channel, 'usage.json')
        prev = {}
        if os.path.exists(path):
            try:
                prev = json.load(open(path))
            except Exception:
                prev = {}
        cumulative = float(prev.get('cumulativeCostUsd', 0) or 0) + turn_cost
        payload = {
            'lastTurnInput': inp,
            'lastTurnCacheRead': cache_read,
            'lastTurnCacheCreate': cache_create,
            'lastTurnContext': full_context,
            'lastTurnOutput': out,
            'lastTurnCostUsd': round(turn_cost, 6),
            'cumulativeCostUsd': round(cumulative, 6),
            'contextWindow': ctx_window,
            'contextPct': round(min(100.0, 100.0 * full_context / ctx_window), 1) if ctx_window else 0,
            'activeModel': active_model,
            'ts': datetime.now().isoformat(),
        }
        atomic_write_json(path, payload)
        # Append a per-turn line to a GLOBAL usage history (foundation for the stats
        # panel). usage.json holds only the latest snapshot, so without this there is no
        # day/week history to aggregate. Best-effort; never affects the turn.
        try:
            hist = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'usage-history.jsonl')
            rec = {'ts': payload['ts'], 'channel': channel, 'cost': round(turn_cost, 6),
                   'in': inp, 'out': out, 'ctxPct': payload['contextPct'], 'model': active_model}
            with open(hist, 'a', encoding='utf-8') as hf:
                hf.write(json.dumps(rec, ensure_ascii=False) + '\n')
        except Exception:
            pass
        log(f'{channel}: usage ctx={full_context} ({payload["contextPct"]}%) '
            f'turn=${turn_cost:.4f} cum=${cumulative:.4f} model={active_model}')
    except Exception as e:
        log(f'{channel}: usage write failed: {e}')


# ---- Inline widget contract (Phase D) -------------------------------------
# The assistant structures its FINAL reply with fenced blocks whose info-string
# is `chatui`. Each block holds EITHER a JSON array of widget objects OR a single
# widget object. Blocks may be interleaved with normal markdown prose:
#
#   prose...
#   ```chatui
#   [ {"type":"verdict", ...}, {"type":"stat-grid", ...} ]
#   ```
#   more prose...
#   ```chatui
#   {"type":"conclusion","text":"...","tone":"green"}
#   ```
#
# reply_to_widgets() turns that into an ORDERED mixed widgets array:
#   - each non-empty prose segment -> {"type":"text","text": <markdown>}
#   - each chatui block -> its parsed widget item(s), spliced in order
# index.html already has ~30 live renderers dispatched by renderWidget over this
# array, so we only reconnect the last mile here (no renderer changes).
#
# Robustness: a chatui block that fails to JSON-parse, or an item without a
# "type" string, NEVER crashes the turn. We fall back to rendering that block's
# raw content as a plain text widget so the reply still lands, and continue.
# Backward compatible: a reply with ZERO chatui blocks yields exactly one text
# widget with the whole reply, identical to the pre-Phase-D behavior.

# Matches a ```chatui ... ``` fence. DOTALL so the body spans newlines; the body
# is captured non-greedily so back-to-back blocks do not merge. The opening fence
# may carry trailing spaces before the newline; the closing fence sits on its own
# line. We tolerate an optional language tail like ```chatui json (rare).
_CHATUI_FENCE = re.compile(
    r'```[ \t]*chatui[^\n]*\n(.*?)\n?```',
    re.DOTALL | re.IGNORECASE,
)


def _coerce_widget_items(parsed):
    """Normalize a parsed chatui block (array or single object) into a list of
    widget dicts. Returns (items, ok). ok is False when the shape is unusable or
    any item lacks a string "type", so the caller can fall back to raw text."""
    if isinstance(parsed, dict):
        items = [parsed]
    elif isinstance(parsed, list):
        items = parsed
    else:
        return [], False
    out = []
    for it in items:
        if not isinstance(it, dict) or not isinstance(it.get('type'), str) or not it.get('type'):
            return [], False
        out.append(it)
    return out, bool(out)


def reply_to_widgets(text):
    """Parse the assistant's final markdown reply into an ORDERED mixed widgets
    array, splitting on ```chatui``` fenced blocks (see contract above).

    - prose between/around blocks -> text widgets (markdown preserved verbatim)
    - each chatui block -> its widget item(s) spliced in order
    - malformed block or typeless item -> rendered as a plain text widget
      (raw block content), turn never crashes
    - zero chatui blocks -> single text widget with the whole reply (back-compat)
    """
    if not text or not text.strip():
        return [{'type': 'text', 'text': '(порожня відповідь)'}]

    widgets = []
    last_end = 0

    def push_prose(segment):
        seg = (segment or '').strip()
        if seg:
            widgets.append({'type': 'text', 'text': seg})

    for m in _CHATUI_FENCE.finditer(text):
        # prose before this fence
        push_prose(text[last_end:m.start()])
        last_end = m.end()

        block = (m.group(1) or '').strip()
        if not block:
            continue
        try:
            parsed = json.loads(block)
        except Exception as e:
            log(f'reply_to_widgets: chatui JSON parse failed ({e}); '
                f'falling back to text for this block')
            push_prose(block)
            continue
        items, ok = _coerce_widget_items(parsed)
        if not ok:
            log('reply_to_widgets: chatui block had no valid typed items; '
                'falling back to text for this block')
            push_prose(block)
            continue
        widgets.extend(items)

    # trailing prose after the last fence (or the whole reply if no fences)
    push_prose(text[last_end:])

    # Guard: an all-whitespace reply that somehow produced nothing.
    if not widgets:
        return [{'type': 'text', 'text': text.strip() or '(порожня відповідь)'}]
    return widgets


def text_to_widgets(text):
    """Backward-compatible alias. Phase D routes the final reply through
    reply_to_widgets(), which parses inline ```chatui``` blocks into a mixed
    widget array. A reply with no such block renders exactly as before."""
    return reply_to_widgets(text)


# ---- Declarative PLAN sidebar (Variant A) ---------------------------------
# The assistant DECLARES its plan as a fenced ```plan``` block of JSON (a full
# snapshot each turn). The RUNNER is the SOLE writer of channels/<id>/plan.json:
# it extracts the block, strips it from the visible reply, and persists it via the
# ONE canonical writer set-plan.cjs (DRY: no re-implementation of the plan schema).
# Design patterns: single-source-of-truth / SRP (one writer), dependency inversion
# (assistant emits abstract data, knows nothing of files/scripts), least privilege
# (assistant executes nothing), best-effort/fail-safe (a bad/absent block never
# crashes a turn nor corrupts an existing plan.json).
#
# The info-string must be EXACTLY `plan` (optional surrounding spaces/tabs, then a
# newline), so `planning` / `chatui` never match. DOTALL so the body spans lines;
# the body is captured non-greedily so stacked blocks do not merge.
_PLAN_FENCE = re.compile(
    r'```[ \t]*plan[ \t]*\n(.*?)\n?```',
    re.DOTALL | re.IGNORECASE,
)

# Absolute path to the canonical plan writer (reused, never re-implemented).
SET_PLAN_CJS = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'set-plan.cjs')


def extract_plan_block(text):
    """Split a ```plan``` declaration out of the assistant reply.

    Returns (clean_text, plan_json_str_or_None):
      - clean_text: the reply with ALL plan blocks removed and stray blank lines
        collapsed, so the block never renders as a bubble nor leaks into TTS.
      - plan_json_str: the raw JSON of the LAST plan block (the authoritative full
        snapshot when a reply somehow carries more than one), or None when there
        is no non-empty plan block.
    Pure/side-effect-free: safe to call anywhere, never raises on odd input."""
    if not text:
        return text, None
    matches = [m for m in _PLAN_FENCE.finditer(text) if (m.group(1) or '').strip()]
    if not matches:
        return text, None
    plan_json = matches[-1].group(1).strip()
    clean = _PLAN_FENCE.sub('', text)
    clean = re.sub(r'\n{3,}', '\n\n', clean).strip()
    return clean, (plan_json or None)


def persist_plan_declaration(channel, plan_json_str):
    """Persist a declared plan snapshot to channels/<id>/plan.json via set-plan.cjs
    (the SINGLE canonical writer). Best-effort and fail-safe: a malformed/empty
    block is validated here and skipped (logged) so it never reaches the writer and
    never corrupts an existing plan.json. Returns True only when the writer ran ok.

    Note: set-plan.cjs writes relative to ITS OWN dir (tools/viz/chat/channels), so
    in the desktop CHATVIEW_HOME build the plan would land beside the bundled tools
    rather than the per-user home; live/dev (this repo) is exact. Acceptable: the
    ban-vs-writer split is what matters, and set-plan.cjs stays the one writer."""
    if not plan_json_str or not plan_json_str.strip():
        return False
    # Validate here so a broken block never even reaches the writer.
    try:
        parsed = json.loads(plan_json_str)
    except Exception as e:
        log(f'{channel}: plan block invalid JSON, skipped ({e})')
        return False
    if not isinstance(parsed, dict):
        log(f'{channel}: plan block is not a JSON object, skipped')
        return False
    tmp = os.path.join(CHANNELS_DIR, channel,
                       f'.plan-decl.{os.getpid()}.{threading.get_ident()}.json')
    try:
        os.makedirs(os.path.dirname(tmp), exist_ok=True)
        with open(tmp, 'w', encoding='utf-8') as f:
            json.dump(parsed, f, ensure_ascii=False)
        # `node set-plan.cjs <channel> <tmpfile>`: channel is the non-file arg,
        # the absolute tmp path is the file arg (its arg parser keys off which
        # token is an existing file). Runner shelling is fine here: the BAN is on
        # the ASSISTANT, not on the runner (least privilege preserved).
        r = subprocess.run([NODE_BIN, SET_PLAN_CJS, channel, tmp],
                           capture_output=True, text=True, timeout=15,
                           env=_child_env(channel))
        if r.returncode != 0:
            log(f'{channel}: set-plan.cjs failed rc={r.returncode}: '
                f'{(r.stderr or r.stdout or "").strip()[:200]}')
            return False
        log(f'{channel}: plan persisted ({(r.stdout or "").strip()[:120]})')
        return True
    except Exception as e:
        log(f'{channel}: plan persist failed ({e})')
        return False
    finally:
        try:
            os.remove(tmp)
        except OSError:
            pass


def finalize_plan_declaration(channel, text):
    """Turn-finalize hook: extract any ```plan``` declaration from the assistant
    reply, persist it (single writer, best-effort), and return the reply with the
    block(s) STRIPPED so they never render as a bubble nor leak into TTS/retell.
    No plan block -> text unchanged and the existing plan.json is left untouched."""
    clean, plan_json = extract_plan_block(text)
    if plan_json is not None:
        persist_plan_declaration(channel, plan_json)
    return clean


# ---- channel storage (mirrors server.py / render-message.sh) ----

def channel_index_path(channel):
    return os.path.join(CHANNELS_DIR, channel, 'index.json')


def _channel_voice_auto(channel):
    """True when the channel's «Голосовий режим» toggle (channels/<id>/voice-auto) is ON."""
    try:
        v = open(os.path.join(CHANNELS_DIR, channel, 'voice-auto')).read().strip().lower()
        return v in ('1', 'true', 'yes', 'on')
    except Exception:
        return False


def _voice_speakable(text):
    """Turn the reply's OWN markdown text into a clean speakable string for TTS.
    This reads the ACTUAL message text verbatim (no LLM rephrasing/summary) and only
    strips non-speakable markdown noise: code fences, **bold**, *italic*, headings,
    bullets, links, em/en-dashes. Every word stays; only the symbols go."""
    import re
    t = (text or '')
    t = re.sub(r'```[\s\S]*?```', ' ', t)                 # fenced code blocks
    t = re.sub(r'`([^`]+)`', r'\1', t)                    # inline code
    t = re.sub(r'!?\[([^\]]+)\]\([^)]*\)', r'\1', t)      # [label](url) / images -> label
    t = re.sub(r'(\*\*|__)(.*?)\1', r'\2', t)             # **bold** / __bold__
    t = re.sub(r'(\*|_)(.*?)\1', r'\2', t)                # *italic* / _italic_
    t = re.sub(r'^[ \t]*#{1,6}[ \t]+', '', t, flags=re.M) # # headings
    t = re.sub(r'^[ \t]*[-*•+][ \t]+', '', t, flags=re.M) # - / * / • bullets
    t = re.sub(r'^[ \t]*>[ \t]?', '', t, flags=re.M)      # > blockquotes
    t = t.replace('—', ', ').replace('–', ', ')           # HARD: never em-dash in TTS
    t = re.sub(r'[ \t]+', ' ', t)
    t = re.sub(r'\n{2,}', '\n', t).strip()
    return t


def maybe_attach_voice(channel, widgets, text):
    """If voice-auto is ON for the channel, synth `text` via /api/voice (OpenAI Nova)
    and append an `audio` widget to `widgets` so the player sits ON THE SAME reply
    card. Graceful: never raises, bounded timeout, never blocks/fails the reply on a
    TTS error (Lesya is the server-side fallback inside /api/voice if OpenAI fails)."""
    try:
        if not _channel_voice_auto(channel) or not isinstance(widgets, list):
            return widgets
        say = _voice_speakable(text)   # the reply's OWN words, markdown stripped — NOT a summary
        if not say:
            return widgets
        if len(say) > 1500:
            say = say[:1500]
        import urllib.request
        body = json.dumps({'text': say, 'engine': 'openai',
                           'voice': 'nova', 'model': 'tts-1-hd'}).encode('utf-8')
        req = urllib.request.Request(
            'http://127.0.0.1:%s/api/voice' % PERM_PORT, data=body,
            headers={'Content-Type': 'application/json'}, method='POST')
        with urllib.request.urlopen(req, timeout=25) as resp:
            data = json.loads(resp.read().decode('utf-8'))
        url = data.get('url')
        if url:
            widgets.append({'type': 'audio', 'src': url,
                            'engine': data.get('engine', 'openai'),
                            'title': '🎙 Аудіо-версія', 'transcript': say})
            log(f'{channel}: voice-auto attached audio -> {url}')
    except Exception as e:
        log(f'{channel}: voice-auto skipped ({e})')
    return widgets


def compaction_divider_widget(freed_pct=None):
    """Build the explicit compaction stream item. The frontend renders type
    'compaction-divider' as a thin V3 chip divider (NOT a chat bubble). The
    `text` field is kept so any older/unknown renderer degrades to a plain line
    instead of an empty card. `freedPct` (the running context % right BEFORE the
    compaction) + `ts` feed the hover detail ("Звільнено ~N% · HH:MM").

    No em-dash anywhere by request (periods/commas only)."""
    w = {'type': 'compaction-divider',
         'text': '♻️ Контекст стиснуто (звільнив місце для нових повідомлень).',
         'ts': datetime.now().strftime('%H:%M')}
    try:
        if freed_pct is not None:
            fp = int(round(float(freed_pct)))
            if fp > 0:
                w['freedPct'] = fp
    except Exception:
        pass
    return w


def append_message(channel, widgets, frm='Claude', tag=None):
    ch_dir = os.path.join(CHANNELS_DIR, channel)
    os.makedirs(ch_dir, exist_ok=True)
    idx_path = channel_index_path(channel)
    items = []
    if os.path.exists(idx_path):
        try:
            items = json.load(open(idx_path))
        except Exception:
            items = []
    ids = [i.get('id', 0) for i in items]
    for f in glob.glob(os.path.join(ch_dir, '[0-9]*.json')):
        m = re.match(r'(\d+)', os.path.basename(f))
        if m:
            ids.append(int(m.group(1)))
    nxt = (max(ids) + 1) if ids else 1
    fname = f'{nxt:04d}.json'
    atomic_write_json(os.path.join(ch_dir, fname), widgets)
    items = [i for i in items if i.get('file') != fname]
    items.append({'id': nxt, 'file': fname,
                  'timestamp': datetime.now().strftime('%H:%M:%S'),
                  'from': frm, 'tag': tag or None})
    items.sort(key=lambda i: i['id'])
    atomic_write_json(idx_path, items)
    return nxt


def clear_busy(channel):
    p = os.path.join(CHANNELS_DIR, channel, 'busy')
    if os.path.exists(p):
        try:
            os.remove(p)
        except OSError:
            pass


def process_channel(channel):
    """Drain this channel's queue in order. Runs in its own thread."""
    try:
        q_dir = os.path.join(CHANNELS_DIR, channel, 'queue')
        while True:
            files = sorted(glob.glob(os.path.join(q_dir, '[0-9]*.json')))
            if not files:
                break
            qf = files[0]
            # Stop guard: server.py /api/stop removes the channel's `busy` flag
            # (and clears the queue) the moment Vova hits Стоп. If busy is gone
            # we must NOT start another turn — discard whatever the poller may
            # have raced in and exit quietly. This is the belt to the kill's
            # braces: even if a queue file lingers, no new claude is spawned.
            if not os.path.exists(os.path.join(CHANNELS_DIR, channel, 'busy')):
                log(f'{channel}: busy cleared (stop) — draining queue, no new turn')
                for f in files:
                    try:
                        os.remove(f)
                    except OSError:
                        pass
                return
            try:
                job = json.load(open(qf))
            except Exception as e:
                log(f'{channel}: bad queue file {qf}: {e}; dropping')
                os.remove(qf)
                continue
            prompt = job.get('text', '')
            attachments = job.get('attachments') or []
            # Inject attached IMAGE paths so Claude opens them via the Read tool —
            # Read renders images visually, so the model actually "sees" them.
            # NOTE: text-file content is already inlined into the prompt by
            # server.py /api/send, and doc (pdf/docx) paths already get their own
            # "open via Read" note there. So here we ONLY list image attachments;
            # listing text/doc again would be redundant. We branch on each
            # attachment's `kind` (image|text|doc), defaulting to image for legacy
            # items that predate the kind field.
            if attachments:
                img_paths = []
                for a in attachments:
                    if isinstance(a, dict):
                        p = a.get('path')
                        kind = a.get('kind', 'image')
                    else:
                        p, kind = a, 'image'
                    if p and kind == 'image':
                        img_paths.append(p)
                if img_paths:
                    listing = '\n'.join(img_paths)
                    prompt = (
                        f'{prompt}\n\n'
                        f'Прикріплені зображення (прочитай кожне через Read tool, '
                        f'щоб побачити вміст):\n{listing}'
                    )
            # Auto-compaction gate: if this channel's running context already
            # crossed the threshold, compact BEFORE spending this turn. The
            # summary turn rotates the session id, so we must re-read the bound
            # session id afterward (the job's stale session_id would resume the
            # poisoned session). On a failed/empty summary compact_channel returns
            # False and leaves everything as-is, so we just proceed normally.
            pct = read_context_pct(channel)
            if (pct is not None and pct >= COMPACT_THRESHOLD * 100
                    and autocompact_enabled(channel)):
                if compact_channel(channel, reason='auto'):
                    append_message(
                        channel,
                        [compaction_divider_widget(freed_pct=pct)],
                        frm='Claude', tag='compaction')
                    job['session_id'] = None  # force re-read of the rotated sid
            session_id = job.get('session_id')
            if not session_id:
                # fall back to channel-bound session file (also the path after a
                # compaction rotation above).
                sid_path = os.path.join(CHANNELS_DIR, channel, 'session-id')
                session_id = open(sid_path).read().strip() if os.path.exists(sid_path) else None
            if not session_id:
                log(f'{channel}: no session id, dropping job')
                os.remove(qf)
                continue
            # Seed the prompt with any pending compaction summary (set by the
            # auto-compact above, or by a manual /api/compact while idle). This
            # is what carries the prior context into the fresh session.
            prompt = seed_prompt_with_summary(channel, prompt)
            # Auto-retry transient server hiccups (529 / rate-limit / warm died)
            # BEFORE ever surfacing an error to the user — Vova should not have to
            # click "send" again for a temporary Anthropic overload. Timeouts and
            # policy blocks are NOT retried (a retry would just waste another turn).
            _model_safe_retry.discard(channel)   # clean state per prompt
            _FORCE_BARE['on'] = False
            _attempt = 0
            while True:
                _attempt += 1
                if _sdk_enabled(channel):
                    text, data, err = run_claude_sdk_turn(prompt, session_id, channel)
                elif WARM_MODE:
                    text, data, err = run_claude_warm(prompt, session_id, channel)
                elif STREAM_MODE:
                    text, data, err = run_claude_stream(prompt, session_id, channel)
                else:
                    text, data, err = run_claude(prompt, session_id, channel)
                # Robust stop detection (fixes "stopped then continued"): /api/stop
                # removes `busy` FIRST, before it kills the turn. If busy is gone
                # now, the user pressed Стоп while this turn ran. Force STOP_SENTINEL
                # so we do NOT retry (a transient-looking kill error like "warm
                # process ended" used to respawn the warm proc and re-run the same
                # prompt) and do NOT deliver a result that finished inside the
                # SIGTERM grace window before SIGKILL.
                if err != STOP_SENTINEL and not os.path.exists(
                        os.path.join(CHANNELS_DIR, channel, 'busy')):
                    log(f'{channel}: stop detected (busy cleared mid-turn), aborting turn')
                    err = STOP_SENTINEL
                # Self-heal a model/CLI failure ONCE with a bare safe model before
                # ever surfacing it: chosen model missing on this machine / old CLI.
                if (err and err != STOP_SENTINEL and _is_model_error(err)
                        and channel not in _model_safe_retry and _attempt <= 2):
                    log(f'{channel}: model/CLI error (try {_attempt}), retry with safe '
                        f'default model: {err[:110]}')
                    _model_safe_retry.add(channel)
                    _FORCE_BARE['on'] = True
                    write_live(channel, {
                        'active': True, 'phase': 'thinking',
                        'steps': [{'icon': '🧠', 'tool': 'Модель недоступна',
                                   'label': 'пробую безпечну модель', 'done': False}],
                        'text': ''})
                    continue
                if (err and err != STOP_SENTINEL and _is_transient_error(err)
                        and _attempt <= 2):
                    log(f'{channel}: transient error (try {_attempt}/3), retrying: {err[:90]}')
                    write_live(channel, {
                        'active': True, 'phase': 'thinking',
                        'steps': [{'icon': '⏳', 'tool': 'Сервер перевантажений',
                                   'label': f'пробую ще раз ({_attempt})', 'done': False}],
                        'text': ''})
                    time.sleep(2 * _attempt)
                    continue
                break
            _FORCE_BARE['on'] = False   # end the safe-model window promptly
            # this turn's process is done; drop our pid file (server may already
            # have removed it on a stop — clear_pid is a no-op then).
            clear_pid(channel)
            # Recover the streamed-so-far partial BEFORE we wipe live.json. Prefer
            # the engine's in-memory `text` (always current; survives the server
            # deleting live.json on /api/stop), and fall back to the live snapshot
            # for engines that return None on abort. The ONLY early-abort left is the
            # user's Стоп (/api/stop): the idle auto-abort was removed, so a long /
            # silent turn now runs to completion instead of being killed.
            aborted = (err == STOP_SENTINEL)
            partial_text = ''
            if aborted:
                partial_text = (text or '').strip()
                if not partial_text:
                    snap_text, _snap_steps = read_live_snapshot(channel)
                    partial_text = (snap_text or '').strip()
            # turn done: the final reply goes to a permanent bubble, so the
            # transient live panel can disappear now.
            clear_live(channel)
            # Intentional stop via /api/stop: the server already cleared the
            # queue/busy/live and may have written a tiny "⏹ Зупинено" bubble.
            # Keep whatever streamed before the stop as a real bubble (partial is
            # NOT discarded), then exit the drain loop quietly without an error
            # bubble and never re-pick the server-emptied queue.
            if err == STOP_SENTINEL:
                log(f'{channel}: turn stopped via /api/stop (partial {len(partial_text)} chars)')
                persist_partial(channel, partial_text,
                                '⏸ Зупинено (ось що встиг).')
                return
            if data:
                write_usage(channel, data)
            if err:
                # Raw technical error goes to the runner log only, never to the
                # user's chat bubble.
                log(f'{channel}: ERROR {err}')
                rotated = False
                if _is_policy_error(err):
                    rotate_session_id(channel)
                    rotated = True
                append_message(channel,
                               friendly_error_bubble(err, rotated, channel),
                               frm='Claude', tag='error')
            else:
                # Declarative PLAN sidebar: persist any ```plan``` block and strip
                # it from the reply (single writer = set-plan.cjs) BEFORE the reply
                # is turned into widgets or spoken, so it never leaks as a bubble.
                text = finalize_plan_declaration(channel, text)
                _w = reply_to_widgets(text)
                _w = maybe_attach_voice(channel, _w, text)   # voice-auto ON -> audio in the same card
                append_message(channel, _w, frm='Claude')
                log(f'{channel}: replied ({len(text)} chars)')
            # job done: remove it whether ok or error (error is reported in chat).
            # On a stop we already returned above, so the server-cleared queue is
            # never re-drained here.
            try:
                os.remove(qf)
            except OSError:
                pass
    finally:
        clear_busy(channel)
        clear_live(channel)
        clear_pid(channel)
        with _active_lock:
            _active.pop(channel, None)


def process_compact_request(channel):
    """Manual compaction worker (triggered by /api/compact -> compact-request
    marker). Summarizes + rotates + stashes the summary for the next prompt,
    even when the queue is empty. Holds the channel busy so the UI shows a
    spinner, and posts a small bubble at the end. The stashed pending-summary is
    consumed by the next real prompt (process_channel -> seed_prompt_with_summary)."""
    marker = compact_request_path(channel)
    busy = os.path.join(CHANNELS_DIR, channel, 'busy')
    try:
        # mark busy so the front end shows activity during the summary turn
        try:
            os.makedirs(os.path.join(CHANNELS_DIR, channel), exist_ok=True)
            with open(busy, 'w') as f:
                f.write(datetime.now().isoformat())
        except Exception:
            pass
        # Capture context % BEFORE compaction so the divider can show how much was
        # freed (compact_channel zeroes usage.json on success).
        pct_before = read_context_pct(channel)
        ok = compact_channel(channel, reason='manual')
        if ok:
            append_message(
                channel,
                [compaction_divider_widget(freed_pct=pct_before)],
                frm='Claude', tag='compaction')
        else:
            append_message(
                channel,
                [{'type': 'text', 'text':
                  'Поки нема що стискати (новий або порожній чат).'}],
                frm='Claude', tag='status')
    finally:
        # remove the marker so we do not loop, and free the channel
        if os.path.exists(marker):
            try:
                os.remove(marker)
            except OSError:
                pass
        clear_busy(channel)
        clear_live(channel)
        clear_pid(channel)
        with _active_lock:
            _active.pop(channel, None)


def poll_once():
    if not os.path.isdir(CHANNELS_DIR):
        return
    for channel in os.listdir(CHANNELS_DIR):
        ch_dir = os.path.join(CHANNELS_DIR, channel)
        if not os.path.isdir(ch_dir):
            continue
        # Manual compaction has priority and works even with an empty queue.
        # Only when the channel is not already occupied by a turn/compact.
        if os.path.exists(compact_request_path(channel)):
            with _active_lock:
                if _active.get(channel):
                    continue
                _active[channel] = True
            t = threading.Thread(target=process_compact_request,
                                 args=(channel,), daemon=True)
            t.start()
            continue
        q_dir = os.path.join(ch_dir, 'queue')
        if not os.path.isdir(q_dir):
            continue
        if not glob.glob(os.path.join(q_dir, '[0-9]*.json')):
            continue
        with _active_lock:
            if _active.get(channel):
                continue
            _active[channel] = True
        t = threading.Thread(target=process_channel, args=(channel,), daemon=True)
        t.start()


# ── Singleton guard ──────────────────────────────────────────────────────────
# Only ONE runner may poll the channels/ queue at a time. Two runners double-
# process prompts (both grab turns, warm/SDK sessions collide) and, historically,
# repeated `python runner.py` launches across sessions stacked up 8 stale runners.
# We hold a loopback lock socket for the whole process lifetime; a second runner
# fails to bind and exits immediately. The OS frees the port the instant the
# holder dies, so there is no stale-lock file to clean up (unlike a PID lock).
# Disable with CHAT_RUNNER_SINGLETON=0; move the port with CHAT_RUNNER_LOCK_PORT.
_SINGLETON_SOCK = None


def _acquire_singleton():
    """Bind the runner lock port. Returns True if we are the sole runner, False if
    another instance already holds it. Never raises."""
    global _SINGLETON_SOCK
    if os.environ.get('CHAT_RUNNER_SINGLETON', '1') in ('0', 'false', 'no'):
        return True
    import socket as _socket
    port = int(os.environ.get('CHAT_RUNNER_LOCK_PORT', '5561'))
    s = _socket.socket(_socket.AF_INET, _socket.SOCK_STREAM)
    # NOTE: deliberately NO SO_REUSEADDR — we WANT the 2nd bind to fail.
    try:
        s.bind(('127.0.0.1', port))
        s.listen(1)
    except OSError:
        try:
            s.close()
        except Exception:
            pass
        return False
    _SINGLETON_SOCK = s   # keep a ref alive so the port stays held for our lifetime
    return True


def main():
    if not _acquire_singleton():
        log('another runner already holds the lock port — exiting (singleton).')
        return
    log(f'runner up. repo={REPO_ROOT} claude={CLAUDE_BIN} model={MODEL} '
        f'perm={PERMISSION_MODE}')
    if not os.path.exists(CLAUDE_BIN):
        log(f'FATAL: claude binary not found at {CLAUDE_BIN}. Set CLAUDE_BIN.')
        sys.exit(1)
    while True:
        try:
            poll_once()
        except Exception as e:
            log(f'poll error: {e}')
        time.sleep(POLL_SECONDS)


if __name__ == '__main__':
    main()
