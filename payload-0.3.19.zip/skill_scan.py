"""Статичний скан чужого скіла перед встановленням.

Чому це взагалі є. Встановити скіл це не «додати рядок у список». Це покласти на
диск чужі інструкції, які потім виконуються з правами користувача на машині, де лежать
його ключі, його репозиторії і його .claude. Каталог знає про ці скіли рівно те,
що зібрав збирач 26 липня, а репозиторій міг змінитись учора ввечері.

Звідси розділення на дві лінії, і воно принципове:

  ПІДКАЗКА ПРИ ПЕРЕГЛЯДІ спирається на метадані каталогу (hasCode) і потрібна
  лише щоб не гортати наосліп. Вона дешева, миттєва і НЕ авторитетна.

  АВТОРИТЕТНА ПЕРЕВІРКА спирається на файли, які реально приїхали. Тому скіл
  спершу тягнеться в карантин, там сканується, і лише після явного слова користувача
  переїжджає у .claude/skills. Скан по метаданих у цій ролі був би театром: він
  описує минулий стан репозиторію, а на диск лягає теперішній.

Скан СИРО ТЕКСТОВИЙ, нічого не виконується і не імпортується. Це свідома стеля:
регулярка не розуміє наміру і її обходить будь-яка обфускація. Вона й не мусить.
Її робота це не довести безпечність, а показати людині факти, які інакше довелось
би шукати руками в двадцяти файлах: ось файл, ось рядок, ось що там написано.
"""

import os
import re

# Категорії свідомо різні за вагою. `secrets` і `destructive` це те, після чого
# «ой, я не подивився» вже не відкотиш, тому вони одні вмикають окреме
# підтвердження. Решта це привід прочитати, а не привід лякатись: половина
# нормальних скілів законно ходить у мережу і ставить пакети.
SEVERITY = {
    'secrets': 'high',
    'destructive': 'high',
    'shell': 'medium',
    'sensitive-write': 'medium',
    'network': 'low',
    'packages': 'low',
}

CATEGORY_LABEL = {
    'secrets': 'Доступ до секретів',
    'destructive': 'Руйнівні дії',
    'shell': 'Виконання шелу',
    'sensitive-write': 'Запис у чутливі місця',
    'network': 'Мережа',
    'packages': 'Встановлення пакетів',
}

# (категорія, людська назва правила, регулярка)
RULES = [
    # виконання шелу
    ('shell', 'bash', r'(?<![\w/-])bash(?![\w-])'),
    ('shell', 'sh -c', r'\bsh\s+-c\b'),
    ('shell', 'exec(', r'\bexec\s*\('),
    ('shell', 'spawn', r'\bspawn(Sync)?\s*\('),
    ('shell', 'child_process', r'child_process'),
    ('shell', 'subprocess', r'\bsubprocess\b'),
    ('shell', 'os.system', r'\bos\.system\s*\('),
    # мережа
    ('network', 'curl', r'(?<![\w/-])curl(?![\w-])'),
    ('network', 'wget', r'(?<![\w/-])wget(?![\w-])'),
    ('network', 'fetch(', r'\bfetch\s*\('),
    ('network', 'urllib', r'\burllib\b'),
    ('network', 'requests.', r'\brequests\.'),
    # секрети
    ('secrets', 'process.env', r'\bprocess\.env\b'),
    ('secrets', 'os.environ', r'\bos\.environ\b'),
    ('secrets', 'keys.json', r'\bkeys\.json\b'),
    ('secrets', '.env', r'(?<![\w.])\.env(?![\w])'),
    ('secrets', '~/.ssh', r'(~|\$HOME)?/\.ssh\b'),
    ('secrets', 'credentials', r'\bcredentials?\b'),
    # запис у чутливі місця
    ('sensitive-write', '.claude/', r'\.claude/'),
    ('sensitive-write', '~/Library', r'(~|\$HOME)/Library\b'),
    ('sensitive-write', '/etc', r'(?<![\w.])/etc/'),
    # руйнівне
    ('destructive', 'rm -rf', r'\brm\s+-[a-zA-Z]*[rR][a-zA-Z]*f?\b|\brm\s+-[a-zA-Z]*f[a-zA-Z]*[rR]\b'),
    ('destructive', 'sudo', r'(?<![\w-])sudo\s'),
    ('destructive', 'chmod 777', r'\bchmod\s+(-\S+\s+)?777\b'),
    # встановлення пакетів
    ('packages', 'npm install', r'\bnpm\s+(i|install|add)\b'),
    ('packages', 'pip install', r'\bpip3?\s+install\b'),
    ('packages', 'brew install', r'\bbrew\s+install\b'),
]

_COMPILED = [(cat, label, re.compile(rx)) for cat, label, rx in RULES]

# Що взагалі відкриваємо.
#
# Раніше тут стояв ЛИШЕ білий список розширень, і саме він тихо зʼїдав покриття:
# на реальному xlsx-скілі читалось 16 файлів із 55, бо 39 схем .xsd просто не
# були в списку. Вердикт «нічого страшного» по третині файлів це не вердикт, а
# вгадування, і найцікавіше має всі шанси лежати саме в непрочитаному.
#
# Тепер логіка зворотна: читаємо ВСЕ, крім того, що доведено не текст.
#   TEXT_EXT   — швидка смуга: знайоме розширення, нюхати не треба;
#   BINARY_EXT — те, що бінарне за визначенням (картинки, архіви, шрифти, медіа);
#   решта      — вирішує ВМІСТ: нульовий байт у першому кілобайті = бінарник.
# Розширення більше не мовчазний фільтр, а лише спосіб не нюхати зайвий раз.
TEXT_EXT = {
    '.md', '.markdown', '.txt', '.json', '.yaml', '.yml', '.toml', '.ini',
    '.cfg', '.conf', '.sh', '.bash', '.zsh', '.fish', '.py', '.js', '.mjs',
    '.cjs', '.ts', '.tsx', '.jsx', '.rb', '.go', '.rs', '.java', '.php',
    '.pl', '.lua', '.sql', '.html', '.htm', '.css', '.xml', '.env', '.example',
}
BINARY_EXT = {
    # картинки і відео
    '.png', '.jpg', '.jpeg', '.gif', '.bmp', '.ico', '.icns', '.webp', '.avif',
    '.tif', '.tiff', '.psd', '.mp4', '.mov', '.avi', '.mkv', '.webm',
    # звук
    '.mp3', '.wav', '.ogg', '.flac', '.m4a', '.aac',
    # архіви і пакети
    '.zip', '.gz', '.tgz', '.bz2', '.xz', '.7z', '.rar', '.tar', '.jar',
    '.whl', '.dmg', '.pkg', '.deb', '.rpm', '.iso',
    # шрифти
    '.woff', '.woff2', '.ttf', '.otf', '.eot',
    # зібране і бази
    '.so', '.dylib', '.dll', '.exe', '.bin', '.o', '.a', '.class', '.pyc',
    '.pyo', '.wasm', '.node', '.db', '.sqlite', '.sqlite3', '.pack', '.idx',
    # документи-контейнери (усередині zip, регуляркою не читаються)
    '.pdf', '.docx', '.xlsx', '.pptx', '.odt', '.ods', '.odp',
}
NO_EXT_OK = {'Makefile', 'Dockerfile', 'Procfile', 'SKILL', 'README', 'LICENSE'}

# Скільки байтів нюхаємо, щоб відрізнити текст від бінарника. Нульовий байт у
# перших кілобайтах не трапляється в жодному текстовому форматі і трапляється
# майже в кожному бінарному, тому дешева перевірка ловить решту випадків.
SNIFF_BYTES = 8192

SKIP_REASON = {
    'binary': 'бінарний файл, регуляркою не читається',
    'too-big': 'більший за ліміт на один файл',
    'unreadable': 'не вдалось прочитати',
    'over-limit': 'понад ліміт кількості файлів',
}

# Огорожа блоку коду в markdown. Сам рядок ```bash як доказ нічого не вартий:
# людині треба бачити КОМАНДУ, а не те, що далі буде команда. Тому для такого
# рядка ми показуємо перший змістовний рядок усередині блоку.
_FENCE_RE = __import__('re').compile(r'^\s*[`~]{3,}\s*(bash|sh|shell|zsh|console)\s*$')

MAX_FILE_BYTES = 512 * 1024
MAX_FILES = 400
MAX_FINDINGS = 120
SNIPPET = 160
SKIP_SHOWN = 12          # скільки пропущених називаємо поіменно у картці


def _classify(full, name):
    """-> None якщо файл треба читати, або причина пропуску (ключ SKIP_REASON).

    Порядок навмисний: спершу дешеве (розширення, розмір), і лише потім читання
    з диска. Файл без знайомого розширення не відкидається, а нюхається."""
    ext = os.path.splitext(name)[1].lower()
    if ext in BINARY_EXT:
        return 'binary'
    try:
        if os.path.getsize(full) > MAX_FILE_BYTES:
            return 'too-big'
    except OSError:
        return 'unreadable'
    if ext in TEXT_EXT or (not ext and name in NO_EXT_OK):
        return None
    try:
        with open(full, 'rb') as f:
            head = f.read(SNIFF_BYTES)
    except Exception:
        return 'unreadable'
    return 'binary' if b'\0' in head else None


def scan_dir(root):
    """-> {ok, files, scanned, skipped[], skippedTotal, skippedByReason{},
           findings[], byCategory{}, severity, requiresConfirm, truncated}

    findings: [{category, label, rule, file, line, snippet, severity}]
    skipped:  [{file, reason, why, bytes}] — перші SKIP_SHOWN штук

    Пропущене повертається ІМЕНАМИ і причинами, а не лише різницею двох чисел.
    «Проскановано 16 з 55» це питання без відповіді: людина не може вирішити,
    чи їй байдуже до тих 39, поки не знає, що це було і чому їх не відкрили."""
    findings = []
    scanned = 0
    skipped = []
    skipped_total = 0
    by_reason = {}
    files = 0
    truncated = False

    def skip(rel, reason, size=None):
        nonlocal skipped_total
        skipped_total += 1
        by_reason[reason] = by_reason.get(reason, 0) + 1
        if len(skipped) < SKIP_SHOWN:
            item = {'file': rel, 'reason': reason, 'why': SKIP_REASON[reason]}
            if size is not None:
                item['bytes'] = size
            skipped.append(item)

    for dp, dirs, fs in os.walk(root):
        dirs[:] = [d for d in dirs if d not in ('.git', 'node_modules', '__pycache__')]
        for name in sorted(fs):
            files += 1
            full = os.path.join(dp, name)
            rel = os.path.relpath(full, root)
            if files > MAX_FILES:
                truncated = True
                skip(rel, 'over-limit')
                continue
            reason = _classify(full, name)
            if reason:
                size = None
                if reason == 'too-big':
                    try:
                        size = os.path.getsize(full)
                    except OSError:
                        pass
                skip(rel, reason, size)
                continue
            try:
                with open(full, encoding='utf-8', errors='replace') as f:
                    lines = f.read().splitlines()
            except Exception:
                skip(rel, 'unreadable')
                continue
            scanned += 1
            seen_here = set()
            for ln, line in enumerate(lines, 1):
                if len(line) > 4000:
                    line = line[:4000]
                for cat, label, rx in _COMPILED:
                    if rx.search(line):
                        # один і той самий рядок правила на файл показуємо ОДИН раз:
                        # десять однакових curl у README це не десять фактів
                        k = (cat, label)
                        if k in seen_here:
                            continue
                        seen_here.add(k)
                        show_ln, show = ln, line.strip()
                        if _FENCE_RE.match(line):
                            for j in range(ln, min(ln + 12, len(lines))):
                                nxt = lines[j].strip()
                                if nxt and not nxt.startswith(('```', '~~~', '#')):
                                    show_ln, show = j + 1, nxt
                                    break
                        findings.append({
                            'category': cat,
                            'label': CATEGORY_LABEL[cat],
                            'rule': label,
                            'file': rel,
                            'line': show_ln,
                            'snippet': show[:SNIPPET],
                            'severity': SEVERITY[cat],
                        })
            if len(findings) > MAX_FINDINGS:
                truncated = True
                findings = findings[:MAX_FINDINGS]
                break
        if len(findings) >= MAX_FINDINGS:
            break

    by_cat = {}
    for f in findings:
        by_cat[f['category']] = by_cat.get(f['category'], 0) + 1
    order = {'high': 3, 'medium': 2, 'low': 1}
    findings.sort(key=lambda f: (-order[f['severity']], f['file'], f['line']))
    worst = 'none'
    for f in findings:
        if order[f['severity']] > order.get(worst, 0):
            worst = f['severity']
    return {
        'ok': True,
        'files': files,
        'scanned': scanned,
        'skipped': skipped,
        'skippedTotal': skipped_total,
        'skippedByReason': by_reason,
        'findings': findings,
        'byCategory': by_cat,
        'severity': worst,
        'requiresConfirm': any(f['severity'] == 'high' for f in findings),
        'truncated': truncated,
    }


_REASON_PLURAL = {
    'binary': 'бінарні',
    'too-big': 'більші за %d КБ' % (MAX_FILE_BYTES // 1024),
    'unreadable': 'не читаються',
    'over-limit': 'понад ліміт у %d файлів' % MAX_FILES,
}


def coverage(scan):
    """Один рядок про ПОКРИТТЯ: скільки прочитано і що саме лишилось поза скном.

    Окремо від summary(), бо це різні питання. summary відповідає «що знайшли»,
    а це відповідає «наскільки взагалі можна вірити першому». Мовчазна різниця
    між files і scanned знецінювала обидві відповіді одразу."""
    files = scan.get('files') or 0
    scanned = scan.get('scanned') or 0
    total_skipped = scan.get('skippedTotal') or 0
    if not files:
        return 'У карантині нема жодного файлу.'
    if not total_skipped:
        return ('Прочитано всі %d файлів скіла.' % files)
    by = scan.get('skippedByReason') or {}
    parts = ['%d %s' % (n, _REASON_PLURAL.get(r, r))
             for r, n in sorted(by.items(), key=lambda kv: -kv[1])]
    return ('Прочитано %d з %d файлів. Пропущено %d: %s.'
            % (scanned, files, total_skipped, ', '.join(parts)))


def summary(scan):
    """Один рядок для картки: що людині думати про цей скіл."""
    if not scan.get('findings'):
        return 'Чистий, лише інструкції: нічого з нашого списку ризиків не знайдено.'
    cats = scan.get('byCategory') or {}
    parts = [f'{CATEGORY_LABEL[c].lower()} ({n})'
             for c, n in sorted(cats.items(), key=lambda kv: -kv[1])]
    head = 'Знайдено: ' + ', '.join(parts) + '.'
    if scan.get('requiresConfirm'):
        head += ' Є звернення до секретів або руйнівні команди, тому встановлення просить окреме підтвердження.'
    return head
