"""Media src normalization for chat message widgets.

WHY THIS EXISTS
---------------
`src` on image/gallery/video/audio/file widgets had no enforced contract, so every
agent wrote whatever it had at hand. Three shapes ended up in channels/*/NNNN.json:

    /assets/portable-v2-light.png                     -> 200, works
    /Users/user/WebstormProjects/chatview/proof/x.png -> 404, filesystem path
    tools/viz/chat/proof-byok/voice-nokey-light.png   -> 404, repo-relative path

The browser cannot read a filesystem path over http, and it resolves a repo-relative
path against the page URL, not against the repo. Both 404. Worse, the failure was
SILENT: the image just never appeared, so the bug survived for months.

THE CONTRACT (single source of truth, mirrored in media-normalize.cjs)
---------------------------------------------------------------------
Put in `src` either a real URL (http/https/data/blob) or a path to a file on disk.
Anything that is already servable is left untouched. Anything that points at a real
file elsewhere on disk is COPIED into the media root (channels/_media, see
home_spread) under a content-hashed name and rewritten to that folder's URL. Anything
that resolves to nothing is flagged with `srcMissing: true` so the front end can draw
a loud placeholder instead of failing quietly.

Content-hashed names give us dedup for free: the same bytes always land on the same
filename, so re-posting or re-running the backfill never grows the folder and never
lets two different files with the same basename clobber each other.

The server serves everything under DIR (os.chdir(DIR) + SimpleHTTPRequestHandler),
so "servable" means "resolves to an existing file under DIR", not just "/assets/".
"""

import hashlib
import json
import os
import re
import shutil
from urllib.parse import unquote

import home_spread

# Widget types that carry media, and which of their keys hold a source path.
_MEDIA_KEYS = {
    'image': ('src', 'url', 'poster'),
    'video': ('src', 'url', 'poster'),
    'audio': ('src', 'url'),
    'file': ('src', 'url', 'path'),
    'gallery': (),          # handled via images[].src
}

_URL_RE = re.compile(r'^(?:https?|data|blob):', re.I)

# Поля віджетів, які фронт віддає в компонент Markdown (logopsis/src/widgets:
# Text -> text|body, Accordion -> items[].body, Reasoning -> body). ДЗЕРКАЛО
# MD_TEXT_KEYS у media-normalize.cjs. Саме в цих полях живе `[текст](адреса)`, і саме
# там локальний шлях лишався мертвим: сторінка віддається по http, а браузер не пускає
# перехід з http на file://, тож клік мовчки не робив нічого. Плюс з iPad через
# Tailscale file:// не дасть нічого в принципі, тому файл мусить віддавати сам :5555.
_MD_TEXT_KEYS = {
    'text': ('text', 'body'),
    'reasoning': ('body',),
    'accordion': (),        # через items[].body
}

# Один прохід по тексту: СПЕРШУ зʼїдаємо код (fenced і інлайн), і лише потім хвіст
# посилання `](адреса)`. Порядок альтернатив і є захистом коду: приклад markdown,
# показаний у бектіках, мусить лишитись рівно тим, що людина написала.
#
# Адреса читається З ПРОБІЛАМИ і з дужками всередині (specs/chat-links-not-rendered, К8).
# Було `[^)\s]+`: перший же пробіл рвав адресу, а перша дужка обрубувала href на
# `report (1`. Тепер дужка читається парою, тому закривна дужка ВСЕРЕДИНІ адреси не може
# стати кінцем збігу. Перенос рядка виключений явно: адреса ніколи не переносить, а без
# цієї межі незакрита `(` тягла б збіг через увесь абзац.
# ДЗЕРКАЛО MD_HREF_RE у media-normalize.cjs.
_MD_HREF_RE = re.compile(
    r'(```.*?```|`[^`\n]*`)'
    r'|(\]\(\s*)((?:[^()\s]|\([^()\n]*\))(?:[^()\n]|\([^()\n]*\))*?)(\s*\))', re.S)
# Кандидат на переписування рівно один: локальний файл, тобто `file://` або голий
# абсолютний шлях. Відносний href не чіпаємо, бо це може бути звичайна адреса сайту.
_LOCAL_HREF_RE = re.compile(r'^(?:file://|/)', re.I)

# ВОРОТА ДОЗВОЛЕНИХ КОРЕНІВ (specs/chat-links-not-rendered, К7). Привід: `_LOCAL_HREF_RE`
# ловить БУДЬ-ЯКИЙ абсолютний шлях, тож `[x](/etc/passwd)` змушував нормалізатор знайти
# файл і покласти його копію в channels/_media, тобто в теку під роздачею сервера. Спека
# цієї ж задачі відмовилась додавати ендпоінт читання довільних файлів, а тиха копія
# давала слабшу версію того самого, тільки назавжди. Список коренів лежить в ОДНОМУ файлі
# на обидва дзеркала: два списки розʼїхались би, і ворота стояли б лише на частині шляхів
# запису картки. ДЗЕРКАЛО rootsCfg() у media-normalize.cjs.
_ROOTS_CFG_PATH = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'link-roots.json')
_ROOTS_CFG = None

# Where message media lives, and the URL it is served at. BOTH come from
# home_spread, which derives them from entities.path_for('channel', '_media') — one
# root, one function, no constant assembled beside it (specs/user-data-architecture,
# К2 + К5). The folder used to be DIR/assets/media, i.e. inside a directory the
# desktop launcher declares READ-ONLY and re-copies from the bundle on every start:
# app files and the user's whole visual history shared one tree. LEGACY_* stay so
# an src written before the move still resolves — through the migration, not through
# a second storage root.
LEGACY_MEDIA_REL = 'assets/media'   # relative to DIR, pre-S6
LEGACY_MEDIA_URL = '/assets/media/'


def media_dir(dir_):
    """Absolute media folder for this home."""
    return home_spread.media_root(dir_)


def media_url(dir_):
    """URL prefix the browser asks for, derived from the folder itself."""
    return home_spread.media_url(dir_)

# Where this file lives -> shared-knowledge in a repo run. Kept as an extra lookup
# root so a repo-relative src still resolves when DIR is a LOGOPSIS_HOME payload
# (desktop/test harness) whose repo root points somewhere else entirely.
CODE_ROOT = os.path.abspath(os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', '..', '..'))


def _roots_cfg():
    global _ROOTS_CFG
    if _ROOTS_CFG is None:
        try:
            with open(_ROOTS_CFG_PATH, encoding='utf-8') as f:
                _ROOTS_CFG = json.load(f)
        except Exception:
            _ROOTS_CFG = {'contextRoots': [], 'homeRelative': [], 'denyDotSegments': True}
    return _ROOTS_CFG


def _realpath_safe(p):
    """Реальний шлях без симлінків. На macOS `/etc` це `/private/etc`, а tmp це
    `/private/var/folders/…`, тож без розвʼязання симлінків порівняння коренів бреше."""
    try:
        return os.path.realpath(p)
    except OSError:
        return os.path.abspath(p)


def allowed_roots(dir_, repo_root):
    """Абсолютні корені, всередині яких файл вважається робочим артефактом."""
    cfg = _roots_cfg()
    home = os.path.expanduser('~')
    ctx = {'dir': dir_, 'repoRoot': repo_root, 'codeRoot': CODE_ROOT,
           'tmp': _tmp_dir(), 'home': home}
    out = []
    for key in cfg.get('contextRoots') or []:
        if ctx.get(key):
            out.append(ctx[key])
    if home:
        for rel in cfg.get('homeRelative') or []:
            out.append(os.path.join(home, rel))
    seen, uniq = set(), []
    for c in out:
        c = _realpath_safe(c)
        if c not in seen:
            seen.add(c)
            uniq.append(c)
    return uniq


def _tmp_dir():
    import tempfile
    return tempfile.gettempdir()


def _has_dot_segment(rel):
    """Сегмент, що починається з крапки (`.ssh`, `.env`, `.git`), заборонений ВСЕРЕДИНІ
    дозволеного кореня: інакше «тека репо» тихо відкривала б і ключі поруч із кодом. Сам
    корінь при цьому може бути крапковим (LOGOPSIS_HOME буває `~/.logopsis`), тому
    перевіряємо рівно ту частину шляху, що лежить ПІД коренем."""
    return any(seg.startswith('.') and seg not in ('.', '')
               for seg in rel.replace('\\', '/').split('/'))


def _under_allowed_root(abs_path, dir_, repo_root):
    """ДЗЕРКАЛО underAllowedRoot у media-normalize.cjs."""
    cfg = _roots_cfg()
    p = _realpath_safe(abs_path)
    for root in allowed_roots(dir_, repo_root):
        if p != root and not p.startswith(root + os.sep):
            continue
        return not (cfg.get('denyDotSegments') and _has_dot_segment(p[len(root):]))
    return False


def _safe_name(name):
    """Імʼя файла, безпечне і для URL, і для диска, але ЛЮДСЬКЕ
    (specs/chat-links-not-rendered, К10). Було `[^A-Za-z0-9._-]+` -> `_`, тобто
    `звіт-кирилиця.html` перетворювався на `-_.html`, і саме цей залишок ставав видимим
    підписом посилання (linkLabel.human бере останній сегмент шляху). Тепер лишаємо
    будь-яку БУКВУ і ЦИФРУ, хоч кирилицю, хоч латиницю, і вирізаємо рівно небезпечне:
    роздільники шляху, пробіли, лапки, керівні символи. Перевірка посимвольна навмисно:
    `str.isalnum()` тут і `\\p{L}\\p{N}` у JS дають однаковий набір, а от `\\w` у двох
    рушіях означає різне. ДЗЕРКАЛО safeName у media-normalize.cjs."""
    out = []
    for ch in name:
        if ch.isalnum() or ch in '._-':
            out.append(ch)
        elif out and out[-1] != '_':
            out.append('_')
    return ''.join(out).strip('_') or 'file'


def _strip_query(s):
    """'assets/x.png?v=1#frag' -> 'assets/x.png'. Also URL-decodes %20 etc."""
    return unquote(s.split('#', 1)[0].split('?', 1)[0])


def _is_url(s):
    return bool(_URL_RE.match(s))


def _servable(s, dir_):
    """True when the browser can already fetch this path from the server.

    The server's document root is DIR, so both '/assets/x.png' and 'assets/x.png'
    resolve to DIR/assets/x.png. A path that escapes DIR (../) is never servable.
    """
    p = _strip_query(s).lstrip('/')
    if not p:
        return False
    root = os.path.abspath(dir_)
    cand = os.path.normpath(os.path.join(root, p))
    return (cand == root or cand.startswith(root + os.sep)) and os.path.isfile(cand)


def _disk_candidates(s, dir_, repo_root):
    """Every place on disk this string could plausibly mean, best guess first."""
    out = []
    for raw in (s, _strip_query(s)):
        if not raw:
            continue
        if raw.lower().startswith('file://'):
            raw = unquote(raw[7:])
        roots = (repo_root, dir_, os.getcwd(), CODE_ROOT)
        if os.path.isabs(raw):
            out.append(raw)
        else:
            for root in roots:
                if root:
                    out.append(os.path.join(root, raw))
        # '/tools/viz/chat/x.png' is repo-relative with a stray leading slash.
        if raw.startswith('/'):
            for root in roots:
                if root:
                    out.append(os.path.join(root, raw.lstrip('/')))
        # An src written before S6 points at DIR/assets/media/<name>; the bytes now
        # live under the channel class root. Looked up here rather than special-cased
        # in the callers, so re-normalising an old message quietly rewrites it to the
        # canonical URL instead of flagging a perfectly present file as missing.
        legacy = _strip_query(raw).lstrip('/')
        if legacy.startswith(LEGACY_MEDIA_REL + '/') and dir_:
            out.append(os.path.join(media_dir(dir_),
                                    legacy[len(LEGACY_MEDIA_REL) + 1:]))
    seen, uniq = set(), []
    for c in out:
        c = os.path.normpath(c)
        if c not in seen:
            seen.add(c)
            uniq.append(c)
    return uniq


def _find_on_disk(s, dir_, repo_root):
    for c in _disk_candidates(s, dir_, repo_root):
        try:
            if os.path.isfile(c):
                return c
        except OSError:
            continue
    return None


def _sha1(path):
    h = hashlib.sha1()
    with open(path, 'rb') as f:
        for chunk in iter(lambda: f.read(1 << 20), b''):
            h.update(chunk)
    return h.hexdigest()


def _publish(abs_path, dir_):
    """Copy a real file into the media root and return its browser URL.

    Idempotent by construction: the destination name is derived from the file's
    content hash, so a repeat call finds the copy already there and skips the I/O.

    ALREADY UNDER THE ROOT means already published. Without that gate the S6 legacy
    bridge would eat itself: an src written before the move (`/assets/media/<hash>-x`)
    no longer resolves at the old path, resolves at the new one, and would be
    "published" a second time under `<hash>-<hash>-x` — a byte-for-byte duplicate with
    a mangled name. Before S6 such an src was simply `servable` and never reached this
    function, so the whole back catalogue (15 663 messages) would have doubled on the
    first `backfill-media.cjs --apply`. The bytes are content-addressed; a file sitting
    in the root IS its own canonical copy.
    """
    root = media_dir(dir_)
    if os.path.dirname(os.path.realpath(abs_path)) == os.path.realpath(root):
        return media_url(dir_) + os.path.basename(abs_path)
    digest = _sha1(abs_path)[:12]
    base = _safe_name(os.path.basename(abs_path))
    if len(base) > 80:
        stem, ext = os.path.splitext(base)
        base = stem[:80 - len(ext)] + ext
    name = digest + '-' + base
    dest = os.path.join(root, name)
    if not os.path.isfile(dest) or os.path.getsize(dest) != os.path.getsize(abs_path):
        os.makedirs(root, exist_ok=True)
        tmp = dest + '.tmp'
        shutil.copyfile(abs_path, tmp)
        os.replace(tmp, dest)
    return media_url(dir_) + name


def normalize_src(s, dir_, repo_root, stats=None):
    """Resolve one src string. Returns (new_src, status).

    status is one of: 'url' (left alone), 'servable' (left alone),
    'copied' (rewritten into the media root), 'missing' (nothing on disk).
    """
    if not isinstance(s, str) or not s.strip():
        return s, 'url'
    if _is_url(s):
        return s, 'url'
    if _servable(s, dir_):
        return s, 'servable'
    found = _find_on_disk(s, dir_, repo_root)
    if found:
        try:
            return _publish(found, dir_), 'copied'
        except Exception:
            return s, 'missing'      # copy failed -> surface it, never fake success
    return s, 'missing'


def probe(s, dir_, repo_root=None):
    """Read-only twin of normalize_src: what WOULD happen, without doing it.

    Returns (status, resolved_abs_or_None) where status is 'url' | 'servable' |
    'disk' (a real file we would copy in) | 'missing'.

    Why it exists (specs/harness-80). normalize_src answers the same question but
    COPIES on the way, so it cannot be used to look before you leap. The model needs
    to know a path is dead BEFORE a card with a broken picture is written into the
    feed: `srcMissing` is only visible after the fact, and only to a human looking at
    the screen. Kept here, next to the copying code, so the two can never drift on
    what «a working src» means.
    """
    if repo_root is None:
        repo_root = os.path.abspath(os.path.join(dir_, '..', '..', '..'))
    if not isinstance(s, str) or not s.strip():
        return 'missing', None
    if _is_url(s):
        return 'url', None
    if _servable(s, dir_):
        return 'servable', None
    found = _find_on_disk(s, dir_, repo_root)
    return ('disk', found) if found else ('missing', None)


def _normalize_link_href(href, dir_, repo_root):
    """Локальний href посилання у робочу адресу. Returns (new_href, status).

    Відрізняється від normalize_src рівно воротами дозволених коренів: у ТЕКСТІ адресу
    пише вільна проза моделі, тож будь-який абсолютний шлях мусить пройти перевірку,
    перш ніж його байти лягають у теку під роздачею сервера. Статус 'blocked' це не
    помилка, а свідома відмова: посилання лишається дослівно таким, як написали.
    ДЗЕРКАЛО normalizeLinkHref у media-normalize.cjs.
    """
    if not isinstance(href, str) or not href.strip():
        return href, 'missing'
    if _is_url(href):
        return href, 'url'
    if _servable(href, dir_):
        return href, 'servable'
    found = _find_on_disk(href, dir_, repo_root)
    if not found:
        return href, 'missing'
    if not _under_allowed_root(found, dir_, repo_root):
        return href, 'blocked'
    try:
        return _publish(found, dir_), 'copied'
    except Exception:
        return href, 'missing'


def _md_links(md, dir_, repo_root, bump):
    """Переписати href markdown-посилань у одному тексті.

    Видимий текст посилання не чіпаємо ніколи: змінюється рівно адреса в дужках, і
    рівно коли файл справді знайшовся на диску У ДОЗВОЛЕНОМУ КОРЕНІ. Голий URL у прозі
    свідомо НЕ чіпаємо: там адреса це і є видимий текст, і підміна сховала б від людини,
    який саме файл їй дали. ДЗЕРКАЛО normalizeMarkdownLinks у media-normalize.cjs.
    """
    if '](' not in md:
        return md

    def repl(m):
        if m.group(1) is not None:          # код: лишаємо рівно як написано
            return m.group(0)
        href = m.group(3)
        if not _LOCAL_HREF_RE.match(href):
            return m.group(0)
        new, status = _normalize_link_href(href, dir_, repo_root)
        bump(status)
        return m.group(2) + new + m.group(4) if status == 'copied' else m.group(0)

    return _MD_HREF_RE.sub(repl, md)


def normalize_widgets(widgets, dir_, repo_root=None, stats=None):
    """Walk a widget tree in place and normalize every media src.

    Recurses through nested lists/dicts so a media widget inside a container is
    reached too, but only ever touches a dict whose `type` is a known media type.
    That keeps an unrelated `src` key (say, inside a code sample) untouched.

    Never raises: a broken widget must not block the message from being posted.
    """
    if repo_root is None:
        repo_root = os.path.abspath(os.path.join(dir_, '..', '..', '..'))
    if stats is None:
        stats = {}

    def bump(k):
        stats[k] = stats.get(k, 0) + 1

    def fix(node, key, container):
        s = container.get(key)
        if not isinstance(s, str) or not s.strip():
            return
        new, status = normalize_src(s, dir_, repo_root, stats)
        bump(status)
        if status == 'copied':
            container[key] = new
            container.pop('srcMissing', None)
        elif status == 'missing':
            container['srcMissing'] = True
        else:
            container.pop('srcMissing', None)

    def fix_md(container, key):
        """Текстове поле буває рядком, списком рядків або списком {p} (Text.body)."""
        v = container.get(key)
        if isinstance(v, str):
            container[key] = _md_links(v, dir_, repo_root, bump)
            return
        if not isinstance(v, list):
            return
        for i, item in enumerate(v):
            if isinstance(item, str):
                v[i] = _md_links(item, dir_, repo_root, bump)
            elif isinstance(item, dict) and isinstance(item.get('p'), str):
                item['p'] = _md_links(item['p'], dir_, repo_root, bump)

    def walk(node):
        if isinstance(node, list):
            for item in node:
                walk(item)
            return
        if not isinstance(node, dict):
            return
        t = node.get('type')
        if t in _MEDIA_KEYS:
            for key in _MEDIA_KEYS[t]:
                fix(node, key, node)
            if t == 'gallery':
                for im in (node.get('images') or []):
                    if isinstance(im, dict):
                        fix(im, 'src', im)
        if t in _MD_TEXT_KEYS:
            for key in _MD_TEXT_KEYS[t]:
                fix_md(node, key)
            if t == 'accordion':
                for it in (node.get('items') or []):
                    if isinstance(it, dict):
                        fix_md(it, 'body')
        for v in node.values():
            if isinstance(v, (list, dict)):
                walk(v)

    try:
        walk(widgets)
    except Exception:
        pass
    return widgets, stats
