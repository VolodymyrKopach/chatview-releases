#!/usr/bin/env python3
"""plan_order_proof.py — verifies that a step's `origin: ordered` claim is real.

WHY THIS MODULE EXISTS (owner decision, 2026-09-06, spec plan-ordered-vs-proposed K2 + K9)
-------------------------------------------------------------------------------------------
plan_store.py (D1) taught the plan format a step's `origin`: ORDERED or PROPOSED.
That flag alone is worthless as a safeguard, because the SAME model that is prone to
writing its own ideas into the plan is also the one setting the flag — a model that
mislabels its guess as an instruction will just as happily mislabel it "ordered" and
move on. The owner: «або це прям прямо було сказано, або він точно розуміє сильний
намір». The only thing that can catch that is a check the model does not control:
does the literal fragment of human words it cites as proof actually appear in the
channel's real messages.

So this module answers exactly one machine-checkable question — nothing semantic,
nothing model-graded, nothing fuzzy beyond case/whitespace — on purpose: a check
that cannot be explained to a human in one sentence is exactly the kind of black box
this feature exists to remove. The sentence is: "the normalized proof text is a
substring of something the human actually typed, within a bounded recent window."

WHAT COUNTS AS "THE HUMAN" (see server.py)
-------------------------------------------
server.py writes the literal text a person typed with `frm='Я'` — and ONLY that.
Every prompt bubble goes through `self._append_message(channel, ..., frm='Я', ...)`
(server.py: `_write_prompt_bubble`, and the room fan-out path), with no other
call site in the whole file ever passing that value. Every other label —
'Claude' (this same assistant), an agent's own name ('Тарас', 'Vika', ...), another
engine ('Antigravity'), or 'Система' for service lines — marks something that was
NOT typed by a person, no matter how much it reads like an instruction. So "was this
message from the human" is one field equality against a constant, not a heuristic
run over the text.

FAIL-SAFE (spec K9)
-------------------
Losing a step is worse than mislabeling it. `resolve_step_origin` never raises and
never drops a field: any failure while checking (channel missing, corrupt JSON,
whatever) is treated exactly like "proof not found" — the step survives, only its
`origin` moves to PROPOSED.

Deliberately NOT this module's job: deciding WHICH steps get checked (that is
whoever calls this, e.g. a future write-path), and owning the `origin` values
themselves (plan_store.py, D1, already closed — this module only imports its two
constants to avoid a second definition drifting out of sync).
"""
import json
import os
import re

import plan_store as _plan_store

ORDERED = _plan_store.ORDERED
PROPOSED = _plan_store.PROPOSED

# The field a step carries its literal quote in. A module-level default, not a
# hardcoded literal sprinkled through the code, so a caller integrating this with a
# differently-named prompt contract field can override it in one place
# (`resolve_step_origin(..., proof_field=...)`) without touching this file.
PROOF_FIELD = 'orderProof'

# How many of the channel's most recent messages (any author) get read before giving
# up on finding proof. A hard, named cap, not a tuning knob: reading a channel's full
# history on every plan write does not scale — some channels run for months and hold
# hundreds of messages (e.g. channels/cc-7f2413) — and a step's order-proof is always
# something the human said in the SAME working session that produced the plan. A claim
# that can only be justified by a quote from hundreds of messages back should be
# re-stated, not exhumed. 200 covers roughly 30-60 back-and-forth turns (each turn is
# a handful of bubbles: the prompt, replies, agent report cards), generous headroom
# for one session without scanning channels that predate it.
MESSAGE_WINDOW = 200

# server.py: the ONLY `from` value ever written for a message a human actually typed
# (see module docstring). Everything else is model/agent/system output.
HUMAN_FROM = 'Я'


def _normalize(text):
    """Case- and whitespace-collapsed form used for substring comparison. This is the
    ONLY transformation applied — no stemming, no fuzzy matching, no model — because
    part of the human's messages arrive via voice input where casing and spacing are
    unreliable (spec risk), and because any smarter comparison would turn "is this
    proof real" back into a black box nobody can explain in one sentence."""
    return re.sub(r'\s+', ' ', str(text or '')).strip().lower()


def _message_text(blocks):
    """Every string found under a 'text' key in a stored message's block list, joined.
    A human bubble is always saved as [{"type": "text", "text": "..."}, ...] (see
    channels/*/NNNN.json written by server.py._append_message), so collecting 'text'
    values is enough — no widget-schema parsing needed."""
    if not isinstance(blocks, list):
        return ''
    return '\n'.join(b['text'] for b in blocks
                      if isinstance(b, dict) and isinstance(b.get('text'), str))


def _recent_human_texts(channel, root, window):
    """Text of every HUMAN message among the last `window` messages of `channel`
    (counting messages of any author, so the window is a real bound on how much of the
    channel gets touched). Reads index.json once, then only the message files that
    fall inside the window slice — never the full channel history. Raises on I/O
    errors (missing channel, corrupt JSON): callers that must never crash use
    `resolve_step_origin`, which wraps this."""
    ch_dir = os.path.join(root, channel)
    with open(os.path.join(ch_dir, 'index.json'), encoding='utf-8') as f:
        items = json.load(f)
    if not isinstance(items, list):
        return []
    items = [i for i in items if isinstance(i, dict) and i.get('file')]
    items.sort(key=lambda i: i.get('id') or 0)
    window_items = items[-window:] if window and window > 0 else items
    texts = []
    for rec in window_items:
        if rec.get('from') != HUMAN_FROM:
            continue
        with open(os.path.join(ch_dir, rec['file']), encoding='utf-8') as f:
            blocks = json.load(f)
        text = _message_text(blocks)
        if text:
            texts.append(text)
    return texts


def human_said(fragment, channel, root, window=MESSAGE_WINDOW):
    """True iff the normalized `fragment` occurs as a substring inside a normalized
    human message, among the channel's last `window` messages. An empty/missing
    fragment is never "found" (an empty string is a substring of everything, which
    would make a missing proof trivially pass). Raises on I/O errors — see
    `resolve_step_origin` for the version that never does."""
    needle = _normalize(fragment)
    if not needle:
        return False
    haystacks = _recent_human_texts(channel, root, window)
    return any(needle in _normalize(text) for text in haystacks)


def resolve_step_origin(step, channel, root, window=MESSAGE_WINDOW, proof_field=PROOF_FIELD):
    """The step, unchanged, when its origin is not ORDERED or its proof checks out;
    otherwise a SHALLOW COPY with `origin` flipped to PROPOSED and every other field
    left exactly as it was (spec K9 — a step must never lose content over a failed or
    impossible check).

    Never raises: any failure while checking (channel missing, corrupt JSON, whatever)
    is treated the same as "proof not found" — an unprovable claim is exactly as
    trustworthy as a disproven one, and mislabeling a step's origin is a far cheaper
    mistake than losing the step outright."""
    if not isinstance(step, dict) or step.get('origin') != ORDERED:
        return step
    try:
        proven = human_said(step.get(proof_field), channel, root, window)
    except Exception:
        proven = False
    if proven:
        return step
    downgraded = dict(step)
    downgraded['origin'] = PROPOSED
    return downgraded
