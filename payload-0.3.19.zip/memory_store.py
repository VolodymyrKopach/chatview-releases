#!/usr/bin/env python3
"""Памʼять ЗАСТОСУНКУ: сховище, добір у хід, конфлікти, перенос.

Спека: specs/app-memory/spec.md, критерії К1-К9.

НАВІЩО. Памʼять Logopsis сьогодні це побічний ефект чужого інструмента. Вичавлені
факти лежать у `~/.claude/projects/<ЗАКОДОВАНИЙ-ШЛЯХ>/memory/`, тобто ключем теки є
ШЛЯХ до проєкту: перенеси репозиторій, і памʼять осиротіє, хоча жоден файл не зникне.
Сирі сигнали навчання падають у третє місце, `<репо>/memory/_learn/inbox.jsonl`, теж
привʼязане до шляху. А runner.py памʼять не підкладає ВЗАГАЛІ: вона доїжджає у хід
лише тому, що рушій запускається з коренем репозиторію як робочою текою. На машині
людини, у якої нема Claude Code з тим самим проєктом, памʼяті не буде, і мовчки.

ЩО ЦЕ Є. Три речі, які застосунок мусить робити САМ: тримати сховище під своєю
домівкою (К1), підкладати памʼять у промпт власними руками (К2) і показувати її
людині (К5). Плюс те, без чого перші три не варті нічого: стабільний ключ проєкту
замість шляху (К3), обовʼязкові поля запису (К4), добір доречного замість усього
корпусу (К6), видимий конфлікт замість тихого злиття (К7) і перенос між машинами (К8).

ЧОГО ТУТ НЕМАЄ СВІДОМО.
  Мережі. Жодного рядка, яким можна вийти за межі машини (К9). Це прибито двома
  тестами одразу: живою пасткою на сокет і статичною перевіркою імпортів. Памʼять,
  яка одного разу поїхала в мережу, не повертає довіру ніколи.
  Бази даних. Сховище лишається файлами: один факт це один файл, який людина може
  відкрити, прочитати і стерти руками, не питаючи застосунок.
  Автоматичної міграції наявних 289 файлів харнесу. Тільки явний імпорт (К8), інакше
  в дев-режимі памʼять задвоїться: харнес підкладе свою, застосунок свою, і відповіді
  почнуть повторювати факти двічі.

ДЕ ЛЕЖИТЬ. `<LOGOPSIS_HOME>/memory/`, той самий патерн, що keys.json і rules.md: у
пакованій збірці під домівкою користувача, у дев-репо поруч зі скриптами (і в
.gitignore, бо це стан машини, а не код). У ~/.claude не пишеться нічого і ніколи.

Чистий stdlib, без побічних ефектів на імпорті: модуль читають ОБИДВА процеси,
server.py і runner.py.
"""
import bisect
import datetime
import hashlib
import json
import math
import os
import re

# Правило експорту (К6). Чистий stdlib під ним, мережі не додає: модуль читає лише
# реєстр класів. Імпорт тут, а не всередині функції, свідомо: правило, яке можна
# «не імпортувати», перестає діяти рівно тоді, коли хтось цього не зробить.
import export_policy as _policy

# ── словник ─────────────────────────────────────────────────────────────────
# Значення полів англійські, підписи для людини українські. Причина не в моді:
# фронтматер їде між машинами і в експорті, а ключ, який залежить від розкладки
# редактора, це джерело мовчазних розбіжностей.

MEM_DIR = 'memory'
FACTS_DIR = 'facts'
REGISTRY_FILE = 'projects.json'
# Маркер проєкту лежить У САМІЙ робочій теці і саме тому переживає перейменування
# (К3). Реєстр у домівці памʼятає ід, маркер памʼятає, кому ця тека належить: разом
# вони дають звʼязок, який не ламається від `mv`.
MARKER_FILE = '.logopsis-project'

TYPES = ('user', 'feedback', 'project', 'reference')
# Походження це не метадані заради метаданих. Різниця між «людина сказала» і «я сам
# вивів» вирішує, чи можна на запис спиратись без перепитування.
ORIGINS = ('said', 'inferred')
SCOPE_KEYS = ('user', 'project', 'channel', 'member')

ORIGIN_LABEL = {'said': 'зі слів людини', 'inferred': 'виведено застосунком'}

# Поверх памʼяті (specs/user-memory-v2, К9). Ядро це те, що їде в хід завжди, архів
# це все інше. Дефолт навмисно `archive`: підвищення до ядра коштує місця в КОЖНОМУ
# ході, тому воно мусить бути рішенням людини, а не побічним ефектом запису.
TIERS = ('core', 'archive')
DEFAULT_TIER = 'archive'
# Карантин. Запис, зроблений застосунком за людину, спершу лежить у `pending` і в хід
# не їде: один хибний автозапис інакше псував би кожну наступну відповідь, причому
# непомітно, бо людина бачить не факт, а лише дивну відповідь.
STATUSES = ('active', 'pending')
DEFAULT_STATUS = 'active'
# Вага в ранжуванні. Середина шкали, а не одиниця: новий запис не мусить одразу
# витісняти те, що вже довело користь.
DEFAULT_WEIGHT = 0.5

# Скільки записів максимум їде в один хід. Не «скільки влізе»: кожен запис це токени
# на КОЖНОМУ ході цієї розмови, і на кількох сотнях фактів рахунок помітний.
DEFAULT_LIMIT = 12
# Довжина тіла запису в промпті. Памʼять це нагадування, а не архів.
BODY_IN_PROMPT = 240

# Вага поля в пошуковій оцінці (specs/user-memory-v2, S6, К12). Опис це те, що
# людина назвала «про що цей запис», тому важить найбільше; тіло індексується
# теж, але з найменшою вагою, щоб довгий текст не переміг короткий влучний опис
# самою довжиною.
SCORE_WEIGHT_DESCRIPTION = 3
SCORE_WEIGHT_KEY = 2
SCORE_WEIGHT_BODY = 1

# Скільки індексів корпусу тримати в памʼяті процесу (S7, дивись `_index`). Індекс
# це мішки слів усіх записів плюс словник рідкості, на живому сховищі це кілька
# мегабайтів, тому кеш навмисно куций: різні області добору дають різні корпуси, і
# тримати їх усі означало б платити памʼяттю за те, що і так рахується за мілісекунди
# при першому доборі в процесі.
INDEX_CACHE_MAX = 2

# Стеля ядра (specs/user-memory-v2, S2): скільки максимум записів МОЖЕ мати позначку
# tier=core, що б із них не настало раніше. Ядро їде в хід ЗАВЖДИ, тобто поза
# DEFAULT_LIMIT, і саме тому йому потрібна ВЛАСНА стеля: без неї постійне HARD-правило
# конкурувало б за місце в промпті з разовою дрібницею одного каналу і програвало б
# звичайному лічильнику на великому сховищі.
CORE_MAX_COUNT = 24
# Сума довжин ОПИСІВ записів ядра, не тіл: тіло в промпті і так ріжеться до
# BODY_IN_PROMPT, а стеля ядра мусить обмежувати те, що платить свою ціну щоходу.
CORE_MAX_CHARS = 2000

# Поріг злиття дублікатів (specs/user-memory-v2, S9, К7). Обидва числа зняті з
# розподілу схожості на живому корпусі, не вигадані: замір і розбір кожної пари лежать
# у data/user-memory-audit/zamir-s9-dedupe.md, скрипт поруч відтворює таблицю.
#
# 0.55 стоїть у ПОРОЖНІЙ смузі розподілу. На 42 778 парах наявних 293 фактів медіана
# схожості 0.032, а p99.9 всього 0.227; вище 0.5 підіймається РІВНО ОДНА пара (0.589) і
# вона справді дублікат (два файли про одне й те саме кодове слово MANGO55, розведені
# по різних ключах лише дефісом проти підкреслення). Найсхожіша пара РІЗНИХ фактів
# набирає 0.488. Тобто поріг має запас 0.062 з боку хибного злиття і 0.039 з боку
# пропуску, і зсунутий вище середини цієї смуги свідомо: втрачений зміст не видно, а
# дублікат видно.
#
# Перевірено не лише таблицею, а й переграванням: усі 293 записи, покладені в порожнє
# сховище по даті без своїх ключів, дають 292 картки і РІВНО ОДНЕ злиття, те саме.
DEDUPE_SIMILARITY = 0.55
# Скільки щонайменше спільних слів мусять мати ОПИСИ, щоб схожість взагалі рахувалась.
# Це не косметика, а латка на конкретну поломку. Опис автозапису це дослівна цитата
# людини, і вона буває у два змістовні слова («Ти що там ахуєл»). На таких мішках частка
# збігу вироджується: дві РІЗНІ скарги з живої історії (c008 про повільність і c025 про
# неперевірений функціонал) дали схожість 0.644 на двох спільних словах і злились би
# при будь-якому порозі. Справжній дублікат корпусу має чотири спільні слова, тому межа
# у три лишає запас по слову в обидва боки.
DEDUPE_MIN_SHARED = 3
# Вага полів у схожості. Опис це заявка «про що цей запис», тому важить більше; тіло
# лишається в формулі як заспокійливе для коротких описів, де сама частка збігу скаче.
DEDUPE_WEIGHT_DESCRIPTION = 0.6
DEDUPE_WEIGHT_BODY = 0.4

# Поріг кандидата на архів (specs/user-memory-v2, S10, рішення 1): понад стільки
# показів при НУЛІ підтверджень факт вважається мертвим вантажем -- показувався, а
# користі жодного разу не приніс. Поріг ОГОЛОШЕНИЙ до прогону, а не підібраний під
# конкретний файл. Позначка мʼяка (рішення 2): ранжування опускає такий факт, але
# добір і далі його не відкидає, бо людина могла просто ще не встигнути підтвердити,
# а тихо ховати правило через це було б гірше за зайвий рядок у промпті.
ARCHIVE_CANDIDATE_SHOWN_THRESHOLD = 20

_FM_RE = re.compile(r'^---\n(.*?)\n---\n?(.*)$', re.S)
# Слово це 3+ літери/цифри. Коротші службові («що», «не», «в») лише шумлять у доборі.
_WORD_RE = re.compile(r'[^\W\d_]{3,}|\d{2,}', re.UNICODE)
# Ознака того, що запис спирається на зовнішній факт, який міг протухнути: назва файлу
# або прапорець командного рядка. Такий запис їде з позначкою «звірити», бо саме
# протухлий шлях перетворює памʼять на шкідливу пораду.
#
# Правило навмисно ВУЗЬКЕ: потрібне відоме розширення або дефісний прапорець. Перша
# версія ловила будь-яке «слово/слово» і через це позначила 269 записів з 288, тобто
# 93 відсотки. Позначка, що стоїть майже скрізь, не попереджає ні про що: людина
# перестає її читати за пів екрана, і тоді справжній протухлий шлях теж проїде повз.
_EXT = r'py|tsx?|jsx?|json|md|cjs|mjs|sh|ya?ml|toml|html|css|png|jpe?g|env|lock'
_PATHY_RE = re.compile(
    r'(?:(?:[\w.-]+/)+[\w.-]+\.(?:%s))\b'      # шлях із розширенням
    r'|(?:\b[\w-]+\.(?:%s))\b'                 # голе імʼя файлу з розширенням
    r'|(?:\s--[a-z][\w-]{2,})' % (_EXT, _EXT), re.I)


# ── шляхи ───────────────────────────────────────────────────────────────────

def store_dir(home):
    """Корінь сховища. Завжди під домівкою застосунку, ніколи в ~/.claude (К1)."""
    return os.path.join(home, MEM_DIR)


def facts_dir(home):
    return os.path.join(store_dir(home), FACTS_DIR)


def registry_path(home):
    return os.path.join(store_dir(home), REGISTRY_FILE)


def fact_path(home, fact_id):
    return os.path.join(facts_dir(home), '%s.md' % fact_id)


def ensure(home):
    """Створити теки. Другий виклик нічого не чіпає."""
    os.makedirs(facts_dir(home), exist_ok=True)
    return store_dir(home)


# ── дрібне ──────────────────────────────────────────────────────────────────

def _now():
    """Мітка часу з мікросекундами, і це НЕ педантизм.

    Правило конфлікту «перемагає новіший» (К7) впирається саме сюди. З точністю до
    секунди два записи, зроблені в одному ході, отримували ОДНАКОВУ дату, і переможця
    далі обирало сортування за ідентифікатором, тобто випадковий шістнадцятковий рядок.
    На живому прогоні так і сталось: старіше рішення про голос побило новіше.
    """
    return datetime.datetime.now(datetime.timezone.utc).strftime('%Y-%m-%dT%H:%M:%S.%fZ')


def _rand(n):
    return hashlib.sha1(os.urandom(20)).hexdigest()[:n]


def _safe_id(value):
    """Ід приходить із мережі (кнопка «стерти» в UI). Слеш або крапка тут означали б
    запис/видалення поза сховищем, тому дозволена рівно одна форма."""
    return bool(re.fullmatch(r'[A-Za-z0-9_-]{1,64}', value or ''))


def _atomic_write(path, text):
    tmp = '%s.tmp.%d' % (path, os.getpid())
    with open(tmp, 'w', encoding='utf-8', newline='\n') as fh:
        fh.write(text)
    os.replace(tmp, path)


def _words(text):
    return [w.lower() for w in _WORD_RE.findall(text or '')]


def _slug(text, limit=48):
    out = '-'.join(_words(text))[:limit].strip('-')
    return out or 'fact'


def _key_slug(text, limit=80):
    """Ключ угруповання, коли автор не назвав його явно.

    Нормалізація тут навмисно БЕЗ ВТРАТ, на відміну від _slug: той викидає короткі
    службові слова, і два різні описи, що відрізнялись саме коротким хвостом,
    отримували ОДИН ключ і оголошувались суперечливими. Фальшивий конфлікт гірший за
    пропущений: він вчить не вірити позначці, і тоді справжній теж проїде повз.

    Однаковий опис і далі дає однаковий ключ, і це правильно: два записи з тією самою
    заявою і різними тілами це і є суперечність.
    """
    out = re.sub(r'[^\w]+', '-', (text or '').lower(), flags=re.UNICODE).strip('-')
    return out[:limit].strip('-') or 'fact'


def _looks_stale(text):
    return bool(_PATHY_RE.search(text or ''))


# ── фронтматер ──────────────────────────────────────────────────────────────
# Свій мінімальний парсер, а не yaml: yaml не в stdlib, а тягнути залежність заради
# десятка плоских ключів означало б поставити сховище памʼяті в залежність від
# встановленого середовища. Формат навмисно плоский, вкладеність передається крапкою
# (`scope.project`), тому файл лишається читабельним і для людини, і для трьох рядків
# коду.

def _dump_front(fields):
    lines = []
    for key, value in fields:
        if isinstance(value, bool):
            value = 'true' if value else 'false'
        lines.append('%s: %s' % (key, '' if value is None else str(value)))
    return '---\n%s\n---\n' % '\n'.join(lines)


def _unquote(value):
    """Зняти ПАРНІ зовнішні лапки зі значення фронтматера.

    Памʼять харнесу пише значення в лапках («name: "..."»), і без цього кроку лапки
    їхали в дані: опис показувався в лапках, а порожнє `name: ""` ставало ключем із
    двох символів. Два такі файли давали фальшивий конфлікт двох НЕПОВʼЯЗАНИХ записів,
    і саме він виліз на живому прогоні. Знімаємо лише коли лапка стоїть на обох краях і
    всередині її нема, щоб не покалічити значення на кшталт «a" and "b».
    """
    if len(value) >= 2 and value[0] == value[-1] and value[0] in '"\'':
        inner = value[1:-1]
        if value[0] not in inner:
            return inner
    return value


def _as_float(value, default):
    """Число з файлу, який могла правити рука. Биті значення падають на дефолт, а не
    валять читання: один зіпсований символ не сміє забрати доступ до всього запису."""
    try:
        return float(value)
    except (TypeError, ValueError):
        return default


def _as_int(value, default):
    try:
        return int(float(value))
    except (TypeError, ValueError):
        return default


def _parse_front(text):
    m = _FM_RE.match(text or '')
    if not m:
        return {}, (text or '').strip()
    fields = {}
    for line in m.group(1).split('\n'):
        if ':' not in line:
            continue
        key, _, value = line.partition(':')
        fields[key.strip()] = _unquote(value.strip())
    return fields, m.group(2).strip()


def _stamp_front(path, updates):
    """Дописати поля У ФРОНТМАТЕР, не зачепивши жодного байта тіла (К9).

    Саме тому тут не використовується `write_fact` і не збирається файл наново:
    перезбирання прогнало б тіло через `strip()` і нормалізацію, тобто текст
    давнішого запису тихо змінився б. А К9 вимагає протилежного: запис закривається,
    але його слова лишаються рівно такими, якими людина їх бачила.

    Незнайомі поля теж переживають правку: файл міг прийти з новішої версії або з
    чужої машини, і мовчки викинути звідти дані означало б втратити їх назавжди.
    """
    try:
        with open(path, encoding='utf-8') as fh:
            raw = fh.read()
    except (OSError, UnicodeDecodeError):
        return False
    m = _FM_RE.match(raw)
    if not m:
        return False
    lines = m.group(1).split('\n')
    for field, value in updates:
        line = '%s: %s' % (field, value)
        for i, existing in enumerate(lines):
            if existing.partition(':')[0].strip() == field:
                lines[i] = line
                break
        else:
            lines.append(line)
    _atomic_write(path, '---\n%s\n---\n' % '\n'.join(lines) + m.group(2))
    return True


def _close_contradicted(home, fact_id, key, scope, date, body):
    """Закрити давніші записи, яким новий суперечить. Повертає їхні ідентифікатори.

    Три обмеження, і кожне куплене ціною конкретної поломки.
      Однакове тіло не закривається: це дублікат, а не суперечність, і мітка на
      дублікатах привчила б не читати мітку взагалі.
      Чужа область не закривається: однаковий ключ у двох проєктах це два різні
      факти, і закрити сусідній означало б тихо погасити памʼять іншого проєкту.
      Уже закритий не чіпається: інакше ланцюг версій злипся б у «всі посилаються на
      останню», і відповісти, що застосунок думав місяць тому, стало б нічим.
    """
    closed = []
    for older in load_all(home):
        if older['id'] == fact_id or older['key'] != key:
            continue
        if older['valid_to'] or older['date'] > date:
            continue
        if older['scope'] != scope or older['body'].strip() == body.strip():
            continue
        if _stamp_front(fact_path(home, older['id']),
                        [('valid_to', date), ('superseded_by', fact_id)]):
            closed.append(older['id'])
    return closed


# ── дедуплікація при записі (S9, К7) ────────────────────────────────────────
# Навіщо. Автозапис (S5) створює кандидата щоразу, коли людина каже моделі, що та
# зробила не так. Людина повторює своє правило різними словами, тому без цього кроку
# через місяць у сховищі лежить пʼять переказів однієї думки, і добір починає віддавати
# три версії одного правила замість трьох різних фактів, тобто памʼять зʼїдає сама себе.
#
# Механізм НЕ новий. Запис з тим самим ключем уже створює нову версію, а давнішому
# проставляє дату кінця дії і посилання на наступника (S1, `_close_contradicted`). Тому
# дедуплікація тут зводиться рівно до одного питання: під яким КЛЮЧЕМ лягає новий запис.
# Знайшли близнюка -- беремо його ключ, і далі все відбувається наявним шляхом версій.
# Окремої гілки злиття не існує, бо друга гілка, що вміє переписувати чужі записи, це
# другий спосіб втратити текст, а вся S1 будувалась на тому, щоб такого способу не було.


# Слова для ПОРІВНЯННЯ записів між собою, а не для добору за запитом. Різниця рівно
# одна: сюди входять і однознакові числа. У доборі таке число це шум (запит «крок 3»
# підняв би все на світі), а при звірці двох записів воно часто єдине, чим вони взагалі
# відрізняються: «версія 1» проти «версія 2», «крок 3» проти «крок 4». Спільний
# `_WORD_RE` викидав їх, і два різні записи ставали побайтово однаковими мішками слів.
_DEDUPE_WORD_RE = re.compile(r'[^\W\d_]{3,}|\d+', re.UNICODE)


def _dedupe_words(text):
    return {w.lower() for w in _DEDUPE_WORD_RE.findall(text or '')}


def _dice(a, b):
    """Частка спільного у двох мішках слів: 2|A∩B| / (|A|+|B|).

    Саме Dice, а не перетин і не вкладеність. Голий перетин виграє довжиною (довге
    тіло перетинається з усім), а вкладеність (|A∩B| / min) оголошує коротку заявку
    дублікатом довгої розповіді, яка її згадала одним рядком.
    """
    if not a or not b:
        return 0.0
    return 2.0 * len(a & b) / float(len(a) + len(b))


def _similarity(dwords, bwords, fact_dwords, fact_bwords):
    return (DEDUPE_WEIGHT_DESCRIPTION * _dice(dwords, fact_dwords)
            + DEDUPE_WEIGHT_BODY * _dice(bwords, fact_bwords))


def similarity(description, body, fact):
    """Наскільки новий запис це переказ уже наявного `fact`. Число від 0 до 1.

    Ключ у порівняння НЕ входить свідомо: у нового запису його ще нема (він і є те,
    що дедуплікація шукає), а в наявних файлах ключ це технічна назва з харнесу
    (`feedback_*`, `project_*`), спільне слово якої підняло б схожість БУДЬ-ЯКИХ двох
    записів однієї категорії, тобто рівно там, де ціна помилки найвища.
    """
    return _similarity(_dedupe_words(description), _dedupe_words(body),
                       _dedupe_words(fact['description']), _dedupe_words(fact['body']))


def find_duplicate(home, description, body, scope=None, facts=None):
    """Наявний запис, який новий лише переказує, або None.

    Три обмеження, кожне з ціною конкретної помилки.

    Область мусить збігатись ТОЧНО. Однакове правило в двох проєктах це два факти, і
    зшити їх одним ключем означало б, що новіший тихо закриє чужий (`_close_contradicted`
    чужу область не чіпає, тож вийшла б ще й половинчаста каша: спільний ключ без
    закриття, тобто вічний фальшивий конфлікт на екрані).

    Порогів два, і другий не декоративний: без DEDUPE_MIN_SHARED дві різні скарги з
    двома спільними словами в цитаті виглядають як дублікат при будь-якому першому
    порозі.

    Карантин і закриті версії з пошуку НЕ виключаються. Кандидат, який повторює
    кандидата, це і є та сама картка, а закритий запис несе ключ своєї картки, тобто
    саме те, заради чого сюди й приходять.
    """
    pool = facts if facts is not None else load_all(home)
    scope = {k: ((scope or {}).get(k) or '') for k in SCOPE_KEYS}
    dwords, bwords = _dedupe_words(description), _dedupe_words(body)
    best, best_score = None, 0.0
    for fact in pool:
        if fact['scope'] != scope:
            continue
        fact_dwords = _dedupe_words(fact['description'])
        if len(dwords & fact_dwords) < DEDUPE_MIN_SHARED:
            continue
        score = _similarity(dwords, bwords, fact_dwords, _dedupe_words(fact['body']))
        # Строго БІЛЬШЕ за найкращий: `load_all` віддає найновіші першими, тому при
        # однаковій схожості лишається найсвіжіша версія картки.
        if score >= DEDUPE_SIMILARITY and score > best_score:
            best, best_score = fact, score
    return best


# ── запис ───────────────────────────────────────────────────────────────────

def write_fact(home, description, body, origin, type='project', scope=None,
               key=None, source='', date=None, fact_id=None, verify=None,
               tier=None, status=None, weight=None, shown=None, hits=None,
               valid_to=None, superseded_by=None):
    """Покласти новий факт ОКРЕМИМ файлом з обовʼязковими полями (К4).

    Валідація тут навмисно жорстка і кидає, а не мовчки лагодить. Запис без
    походження неможливо оцінити на довіру, а запис без однорядкового опису
    неможливо ДОБРАТИ у хід (К6), тобто він або лежить мертвим вантажем, або їде в
    промпт завжди. Обидва варіанти гірші за чесну відмову на місці.
    """
    description = (description or '').strip()
    if not description:
        raise ValueError('факт без однорядкового опису не створюється')
    if '\n' in description or '\r' in description:
        raise ValueError('опис мусить бути ОДНОрядковим')
    if origin not in ORIGINS:
        raise ValueError('походження мусить бути одним з %s' % (ORIGINS,))
    if type not in TYPES:
        raise ValueError('тип мусить бути одним з %s' % (TYPES,))
    tier = tier or DEFAULT_TIER
    if tier not in TIERS:
        raise ValueError('поверх мусить бути одним з %s' % (TIERS,))
    status = status or DEFAULT_STATUS
    if status not in STATUSES:
        raise ValueError('стан мусить бути одним з %s' % (STATUSES,))
    try:
        weight = DEFAULT_WEIGHT if weight is None else float(weight)
        shown = 0 if shown is None else int(shown)
        hits = 0 if hits is None else int(hits)
    except (TypeError, ValueError):
        raise ValueError('вага і лічильники мусять бути числами')

    ensure(home)
    scope = scope or {}
    scope = {k: (scope.get(k) or '') for k in SCOPE_KEYS}
    fact_id = fact_id or ('mem-' + _rand(10))
    if not _safe_id(fact_id):
        raise ValueError('поганий ідентифікатор запису')
    body = (body or '').strip()
    if verify is None:
        verify = _looks_stale(body) or _looks_stale(description)
    date = date or _now()
    # Дедуплікація (К7). Ключ шукається СЕРЕД НАЯВНИХ записів, і лише коли автор його
    # не назвав: явний ключ це вже ухвалене рішення про угруповання, і мовчки його
    # переписати означало б зламати і перенос, і імпорт, які кладуть чужі записи з
    # їхніми власними ключами (`import_bundle`, `import_claude_dir`). Знайшовся
    # близнюк -- новий запис лягає ЙОГО ключем, тобто стає наступною версією тієї
    # самої картки замість другого запису про те саме.
    if not key:
        twin = find_duplicate(home, description, body, scope)
        key = twin['key'] if twin else _key_slug(description)

    fields = [
        ('id', fact_id),
        ('type', type),
        ('date', date),
        ('origin', origin),
        ('description', description),
        ('key', key),
        ('source', source),
        ('verify', bool(verify)),
        ('tier', tier),
        ('status', status),
        ('weight', weight),
        ('valid_to', valid_to or ''),
        ('superseded_by', superseded_by or ''),
        ('shown', shown),
        ('hits', hits),
    ]
    fields += [('scope.%s' % k, scope[k]) for k in SCOPE_KEYS]
    _atomic_write(fact_path(home, fact_id), _dump_front(fields) + body + '\n')
    # Закриваємо давніших ПІСЛЯ того, як новий запис ліг на диск. Зворотний порядок
    # у разі збою запису лишив би сховище без чинної версії взагалі: давніші вже
    # закриті, наступника нема.
    #
    # Кандидат у карантині нікого не закриває: він ще не факт, і дати автозапису
    # право гасити підтверджене означало б обійти карантин з іншого боку (К6).
    if status == 'active':
        _close_contradicted(home, fact_id, key, scope, date, body)
    return fact_id


# ── ядро профілю (S2) ──────────────────────────────────────────────────────
# Позначку tier=core ставить `write_fact` (потрібно для імпорту й переносу, де файл
# ядра іншої машини мусить лягти як є, без перевірки стелі: інакше S12 тихо губила б
# записи при злитті двох сховищ). Стелю CORE_MAX_COUNT/CORE_MAX_CHARS перевіряє лише
# `set_tier` — єдиний шлях, яким ЛЮДИНА через екран підвищує архівний запис до ядра.

class CoreFullError(ValueError):
    """Ядро вже на стелі (К2). Несе кандидата на витіснення, а не лише текст
    повідомлення, щоб виклик міг показати людині ІМʼЯ, а не просто «не вийшло»."""

    def __init__(self, candidate_id, candidate_description):
        self.candidate_id = candidate_id
        self.candidate_description = candidate_description
        super().__init__('ядро заповнене, кандидат на витіснення: %s (%s)'
                         % (candidate_id, candidate_description))


def _core_pool(home, exclude=None):
    """Чинні записи ядра: без карантину і без закритих (той самий фільтр, що йде
    в зібраний блок памʼяті). Мертва вага не мусить займати місце на стелі."""
    return [f for f in load_all(home)
            if f['tier'] == 'core' and f['status'] == 'active' and not f['valid_to']
            and f['id'] != exclude]


def set_tier(home, fact_id, tier):
    """Єдиний публічний спосіб позначити факт ядром або зняти позначку.

    Пониження (у архів) дозволене завжди, бо воно тільки звільняє місце. Підвищення
    перевіряє стелю ПЕРЕД записом і відмовляє з конкретним кандидатом на витіснення
    (К2), а не мовчки обрізає найслабше: людина мусить сама вирішити, чим пожертвувати
    заради нового правила, інакше вона довідається про втрату лише тоді, коли ядро
    вже промовчало про факт, на який спиралась.
    """
    if tier not in TIERS:
        raise ValueError('поверх мусить бути одним з %s' % (TIERS,))
    fact = get_fact(home, fact_id)
    if fact is None:
        raise ValueError('такого запису нема: %s' % fact_id)
    if tier == 'core' and fact['tier'] != 'core':
        core = _core_pool(home, exclude=fact_id)
        chars = sum(len(f['description']) for f in core) + len(fact['description'])
        if len(core) + 1 > CORE_MAX_COUNT or chars > CORE_MAX_CHARS:
            weakest = min(core, key=lambda f: (f['weight'], f['date'])) if core else fact
            raise CoreFullError(weakest['id'], weakest['description'])
    _stamp_front(fact_path(home, fact_id), [('tier', tier)])
    return fact_id


def read_fact(path):
    """Файл -> запис. Биті файли віддають None, а не валять весь екран памʼяті.

    Дефолти нових полів підставляються ТУТ, при читанні, і саме тому 293 наявні
    файли не потребують міграції: старий файл лишається на диску таким, яким його
    написали, а всі поля має вже запис у памʼяті. Міграція коштувала б переписування
    всього сховища заради значень, які й так відомі наперед.
    """
    try:
        with open(path, encoding='utf-8') as fh:
            raw = fh.read()
    except (OSError, UnicodeDecodeError):
        return None
    fields, body = _parse_front(raw)
    if not fields.get('id'):
        return None
    return {
        'id': fields['id'],
        'type': fields.get('type') or 'project',
        'date': fields.get('date') or '',
        'origin': fields.get('origin') or 'inferred',
        'description': fields.get('description') or '',
        'key': fields.get('key') or _key_slug(fields.get('description')),
        'source': fields.get('source') or '',
        'verify': (fields.get('verify') or '').lower() == 'true',
        'tier': fields.get('tier') if fields.get('tier') in TIERS else DEFAULT_TIER,
        'status': fields.get('status') if fields.get('status') in STATUSES else DEFAULT_STATUS,
        'weight': _as_float(fields.get('weight'), DEFAULT_WEIGHT),
        'valid_to': fields.get('valid_to') or '',
        'superseded_by': fields.get('superseded_by') or '',
        'shown': _as_int(fields.get('shown'), 0),
        'hits': _as_int(fields.get('hits'), 0),
        'scope': {k: (fields.get('scope.%s' % k) or '') for k in SCOPE_KEYS},
        'body': body,
        'size': len(body),
    }


def get_fact(home, fact_id):
    if not _safe_id(fact_id):
        return None
    return read_fact(fact_path(home, fact_id))


def load_all(home):
    """Усі записи, найновіші першими. Порядок стабільний: дата, потім ід."""
    out = []
    try:
        names = sorted(os.listdir(facts_dir(home)))
    except OSError:
        return out
    for name in names:
        if not name.endswith('.md'):
            continue
        fact = read_fact(os.path.join(facts_dir(home), name))
        if fact:
            out.append(fact)
    out.sort(key=lambda f: (f['date'], f['id']), reverse=True)
    return out


def delete_fact(home, fact_id):
    """Стерти РІВНО один запис, не зачепивши решти (К5).

    Неіснуючий ід віддає False, а не кидає: кнопка «стерти», натиснута двічі, це
    нормальна поведінка людини, а не помилка застосунку.
    """
    if not _safe_id(fact_id):
        return False
    try:
        os.remove(fact_path(home, fact_id))
        return True
    except OSError:
        return False


# ── реєстр проєктів (К3) ────────────────────────────────────────────────────

def _load_registry(home):
    try:
        with open(registry_path(home), encoding='utf-8') as fh:
            data = json.load(fh)
        if isinstance(data, dict) and isinstance(data.get('projects'), list):
            return data
    except (OSError, ValueError):
        pass
    return {'projects': []}


def _save_registry(home, reg):
    ensure(home)
    _atomic_write(registry_path(home), json.dumps(reg, ensure_ascii=False, indent=2) + '\n')


def _marker_path(path):
    return os.path.join(path, MARKER_FILE)


def _read_marker(path):
    try:
        with open(_marker_path(path), encoding='utf-8') as fh:
            data = json.load(fh)
        pid = data.get('project') if isinstance(data, dict) else None
        return pid if _safe_id(pid or '') else None
    except (OSError, ValueError):
        return None


def _write_marker(path, pid):
    """Найкраще зусилля: тека може бути тільки на читання, і це не привід падати."""
    try:
        _atomic_write(_marker_path(path), json.dumps({'project': pid}) + '\n')
    except OSError:
        pass


def resolve_project(home, path, name=None):
    """Стабільний ід проєкту для робочої теки. НІКОЛИ не похідна від шляху (К3).

    Порядок пошуку і чому саме такий:
      1. Маркер У САМІЙ теці. Він їде разом з нею, тому переживає `mv` і
         перейменування, тобто рівно ту поломку, через яку задача й зʼявилась.
      2. Реєстр за відомим шляхом. Це шлях для теки, куди маркер не записався.
      3. Новий запис.
    Коли маркер знайшовся, а шлях у реєстрі інший, реєстр самополікується: людина не
    мусить нічого рятувати руками після звичайного перейменування теки.
    """
    path = os.path.abspath(path)
    reg = _load_registry(home)
    by_id = {p.get('id'): p for p in reg['projects']}

    pid = _read_marker(path)
    if pid:
        entry = by_id.get(pid)
        if entry is None:
            reg['projects'].append({'id': pid, 'name': name or os.path.basename(path),
                                    'path': path, 'createdAt': _now()})
            _save_registry(home, reg)
        elif entry.get('path') != path:
            entry['path'] = path
            _save_registry(home, reg)
        return pid

    for entry in reg['projects']:
        if entry.get('path') == path:
            _write_marker(path, entry['id'])
            return entry['id']

    pid = 'prj-' + _rand(8)
    reg['projects'].append({'id': pid, 'name': name or os.path.basename(path) or pid,
                            'path': path, 'createdAt': _now()})
    _save_registry(home, reg)
    _write_marker(path, pid)
    return pid


def project_entry(home, pid):
    for entry in _load_registry(home)['projects']:
        if entry.get('id') == pid:
            return entry
    return None


def projects(home):
    return _load_registry(home)['projects']


# ── конфлікти (К7) ──────────────────────────────────────────────────────────

def resolve_conflicts(facts):
    """Групувати за ключем, узяти новіший, показати факт конфлікту.

    Правило «однаковий ключ і РІЗНЕ тіло» навмисно вужче за «однаковий ключ». Два
    записи з тим самим текстом це дублікат, а не суперечність, і кричати про нього
    означало б привчити людину гасити позначку не читаючи. А тоді справжній конфлікт
    вона теж погасить не читаючи.

    Закритий запис (стоїть `valid_to`) не може перемогти НІКОЛИ, навіть маючи новішу
    дату. Без цього правила незнищенність була б безсила: К9 лишає давніший файл на
    диску, і той спокійно їхав би далі в кожен хід. Дата тут не єдиний суддя саме
    тому, що вона приїжджає з чужої машини і з часу правки файлу, тобто бреше легко.

    :returns: (переможці зі стоячим полем `conflict`, список конфліктів)
    """
    groups = {}
    for fact in facts:
        groups.setdefault(fact['key'], []).append(fact)

    winners, conflicts = [], []
    for key, group in groups.items():
        group = sorted(group, key=lambda f: (not f['valid_to'], f['date'], f['id']),
                       reverse=True)
        winner = dict(group[0])
        bodies = {f['body'].strip() for f in group}
        losers = [f for f in group[1:] if f['body'].strip() != winner['body'].strip()]
        winner['conflict'] = len(bodies) > 1
        winner['supersedes'] = [f['id'] for f in group[1:]]
        winners.append(winner)
        if winner['conflict']:
            conflicts.append({'key': key, 'winner': winner, 'losers': losers})
    winners.sort(key=lambda f: (f['date'], f['id']), reverse=True)
    conflicts.sort(key=lambda c: c['key'])
    return winners, conflicts


def fact_history(home, key, facts=None):
    """Усі версії факту за ключем, від найновішої до найдавнішої (К10).

    Історія тримається не окремим журналом, а самими файлами: версія це запис з тим
    самим ключем, а звʼязок дає `superseded_by`. Журнал поруч із файлами розʼїхався б
    з ними при першому ж видаленні руками, а тут джерело істини одне.

    Порядок строго за датою, без переставляння чинного нагору: історію читають як
    хронологію, і зсув «бо цей ще діє» зробив би її нечитабельною.
    """
    pool = facts if facts is not None else load_all(home)
    rows = []
    for fact in pool:
        if fact['key'] != key:
            continue
        row = dict(fact)
        row['active'] = not fact['valid_to']
        rows.append(row)
    rows.sort(key=lambda f: (f['date'], f['id']), reverse=True)
    return rows


# ── добір (К6) ──────────────────────────────────────────────────────────────

def _scope_ok(fact, scope):
    """Порожнє поле запису означає «стосується всього».

    Саме тому знання про людину (тон, заборони, спосіб читати) не зникає при
    переході між проєктами, а робоча дрібниця одного каналу не лізе в чужу розмову.
    """
    if not scope:
        return True
    for k in SCOPE_KEYS:
        want = (scope.get(k) or '').strip()
        have = (fact['scope'].get(k) or '').strip()
        if want and have and want != have:
            return False
    return True


def _in_field(token, words):
    """Чи є цей токен у полі. Відповідь двійкова, «знайдено чи ні», а не кількість
    входжень: інакше довге тіло виграло б у короткого влучного опису самою частотою
    слова, а не суттю збігу (specs/user-memory-v2, рішення 2 до S6).
    """
    for word in words:
        if word == token or (len(token) >= 4 and (word.startswith(token) or token.startswith(word))):
            return True
    return False


# ── рідкість слів у корпусі (S7) ────────────────────────────────────────────
# НАВІЩО. Ваги полів кажуть, ДЕ знайдено слово. Вони нічого не кажуть про те, ЧОГО
# ВАРТЕ саме це слово. Поки всі токени запиту важили однаково, «як», «через», «сам»
# і «щоб» давали той самий внесок, що й «плеєр», «снепшот» чи «Sentry», а службових
# слів у живій репліці більшість. Замір S6 показав це числом: девʼять із тринадцяти
# промахів МАЛИ спільні слова з потрібним записом, тобто лексичний шанс був, і його
# зʼїдав шум (data/user-memory-audit/zamir-s6.md).
#
# ЯК РАХУЄМО. Рідкість береться з САМОГО корпусу фактів, а не з зовнішнього словника
# української: сховище памʼяті це вузька предметна мова однієї людини, у якій
# «памʼять», «чат» і «віджет» настільки ж службові, як «через», хоча в жодному
# словнику загальновживаних слів їх нема. Формула класична, log((N+1)/df): слово, що
# лежить майже в кожному записі, важить майже нуль, слово з двох записів важить
# багато, і жодне значення не падає в нуль остаточно, тому на крихітному сховищі
# (два записи, обидва зі спільним словом) добір не вироджується в порожньо.
#
# ЧОМУ ІНДЕКС, А НЕ ПІДРАХУНОК НА КОЖЕН ЗАПИТ. Добір відбувається на КОЖНОМУ ході.
# Побудова словника рідкості це повний прохід по корпусу (на живих 294 фактах
# близько 43 мс проти 14 мс на читання самих файлів), тому вона робиться раз на
# завантажений корпус і лягає в кеш. Мішки слів записів лежать у тому самому індексі,
# тож оцінка більше не токенізує корпус наново на кожен запит: добір після цієї зміни
# коштує МЕНШЕ, ніж коштував до неї.

_INDEX_CACHE = {}
_INDEX_ORDER = []


def _fingerprint(facts):
    """Відбиток корпусу для кеша індексу.

    Ід і дата це не просто «щось унікальне»: нова версія запису це ЗАВЖДИ новий файл
    з новим ідом (S1, незнищенність), а правка наявного файлу зачіпає лише
    фронтматер (`_stamp_front`: лічильники, поверх, дата кінця дії). Тому пара
    «ід + дата» плюс довжини полів ловлять будь-яку зміну, від якої рідкість слів
    могла б поїхати, і не ловлять нічого зайвого.
    """
    return tuple((f['id'], f['date'], len(f['description']), len(f['key']), len(f['body']))
                 for f in facts)


def _build_index(facts):
    bags, df = {}, {}
    for fact in facts:
        bag = (frozenset(_words(fact['description'])),
               frozenset(_words(fact['key'].replace('-', ' '))),
               frozenset(_words(fact['body'])))
        bags[fact['id']] = bag
        # Слово рахується РАЗ на запис, у скількох би полях воно не стояло: рідкість
        # відповідає на питання «у скількох записах це взагалі трапляється».
        for word in bag[0] | bag[1] | bag[2]:
            df[word] = df.get(word, 0) + 1
    return {'total': len(facts), 'df': df, 'vocab': sorted(df), 'bags': bags}


def _index(facts):
    """Індекс корпусу з кеша або новий. Один прохід на корпус, не на запит."""
    fp = _fingerprint(facts)
    index = _INDEX_CACHE.get(fp)
    if index is None:
        index = _build_index(facts)
        _INDEX_CACHE[fp] = index
        _INDEX_ORDER.append(fp)
        while len(_INDEX_ORDER) > INDEX_CACHE_MAX:
            _INDEX_CACHE.pop(_INDEX_ORDER.pop(0), None)
    return index


def _token_df(token, index):
    """У скількох записах корпусу цей токен щось піднімає.

    Рахується за ТИМ САМИМ правилом, що й збіг у `_in_field`, інакше рідкість
    міряла б не те, що потім знаходить добір: токен «пушай» не стоїть у корпусі
    жодного разу дослівно, але через префікс піднімає всі записи зі словом «пуш», і
    вважати його унікальним означало б дати шумному слову найбільшу вагу.

    Береться НАЙЧАСТІША зі споріднених форм, а не сума по них. Сума перебільшила б
    рідкість навпаки, у бік нуля, а точний перелік записів на кожну форму вимагав би
    проходу по корпусу на КОЖЕН запит, тобто рівно того, чого індекс і уникає.
    """
    df, vocab = index['df'], index['vocab']
    best = df.get(token, 0)
    if len(token) < 4:
        return best
    i = bisect.bisect_left(vocab, token)
    while i < len(vocab) and vocab[i].startswith(token):
        best = max(best, df[vocab[i]])
        i += 1
    for cut in range(2, len(token)):
        best = max(best, df.get(token[:cut], 0))
    return best


def _rarity(tokens, index):
    """Вага кожного токена запиту за рідкістю в корпусі. Токен, якого в корпусі
    нема взагалі, отримує нуль: він однаково нічого не піднімає."""
    total = index['total']
    weights = {}
    for token in tokens:
        if token in weights:
            continue
        df = _token_df(token, index)
        weights[token] = math.log((total + 1.0) / df) if df else 0.0
    return weights


def _score(fact, tokens, index, rarity):
    """Скільки цей запис важить для запиту. Рахується і по опису, і по ключу, і
    по тілу (специфікація К12), кожне поле зі своєю вагою (SCORE_WEIGHT_*): опис
    важить найбільше, тіло найменше, щоб довгий текст не переміг короткий
    влучний опис самою довжиною.

    Рідкість токена (S7) множиться ПОВЕРХ ваг полів, а не замість них: питання «де
    знайдено» і «чого варте знайдене» це різні питання, і відповідь на друге не
    скасовує першої. Наслідок навмисний: рідкісне слово, знайдене лише в тілі, може
    переважити службове слово, знайдене в описі.
    """
    desc, key, body = index['bags'][fact['id']]
    score = 0.0
    for token in tokens:
        weight = rarity.get(token, 0.0)
        if not weight:
            continue
        fields = 0
        if _in_field(token, desc):
            fields += SCORE_WEIGHT_DESCRIPTION
        if _in_field(token, key):
            fields += SCORE_WEIGHT_KEY
        if _in_field(token, body):
            fields += SCORE_WEIGHT_BODY
        score += weight * fields
    return score


def _is_archive_candidate(fact):
    """Багато показів, жодного підтвердження (специфікація К18). Це сигнал
    людині, не команда системі: саме архівування лишається дією людини
    (рішення 3 до S10), тут ставиться лише позначка."""
    return (fact['shown'] > ARCHIVE_CANDIDATE_SHOWN_THRESHOLD
            and fact['hits'] == 0)


def _bump_shown(home, picked):
    """Лічильник показів (специфікація К17): факт, що потрапив у зібраний блок,
    отримує `shown + 1`.

    Оновлюються ЛИШЕ файли з `picked`, а не весь корпус (план S10, рішення 5):
    збірка блоку йде щоходу, і переписувати сотні файлів заради дюжини показаних
    перетворило б кожну відповідь на зайвий диск-I/O. Через `_stamp_front` тіло
    факту лишається недоторканим -- той самий принцип, на якому стоїть К9.
    """
    for fact in picked:
        _stamp_front(fact_path(home, fact['id']), [('shown', fact['shown'] + 1)])


def select(home, query='', scope=None, limit=DEFAULT_LIMIT, facts=None):
    """Підняти лише доречні записи, а не весь корпус (К6), і завжди донести ядро
    (specs/user-memory-v2, К1) окремо від цієї стелі.

    Порожній запит це не «віддати все»: це «віддати найсвіжіше в межах обсягу, до
    стелі». Стеля (`limit`) обмежує лише ДИНАМІЧНУ частину, бо саме її ціна росте з
    кожним новим фактом у сховищі; ядро свою стелю вже пройшло при записі (S2:
    CORE_MAX_COUNT/CORE_MAX_CHARS, дивись `set_tier`) і тут більше не перевіряється.

    Ранжування динамічної частини враховує підтвердження і кандидатність на архів
    (К18) ПІСЛЯ лексичної оцінки, тобто лише як тай-брейк: кандидат на архів
    (`_is_archive_candidate`) не викидається з добору, він лише поступається місцем
    факту з ТІЄЮ Ж оцінкою, якщо той підтверджений частіше або просто свіжіший і ще
    не встиг набрати показів без жодного підтвердження.
    """
    pool = facts if facts is not None else load_all(home)
    # Карантин (S5) не потрапляє в хід НІКОЛИ, навіть якщо хтось поставив йому
    # tier=core в обхід set_tier: непідтверджений автозапис не сміє псувати
    # відповідь так само, як підтверджений факт.
    pool = [f for f in pool if f['status'] == 'active']
    pool = [f for f in pool if _scope_ok(f, scope)]
    winners, _ = resolve_conflicts(pool)
    for f in winners:
        f['archive_candidate'] = _is_archive_candidate(f)

    core = [f for f in winners if f['tier'] == 'core']
    rest = [f for f in winners if f['tier'] != 'core']

    def _rank(f):
        return (not f['archive_candidate'], f['hits'], f['date'])

    tokens = _words(query)
    if tokens:
        # Індекс будується по ВСІХ чинних записах, включно з ядром: рідкість це
        # властивість корпусу, а не тієї його частини, що бореться за місце в стелі.
        index = _index(winners)
        rarity = _rarity(tokens, index)
        scored = [(self_score, f) for f in rest
                  for self_score in (_score(f, tokens, index, rarity),) if self_score > 0]
        scored.sort(key=lambda pair: (pair[0],) + _rank(pair[1]), reverse=True)
        dynamic = [f for _, f in scored[:limit]]
    else:
        dynamic = sorted(rest, key=_rank, reverse=True)[:limit]
    return core + dynamic


def prompt_block(home, query='', scope=None, limit=DEFAULT_LIMIT, facts=None):
    """Готовий блок памʼяті для системного шару ходу (К2).

    Порожнє сховище віддає порожній рядок, а не порожню шапку. Причина не в
    охайності: будь-який зайвий байт у системному шарі перераховує ВЕСЬ префікс
    кеша (див. tests/unit/test_sys_prompt_stability.py), тобто порожня секція
    коштувала б грошей рівно ні за що.

    Саме тут, а не в `select`, рахуються покази (К17): `select` окремо викликає і
    пошук (`/api/memory/search`), де факт лише ЗНАЙДЕНО, а не показано в ході, і
    підмінити один виклик іншим означало б рахувати покази за кожен пошук моделі.
    """
    picked = select(home, query=query, scope=scope, limit=limit, facts=facts)
    if not picked:
        return ''
    _bump_shown(home, picked)
    lines = ['\n\n[Памʼять застосунку. Це вже записано раніше, спирайся на це і не '
             'вигадуй понад це]']
    for fact in picked:
        body = fact['body'].replace('\n', ' ').strip()
        if len(body) > BODY_IN_PROMPT:
            body = body[:BODY_IN_PROMPT].rstrip() + '...'
        marks = []
        if fact['conflict']:
            marks.append('конфлікт: є суперечливий давніший запис, узято новіший')
        if fact['verify']:
            marks.append('звірити перед використанням')
        tail = (' [' + '; '.join(marks) + ']') if marks else ''
        lines.append('- (%s, %s, %s) %s: %s%s' % (
            fact['type'], (fact['date'] or '')[:10], ORIGIN_LABEL.get(fact['origin'], fact['origin']),
            fact['description'], body, tail))
    return '\n'.join(lines)


# ── перенос (К8) ────────────────────────────────────────────────────────────

BUNDLE_KIND = 'logopsis-memory'
BUNDLE_VERSION = 1


def export_bundle(home, external_answer=None):
    """Уся памʼять ОДНИМ обʼєктом, який серіалізується в один файл.

    Машинних шляхів у бандлі нема свідомо: проєкти їдуть ідом і назвою, без `path`.
    Саме тому імпорт на іншій машині не вимагає «жодної правки шляхів»: правити нема
    чого, шляху в даних не існує.

    ПРАВИЛО ЕКСПОРТУ ТУТ ТЕ САМЕ, ЩО В ПЕРЕНОСІ (specs/user-data-architecture, К6).
    Сьогодні клас `memory` наш, тому бандл везе факти як віз. Але рішення «везти»
    ухвалює не цей рядок, а `export_policy`, який читає ознаку `external` з реєстру:
    у день, коли памʼять переїде в чуже сховище, вивантаження зупиниться саме тут і
    принесе питання людині, а не винесе чужі записи мовчки. `external_answer` це
    СЛОВО людини, не булевий прапорець (див. докстрінг export_policy).
    """
    decision = _policy.plan(('memory',), answer=external_answer)
    carry_facts = 'memory' in decision['carry'] or decision['externalIncluded']
    return {
        'kind': BUNDLE_KIND,
        'version': BUNDLE_VERSION,
        'exportedAt': _now(),
        'projects': [{'id': p.get('id'), 'name': p.get('name')} for p in projects(home)]
                    if carry_facts else [],
        'facts': load_all(home) if carry_facts else [],
        'skipped': decision['skipped'],
        'external': {
            'included': decision['externalIncluded'],
            'answer': decision['answer'],
            'items': decision['externalItems'],
            'question': decision['question'],
        },
    }


def import_bundle(home, bundle):
    """Відновити памʼять із бандла. Повторний імпорт нічого не задвоює.

    Ід запису це і є ключ ідемпотентності: людина, яка натиснула імпорт двічі (а
    вона натисне, бо перший раз мовчазний), мусить отримати ту саму памʼять, а не
    подвійну.
    """
    if not isinstance(bundle, dict) or bundle.get('kind') != BUNDLE_KIND:
        raise ValueError('це не файл памʼяті Logopsis')
    ensure(home)

    reg = _load_registry(home)
    known = {p.get('id') for p in reg['projects']}
    for proj in bundle.get('projects') or []:
        pid = (proj or {}).get('id')
        if pid and pid not in known:
            reg['projects'].append({'id': pid, 'name': proj.get('name') or pid,
                                    'path': '', 'createdAt': _now()})
            known.add(pid)
    _save_registry(home, reg)

    imported = skipped = 0
    for fact in bundle.get('facts') or []:
        if not isinstance(fact, dict):
            continue
        fid = fact.get('id') or ''
        if not _safe_id(fid) or os.path.exists(fact_path(home, fid)):
            skipped += 1
            continue
        try:
            write_fact(home,
                       description=fact.get('description'),
                       body=fact.get('body') or '',
                       origin=fact.get('origin') or 'inferred',
                       type=fact.get('type') or 'project',
                       scope=fact.get('scope') or {},
                       key=fact.get('key'),
                       source=fact.get('source') or '',
                       date=fact.get('date'),
                       fact_id=fid,
                       verify=fact.get('verify'),
                       # Версійність переїжджає разом із записом. Інакше памʼять
                       # «оживає» на новій машині без історії, і закритий запис знову
                       # починає їхати в хід нарівні з чинним.
                       tier=fact.get('tier'),
                       status=fact.get('status'),
                       weight=fact.get('weight'),
                       valid_to=fact.get('valid_to'),
                       superseded_by=fact.get('superseded_by'),
                       shown=fact.get('shown'),
                       hits=fact.get('hits'))
            imported += 1
        except ValueError:
            skipped += 1
    return {'imported': imported, 'skipped': skipped}


# Тип запису харнесу -> походження. Ці два типи в контракті памʼяті Claude Code
# означають саме сказане людиною (хто вона, що вона поправила), решта це наші власні
# спостереження. Вгадування тут навмисно консервативне: помилитись у бік «виведено»
# дешевше, ніж підписати застосунку слова, яких людина не казала.
_CLAUDE_SAID_TYPES = ('user', 'feedback')
# Індекс харнесу, а не факт: рядки-вказівники на інші файли. Затягнути його означало б
# отруїти сховище записом, який ні на що не спирається.
_CLAUDE_SKIP = ('memory.md', 'readme.md')


def import_claude_dir(home, path, scope=None):
    """Імпорт із теки памʼяті Claude Code. Явна дія людини, ніколи не автоматично.

    Автоматичну міграцію заборонено спекою прямим текстом, і причина практична: у
    дев-режимі харнес підкладає свою памʼять, а застосунок підклав би свою, тож
    відповіді почали б повторювати факти двічі і суперечити самі собі.
    """
    if not os.path.isdir(path):
        raise ValueError('такої теки нема: %s' % path)
    ensure(home)
    imported = skipped = 0
    for name in sorted(os.listdir(path)):
        if not name.endswith('.md') or name.lower() in _CLAUDE_SKIP:
            continue
        src_file = os.path.join(path, name)
        try:
            with open(src_file, encoding='utf-8') as fh:
                raw = fh.read()
        except (OSError, UnicodeDecodeError):
            skipped += 1
            continue
        # Дата береться з ФАЙЛУ, а не ставиться поточна. Памʼять харнесу дати в собі не
        # несе, і перший імпорт проштампував усі 288 записів сьогоднішнім числом: колонка
        # дати перетворилась на однакове число в кожному рядку, тобто ні на що. Час
        # правки файлу це найближче до правди, що взагалі можна дізнатись.
        try:
            stamp = datetime.datetime.fromtimestamp(
                os.path.getmtime(src_file), datetime.timezone.utc)
            when = stamp.strftime('%Y-%m-%dT%H:%M:%SZ')
        except OSError:
            when = None
        fields, body = _parse_front(raw)
        description = (fields.get('description') or fields.get('name') or '').strip()
        description = description.replace('\n', ' ').strip()
        if not description:
            first = next((ln.strip() for ln in body.split('\n') if ln.strip()), '')
            description = re.sub(r'^#+\s*', '', first)[:200]
        if not description:
            skipped += 1
            continue
        ftype = (fields.get('type') or 'project').strip()
        if ftype not in TYPES:
            ftype = 'project'
        source = 'claude-code:%s' % name
        # Ід детермінований від джерела: другий імпорт тієї самої теки мусить бути
        # нулем нових записів, а не другою копією всього.
        fid = 'mem-' + hashlib.sha1(source.encode('utf-8')).hexdigest()[:10]
        if os.path.exists(fact_path(home, fid)):
            skipped += 1
            continue
        try:
            write_fact(home, description=description, body=body,
                       origin='said' if ftype in _CLAUDE_SAID_TYPES else 'inferred',
                       type=ftype, scope=scope or {},
                       key=((fields.get('name') or '').strip() or _key_slug(description)),
                       source=source, fact_id=fid, date=when)
            imported += 1
        except ValueError:
            skipped += 1
    return {'imported': imported, 'skipped': skipped}


# ── зріз для екрана памʼяті (К5) ────────────────────────────────────────────

def board(home, project=None):
    """Усе, що потрібно екрану памʼяті одним запитом: записи, конфлікти, проєкти.

    Записи віддаються ВСІ, не добірка: екран це відповідь на питання «що застосунок
    про мене знає», і добір там був би тихим приховуванням частини відповіді.
    """
    facts = load_all(home)
    _, conflicts = resolve_conflicts(facts)
    # Роль у суперечці, а не просто «є конфлікт». Обидва боки помічені, але переможець
    # і програвший це РІЗНІ новини для людини: один поїде в хід, другий ні. Однаковий
    # підпис на обох картках читався б як «обидва в ході», тобто саме як те тихе
    # злиття, від якого К7 і рятує.
    role = {}
    for c in conflicts:
        role[c['winner']['id']] = 'winner'
        for f in c['losers']:
            role[f['id']] = 'loser'
    rows = []
    for fact in facts:
        row = dict(fact)
        row['conflict'] = fact['id'] in role
        row['conflictRole'] = role.get(fact['id'], '')
        # Позначка кандидата на архів (К18), готова для екрана памʼяті (S11).
        # Тут ЛИШЕ дані: саме архівування лишається дією людини (рішення 3).
        row['archive_candidate'] = _is_archive_candidate(fact)
        if project and (fact['scope'].get('project') or '') not in ('', project):
            row['foreign'] = True
        rows.append(row)
    return {
        'root': store_dir(home),
        'facts': rows,
        'conflicts': [{'key': c['key'],
                       'winner': c['winner']['id'],
                       'losers': [f['id'] for f in c['losers']]} for c in conflicts],
        'projects': projects(home),
        'total': len(rows),
        'bytes': sum(f['size'] for f in facts),
    }
