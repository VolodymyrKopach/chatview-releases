#!/usr/bin/env python3
"""Мова ОПЕРАЦІЙНОЇ СИСТЕМИ на ПЕРШОМУ запуску (specs/i18n-interface, К1).

Дослівна постановка власника: «текст має бути локалізований залежно від мови на
компʼютері юзера». Ключове слово тут НА КОМПʼЮТЕРІ, і саме воно робить цей модуль
потрібним, хоч визначення за системою на фронті вже є.

## Чому мови браузера НЕ ВИСТАЧАЄ, хоч фронт її вже читає

`logopsis/src/i18n/detect.ts` бере `navigator.languages` і робить це правильно. Але
пакована збірка НЕ має вбудованого вебвʼю: `desktop/entry.py` кличе
`webbrowser.open(...)`, тобто відкриває ДЕФОЛТНИЙ БРАУЗЕР людини. Отже
`navigator.languages` це список переваг БРАУЗЕРА, окреме налаштування, яке людина
міняє в самому браузері і яке після встановлення живе незалежно від ОС. Українська
система з англійським Chrome дасть `en`, і людина отримає рівно ту англійську,
проти якої задача.

Друга діра рівно та сама, але з іншого боку: до першого завантаження сторінки фронт
не сказав ще нічого, тому бек на чистій домівці відповідає всім `DEFAULT_LANG`. Усе,
що встигає статись раніше (фоновий агент, елемент черги, розпізнавання голосу), їде
англійською навіть на українській машині.

Тому джерело правди тут ОС, а не браузер, і читає його бек, а не фронт.

## Джерела за платформами і чому саме вони

mac     `defaults read -g AppleLanguages` -> впорядкований список мов інтерфейсу ОС,
        рівно те, що людина перетягує в Системних налаштуваннях. `locale` тут
        НЕПРИДАТНИЙ: під launchd (а застосунок стартує саме так) змінних `LANG`
        і `LC_ALL` просто немає, а `locale.getdefaultlocale()` на цій машині
        вигадує `en_US` при порожньому оточенні, тобто відповідає здогадкою.
win     `GetUserDefaultUILanguage()` через ctypes -> LANGID, який `locale.windows_locale`
        перекладає у `uk_UA`. Це МОВА ІНТЕРФЕЙСУ користувача, а не регіональний формат:
        англійська Windows з українським форматом дати лишається англійською, і це
        правильно. Немає ctypes -> `locale.getdefaultlocale()`, яка на Windows питає
        ту саму систему іншими дверима.
решта   змінні оточення (`LANGUAGE`, `LC_ALL`, `LC_MESSAGES`, `LANG`) і БІЛЬШЕ НІЧОГО:
        чому саме так, написано над `_locale_default`.

## Контракт модуля

Чистий стдліб, без залежностей, нічого не імпортує з server.py чи runner.py: два
процеси, спільного імпорту між ними нема (той самий принцип, що в rules_store і
agent_room). Список доступних мов і дефолт СЮДИ НЕ ЗАШИТІ, вони приходять
параметром: власник мовного списку це runner.AVAILABLE_LANGS, і другої копії правди
тут заводити не можна.

НІКОЛИ НЕ КИДАЄ. Будь-який провал (немає `defaults`, немає ctypes, домівка тільки для
читання) це порожній список тегів і подальший `DEFAULT_LANG`, а не виняток: мова не
має права завалити старт застосунку.
"""
import locale
import os
import subprocess
import sys
import time

# Ручний перебивач мови системи. Існує з двох причин, і обидві реальні.
#
# 1. ДОКАЗ. Перевірити «українська система дає українську» інакше можна лише
#    перемкнувши мову всього компʼютера і перелогінившись. Такий доказ неможливо
#    прогнати в CI і неможливо повторити.
# 2. ЛЮДИНА В ДИВНОМУ ОТОЧЕННІ. Docker, ssh, кіоск: там ОС не повідомляє нічого
#    осмисленого, і одна змінна оточення дешевша за пояснення.
#
# Формат той самий, що в самих джерел: список тегів через кому або двокрапку,
# найпереважніший перший. `LOGOPSIS_SYSTEM_LANG=uk-UA,en-US`.
ENV_OVERRIDE = 'LOGOPSIS_SYSTEM_LANG'

# Стеля на `defaults read`. Виклик робиться РІВНО РАЗ на установку (далі є файл мови),
# тому дві секунди тут це стеля аварії, а не бюджет старту: нормальний виклик
# відпрацьовує за ~20 мс.
_DEFAULTS_TIMEOUT = 2.0


def _split_tags(raw):
    """Рядок джерела -> список тегів. Роздільники обидва, бо джерела різні:
    `LANGUAGE` розділяє двокрапкою, людина в змінній оточення пише кому."""
    out = []
    for chunk in str(raw or '').replace(':', ',').replace(';', ',').split(','):
        tag = chunk.strip().strip('"').strip("'").strip()
        if tag:
            out.append(tag)
    return out


def _mac_ui_languages(runner=None):
    """macOS: впорядкований `AppleLanguages` з глобального домену.

    Вивід `defaults` це стара plist-нотація, а не JSON:

        (
            "uk-UA",
            "en-US"
        )

    Лапки НЕОБОВʼЯЗКОВІ (голе `uk` друкується без них), тому розбираємо рядками і
    чистимо кожен від дужок, ком і лапок. Повний plist-парсер тут був би зайвою
    залежністю заради трьох рядків.

    `runner` існує заради тесту: підставити свій вивід дешевше, ніж підміняти
    справжній `defaults` на машині."""
    call = runner or _defaults_read
    try:
        raw = call()
    except Exception:
        return []
    if not raw:
        return []
    out = []
    for line in str(raw).replace('(', '\n').replace(')', '\n').splitlines():
        tag = line.strip().rstrip(',').strip().strip('"').strip("'").strip()
        if tag:
            out.append(tag)
    return out


def _defaults_read():
    """Справжній виклик `defaults`. Відділений від розбору, щоб тест перевіряв саме
    розбір і не залежав від того, що стоїть у людини в системі."""
    res = subprocess.run(['defaults', 'read', '-g', 'AppleLanguages'],
                         stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                         timeout=_DEFAULTS_TIMEOUT)
    if res.returncode != 0:
        return ''
    return res.stdout.decode('utf-8', 'replace')


def _windows_ui_langid():
    """Справжній виклик WinAPI. Той самий поділ, що на маку: виклик окремо, розбір
    окремо, тому гілку Windows можна довести тестом з мака."""
    import ctypes
    return int(ctypes.windll.kernel32.GetUserDefaultUILanguage())


def _windows_ui_languages(langid_reader=None):
    """Windows: LANGID мови інтерфейсу -> тег на кшталт `uk_UA`.

    `locale.windows_locale` це звичайний словник стдлібу, доступний на БУДЬ-ЯКІЙ
    платформі (перевірено на маку: `0x422 -> uk_UA`), тому переклад LANGID у тег
    тестується без Windows. Недоступний ctypes чи невідомий LANGID це порожній
    список, а не виняток.

    Один тег, а не список, і це не недогляд: Windows має РІВНО ОДНУ мову інтерфейсу
    користувача. Список переваг у неї теж є, але він про формати і розкладки, а
    питання тут «якою мовою написана система»."""
    reader = langid_reader or _windows_ui_langid
    try:
        langid = reader()
    except Exception:
        return []
    name = locale.windows_locale.get(langid)
    return [name] if name else []


def _env_languages(env):
    """POSIX: змінні оточення в порядку спадання пріоритету, як їх читає gettext.
    `uk_UA.UTF-8` ріжеться до `uk_UA`: кодування нас не цікавить. `C` і `POSIX` це
    «мови немає», а не мова."""
    out = []
    for var in ('LANGUAGE', 'LC_ALL', 'LC_MESSAGES', 'LANG'):
        for chunk in _split_tags(env.get(var)):
            tag = chunk.split('.')[0].strip()
            if tag and tag.upper() not in ('C', 'POSIX'):
                out.append(tag)
    return out


def _locale_default():
    """Запасний шлях РІВНО для Windows, коли ctypes недоступний.

    На Windows це САМОСТІЙНЕ джерело: CPython питає `GetLocaleInfo(LOCALE_USER_DEFAULT)`,
    тобто ту саму систему, тільки іншими дверима. Тому там воно має сенс.

    На POSIX і на маку воно СВІДОМО не викликається, і це не економія, а вимога до
    чесності. На POSIX функція читає рівно ті самі змінні оточення, що `_env_languages`
    вище, тобто нічого не додає. На маку при порожньому оточенні (а під launchd воно
    порожнє) вона віддає вигадане `en_US`: заміряно на машині автора, де мова системи
    англійська лише випадково. Якби ми лишили її як загальний останній шанс, стан
    «система не сказала нічого» перестав би існувати взагалі, і будь-яка мовчазна
    система виглядала б як американська. Тест
    `test_a_silent_system_is_treated_like_an_unsupported_one` ловить саме це."""
    try:
        code = (locale.getdefaultlocale() or (None, None))[0]
    except Exception:
        return []
    return [code] if code else []


def system_lang_tags(platform=None, env=None, mac_reader=None, win_reader=None):
    """Мови системи, найпереважніша перша. Порожній список = система не сказала нічого.

    Перебивач оточення стоїть ПЕРШИМ і замінює платформну гілку цілком: сенс
    перебивача саме в тому, щоб не залежати від того, що скаже ОС."""
    env = os.environ if env is None else env
    platform = sys.platform if platform is None else platform

    override = _split_tags(env.get(ENV_OVERRIDE))
    if override:
        return override

    if platform == 'darwin':
        tags = _mac_ui_languages(mac_reader)
    elif platform.startswith('win'):
        tags = _windows_ui_languages(win_reader) or _locale_default()
    else:
        tags = _env_languages(env)

    return tags


def primary(tag):
    """Первинний субтег: `uk-UA` -> `uk`, `en_US` -> `en`. Дзеркалить `primary()` у
    logopsis/src/i18n/detect.ts: два визначники мусять зводити теги однаково,
    інакше фронт і бек розійшлися б на тій самій системі."""
    return str(tag or '').strip().lower().replace('_', '-').split('-')[0]


def pick_lang(tags, available):
    """Перша мова зі списку системи, яку ми вміємо. Немає жодної -> None.

    Дзеркалить `detectSystemLang` фронту, включно з поведінкою на списку: людина з
    `[pl, uk, en]` отримає українську, бо польської в нас немає, і це ближче до її
    вибору, ніж англійська за алфавітом черги."""
    for tag in tags or ():
        code = primary(tag)
        if code and code in available:
            return code
    return None


def _atomic_write(path, text):
    """Той самий запис, що в `POST /api/lang`: tmp поруч, fsync, `os.replace`.
    Обірваний запис лишив би порожній файл, а порожній файл це вже НЕ «перший
    запуск», тобто визначення більше не повторилось би ніколи."""
    tmp = '%s.tmp.%d' % (path, os.getpid())
    with open(tmp, 'w', encoding='utf-8') as f:
        f.write(text)
        f.flush()
        os.fsync(f.fileno())
    os.replace(tmp, path)


def seed_lang_file(path, available, default, log=None, **hooks):
    """ПЕРШИЙ ЗАПУСК: файлу мови ще немає -> взяти мову ОС і записати її (К1).

    Повертає dict-звіт: `{'wrote', 'lang', 'tags', 'reason'}`. Сам нічого не показує
    людині, лише пише рядок у лог застосунку через `log`.

    ТРИ ВИХОДИ, І КОЖЕН НАВМИСНИЙ.

    1. Файл Є -> не робимо НІЧОГО і мовчимо. Це і є «визначення рівно один раз»:
       далі істина це файл. Людина, яка перемкнула мову руками, не отримає її назад
       ні при наступному запуску, ні коли передумає щодо мови системи.
    2. Файл ВІДСУТНІЙ, мова системи підтримана -> пишемо її і друкуємо рядок.
    3. Файл ВІДСУТНІЙ, мова системи НЕ підтримана (або система мовчить) -> лишається
       `DEFAULT_LANG`, і файл СВІДОМО НЕ СТВОРЮЄТЬСЯ.

    Чому третій вихід не пише файл, хоч це виглядало б акуратніше. Записавши сюди
    `en`, ми б назавжди зачинили стан «бек ще нічого не знає», а саме він дозволяє
    фронту рівно один раз записати СВОЮ здогадку (specs/dictation-language-independence,
    К6). А фронтова здогадка на Windows багатша за нашу: `GetUserDefaultUILanguage`
    віддає одну мову інтерфейсу, тоді як `navigator.languages` віддає список, у якому
    підтримана мова може стояти другою. Тобто німецька Windows зі списком `[de, uk]`
    отримає українську від фронту, якщо бек не встигне забити файл англійською.
    Результат для самої непідтриманої мови той самий (`current_lang` на відсутньому
    файлі і так віддає `DEFAULT_LANG`), тому ми нічого не втрачаємо і лишаємо фронту
    його шанс.

    Рядок у лозі друкується в ОБОХ випадках 2 і 3, бо тиха магія тут гірша за явний
    дефолт: людина, чий інтерфейс раптом став українським, мусить мати де прочитати,
    що саме ми побачили в системі.
    """
    log = log or (lambda _m: None)
    if os.path.exists(path):
        return {'wrote': False, 'lang': None, 'tags': [], 'reason': 'lang file exists'}

    tags = system_lang_tags(**hooks)
    choice = pick_lang(tags, available)
    # Форма рядка навмисно та сама, що в решти родини `[lang ...]` у server.py: та сама
    # позиція часу в дужках, той самий повний ISO (лог не ротується, сама година в ньому
    # неоднозначна), та сама англійська. Тому людина грепає всю історію мови одним
    # рухом `^\[lang `, а не двома різними.
    stamp = time.strftime('%Y-%m-%dT%H:%M:%S')
    seen = ','.join(tags) if tags else 'none'

    if not choice:
        log('[lang %s] first run: system=%s unsupported -> %s (no file written)'
            % (stamp, seen, default))
        return {'wrote': False, 'lang': default, 'tags': tags,
                'reason': 'system language not supported'}

    try:
        _atomic_write(path, choice + '\n')
    except Exception as e:
        # Домівка тільки для читання чи зайнятий диск. Мова відкотиться до
        # `DEFAULT_LANG`, застосунок стартує, а причина лишиться в лозі.
        log('[lang %s] first run: system=%s -> %s, write failed: %s'
            % (stamp, seen, choice, e))
        return {'wrote': False, 'lang': default, 'tags': tags,
                'reason': 'write failed: %s' % e}

    log('[lang %s] first run: system=%s -> %s' % (stamp, seen, choice))
    return {'wrote': True, 'lang': choice, 'tags': tags, 'reason': 'system language'}


if __name__ == '__main__':
    # Ручний огляд: що ця машина розповідає про свою мову. Нічого не пише.
    _tags = system_lang_tags()
    print('platform: %s' % sys.platform)
    print('tags:     %s' % (','.join(_tags) if _tags else 'none'))
    print('pick:     %s' % (pick_lang(_tags, ('en', 'uk')) or '-'))
