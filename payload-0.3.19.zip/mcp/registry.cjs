// registry.cjs: ЧИТАЧ єдиного реєстру здатностей Logopsis (capabilities.json).
//
// Перший споживач реєстру: список інструментів MCP у server.cjs. Другий, поле `actions`
// у GET /api/project-state, читає ТОЙ САМИЙ файл через registry.py.
//
// Опис інструмента збирається за тим самим правилом, що й у registry.py: summary,
// потім ендпоінти, і для тих, що змінюють стан, речення про явне прохання користувача.
// Правило одне на два консюмери, бо інакше описи розповзуться так само, як розповзлись
// колись самі списки (specs/chatview-mcp/spec.md).
'use strict';

const fs = require('fs');
const path = require('path');

const CAPABILITIES_FILE = path.join(__dirname, 'capabilities.json');

function load(file) {
  const raw = fs.readFileSync(file || CAPABILITIES_FILE, 'utf8');
  const data = JSON.parse(raw);
  if (!data || !Array.isArray(data.capabilities)) {
    throw new Error('capabilities.json: очікується {capabilities: [...]}');
  }
  return data;
}

function describe(cap, consentClause) {
  const calls = (cap.calls || []).map(c => `${c.method} ${c.path}`).join(' + ');
  const parts = [cap.summary, calls];
  if (cap.mutates) parts.push(consentClause);
  // Те саме правило, що в registry.py: шматки без кінцевої крапки, одна крапка в кінці.
  // Описи двох поверхонь мають збігатись символ у символ, і тест це звіряє.
  return parts.filter(p => p && p.trim())
    .map(p => p.trim().replace(/\.+$/, ''))
    .join('. ') + '.';
}

// tools/list MCP: імʼя + опис + JSON-схема входу, усе з реєстру.
function toolDefinitions(file) {
  const data = load(file);
  return data.capabilities.map(cap => ({
    name: cap.name,
    description: describe(cap, data.consentClause || ''),
    inputSchema: cap.input || { type: 'object', properties: {} },
  }));
}

function byName(file) {
  const out = new Map();
  for (const cap of load(file).capabilities) out.set(cap.name, cap);
  return out;
}

module.exports = { CAPABILITIES_FILE, load, describe, toolDefinitions, byName };
