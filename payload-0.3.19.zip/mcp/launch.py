#!/usr/bin/env python3
"""launch.py: підйом MCP-сервера Logopsis, коли `node` НЕ в PATH.

ЧОМУ ЦЕ ІСНУЄ. У `.mcp.json` командою стояло голе `node`, а клієнт спавнить MCP-сервери
з бідним PATH (`~/.local/bin:/usr/local/bin:/usr/bin:/bin`). Нода на цій машині живе під
nvm, тобто в PATH її нема, і `claude mcp list` віддавав:

    logopsis: node tools/viz/chat/mcp/server.cjs
              ✘ Failed to connect - ENOENT: Executable not found in $PATH: "node"

Тобто всі 16 інструментів Logopsis були недоступні ЖОДНОГО разу, і мовчки: асистент не
бачив ні інструментів, ні причини.

ЧОМУ САМЕ ТАК, а не абсолютним шляхом до ноди. Абсолютний шлях
(`~/.nvm/versions/node/v20.20.2/bin/node`) вмирає від першого `nvm install`, а на чужій
машині його нема взагалі. Тут натомість те саме правило, яким уже живе сам застосунок
(`server.py:_resolve_node_bin`, `runner.py:_resolve_node`): спершу PATH, потім відомі
місця менеджерів версій, і все це ГЛОБОМ, без жодної прибитої версії.

ЧОМУ ЛАУНЧЕР НА PYTHON. Нової залежності це не додає: Logopsis сам написаний на Python
(`server.py`), і місток без запущеного застосунку безглуздий, тож python3 на машині вже
мусить бути. Зате python3 є в бідному PATH (`/usr/local/bin/python3`), а node нема, і
саме це різниця між «інструменти є» і «інструментів нема».

Windows. Команду в `.mcp.json` записано як `${LOGOPSIS_MCP_PYTHON:-python3}`. Там, де
інтерпретатор зветься `python` або `py`, це лікується однією змінною середовища, без
правок у репозиторії:

    setx LOGOPSIS_MCP_PYTHON python

Ноду сам лаунчер шукає і в Windows-місцях (nvm4w, Program Files, fnm, volta, asdf).
Точковий обхід: LOGOPSIS_MCP_NODE=<повний шлях до node>.

Не знайшли ноду ніде: виходимо кодом 1 і кажемо ОДНЕ людське речення в stderr. Мовчазний
провал це рівно те, що ця правка лікує.

ДРУГА ПОЛОМКА, теж заміряна (2026-09-11): CONNECTION_CLOSED навіть коли нода на місці.
`claude mcp list` резолвить рядок `args` із `.mcp.json` від каталогу, в якому ЗАПУЩЕНО
клієнта, а не від каталогу самого `.mcp.json`: з кореня репозиторію виходить «✔
Connected», з `tools/viz/chat` — `python3: can't open file
.../tools/viz/chat/tools/viz/chat/mcp/launch.py` (подвоєний шлях) і клієнт бачить це як
CONNECTION_CLOSED, мовчки. `${CLAUDE_PROJECT_DIR}` тут не рятує: Claude Code кладе його в
СЕРЕДОВИЩЕ дочірнього процесу (це працює, перевірено пробником, що читає
`os.environ['CLAUDE_PROJECT_DIR']` зсередини), але сама його ЗНАЧЕННЯ — це каталог
ЗАПУСКУ клієнта в цій сесії, а не «корінь git-репозиторію»: з підкаталогу
`CLAUDE_PROJECT_DIR` так само вказує на підкаталог. Тому підставляти
`${CLAUDE_PROJECT_DIR}` текстом У САМОМУ РЯДКУ `args` (те, що документація Claude Code
називає підтримуваним) тут марно: `${VAR}`-підстановку клієнт робить ДО спавна, зі
СВОГО Ж середовища, де `CLAUDE_PROJECT_DIR` ще нема.

Тому в `.mcp.json` `args` це більше не шлях до файла, а інлайн `python3 -c` з пошуком
УГОРУ по батьківських теках від `CLAUDE_PROJECT_DIR` (або поточної теки, якщо змінної
нема — той самий фолбек, що nвм-пошук ноди тут же нижче) до першої теки, де реально є
`tools/viz/chat/mcp/launch.py`, і лише тоді запускає його `runpy.run_path` з уже
АБСОЛЮТНИМ шляхом. Знайдений абсолютний шлях означає, що всередині цього файлу `HERE`
(нижче) рахується правильно незалежно від того, звідки стартував клієнт: сам launch.py
про цю пляшкову шийку більше не знає і не мусить.

Чому логіка пошуку лежить у `.mcp.json`, а не тут: перший процес, який клієнт спавнить,
не має ЖОДНОГО файлового аргументу для резолву (`python3 -c "..."` не відкриває файл
узагалі, тому cwd на цьому кроці не важить), і саме це розриває залежність від cwd. Якби
пошук був усередині ЦЬОГО файлу, ОС однаково не змогла б його знайти на самому першому
кроці — рівно та ж хвороба, яку лікуємо.
"""
import glob
import os
import shutil
import subprocess
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
SERVER_CJS = os.path.join(HERE, 'server.cjs')

WINDOWS = os.name == 'nt'
NODE_NAME = 'node.exe' if WINDOWS else 'node'


def _version_key(path):
    """Впорядкувати версії ЧИСЛАМИ, а не рядком: рядкове сортування ставить v9 вище
    за v20, і тоді місток піднімався б на найстарішій ноді в системі."""
    for part in path.replace('\\', '/').split('/'):
        digits = part.lstrip('v').split('.')
        if part.startswith('v') and all(d.isdigit() for d in digits if d):
            return tuple(int(d) for d in digits if d.isdigit())
    return ()


def _managed_candidates(home):
    """Місця, куди менеджери версій кладуть ноду. Тільки шаблони, жодної версії."""
    patterns = [
        os.path.join(home, '.nvm/versions/node/*/bin', NODE_NAME),          # nvm
        os.path.join(home, '.volta/tools/image/node/*/bin', NODE_NAME),     # volta
        os.path.join(home, '.asdf/installs/nodejs/*/bin', NODE_NAME),       # asdf
        os.path.join(home, '.local/share/fnm/node-versions/*/installation/bin', NODE_NAME),
        os.path.join(home, 'Library/Application Support/fnm/node-versions/*/installation/bin',
                     NODE_NAME),
        os.path.join(home, 'n/versions/node/*/bin', NODE_NAME),             # n
    ]
    if WINDOWS:
        for var in ('NVM_HOME', 'APPDATA', 'LOCALAPPDATA'):
            root = os.environ.get(var)
            if root:
                patterns.append(os.path.join(root, 'nvm', '*', NODE_NAME))  # nvm-windows
        patterns.append(os.path.join(home, 'AppData/Roaming/nvm/*', NODE_NAME))
        patterns.append(os.path.join(home, 'scoop/apps/nodejs/*', NODE_NAME))
    found = []
    for pattern in patterns:
        found.extend(glob.glob(pattern))
    # Найновіша версія перша: місток нічого екзотичного не вимагає, тому свіжа нода
    # завжди безпечніша за випадкову стару, що валялась у системі.
    return sorted(set(found), key=_version_key, reverse=True)


def _fixed_candidates():
    out = []
    if WINDOWS:
        for var in ('ProgramFiles', 'ProgramW6432', 'LOCALAPPDATA'):
            root = os.environ.get(var)
            if root:
                out.append(os.path.join(root, 'nodejs', NODE_NAME))
                out.append(os.path.join(root, 'Programs', 'nodejs', NODE_NAME))
    else:
        out += ['/opt/homebrew/bin/node', '/usr/local/bin/node', '/usr/bin/node',
                '/snap/bin/node']
    return out


def resolve_node():
    """Перший робочий кандидат. Порядок: явна вказівка, PATH, менеджери версій,
    типові інсталяції. Той самий порядок, що в server.py і runner.py."""
    explicit = (os.environ.get('LOGOPSIS_MCP_NODE') or '').strip()
    if explicit:
        return explicit if os.path.isfile(explicit) else None
    on_path = shutil.which('node')
    if on_path:
        return on_path
    home = os.path.expanduser('~')
    for cand in _managed_candidates(home) + _fixed_candidates():
        if os.path.isfile(cand) and os.access(cand, os.X_OK):
            return cand
    return None


def fail(message):
    sys.stderr.write('Logopsis MCP: ' + message + '\n')
    raise SystemExit(1)


def main():
    if not os.path.isfile(SERVER_CJS):
        fail('поруч із цим лаунчером нема server.cjs (%s). Схоже, теку mcp/ перенесли '
             'або зіпсували: поверніть файл на місце.' % SERVER_CJS)
    node = resolve_node()
    if not node:
        fail('не знайшов Node.js ні в PATH, ні там, куди його кладуть nvm, fnm, volta, '
             'asdf і звичайний інсталятор. Поставте Node 18+ або вкажіть шлях змінною '
             'LOGOPSIS_MCP_NODE=/повний/шлях/до/node, і перезапустіть клієнта.')
    argv = [node, SERVER_CJS] + sys.argv[1:]
    if WINDOWS:
        # На Windows execv підміняє процес не так, як на POSIX, і клієнт бачить це як
        # смерть сервера. Тому лишаємось батьком і чесно віддаємо код виходу.
        raise SystemExit(subprocess.call(argv))
    os.execv(node, argv)


if __name__ == '__main__':
    main()
