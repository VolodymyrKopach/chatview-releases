#!/usr/bin/env node
// server.cjs: MCP-сервер Logopsis (stdio). ТОНКИЙ місток між асистентом і локальним
// HTTP API застосунку: кожен інструмент це обгортка над ІСНУЮЧИМ ендпоінтом на
// 127.0.0.1:5555. Жодних нових привілеїв, жодної логіки в обхід сервера.
//
// НАВІЩО (specs/chatview-mcp/spec.md). Людина просить «перейменуй цей чат і додай іконку»,
// а асистент відповідає «не бачу такої дії в API»: ендпоінт /api/channel-rename існує з
// давніх пір, але самоопис про нього мовчав. Тепер здатності живуть в одному реєстрі
// (capabilities.json), з якого народжується і цей tools/list, і поле actions у
// /api/project-state.
//
// ЩО СЮДИ НЕ ПОТРАПИТЬ НІКОЛИ: ключі, файли, команди, ВИДАЛЕННЯ (чатів, меседжів,
// помічників), спавн агентів, зміна двигуна. Перелік дозволеного закритий і накритий
// тестом, який падає на будь-який зайвий інструмент.
//
// Запуск: node tools/viz/chat/mcp/server.cjs   (зареєстрований у .mcp.json репозиторію)
// Адреса: LOGOPSIS_MCP_URL або http://127.0.0.1:5555. Нелокальна адреса = відмова
// стартувати: цей місток не для мережі.
'use strict';

const crypto = require('crypto');
const http = require('http');
const { URL } = require('url');
const { toolDefinitions, byName, load } = require('./registry.cjs');
const canvasWidgets = require('./canvas-widgets.cjs');
// Запуск уміння помічника винесений цілком у сусідній модуль: увесь ризик «тут стартує
// процес» зібраний в одному файлі, а місток лишається тонкою обгорткою над HTTP і не
// має ані файлової системи, ані права спавнити (на цьому стоять тести гаджетів і
// повідомлень). Три засуви цього запуску описані там же, у шапці skill-run.cjs.
const skillRun = require('./skill-run.cjs');

// Дзеркалення імен змінних середовища (CHATVIEW_* <-> LOGOPSIS_*) під час ребренду.
// Мусить стояти вище за перше читання process.env у цьому файлі: у власника
// лишились запущені служби і аліаси зі старими іменами. Контракт: brand-env.cjs.
require("../brand-env.cjs")

const SERVER_NAME = 'chatview';
const SERVER_VERSION = '1.0.0';
const DEFAULT_PROTOCOL = '2024-11-05';

// ---- 1. Гейт на локальність -------------------------------------------------
// Не «попередження», а відмова стартувати: місток дає право писати в чужий Logopsis,
// і єдина причина, чому це безпечно, це те, що він фізично не вміє вийти за 127.0.0.1.
const LOCAL_HOSTS = new Set(['127.0.0.1', 'localhost', '::1', '[::1]', '0.0.0.0']);

function resolveBase() {
  const raw = process.env.LOGOPSIS_MCP_URL || 'http://127.0.0.1:5555';
  let url;
  try {
    url = new URL(raw);
  } catch {
    throw new Error(
      `Адреса Logopsis «${raw}» не схожа на URL. Приберіть LOGOPSIS_MCP_URL або вкажіть ` +
      'http://127.0.0.1:5555.');
  }
  if (!LOCAL_HOSTS.has(url.hostname)) {
    throw new Error(
      `MCP Logopsis працює лише з локальним застосунком, а вказано «${url.hostname}». ` +
      'Це навмисне обмеження: місток керує вашим Logopsis і не ходить у мережу. ' +
      'Приберіть LOGOPSIS_MCP_URL або поверніть http://127.0.0.1:5555.');
  }
  return url;
}

let BASE;
try {
  BASE = resolveBase();
} catch (e) {
  process.stderr.write('Logopsis MCP: ' + e.message + '\n');
  process.exit(1);
}

// ---- 2. HTTP до застосунку ---------------------------------------------------
// Людська помилка замість сирого стека: «апка не запущена» це найчастіший стан, і
// асистент має переказати його користувачу, а не показати ECONNREFUSED.
class AppError extends Error {}

function appDownMessage() {
  return `Logopsis не відповідає на ${BASE.origin}. Схоже, застосунок не запущений: ` +
    'відкрийте Logopsis (або підніміть сервер на 5555) і повторіть.';
}

function request(method, path, body) {
  return new Promise((resolve, reject) => {
    const payload = body === undefined ? null : Buffer.from(JSON.stringify(body), 'utf8');
    const req = http.request({
      host: BASE.hostname,
      port: BASE.port || 80,
      path,
      method,
      headers: payload
        ? { 'Content-Type': 'application/json', 'Content-Length': payload.length }
        : {},
      timeout: 30000,
    }, res => {
      const chunks = [];
      res.on('data', c => chunks.push(c));
      res.on('end', () => {
        const text = Buffer.concat(chunks).toString('utf8');
        let parsed = null;
        try { parsed = JSON.parse(text); } catch { /* не JSON: віддамо як текст */ }
        if (res.statusCode >= 400) {
          const why = (parsed && (parsed.error || parsed.hint)) || text.slice(0, 300);
          reject(new AppError(
            `Logopsis відповів помилкою на ${method} ${path}: ${why || res.statusCode}`));
          return;
        }
        resolve(parsed === null ? { raw: text } : parsed);
      });
    });
    req.on('timeout', () => {
      req.destroy();
      reject(new AppError(
        `Logopsis не встиг відповісти за 30 секунд на ${method} ${path}. ` +
        'Застосунок живий, але зайнятий: спробуйте ще раз за хвилину.'));
    });
    req.on('error', err => {
      if (err && (err.code === 'ECONNREFUSED' || err.code === 'EHOSTUNREACH' ||
                  err.code === 'ENOTFOUND' || err.code === 'ECONNRESET')) {
        reject(new AppError(appDownMessage()));
      } else {
        reject(new AppError(`Не вдалось звернутись до Logopsis: ${err.message}`));
      }
    });
    if (payload) req.write(payload);
    req.end();
  });
}

const get = (path) => request('GET', path);

// Мʼяка відмова (HTTP 200 з `ok:false`) це ВІДМОВА, а не результат. Так відповідає,
// наприклад, встановлення чужого помічника, яке вимагає карантину: віддати таке
// як успіх означає сказати «поставив», не поставивши.
const post = async (path, body) => {
  const res = await request('POST', path, body || {});
  if (res && res.ok === false) {
    throw new AppError(
      `Logopsis не виконав ${path}: ${res.error || res.hint || 'причини не назвав'}`);
  }
  return res;
};

const put = async (path, body) => {
  const res = await request('PUT', path, body === undefined ? {} : body);
  if (res && res.ok === false) {
    throw new AppError(
      `Logopsis не виконав ${path}: ${res.error || res.hint || 'причини не назвав'}`);
  }
  return res;
};

// ---- 3. Виконавці інструментів ----------------------------------------------
// Кожен рівно один: тіло дозволених інструментів, нічого поза реєстром.
const need = (args, key) => {
  const v = args && args[key];
  if (v === undefined || v === null || v === '') {
    throw new AppError(`Бракує обовʼязкового параметра «${key}».`);
  }
  return v;
};

// ПРАВИЛО ЧЕСНОСТІ, одне на весь місток (data/logopsis-harness-audit/ergonomics.md).
// Інструмент рапортує ЛИШЕ те, що підтвердило сховище, і НІКОЛИ те, що ми йому
// надіслали. Привід: `canvas_add` рахував результат як довжину власного входу
// (`return {added: shapes.length}`), тимчасом як сервер зберігає лише шейпи з полем
// `id` (server.py:10601) і чесне число віддає полем `persisted`. Виходило
// `{added:1, isError:false}` при порожній канві, і слабка модель рапортувала
// користувачу «готово». Мовчазна брехня про успіх гірша за гучну відмову.
const numberFrom = (res, key) => {
  const v = res && res[key];
  return typeof v === 'number' && isFinite(v) ? v : null;
};

async function chatsList() {
  const reg = await get('/api/channels');
  const items = Array.isArray(reg) ? reg : (reg.channels || []);
  return items
    .filter(c => c && c.id && !c.hidden)
    .map(c => ({ id: c.id, label: c.label || c.id, icon: c.icon || null,
                 pinned: !!c.pinned }));
}

// Пін і розпін це один ендпоінт і одне правило: віримо тому стану, який повернув
// реєстр, а не тому, який ми просили поставити.
async function setPinned(args, want) {
  const id = need(args, 'id');
  const res = await post('/api/channel-pin', { id, pinned: want });
  if (res && res.found === false) throw new AppError(`Чату «${id}» нема в реєстрі.`);
  const now = typeof (res && res.pinned) === 'boolean' ? res.pinned : null;
  if (now !== want) {
    throw new AppError(
      `Logopsis не підтвердив ${want ? 'закріплення' : 'відкріплення'} чату «${id}»: ` +
      `реєстр повернув ${now === null ? 'порожній стан' : (now ? 'закріплено' : 'не закріплено')}. ` +
      'Найімовірніше, такого чату в реєстрі вже нема.');
  }
  return { id, pinned: now };
}

// ── Гаджети (specs/harness-80, К6-К8) ────────────────────────────────────────
// Гаджети будувались саме як міні-апки під керування AI, і при цьому мали одинадцять
// ручок і НУЛЬ інструментів: модель не могла навіть прочитати, які вони є
// (data/logopsis-harness-audit/surface-inventory.md, розділ 3.1).
//
// МЕЖУ ДОЗВОЛЕНОГО ТУТ СТАВИТЬ АВТОР ГАДЖЕТА, І ЦЕ НАВМИСНЕ. Перелік дій закритий
// маніфестом гаджета, а неоголошену дію відхиляє сам сервер (`_gadget_apply_action`).
// Свого білого списку місток НЕ веде: він дублював би цю межу і розходився б з нею на
// першій же правці маніфесту. Наше діло не перевіряти вдруге, а ПОЯСНИТИ відмову, і
// робимо ми це вже після неї, а не замість неї.
async function gadgetInfo(id, full) {
  const res = await get(
    `/api/gadgets?id=${encodeURIComponent(id)}${full ? '&full=1' : ''}`);
  const g = res && res.gadget;
  if (!g) {
    throw new AppError(
      `Logopsis не віддав гаджет «${id}». Перелік наявних дає gadgets_list.`);
  }
  return g;
}

// Відмову сервера («unknown action: X») перекладаємо на мову, якою можна діяти: К9
// вимагає назвати не лише причину, а й дозволену альтернативу. Тому перелік оголошених
// дій читається САМЕ ТУТ, після відмови, і саме з маніфесту, а не з нашої копії.
async function explainRefusedAction(gadgetId, action, err) {
  let info = null;
  try {
    info = await gadgetInfo(gadgetId);
  } catch { /* нижче розберемось: найімовірніше, гаджета просто нема */ }
  if (!info) {
    return `Гаджета «${gadgetId}» нема серед встановлених, тому виконувати «${action}» ` +
      'нема на чому. Перелік наявних гаджетів дає gadgets_list.';
  }
  const names = (info.actions || [])
    .map(a => (typeof a === 'string' ? a : (a && a.name)))
    .filter(Boolean);
  if (!names.includes(action)) {
    return names.length
      ? `Гаджет «${gadgetId}» не оголошував дію «${action}», і сервер її відхилив. ` +
        `Оголошені дії цього гаджета: ${names.join(', ')}. ` +
        'Повторіть gadget_action з однією з них.'
      : `Гаджет «${gadgetId}» не оголосив жодної дії, тому змінити його через ` +
        'gadget_action не можна. Що йому дозволено, вирішує автор гаджета в маніфесті.';
  }
  return `Гаджет «${gadgetId}» оголошує дію «${action}», але вона не виконалась: ` +
    err.message;
}

async function findChat(id) {
  const chats = await chatsList();
  const hit = chats.find(c => c.id === id);
  if (!hit) {
    throw new AppError(
      `Чату «${id}» нема серед відкритих вкладок. Візьміть id зі списку chats_list.`);
  }
  return hit;
}

// ── Повідомлення: моделі нарешті дають ОКО (specs/harness-80) ────────────────
// Розвідка (surface-inventory.md, розділ 3.3) намацала найбільшу асиметрію застосунку:
// вісімнадцять ручок і рівно ОДИН інструмент, і той ПИШЕ. Модель уміла класти картку в
// стрічку і не бачила ані того, що в цій стрічці вже лежить, ані того, що людина щойно
// написала. Тому «нагадай, на чому ми зупинились» вимагало переказу від самої людини.
//
// ГАЗ ЛИШАЄТЬСЯ ЗАКРИТИМ, ВІДКРИТЕ ЛИШЕ ОКО. `/api/send` і `/api/retry` запускають
// ОПЛАЧУВАНИЙ хід: модель, яка вміє писати промпт сама собі, це нескінченний цикл за
// гроші людини. `/api/delete` це видалення. `/api/pull-context` розвідка позначила як
// «по суті читання чужої стрічки», але код каже інше: ручка КРУТИТЬ session-id каналу і
// сіє seed-from у наступний хід, тобто це мутація двигуна. Читати чужу стрічку дає
// messages_read, і робить це без жодного побічного ефекту.

// Найбільша картка, яку не шкода вивалити в контекст цілком. Стрічка вміє носити
// відповіді на сотні кілобайт (бойовий канал це 5.6 МБ на 111 карток), і саме тому
// «прочитай усе» мусить мати названу межу, а не мовчазний обрив.
const MAX_MESSAGE_BYTES = 120000;

const clampInt = (v, lo, hi, dflt) => {
  const n = Number(v);
  if (!Number.isFinite(n)) return dflt;
  return Math.max(lo, Math.min(hi, Math.round(n)));
};

const needMessageId = (args, key) => {
  const raw = need(args, key);
  const n = Number(raw);
  if (!Number.isInteger(n) || n <= 0) {
    throw new AppError(
      `Параметр «${key}» це номер картки у стрічці, ціле число більше нуля, а прийшло ` +
      `«${raw}». Номери показує messages_read.`);
  }
  return n;
};

// Одна картка зі стрічки за номером. `/api/messages` віддає ВІКНО, тому просимо рівно
// одну картку, старішу за наступний номер. Джерело правди тут те саме, що й у читанні
// стрічки, і те саме, яким перевіряється результат після запису: двох різних відповідей
// на питання «що зараз у стрічці» бути не повинно.
async function feedEntry(channel, id) {
  const res = await get(
    `/api/messages?channel=${encodeURIComponent(channel)}&limit=1&before=${id + 1}`);
  if (!res || !Array.isArray(res.messages)) {
    throw new AppError(
      'Logopsis не віддав стрічку каналу (нема поля «messages» у /api/messages). ' +
      'Схоже на застарілу версію застосунку: оновіть її.');
  }
  const hit = res.messages.find(m => m && m.id === id) || null;
  return { entry: hit, total: typeof res.total === 'number' ? res.total : 0 };
}

// Пін це ПЕРЕМИКАЧ (`/api/pin` не приймає бажаного стану, він інвертує наявний), і на
// неіснуючий номер він відповідає ok:true. Дві пастки на одному ендпоінті, тому стан
// читається ДО (щоб другий «запінь» не означав «розпінь») і ПІСЛЯ (щоб «готово» не
// означало «ми попросили»).
async function setMessagePinned(args, want) {
  const channel = String(need(args, 'channel')).trim();
  const id = needMessageId(args, 'id');
  await findChat(channel);
  const { entry, total } = await feedEntry(channel, id);
  if (!entry) {
    throw new AppError(
      `Повідомлення №${id} у чаті «${channel}» нема, а всього в стрічці ${total}. ` +
      'Ендпоінт піна на такий номер однаково відповідає «готово», тому вірити йому не ' +
      'можна: візьміть справжній номер із messages_read і повторіть.');
  }
  if (!!entry.pinned === want) {
    return { channel, id, pinned: want, changed: false,
             note: want ? 'Картка вже була збережена, повторно нічого не робилось.'
                        : 'Картка і так не була збережена, повторно нічого не робилось.' };
  }
  await post('/api/pin', { channel, id });
  const after = (await feedEntry(channel, id)).entry;
  if (!after || !!after.pinned !== want) {
    throw new AppError(
      `Logopsis не підтвердив ${want ? 'збереження' : 'зняття'} картки №${id}: у стрічці ` +
      `після запису вона ${after && after.pinned ? 'збережена' : 'не збережена'}. ` +
      'Повторіть; якщо тримається, індекс каналу переписує щось інше.');
  }
  return { channel, id, pinned: !!after.pinned, changed: true };
}

// ── Медіа в стрічку: контракт `src` перестає виконуватись мовчки ─────────────
// Правило проєкту давнє: у `src` кладеться або https-посилання, або шлях до файла на
// диску, а нормалізатор сам копіює файл у assets/media і переписує посилання. Мовчазною
// лишалась НЕВДАЧА: на мертвий шлях `media_normalize` ставить `srcMissing: true`,
// повідомлення все одно лягає, і `message_post` віддає {ok, messageId}, тобто виглядає
// як успіх. Модель чесно рапортувала «поклав картинку» там, де людина бачила картку
// помилки. Тому тут дві перевірки: розвідка ДО запису (щоб не лишати картку-труп) і
// перечитування покладеної картки ПІСЛЯ (щоб рапортувати адресу зі сховища).
const MEDIA_KINDS = [
  { kind: 'image', exts: ['png', 'jpg', 'jpeg', 'gif', 'webp', 'svg', 'avif', 'bmp'],
    fields: ['title', 'caption'] },
  { kind: 'video', exts: ['mp4', 'mov', 'webm', 'm4v', 'mkv', 'avi'],
    fields: ['title', 'caption', 'poster'] },
  { kind: 'audio', exts: ['mp3', 'wav', 'm4a', 'ogg', 'oga', 'opus', 'aac', 'flac'],
    fields: ['title', 'transcript'] },
];

function mediaExt(src) {
  const clean = String(src).split('#')[0].split('?')[0];
  const base = clean.split(/[\\/]/).pop() || '';
  const dot = base.lastIndexOf('.');
  return dot > 0 ? base.slice(dot + 1).toLowerCase() : '';
}

function mediaKind(src) {
  const ext = mediaExt(src);
  return MEDIA_KINDS.find(k => k.exts.includes(ext)) || null;
}

// Розвідка перед записом: чи дістане браузер це посилання. Відповідає той самий модуль,
// який потім і нормалізує (media_normalize.probe), тому «робочий src» тут і там означає
// одне й те саме.
async function mediaProbe(src, field) {
  const res = await get(`/api/media-resolve?src=${encodeURIComponent(src)}`);
  if (!res || !res.status) {
    throw new AppError(
      'Logopsis не сказав, чи досяжне це медіа (нема поля «status» у ' +
      '/api/media-resolve). Схоже на застарілу версію застосунку: оновіть її.');
  }
  if (res.status === 'missing') {
    throw new AppError(
      `Не покладено нічого: за «${src}» (${field}) на цій машині файла нема. ` +
      'Дайте ПОВНИЙ шлях до файла, напр. /Users/you/Desktop/dokaz.png, або посилання ' +
      'http/https. Шлях відносно репозиторію не годиться ніколи: браузер резолвить ' +
      'його від адреси сторінки, а не від кореня репо, і мовчки отримує 404.');
  }
  return res;
}

// ── Канва: намір замість сирого шейпа tldraw ─────────────────────────────────
// Розвідка довела, що канвою через місток користуватись було неможливо: сторінку
// створити нічим, а шейп мовчки викидався без поля `id`, про яке не сказано ніде.
// Правило цього шматка: модель називає НАМІР (сторінка з назвою; віджет такого типу з
// таким змістом), а все службове (id шейпа, typeName, parentId, index, розміри, файл
// даних) дописує харнес. Знання про устрій tldraw моделі більше не потрібне.

// Один запис у сховище канви на всі канвові інструменти. Правило чесності живе тут
// одне: число доданого це `persisted` зі сховища, недобір це помилка з причиною.
async function addShapesToStore(shapes, pageId) {
  const payload = pageId
    ? shapes.map(s => (s && !s.parentId ? Object.assign({}, s, { parentId: pageId }) : s))
    : shapes;
  const res = await post('/api/canvas/add-shapes', { shapes: payload, pageId });
  const persisted = numberFrom(res, 'persisted');
  if (persisted === null) {
    throw new AppError(
      'Logopsis не сказав, скільки шейпів записав (у відповіді нема «persisted»), тому ' +
      'вважати їх доданими не можна. Схоже на застарілу версію застосунку.');
  }
  if (res.persistError) {
    throw new AppError(
      `Канва записала ${persisted} із ${shapes.length} і повідомила помилку: ` +
      `${res.persistError}`);
  }
  if (persisted < shapes.length) {
    throw new AppError(
      `Записано ${persisted} із ${shapes.length}: решту канва відкинула. Найчастіша ` +
      'причина: шейп із таким «id» на канві вже є, а повторний запис ігнорується. ' +
      'Візьміть нові унікальні id і повторіть.');
  }
  return { persisted, server: res };
}

// Перелік сторінок береться з АВТОРИТЕТНОГО сховища канви (того самого, куди пише
// add-shapes). Раніше він читався з /api/project-state, а той бере жорсткий шлях повз
// CANVAS_DATA_DIR: два джерела правди на одне поняття, і перевірка «сторінка справді
// зʼявилась» на них не будується.
async function canvasPages() {
  const res = await get('/api/canvas/pages');
  const pages = res && Array.isArray(res.pages) ? res.pages : null;
  if (!pages) {
    throw new AppError(
      'Logopsis не віддав перелік сторінок канви (нема поля «pages» у ' +
      '/api/canvas/pages). Схоже на застарілу версію застосунку: оновіть її.');
  }
  return pages.map(p => ({
    id: p.id,
    title: p.title || p.id,
    shapes: typeof p.shapes === 'number' ? p.shapes : 0,
    right: typeof p.right === 'number' ? p.right : 0,
  }));
}

// ── Правка НАЯВНОГО віджета канви (specs/harness-80) ────────────────────────
// Досі модель уміла покласти віджет і не вміла його змінити, тому кожне «онови цифру»
// означало НОВИЙ віджет поруч зі старим. Через десять правок сторінка це десять копій
// одного блока, з яких девʼять брехливі і жодна не позначена застарілою.
//
// ПРАВИЛО ЦЬОГО ШМАТКА: правка ЧАСТКОВА. Зміст живе окремо від шейпа (у файлі
// `/api/data/<dataFile>`), геометрія окремо від змісту (`/api/canvas/update-positions`
// міняє названі числа і не чіпає решти запису). Тому оновлення змісту фізично не може
// зрушити віджет, а переміщення не може зачепити текст: жоден із цих інструментів не
// перезаписує запис шейпа цілком. Заміна обʼєкта цілком виглядала б у відповіді як успіх,
// а на екрані як поїхала верстка, і не одразу.
const WIDGET_SHAPE = 'html-widget';

// Один шейп (або шейпи однієї сторінки) без викачування всього стору: GET /api/canvas
// серіалізує ~2 МБ під замком, і платити цим за кожну правку означало б підвішувати всі
// канвові ручки заради двох чисел.
async function canvasShapes(query) {
  const res = await get('/api/canvas/shapes' + (query || ''));
  const shapes = res && Array.isArray(res.shapes) ? res.shapes : null;
  if (!shapes) {
    throw new AppError(
      'Logopsis не віддав перелік віджетів канви (нема поля «shapes» у ' +
      '/api/canvas/shapes). Схоже на застарілу версію застосунку: оновіть її.');
  }
  return shapes;
}

// К9 живе тут: «такого id нема» без переліку того, що є, лишає модель у тому самому
// глухому куті, з якого вона й прийшла.
async function findWidget(shapeId) {
  const hit = (await canvasShapes(`?id=${encodeURIComponent(shapeId)}`))
    .find(s => s && s.id === shapeId) || null;
  if (!hit) {
    const widgets = (await canvasShapes('')).filter(s => s && s.type === WIDGET_SHAPE);
    const shown = widgets.slice(0, 20)
      .map(s => `${s.id} (${s.widgetType || 'без типу'} на «${s.pageTitle || s.page}»)`)
      .join(', ');
    throw new AppError(
      `Не змінено нічого: віджета «${shapeId}» на канві нема. ` +
      (widgets.length
        ? `Є такі: ${shown}${widgets.length > 20 ? ` і ще ${widgets.length - 20}` : ''}. ` +
          'Візьміть id звідти або з canvas_pages з полем pageId і повторіть'
        : 'На канві поки немає жодного віджета: покладіть його через canvas_widget_add') +
      '.');
  }
  if (hit.type !== WIDGET_SHAPE) {
    throw new AppError(
      `Не змінено нічого: «${shapeId}» це шейп типу «${hit.type}», а не віджет-картка. ` +
      'Сирі шейпи tldraw (geo, text, arrow) кладе canvas_add, у них нема ані типу ' +
      'віджета, ані файла даних, тому правити їх цим інструментом нема чого. Перелік ' +
      'віджетів дає canvas_pages з полем pageId.');
  }
  return hit;
}

// Геометрію міняє ОДНА ручка на два наміри, бо розмір віджета лежить у props, а позиція
// в корені запису, і обидва це та сама часткова правка. Число зміненого беремо зі
// сховища: «updated: 0» при `ok: true` це рівно та мовчазна брехня, з якої почалась ця
// спека.
async function updatePositions(pos, shapeId) {
  const res = await post('/api/canvas/update-positions', { positions: [pos] });
  const updated = numberFrom(res, 'updated');
  if (updated === null) {
    throw new AppError(
      'Logopsis не сказав, скільки віджетів змінив (нема «updated» у ' +
      '/api/canvas/update-positions), тому вважати правку застосованою не можна. ' +
      'Схоже на застарілу версію застосунку.');
  }
  if (updated < 1) {
    const missing = Array.isArray(res.missing) && res.missing.length
      ? ` Сховище назвало зниклим: ${res.missing.join(', ')}.` : '';
    throw new AppError(
      `Не змінено нічого: у момент запису сховище канви не знайшло віджета ` +
      `«${shapeId}».${missing} Перевірте canvas_pages з полем pageId і повторіть.`);
  }
}

// Число з входу: порожнє поле це «не чіпати», а не нуль. Нуль тут значущий (координата 0
// це лівий край), тому відрізняти доводиться явно.
const numArg = (args, key) => {
  const v = args && args[key];
  if (v === undefined || v === null || v === '') return null;
  const n = Number(v);
  if (!Number.isFinite(n)) {
    throw new AppError(`Параметр «${key}» це число, а прийшло «${v}».`);
  }
  return n;
};

// Сторона віджета. Нижня межа не з естетики: віджет на нуль пікселів це віджет, якого
// на екрані нема, тобто «змінив розмір» перетворюється на «загубив блок».
const MIN_SIDE = 20;
const MAX_SIDE = 20000;

function checkSide(key, value) {
  if (value === null) return;
  if (!(value >= MIN_SIDE && value <= MAX_SIDE)) {
    throw new AppError(
      `Не змінено нічого: «${key}» = ${value} це не розмір, який видно на екрані. ` +
      `Сторона віджета це число від ${MIN_SIDE} до ${MAX_SIDE} пікселів.`);
  }
}

const widgetState = (s) => ({
  shapeId: s.id, pageId: s.page, page: s.pageTitle, widgetType: s.widgetType,
  x: s.x, y: s.y, w: s.w, h: s.h,
});


// Порівняння змісту, стійке до порядку ключів: доказ того, що у файлі лежить саме те,
// що прислали, а не те, що ми хотіли покласти.
/**
 * Копія обʼєкта без поля `updated`.
 *
 * Читання-після-запису порівнює те, чим керує КЛІЄНТ. Момент останнього запису ним не
 * керує: сервер сам перебиває `updated` на файлах, які це поле вже несуть (server.cjs
 * і server.py, «Server is authoritative on `updated`»). Без цього зрізу кожен віджет
 * з полем updated повертався з іншим значенням, ніж його прислали, і MCP чесно, але
 * помилково рапортував «зміст не зберігся» та не створював шейп.
 */
function sansUpdated(v) {
  if (!v || typeof v !== 'object' || Array.isArray(v)) return v;
  const out = {};
  for (const k of Object.keys(v)) if (k !== 'updated') out[k] = v[k];
  return out;
}

function stable(v) {
  if (Array.isArray(v)) return '[' + v.map(stable).join(',') + ']';
  if (v && typeof v === 'object') {
    return '{' + Object.keys(v).sort().map(k => JSON.stringify(k) + ':' + stable(v[k])).join(',') + '}';
  }
  return JSON.stringify(v === undefined ? null : v);
}

// ── Памʼять: спільне з обома інструментами читання/запису ────────────────────
// Ті самі значення, що memory_store.py тримає в TYPES і SCOPE_KEYS (S1). Копія тут не
// розходиться з python-стороною доти, доки їх обидві звіряє інтеграційний прогін.
const MEMORY_TYPES = ['user', 'feedback', 'project', 'reference'];
const MEMORY_SCOPE_KEYS = ['user', 'project', 'channel', 'member'];

function memoryScopeArg(args) {
  const raw = args && args.scope;
  if (raw === undefined || raw === null) return {};
  if (typeof raw !== 'object' || Array.isArray(raw)) {
    throw new AppError(
      'Параметр «scope» має бути обʼєктом з полями user/project/channel/member, ' +
      'напр. {"project": "chatview"}.');
  }
  const scope = {};
  for (const k of MEMORY_SCOPE_KEYS) {
    if (raw[k] !== undefined && raw[k] !== null && String(raw[k]).trim() !== '') {
      scope[k] = String(raw[k]).trim();
    }
  }
  return scope;
}

// ── Документ-саммарі: спільне для всіх пʼятьох інструментів ─────────────────
// Обґрунтування дизайну (який шар, чому raw, чому нема повного перезапису) стоїть
// коментарем просто над самими інструментами (HANDLERS.summary_get і нижче), щоб
// читалось разом із кодом, який це рішення виконує.
async function rawGeneration(channel) {
  const gen = await get(`/channels/${encodeURIComponent(channel)}/summary-generation.json`);
  return {
    mode: (gen && gen.mode) || 'none',
    model: gen && gen.model,
    source: (gen && gen.source) || {},
    counted: gen && gen.counted,
    sections: Array.isArray(gen && gen.sections) ? gen.sections : [],
  };
}

// Ключі секцій і пунктів ділять ОДИН простір на весь документ (summary_store.py,
// validate_generation: один `seen`-набір на секції й пункти разом), тому перевірка
// унікальності нового ключа мусить дивитись на обидва рівні одразу.
function usedKeys(gen) {
  const out = new Set();
  for (const s of gen.sections) {
    out.add(String(s.key));
    for (const it of (s.items || [])) out.add(String(it.key));
  }
  return out;
}

// `source`/`model`/`counted` переносяться З ПОТОЧНОЇ raw-генерації БЕЗ змін: це
// метадані фонового генератора (К15/К18/К19 — lastMessageId, incrementalCount,
// скільки карток враховано), і хірургічна правка інструментом MCP не мусить їх
// чіпати. Якби ми лишали їх порожніми, наступне відкриття каналу побачило б
// lastMessageId:0 і вважало б документ застарілим відносно КОЖНОГО повідомлення,
// яке вже було враховано.
async function postSummaryGenerate(channel, sections, prevGen) {
  const body = {
    channel, op: 'generate', sections,
    mode: prevGen.mode && prevGen.mode !== 'none' ? prevGen.mode : 'full',
    source: prevGen.source, model: prevGen.model, counted: prevGen.counted,
  };
  const res = await request('POST', '/api/summary', body);
  if (!res || res.ok === false) {
    // server.py:_summary_failure кладе ЛЮДСЬКИЙ текст у `hint`, а короткий код
    // ("summary_bad_request") у `error` — навпаки, ніж у більшості інших ручок
    // застосунку, де `error` вже і є те речення. Тому тут пріоритет свідомо
    // зворотний до спільного post()/put() вище: hint першим, інакше замість
    // причини («ключ пункту «X» не унікальний») асистент побачив би голий код.
    throw new AppError(
      (res && (res.hint || res.error)) || 'Logopsis не підтвердив запис саммарі.');
  }
  if (!res.generation || !Array.isArray(res.generation.sections)) {
    throw new AppError(
      'Logopsis не повернув записану генерацію (нема «generation.sections» у ' +
      'відповіді /api/summary), тому вважати запис підтвердженим не можна.');
  }
  return res;
}

const HANDLERS = {
  chats_list: () => chatsList(),

  chat_rename: async (args) => {
    const id = need(args, 'id');
    const label = String(need(args, 'label')).trim();
    const before = (await findChat(id)).label;
    const res = await post('/api/channel-rename', { id, label });
    if (res && res.found === false) {
      throw new AppError(`Чат «${id}» зник із реєстру, перейменування не застосоване.`);
    }
    // Перечитуємо реєстр. У відповіді ендпоінта `label` це відлуння нашого ж запиту,
    // тобто доказом що завгодно, тільки не тим, як тепер зветься вкладка.
    const after = (await findChat(id)).label;
    if (after !== label) {
      throw new AppError(
        `Перейменування не збереглось: у реєстрі досі «${after}», а не «${label}». ` +
        'Повторіть; якщо тримається, вкладку перезаписує інший запис реєстру.');
    }
    return { id, before, label: after, changed: before !== after };
  },

  // Іконка йде тим самим ендпоінтом, що й назва (label там обовʼязковий), тому
  // спершу читаємо поточну назву і повертаємо її незмінною. Це не «своя логіка»:
  // це виконання контракту /api/channel-rename без вигадування нового.
  chat_set_icon: async (args) => {
    const id = need(args, 'id');
    const icon = String(need(args, 'icon')).trim();
    const chat = await findChat(id);
    await post('/api/channel-rename', { id, label: chat.label, icon });
    const after = await findChat(id);
    if ((after.icon || '') !== icon) {
      throw new AppError(
        `Іконка не збереглась: у реєстрі досі ${after.icon ? `«${after.icon}»` : 'порожньо'}. ` +
        'Перевірте, що це одне емодзі, і повторіть.');
    }
    return { id, label: after.label, before: chat.icon, icon: after.icon };
  },

  chat_pin: (args) => setPinned(args, true),

  chat_unpin: (args) => setPinned(args, false),

  chat_create: async (args) => {
    const label = String(need(args, 'label')).trim();
    const body = { label };
    if (args.icon) body.icon = String(args.icon).trim();
    const res = await post('/api/channel-create', body);
    const id = res && res.id ? String(res.id) : null;
    if (!id) {
      throw new AppError(
        'Logopsis не повернув id створеного чату, тому вважати його створеним не можна. ' +
        'Перевірте chats_list: якщо вкладки там нема, повторіть створення.');
    }
    // Віддаємо ПРОЧИТАНЕ з реєстру, а не переказ власного запиту: інакше «створено»
    // означало б лише «ми попросили створити».
    const made = (await chatsList()).find(c => c.id === id);
    if (!made) {
      throw new AppError(
        `Logopsis відповів id «${id}», але такої вкладки в реєстрі нема: чат не створений.`);
    }
    return { id: made.id, label: made.label, icon: made.icon };
  },

  plan_get: async (args) => {
    const channel = String(need(args, 'channel'));
    const plan = await get(`/channels/${encodeURIComponent(channel)}/plan.json`);
    const steps = Array.isArray(plan && plan.steps) ? plan.steps : [];
    return {
      channel,
      goal: (plan && plan.goal) || null,
      done: steps.filter(s => s && s.state === 'done').length,
      total: steps.length,
      plan: plan || {},
    };
  },

  plan_update: async (args) => {
    const channel = String(need(args, 'channel'));
    const plan = need(args, 'plan');
    if (typeof plan !== 'object' || Array.isArray(plan)) {
      throw new AppError('Параметр «plan» має бути обʼєктом {goal, steps:[...]}.');
    }
    const res = await post('/api/plan-update', { channel, plan });
    // `done` і `total` рахуються вже ПІСЛЯ злиття зі збереженим планом, тобто це
    // стан сховища. Немає їх у відповіді, немає й підтвердження, що план записано.
    if (numberFrom(res, 'total') === null) {
      throw new AppError(
        `Logopsis не підтвердив запис плану каналу «${channel}» (у відповіді нема ` +
        'кількості кроків). Перечитайте план через plan_get і повторіть.');
    }
    return res;
  },

  // ── Робочий аркуш (chat-268) ────────────────────────────────────────────────
  // Чистовик сесії. Усі пʼять інструментів ходять в ОДНУ ручку /api/worksheet, бо вся
  // валідація живе у worksheet_store.apply_op: тут не місце другій копії правил, яка
  // згодом розійдеться з першою.
  //
  // Правило чесності (див. numberFrom вище) тримається тим самим прийомом, що й скрізь:
  // повертаємо `block` із ВІДПОВІДІ сервера, тобто те, що реально записалось, а не
  // відлуння власного запиту.
  worksheet_get: async (args) => {
    const channel = String(need(args, 'channel'));
    const doc = await get(`/channels/${encodeURIComponent(channel)}/worksheet.json`);
    const blocks = Array.isArray(doc && doc.blocks) ? doc.blocks : [];
    return {
      channel,
      title: (doc && doc.title) || null,
      rev: (doc && doc.rev) || 0,
      // Історію віддаємо ЛІЧИЛЬНИКОМ, не тілом. Аркуш із десятком доопрацьованих блоків
      // інакше приїхав би в контекст удесятеро більшим за самі висновки, а саме проти
      // цього фіча й існує: показати чисте, а не весь журнал спроб.
      blocks: blocks.map(b => ({
        id: b.id, title: b.title, widgets: b.widgets,
        rev: b.rev, updated: b.updated,
        versions: Array.isArray(b.history) ? b.history.length : 0,
      })),
      archived: Array.isArray(doc && doc.archived) ? doc.archived.length : 0,
    };
  },

  worksheet_append: async (args) => {
    const channel = String(need(args, 'channel'));
    const title = String(need(args, 'title'));
    const widgets = need(args, 'widgets');
    if (!Array.isArray(widgets) || widgets.length === 0) {
      throw new AppError('Параметр «widgets» має бути непорожнім масивом віджетів.');
    }
    const body = { channel, op: 'append', title, widgets };
    if (args.source) body.source = args.source;
    const res = await post('/api/worksheet', body);
    if (!res || !res.block || !res.block.id) {
      throw new AppError(
        'Logopsis не повернув id блока, тому вважати його покладеним на аркуш не можна. ' +
        'Перечитайте аркуш через worksheet_get і повторіть.');
    }
    return { channel, block: res.block, blocks: res.summary && res.summary.blocks };
  },

  worksheet_update: async (args) => {
    const channel = String(need(args, 'channel'));
    const id = String(need(args, 'id'));
    if (args.title === undefined && args.widgets === undefined) {
      throw new AppError(
        'Нема що міняти: передайте «title», «widgets» або обидва. ' +
        'Щоб додати НОВИЙ етап, беріть worksheet_append, а не оновлення чужого блока.');
    }
    const body = { channel, op: 'update', id };
    if (args.title !== undefined) body.title = String(args.title);
    if (args.widgets !== undefined) {
      if (!Array.isArray(args.widgets) || args.widgets.length === 0) {
        throw new AppError('Параметр «widgets» має бути непорожнім масивом віджетів.');
      }
      body.widgets = args.widgets;
    }
    if (args.reason) body.reason = String(args.reason);
    // Необовʼязкова оптимістична перевірка. Модель бере її, коли править ЧУЖИЙ текст:
    // тоді свіжіша правка людини не затирається, а виклик чесно падає з причиною.
    if (args.baseRev !== undefined && args.baseRev !== null) body.baseRev = Number(args.baseRev);
    const res = await post('/api/worksheet', body);
    const block = res && res.block;
    // rev мусив зрости, інакше запис не відбувся, хай навіть відповідь виглядає бадьоро.
    if (!block || numberFrom(block, 'rev') === null || block.rev < 2) {
      throw new AppError(
        `Logopsis не підтвердив запис блока «${id}»: у відповіді нема нової версії. ` +
        'Перечитайте аркуш через worksheet_get і повторіть.');
    }
    return { channel, block, versions: Array.isArray(block.history) ? block.history.length : 0 };
  },

  // Назва саме «archive», а не «remove»: у містку НЕМА інструментів зі словом видалення
  // в назві (tests/integration/test_mcp_registry.py), і це правило старше за цю фічу.
  // Тут воно ще й точніше описує дію: блок їде вбік разом зі своєю історією, звідки
  // його повертають одним кліком.
  worksheet_archive: async (args) => {
    const channel = String(need(args, 'channel'));
    const id = String(need(args, 'id'));
    const res = await post('/api/worksheet', { channel, op: 'archive', id });
    if (!res || !res.block) {
      throw new AppError(`Logopsis не підтвердив, що блок «${id}» прибрано з аркуша.`);
    }
    return { channel, block: res.block, restorable: true };
  },

  worksheet_title: async (args) => {
    const channel = String(need(args, 'channel'));
    const title = String(need(args, 'title')).trim();
    const res = await post('/api/worksheet', { channel, op: 'title', title });
    const after = res && res.doc && res.doc.title;
    if (after !== title) {
      throw new AppError(
        `Назва аркуша не збереглась: у сховищі досі ${after ? `«${after}»` : 'порожньо'}.`);
    }
    return { channel, title: after };
  },

  // ── Документ-саммарі (specs/chat-summary, К39) ───────────────────────────────
  // Пʼять інструментів на ОДНУ ручку /api/summary, той самий дух, що в аркуша: вся
  // валідація живе у summary_store.apply_op/validate_generation, тут не місце другій
  // копії правил.
  //
  // ЯКИЙ ШАР ПИШЕ КОЖЕН ІНСТРУМЕНТ (задача явно просила це продумати, не мовчки
  // обрати). Документ має два неперетинні шари (specs/chat-summary, розділ 4.2):
  // `generation` це шар машини, `overlay` це шар людини (список патчів), і жодна
  // операція не сміє писати в обидва. Усі чотири мутуючі інструменти нижче пишуть у
  // GENERATION, включно з summary_section_archive, і ось чому:
  //   1. К39 дослівно про асистента, що САМ кладе зміст у документ інструментами —
  //      тобто це машина, яка веде свій же шар, а не людина, що клацає в UI.
  //      Ручний edit-in-place (клік людини в текст, К22-К26/К40-К41) це ІНША, вже
  //      заскопована фаза на фронті, і туди ці інструменти не лізуть.
  //   2. У самого summary_store НЕМА overlay-операції рівня "сховати цілу секцію":
  //      `hide` (PATCH_OPS) адресує лише ОДИН пункт (`target.item`), а `order`
  //      переставляє пункти ВСЕРЕДИНІ секції, не самі секції. Додати таку операцію
  //      означало б редагувати summary_store.py, а ця задача це прямо забороняє
  //      (над ним паралельно працює інший агент). Писати "прибирання секції" в
  //      overlay без цієї операції фізично нема як.
  //   3. Втрату при цьому не робимо: `write_generation` сам штовхає ПОПЕРЕДНЮ
  //      generation у `doc.history` (до 5 версій, summary_store.py) на КОЖЕН запис,
  //      тобто прибрана секція лишається читною там же, де К6 і так це гарантує.
  //
  // РУЧКИ "ПЕРЕПИСАТИ ДОКУМЕНТ ЦІЛКОМ" В ІНТЕРФЕЙСІ НЕМА (те саме правило, що для
  // аркуша, specs/chatview-mcp розділ 7). `/api/summary` з `op:"generate"` дійсно
  // приймає `sections` цілком — так і мусить бути, бо ним керує фонова перегенерація
  // (К6) — але ЖОДЕН інструмент нижче не бере такого поля на вхід (звірено тестом
  // test_no_summary_tool_accepts_a_whole_sections_tree). Кожен читає ПОТОЧНИЙ сирий
  // шар сам (rawGeneration), міняє РІВНО ту секцію чи той пункт, який назвали в
  // аргументах, і лише тоді шле повний масив назад. Асистент пʼятнадцятого виклику
  // фізично не має параметра, яким стер би висновок пʼятого.
  //
  // ЧОМУ RAW, А НЕ /channels/<ch>/summary.json (те, чим живиться summary_get): та
  // ручка віддає ЗІБРАНИЙ документ, generation+overlay РАЗОМ. Якби мутуючі
  // інструменти брали його за основу для наступного generate, вони тихо записали б
  // людські патчі (set/insert/hide) назад у generation як "факт від машини" — рівно
  // те, що К5 забороняє. Тому мутації йдуть через нову тонку ручку
  // /channels/<ch>/summary-generation.json (server.py, лише summary_store.read_doc,
  // нового коду в summary_store.py нуль).
  summary_get: async (args) => {
    const channel = String(need(args, 'channel'));
    const doc = await get(`/channels/${encodeURIComponent(channel)}/summary.json`);
    const sections = Array.isArray(doc && doc.sections) ? doc.sections : [];
    return {
      channel,
      genRev: (doc && doc.genRev) || 0,
      mode: (doc && doc.mode) || null,
      sections: sections.map(s => ({
        key: s.key, title: s.title || null,
        items: (s.items || []).map(it => ({
          key: it.key, title: it.title || null, widgets: it.widgets || [],
        })),
      })),
      conflicts: (doc && doc.conflicts) || [],
      orphans: (doc && doc.orphans) || [],
      freshness: (doc && doc.freshness) || null,
    };
  },

  summary_section_add: async (args) => {
    const channel = String(need(args, 'channel'));
    const key = String(need(args, 'key')).trim();
    const items = need(args, 'items');
    if (!Array.isArray(items) || items.length === 0) {
      throw new AppError(
        'Параметр «items» має бути непорожнім масивом пунктів (кожен: {key, widgets}).');
    }
    for (const it of items) {
      if (!it || typeof it !== 'object' || !it.key) {
        throw new AppError('Кожен пункт секції мусить мати «key».');
      }
      if (!Array.isArray(it.widgets) || it.widgets.length === 0) {
        throw new AppError(`Пункт «${it.key}»: «widgets» має бути непорожнім масивом віджетів.`);
      }
    }
    const gen = await rawGeneration(channel);
    const used = usedKeys(gen);
    if (used.has(key)) {
      throw new AppError(
        `Ключ секції «${key}» вже зайнятий у документі (ключі секцій і пунктів ` +
        `спільні на весь документ). Наявні: ${[...used].slice(0, 30).join(', ')}.`);
    }
    used.add(key);
    for (const it of items) {
      const ik = String(it.key);
      if (used.has(ik)) {
        throw new AppError(`Ключ пункту «${ik}» вже зайнятий у документі. Візьміть інший.`);
      }
      used.add(ik);
    }
    const newSection = {
      key,
      ...(args.title !== undefined ? { title: String(args.title) } : {}),
      items: items.map(it => ({
        key: String(it.key),
        ...(it.title !== undefined ? { title: String(it.title) } : {}),
        widgets: it.widgets,
      })),
    };
    const res = await postSummaryGenerate(channel, [...gen.sections, newSection], gen);
    const saved = (res.generation.sections || []).find(s => s.key === key);
    if (!saved) {
      throw new AppError(
        `Секцію «${key}» надіслано, але в записаній генерації її нема. Перечитайте ` +
        'summary_get і повторіть.');
    }
    return { channel, section: saved, sections: (res.generation.sections || []).length };
  },

  summary_node_update: async (args) => {
    const channel = String(need(args, 'channel'));
    const sectionKey = String(need(args, 'section'));
    const itemKey = String(need(args, 'key'));
    if (args.title === undefined && args.widgets === undefined) {
      throw new AppError('Нема що міняти: передайте «title», «widgets» або обидва.');
    }
    if (args.widgets !== undefined
        && (!Array.isArray(args.widgets) || args.widgets.length === 0)) {
      throw new AppError('Параметр «widgets» має бути непорожнім масивом віджетів.');
    }
    const gen = await rawGeneration(channel);
    const section = gen.sections.find(s => String(s.key) === sectionKey);
    if (!section) {
      const keys = gen.sections.map(s => s.key).join(', ') || '(секцій нема)';
      throw new AppError(`Секції «${sectionKey}» у документі нема. Наявні: ${keys}.`);
    }
    const items = section.items || [];
    const idx = items.findIndex(it => String(it.key) === itemKey);
    if (idx < 0) {
      const keys = items.map(it => it.key).join(', ') || '(пунктів нема)';
      throw new AppError(
        `Пункту «${itemKey}» у секції «${sectionKey}» нема. Наявні: ${keys}. Щоб додати ` +
        'новий пункт, кладіть його новою секцією через summary_section_add.');
    }
    const updated = { ...items[idx] };
    delete updated.hash; // перерахує сховище на запису; старий хеш тут нічий не якір
    if (args.title !== undefined) updated.title = String(args.title);
    if (args.widgets !== undefined) updated.widgets = args.widgets;
    const newItems = items.slice();
    newItems[idx] = updated;
    const sections = gen.sections.map(
      s => (String(s.key) === sectionKey ? { ...s, items: newItems } : s));
    const res = await postSummaryGenerate(channel, sections, gen);
    const savedSection = (res.generation.sections || []).find(s => s.key === sectionKey);
    const savedItem = savedSection && (savedSection.items || []).find(it => it.key === itemKey);
    if (!savedItem) {
      throw new AppError(
        `Запис пройшов, але пункт «${itemKey}» у збереженій генерації не знайдено. ` +
        'Перечитайте summary_get.');
    }
    return { channel, section: sectionKey, item: savedItem };
  },

  summary_reorder: async (args) => {
    const channel = String(need(args, 'channel'));
    const order = need(args, 'order');
    if (!Array.isArray(order) || order.length === 0) {
      throw new AppError('Параметр «order» має бути непорожнім масивом ключів наявних секцій.');
    }
    const gen = await rawGeneration(channel);
    const currentKeys = gen.sections.map(s => String(s.key));
    const wantKeys = order.map(String);
    const sameSet = currentKeys.length === wantKeys.length
      && new Set(wantKeys).size === wantKeys.length
      && currentKeys.every(k => wantKeys.includes(k));
    if (!sameSet) {
      throw new AppError(
        '«order» мусить містити РІВНО ті ключі секцій, що вже є в документі, без ' +
        `додавання чи пропуску. Наявні: ${currentKeys.join(', ')}. Прислано: ` +
        `${wantKeys.join(', ')}.`);
    }
    const byKey = new Map(gen.sections.map(s => [String(s.key), s]));
    const sections = wantKeys.map(k => byKey.get(k));
    const res = await postSummaryGenerate(channel, sections, gen);
    const savedOrder = (res.generation.sections || []).map(s => s.key);
    if (savedOrder.join('|') !== wantKeys.join('|')) {
      throw new AppError(
        'Порядок надіслано, але збережений порядок секцій інший. Перечитайте summary_get.');
    }
    return { channel, order: savedOrder };
  },

  // Назва саме «archive», а не «remove»: те саме правило, що вже діє для аркуша
  // (worksheet_archive вище) — у містку нема інструментів зі словом видалення в
  // назві. Тут воно ще й чесне: секція не зникає безслідно, а лишається в
  // doc.history (К6, до 5 останніх генерацій), звідки її видно, хай і не одним
  // кліком, як з аркушем.
  summary_section_archive: async (args) => {
    const channel = String(need(args, 'channel'));
    const key = String(need(args, 'key'));
    const gen = await rawGeneration(channel);
    const idx = gen.sections.findIndex(s => String(s.key) === key);
    if (idx < 0) {
      const keys = gen.sections.map(s => s.key).join(', ') || '(секцій нема)';
      throw new AppError(`Секції «${key}» у документі нема. Наявні: ${keys}.`);
    }
    if (gen.sections.length === 1) {
      throw new AppError(
        `«${key}» це остання секція документа: порожній документ generate не приймає. ` +
        'Додайте іншу секцію перед тим, як прибирати цю.');
    }
    const archivedTitle = gen.sections[idx].title || null;
    const sections = gen.sections.filter((_, i) => i !== idx);
    const res = await postSummaryGenerate(channel, sections, gen);
    const stillThere = (res.generation.sections || []).some(s => s.key === key);
    if (stillThere) {
      throw new AppError(`Секцію «${key}» надіслано на прибирання, але вона досі в документі.`);
    }
    return {
      channel, archived: { key, title: archivedTitle },
      sections: (res.generation.sections || []).length,
      recoverable: 'у doc.history (до 5 останніх генерацій)',
    };
  },

  message_post: async (args) => {
    const channel = String(need(args, 'channel'));
    const widgets = need(args, 'widgets');
    if (!Array.isArray(widgets) || widgets.length === 0) {
      throw new AppError('Параметр «widgets» має бути непорожнім масивом віджетів.');
    }
    const body = { channel, widgets };
    if (args.from) body.from = String(args.from);
    if (args.tag) body.tag = String(args.tag);
    const res = await post('/api/message-post', body);
    if (!res || !res.messageId) {
      throw new AppError(
        'Logopsis не повернув id картки, тому вважати повідомлення покладеним не можна. ' +
        'Перевірте, що такий канал є (chats_list), і повторіть.');
    }
    return { channel, messageId: res.messageId, widgets: res.widgets };
  },

  canvas_pages: async (args) => {
    const pages = (await canvasPages())
      .map(p => ({ id: p.id, title: p.title, shapes: p.shapes }));
    const pageId = args && args.pageId ? String(args.pageId).trim() : '';
    if (!pageId) return pages;
    // Id віджетів на вимогу, а не завжди: без них правити наявний віджет неможливо в
    // новій сесії (id з canvas_widget_add лишився в попередній), а з ними на кожен
    // перелік сторінок їхало б до сотні рядків, яких ніхто не просив.
    const page = pages.find(p => p.id === pageId);
    if (!page) {
      const shown = pages.slice(0, 20).map(p => `${p.id} («${p.title}»)`).join(', ');
      throw new AppError(
        `Сторінки «${pageId}» на канві нема. ` +
        (pages.length ? `Є такі: ${shown}. ` : 'На канві поки немає жодної сторінки. ') +
        'Викличте canvas_pages без параметрів, щоб побачити всі.');
    }
    page.widgets = (await canvasShapes(`?page=${encodeURIComponent(pageId)}`))
      .filter(s => s && s.type === WIDGET_SHAPE)
      .map(s => ({ shapeId: s.id, widgetType: s.widgetType,
                   x: s.x, y: s.y, w: s.w, h: s.h }));
    return pages;
  },

  canvas_page_create: async (args) => {
    const title = String(need(args, 'title')).trim();
    const res = await post('/api/canvas/add-page', { title });
    const id = res && res.id ? String(res.id) : null;
    if (!id) {
      throw new AppError(
        'Logopsis не повернув id створеної сторінки, тому вважати її створеною не можна. ' +
        'Перевірте canvas_pages: якщо сторінки там нема, повторіть створення.');
    }
    // Перечитуємо перелік ПІСЛЯ запису: «створено» мусить означати «знайдено у
    // сховищі», а не «ми попросили створити».
    const pages = await canvasPages();
    const made = pages.find(p => p.id === id);
    if (!made) {
      throw new AppError(
        `Logopsis відповів id «${id}», але такої сторінки в переліку канви нема: ` +
        'сторінка не створена. Повторіть виклик.');
    }
    return { id: made.id, title: made.title, pagesTotal: pages.length };
  },

  canvas_widget_types: (args) => {
    const all = canvasWidgets.widgetTypes();
    const q = args && args.q ? String(args.q).trim().toLowerCase() : '';
    const list = q
      ? all.filter(w => w.type.toLowerCase().includes(q) ||
                        String(w.label || '').toLowerCase().includes(q))
      : all;
    return { total: all.length, matched: list.length, types: list };
  },

  // К5. Вхід: сторінка, тип віджета, дані. Усе інше дописується тут.
  canvas_widget_add: async (args) => {
    const pageId = String(need(args, 'pageId')).trim();
    const widgetType = String(need(args, 'widgetType')).trim();
    const data = need(args, 'data');
    if (typeof data !== 'object' || Array.isArray(data)) {
      throw new AppError(
        'Параметр «data» має бути обʼєктом зі змістом віджета, наприклад ' +
        '{"updated":"2026-08-15","html":"<b>Текст</b>"} для eq-html.');
    }

    // 1. Тип. Перевіряємо ДО запису і по живому реєстру рендерера: типу, якого фронт
    // не знає, він малює як «Unknown widget», тобто «поклав» на екрані порожньо.
    const known = canvasWidgets.byType();
    const def = known.get(widgetType);
    if (!def) {
      const near = canvasWidgets.nearest(widgetType, 8);
      throw new AppError(
        `Не покладено нічого: типу віджета «${widgetType}» на канві не існує. ` +
        (near.length ? `Найближчі за назвою: ${near.join(', ')}. ` : '') +
        `Повний перелік (${known.size} типів) віддає canvas_widget_types: візьміть ` +
        'тип звідти і повторіть.');
    }

    // 2. Сторінка. Шейп із вигаданим parentId сховище приймало мовчки, і він лежав
    // під неіснуючою сторінкою назавжди, не показуючись ніколи.
    const pages = await canvasPages();
    const page = pages.find(p => p.id === pageId);
    if (!page) {
      const shown = pages.slice(0, 20).map(p => `${p.id} («${p.title}»)`).join(', ');
      throw new AppError(
        `Не покладено нічого: сторінки «${pageId}» на канві нема. ` +
        (pages.length
          ? `Є такі: ${shown}${pages.length > 20 ? ` і ще ${pages.length - 20}` : ''}. ` +
            'Візьміть id із canvas_pages'
          : 'На канві поки немає жодної сторінки. Створіть її через canvas_page_create') +
        ' і повторіть.');
    }

    // 3. Службове. Зміст віджета канви живе не в шейпі, а у файлі, який рендерер тягне
    // окремим запитом /api/data/<dataFile>, тому спершу кладемо зміст: шейп, що
    // показує на неіснуючий файл, малює картку помилки.
    const slug = widgetType.replace(/[^a-zA-Z0-9]+/g, '-').replace(/^-|-$/g, '') || 'widget';
    const dataFile = `mcp-${slug}-${crypto.randomBytes(4).toString('hex')}`;
    const shapeId = `shape:${dataFile}`;
    await put(`/api/data/${dataFile}`, data);
    const back = await get(`/api/data/${dataFile}`);
    if (stable(sansUpdated(back)) !== stable(sansUpdated(data))) {
      throw new AppError(
        `Зміст віджета не зберігся: файл «${dataFile}» після запису читається інакше, ` +
        'ніж його прислали, тому шейп не створювався. Повторіть виклик.');
    }

    const w = Number.isFinite(args.w) ? Number(args.w) : def.w;
    const h = Number.isFinite(args.h) ? Number(args.h) : def.h;
    // Праворуч від усього, що вже є на сторінці: віджет, покладений поверх чужого,
    // для користувача виглядає так само, як не покладений зовсім.
    const x = Number.isFinite(args.x) ? Number(args.x)
      : (page.shapes ? Math.round(page.right) + 40 : 0);
    const y = Number.isFinite(args.y) ? Number(args.y) : 0;

    await addShapesToStore([{
      id: shapeId,
      type: 'html-widget',
      x, y,
      parentId: pageId,
      props: { w, h, widgetType, dataFile, collapsed: false, expandedH: h },
    }], pageId);

    // 4. Стан ПІСЛЯ запису, перечитаний зі сховища.
    const after = await canvasPages();
    const now = after.find(p => p.id === pageId);
    if (!now || now.shapes <= page.shapes) {
      throw new AppError(
        `Канва підтвердила запис, але сторінка «${pageId}» після нього показує ` +
        `${now ? now.shapes : 0} віджетів замість ${page.shapes + 1}. Вважати віджет ` +
        'покладеним не можна: перевірте canvas_pages і повторіть.');
    }
    return { shapeId, pageId, page: now.title, widgetType, dataFile,
             x, y, w, h, shapesOnPage: now.shapes };
  },

  // Зміст віджета лежить у файлі, а не в шейпі, тому оновлення змісту фізично не
  // торкається ані позиції, ані розміру, ані порядку. Геометрію у відповіді все одно
  // перечитуємо зі сховища ПІСЛЯ запису: сказати «не зрушило» з даних, прочитаних ДО
  // правки, означало б доводити тезу тим самим, що й перевіряємо.
  canvas_widget_update: async (args) => {
    const shapeId = String(need(args, 'shapeId')).trim();
    const data = need(args, 'data');
    if (typeof data !== 'object' || Array.isArray(data)) {
      throw new AppError(
        'Параметр «data» має бути обʼєктом зі змістом віджета, наприклад ' +
        '{"html":"<b>Текст</b>"} для eq-html.');
    }
    const replace = args.replace === true;
    const before = await findWidget(shapeId);
    const dataFile = before.dataFile;
    // Імʼя файла сервер зачищає до [a-zA-Z0-9_-] (server.py, /api/data/<file>), тож
    // «майже підходяще» імʼя писало б і читало РІЗНІ файли, а виглядало б як успіх.
    if (typeof dataFile !== 'string' || !/^[a-zA-Z0-9_-]+$/.test(dataFile)) {
      throw new AppError(
        `Не змінено нічого: у віджета «${shapeId}» нема придатного файла даних ` +
        `(props.dataFile = ${JSON.stringify(dataFile)}), тому міняти зміст нема де. ` +
        'Такий віджет кладеться заново через canvas_widget_add.');
    }
    let current = {};
    try {
      current = await get(`/api/data/${dataFile}`);
    } catch (e) {
      // Файла ще нема (шейп показує на порожнє місце і малює картку помилки): тоді це
      // не злиття, а перше заповнення, і мовчати про це не треба.
      if (!(e instanceof AppError)) throw e;
      current = {};
    }
    if (!current || typeof current !== 'object' || Array.isArray(current)) current = {};
    const next = replace ? Object.assign({}, data) : Object.assign({}, current, data);
    await put(`/api/data/${dataFile}`, next);
    const back = await get(`/api/data/${dataFile}`);
    if (stable(sansUpdated(back)) !== stable(sansUpdated(next))) {
      throw new AppError(
        `Зміст віджета не оновився: файл «${dataFile}» після запису читається інакше, ` +
        'ніж його прислали. Повторіть виклик; якщо тримається, у цей файл пише щось іще.');
    }
    const after = await findWidget(shapeId);
    return Object.assign(widgetState(after), {
      dataFile, replaced: replace,
      dataKeys: Object.keys(back), dataBytes: JSON.stringify(back).length,
    });
  },

  canvas_widget_move: async (args) => {
    const shapeId = String(need(args, 'shapeId')).trim();
    const x = numArg(args, 'x');
    const y = numArg(args, 'y');
    if (x === null && y === null) {
      throw new AppError(
        'Не змінено нічого: не сказано, куди рухати. Дайте «x», «y» або обидва; ' +
        'та координата, якої нема у виклику, лишається як була. Де віджет стоїть ' +
        'зараз, показує canvas_pages з полем pageId.');
    }
    const before = await findWidget(shapeId);
    const pos = { id: shapeId };
    if (x !== null) pos.x = x;
    if (y !== null) pos.y = y;
    await updatePositions(pos, shapeId);
    const after = await findWidget(shapeId);
    const wantX = x === null ? before.x : x;
    const wantY = y === null ? before.y : y;
    if (after.x !== wantX || after.y !== wantY) {
      throw new AppError(
        `Канва підтвердила запис, але віджет «${shapeId}» після нього стоїть у ` +
        `(${after.x}, ${after.y}) замість (${wantX}, ${wantY}). Вважати його ` +
        'пересунутим не можна: повторіть виклик.');
    }
    return Object.assign(widgetState(after), { before: { x: before.x, y: before.y } });
  },

  canvas_widget_resize: async (args) => {
    const shapeId = String(need(args, 'shapeId')).trim();
    const w = numArg(args, 'w');
    const h = numArg(args, 'h');
    if (w === null && h === null) {
      throw new AppError(
        'Не змінено нічого: не сказано, якого розміру. Дайте «w», «h» або обидва; ' +
        'та сторона, якої нема у виклику, лишається як була. Який розмір зараз, ' +
        'показує canvas_pages з полем pageId.');
    }
    checkSide('w', w);
    checkSide('h', h);
    const before = await findWidget(shapeId);
    const pos = { id: shapeId };
    let note = null;
    if (w !== null) pos.w = w;
    if (h !== null) {
      // `expandedH` це висота, до якої віджет повертається після згортання
      // (HtmlWidgetShape.tsx). Лишити її старою означає, що людина згортає віджет,
      // розгортає і бачить стрибок назад до розміру, який щойно міняли.
      pos.expandedH = h;
      if (before.collapsed) {
        note = 'Віджет зараз згорнутий, і згорнутому висоту тримає його заголовок, ' +
          'тому нова висота лягла на розгорнутий стан: людина побачить її, щойно ' +
          'розгорне картку.';
      } else {
        pos.h = h;
      }
    }
    await updatePositions(pos, shapeId);
    const after = await findWidget(shapeId);
    const wantW = w === null ? before.w : w;
    const wantH = (h === null || before.collapsed) ? before.h : h;
    if (after.w !== wantW || after.h !== wantH) {
      throw new AppError(
        `Канва підтвердила запис, але віджет «${shapeId}» після нього має розмір ` +
        `${after.w}x${after.h} замість ${wantW}x${wantH}. Вважати розмір зміненим не ` +
        'можна: повторіть виклик.');
    }
    return Object.assign(widgetState(after),
                         { before: { w: before.w, h: before.h }, note });
  },

  canvas_add: async (args) => {
    const shapes = need(args, 'shapes');
    if (!Array.isArray(shapes) || shapes.length === 0) {
      throw new AppError('Параметр «shapes» має бути непорожнім масивом.');
    }
    // Сервер зберігає ЛИШЕ шейпи з полем `id` (server.py:10601), решту мовчки
    // викидає. Ловимо це ДО запису: так канва не лишається напівзаповненою, а
    // відповідь називає рівно те поле, якого бракує.
    const noId = [];
    shapes.forEach((s, i) => {
      const id = s && typeof s === 'object' ? s.id : null;
      if (typeof id !== 'string' || !id.trim()) noId.push(i);
    });
    if (noId.length) {
      throw new AppError(
        `Не додано нічого: у шейпів ${noId.join(', ')} (нумерація з нуля) нема поля «id», ` +
        'а канва зберігає лише шейпи з id. Дайте кожному власний рядковий id виду ' +
        '«shape:коротка-унікальна-назва» і повторіть.');
    }
    const pageId = args.pageId ? String(args.pageId) : null;
    const { persisted, server } = await addShapesToStore(shapes, pageId);
    return { added: persisted, pageId, server };
  },

  helpers_list: async (args) => {
    const data = await get('/api/helpers');
    const skills = data.skills || [];
    const installed = skills.filter(s => s.installed)
      .map(s => ({ id: s.id, name: s.name }));
    // Перелік запускного їде разом із каталогом навмисне: інакше єдиний спосіб
    // дізнатись, що дозволено, це напоротись на відмову, тобто та сама вітрина,
    // тільки з охоронцем на дверях.
    const runnable = skillRun.runnable();
    if (args && args.installedOnly) {
      return { installed, runnable, corpusTotal: data.corpusTotal };
    }
    return {
      installed,
      available: skills.filter(s => !s.installed)
        .map(s => ({ id: s.id, name: s.name, remote: !!s.remote })),
      runnable,
      corpusTotal: data.corpusTotal,
    };
  },

  // Відмова модуля запуску це вже готовий людський текст із наступною дією (К9), тому
  // сюди вона доїжджає дослівно, а не загорнутою в «не вдалось виконати».
  helper_run: async (args) => {
    const id = String(need(args, 'id')).trim();
    const skill = String(need(args, 'skill')).trim();
    try {
      return await skillRun.run(id, skill, args.params);
    } catch (e) {
      if (e instanceof skillRun.SkillRunError) throw new AppError(e.message);
      throw e;
    }
  },

  helper_install: async (args) => {
    const id = String(need(args, 'id'));
    return post('/api/helpers/install', { id });
  },

  // Створення помічника з нуля. Тонка обгортка НАВМИСНЕ: уся валідація, атомарність
  // і відкіт живуть у helper_store.py за одним ендпоінтом, тому MCP, HTTP і CLI не
  // можуть розійтись у поведінці. Щойно тут зʼявилась би власна перевірка імені або
  // власний порядок кроків, ми отримали б дві правди про те, що таке «створено».
  helper_create: async (args) => {
    return post('/api/helpers/create', {
      name: String(need(args, 'name')),
      title: String(need(args, 'title')),
      description: String(need(args, 'description')),
      body: String(need(args, 'body')),
      cat: args && args.cat ? String(args.cat) : undefined,
      icon: args && args.icon ? String(args.icon) : undefined,
      // Приватність за замовчуванням: false ставиться лише коли його ЯВНО передали.
      // Правило власника (2026-09-12): усі помічники персональні, поки не сказано інше.
      private: args && args.private === false ? false : true,
    });
  },

  helper_verify: async (args) => {
    return post('/api/helpers/verify', { name: String(need(args, 'name')) });
  },

  skills_search: async (args) => {
    const q = String(need(args, 'q'));
    const limit = Math.max(1, Math.min(30, Number(args.limit) || 8));
    return get(`/api/helpers/search?q=${encodeURIComponent(q)}&limit=${limit}`);
  },

  work_list: async () => {
    const [agents, jobs] = await Promise.all([
      get('/api/agents-all'),
      get('/api/jobs?all=1'),
    ]);
    return {
      agents: (agents && agents.items) || [],
      jobs: (jobs && (jobs.items || jobs.jobs)) || [],
    };
  },

  project_state: () => get('/api/project-state'),

  // ── Гаджети ────────────────────────────────────────────────────────────────
  gadgets_list: async () => {
    const res = await get('/api/gadgets');
    const gadgets = Array.isArray(res && res.gadgets) ? res.gadgets : [];
    return { total: gadgets.length, gadgets, note: (res && res.note) || null };
  },

  gadget_state: (args) => gadgetInfo(String(need(args, 'id')).trim(), true),

  // Тіло ОДНОЇ бестпрактики гаджета (specs/gadget-skills, К2). Виконавець тут
  // обовʼязковий, а не «за бажанням»: гейт нижче (реєстр == виконавці) валить весь
  // місток на старті, щойно в capabilities.json зʼявляється інструмент без пари.
  //
  // Вузько НАВМИСНО: один гаджет, один slug, ніяких переліків. Описові інструменти
  // віддають лише індекс (slug, опис, умова вмикання), і саме тому індекс лишається
  // дешевим; тіло приїжджає рівно тоді, коли модель вирішила, що воно до діла.
  gadget_skill: async (args) => {
    const gadgetId = String(need(args, 'gadgetId')).trim();
    const slug = String(need(args, 'slug')).trim();
    const res = await get(`/api/gadget-skill?gadgetId=${encodeURIComponent(gadgetId)}` +
      `&slug=${encodeURIComponent(slug)}`);
    return {
      gadgetId, slug,
      name: res.name || slug,
      description: res.description || '',
      when: res.when || '',
      scope: res.scope || 'gadget',
      bytes: typeof res.bytes === 'number' ? res.bytes : null,
      content: res.content || '',
    };
  },

  gadget_action: async (args) => {
    const gadgetId = String(need(args, 'gadgetId')).trim();
    const action = String(need(args, 'action')).trim();
    const params = args.params;
    if (params !== undefined && params !== null &&
        (typeof params !== 'object' || Array.isArray(params))) {
      throw new AppError(
        'Параметр «params» має бути обʼєктом, напр. {"value": 3}. Які параметри бере ' +
        `дія «${action}», видно в gadget_state.`);
    }
    try {
      await post('/api/gadget-action', { gadgetId, action, params: params || {} });
    } catch (e) {
      if (!(e instanceof AppError)) throw e;
      throw new AppError(await explainRefusedAction(gadgetId, action, e));
    }
    // Стан ПЕРЕЧИТУЄМО зі сховища, а не переказуємо відповідь на власний запис: те саме
    // правило чесності, що й на решті містка. Дія, яка нічого не змінила, має бути
    // видима як «нічого не змінилось», а не як «зроблено».
    const after = await gadgetInfo(gadgetId);
    return { gadgetId, action, state: after.state, stateBytes: after.stateBytes };
  },

  // Відкат останньої дії (specs/gadget-mcp-hardening, К4). Виконавець тут обовʼязковий,
  // а не «за бажанням»: гейт вище (реєстр == виконавці) валить весь місток на старті,
  // щойно в capabilities.json зʼявляється інструмент без пари в цьому обʼєкті.
  gadget_undo: async (args) => {
    const gadgetId = String(need(args, 'gadgetId')).trim();
    const res = await post('/api/gadget-undo', { gadgetId });
    // Те саме правило чесності, що й на gadget_action: стан беремо зі сховища ПІСЛЯ
    // запису, а не переказуємо власний запит.
    const after = await gadgetInfo(gadgetId);
    return {
      gadgetId,
      undone: res.undone || null,
      changes: res.changes || [],
      remaining: typeof res.remaining === 'number' ? res.remaining : null,
      state: after.state,
      stateBytes: after.stateBytes,
    };
  },

  gadget_create: async (args) => {
    const description = String(need(args, 'description')).trim();
    if (!description) {
      throw new AppError(
        'Параметр «description» порожній. Опишіть словами, що гаджет має показувати і ' +
        'які в нього кнопки, напр. «лічильник склянок води з ціллю 8, кнопка +1».');
    }
    // Канал це не прикраса, а ВИБІР ДВИГУНА. Конструктор будує гаджет тим самим
    // двигуном і тим самим рівнем, що відповідають у цьому каналі, тож без `channel`
    // збірка поїде глобальним дефолтом застосунку, а не тим, що людина щойно обрала
    // в поповері. Необовʼязковий він лише тому, що є виклики поза каналом (лаунчер).
    const channel = args && args.channel ? String(args.channel).trim() : '';
    let res;
    try {
      res = await post('/api/gadget-build', channel ? { description, channel } : { description });
    } catch (e) {
      if (!(e instanceof AppError)) throw e;
      // Конструктор працює на моделі, тому найчастіша причина відмови це не опис, а
      // відсутній ключ. Назвати її прямо дешевше, ніж дати переписувати опис намарно.
      throw new AppError(/LLM/i.test(e.message)
        ? `${e.message}. Конструктор гаджетів працює на моделі: перевірте ключ Gemini ` +
          'або OpenAI у ⚙ Налаштування Logopsis і повторіть.'
        : `${e.message}. Опишіть гаджет конкретніше: що показувати, які кнопки і що ` +
          'вони міняють.');
    }
    const id = res && res.gadget && res.gadget.id ? String(res.gadget.id) : null;
    if (!id) {
      throw new AppError(
        'Logopsis не повернув id створеного гаджета, тому вважати його створеним не ' +
        'можна. Перевірте gadgets_list: якщо гаджета там нема, повторіть створення.');
    }
    // «Створено» має означати «лежить у застосунку», а не «ми попросили створити».
    const made = await gadgetInfo(id);
    const g = res.gadget || {};
    // Хто саме зібрав гаджет, їде у відповідь ЗАВЖДИ, а заміна двигуна ще й окремим
    // реченням. Та сама угода, що в резолвері рівнів: тиха заміна виглядає як «модель
    // дурна», і саме через неї слабкий конструктор жив непоміченим.
    const built = g.builtBy ? { builtBy: g.builtBy } : {};
    if (g.fallback) {
      built.engineFallback =
        `Двигун каналу не поїхав (${g.fallbackReason || 'причина не названа'}), ` +
        `гаджет зібрано запасним ${g.builtBy || 'шляхом'}. Скажіть про це користувачу: ` +
        'на своєму двигуні результат був би іншим.';
    }
    return {
      id: made.id, name: made.name, icon: made.icon,
      actions: made.actions, state: made.state, ...built,
      next: `Щоб користувач побачив гаджет, викличте gadget_open з id «${made.id}».`,
    };
  },

  gadget_open: async (args) => {
    const id = String(need(args, 'id')).trim();
    let res;
    try {
      res = await post('/api/app-open', { appId: id });
    } catch (e) {
      if (!(e instanceof AppError)) throw e;
      throw new AppError(
        `Гаджет «${id}» не відкрився: ${e.message}. Звірте id зі gadgets_list: ` +
        'колонкою відкривається лише той гаджет, що справді лежить у застосунку.');
    }
    const channelId = res && res.id ? String(res.id) : null;
    if (!channelId) {
      throw new AppError(
        `Logopsis не сказав, яка колонка відкрилась для гаджета «${id}», тому вважати ` +
        'його відкритим не можна. Перевірте chats_list і повторіть.');
    }
    // Колонка це вкладка в реєстрі каналів. Немає її там, немає й відкриття.
    const chat = (await chatsList()).find(c => c.id === channelId);
    if (!chat) {
      throw new AppError(
        `Logopsis відповів колонкою «${channelId}», але такої вкладки в реєстрі нема: ` +
        'гаджет не відкритий.');
    }
    return { gadgetId: id, channelId: chat.id, label: chat.label };
  },

  // ── Повідомлення ───────────────────────────────────────────────────────────
  messages_read: async (args) => {
    const channel = String(need(args, 'channel')).trim();
    // Канал звіряємо з РЕЄСТРОМ, а не з наявністю теки: chatsList відкидає приховані
    // вкладки, а приховане людині не варто читати й моделі (не-ціль спеки).
    await findChat(channel);
    const limit = clampInt(args.limit, 1, 100, 20);
    let path = `/api/messages?channel=${encodeURIComponent(channel)}&limit=${limit}`;
    if (args.before !== undefined && args.before !== null && args.before !== '') {
      path += `&before=${needMessageId(args, 'before')}`;
    }
    const res = await get(path);
    if (!res || !Array.isArray(res.messages)) {
      throw new AppError(
        'Logopsis не віддав стрічку каналу (нема поля «messages» у /api/messages). ' +
        'Схоже на застарілу версію застосунку: оновіть її.');
    }
    return { channel, total: res.total, shown: res.messages.length,
             messages: res.messages,
             note: res.total > res.messages.length
               ? `Показано ${res.messages.length} останніх із ${res.total}. Старіші ` +
                 `бере той самий messages_read з полем «before».`
               : null };
  },

  message_read: async (args) => {
    const channel = String(need(args, 'channel')).trim();
    const id = needMessageId(args, 'id');
    await findChat(channel);
    const { entry, total } = await feedEntry(channel, id);
    if (!entry) {
      throw new AppError(
        `Повідомлення №${id} у чаті «${channel}» нема, а всього в стрічці ${total}. ` +
        'Наявні номери показує messages_read.');
    }
    if (typeof entry.bytes === 'number' && entry.bytes > MAX_MESSAGE_BYTES) {
      throw new AppError(
        `Картка №${id} важить ${entry.bytes} байтів, а цілком віддаються лише до ` +
        `${MAX_MESSAGE_BYTES}. Така відповідь зайняла б вікно контексту і не лишила ` +
        'місця на роботу. Її переказ уже є в messages_read, і там же видно, з яких ' +
        'віджетів вона складається.');
    }
    const widgets = await get(
      `/channels/${encodeURIComponent(channel)}/${encodeURIComponent(entry.file)}`);
    if (!Array.isArray(widgets)) {
      throw new AppError(
        `Файл картки №${id} («${entry.file}») прочитався не як список віджетів. ` +
        'Схоже, повідомлення на диску пошкоджене: подивіться його переказ у messages_read.');
    }
    return { channel, id, from: entry.from, timestamp: entry.timestamp,
             tag: entry.tag, pinned: entry.pinned, bytes: entry.bytes, widgets };
  },

  messages_pinned: async (args) => {
    const channel = args && args.channel ? String(args.channel).trim() : '';
    if (channel) await findChat(channel);
    const res = await get('/api/pinned' +
      (channel ? `?channel=${encodeURIComponent(channel)}` : ''));
    const items = Array.isArray(res && res.items) ? res.items : [];
    return { channel: channel || null, total: items.length, messages: items };
  },

  message_pin: (args) => setMessagePinned(args, true),

  message_unpin: (args) => setMessagePinned(args, false),

  channel_events: async (args) => {
    const channel = String(need(args, 'channel')).trim();
    await findChat(channel);
    const limit = clampInt(args.limit, 1, 100, 30);
    const res = await get(`/api/events?channel=${encodeURIComponent(channel)}`);
    const items = Array.isArray(res && res.items) ? res.items : [];
    const tail = items.slice(-limit);
    return { channel, total: items.length, shown: tail.length, events: tail };
  },

  // ── Медіа-бібліотека ───────────────────────────────────────────────────────
  library_list: async () => {
    let lib;
    try {
      lib = await get('/api/library');
    } catch (e) {
      if (!(e instanceof AppError)) throw e;
      throw new AppError(
        `Каталог медіа-бібліотеки не читається: ${e.message}. Бібліотека зʼявляється ` +
        'після того, як у Logopsis підключили теку з відео, і доти каталогу просто ' +
        'нема, тому показувати нічого.');
    }
    const cats = (lib && lib.categories) || {};
    const categories = Object.keys(cats).map(key => {
      const c = cats[key] || {};
      const files = Array.isArray(c.files) ? c.files : [];
      return { key, label: c.label || key, route: c.route || null,
               count: files.length, files };
    });
    // Рахуємо ПО СПИСКАХ, а не беремо оголошене поле `total`: воно записане людиною
    // при склейці каталогу і розходиться з реальністю мовчки. Розбіжність не ховаємо,
    // а показуємо окремим полем.
    const counted = categories.reduce((n, c) => n + c.count, 0);
    const declared = typeof (lib && lib.total) === 'number' ? lib.total : null;
    return {
      total: counted,
      declaredTotal: declared !== null && declared !== counted ? declared : undefined,
      sourceFolder: (lib && lib.source_folder) || null,
      // Каталог склеюється на тій машині, де лежать самі файли, і подорожує разом із
      // чужим шляхом. Сказати «є N відео» і змовчати, що жодного з них тут нема,
      // означає підготувати наступну брехню, бо модель піде класти їх у стрічку.
      sourceFolderPresent: !!(lib && lib.source_folder_present),
      note: (lib && lib.note) || null,
      categories,
    };
  },

  media_post: async (args) => {
    const channel = String(need(args, 'channel')).trim();
    const src = String(need(args, 'src')).trim();
    await findChat(channel);

    // 1. Що це за медіа. Тип віджета бере на себе харнес: модель називає файл.
    const kind = mediaKind(src);
    if (!kind) {
      const ext = mediaExt(src);
      throw new AppError(
        `Не покладено нічого: ${ext ? `за розширенням «.${ext}»` : 'без розширення у назві'} ` +
        'не видно, що це за медіа. Інлайн у стрічку лягають картинка (' +
        `${MEDIA_KINDS[0].exts.join(', ')}), відео (${MEDIA_KINDS[1].exts.join(', ')}) ` +
        `і аудіо (${MEDIA_KINDS[2].exts.join(', ')}). Документ (pdf, docx, zip) так ` +
        'покласти не можна: віджет файлу в Logopsis малює власний текст і посилання на ' +
        'диск не читає, тому картка вийшла б порожньою. Документ віддають людині ' +
        'вкладенням через поле вводу чату.');
    }

    // 2. Поля, яких цей віджет не показує, мовчки не ковтаємо: «додав розшифровку» до
    // картинки це та сама тиха брехня, тільки дрібніша.
    const extra = ['title', 'caption', 'transcript', 'poster'].filter(f =>
      args[f] !== undefined && args[f] !== null && String(args[f]).trim() !== '' &&
      !kind.fields.includes(f));
    if (extra.length) {
      throw new AppError(
        `Не покладено нічого: віджет «${kind.kind}» не показує ` +
        `${extra.map(f => `«${f}»`).join(', ')}. Для цього типу лишаються: ` +
        `${kind.fields.join(', ')}.`);
    }

    // 3. Розвідка ДО запису: інакше в стрічці залишиться картка з битим посиланням, а
    // відповідь виглядатиме як успіх.
    const probe = await mediaProbe(src, 'src');
    if (args.poster) await mediaProbe(String(args.poster).trim(), 'poster');

    const widget = { type: kind.kind, src };
    for (const f of kind.fields) {
      if (args[f] !== undefined && args[f] !== null && String(args[f]).trim() !== '') {
        widget[f] = String(args[f]);
      }
    }
    const res = await post('/api/message-post', { channel, widgets: [widget] });
    const messageId = res && res.messageId;
    if (!messageId) {
      throw new AppError(
        'Logopsis не повернув id картки, тому вважати медіа покладеним не можна. ' +
        'Перевірте messages_read і повторіть.');
    }

    // 4. Стан ПІСЛЯ запису. Адресу рапортуємо ТУ, що лежить у сховищі: нормалізатор
    // переписує шлях з диска на /assets/media/<хеш>-імʼя, і саме її відкриє браузер.
    const { entry } = await feedEntry(channel, messageId);
    if (!entry) {
      throw new AppError(
        `Logopsis відповів карткою №${messageId}, але у стрічці каналу «${channel}» її ` +
        'нема: медіа не покладено. Повторіть виклик.');
    }
    const stored = await get(
      `/channels/${encodeURIComponent(channel)}/${encodeURIComponent(entry.file)}`);
    const w = Array.isArray(stored) ? stored[0] : null;
    if (!w || typeof w.src !== 'string' || !w.src) {
      throw new AppError(
        `Картка №${messageId} лягла у стрічку без посилання на медіа, тому показати ` +
        'вона нічого не покаже. Повторіть виклик.');
    }
    if (w.srcMissing) {
      throw new AppError(
        `Картка №${messageId} лягла, але Logopsis позначив «${src}» як недосяжний, ` +
        'і в стрічці людина побачить помітну картку помилки замість медіа. Дайте ' +
        'ПОВНИЙ шлях до наявного файла або посилання http/https і повторіть.');
    }
    return { channel, messageId, kind: kind.kind, src: w.src, srcBefore: src,
             copied: w.src !== src, bytes: probe.bytes || null };
  },

  // ── Памʼять (specs/user-memory-v2, S4) ───────────────────────────────────────
  // Чотири наміри: записати факт, знайти, показати історію версій, показати стан
  // сховища. ВИДАЛЕННЯ ТУТ НЕМА: спроба покликати щось на кшталт memory_delete падає
  // в generic-відмову нижче (гейт «інструмента нема»), а forbidden у capabilities.json
  // прямо називає, хто має право стирати (не-ціль спеки: видаляє людина в застосунку).
  memory_write: async (args) => {
    const description = String(need(args, 'description')).trim();
    if (description.includes('\n') || description.includes('\r')) {
      throw new AppError(
        'Параметр «description» мусить бути ОДНОрядковим: перенесення рядка туди не ' +
        'кладуть, деталі йдуть у «body».');
    }
    const type = args.type ? String(args.type).trim() : 'project';
    if (!MEMORY_TYPES.includes(type)) {
      throw new AppError(
        `Параметр «type» мусить бути одним з: ${MEMORY_TYPES.join(', ')}, а прийшло ` +
        `«${type}».`);
    }
    const body = args.body !== undefined && args.body !== null ? String(args.body) : '';
    const scope = memoryScopeArg(args);
    const res = await post('/api/memory/add',
      { description, body, type, scope, origin: 'said', source: 'mcp' });
    const id = res && res.id ? String(res.id) : null;
    if (!id) {
      throw new AppError(
        'Logopsis не повернув id записаного факту, тому вважати його записаним не ' +
        'можна. Перевірте memory_search і повторіть.');
    }
    // Перечитуємо сховище ОКРЕМИМ запитом, а не переказ відповіді POST: «записано» це
    // те, що лежить у файлі, а не те, що сервер сказав «ok».
    const board = await get('/api/memory');
    const facts = Array.isArray(board && board.facts) ? board.facts : [];
    const saved = facts.find(f => f && f.id === id);
    if (!saved) {
      throw new AppError(
        `Logopsis відповів id «${id}», але в сховищі памʼяті такого запису нема: факт ` +
        'не записався. Повторіть виклик.');
    }
    if (saved.description !== description) {
      throw new AppError(
        `Факт «${id}» ліг на диск, але опис там («${saved.description}») відрізняється ` +
        `від надісланого («${description}»). Повторіть виклик.`);
    }
    return { id: saved.id, description: saved.description, type: saved.type,
             key: saved.key, scope: saved.scope, tier: saved.tier, status: saved.status };
  },

  memory_search: async (args) => {
    const q = args && args.q !== undefined && args.q !== null ? String(args.q).trim() : '';
    const scope = memoryScopeArg(args);
    const limit = clampInt(args && args.limit, 1, 50, 12);
    const params = new URLSearchParams();
    if (q) params.set('q', q);
    for (const k of MEMORY_SCOPE_KEYS) {
      if (scope[k]) params.set(`scope.${k}`, scope[k]);
    }
    params.set('limit', String(limit));
    const res = await get(`/api/memory/search?${params.toString()}`);
    if (!res || !Array.isArray(res.matches)) {
      throw new AppError(
        'Logopsis не віддав результат пошуку (нема поля «matches» у ' +
        '/api/memory/search). Схоже на застарілу версію застосунку: оновіть її.');
    }
    return {
      query: q, total: res.matches.length,
      matches: res.matches.map(f => ({
        id: f.id, description: f.description, body: f.body, type: f.type, key: f.key,
        tier: f.tier, status: f.status, scope: f.scope, date: f.date, origin: f.origin,
        conflict: !!f.conflict, verify: !!f.verify,
      })),
    };
  },

  memory_history: async (args) => {
    const id = String(need(args, 'id')).trim();
    const res = await get(`/api/memory/history?id=${encodeURIComponent(id)}`);
    if (!res || !Array.isArray(res.versions)) {
      throw new AppError(
        'Logopsis не віддав історію факту (нема поля «versions» у ' +
        '/api/memory/history). Схоже на застарілу версію застосунку: оновіть її.');
    }
    return {
      id, key: res.key,
      versions: res.versions.map(v => ({
        id: v.id, description: v.description, body: v.body, date: v.date,
        origin: v.origin, source: v.source, active: !!v.active,
        valid_to: v.valid_to || null, superseded_by: v.superseded_by || null,
      })),
    };
  },

  memory_state: async () => {
    const board = await get('/api/memory');
    if (!board || !Array.isArray(board.facts)) {
      throw new AppError(
        'Logopsis не віддав стан памʼяті (нема поля «facts» у /api/memory). Схоже на ' +
        'застарілу версію застосунку: оновіть її.');
    }
    const byTier = { core: 0, archive: 0 };
    const byStatus = { active: 0, pending: 0 };
    const byType = { user: 0, feedback: 0, project: 0, reference: 0 };
    const core = [];
    for (const f of board.facts) {
      if (byTier[f.tier] !== undefined) byTier[f.tier] += 1;
      if (byStatus[f.status] !== undefined) byStatus[f.status] += 1;
      if (byType[f.type] !== undefined) byType[f.type] += 1;
      if (f.tier === 'core') {
        core.push({ id: f.id, description: f.description, type: f.type });
      }
    }
    return {
      total: board.total, bytes: board.bytes, byTier, byStatus, byType,
      conflicts: Array.isArray(board.conflicts) ? board.conflicts.length : 0,
      core, projects: Array.isArray(board.projects) ? board.projects.length : 0,
    };
  },
};

// ---- 4. Гейт на перелік ------------------------------------------------------
// Реєстр і виконавці мають збігатись рівно. Розбіжність це або мертвий інструмент у
// списку, або живий інструмент поза реєстром: обидва варіанти отруйні, тому падаємо
// на старті, а не тихо працюємо наполовину.
const REGISTRY = byName();
{
  const declared = [...REGISTRY.keys()].sort().join(',');
  const implemented = Object.keys(HANDLERS).sort().join(',');
  if (declared !== implemented) {
    process.stderr.write(
      'Logopsis MCP: реєстр і виконавці розійшлись.\n  у реєстрі: ' + declared +
      '\n  у коді:    ' + implemented + '\n');
    process.exit(1);
  }
}

function refusal(name) {
  const allowed = [...REGISTRY.keys()].join(', ');
  const forbidden = (load().forbidden || []).join('; ');
  return `Інструмента «${name}» у Logopsis MCP нема і не буде. Дозволено лише: ${allowed}. ` +
    `Свідомо не даємо: ${forbidden}.`;
}

// ---- 5. JSON-RPC по stdio ----------------------------------------------------
function send(msg) {
  process.stdout.write(JSON.stringify(msg) + '\n');
}

function result(id, value) { send({ jsonrpc: '2.0', id, result: value }); }
function error(id, code, message) { send({ jsonrpc: '2.0', id, error: { code, message } }); }

function textResult(id, value, isError) {
  const text = typeof value === 'string' ? value : JSON.stringify(value, null, 2);
  result(id, { content: [{ type: 'text', text }], isError: !!isError });
}

async function handle(msg) {
  const { id, method, params } = msg;
  const isNotification = id === undefined || id === null;

  if (method === 'initialize') {
    const want = params && params.protocolVersion;
    result(id, {
      protocolVersion: typeof want === 'string' ? want : DEFAULT_PROTOCOL,
      capabilities: { tools: { listChanged: false } },
      serverInfo: { name: SERVER_NAME, version: SERVER_VERSION },
    });
    return;
  }
  if (method === 'notifications/initialized' || method === 'initialized') return;
  if (method === 'ping') { if (!isNotification) result(id, {}); return; }
  if (method === 'tools/list') { result(id, { tools: toolDefinitions() }); return; }

  if (method === 'tools/call') {
    const name = params && params.name;
    const args = (params && params.arguments) || {};
    const fn = HANDLERS[name];
    // Заборонене (чи просто неіснуюче) відмовляється ВГОЛОС, з причиною: мовчазне
    // «нічого не сталось» це те, від чого ця спека і починалась.
    if (!fn) { textResult(id, refusal(name), true); return; }
    try {
      textResult(id, await fn(args), false);
    } catch (e) {
      const human = e instanceof AppError ? e.message
        : `Не вдалось виконати «${name}»: ${e.message}`;
      textResult(id, human, true);
    }
    return;
  }

  if (!isNotification) error(id, -32601, `Метод «${method}» не підтримується`);
}

// Виходимо лише тоді, коли ВІДПОВІЛИ на все, що встигли прийняти. Без цього лічильника
// клієнт, який закриває stdin одразу після запиту (а так робить будь-який пакетний
// виклик), гасив процес до того, як HTTP-відповідь застосунку встигала перетворитись на
// tools/call result: назовні це виглядало як мовчання замість помилки.
let pending = 0;
let stdinClosed = false;
let chain = Promise.resolve();
function maybeExit() {
  if (!stdinClosed || pending !== 0) return;
  // І ЛИШЕ ТОДІ, КОЛИ ВІДПОВІДЬ СПРАВДІ ВИЙШЛА. У канал (pipe) влазить 64 КБ, решту
  // `write()` лишає у власній черзі, а `process.exit()` цю чергу ВИКИДАЄ: заміряно
  // рівно 65536 байтів із 200001. Назовні це виглядало як мовчання замість відповіді,
  // причому тим частіше, чим більше даних просили. Ловиться на gadget_state великого
  // гаджета (бойовий `today` це 198 КБ стану).
  if (process.stdout.writableLength === 0) process.exit(0);
  else process.stdout.once('drain', () => process.exit(0));
}

let buffer = '';
process.stdin.setEncoding('utf8');
process.stdin.on('data', chunk => {
  buffer += chunk;
  let nl;
  while ((nl = buffer.indexOf('\n')) >= 0) {
    const line = buffer.slice(0, nl).trim();
    buffer = buffer.slice(nl + 1);
    if (!line) continue;
    let msg;
    try {
      msg = JSON.parse(line);
    } catch {
      error(null, -32700, 'Некоректний JSON');
      continue;
    }
    pending += 1;
    // ПО ЧЕРЗІ, а не паралельно. Заміряно на живому :5555: rename і set_icon,
    // відправлені одним пакетом, обидва читають реєстр каналів, обидва пишуть його
    // цілком, і зміна того, хто закінчив першим, зникає (іконка поїхала назад).
    // Черга коштує нічого: інструменти тут короткі, а загублена правка виглядає для
    // користувача як «місток збрехав, що зробив».
    chain = chain
      .then(() => handle(msg))
      .catch(e => {
        if (msg && msg.id !== undefined && msg.id !== null) {
          error(msg.id, -32603, String(e && e.message || e));
        }
      })
      .finally(() => { pending -= 1; maybeExit(); });
  }
});
process.stdin.on('end', () => { stdinClosed = true; maybeExit(); });
