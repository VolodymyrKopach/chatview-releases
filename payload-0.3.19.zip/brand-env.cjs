// ПЕРЕЇЗД ЗМІННИХ СЕРЕДОВИЩА ПІД НОВУ НАЗВУ ПРОДУКТУ (CHATVIEW_* -> LOGOPSIS_*).
//
// Рідний брат `brand_env.py`: той самий контракт, та сама механіка, лише мовою містків,
// хуків і скриптів запуску. Повний опис причин лежить у пітонівському файлі, тут коротко.
//
// КОНТРАКТ. Читаємо `LOGOPSIS_X` першою, `CHATVIEW_X` лишається запасним джерелом
// назавжди. Реалізовано ДЗЕРКАЛЕННЯМ: якщо стоїть лише одне з імен, друге дописується з
// тим самим значенням; якщо стоять обидва, не чіпаємо жодного, тому виграє те, яке читає
// код, а код читає нове.
//
// Чому дзеркалення, а не обгортка над кожним читанням. Хуки і містки запускаються
// десятками окремих процесів, і кожен з них успадковує середовище батька. Дозеркалене
// один раз середовище лікує одразу весь ланцюг: і місце, яке ще читає старим іменем, і
// дочірній процес, який ми не контролюємо.

const NEW_PREFIX = "LOGOPSIS_"
const OLD_PREFIX = "CHATVIEW_"

/** `CHATVIEW_HOME` -> `LOGOPSIS_HOME`. Чуже ім'я повертається як є. */
function newName(name) {
  return name.startsWith(OLD_PREFIX) ? NEW_PREFIX + name.slice(OLD_PREFIX.length) : name
}

/** `LOGOPSIS_HOME` -> `CHATVIEW_HOME`. Чуже ім'я повертається як є. */
function oldName(name) {
  return name.startsWith(NEW_PREFIX) ? OLD_PREFIX + name.slice(NEW_PREFIX.length) : name
}

/** Дозеркалити середовище на місці. Повертає кількість дописаних імен. */
function mirror(env) {
  const target = env || process.env
  let added = 0
  for (const name of Object.keys(target)) {
    let twin
    if (name.startsWith(OLD_PREFIX)) twin = newName(name)
    else if (name.startsWith(NEW_PREFIX)) twin = oldName(name)
    else continue
    if (target[twin] === undefined) {
      target[twin] = target[name]
      added++
    }
  }
  return added
}

/** Явне читання «нова, потім стара» для словників, які прийшли ззовні недзеркаленими. */
function get(name, fallback, env) {
  const src = env || process.env
  const fresh = src[newName(name)]
  if (fresh !== undefined) return fresh
  const legacy = src[oldName(name)]
  if (legacy !== undefined) return legacy
  return fallback
}

/** Виставити змінну ОБОМА іменами: дитина, яка читає старим, теж мусить її побачити. */
function put(name, value, env) {
  const target = env || process.env
  target[newName(name)] = value
  target[oldName(name)] = value
  return target
}

// Дзеркалимо на вимозі модуля, тому `require("./brand-env.cjs")` першим рядком досить.
mirror()

module.exports = { NEW_PREFIX, OLD_PREFIX, newName, oldName, mirror, get, put }
