"""project_state.py: ONE read-only snapshot of the Logopsis ecosystem.

So any chat (via runner system-prompt injection, Phase B) and the UI (via
/api/project-state) know what exists in this project: chats, canvas pages,
helpers. Pure file reads, no side effects, cheap. Phase A of the Project Context
Layer.

build_project_state(dir_, repo_root) -> {
  chats:     [{id, label}],            # visible channels (registry + local overlay)
  canvases:  [{id, title}],            # tldraw pages from canvas-state store
  helpers:   {installed:[name], catalog:{local:N, remote:M}},
  counts:    {chats, canvases, installed},
}
"""
import os
import json

import home_spread


def _load_json(path, default):
    try:
        with open(path, encoding='utf-8') as f:
            return json.load(f)
    except Exception:
        return default


def _chats(dir_):
    """Visible channels, merged from the committed registry + local cc-* overlay,
    deduped by id, hidden ones dropped."""
    ch_dir = os.path.join(dir_, 'channels')
    out = {}
    for fn in ('index.json', 'index.local.json'):
        data = _load_json(os.path.join(ch_dir, fn), [])
        items = data if isinstance(data, list) else (data.get('channels') or [])
        for c in items:
            if isinstance(c, dict) and c.get('id') and not c.get('hidden'):
                out[c['id']] = {'id': c['id'], 'label': c.get('label') or c['id']}
    return list(out.values())


def _canvases(dir_):
    """Live tldraw pages (typeName == 'page') from the canvas store.

    Шлях питається в `home_spread.canvas_root`, тобто в ТОГО САМОГО місця, що й
    server.py (specs/user-data-architecture, К5). Раніше цей рядок збирав адресу сам,
    двома рівнями вгору до історичної теки канви в репозиторії, і це була ТРЕТЯ
    незалежна дорога до одних даних: реєстр казав `canvas-data`, сервер брав
    CANVAS_DATA_DIR, а цей рядок ішов повз обидва. Розбіжність уже коштувала нам
    порожнього переліку сторінок при успішному записі шапок на канву."""
    p = os.path.join(home_spread.canvas_root(dir_), 'canvas-state.json')
    store = (_load_json(p, {}) or {}).get('store', {}) or {}
    out = []
    for k, v in store.items():
        if isinstance(v, dict) and v.get('typeName') == 'page':
            out.append({'id': k, 'title': (v.get('name') or k)})
    return out


def _catalog(lib):
    """Розміри каталогу з ТОГО САМОГО місця, що й /api/helpers: skill_search.

    Раніше тут стояла власна формула (len(index.json) + remote["count"]), і вона
    давала 7498 там, де пошуковий корпус мав 7478: 20 записів лежать в обох файлах
    під однаковим id, у корпус іде наша версія, зовнішня відкидається. Дві формули
    на одне поняття і були дефектом, тому лічильника тут більше нема.

    Вантажимо модуль по шляху до файла, як і реєстр здатностей: project_state
    імпортують з різних місць (сервер, раннер, тести), і покладатись на sys.path
    тут не можна. Якщо сервер уже імпортував skill_search, беремо його ж
    екземпляр, щоб ділити кеш корпусу, а не будувати другий.

    -> (catalog, error_or_None)
    """
    import importlib.util
    import sys
    mod = sys.modules.get('skill_search')
    if mod is None:
        path = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'skill_search.py')
        if not os.path.isfile(path):
            return None, 'skill_search.py не знайдено поруч із застосунком'
        try:
            spec = importlib.util.spec_from_file_location('skill_search', path)
            mod = importlib.util.module_from_spec(spec)
            sys.modules['skill_search'] = mod
            spec.loader.exec_module(mod)
        except Exception as e:
            sys.modules.pop('skill_search', None)
            return None, 'каталог помічників не читається: %s' % e
    try:
        return mod.catalog_stats(lib), None
    except Exception as e:
        return None, 'каталог помічників не рахується: %s' % e


def _helpers(dir_, repo_root):
    """Installed skill folders + catalog sizes (local + harvested remote)."""
    installed = []
    sk_dir = os.path.join(repo_root, '.claude', 'skills')
    try:
        installed = sorted(d for d in os.listdir(sk_dir)
                           if os.path.isdir(os.path.join(sk_dir, d)))
    except Exception:
        installed = []
    catalog, error = _catalog(os.path.join(dir_, 'skills-library'))
    out = {'installed': installed,
           'catalog': catalog if catalog is not None else {}}
    if error:
        # Вголос, а не тихий нуль: мовчазне число і є та хвороба, яку лікує ця правка.
        out['catalogError'] = error
    return out


def _actions(dir_):
    """Перелік дозволених дій з ЄДИНОГО реєстру здатностей (mcp/capabilities.json).

    Той самий файл живить tools/list MCP-сервера, тому дві поверхні не можуть
    розійтись. Раніше цей блок був написаний руками і документував 4 дії при 81
    POST-ендпоінті на сервері: асистент бачив самоопис, не бачив у ньому
    перейменування каналу і чесно відмовлявся діяти (specs/chatview-mcp/spec.md).

    Вантажимо по шляху до файла, а не `import mcp.registry`: тека називається `mcp`, і
    звичайний імпорт злапав би однойменний пакет з PyPI, якби він стояв у середовищі.

    Шукаємо біля КОДУ, а не біля даних: у пакованій збірці dir_ це LOGOPSIS_HOME
    (домівка даних користувача), а реєстр їде разом з файлами застосунку. Якщо реєстру
    нема взагалі, віддаємо порожньо ПЛЮС причину: тихий вигаданий список це рівно той
    дрейф самоопису, який ця спека лікує.

    -> (actions, error_or_None)
    """
    import importlib.util
    here = os.path.dirname(os.path.abspath(__file__))
    for base in (here, dir_):
        path = os.path.join(base, 'mcp', 'registry.py')
        if not os.path.isfile(path):
            continue
        try:
            spec = importlib.util.spec_from_file_location('logopsis_mcp_registry', path)
            mod = importlib.util.module_from_spec(spec)
            spec.loader.exec_module(mod)
            return mod.actions_map(), None
        except Exception as e:
            return {}, 'реєстр здатностей не читається: %s' % e
    return {}, 'реєстр здатностей mcp/capabilities.json не знайдено поруч із застосунком'


def build_project_state(dir_, repo_root):
    chats = _chats(dir_)
    canvases = _canvases(dir_)
    helpers = _helpers(dir_, repo_root)
    actions, actions_error = _actions(dir_)
    out = {
        'chats': chats,
        'canvases': canvases,
        'helpers': helpers,
        'counts': {
            'chats': len(chats),
            'canvases': len(canvases),
            'installed': len(helpers['installed']),
        },
        # Phase C: action contracts so awareness becomes action. Джерело одне:
        # mcp/capabilities.json (ті самі інструменти, що й у MCP-сервері).
        'actions': actions,
        # Порада щодо поведінки, а не здатність. Живе поруч, а не серед `actions`:
        # ключі actions мусять збігатись з іменами інструментів MCP рівно, і на цьому
        # стоїть тест на збіг двох поверхонь.
        'actionsNote': 'Не постити в чужий канал; інші чати тільки для контексту. '
                       'Дії, що змінюють стан, робити лише на явне прохання користувача.',
    }
    if actions_error:
        out['actionsError'] = actions_error
    return out


if __name__ == '__main__':
    d = os.path.dirname(os.path.abspath(__file__))
    repo = os.path.abspath(os.path.join(d, '..', '..', '..'))
    st = build_project_state(d, repo)
    print(json.dumps(st['counts'], ensure_ascii=False))
    print('chats sample:', [c['label'] for c in st['chats'][:3]])
    print('canvas sample:', [c['title'] for c in st['canvases'][:3]])
    print('installed sample:', st['helpers']['installed'][:3])
    print('catalog:', st['helpers']['catalog'])
