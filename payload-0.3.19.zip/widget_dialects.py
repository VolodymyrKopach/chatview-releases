"""Адаптер діалектів віджетів: anti-corruption layer на межі «модель -> ворота».

Специфікація: specs/widget-dialect-adapter/spec.md
Нормативна таблиця правил: specs/widget-dialect-adapter/dialects.md (R0-R5)
Спільна фікстура з фронтом: tests/fixtures/widget-dialects.json
Очікуваний результат на кожен випадок: tests/fixtures/widget-dialects.expected.json

ЩО ЦЕ ЛІКУЄ. Замір 31.08.2026 на всіх 15 300 повідомленнях channels/: Antigravity
(Gemini) ламає віджет у 37 разів частіше за Claude (4,84 % проти 0,13 % повідомлень).
З 63 унікальних поламаних блоків 54 це ВАЛІДНИЙ JSON з чужими іменами полів: `headers`
замість `columns`, `status` замість `verdict`, `rows:[{key,value}]` замість
`items:[{k,v}]`. Драбина ремонту JSON лікувала не ту хворобу (ремонтувати нема чого),
а ворота `_is_renderable_widget` чесно відкидали віджет по точному збігу ключів.
Тому між ремонтом синтаксису і воротами стає третій шар: перекладач діалектів.

Закон Постела на межі: приймаємо ліберально, ЗБЕРІГАЄМО СТРОГО. Нормалізація
відбувається рівно один раз, на вході (`runner._salvage_chatui_block`), тому в
channels/*.json завжди лягає канонічний віджет, і 44 рендерери нічого не знають
про діалекти.

ЧИСТОТА. Модуль не імпортує runner, не робить IO і не тримає глобального стану:
`normalize_widget` це чиста функція, її можна ганяти в тесті окремо. Запис обліку
робить викликач (runner), а формат рядка задекларований тут (див. TRANSLATION LOG).

ІНВАРІАНТИ (dialects.md, розділ «Інваріанти»):
  1. Нічого не вигадуємо. Немає джерела значення означає не перекладати.
  2. No-op на канонічному вході: перевірка «вже канонічний» іде ПЕРШОЮ і повертає
     ТОЙ САМИЙ обʼєкт (identity, не копію).
  3. Тільки перейменування і перестановка.
  4. Зміна типу лише при повному збігу набору полів з цільовим типом.
  5. Конверт (`title`, `subtitle`, `note`, `tag`, `detail`) переноситься як є.
  6. Один прохід, без рекурсії у довільні дерева.

ВІДХИЛЕННЯ ВІД dialects.md (свідоме, задокументоване).
  R1b у dialects.md має додаткову умову «status.lower() ∈ {go, pivot, kill}, інакше
  правило НЕ спрацьовує». Ця умова суперечить решті того ж документа і критерію К9:
  сам R1b перелічує 14 живих випадків (9 разів {status,text} + 5 разів
  {status,title,rationale}), але у фікстурі лише 4 з тих 14 мають status='go', решта
  це 'success' (6) і 'info' (4). З трійковою умовою рятується 38 з 50 випадків
  Antigravity, тобто 76 %, і К9 (не менше 85 %) недосяжний у принципі. Тому R1b тут
  спрацьовує на БУДЬ-ЯКОМУ непорожньому рядку `status`, а трійка лишається тим, чим
  вона є насправді: канонічним написанням (`.upper()`). Інваріант «нічого не
  вигадуємо» не порушений: у `verdict` їде рядок, який модель написала сама.
  Таблиця в spec.md розділ 1 мапить `{status, text}` -> `{subject, verdict}` без
  жодної згадки про трійку, тож це відхилення від dialects.md, а не від спеки.

TRANSLATION LOG (К6). Облік ведеться двома слідами, обидва пише runner:
  1. Рядок у runner.out.log поруч з наявним `widget rejected: ...`, того ж стилю:
     `widget dialect: type=<in>-><out> dialect=<signature> model=<model>`
  2. Структурований рядок у JSONL `<LOGOPSIS_HOME або tools/viz/chat>/DIALECT_LOG_NAME`,
     рівно та схема, за якою читає scripts/widget-dialects-report.cjs:
         {"ts": ISO-8601, "type_in": str, "type_out": str,
          "dialect": str, "model": str}
     Готовий словник рядка будує `translation_record()` нижче, щоб схема жила поруч
     з правилами, а не в раннері.

ПІДПИС ДІАЛЕКТУ це ідентифікатор правила плюс короткий слаг перетворення
(`R2a:headers→columns`). Коли на віджеті спрацювало кілька правил, підписи склеєні
через `+` у порядку застосування (`R0:key-value→key-values+R4:rows→items`).
"""

# Ім'я файла обліку. Каталог обирає викликач (LOGOPSIS_HOME у пакованій збірці,
# тека tools/viz/chat у дев-репо), бо шлях це IO, а модуль лишається чистим.
DIALECT_LOG_NAME = 'widget-dialects.jsonl'

# Конверт: ці ключі жоден рядок не читає і не переписує (інваріант 5).
ENVELOPE_KEYS = ('title', 'subtitle', 'note', 'tag', 'detail')


def translation_record(ts, type_in, type_out, dialect, model):
    """Один рядок JSONL обліку (К6). Схема узгоджена зі scripts/widget-dialects-report.cjs.
    `model` None стає 'unknown', бо вигаданого дефолта тут не буває (той самий підхід,
    що у `runner._is_renderable_widget`)."""
    return {
        'ts': ts,
        'type_in': type_in or '(без типу)',
        'type_out': type_out or '(без типу)',
        'dialect': dialect,
        'model': model or 'unknown',
    }


# ── дрібні предикати ────────────────────────────────────────────────────────────

def _nonempty_str(v):
    return isinstance(v, str) and v.strip() != ''


def _nonempty_list(v):
    return isinstance(v, list) and len(v) > 0


def _first_str(w, *keys):
    """Перше непорожнє РЯДКОВЕ значення серед ключів, або None. Джерело значення, а
    не дефолт: коли жодного нема, викликач нічого не пише."""
    for k in keys:
        v = w.get(k)
        if _nonempty_str(v):
            return v
    return None


def _cell_text(cell):
    """Текст клітинки: сирий рядок, число або обгортка {text}. Нічого іншого."""
    if isinstance(cell, str):
        return cell
    if isinstance(cell, (int, float)) and not isinstance(cell, bool):
        return str(cell)
    if isinstance(cell, dict) and _nonempty_str(cell.get('text')):
        return cell['text']
    return None


def _list_of_dicts(v):
    return _nonempty_list(v) and all(isinstance(x, dict) for x in v)


def _list_of_lists(v):
    return _nonempty_list(v) and all(isinstance(x, list) for x in v)


def _list_of_strs(v):
    return _nonempty_list(v) and all(isinstance(x, str) for x in v)


# ── «вже канонічний?»: дзеркало runner._WIDGET_VALIDATORS ───────────────────────
# Рівно ті типи, яких адаптер узагалі торкається. Решту 37 типів реєстру він
# пропускає раніше (див. _TOUCHED_TYPES), тому дублювати весь валідатор не треба.
# Розходження з раннером ловить тест test_widget_dialects.py (drift guard).
_CANONICAL = {
    'verdict': lambda w: _nonempty_str(w.get('subject')) and _nonempty_str(w.get('verdict')),
    'table': lambda w: (_nonempty_list(w.get('columns')) and _nonempty_list(w.get('rows'))
                        and all(isinstance(r, list) for r in w['rows'])),
    'comparison-matrix': lambda w: ((_nonempty_list(w.get('cols')) or _nonempty_list(w.get('columns')))
                                    and _nonempty_list(w.get('rows'))
                                    and _nonempty_list(w.get('cells'))),
    'key-values': lambda w: _nonempty_list(w.get('items')),
    'checklist': lambda w: _nonempty_list(w.get('items')),
    'gallery': lambda w: _nonempty_list(w.get('images')),
    'code-block': lambda w: isinstance(w.get('code'), str) and w.get('code') != '',
}

# R0: псевдоніми типів, які діють безумовно (опечатка або синонім).
_ALIAS_ALWAYS = {
    'code-black': 'code-block',
    'key-value': 'key-values',
}
# R0: псевдоніми, які діють лише за наявності вмісту.
_ALIAS_ITEMS = ('list', 'bullet-list')   # -> checklist, коли є непорожній items

# Типи, на яких адаптер узагалі щось робить. Усе інше повертається миттєво і
# незміненим: це і є головна гарантія no-op на канонічному корпусі (К3).
_TOUCHED_TYPES = frozenset(
    set(_ALIAS_ALWAYS) | set(_ALIAS_ITEMS) | {
        'plan', 'verdict', 'table', 'comparison-matrix', 'key-values', 'gallery',
    }
)


# ── R0. Псевдоніми типів ────────────────────────────────────────────────────────

def _r0_alias(out, marks):
    t = out.get('type')
    if t in _ALIAS_ALWAYS:
        out['type'] = _ALIAS_ALWAYS[t]
        marks.append(f'R0:{t}→{out["type"]}')
        return
    if t in _ALIAS_ITEMS and _nonempty_list(out.get('items')):
        out['type'] = 'checklist'
        marks.append(f'R0:{t}→checklist')
        return
    if t == 'plan' and _list_of_dicts(out.get('steps')):
        items = []
        for s in out['steps']:
            text = _first_str(s, 'text', 'title', 'label')
            if text is None:
                continue
            items.append({'text': text, 'state': 'done' if s.get('completed') else 'pending'})
        if not items:
            return          # нема з чого будувати список: не перекладаємо (інваріант 1)
        out['type'] = 'checklist'
        out['items'] = items
        out.pop('steps', None)
        marks.append('R0:plan→checklist')


# ── R1. verdict ─────────────────────────────────────────────────────────────────

# R1a спрацьовує лише коли ВЕСЬ набір ключів належить conclusion (інваріант 4).
_R1A_ALLOWED = frozenset({'type', 'text', 'tone', 'points'} | set(ENVELOPE_KEYS))


def _r1_verdict(out, marks):
    has_verdict = _nonempty_str(out.get('verdict'))
    has_subject = _nonempty_str(out.get('subject'))

    # R1a: це взагалі не verdict, а conclusion (9 живих випадків {text, tone}).
    if (not has_verdict and not has_subject and _nonempty_str(out.get('text'))
            and set(out.keys()) <= _R1A_ALLOWED):
        out['type'] = 'conclusion'
        marks.append('R1a:verdict→conclusion')
        return

    # R1b: модель написала присуд у полі status (14 живих випадків).
    if has_verdict or not _nonempty_str(out.get('status')):
        return
    out['verdict'] = out['status'].strip().upper()
    out.pop('status', None)
    if not has_subject:
        subject = _first_str(out, 'title', 'text', 'subtitle')
        if subject is not None:
            out['subject'] = subject
    if 'reasons' not in out:
        why = _first_str(out, 'rationale', 'description')
        if why is not None:
            out['reasons'] = [why]
    marks.append('R1b:status→verdict')


# ── R2. table ───────────────────────────────────────────────────────────────────

def _column_keys(cols):
    """[{key,label}] -> (keys, labels), або (None, None) коли це не той діалект."""
    if not _list_of_dicts(cols):
        return None, None
    keys, labels = [], []
    for c in cols:
        k = _first_str(c, 'key', 'id', 'field')
        if k is None:
            return None, None
        keys.append(k)
        labels.append(_first_str(c, 'label', 'name', 'title') or k)
    return keys, labels


def _rows_by_keys(rows, keys):
    """[{k: v}] -> [[v]] у порядку keys. Відсутнє значення це порожня КЛІТИНКА тієї
    самої таблиці (дозволено dialects.md R2b), а не вигаданий зміст."""
    return [[('' if r.get(k) is None else r.get(k)) for k in keys] for r in rows]


def _r2_table(out, marks):
    # R2a: headers замість columns (10 живих випадків).
    if not _nonempty_list(out.get('columns')) and _nonempty_list(out.get('headers')):
        out['columns'] = out['headers']
        out.pop('headers', None)
        marks.append('R2a:headers→columns')

    cols, rows = out.get('columns'), out.get('rows')
    if not _nonempty_list(cols) or not _list_of_dicts(rows):
        return

    # R2b: колонки-обʼєкти з key плюс рядки-обʼєкти (2 живих випадки).
    keys, labels = _column_keys(cols)
    if keys is not None:
        out['columns'] = labels
        out['rows'] = _rows_by_keys(rows, keys)
        marks.append('R2b:key-columns→cells')
        return

    # R2c: рядки-обʼєкти, а колонки це рядки: беремо значення за збігом ключа з міткою.
    if _list_of_strs(cols) and any(c in rows[0] for c in cols):
        out['rows'] = _rows_by_keys(rows, cols)
        marks.append('R2c:row-objects→cells')


# ── R3. comparison-matrix ───────────────────────────────────────────────────────

def _row_label(row, key_blacklist=()):
    for k in ('label', 'name', 'row', 'title', 'key'):
        if k in key_blacklist:
            continue
        if _nonempty_str(row.get(k)):
            return row[k]
    return None


def _r3_from_row_objects(out, marks, cells_key, mark):
    """R3a / R3b: columns:[str] + rows:[{label, cells|values}] -> cols/rows/cells."""
    cols, rows = out.get('columns'), out.get('rows')
    if not _list_of_strs(cols) or not _list_of_dicts(rows):
        return False
    ncol = len(cols)
    labels, cells = [], []
    for r in rows:
        rc = r.get(cells_key)
        if not _nonempty_list(rc):
            return False
        if len(rc) == ncol + 1:
            # Перша клітинка це мітка рядка (dialects.md R3a, особливий випадок).
            label = _cell_text(rc[0])
            body = rc[1:]
        else:
            label = _row_label(r)
            body = rc
        if label is None:
            return False        # мітки нема, вигадувати не будемо (інваріант 1)
        labels.append(label)
        cells.append(body)
    out['cols'] = [{'name': c} for c in cols]
    out['rows'] = labels
    out['cells'] = cells
    out.pop('columns', None)
    marks.append(mark)
    return True


def _r3_from_grid(out, marks):
    """R3c: columns/headers + rows:[[...]] -> cols/rows/cells."""
    cols = out.get('columns')
    rows = out.get('rows')
    if not _list_of_strs(cols) or not _list_of_lists(rows):
        return False
    ncol = len(cols)
    widths = {len(r) for r in rows}
    if widths == {ncol + 1}:
        head = list(cols)               # колонки міток у заголовку нема
    elif widths == {ncol} and ncol >= 2:
        head = list(cols[1:])           # перша колонка це колонка міток
    else:
        return False
    labels, cells = [], []
    for r in rows:
        label = _cell_text(r[0])
        if label is None:
            return False
        labels.append(label)
        cells.append(list(r[1:]))
    out['cols'] = [{'name': c} for c in head]
    out['rows'] = labels
    out['cells'] = cells
    out.pop('columns', None)
    marks.append('R3c:grid→cols/rows/cells')
    return True


def _r3_from_key_cols(out, marks):
    """R3d: cols:[{key,label}] + rows:[{<key>: cell}] -> cols/rows/cells."""
    cols, rows = out.get('cols'), out.get('rows')
    keys, labels = _column_keys(cols)
    if keys is None or not _list_of_dicts(rows):
        return False
    row_labels = []
    for r in rows:
        label = _row_label(r, key_blacklist=keys)
        if label is None:
            return False
        row_labels.append(label)
    out['cells'] = _rows_by_keys(rows, keys)
    out['cols'] = [{'name': lb} for lb in labels]
    out['rows'] = row_labels
    marks.append('R3d:key-cols→cols/rows/cells')
    return True


def _r3_matrix(out, marks):
    if _nonempty_list(out.get('cells')):
        return
    # headers це той самий діалект, що й у table (R2a), і він трапляється тут теж.
    if not _nonempty_list(out.get('columns')) and _nonempty_list(out.get('headers')):
        out['columns'] = out['headers']
        out.pop('headers', None)
        marks.append('R2a:headers→columns')
    if _r3_from_row_objects(out, marks, 'cells', 'R3a:row-cells→cols/rows/cells'):
        return
    if _r3_from_row_objects(out, marks, 'values', 'R3b:row-values→cols/rows/cells'):
        return
    if _r3_from_grid(out, marks):
        return
    _r3_from_key_cols(out, marks)


# ── R4. key-values ──────────────────────────────────────────────────────────────

def _r4_key_values(out, marks):
    rows = out.get('rows')
    if _nonempty_list(out.get('items')) or not _list_of_dicts(rows):
        return
    items = []
    for r in rows:
        k = _first_str(r, 'key', 'label', 'k', 'name')
        v = r.get('value') if r.get('value') is not None else r.get('v')
        if k is None or v is None or (isinstance(v, str) and v.strip() == ''):
            continue            # без обох половин пари писати нема чого
        item = {'k': k, 'v': v}
        if _nonempty_str(r.get('color')):
            item['color'] = r['color']
        items.append(item)
    if not items:
        return
    out['items'] = items
    out.pop('rows', None)
    marks.append('R4:rows→items')


# ── R5. gallery ─────────────────────────────────────────────────────────────────

def _r5_gallery(out, marks):
    items = out.get('items')
    if _nonempty_list(out.get('images')) or not _list_of_dicts(items):
        return
    images = []
    for it in items:
        src = _first_str(it, 'image', 'src', 'url')
        if src is None:
            continue
        img = {'src': src}
        caption = _first_str(it, 'caption', 'title')
        if caption is not None:
            img['caption'] = caption
        images.append(img)
    if not images:
        return
    out['images'] = images
    out.pop('items', None)
    marks.append('R5:items→images')


_RULES_BY_TYPE = {
    'verdict': _r1_verdict,
    'table': _r2_table,
    'comparison-matrix': _r3_matrix,
    'key-values': _r4_key_values,
    'gallery': _r5_gallery,
}


def normalize_widget(w, model=None):
    """Перекласти віджет із відомого діалекту в канонічну схему.

    Повертає `(widget, dialect_signature)`. `dialect_signature` це None, коли нічого
    не перекладалось: тоді `widget` це ТОЙ САМИЙ обʼєкт (`result is w`), а не копія.
    Коли переклад відбувся, повертається НОВИЙ обʼєкт, вхідний не мутується.

    `model` не впливає на переклад узагалі: він тут лише щоб викликачу не треба було
    тягнути модель окремим шляхом до обліку (К6). Жодного правила «під двигун» немає,
    інакше це була б друга схема, яку спека прямо забороняє.
    """
    if not isinstance(w, dict):
        return w, None
    t = w.get('type')
    if not isinstance(t, str) or t not in _TOUCHED_TYPES:
        return w, None
    # Інваріант 2: «вже канонічний» перевіряємо ПЕРШИМ і виходимо тим самим обʼєктом.
    checker = _CANONICAL.get(t)
    if checker is not None:
        try:
            if checker(w):
                return w, None
        except Exception:
            return w, None

    out = dict(w)
    marks = []
    try:
        _r0_alias(out, marks)
        rule = _RULES_BY_TYPE.get(out.get('type'))
        if rule is not None:
            rule(out, marks)
    except Exception:
        # Перекладач не має права зробити гірше, ніж було: будь-яка несподівана
        # форма даних повертає вхід незміненим, і його судять ворота, як і раніше.
        return w, None
    if not marks:
        return w, None
    return out, '+'.join(marks)
