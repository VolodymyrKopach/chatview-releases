#!/usr/bin/env python3
"""Переїзд домівки в три шухляди, недеструктивно (specs/user-data-architecture, К9).

ЩО ЦЕ. Одна операція, яка бере домівку СТАРОЇ розкладки (корені класів навалом у
корені дому) і розкладає її по трьох шухлядах, які вже оголосив реєстр:

    <дім>/channels        ->  <дім>/data/channels        (drawer='data')
    <дім>/voice-cache     ->  <дім>/cache/voice-cache    (drawer='cache')
    <дім>/jobs            ->  <дім>/state/jobs           (drawer='state')

Куди саме поїде клас, тут НЕ вирішується і не може бути вирішено: шухляда це поле
`drawer` у `entities.REGISTRY`, і цей модуль її лише читає. Новий клас, доданий у
реєстр завтра, переїжджає сам, без жодної правки тут (К8). Список імен руками був би
рівно тим механізмом, яким уже розійшлись `settings.json` і `user-settings.json`.

ЧОМУ ЦЕ НЕБЕЗПЕЧНА ОПЕРАЦІЯ І ЯК САМЕ ВОНА ЗАХИЩЕНА. На домівці автора лежить 293
факти памʼяті, 15 каналів, 540 МБ медіа і 685 МБ канви. Це не тестові дані: втрачене
тут не відновлюється нізвідки. Тому в модулі три правила, і кожне з них є відповіддю
на конкретну смерть:

  1. ОРИГІНАЛ ЗНИКАЄ ОСТАННІМ. `os.rename` там, де можна (та сама файлова система,
     миттєво і атомарно: файл фізично не існує у двох місцях ані на мить). Де rename
     неможливий, повна копія в тимчасове імʼя, звірка «скільки файлів і байтів
     увійшло / вийшло», атомарна публікація копії під фінальним іменем, і аж потім
     видалення оригіналу. Обірвана копія лишає недоробку під іменем з `PARTIAL_MARK`
     і НЕДОТОРКАНИЙ оригінал.
  2. ОБРИВ ДОВОДИТЬСЯ ДО КІНЦЯ, А НЕ ПОЧИНАЄТЬСЯ З НУЛЯ. `data/.schema` пишеться
     ДВІЧІ: `running` до першого переносу і `done` після останнього. Саме перший
     запис відрізняє «нас убили посеред роботи» від «людина сама щось поклала в
     нову розкладку»: у першому випадку ціль під фінальним іменем означає готовий
     перенос і оригінал можна прибрати, у другому це збіг імен, який ми НЕ чіпаємо,
     а називаємо в лозі.
  3. НЕВІДОМЕ НЕ ЇДЕ НІКУДИ. Те, що не належить жодному класу реєстру (`keys.json`,
     `assets/`, `payload/`, `memory/projects.json`), лишається рівно там, де лежало,
     і потрапляє в `leftovers` з причиною. Розкидати невідоме по шухлядах «за
     змістом імені» це рівно той спосіб, яким дані і губляться: помилка виглядає як
     виконана робота.

ЧОМУ МІГРАЦІЯ ЗАРАЗ НЕ ЗАПУСКАЄТЬСЯ САМА, І ЧОМУ ЦЕ НЕ ЗАБУДЕТЬСЯ. Дані і читачі
мусять переїжджати разом. Сьогодні `entities.path_for` віддає `<дім>/channels` без
сегмента шухляди (його поява в одному місці описана в докстрінгу самої `path_for`),
і `server.py` теж читає старі шляхи. Перенести дані під `data/` раніше за читачів
означає застосунок, який стартує на порожньому екрані при цілих даних на диску, а це
для людини нічим не відрізняється від втрати.

Тому гейт тут НЕ прапорець і НЕ змінна оточення, яку хтось забуде виставити:
`readers_expect_drawers()` ПИТАЄ САМ КОНТРАКТ, тобто дивиться, що `path_for` віддає
для кожного класу реєстру. Поки читачі беруть старі шляхи, `migrate_on_start`
свідомо не робить нічого і каже про це рядком. Щойно `path_for` почне видавати
сегмент шухляди, переїзд поїде сам, без жодної правки в цьому файлі і без чиєїсь
памʼяті про прапорець. Прапорець забувають; питання до контракту не забувається.

ЩО ЦЕ НЕ РОБИТЬ. Не чіпає розповзання класів (`assets/media`, канва в
`tools/canvas-cmd/data`, стан гаджета впереміш із його кодом): це S6, і він
скористається саме цим механізмом. Не чіпає нічого поза домівкою: клас, корінь якого
цією збіркою розвʼязується за межі дому (`.claude/skills` у дев-репо), пропускається
з названою причиною, бо переїзд дев-запуску з репо це не-ціль спеки.
"""
import io
import os
import json
import time
import shutil

import entities

#: Версія розкладки домівки. Пишеться в `data/.schema`; збіг версії і статусу `done`
#: означає «тут уже нова розкладка», і другий старт не робить нічого.
SCHEMA_VERSION = 1

#: Імена станів у `.schema`. `running` це не діагностика, а робочий стан: рівно він
#: дозволяє повторному старту відрізнити свою ж обірвану роботу від чужих файлів.
RUNNING = 'running'
DONE = 'done'

#: Префікс недороблених копій. Публікація під фінальним іменем відбувається
#: атомарним rename, тому все, що лишилось із цим префіксом, за визначенням не
#: дороблене і підлягає перезапуску, а не використанню.
PARTIAL_MARK = '.migrating-'

#: Файл версії розкладки. Лежить у `data/`, бо саме `data` це шухляда, зникнення
#: якої означає втрату: мітка розкладки мусить жити поруч з тим, що вона описує.
SCHEMA_FILE = '.schema'


# ── де що лежить ────────────────────────────────────────────────────────────

def schema_path(home):
    """Шлях до мітки розкладки: `<дім>/data/.schema`."""
    return os.path.join(home, 'data', SCHEMA_FILE)


def read_schema(home):
    """Мітка розкладки або None. Нечитабельна мітка це теж None.

    Бита мітка навмисно НЕ помилка: єдиний наслідок це ще один прохід міграції, а
    прохід по вже перенесеній домівці нічого не ламає (усі кроки ідемпотентні).
    Впасти тут означало б застосунок, який не стартує через один зіпсований байт."""
    try:
        with io.open(schema_path(home), encoding='utf-8') as fh:
            data = json.loads(fh.read() or 'null')
    except Exception:
        return None
    return data if isinstance(data, dict) else None


def _base(cls, home, env):
    """База, від якої відлічується корінь класу.

    Свідомо береться `entities._base_for`, а не власна здогадка по сегментах шляху.
    Здогадка «передостанній сегмент і є шухляда» помиляється на домівці, яка сама
    зветься `data` (а такі бувають), і ціна цієї помилки тут максимальна: міграція
    вирішила б, що читачі вже знають нову розкладку, і забрала б дані з-під них."""
    return entities._base_for(cls, home, env)


def registered():
    """Класи, які реєстр знає ЗАРАЗ, включно з доданими через `register()`.

    Свідомо `REGISTRY`, а не `entities.kinds()`: kinds() перелічує вбудований кортеж
    `_CLASSES`, тобто клас, доданий у реєстр з іншого модуля, у переїзд би не
    потрапив і тихо лишився б у старій розкладці. Тихо тут означає «дані на диску,
    яких не бачить жоден читач»."""
    return list(entities.REGISTRY.values())


def _root_segments(cls):
    return [s for s in cls.root.replace('\\', '/').split('/') if s]


def old_root(cls, home, env):
    """Де корінь класу лежить у СТАРІЙ розкладці."""
    return os.path.join(_base(cls, home, env), *_root_segments(cls))


def new_root(cls, home, env):
    """Де корінь класу мусить лежати в НОВІЙ розкладці: база + шухляда + корінь."""
    return os.path.join(_base(cls, home, env), cls.drawer, *_root_segments(cls))


def readers_expect_drawers(home=None, env=None):
    """Чи контракт шляхів УЖЕ віддає сегмент шухляди. -> bool.

    Питання ставиться самій `entities.path_for` по кожному класу реєстру, тобто
    тому єдиному місцю, звідки шлях беруть читачі. Розкладка навпіл (частина класів
    по-старому, частина по-новому) це не «майже готово», а зламаний контракт, і
    мовчки мігрувати в такому стані не можна: половина даних поїхала б з-під
    читачів. Тому там виняток, а не вибір більшості."""
    env = os.environ if env is None else env
    home = home or entities.data_root(env)
    old = []
    new = []
    for cls in registered():
        kind = cls.kind
        got = entities.path_for(kind, home=home, env=env)
        if got == old_root(cls, home, env):
            old.append(kind)
        elif got == new_root(cls, home, env):
            new.append(kind)
        else:
            raise RuntimeError(
                'клас «%s»: path_for віддає %r, що не є ані старим коренем, ані '
                'коренем у шухляді «%s». Міграція не рухає дані, доки не розуміє, '
                'куди дивиться читач' % (kind, got, cls.drawer))
    if old and new:
        raise RuntimeError(
            'реєстр видає шляхи ДВОМА розкладками одночасно: по-старому %s, у '
            'шухляді %s. Це зламаний контракт, а не проміжний стан: половина даних '
            'поїхала б з-під читачів' % (', '.join(old), ', '.join(new)))
    return bool(new)


# ── план переїзду ───────────────────────────────────────────────────────────

def plan(home=None, env=None):
    """Що і куди їде. -> [{kind, drawer, src, dst, present}] + [{kind, why}] пропущені.

    Повертає пару (moves, skipped). Джерело рішення одне: реєстр. Клас, корінь якого
    цією збіркою розвʼязується за межі дому, у переїзд не входить (дев-репо тримає
    помічники власника в корені репозиторію, і це не-ціль спеки)."""
    env = os.environ if env is None else env
    home = home or entities.data_root(env)
    moves, skipped = [], []
    for cls in registered():
        kind = cls.kind
        src = old_root(cls, home, env)
        dst = new_root(cls, home, env)
        if not _under(src, home):
            skipped.append({
                'kind': kind, 'src': src,
                'why': 'корінь класу лежить поза домівкою (%s): переїзд дев-запуску '
                       'з репозиторію це не-ціль спеки' % src})
            continue
        moves.append({'kind': kind, 'drawer': cls.drawer, 'src': src, 'dst': dst,
                      'present': os.path.exists(src)})
    return moves, skipped


def leftovers(home, env=None):
    """Що лишилось у корені дому і НЕ належить жодному класу. -> [{name, path, why}]

    Це не перелік для краси, а обовʼязок з умови задачі: невідоме не їде нікуди, але
    й не замовчується. Мовчазний залишок виглядає як виконана робота рівно доти, доки
    хтось не піде його шукати."""
    env = os.environ if env is None else env
    claimed = {}
    for cls in registered():
        src = old_root(cls, home, env)
        if _under(src, home):
            head = os.path.relpath(src, home).replace('\\', '/').split('/')[0]
            claimed.setdefault(head, []).append(cls.kind)
    out = []
    try:
        names = sorted(os.listdir(home))
    except OSError:
        return out
    for name in names:
        if name in entities.DRAWERS:
            continue
        full = os.path.join(home, name)
        if name in claimed:
            why = ('у корені класу (%s) лишилось те, що самому класу не належить'
                   % ', '.join(claimed[name]))
        else:
            why = 'не належить жодному класу реєстру: правила життя для нього нема'
        out.append({'name': name, 'path': full, 'why': why})
    return out


# ── перенос ─────────────────────────────────────────────────────────────────

def weigh(path):
    """(файлів, байтів) під шляхом. Мірка «скільки увійшло і скільки вийшло»."""
    if not os.path.exists(path):
        return (0, 0)
    if os.path.isfile(path) and not os.path.islink(path):
        return (1, os.path.getsize(path))
    files = size = 0
    for base, _dirs, names in os.walk(path):
        for name in names:
            full = os.path.join(base, name)
            files += 1
            try:
                size += os.path.getsize(full)
            except OSError:
                pass
    return (files, size)


def _under(path, root):
    path = os.path.realpath(path)
    root = os.path.realpath(root)
    return path == root or path.startswith(root + os.sep)


def _ensure_dir(path):
    if path:
        os.makedirs(path, exist_ok=True)


def _sync_dir(path):
    """Змусити каталог лягти на диск. Без цього публікація копії переживає падіння
    процесу, але не обовʼязково падіння машини."""
    try:
        fd = os.open(path, getattr(os, 'O_DIRECTORY', os.O_RDONLY))
    except OSError:
        return
    try:
        os.fsync(fd)
    except OSError:
        pass
    finally:
        os.close(fd)


def _drop(path):
    if os.path.islink(path) or os.path.isfile(path):
        os.remove(path)
    elif os.path.isdir(path):
        shutil.rmtree(path)


def _partial_for(dst):
    return os.path.join(os.path.dirname(dst), PARTIAL_MARK + os.path.basename(dst))


def sweep_partials(directory):
    """Прибрати недоробки минулого обриву. -> скільки прибрано.

    Безпечно за побудовою: під іменем з `PARTIAL_MARK` не існує НІЧОГО завершеного,
    бо завершення це атомарний rename під фінальне імʼя."""
    n = 0
    try:
        names = os.listdir(directory)
    except OSError:
        return 0
    for name in names:
        if name.startswith(PARTIAL_MARK):
            _drop(os.path.join(directory, name))
            n += 1
    return n


def _copy_then_drop(src, dst):
    """Копія з ЦІЛИМ оригіналом, звірка, атомарна публікація, і лише потім видалення."""
    part = _partial_for(dst)
    _drop(part)
    if os.path.isdir(src) and not os.path.islink(src):
        shutil.copytree(src, part, symlinks=True)
    else:
        shutil.copy2(src, part, follow_symlinks=False)
    was, got = weigh(src), weigh(part)
    if was != got:
        raise IOError(
            'копія %s розійшлась з оригіналом: увійшло %d файлів / %d Б, вийшло '
            '%d файлів / %d Б. Оригінал НЕ чіпаємо' % ((src,) + was + got))
    _sync_dir(os.path.dirname(dst))
    os.rename(part, dst)
    _sync_dir(os.path.dirname(dst))
    _drop(src)
    return 'copy'


def _move(src, dst):
    """Перенести ОДИН вузол (теку або файл). -> 'rename' | 'copy'.

    rename перший не з любові до швидкості: він атомарний, тобто вузол не існує у
    двох місцях ані на мить і не існує в жодному ані на мить. Копія це запасний
    шлях для випадку, коли ціль на іншій файловій системі."""
    _ensure_dir(os.path.dirname(dst))
    try:
        os.rename(src, dst)
        return 'rename'
    except OSError as why:
        try:
            return _copy_then_drop(src, dst)
        except Exception as e:
            raise IOError('не вдалось перенести %s -> %s: rename сказав «%s», '
                          'копія сказала «%s»' % (src, dst, why, e))


def _merge_into(src_root, dst_root, resumed, say):
    """Ціль уже існує: доробити поелементно. -> (перенесено, конфлікти)."""
    conflicts = []
    sweep_partials(dst_root)
    for name in sorted(os.listdir(src_root)):
        src = os.path.join(src_root, name)
        dst = os.path.join(dst_root, name)
        if not os.path.exists(dst):
            _move(src, dst)
            continue
        if resumed:
            # Під фінальним іменем ціль зʼявляється ЛИШЕ після повного переносу
            # (rename атомарний, копія публікується атомарно). Отже це наш
            # власний, доведений до кінця крок, обірваний перед прибиранням.
            _drop(src)
            continue
        conflicts.append({'src': src, 'dst': dst,
                          'why': 'обидві копії існують, а мітки обірваного переїзду '
                                 'нема: це не наша недоробка, тому не чіпаємо'})
        say('  ! %s: є і там, і там, лишаю обидві' % name)
    return conflicts


def _prune_empty(path, stop):
    """Прибрати порожні теки, що лишились після виїзду класу, не вище за `stop`."""
    while _under(path, stop) and os.path.realpath(path) != os.path.realpath(stop):
        try:
            os.rmdir(path)
        except OSError:
            return
        path = os.path.dirname(path)


# ── сама міграція ───────────────────────────────────────────────────────────

def _write_schema(home, status, extra=None):
    path = schema_path(home)
    _ensure_dir(os.path.dirname(path))
    body = {'version': SCHEMA_VERSION, 'status': status,
            'drawers': list(entities.DRAWERS), 'at': time.time()}
    body.update(extra or {})
    tmp = path + '.tmp'
    with io.open(tmp, 'w', encoding='utf-8') as fh:
        json.dump(body, fh, ensure_ascii=False, indent=1)
        fh.write('\n')
        fh.flush()
        os.fsync(fh.fileno())
    os.replace(tmp, path)
    _sync_dir(os.path.dirname(path))
    return body


def migrate(home=None, env=None, log=None):
    """Перенести домівку в три шухляди. -> звіт (dict).

    Ідемпотентна: другий виклик на вже перенесеній домівці не робить нічого і каже
    про це в `reason`. Обірваний виклик доводиться наступним, а не починається з
    нуля: мітка `running` у `.schema` це і є памʼять про недороблене."""
    env = os.environ if env is None else env
    home = home or entities.data_root(env)
    say = log or (lambda _m: None)

    was = read_schema(home)
    if was and was.get('version') == SCHEMA_VERSION and was.get('status') == DONE:
        return {'migrated': False, 'resumed': False, 'version': SCHEMA_VERSION,
                'reason': 'домівка вже в трьох шухлядах (data/.schema, версія %d)'
                          % SCHEMA_VERSION,
                'moves': [], 'skipped': [], 'conflicts': [],
                'leftovers': leftovers(home, env),
                'filesIn': 0, 'bytesIn': 0, 'filesOut': 0, 'bytesOut': 0}

    resumed = bool(was and was.get('status') == RUNNING)
    moves, skipped = plan(home, env)
    todo = [m for m in moves if m['present']]

    # Мітка `running` пишеться ДО першого переносу. Саме вона дає повторному старту
    # право прибрати оригінал, ціль якого вже на місці: без неї відрізнити свою
    # обірвану роботу від чужих файлів нема як.
    _write_schema(home, RUNNING, {'classes': [m['kind'] for m in todo]})
    for drawer in entities.DRAWERS:
        _ensure_dir(os.path.join(home, drawer))
        sweep_partials(os.path.join(home, drawer))

    done, conflicts = [], []
    files_in = bytes_in = files_out = bytes_out = 0
    say('переїзд домівки %s: класів до переносу %d%s'
        % (home, len(todo), ', продовжуємо обірваний' if resumed else ''))
    for m in todo:
        src, dst = m['src'], m['dst']
        was_files, was_bytes = weigh(src)
        if os.path.exists(dst):
            got = _merge_into(src, dst, resumed, say)
            conflicts.extend(got)
            how = 'merge'
        else:
            how = _move(src, dst)
        if not conflicts:
            _prune_empty(src, home)
        out_files, out_bytes = weigh(dst)
        files_in += was_files
        bytes_in += was_bytes
        files_out += out_files
        bytes_out += out_bytes
        done.append({'kind': m['kind'], 'drawer': m['drawer'], 'src': src, 'dst': dst,
                     'how': how, 'files': was_files, 'bytes': was_bytes,
                     'filesAfter': out_files, 'bytesAfter': out_bytes})
        say('  %-9s %-6s %s -> %s (%d файлів, %d Б)'
            % (m['kind'], how, os.path.relpath(src, home),
               os.path.relpath(dst, home), was_files, was_bytes))

    rest = leftovers(home, env)
    for item in rest:
        say('  лишається на місці: %-24s %s' % (item['name'], item['why']))
    for item in skipped:
        say('  поза домівкою: %-14s %s' % (item['kind'], item['why']))

    _write_schema(home, DONE, {'classes': [m['kind'] for m in done]})
    return {'migrated': True, 'resumed': resumed, 'version': SCHEMA_VERSION,
            'reason': '', 'moves': done, 'skipped': skipped, 'conflicts': conflicts,
            'leftovers': rest,
            'filesIn': files_in, 'bytesIn': bytes_in,
            'filesOut': files_out, 'bytesOut': bytes_out}


def migrate_on_start(home=None, env=None, log=None):
    """Точка старту: перенести домівку, ЯКЩО читачі вже знають нову розкладку.

    Гейт тут не косметичний і не тимчасовий сором. Дані і читачі мусять переїжджати
    разом: перенести `channels/` під `data/` раніше, ніж `path_for` почне видавати
    сегмент шухляди, означає застосунок з порожніми екранами при цілих даних на
    диску, а для людини це те саме, що втрата. Питання ставиться контракту, а не
    прапорцю, тому вмикати тут нічого не доведеться: щойно `path_for` віддасть
    шухляду, переїзд поїде сам."""
    env = os.environ if env is None else env
    home = home or entities.data_root(env)
    say = log or (lambda _m: None)
    if not readers_expect_drawers(home, env):
        return {'migrated': False, 'resumed': False, 'version': SCHEMA_VERSION,
                'reason': 'читачі ще беруть шляхи старої розкладки (entities.path_for '
                          'без сегмента шухляди): переносити дані з-під них не можна',
                'moves': [], 'skipped': [], 'conflicts': [], 'leftovers': [],
                'filesIn': 0, 'bytesIn': 0, 'filesOut': 0, 'bytesOut': 0}
    return migrate(home, env, say)


if __name__ == '__main__':
    import sys
    target = sys.argv[1] if len(sys.argv) > 1 else None
    report = migrate(target, env={'LOGOPSIS_HOME': target} if target else None,
                     log=lambda m: print(m))
    print(json.dumps({k: v for k, v in report.items() if k != 'moves'},
                     ensure_ascii=False, indent=1))
