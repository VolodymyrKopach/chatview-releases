#!/usr/bin/env python3
"""summary_generate.py — генератор саммарі каналу (specs/chat-summary, розділ 4.4 і 7.1).

НАЙРИЗИКОВАНІШИЙ ФРАГМЕНТ ФІЧІ. Дослівно зі спеки: «Провалить не рендерер (двісті рядків),
а генератор. Схема ловить правки, але не ловить створення... Без власного валідатора з
циклом ремонту система за кілька тижнів тихо деградує назад у вільний HTML.» Тому весь цей
файл побудований навколо ОДНОГО факту: модель повертає JSON з ймовірністю помилки, і кожен
виклик `summary_store.validate_generation` тут не формальність, а єдине, що стоїть між
моделлю і тихою деградацією.

ПРОВАЙДЕР КАНАЛУ (specs/chat-summary розділ 7.1, доданий): канал має ДВА можливих двигуни
(`runner.channel_provider`, 'claude' | 'antigravity'), і генератор кличе рівно той, на якому
живе канал, а не завжди Claude. Обидва шляхи (`_invoke_claude_cli`/`_invoke_agy_cli`) віддають
однаковий контракт — сирий текст відповіді моделі — і йдуть в ОДИН спільний цикл ремонту
(`_run_with_repair`) та ОДНУ перевірку подачі (`_presentation_ok`): вибір провайдера це рівно
один `if` при побудові функції-виклику в `ensure_summary`, решта пайплайну від провайдера не
залежить. Помилки з двох двигунів НЕ плутаються: `GenerationError` з `_invoke_claude_cli`
завжди починається з `'claude CLI'`, з `_invoke_agy_cli` — з `'agy CLI'`, тож у лозі видно,
який саме двигун відмовив.

ЯК ВИКЛИКАЄТЬСЯ МОДЕЛЬ (дослідження перед кодом, а не вигадка)
----------------------------------------------------------------
`agent_worker.py` уже показує канонічний шлях: детач-агенти Logopsis крутять модель через
сирий `<claude_bin> -p <prompt> ...` subprocess, з бінарником з `runner.CLAUDE_BIN` і
аргументами моделі з `runner._resolve_model_args`. Це ЄДИНА автентифікація в проєкті для
викликів Claude: сесія `claude` CLI, залогінена на машині (OAuth/keychain), той самий шлях,
яким кермує вся Logopsis. Жодного нового ключа не заведено: BYOK-політика проєкту стосується
OpenAI (TTS), а не цього виклику. Канал на `antigravity` йде тим самим принципом через
`runner.AGY_BIN` (`agy` CLI, живий зонд задокументований біля `_invoke_agy_cli` нижче).

Але для ЦЬОГО виклику (фонова генерація структурованого дерева, а не чат-хід) є три різниці
з тим, як `agent_worker.py` спавнить агента-кодера, і всі три перевірені живим прогоном
(не здогад):
  1. `cwd`. `agent_worker.py` стартує з `cwd=REPO_ROOT`, бо агенту-коду потрібен репозиторій.
     Наш генератор працює ЛИШЕ з текстом, який ми самі кладемо у промпт, тож ставимо
     `cwd` у нейтральну системну temp-теку. Перевірено: коли `cwd` лежить УСЕРЕДИНІ
     репозиторію, харнес підвантажує `.claude/settings.json` цього репо (MCP-сервери,
     UserPromptSubmit-хуки типу `skills-roster.cjs`), а це чужий шум у промпті генератора.
  2. `--system-prompt` (ПОВНА заміна), а не `--append-system-prompt` (додавання). Живий
     прогін підтвердив: з `--system-prompt` дефолтний системний промпт claude_code preset
     (і razом з ним CLAUDE.md ЦЬОГО репозиторію, з рядком «ти оркестратор, делегуй усе
     Тарасу») НЕ підмішується. Ловись: user-рівневий `~/.claude/CLAUDE.md` все одно
     прилітає окремим `<system-reminder>` у ПЕРШЕ повідомлення користувача, незалежно від
     `--system-prompt` і від `cwd` (це властивість автентифікованої сесії, не проєкту).
     Тому екстракція відповіді (`_extract_json`) мусить бути стійкою до чужого тексту
     навколо JSON, а не вірити, що відповідь це рівно JSON і нічого більше.
  3. `--tools "" --strict-mcp-config`. Без цього перший же холодний виклик коштував
     $0.147 на «PONG» (36572 токени кеш-запису: у системний контекст вантажились описи
     MCP-серверів з user-рівневого реєстру — chrome-devtools, context7, serena, clickup,
     posthog, sentry). З цими двома прапорцями той самий виклик впав до $0.003 (953 токени).
     Генератору інструменти не потрібні взагалі: увесь контекст (нові картки + попереднє
     саммарі) ми самі кладемо у промпт, моделі нема чого читати з диска.

ЦИКЛ РЕМОНТУ (К16)
-------------------
Дерево від моделі йде через `summary_store.validate_generation` СИНХРОННО, до будь-якого
запису. При помилці моделі повертається ТЕКСТ помилки (той самий, що бачив би розробник) і
дається ще одна спроба, до `MAX_GENERATION_ATTEMPTS`. Жодна проміжна спроба нічого не пише:
`write_generation` викликається РІВНО ОДИН РАЗ, і тільки для дерева, яке вже пройшло
валідатор. Якщо спроби скінчились — попередня генерація лишається на місці (ми просто не
викликаємо `write_generation`).

Провал видно двома способами: у поверненому результаті (`ok: False`, `error`, `attempts`) і
в лозі (`log_fn`, за замовчуванням `runner.log`, той самий журнал, який уже пише решта
Logopsis) — ніколи мовчки.

К43/К44 (specs/chat-summary, розділ 9.1) розширюють ТОЙ САМИЙ цикл, а не заводять другий:
дерево, яке пройшло схему (`ss.validate_generation`), додатково проходить `_presentation_ok`
(мінімум різних типів вузлів, стеля частки `note`); провал тут теж повертає моделі ТЕКСТ з
числами і йде на новий заход. Якщо жоден захід не взяв поріг подачі — К44-запобіжник бере
НАЙКРАЩЕ зі схема-валідних дерев замість того, щоб лишити канал зовсім без документа.

К45 (specs/chat-summary, розділ 9) додає ТРЕТІЙ поріг у той самий `_presentation_ok`: частка
вузлів `free` вище `FREE_FRACTION_CEILING` теж провалює подачу і йде на той самий ремонт із
числом у поясненні, тим самим законом, а не проханням у промпті (той самий урок, що вже двічі
довела ця спека — двоїння теми, розділ 7.5, і бідна подача, розділ 8.1). `free` при цьому
НІКОЛИ не рахується як внесок у різноманіття (`distinct`): інакше модель могла б підмінити
бракуючий структурний тип вузлом-виходом із самої системи компонентів, яку ця перевірка існує,
щоб захищати.
"""
import copy
import json
import os
import re
import subprocess
import tempfile
import threading

import summary_store as ss

try:
    import runner
except Exception:  # pragma: no cover - runner тягне платформний шар; тести підміняють CLI
    runner = None


# ── Константи модуля (жодного магічного числа в коді) ────────────────────────

#: К16. Обмежена кількість спроб: 1 перша + до 3 ремонтів. Достатньо, щоб пережити типову
#: одну криву спробу моделі, замало, щоб цикл ремонту сам перетворився на дорогий цикл.
MAX_GENERATION_ATTEMPTS = 4

#: К17 + К47. Стеля ПОВНОГО ТЕКСТУ попереднього саммарі в символах (розділ 4.3): 6000
#: символів ≈ 2000 токенів. Стеля лишається, бо контекст не безмежний, але з К47 вона
#: більше не ріже КАРТУ документа: обрізання торкається лише того, що подано дослівно.
#: Що вона ріже і чого вже не ріже, дослівно:
#:   ріже — повний JSON пунктів, які до нових карток стосунку не мають;
#:   НЕ ріже — жодного ключа секції чи пункта (`_document_map_block` завжди повна).
#: Чому це не косметика (заміряно по ревізіях chat-269, скільки ключів пункту взагалі
#: потрапляло в промпт під цією стелею, коли вона різала хвіст дерева без розбору):
#:   genRev 3: 19 пунктів -> видно 14 (74%)
#:   genRev 4: 27 пунктів -> видно 11 (41%)   <- пік документа
#:   genRev 5: 22 пункти  -> видно 11 (50%)   <- і саме тут зникло 26 пунктів
#:   genRev 6: 17 пунктів -> видно 11 (65%)
#:   genRev 7: 16 пунктів -> видно 11 (69%)
#:   genRev 8: 10 пунктів -> видно 10 (100%)  <- не одужання, а вже наслідок обвалу
#: 6000 символів пропускають приблизно 11 пунктів, скільки б їх не було насправді, тому чим
#: більший документ, тим меншу його частку модель мала шанс зберегти. Пункт, якого модель не
#: бачить, для неї не існує: вона не оновлювала його, а вигадувала новий ключ поруч.
PREV_SUMMARY_CHAR_CEILING = 6000

#: К47. Скільки символів ЗМІСТУ несе один пункт у карті документа, і як карта коротшає,
#: коли не влазить у свій бюджет. Сходинки йдуть до НУЛЯ навмисно: у найгіршому разі
#: карта вироджується в голий список ключів і заголовків, але ключ не зникає НІКОЛИ.
#: Пункт без дайджесту модель ще може зберегти посиланням `{"key": ..., "keep": true}`;
#: пункт без ключа вона зберегти не може в принципі.
MAP_DIGEST_STEPS = (160, 90, 45, 0)

#: Бюджет самої карти. Не критерій зі спеки, а власний запобіжник: 20 секцій по 40 пунктів
#: (стелі `summary_store`) з дайджестом 160 символів дали б ≈130 КБ у промпті. Реальні
#: документи на порядок менші (chat-269 на піку — 27 пунктів), тому на практиці звуження
#: не вмикається; воно існує рівно для того, щоб патологічний документ не вибив виклик.
MAP_CHAR_BUDGET = 12000

#: К18. Кожні стільки ІНКРЕМЕНТАЛЬНИХ оновлень поспіль — повна перезбірка (mode='full'),
#: щоб дрейф (початок чату «виїжджає» з підсумку) не накопичувався без обмеження.
#:
#: К47 змінив ЗМІСТ слова «повна». Раніше `full` означав чистий аркуш: `prev_block = None`,
#: модель не бачила попереднього документа взагалі й складала його наново з карток. На
#: chat-269 саме такий прогін (genRev 8) лишив 10 пунктів там, де було 27, при розмові, що
#: весь час РОСЛА. Тепер `full` означає РЕОРГАНІЗАЦІЮ: модель бачить і всю історію карток,
#: і повну карту наявного документа, і має право перекласти пункти як завгодно, але не має
#: способу забути їх мовчки — зникнення лишається явним актом (`retired`).
FULL_REBUILD_EVERY = 5

#: К49. Стеля частки пунктів попереднього документа, які ОДНА генерація сміє відставити
#: (`retired`) за раз. Вище стелі генерація йде в той самий цикл ремонту (К16), що й крива
#: схема і бідна подача, з числом у поясненні.
#:
#: Число взяте із замірів chat-269, а не зі стелі. Частки зниклих пунктів по його реальних
#: ревізіях: 26% (19→27 пунктів, 9 переписано на місці), 96% (27→22, переписано 1), 50%
#: (22→17, переписано 8), 35% (17→16, переписано 8), 94% (16→10, переписано 1). Вони чітко
#: розпадаються на два кластери з розривом між 50% і 94%: нижній кластер це ревізії, які ще
#: РЕДАГУВАЛИ документ (8-9 пунктів переписано на місці), верхній — рівно дві ревізії, де
#: документ переписувався з нуля (переписано рівно 1). Половина це найширша лінія в цьому
#: розриві: вона ловить обидва обвали з великим запасом і не чіпає жодної ревізії, яка ще
#: робила справжню редакторську роботу. Тугіший поріг (наприклад третина) відхиляв би і
#: живе редагування, а недосяжний поріг палить токени на цикл ремонту, який не збігається
#: (те саме застереження, що для К44).
RETIRE_FRACTION_CEILING = 0.5

#: К43 (specs/chat-summary, розділ 9.1). Поріг подачі: нижче нього генерація відхиляється
#: тим самим циклом ремонту (К16), не приймається як стилістичний вибір моделі (К38).
#: Дослівний замір розділу 9.1: БЕЗ вимоги різноманіття в промпті — 2 типи, 93% note.
#: ПІСЛЯ того, як промпт отримав правила подачі й приклад (К35-К38) — 7 типів/65% note
#: (demo-vygul-2) і 5 типів/50% note (demo-vygul-1) на живих каналах. Еталон стрічки
#: (chat-293) — 13 типів на 18 меседжів. Пороги нижче НАВМИСНО не еталонні 13: мета
#: зловити провал (2 типи/93%, стан ДО правил подачі), а не жбурляти в ремонт кожну
#: генерацію, яка вже й так непогана — недосяжний поріг із першої спроби спалює токени
#: на цикл, що ніколи не збіжиться (застереження розділу 9.2 щодо К44).
MIN_DISTINCT_NODE_TYPES = 4
NOTE_FRACTION_CEILING = 0.6

#: К45 (specs/chat-summary, розділ 9.1). Стеля частки `free`-вузлів: та сама механіка, що
#: NOTE_FRACTION_CEILING (провал відхиляється тим самим циклом ремонту, число в поясненні),
#: але поріг НАБАГАТО жорсткіший, і це навмисно. `note` — це принаймні читабельний текст,
#: який просто не доїхав до структури; `free` — вихід ІЗ САМОЇ СИСТЕМИ КОМПОНЕНТІВ (нуль
#: адресації, нуль редагування, нуль diff на рівні слота), тобто рівно та регресія, від якої
#: захищається вся ця спека (розділ 4.4: «без валідатора система тихо деградує назад у
#: вільний HTML»). Дозволити `free` ту саму частку, що й `note` (60%), означало б узаконити
#: цю регресію, а не стримати її. Беремо третину від NOTE_FRACTION_CEILING: досить, щоб один
#: легітимний `free`-вузол пройшов у невеликому документі, замало, щоб `free` став дефолтною
#: стратегією замість добору типізованого вузла.
FREE_FRACTION_CEILING = 0.2  # == NOTE_FRACTION_CEILING / 3

#: Захист від однієї картки-мастодонта, що займе весь промпт сама. Не є критерієм зі спеки,
#: це наш власний запобіжник: без нього одна велика картка витіснила б решту нових карток
#: з контексту генерації.
CARD_TEXT_CAP = 600

#: Таймаут одного виклику CLI. Генерація однієї моделі — це не інтерактивний хід з
#: інструментами, тому й не потребує годинного вікна, яким живе runner.TURN_TIMEOUT.
CLI_TIMEOUT_SECONDS = 180

#: Поля, які НЕ несуть змісту для читача (службова розмітка вузла), тому виключені з
#: дайджесту картки, який іде моделі. Найкраще зусилля, не вичерпний список: краще
#: пропустити службове поле, ніж змусити модель продиратись крізь `"type":"note"` у
#: кожному рядку історії.
_DIGEST_SKIP_KEYS = {
    'type', 'tone', 'color', 'icon', 'id', 'key', 'src', 'lang', 'variant',
    'tag', 'state', 'kind', 'detail', 'by', 'hash', 'widgetType', 'span', 'n',
    'cols', 'poster', 'href', 'url',
}


class GenerationError(RuntimeError):
    """Виклик моделі провалився технічно (CLI впав, не автентифікований, таймаут).

    Окремо від `ss.SummaryError`: та каже «модель відповіла, але криво», ця каже
    «модель взагалі не відповіла». Обидві однаково йдуть у цикл ремонту (К16)."""


# ── Промпт для моделі. Англійською (економія токенів), зміст документа —
# українською: закритий словник, стеля глибини і форма слота беруться З ЖИВОГО summary_store,
# а не переписані тут руками, щоб промпт не розійшовся зі схемою, яка реально валідує. ─────

_ENVELOPE_EXAMPLE = json.dumps({
    'header': {'title': 'Коротка тема розмови',
               'subtitle': 'Одне речення про що саме ця розмова.'},
    'sections': [{
        'key': 'sec.example', 'title': 'Приклад секції',
        'items': [{'key': 'item.example', 'widgets': [
            {'type': 'note', 'title': 'Заголовок', 'body': 'Абзац з **інлайновою** розміткою.'},
        ]}],
    }],
    'retired': [],
}, ensure_ascii=False)

#: К47 few-shot: три ходи контракту збереження в ОДНІЙ відповіді. Приклад навмисно
#: показує те, чого не показує жоден інший: пункт-ПОСИЛАННЯ (`keep`) поруч зі звичайним
#: переписаним пунктом. Модель копіює форму з прикладу надійніше, ніж з абзацу прози.
_PRESERVE_EXAMPLE = json.dumps({
    'header': {'title': 'Тема', 'subtitle': 'Одне речення.'},
    'sections': [{
        'key': 'sec.decisions', 'title': 'Рішення', 'items': [
            {'key': 'dec.byok', 'keep': True},
            {'key': 'dec.voice', 'widgets': [
                {'type': 'note', 'title': 'Озвучка',
                 'body': 'Оновлено: рушій змінено на новий.'}]},
        ],
    }],
    'retired': ['dec.old-pricing'],
}, ensure_ascii=False)

#: К35/К36 few-shot (specs/chat-summary 8.3): a document that mixes kpi-strip, table and
#: grid/cell, the three structural shapes the diagnosis (8.1) found at 0% real usage.
#: A model copies a worked example far more reliably than it follows a prose instruction
#: (that is *why* this exists, not decoration) — but it only works if the example itself is
#: schema-correct, which is why TestPromptContract validates this exact tree against
#: `ss.validate_generation`, not just greps for substrings.
_GOOD_DOCUMENT_TREE = {
    'sections': [
        {'key': 'sec.metrics', 'title': 'Метрики', 'items': [
            {'key': 'item.kpi', 'widgets': [
                {'type': 'kpi-strip', 'items': [
                    {'value': '404', 'label': 'Реєстрацій', 'tone': 'blue'},
                    {'value': '61%', 'label': 'Хочуть облік клієнтів'},
                ]},
            ]},
        ]},
        {'key': 'sec.compare', 'title': 'Порівняння варіантів', 'items': [
            {'key': 'item.table', 'widgets': [
                {'type': 'table', 'cols': ['Варіант', 'Плюс', 'Мінус'], 'rows': [
                    [{'text': 'A'}, {'text': 'дешево', 'tone': 'green'}, {'text': 'повільно'}],
                    [{'text': 'B'}, {'text': 'швидко', 'tone': 'green'}, {'text': 'дорого', 'tone': 'red'}],
                ]},
            ]},
        ]},
        {'key': 'sec.canvas', 'title': 'Канва', 'items': [
            {'key': 'item.grid', 'widgets': [
                {'type': 'grid', 'cols': 2, 'children': [
                    {'type': 'cell', 'n': 1, 'title': 'Проблема', 'body': 'Коротко в чому біль.'},
                    {'type': 'cell', 'n': 2, 'title': 'Рішення', 'body': 'Коротко що робимо.'},
                ]},
            ]},
        ]},
    ],
}
_GOOD_DOCUMENT_EXAMPLE = json.dumps(_GOOD_DOCUMENT_TREE, ensure_ascii=False)

#: К45 few-shot (specs/chat-summary розділ 9, 9.1): SELECTION examples for the "free" node,
#: not schema examples — all trees below are equally schema-valid (`ss.validate_node` passes
#: on every one, proven by TestPresentationPromptStandard), which is exactly why the schema
#: validator alone cannot stop this misuse and the prompt has to carry good/bad pairs. The BAD
#: node is content a typed node already owns (a two-row price table). The two GOOD nodes are
#: NOT invented: they are the two content shapes an audit of five live channels
#: (work/free-node/audit.md) actually found with no typed home, each one currently either
#: flattened into a "note" paragraph (losing the shape) or dropped from the document outright:
#:   - a LOOP (a live channel, "Бартерний маховик колаборацій": 5 steps that feed back into the
#:     first one — "checklist"/"journey" both read as one-way progress, so the generated
#:     document had this as flat prose instead of a cycle).
#:   - a 2D POSITION (#startup90, a competitors quadrant on "клінічне/салонне" x "під-UA/не під
#:     UA": four items placed by two axes at once — no leaf holds an (x, y) pair, so the
#:     generated document dropped this content entirely, not even as prose).
_FREE_GOOD_LOOP_NODE = {
    'type': 'free', 'caption': 'Бартерний маховик колаборацій: кожен оберт додає ваги',
    'html': "<div class='loop'><!-- 5 steps feeding back into step 1: партнер з ЦА -> обмін "
            "Reels/Stories -> +аудиторія $0 бюджету -> більше ваги -> колаба з більшим "
            "блогером -> назад до кроку 1 --></div>",
}
_FREE_GOOD_QUADRANT_NODE = {
    'type': 'free', 'caption': 'Де сидить наш продукт: клінічне/салонне x під-UA/не під UA',
    'html': "<svg viewBox='0 0 200 200'><!-- 4 points on 2 axes: YClients/Altegio, Excel+Viber, "
            "US EMR, наш продукт alone in the empty clinical+under-UA corner --></svg>",
}
_FREE_BAD_NODE = {
    'type': 'free',
    'html': "<table><tr><th>Варіант</th><th>Ціна</th></tr><tr><td>A</td><td>$10</td></tr></table>",
}
_FREE_GOOD_LOOP_EXAMPLE = json.dumps(_FREE_GOOD_LOOP_NODE, ensure_ascii=False)
_FREE_GOOD_QUADRANT_EXAMPLE = json.dumps(_FREE_GOOD_QUADRANT_NODE, ensure_ascii=False)
_FREE_BAD_EXAMPLE = json.dumps(_FREE_BAD_NODE, ensure_ascii=False)
# Backward-compat aliases: the loop example is the primary GOOD example referenced by name.
_FREE_GOOD_NODE = _FREE_GOOD_LOOP_NODE
_FREE_GOOD_EXAMPLE = _FREE_GOOD_LOOP_EXAMPLE


# ── МОВА ЗМІСТУ ЗВЕДЕННЯ (Д5) ───────────────────────────────────────────────────────
# Тут свідомо НЕ мова інтерфейсу, і це не недогляд, а рішення.
#
# Поділ, який ми тримаємо по всьому беку: мова ІНТЕРФЕЙСУ керує хромою інтерфейсу і
# текстом, який модель пише ДЛЯ інтерфейсу (кнопки, картки помилок, відповідь у
# стрічку). Мова ЗМІСТУ керує текстом, ВИВЕДЕНИМ з уже наявного змісту. Зведення це
# другий випадок за визначенням: воно не відповідає людині, а конденсує рівно ті
# повідомлення, які в каналі вже лежать, разом з їхніми цитатами, назвами і рішеннями.
#
# Що було б, якби взяли мову інтерфейсу. Людина з українським каналом перемикає
# інтерфейс на англійську, і наступний фоновий прохід переписує аркуш англійською.
# Це не переклад, а ПЕРЕПИС: 'key' зведення живуть між генераціями, людські ручні
# правки приколоті до цих ключів (PRESERVATION CONTRACT нижче), і зміна мови змісту
# осиротила б їх усі до одної, при тому що жоден факт не змінився. Плюс цитати з
# української розмови поїхали б машинним перекладом назад у документ, який людина
# читає як першоджерело.
#
# Проводки мови сюди через це НЕ додано жодної: правильне джерело лежить у тому ж
# промпті, яким модель і так годують (історія повідомлень у _build_user_prompt), тому
# інструкція вказує на нього, а не на стан застосунку. Уже наявний аркуш при цьому
# сильніший за історію: це якір проти документа, зшитого з двох мов.
def _system_prompt():
    containers = ', '.join(sorted(ss.CONTAINERS))
    leaves = ', '.join(sorted(ss.LEAVES))
    slots = ', '.join(ss._SLOT_KEYS)
    vpc_roles = ', '.join(sorted(ss.VPC_ROLES))
    free_cap = ss.MAX_FREE_HTML_CHARS
    free_ceiling_pct = int(FREE_FRACTION_CEILING * 100)
    return f'''You are the background summary generator for a chat app (Logopsis). You read
chat history and produce a compact "sheet" document a human can scan in a few seconds
instead of scrolling the whole channel.

OUTPUT CONTRACT — return ONLY a single JSON object, nothing before or after it, no markdown
code fence:
{_ENVELOPE_EXAMPLE}

Top level: {{"header": {{...}}, "sections": [section, ...]}}. Each section:
{{"key", "title", "items": [item, ...]}}. Each item: {{"key", "widgets": [node, ...]}}. A
"widgets" array holds one or more top-level nodes (depth 1).

CLOSED NODE VOCABULARY — this is the whole set, do not invent a type outside it:
  CONTAINERS (may have a "children" array of nodes): {containers}
  LEAVES (never have "children", carry slot fields instead): {leaves}
An unknown type is REJECTED on write, not silently rendered as a fallback box, so use only
the types above.

DEPTH CEILING: {ss.MAX_DEPTH}. A node placed directly in "widgets" is depth 1; each nested
"children" level adds 1. A tree deeper than {ss.MAX_DEPTH} is rejected by name and depth, not
silently trimmed.

SLOT SHAPE: fields {slots} accept EITHER a plain string (inline markdown like **bold** is
fine) OR an array of strings for a bullet list. Never a nested object, never a number.

STRUCTURAL NODE SHAPES — the schema check only verifies that slot fields are strings, it does
NOT check these extra fields, so a wrong shape here does not get rejected, it just renders
BROKEN (an empty box, a caption nobody sees). These are the exact fields the renderer reads,
copy them literally:
  "kpi-strip":   {{"items": [{{"value", "label", "tone"?}}, ...]}}  — 2 to 6 headline numbers.
                 Do NOT use parallel "label"/"value" arrays on the node itself, the renderer
                 reads "items", nothing else.
  "fact-list":   {{"items": [{{"label", "value", "tone"?}}, ...]}}  — labeled pairs, any count.
  "checklist":   {{"items": [{{"text", "state"?: "done"|"blocked"|"progress", "note"?}}, ...]}}
  "table":       {{"cols": [string, ...], "rows": [[{{"text", "tone"?}} or a plain string, ...], ...]}}
  "grid":        {{"cols": <number of columns>, "children": [cell, ...]}} — a "cell" only makes
                 sense as a child of "grid".
  "cell":        {{"n"?, "title", "body", "span"?, "tone"?}} — "n" is the fill order (1, 2, 3…),
                 that is methodology (e.g. Lean Canvas numbering), not decoration, keep it.
  "axis":        {{"series": [{{"label", "from", "to", "tone"?}}, ...], "min"?, "max"?}} —
                 position is computed FROM "from"/"to" by the renderer, never invent a
                 pixel/percent value yourself.
  "quote":       {{"text", "author"?}} — the field is "author", NOT "caption".
  "avatar-card": {{"avatar", "name", "role", "text"}}
  "vpc":         {{"items": [{{"role": one of {vpc_roles}, "title"?, "points"?}}, ...]}} —
                 exactly one zone per role, zone body goes in "points", not "items".
  "journey":     {{"items": [{{"label", "value": <number, drives the curve position>, "action"?,
                 "barrier"?, "solution"?}}, ...], "min"?, "max"?}} — up to {ss.MAX_JOURNEY_STAGES}
                 stages, never add an "emoji" field, the curve point comes from "value".
  "free":        {{"html", "caption"?}} — raw markup, capped at {free_cap} characters, rendered
                 in an ISOLATED context with no access to the app. This is an exception, not a
                 normal choice — read the FREE NODE section below before reaching for it.

PRESENTATION STANDARD (mandatory, checkable — the same discipline this app already enforces on
its own chat feed, ported to this document's smaller 18-type vocabulary; specs/chat-summary
К35-К38). Measured proof of the failure mode this fixes: a real generated document used "note"
for 16 of 25 nodes and zero grids, zero tables, zero kpi-strips, while carrying a metrics
paragraph and a competitor comparison that both belonged in a structural node.
  1. DIVERSITY. A document with 3 or more sections must use at least 3 different leaf/container
     types (not counting "doc-header"); with 6 or more items across the document, at least 4.
     Using the same type five times still counts as one type.
  2. NUMBERS -> "kpi-strip" or "fact-list", never left sitting inside "note" prose. Any concrete
     metric, count, percentage or amount ("404 реєстрацій", "61%", "$120/рік") gets its own node.
  3. COMPARISON -> "table" or "grid", never a run of separate "note" leaves that only look alike
     because they share a heading pattern. Two or more comparable things side by side (options,
     competitors, before/after, a named-cell framework like Lean Canvas or SWOT) is a "table"
     (rows x cols) or a "grid" of "cell" children.
  4. TIME/SEQUENCE -> "axis". A set of dated or ordered intervals is a "series" on an "axis"
     node, not a paragraph spelling out dates.
  5. NO NOTE-ONLY DOCUMENTS. If every single item in your draft is a "note", that is a FAILED
     generation (К38), not a valid minimalist style: stop and check whether some of those notes
     are hiding numbers (rule 2), a comparison (rule 3) or a direct quote ("quote") that belongs
     in its own node instead.
  6. FREE NODES ARE CAPPED, NOT BANNED. "free" never counts toward the diversity requirement in
     rule 1: stacking "free" nodes cannot substitute for genuine structural variety. A document
     where more than {free_ceiling_pct}% of its nodes are "free" fails exactly like a note-only
     document (rule 5) and is rejected with the actual percentage. See the FREE NODE section
     below for what actually earns a "free" node.

GOOD DOCUMENT EXAMPLE (few-shot, shows the mix rules 1-3 above ask for; not a template to copy
verbatim, your sections and content must come from the actual chat history):
{_GOOD_DOCUMENT_EXAMPLE}

FREE NODE — WHEN TO USE IT (specs/chat-summary розділ 9, К45). Most conversation content has a
home in the closed vocabulary above: numbers, comparisons, sequences, lists and quotes all map
to a typed node (rules 2-4). "free" exists for the remaining shapes that genuinely do not,
because the SHAPE itself carries the meaning and a typed node would flatten it away. Two shapes
come up in real conversations often enough to name:
  - A LOOP: steps that feed back into their own start (a growth flywheel, a compounding cycle),
    not a one-way sequence. "checklist" and "journey" both read as linear progress, so forcing a
    loop into either drops the "this repeats and compounds" fact and leaves a flat step list.
  - A 2D POSITION: several things placed by two independent axes at once (a competitive map, a
    build-vs-buy plot). No typed leaf holds an (x, y) pair, so this content either turns into a
    paragraph of coordinates nobody can scan, or gets left out of the document entirely.
This is a SELECTION rule, not an availability rule: if the content is numbers, a comparison, a
sequence of steps, a plain list or a direct quote, it MUST go into the matching typed node above
(rules 2-4) — never into "free", even though "free" would technically accept it too. A typed
node stays addressable, editable and diffable the way "free" markup never can, so reach for
"free" only when no typed shape actually fits the content, not when a typed node feels like more
effort than a div.

GOOD use of "free" — a growth loop (no typed node holds a cycle that feeds back into itself):
{_FREE_GOOD_LOOP_EXAMPLE}
GOOD use of "free" — a 2D competitive position (no typed node holds an (x, y) pair):
{_FREE_GOOD_QUADRANT_EXAMPLE}
BAD use of "free" (do not do this — the SAME data belongs in a "table" node instead):
{_FREE_BAD_EXAMPLE}
Three named options with a price each is exactly what "table" (cols/rows) exists for; wrapping
the same data in raw HTML throws away addressing and editing for zero benefit.

STABLE KEYS — this is the most load-bearing rule. Every section and every item needs a
unique "key" (short, semantic, kebab-case, e.g. "dec.byok", not "item3" or a random id).
A human may have hand-edited content addressed by that exact key. If you keep the same key
across regenerations for a fact that is still true, the human's edit re-applies automatically.
If you rename the key while the underlying fact is unchanged, that edit is silently orphaned
even though nothing actually changed. Only give a fact a NEW key when it is a materially
different fact, not a rephrasing of the same one.

CONTENT LANGUAGE: every section title, item title/body/text and any other content field must
be written in THE LANGUAGE OF THE CHAT HISTORY you are reading, not in the language of this
prompt. Ukrainian messages give a Ukrainian sheet, English messages give an English sheet.
Mixed history: follow the language the HUMAN writes in, not the assistant. If an EXISTING
SHEET is shown to you below, it already fixes the choice: keep writing in its language, so
one document never ends up half in one language and half in another. Only the JSON field
names and node "type" values stay in English (they are schema, not content).

DOCUMENT TOPIC: always include the top-level "header" field, every time you build or update
the sheet. "title" is the short topic of this whole conversation (aim for at most ~60
characters), "subtitle" is one sentence describing what the conversation is actually about.
Both are written in the same CONTENT LANGUAGE as everything else. If the EXISTING
SUMMARY JSON shown to you below contains a section with key "{ss.HEADER_SECTION_KEY}" holding
an item "{ss.HEADER_ITEM_KEY}" of type "doc-header", that is the CURRENT topic and is shown
for your context only: never put it back inside your own "sections" array, express the
(possibly unchanged) topic only through the top-level "header" field, exactly once.

PRESERVATION CONTRACT — THE MOST IMPORTANT RULE IN THIS PROMPT. The sheet is a living
document that gets UPDATED. It is never retyped from memory and never rebuilt from a blank
page, not even on a full pass. Whenever a sheet already exists you are shown a COMPLETE MAP
of it (every section key, every item key, a short digest of each item) plus the FULL TEXT of
the items the new messages most likely touch. The map is complete by construction: if a key
is not in the map, it does not exist.

You have exactly three moves, and only three:
  1. KEEP — THE DEFAULT. An item you do not mention at all stays in the sheet exactly as it
     is, in its current section, with its current content. You do NOT have to retype an item
     in order to keep it. You MUST NOT retype an item from its short digest in the map: the
     digest is a few characters of a preview, not the item, and retyping it from the digest
     silently destroys the rest of that item. Silence means KEEP, never DROP.
     If you want to keep an item but move it, rename its section or change its position, put
     a REFERENCE in your output instead of the full item: {{"key": "dec.byok", "keep": true}}.
     The stored content is spliced in unchanged wherever you placed the reference.
  2. REWRITE — emit the item in full with THE SAME key. Your content replaces the old content
     of that key. This is how a claim that a newer message contradicts gets corrected: same
     key, new content. Not a second, contradicting item sitting next to the stale one.
  3. RETIRE — to remove an item you MUST name its key in the top-level "retired" array:
     {{"header": {{...}}, "sections": [...], "retired": ["old.key", ...]}}. This is the ONLY
     way an item can leave the sheet. Retiring is a deliberate editorial act ("this fact
     stopped being true", "this was merged into another item"), not a tool for keeping the
     document short. A generation that retires more than {int(RETIRE_FRACTION_CEILING * 100)}% of the existing items
     in a single pass is REJECTED and sent back to you with the numbers.

Example of all three moves at once (keep one item by reference, rewrite another, retire a
third):
{_PRESERVE_EXAMPLE}

Consequences worth stating plainly, because they are what usually goes wrong:
  - Your output does NOT have to contain the whole document. A short answer that references
     the untouched items and rewrites only what changed is the CORRECT answer, not a lazy one.
  - "The document is getting long" is not a reason to drop items. Retire what is no longer
     true; keep what still is.
  - A section you do not mention keeps the items that live in it. Items whose section you
     removed without retiring them are moved into a holding section, not deleted.

When asked to UPDATE an existing sheet: if a new message contradicts or supersedes an earlier
claim, REPLACE that claim in place (same key if the fact is the same topic) instead of adding
a second, contradicting note next to it. Do not just append.'''


SYSTEM_PROMPT = _system_prompt()


# ── Дайджест повідомлень: сирі widgets-картки -> компактний рядок для промпту ────────────

def _collect_strings(node, out):
    if isinstance(node, dict):
        for k, v in node.items():
            if k in _DIGEST_SKIP_KEYS:
                continue
            _collect_strings(v, out)
    elif isinstance(node, list):
        for v in node:
            _collect_strings(v, out)
    elif isinstance(node, str):
        s = node.strip()
        if s:
            out.append(s)


def _digest_message(msg, cap=CARD_TEXT_CAP):
    """Одна картка чату -> один рядок «[id] відправник: текст», обрізаний до `cap`.

    Найкраще зусилля: збирає всі рядкові значення з віджетів картки, крім службових
    полів (`_DIGEST_SKIP_KEYS`). Не претендує на ідеальний переказ 44 типів віджетів,
    лише на достатній контекст для генератора саммарі."""
    strings = []
    _collect_strings(msg.get('widgets'), strings)
    text = ' / '.join(strings) if strings else '(порожня картка)'
    if len(text) > cap:
        text = text[:cap] + '…'
    return f"[{msg.get('id')}] {msg.get('from') or '?'}: {text}"


def _messages_block(messages):
    if not messages:
        return '(немає карток)'
    return '\n'.join(_digest_message(m) for m in messages)


def _patched_item_keys(doc):
    """specs/chat-summary розділ 6 (найдорожчий ризик): ключі пунктів, на які стоїть
    ЖИВИЙ патч людини (`op` set/hide/freeze, тобто `target.item` заповнений).

    Замір `summary_reanchor_bench.py` на трьох живих каналах: 57 патчів, 31.6% осиротіло,
    і у ВСІХ 18 випадках причина дослівно «пункт зник з генерації». Ключі при цьому НЕ
    перейменовуються (перевірено окремо на chat-269: 11/11 ключів пережили ревізію) —
    пункт просто не влазив у стелю `_previous_summary_block`, бо вона різала хвіст дерева
    без розбору, і модель фізично не могла його побачити й відтворити. Ці ключі мусять
    лишатись видимими моделі незалежно від стелі нижче."""
    keys, seen = [], set()
    for p in doc.get('overlay', {}).get('patches', []):
        key = (p.get('target') or {}).get('item')
        if key is None:
            continue
        key = str(key)
        if key not in seen:
            seen.add(key)
            keys.append(key)
    return keys


def _extract_items_by_key(sections, keys):
    """Сирі пункти машини (з `hash`), чиї ключі входять у `keys`, у порядку появи в дереві."""
    if not keys:
        return []
    wanted = set(keys)
    return [it for s in (sections or []) for it in (s.get('items') or [])
            if str(it.get('key')) in wanted]


def _drop_items_by_key(sections, keys):
    """Ті самі секції без пунктів із `keys` — щоб пінений пункт не дублювався в
    непінованому хвості, який ще й ріжеться стелею."""
    if not keys:
        return sections
    drop = set(keys)
    return [{**s, 'items': [it for it in (s.get('items') or [])
                             if str(it.get('key')) not in drop]}
            for s in (sections or [])]


# ── К47: карта документа. Модель, яка не бачить ключ, не може його зберегти ─────────────
# Замір, з якого це виросло (chat-269, шість реальних ревізій): «переписано на місці» падає
# до 1 рівно на тих ревізіях, де найбільше ЗНИКЛО. Це не примха моделі, а механіка: стеля
# `PREV_SUMMARY_CHAR_CEILING` різала хвіст попереднього документа без розбору, і модель
# фізично не бачила ключа, який мала оновити, тому заводила поруч новий. Ліки не в тому,
# щоб підняти стелю (контекст не безмежний і ціна виклику реальна), а в тому, щоб розділити
# ДВІ різні речі: КАРТА документа (усі ключі, коротко) мусить бути повною завжди, ПОВНИЙ
# ТЕКСТ подається лише там, де він потрібен, і саме він живе під стелею.

_MAP_WORD_RE = re.compile(r'[^\W\d_]{4,}', re.UNICODE)


def _iter_items_with_section(sections):
    for s in sections or []:
        if not isinstance(s, dict):
            continue
        for it in (s.get('items') or []):
            if isinstance(it, dict):
                yield it, s.get('key')


def _strip_header_section(sections):
    """Службова секція теми (`sec.hdr`) не бере участі ні в карті, ні в збереженні, ні в
    підрахунку відставлених: тема живе власним шляхом (К31, `_with_header_section`), і якби
    вона потрапила сюди, то або дублювалась би, або рахувалась як «пункт, що зник»."""
    return [s for s in (sections or [])
            if isinstance(s, dict) and s.get('key') != ss.HEADER_SECTION_KEY]


def _item_text(item):
    strings = []
    _collect_strings(item.get('widgets'), strings)
    return ' '.join(' / '.join(strings).split())


def _item_types(item):
    types = []
    for w in (item.get('widgets') or []):
        _collect_node_types(w, types)
    out, seen = [], set()
    for t in types:
        if t not in seen:
            seen.add(t)
            out.append(t)
    return out


def _document_map(sections, digest_cap):
    lines = []
    for s in sections or []:
        if not isinstance(s, dict):
            continue
        title = (s.get('title') or '').strip()
        lines.append('# %s%s' % (s.get('key'), (' | ' + title) if title else ''))
        for it in (s.get('items') or []):
            if not isinstance(it, dict):
                continue
            line = '  - %s [%s]' % (it.get('key'), ','.join(_item_types(it)) or '-')
            if digest_cap:
                text = _item_text(it)
                if len(text) > digest_cap:
                    text = text[:digest_cap] + '…'
                if text:
                    line += ' ' + text
            lines.append(line)
    return '\n'.join(lines)


def _document_map_block(sections):
    """Карта ЗАВЖДИ повна за ключами. Коли вона не влазить у власний бюджет, коротшає
    ЗМІСТ кожного пункту (аж до нуля), а НЕ список ключів: пункт без дайджесту модель ще
    може зберегти посиланням `keep`, пункт без ключа — вже ніколи. Повертає
    `(текст, використаний_дайджест)`."""
    text = _document_map(sections, MAP_DIGEST_STEPS[0])
    for cap in MAP_DIGEST_STEPS:
        text = _document_map(sections, cap)
        if len(text) <= MAP_CHAR_BUDGET:
            return text, cap
    return text, MAP_DIGEST_STEPS[-1]


def _tokens(text):
    return {w.lower() for w in _MAP_WORD_RE.findall(text or '')}


def _relevance_order(sections, new_messages):
    """Порядок пунктів для ПОВНОГО тексту: спершу ті, яких нові картки найімовірніше
    стосуються. Лексичний перетин слів, а не ще один виклик моделі: дешево, детерміновано,
    його видно в тесті й воно не додає жодного токена до ціни генерації. Нормування на
    корінь довжини пункта тримає баланс: без нього довгий пункт вигравав би просто тим, що
    в ньому більше слів, а короткий влучний програвав би завжди."""
    msg_tokens = set()
    for m in new_messages or []:
        msg_tokens |= _tokens(_digest_message(m, cap=CARD_TEXT_CAP))
    scored = []
    for pos, (it, _sec) in enumerate(_iter_items_with_section(sections)):
        toks = _tokens(_item_text(it))
        score = (len(toks & msg_tokens) / (len(toks) ** 0.5)) if toks else 0.0
        scored.append((-score, pos, str(it.get('key'))))
    scored.sort()
    return [k for _s, _p, k in scored]


def _previous_summary_block(doc, new_messages=None):
    """К17 + К47 + розділ 6. Попередній документ іде моделі ДВОМА блоками з різними
    гарантіями, і саме цей поділ лагодить корінь проблеми.

    БЛОК 1, КАРТА (`_document_map_block`) — ПОВНА ЗАВЖДИ. Усі ключі секцій, усі ключі
    пунктів, типи вузлів і короткий дайджест змісту. Стеля символів її НЕ ріже: коли карта
    велика, коротшає дайджест кожного пункту, аж до нуля, але жоден ключ не зникає. Це
    прямий наслідок заміру (таблиця біля `PREV_SUMMARY_CHAR_CEILING`): на піку документа
    chat-269 модель бачила 11 ключів із 27 своїх, і саме на наступній ревізії зникло 26
    пунктів. Пункт, якого модель не бачить, для неї не існує.

    БЛОК 2, ПОВНИЙ ТЕКСТ — під стелею `PREV_SUMMARY_CHAR_CEILING`. Порядок: спершу пункти
    з живим людським патчем (`_patched_item_keys`, розділ 6: їх ріже не можна, бо на них
    висить робота людини), далі за лексичною близькістю до НОВИХ карток (`_relevance_order`):
    повний текст потрібен рівно там, де модель збирається щось міняти. Пункт, що не влiз,
    не «зник» — він у карті, і контракт збереження (`keep` за замовчуванням) дає моделі
    залишити його неторкнутим, НЕ переписуючи з дайджесту.

    Береться сирий шар машини (`generation`), а не `compose()`: у промпт іде те, за що
    документ ВІДПОВІДАЄ (факти), а не шар людських правок, який живе окремо (К8/К9).

    Повертає `(текст_блоку, список_пінених_ключів)`."""
    sections = _strip_header_section(doc['generation'].get('sections', []))
    if not sections:
        return None, []

    pinned_keys = [k for k in _patched_item_keys(doc)]
    items_by_key = {str(it.get('key')): it for it, _sec in _iter_items_with_section(sections)}
    pinned_present = [k for k in pinned_keys if k in items_by_key]

    map_text, digest_cap = _document_map_block(sections)

    def raw_len(key):
        return len(json.dumps(items_by_key[key], ensure_ascii=False)) + 2

    shown = list(pinned_present)
    used = sum(raw_len(k) for k in shown)
    # Розділ 6: пінені пункти показуються ПОВНІСТЮ навіть коли самі перекривають стелю —
    # стеля не піднімається наосліп, але й правку людини не ріже; переповнення називається
    # моделі прямим текстом, а не ховається.
    over_by_pinned = bool(shown) and used >= PREV_SUMMARY_CHAR_CEILING
    if not over_by_pinned:
        chosen = set(shown)
        for key in _relevance_order(sections, new_messages):
            if key in chosen:
                continue
            if used + raw_len(key) > PREV_SUMMARY_CHAR_CEILING:
                continue  # може, наступний, коротший, ще влізе — не break
            chosen.add(key)
            shown.append(key)
            used += raw_len(key)

    order = [k for k in items_by_key if k in set(shown)]
    full_items = [items_by_key[k] for k in order]
    hidden = [k for k in items_by_key if k not in set(shown)]

    parts = [
        'MAP OF THE EXISTING SHEET — complete, nothing is cut here. Every section and every '
        'item that exists right now. Format: "# <section key> | <section title>", then '
        '"  - <item key> [node types] <short digest of its content>". The digest is a '
        'PREVIEW, never the item itself: never retype an item from its digest.',
        map_text,
    ]
    if pinned_present:
        parts.append(
            '[ЦІ ПУНКТИ ПРАВИЛА ЛЮДИНА РУКАМИ, показані повністю незалежно від стелі: %s]'
            % ', '.join(pinned_present))
    parts.append(
        'FULL TEXT of %d of those %d items (JSON, exactly as stored), chosen as: everything '
        'a human hand-edited, then whatever the new messages are closest to.'
        % (len(full_items), len(items_by_key)))
    parts.append(json.dumps({'items': full_items}, ensure_ascii=False))
    if hidden:
        parts.append(
            '…[ПОВНИЙ ТЕКСТ ОБРІЗАНО стелею %d символів: решта %d пунктів подана вище лише '
            'в карті, з ключами. Це НЕ означає, що їх нема або що їх треба переписати з '
            'дайджесту: не згадуй їх у відповіді (тоді вони лишаться незмінними) або постав '
            'посилання {"key": "…", "keep": true}, якщо хочеш їх пересунути. Ключі: %s]'
            % (PREV_SUMMARY_CHAR_CEILING, len(hidden), ', '.join(hidden)))
    if over_by_pinned:
        parts.append(
            '…[СТЕЛЯ %d ПЕРЕВИЩЕНА САМИМИ ПРАВЛЕНИМИ ПУНКТАМИ: решта попереднього саммарі '
            'подана в цей виклик лише картою]' % PREV_SUMMARY_CHAR_CEILING)
    if digest_cap != MAP_DIGEST_STEPS[0]:
        parts.append('[карта звужена до %d символів на пункт: документ великий. Ключі всі '
                     'на місці, скорочений лише дайджест]' % digest_cap)
    return '\n'.join(parts), pinned_present


# ── К47/К48/К49: контракт збереження на шляху ЗАПИСУ, а не в проханні до моделі ─────────
# Той самий урок, що вже двічі довела ця спека (двоїння теми, розділ 7.5; бідна подача,
# розділ 8.1): інструкція в промпті це ПРОХАННЯ, і на ньому не можна тримати інваріант.
# Промпт каже моделі, що мовчання означає «лишити пункт», але ГАРАНТУЄ це не промпт, а код
# нижче: `_preserve_missing` повертає в документ усе, чого модель не згадала і не відставила
# явно, а `_retirement_ok` не пускає генерацію, яка відставляє надто велику частку одразу.


def _prev_items_index(prev_sections):
    """{ключ: (пункт, ключ_його_секції)} у порядку появи в документі."""
    out = {}
    for it, sec in _iter_items_with_section(prev_sections):
        out[str(it.get('key'))] = (it, sec)
    return out


def _retired_keys(parsed):
    """К48: список ключів, які модель ЯВНО відставляє. Криву форму не «розуміємо як могли»,
    а називаємо помилкою: тихе тлумачення зіпсованого `retired` означало б тихе видалення
    пунктів, тобто рівно те, від чого весь цей механізм і існує."""
    raw = parsed.get('retired') if isinstance(parsed, dict) else None
    if raw is None:
        return []
    if not isinstance(raw, list):
        raise ss.SummaryError(
            '"retired" мусить бути масивом ключів, прийшло %s' % type(raw).__name__)
    out, seen = [], set()
    for k in raw:
        if not isinstance(k, str) or not k.strip():
            raise ss.SummaryError('у "retired" мусять бути рядки-ключі, а не %r' % (k,))
        k = k.strip()
        if k not in seen:
            seen.add(k)
            out.append(k)
    return out


def _expand_keep_refs(sections, prev_items):
    """К47, хід 1: пункт-ПОСИЛАННЯ `{"key": ..., "keep": true}` розгортається у ПОВНИЙ
    збережений пункт зі старої генерації.

    Навіщо взагалі посилання, коли є мовчання: мовчання лишає пункт там, де він лежав, а
    посилання дає моделі пересунути/перевпорядкувати його, НЕ переписуючи зміст. Без цього
    будь-яка реорганізація вимагала б передрукувати весь документ — а саме передруковування
    під тиском довжини відповіді і є тим, через що документ стискався з 27 пунктів до 10.

    Пункт з непорожніми `widgets` це ПЕРЕЗАПИС, навіть якщо `keep` там теж стоїть: зміст,
    який модель справді написала, головніший за прапорець. Пункт без `widgets` і без
    відповідника в попередньому документі це помилка з іменем ключа, а не мовчазний
    порожній пункт, який відрендериться пусткою."""
    out, expanded = [], []
    for s in sections or []:
        if not isinstance(s, dict):
            out.append(s)
            continue
        items = []
        for it in (s.get('items') or []):
            if not isinstance(it, dict) or it.get('widgets'):
                items.append(it)
                continue
            key = str(it.get('key'))
            prev = prev_items.get(key)
            if prev is None:
                raise ss.SummaryError(
                    'пункт "%s" не має жодного вузла в "widgets" і не існує в попередньому '
                    'документі, тому зберігати нема чого: або віддай його зміст повністю, '
                    'або не згадуй його зовсім' % key)
            kept = copy.deepcopy(prev[0])
            kept.pop('hash', None)
            # Модель САМА поставила цей пункт сюди, тобто система його вже не «рятує»:
            # слід рятувальної операції на ньому був би неправдою.
            kept.pop('preserved', None)
            if isinstance(it.get('title'), str) and it['title'].strip():
                kept['title'] = it['title']
            items.append(kept)
            expanded.append(key)
        out.append(dict(s, items=items))
    return out, expanded


def _retirement_stats(prev_items, retired):
    known = [k for k in retired if k in prev_items]
    total = len(prev_items)
    return {'prev': total, 'retired': len(known), 'keys': known,
            'fraction': (len(known) / total) if total else 0.0}


def _retirement_ok(stats):
    return stats['fraction'] <= RETIRE_FRACTION_CEILING


def _retirement_error_message(stats):
    """К49: модель отримує назад ЧИСЛО і свої ж ключі, а не прохання «бережи зміст» — той
    самий принцип, що у К43 і в помилках `ss.SummaryError`."""
    return (
        'відставлено забагато: %d пунктів з %d (%.0f%%, стеля %.0f%%). Ключі: %s. Документ '
        'ОНОВЛЮЄТЬСЯ, а не переписується з нуля: пункт, який досі правдивий, лишай на місці '
        '(не згадуй його зовсім, або постав посилання {"key": "…", "keep": true}, якщо '
        'треба пересунути), а в "retired" лишай тільки те, що справді перестало бути правдою.'
        % (stats['retired'], stats['prev'], stats['fraction'] * 100,
           RETIRE_FRACTION_CEILING * 100, ', '.join(stats['keys'][:12]) or '—'))


def _base_from_previous(prev_sections, retired):
    """Порожній масив `sections` це ЗАКОННА відповідь: «у документі нічого не міняється».
    Промпт прямо каже, що коротка відповідь правильна, коли змінилось мало, тож нуль секцій
    це найкоротша з можливих. Без цієї гілки така відповідь зʼїдала б СТРУКТУРУ: жодної
    секції моделі не лишилось би, і `_preserve_missing` звалив би весь документ на поличку
    `sec.kept` однією купою. Тобто зміст ми б зберегли, а розкладку втратили, і це була б та
    сама втрата, тільки іншого сорту. Тому базою стає попередній документ як є, мінус явно
    відставлені пункти."""
    drop = set(retired or [])
    out = []
    for sec in copy.deepcopy(prev_sections or []):
        sec['items'] = [it for it in (sec.get('items') or [])
                        if str(it.get('key')) not in drop]
        out.append(sec)
    return out


def _preserve_missing(sections, prev_sections, retired):
    """К47, хід 1 як ГАРАНТІЯ: усе, чого модель не згадала і не відставила явно,
    повертається в документ незмінним.

    Куди повертається: у СВОЮ секцію, якщо модель її лишила (тоді пункт навіть візуально
    нікуди не дівався). Якщо секція зникла — у видиму поличку `sec.kept`, а не назад у
    відроджену секцію: реорганізація це право моделі, і воювати з нею тут не можна.

    Чого НЕ робить: не чіпає overlay (К5/К6 лишаються в силі), не міняє зміст пункта і не
    перераховує його hash (це зробить `write_generation` спільним циклом), тому патч
    людини перенакладається звичайним шляхом, наче пункт нікуди не зникав.

    Повертає `(sections, перенесені_ключі, пропущені_ключі)`. Пропущені (впертись у стелю
    секцій чи пунктів) НЕ ховаються: виклик-власник кладе їх у лог і в результат."""
    if not isinstance(sections, list):
        return sections, [], []
    present = {str(it.get('key')) for it, _sec in _iter_items_with_section(sections)}
    retired_set = set(retired or [])
    by_key = {s.get('key'): s for s in sections if isinstance(s, dict)}
    preserved, skipped = [], []
    shelf = by_key.get(ss.PRESERVED_SECTION_KEY)
    for it, origin in _iter_items_with_section(prev_sections):
        key = str(it.get('key'))
        if key in present or key in retired_set:
            continue
        target = by_key.get(origin)
        if target is None:
            if shelf is None:
                if len(sections) >= ss.MAX_SECTIONS:
                    skipped.append(key)
                    continue
                shelf = {'key': ss.PRESERVED_SECTION_KEY,
                         'title': ss.PRESERVED_SECTION_TITLE, 'items': []}
                sections.append(shelf)
                by_key[ss.PRESERVED_SECTION_KEY] = shelf
            target = shelf
        items = target.setdefault('items', [])
        if len(items) >= ss.MAX_ITEMS_PER_SECTION:
            skipped.append(key)
            continue
        kept = copy.deepcopy(it)
        kept.pop('hash', None)
        kept['preserved'] = True
        items.append(kept)
        preserved.append(key)
        present.add(key)
    return sections, preserved, skipped


def _build_user_prompt(mode, new_messages, prev_summary_block, pinned_keys=None):
    """К47 змінив і `full`, і `incremental`, і по-різному.

    `full` БЕЗ попереднього документа лишився тим, чим був: перша генерація каналу, чистий
    аркуш чесно означає чистий аркуш. `full` З попереднім документом більше не починається
    з нуля: він бачить і всю історію карток, і повну карту документа, і називається тим, чим
    він насправді є — РЕОРГАНІЗАЦІЄЮ. Раніше тут стояв `prev_block = None`, і саме цей рядок
    перетворював кожну пʼяту генерацію на переписування наосліп (chat-269, genRev 8: 10
    пунктів там, де було 27).

    `incremental` лишився оновленням, але його фінальна фраза змінилась на протилежну за
    сенсом. Було: «Return the FULL updated JSON object (the whole sheet...)» — тобто вимога
    передрукувати весь документ щоразу. Саме ця вимога і створювала тиск довжини відповіді,
    під яким модель стискала документ. Стало: поверни те, що змінюєш, а решту лиши мовчанням
    або посиланням."""
    msgs_block = _messages_block(new_messages)
    pinned_note = ''
    if pinned_keys:
        # specs/chat-summary розділ 6: дослівна інструкція, чому ці ключі не можна тихо
        # перейменувати чи викинути як «застарілий дубль» під час апдейту.
        pinned_note = (
            'HUMAN-EDITED KEYS: %s. A human hand-edited these exact items in the sheet below. '
            'If the underlying fact is still true, KEEP THE SAME KEY for it: do not rename it '
            'and do not drop it as a stale duplicate. Only remove one of these keys if that '
            'specific fact has genuinely stopped being true.\n\n' % ', '.join(pinned_keys)
        )
    if mode == 'full':
        if not prev_summary_block:
            return (
                'Build a fresh summary sheet from scratch for this chat channel.\n'
                'Full message history, chronological, one line per card as "[id] sender: text":\n'
                f'{msgs_block}\n\n'
                'Return only the JSON object described in the system prompt.'
            )
        return (
            'REORGANIZE the existing summary sheet below. This is a full pass: you are shown '
            'the WHOLE message history again, so you may restructure sections, merge items, '
            'rename section titles and move things around freely.\n'
            'A full pass is permission to RE-PLACE what the sheet already holds. It is NOT '
            'permission to forget it, and it is NOT a request to retype it. The PRESERVATION '
            'CONTRACT holds here exactly as it does on an incremental update: an item you do '
            'not mention stays as it is, an item you want to move goes in as '
            '{"key": "…", "keep": true}, and an item leaves the sheet only by being named in '
            '"retired".\n\n'
            f'{pinned_note}'
            f'EXISTING SHEET:\n{prev_summary_block}\n\n'
            'FULL MESSAGE HISTORY, chronological, one line per card as "[id] sender: text":\n'
            f'{msgs_block}\n\n'
            'Return the JSON object: the sections as you want them arranged (full items for '
            'what you write or rewrite, {"key": …, "keep": true} references for what you only '
            'move), plus "retired" for whatever genuinely stopped being true.'
        )
    return (
        'Update the existing summary sheet below to account for the new messages that arrived '
        'after it was generated.\n\n'
        f'{pinned_note}'
        f'EXISTING SHEET:\n{prev_summary_block}\n\n'
        'NEW MESSAGES since that summary, one line per card as "[id] sender: text":\n'
        f'{msgs_block}\n\n'
        'Return the JSON object with what you CHANGE: full items for anything you add or '
        'rewrite, {"key": "…", "keep": true} references only where you need to move or '
        'reorder something, and "retired" for anything that genuinely stopped being true. '
        'Everything you do not mention stays in the sheet unchanged, so a short answer is '
        'the correct answer when little changed.'
    )


def _repair_prompt(original_user_prompt, error_text, raw_reply=None):
    """К16: модель отримує ТЕКСТ помилки валідатора і повертається до тієї самої
    задачі. Кожна спроба — окремий однокроковий виклик (`--no-session-persistence`),
    тому повний контекст (оригінальний промпт + що саме було не так) переноситься
    руками, а не через памʼять сесії."""
    bad = f'\n\nYour previous raw reply was:\n{raw_reply[:2000]}' if raw_reply else ''
    return (
        f'{original_user_prompt}\n\n'
        '--- REPAIR ---\n'
        'Your previous answer was REJECTED by the schema validator with this exact error:\n'
        f'{error_text}{bad}\n'
        'Fix exactly that problem and return ONLY the corrected full JSON object. '
        'No prose, no markdown code fence.'
    )


# ── Екстракція JSON з відповіді моделі: стійка до чужого тексту навколо ──────────────────
# Живий прогін довів, що навіть з --system-prompt user-рівневий ~/.claude/CLAUDE.md
# долітає окремим system-reminder і модель МОЖЕ обрамити відповідь поясненням чи
# markdown-огорожею попри пряму заборону в промпті. Тому парсер не вірить, що вся
# відповідь — рівно JSON, а вміє витягти перший збалансований {...} з чого завгодно.

def _first_balanced_object(text):
    start = text.find('{')
    if start == -1:
        raise ValueError('no opening { found')
    depth = 0
    in_str = False
    esc = False
    for i in range(start, len(text)):
        c = text[i]
        if in_str:
            if esc:
                esc = False
            elif c == '\\':
                esc = True
            elif c == '"':
                in_str = False
            continue
        if c == '"':
            in_str = True
        elif c == '{':
            depth += 1
        elif c == '}':
            depth -= 1
            if depth == 0:
                return text[start:i + 1]
    raise ValueError('unbalanced braces, no closing } for the first {')


def _extract_json(raw):
    text = (raw or '').strip()
    if not text:
        raise ValueError('empty model reply')
    candidates = []
    fence = re.search(r'```(?:json)?\s*(.*?)```', text, re.DOTALL)
    if fence:
        candidates.append(fence.group(1).strip())
    candidates.append(text)
    last_err = None
    for cand in candidates:
        try:
            return json.loads(cand)
        except Exception as e:
            last_err = e
        try:
            return json.loads(_first_balanced_object(cand))
        except Exception as e:
            last_err = e
    raise ValueError(f'no valid JSON object found in model reply: {last_err}')


# ── Виклик моделі: сирий `claude -p`, той самий бінарник і той самий спосіб резолвити
# модель, яким уже керує agent_worker.py. Нового способу тримати ключі тут немає: сесія
# claude CLI на машині — вже автентифікована, ідентична решті Logopsis. ────────────────

def _invoke_claude_cli(system_prompt, user_prompt, model):
    if runner is None:
        raise GenerationError('runner module unavailable: cannot resolve the claude CLI')
    cmd = [runner.CLAUDE_BIN, '-p', user_prompt,
           '--system-prompt', system_prompt,
           *runner._resolve_model_args(model),
           '--tools', '',                 # генератору не треба жодного інструмента
           '--strict-mcp-config',         # і жодного MCP-сервера (перевірено: $0.147 -> $0.003)
           '--output-format', 'json',
           '--no-session-persistence']
    try:
        r = subprocess.run(cmd, cwd=tempfile.gettempdir(), capture_output=True,
                           text=True, timeout=CLI_TIMEOUT_SECONDS)
    except subprocess.TimeoutExpired as e:
        raise GenerationError(f'claude CLI timed out after {CLI_TIMEOUT_SECONDS}s: {e}')
    except Exception as e:
        raise GenerationError(f'claude CLI failed to start: {e}')
    if r.returncode != 0:
        raise GenerationError(
            f'claude CLI exited {r.returncode}: {(r.stderr or "").strip()[:500]}')
    try:
        data = json.loads(r.stdout)
    except Exception as e:
        raise GenerationError(
            f'claude CLI did not return a JSON envelope: {e}: {r.stdout[:300]!r}')
    if data.get('is_error'):
        raise GenerationError(f'claude CLI reported an error turn: {data.get("result")}')
    return data.get('result') or ''


def _last_json_object(stdout):
    """`agy --output-format json` пише зазвичай РІВНО один рядок компактного JSON, але
    живий зонд показав виняток: коли headless-режим автоматично забороняє спробу
    інструмента, ПЕРЕД JSON-об'єктом стоїть діагностичний рядок
    (`jetski: no output produced — a tool required the "command" permission ...`).
    Об'єкт завжди лишається ОСТАННІМ непорожнім рядком stdout, тому шукаємо саме
    його, з кінця, а не довіряємо, що весь stdout — рівно JSON (та сама обережність,
    що і в `_extract_json` нижче для тексту відповіді моделі)."""
    for line in reversed((stdout or '').strip().splitlines()):
        line = line.strip()
        if not line:
            continue
        try:
            data = json.loads(line)
        except Exception:
            continue
        if isinstance(data, dict):
            return data
    return None


def _invoke_agy_cli(system_prompt, user_prompt, channel):
    """Симетрично до `_invoke_claude_cli`, для каналів на провайдері 'antigravity'
    (`runner.channel_provider`). Живий зонд (`agy --help`, CLI встановлений на цій
    машині) підтвердив форму відповіді і дві розбіжності з Claude-гілкою:

    1. РОЗДІЛЬНОГО СИСТЕМНОГО ПРОМПТУ НЕМАЄ. `agy --help` не має ані
       `--system-prompt`, ані `--append-system-prompt` — жодного аналога. Єдиний
       спосіб — покласти системний і користувацький текст одним рядком у `-p`.
    2. ВІДПОВІДІ. `agy` підтримує `--output-format json` напряму (не лише
       `stream-json`, яким кермує жива стрічка чату в `runner.run_agy_stream`): живий
       виклик віддає один компактний JSON-рядок `{"status": "SUCCESS"|"ERROR"|
       "CANCELED", "response": "...", "error"?: "...", "usage": {...}}` — контракт,
       який для нашого одноразового структурованого виклику простіший і симетричніший
       до Claude-гілки, ніж розбір NDJSON-подій стріму. `status` перевіряється явно:
       ERROR/CANCELED з порожнім `response` не проходять мовчки.

    ВІДПОВІДНИКА `--tools '' --strict-mcp-config` В AGY НЕМАЄ (перевірено: `agy --help`
    не має жодного прапорця, що вимикає інструменти чи MCP на один хід; є лише
    `--dangerously-skip-permissions`, який навпаки ДОЗВОЛЯЄ їх без питань, і
    `--sandbox`, який підміняє запис підробленою текою, а не забороняє дію —
    reference_agy_headless_flags_gotcha). Найближчий доступний еквівалент —
    НЕ передавати жодного з них: без `--add-dir` інструмент читання/запису файлів
    працює в чужій scratch-теці (не в репозиторії), а без
    `--dangerously-skip-permissions` headless-режим fail-closed: спробу виклику
    інструмента автоматично забороняє замість виконання (живий зонд:
    `status` стає `"CANCELED"`, а не зависання). Це ЗАХИЩАЄ від випадкового
    інструмента, але НЕ економить токени системного контексту так, як прапорці
    Claude, бо жодного прапорця для цього просто немає — оверхед залежить від
    поточного ГЛОБАЛЬНОГО реєстру MCP-серверів agy (`agy mcp add/list/remove`),
    а не від чогось, чим керує один виклик. Живий доказ того самого дня
    (2026-09-08): на момент написання цього коду `agy mcp list` показував «No
    MCP servers configured», а за лічені хвилини, поки в цій же сесії
    паралельно йшла інша задача (реєстрація logopsis MCP для agy), той самий
    `agy mcp list` став показувати `logopsis enabled` — і той самий зонд-виклик
    («PONG») зріс з 11048 до 12131 вхідних токенів (+10%, `usage.input_tokens`,
    живий прогін). Ризик не гіпотетичний і не залежить від нас: БУДЬ-ЯКА
    майбутня реєстрація MCP-сервера для agy (своя чи чужа задача) тихо додає
    вартість до КОЖНОЇ генерації саммарі на antigravity-каналах, і жоден
    прапорець тут це не спинить — на відміну від Claude-гілки, яка захищена
    `--strict-mcp-config` назавжди, незалежно від того, скільки MCP-серверів
    зареєстровано глобально для Claude Code."""
    if runner is None or not runner.AGY_BIN:
        raise GenerationError('runner.AGY_BIN unavailable: agy CLI not installed')
    model_id = runner.agy_model_for(runner._agy_alias(channel))
    cmd = [runner.AGY_BIN, '-p', f'{system_prompt}\n\n{user_prompt}',
           '--output-format', 'json',
           '--print-timeout', f'{CLI_TIMEOUT_SECONDS}s']
    if model_id:
        cmd += ['--model', model_id]
    try:
        r = subprocess.run(cmd, cwd=tempfile.gettempdir(), capture_output=True,
                           text=True, timeout=CLI_TIMEOUT_SECONDS)
    except subprocess.TimeoutExpired as e:
        raise GenerationError(f'agy CLI timed out after {CLI_TIMEOUT_SECONDS}s: {e}')
    except Exception as e:
        raise GenerationError(f'agy CLI failed to start: {e}')
    if r.returncode != 0:
        raise GenerationError(
            f'agy CLI exited {r.returncode}: {(r.stderr or "").strip()[:500]}')
    data = _last_json_object(r.stdout)
    if data is None:
        raise GenerationError(f'agy CLI did not return a JSON envelope: {r.stdout[:300]!r}')
    status = str(data.get('status') or '').upper()
    if status != 'SUCCESS':
        raise GenerationError(
            f'agy CLI reported {status or "unknown"} status: '
            f'{(data.get("error") or "").strip()[:500]}')
    return data.get('response') or ''


def _resolve_provider(channel, root):
    """Двигун каналу: 'claude' (дефолт) | 'antigravity', тим самим шляхом і тим самим
    застереженням, що й `_resolve_model` (файл каналу — `runner.channel_provider` —
    живе поза нашим `root`, тому цей шлях працює тільки для СПРАВЖНЬОГО каналу,
    root=None; тести з фейковим `root` завжди отримують дефолт 'claude', якщо явно
    не підмінили `runner` самі, щоб перевірити саме маршрутизацію)."""
    if root is None and runner is not None:
        try:
            return runner.channel_provider(channel)
        except Exception:
            pass
    return 'claude'


def _resolve_model(channel, root):
    """Модель каналу, тим самим шляхом, що й будь-який інший хід Logopsis. Файл каналу
    живе поза `root` (він у `runner.CHANNELS_DIR`, не у нашому storage `root`), тому цей
    шлях працює тільки для СПРАВЖНЬОГО каналу (root=None); тести завжди підміняють
    `model_call` і сюди не заходять."""
    if root is None and runner is not None:
        try:
            return runner.channel_model(channel)
        except Exception:
            pass
    return 'sonnet'


def _default_log(msg):
    if runner is not None:
        try:
            runner.log('summary_generate:', msg)
            return
        except Exception:
            pass
    print(f'[summary_generate] {msg}')


# ── Тема документа (К31, К34): "header" з відповіді моделі -> звичайний пункт `hdr` ──────

def _previous_header_item(sections):
    """Пункт теми з ПОПЕРЕДНЬОЇ генерації, якщо він там був (К31: тема живе звичайним
    пунктом `hdr` у секції `sec.hdr`)."""
    for sec in (sections or []):
        if not isinstance(sec, dict) or sec.get('key') != ss.HEADER_SECTION_KEY:
            continue
        for it in (sec.get('items') or []):
            if isinstance(it, dict) and str(it.get('key')) == ss.HEADER_ITEM_KEY:
                keep = copy.deepcopy(it)
                keep.pop('hash', None)
                return keep
    return None


def _build_header_item(header, previous=None):
    """К31: `header` опційний. Відсутність (`None`) не помилка — теми просто немає (К34),
    заглушки бути не може. Якщо модель щось повернула, `title` не може бути порожнім: це
    криве дерево, і воно йде в той самий цикл ремонту (К16), що й помилки в `sections`.

    К48 (доданий 2026-09-11): «теми немає» і «модель забула прислати тему» це РІЗНІ події,
    і плутати їх не можна. Коли тема вже була, а нова відповідь мовчить, діє той самий
    контракт збереження, що й для звичайних пунктів: мовчання означає ЗБЕРЕГТИ. Інакше
    найстабільніший ключ документа (`hdr`, єдиний, що не залежить від примхи моделі) губив
    би зміст саме тоді, коли решта документа вже захищена, і правка теми руками (К33)
    сиротіла б на рівному місці. `previous is None` (перша генерація каналу) лишає стару
    поведінку слово в слово: теми немає, заглушки не буде."""
    if header is None:
        return previous
    if not isinstance(header, dict):
        raise ss.SummaryError('header мусить бути обʼєктом, прийшло %s' % type(header).__name__)
    title = header.get('title')
    if not isinstance(title, str) or not title.strip():
        raise ss.SummaryError('header.title не може бути порожнім')
    subtitle = header.get('subtitle')
    if subtitle is not None and not isinstance(subtitle, str):
        raise ss.SummaryError('header.subtitle мусить бути рядком')
    widget = {'type': 'doc-header', 'title': title}
    if subtitle:
        widget['subtitle'] = subtitle
    return {'key': ss.HEADER_ITEM_KEY, 'widgets': [widget]}


def _demote_stray_headers(sections, topic_title=None):
    """`doc-header` існує в документі РІВНО в одному місці: пункт `hdr` у секції `sec.hdr`.

    Привід заміряний на живому каналі chat-269: після введення теми (К31) документ мав ДВА
    вузли `doc-header` з однаковим заголовком, і на екрані тема була надрукована двічі
    підряд. Другий приїхав не з примхи моделі, а з ІСТОРІЇ: пункт існував ще з тих часів,
    коли тему клали руками всередину секції стану, і інкрементальна генерація чесно
    перенесла його далі.

    Тому лагодимо детерміновано, а не інструкцією в промпті: інструкція це прохання, і на
    пункті, який модель бачить у попередньому саммарі як даність, вона його не виконує.
    Чужий `doc-header` знижується до `note`, а не викидається: `status` і `meta` там несуть
    зміст, якого більше ніде немає. Заголовок, що дублює тему, при цьому не переїжджає,
    інакше дубль лишився б, просто іншим шрифтом."""
    if not isinstance(sections, list):
        return sections
    topic = (topic_title or '').strip()
    out = []
    for s in sections:
        if not isinstance(s, dict) or s.get('key') == ss.HEADER_SECTION_KEY:
            out.append(s)
            continue
        items = []
        for it in (s.get('items') or []):
            if not isinstance(it, dict):
                items.append(it)
                continue
            widgets = []
            for w in (it.get('widgets') or []):
                if not isinstance(w, dict) or w.get('type') != 'doc-header':
                    widgets.append(w)
                    continue
                title = (w.get('status') or '').strip()
                own = (w.get('title') or '').strip()
                if not title and own and own != topic:
                    title = own
                body = [x for x in ((w.get('subtitle') or '').strip(),
                                    (w.get('meta') or '').strip()) if x]
                if not title and not body:
                    continue  # нічого, крім дубля теми: тихо зникає разом з ним
                note = {'type': 'note'}
                if title:
                    note['title'] = title
                if body:
                    note['body'] = body if len(body) > 1 else body[0]
                widgets.append(note)
            if widgets:
                items.append(dict(it, widgets=widgets))
        out.append(dict(s, items=items))
    return out


def _with_header_section(sections, header_item):
    """К31: тема лягає в генерацію як звичайний пункт, не як окреме поле поза сховищем.
    Кладемо його в окрему секцію з фіксованим ключем (`ss.HEADER_SECTION_KEY`), не першим
    пунктом першої секції моделі — обґрунтування біля самої константи в summary_store.py."""
    if not isinstance(sections, list):
        return sections  # невалідне саме по собі: validate_generation дасть точну причину
    topic = None
    if isinstance(header_item, dict):
        for w in (header_item.get('widgets') or []):
            if isinstance(w, dict) and w.get('type') == 'doc-header':
                topic = w.get('title')
                break
    sections = _demote_stray_headers(sections, topic)
    if header_item is None:
        return sections
    return [{'key': ss.HEADER_SECTION_KEY, 'items': [header_item]}] + list(sections)


# ── К43: замір подачі дерева, що вже пройшло схему ──────────────────────────────────────
# specs/chat-summary 9.1: інструкція в промпті (К35-К38) це ПРОХАННЯ і на ньому не можна
# тримати інваріант (той самий урок, що з темою документа, розділ 7.5). Тому подача
# перевіряється тут ДЕТЕРМІНОВАНО, тим самим циклом ремонту, що вже ловить криву схему.

#: Службова шапка не контент: не рахується ні в різноманітті, ні в частці `note`, так
#: само, як промпт (PRESENTATION STANDARD, rule 1) не рахує її в diversity.
_PRESENTATION_EXCLUDED_TYPES = {'doc-header'}

#: К45: `free` рахується у `total` (і тому впливає на `note_fraction`/`free_fraction`, як
#: будь-який інший реальний вузол документа), але НІКОЛИ не рахується внеском у `distinct`
#: (різноманіття, rule 1 промпту). Без цього винятку модель могла б підмінити бракуючий
#: СПРАВЖНІЙ структурний тип купою `free`-вузлів: вони мають один спільний `type`, тож самі
#: по собі додали б лише ОДНЕ значення до множини типів, але цього одного значення досить,
#: щоб штучно дотягнути `distinct` до порогу без жодного реального різноманіття. Виняток тут
#: не про підрахунок, а про заборону: `free` не визнається «структурним» вузлом для цієї
#: метрики в принципі, скільки б разів він не зустрівся.
_DIVERSITY_EXCLUDED_TYPES = {'free'}


def _collect_node_types(node, out):
    """Рекурсивно збирає `type` вузла і всіх його дітей (контейнер+листок, будь-яка
    глибина до стелі К2), крім `_PRESENTATION_EXCLUDED_TYPES`."""
    if not isinstance(node, dict):
        return
    t = node.get('type')
    if t and t not in _PRESENTATION_EXCLUDED_TYPES:
        out.append(t)
    kids = node.get('children')
    if isinstance(kids, list):
        for k in kids:
            _collect_node_types(k, out)


def _presentation_stats(sections):
    """К43/К45: подача дерева, що вже пройшло `ss.validate_generation`. Той самий обхід
    (контейнери + діти), яким заміряно числа розділу 9.1, застосований до КОНКРЕТНОГО
    дерева-кандидата, а не до всього каналу.

    `distinct` рахується БЕЗ `_DIVERSITY_EXCLUDED_TYPES` (тобто без `free`): `free` лишається
    в `total`/`note_fraction`/`free_fraction` як будь-який інший реальний вузол, але не має
    права підмінити собою бракуючий структурний тип у вимозі різноманіття."""
    types = []
    for s in sections or []:
        for it in (s.get('items') or []):
            for w in (it.get('widgets') or []):
                _collect_node_types(w, types)
    total = len(types)
    note = sum(1 for t in types if t == 'note')
    free = sum(1 for t in types if t == 'free')
    distinct_types = {t for t in types if t not in _DIVERSITY_EXCLUDED_TYPES}
    return {'total': total, 'distinct': len(distinct_types), 'note': note, 'free': free,
            'note_fraction': (note / total) if total else 0.0,
            'free_fraction': (free / total) if total else 0.0}


def _presentation_ok(stats):
    return (stats['distinct'] >= MIN_DISTINCT_NODE_TYPES
            and stats['note_fraction'] <= NOTE_FRACTION_CEILING
            and stats['free_fraction'] <= FREE_FRACTION_CEILING)


def _presentation_error_message(stats):
    """К43/К45: модель отримує назад ЧИСЛО, не прохання «зроби різноманітніше» — той самий
    принцип, що й у помилках `ss.SummaryError` (розробник бачив би те саме)."""
    return (
        'подача бідна: %d різних типів вузлів (мінімум %d), частка "note" %.0f%% (стеля %.0f%%), '
        'частка "free" %.0f%% (стеля %.0f%%)'
        % (stats['distinct'], MIN_DISTINCT_NODE_TYPES,
           stats['note_fraction'] * 100, NOTE_FRACTION_CEILING * 100,
           stats['free_fraction'] * 100, FREE_FRACTION_CEILING * 100))


def _better_presentation(a, b):
    """К44: порядок кандидатів для запобіжника — більше різних типів перше, менша
    частка `note` як другий тайбрейк, менша частка `free` як третій ("найбільше типів /
    найменше note / найменше free")."""
    if a['distinct'] != b['distinct']:
        return a['distinct'] > b['distinct']
    if a['note_fraction'] != b['note_fraction']:
        return a['note_fraction'] < b['note_fraction']
    return a['free_fraction'] < b['free_fraction']


# ── Цикл ремонту (К16, розширений К43/К44) ──────────────────────────────────────────────

def _run_with_repair(channel, model_call, user_prompt, log_fn, prev_sections=None,
                     prev_header_section=None):
    """Повертає (sections, attempts, error, presentation_ok, preserve_meta).

    `sections is None` означає повний провал: жоден із `MAX_GENERATION_ATTEMPTS` не дав
    дерева, яке проходить `validate_generation`. Якщо схема пройдена, але подача (К43)
    бідна на кожній спробі, К44-запобіжник повертає НАЙКРАЩЕ з отриманих схема-валідних
    дерев (`presentation_ok=False`) замість повного провалу; `error` при цьому `None`,
    бо документ таки записується.

    К47/К48/К49 вбудовані в ТОЙ САМИЙ цикл, а не в окремий прохід: відповідь моделі
    послідовно проходить розгортання посилань `keep`, запобіжник на частку відставлених і
    повернення незгаданих пунктів, і ЛИШЕ потім іде в `validate_generation` та в перевірку
    подачі. Порядок саме такий, бо кожен наступний крок працює з деревом, яке вже зібране:
    рахувати «скільки пунктів зникло» до розгортання посилань означало б рахувати чужі
    числа, а валідувати до повернення пунктів означало б валідувати не той документ, що
    ляже на диск.

    `prev_sections` вже без службової секції теми (`_strip_header_section`): тема живе
    власним шляхом і в цих трьох механізмах не бере участі."""
    convo = user_prompt
    last_error = None
    best = None  # (stats, sections, meta) — найкращий схема-валідний кандидат для К44
    prev_items = _prev_items_index(prev_sections or [])
    prev_header = _previous_header_item(prev_header_section)
    for attempt in range(1, MAX_GENERATION_ATTEMPTS + 1):
        raw = None
        try:
            raw = model_call(SYSTEM_PROMPT, convo)
        except Exception as e:
            last_error = f'model call failed: {e}'
            log_fn(f'{channel}: attempt {attempt}/{MAX_GENERATION_ATTEMPTS} — {last_error}')
            convo = _repair_prompt(user_prompt, last_error)
            continue
        try:
            parsed = _extract_json(raw)
        except Exception as e:
            last_error = f'model reply is not valid JSON: {e}'
            log_fn(f'{channel}: attempt {attempt}/{MAX_GENERATION_ATTEMPTS} — {last_error}')
            convo = _repair_prompt(user_prompt, last_error, raw)
            continue
        raw_sections = parsed.get('sections') if isinstance(parsed, dict) else None
        header = parsed.get('header') if isinstance(parsed, dict) else None
        meta = {'preserved': [], 'retired': [], 'kept': [], 'skipped': []}
        try:
            if not isinstance(raw_sections, list):
                # Порожній масив секцій — законна відповідь (усе лишається як було, К47);
                # ВІДСУТНІЙ масив — ні: тоді збереження підмінило б провал моделі тихою
                # копією старого документа, і провал ніхто б не побачив.
                raise ss.SummaryError('відповідь мусить мати масив "sections"')
            retired = _retired_keys(parsed)
            header_item = _build_header_item(header, prev_header)
            if not raw_sections and prev_sections:
                sections, kept_refs = _base_from_previous(prev_sections, retired), []
            else:
                sections, kept_refs = _expand_keep_refs(raw_sections, prev_items)
            retire_stats = _retirement_stats(prev_items, retired)
            if not _retirement_ok(retire_stats):
                raise ss.SummaryError(_retirement_error_message(retire_stats))
            sections, preserved, skipped = _preserve_missing(
                sections, prev_sections or [], retired)
            meta = {'preserved': preserved, 'retired': retire_stats['keys'],
                    'kept': kept_refs, 'skipped': skipped}
            sections = _with_header_section(sections, header_item)
            ss.validate_generation({'sections': sections})
        except ss.SummaryError as e:
            last_error = str(e)
            log_fn(f'{channel}: attempt {attempt}/{MAX_GENERATION_ATTEMPTS} — '
                   f'validate_generation refused: {last_error}')
            convo = _repair_prompt(user_prompt, last_error, raw)
            continue

        if meta['preserved'] or meta['skipped']:
            log_fn('%s: К47 збережено %d незгаданих пунктів%s'
                   % (channel, len(meta['preserved']),
                      (', НЕ влізло %d (стеля секцій/пунктів): %s'
                       % (len(meta['skipped']), ', '.join(meta['skipped'][:10])))
                      if meta['skipped'] else ''))
        stats = _presentation_stats(sections)
        if best is None or _better_presentation(stats, best[0]):
            best = (stats, sections, meta)
        if not _presentation_ok(stats):
            last_error = _presentation_error_message(stats)
            log_fn(f'{channel}: attempt {attempt}/{MAX_GENERATION_ATTEMPTS} — '
                   f'К43 refused: {last_error}')
            convo = _repair_prompt(user_prompt, last_error, raw)
            continue

        return sections, attempt, None, True, meta

    if best is not None:
        stats, sections, meta = best
        log_fn(f'{channel}: поріг подачі (К43) не взято за {MAX_GENERATION_ATTEMPTS} спроб, '
               f'запобіжник (К44) бере найкращу версію: {stats["distinct"]} типів '
               f'(мінімум {MIN_DISTINCT_NODE_TYPES}), note {stats["note_fraction"] * 100:.0f}% '
               f'(стеля {NOTE_FRACTION_CEILING * 100:.0f}%)')
        return sections, MAX_GENERATION_ATTEMPTS, None, False, meta

    return None, MAX_GENERATION_ATTEMPTS, last_error, None, None


# ── К20: одна генерація на канал одночасно ────────────────────────────────────────────
# Сервер багатопотоковий (socketserver.ThreadingTCPServer, один процес), тому замок у
# памʼяті процесу, а не файл-лок, — правильний і достатній інструмент: другий потік, що
# прийшов, поки перший генерує, БЛОКУЄТЬСЯ на тому самому замку, а щойно перший записав
# нову генерацію — перечитує стан і бачить «нових карток немає», тобто повертає щойно
# зроблений результат замість того, щоб запускати другий виклик моделі. Ніякого окремого
# «чи вже йде генерація» прапорця не треба: double-checked freshness під замком дає той
# самий ефект простіше.
_locks = {}
_locks_guard = threading.Lock()


def _channel_lock(channel):
    with _locks_guard:
        lock = _locks.get(channel)
        if lock is None:
            lock = threading.Lock()
            _locks[channel] = lock
        return lock


# ── Публічний вхід ──────────────────────────────────────────────────────────────────

def ensure_summary(channel, root=None, model_call=None, model=None, log_fn=None):
    """К15: викликати при ВІДКРИТТІ каналу. Якщо з часу останньої генерації додались
    картки — генерує (інкрементально або повною перезбіркою, К18) і повертає свіжий
    документ; якщо ні — не робить нічого дорожчого за читання файлу.

    `model_call(system_prompt, user_prompt) -> str` — точка підміни для тестів (fake
    модель, нуль токенів). Продакшн-виклик за замовчуванням залежить від провайдера
    каналу (`_resolve_provider`, `runner.channel_provider`): `claude` іде через
    `_invoke_claude_cli` (той самий `claude` CLI і той самий спосіб резолвити модель,
    яким уже керує `agent_worker.py`), `antigravity` — через `_invoke_agy_cli` (`agy`
    CLI). Обидва повертають той самий контракт (сирий текст відповіді) і йдуть в
    ОДИН спільний цикл ремонту й ОДНУ перевірку подачі нижче.

    Повертає dict:
      {'doc': compose()-документ, 'generated': bool, 'ok': bool,
       'mode': 'full'|'incremental'|None, 'attempts': int, 'error': str|None,
       'presentationOk': bool|None, 'reason': 'empty'|'fresh'|None,
       'preserved': int, 'retired': int, 'kept': int, 'skipped': [str]}
    `preserved`/`retired`/`kept`/`skipped` (К47-К49) роблять контракт збереження ВИДИМИМ
    числом: скільки пунктів повернуто в документ, бо модель їх не згадала; скільки вона
    відставила ЯВНО; скільки пересунула посиланням `keep`; і які не влізли назад через
    стелю секцій/пунктів (порожній список у нормі, непорожній — привід дивитись).
    `presentationOk` (К43/К44): `True` коли поріг подачі взято, `False` коли спрацював
    запобіжник К44 (документ записаний, але це найкраща з бідних спроб), `None` коли
    подача не оцінювалась узагалі (нічого не генерувалось або повний схемний провал).
    `reason` (Д5) заповнений ЛИШЕ коли `generated=False`: `'empty'` — у каналі нема
    жодної картки, генерувати нема з чого; `'fresh'` — картки є, але документ уже
    враховує останню. Обробник (`/api/summary-generate`, `/api/summary-rebuild`)
    використовує це, щоб дати hint саме на порожній канал, а не мовчати однаково
    в обох випадках."""
    log_fn = log_fn or _default_log
    channel_dir = os.path.join(root or ss.channels_dir(), channel)

    lock = _channel_lock(channel)
    with lock:
        doc = ss.read_doc(channel, root)
        messages = _read_channel_messages(channel_dir)
        last_id = max((m['id'] for m in messages if isinstance(m.get('id'), int)), default=0)
        has_previous = bool(doc['generation'].get('sections'))
        prev_source = doc['generation'].get('source') or {}
        prev_last_id = int(prev_source.get('lastMessageId') or 0)
        stale = last_id > 0 and (not has_previous or last_id > prev_last_id)

        if not stale:
            # Д5: `generated=False, ok=True` сам по собі не каже, ЧОМУ нічого не сталось.
            # Канал без жодної картки (`last_id == 0`) і канал, що вже свіжий, обидва
            # приходять сюди однаково мовчки — кнопка «Зробити саммарі» на порожньому
            # каналі відповідає тишею, невідрізненною від «уже свіже». `reason` дає
            # обробнику (`/api/summary-generate`, `/api/summary-rebuild`) підставу
            # відрізнити ці два випадки й дати людський hint саме на порожній канал.
            reason = 'empty' if last_id == 0 else 'fresh'
            return {'doc': ss.compose(channel, root), 'generated': False, 'ok': True,
                    'mode': None, 'attempts': 0, 'error': None, 'presentationOk': None,
                    'reason': reason, 'preserved': 0, 'retired': 0, 'kept': 0,
                    'skipped': []}

        prev_incremental = int(prev_source.get('incrementalCount') or 0)
        do_full = (not has_previous) or (prev_incremental + 1 >= FULL_REBUILD_EVERY)
        mode = 'full' if do_full else 'incremental'
        new_messages = messages if mode == 'full' else [m for m in messages if m['id'] > prev_last_id]
        # К47: попередній документ подається В ОБОХ режимах. Раніше тут стояло
        # `(None, []) if mode == 'full'`, і саме цей рядок робив кожну пʼяту генерацію
        # переписуванням з чистого аркуша (chat-269, genRev 8: 15 зниклих пунктів з 16).
        prev_sections = _strip_header_section(doc['generation'].get('sections', []))
        prev_block, pinned_keys = _previous_summary_block(doc, new_messages)
        user_prompt = _build_user_prompt(mode, new_messages, prev_block, pinned_keys)

        model_name = model or _resolve_model(channel, root)
        provider = _resolve_provider(channel, root)
        if model_call is not None:
            call = model_call
        elif provider == 'antigravity':
            call = lambda sp, up: _invoke_agy_cli(sp, up, channel)
        else:
            call = lambda sp, up: _invoke_claude_cli(sp, up, model_name)

        sections, attempts, error, presentation_ok, preserve_meta = _run_with_repair(
            channel, call, user_prompt, log_fn, prev_sections,
            doc['generation'].get('sections', []))

        if sections is None:
            log_fn(f'{channel}: generation FAILED after {attempts} attempts '
                    f'(provider={provider}), previous generation left untouched. '
                    f'Last error: {error}')
            return {'doc': ss.compose(channel, root), 'generated': False, 'ok': False,
                    'mode': mode, 'attempts': attempts, 'error': error,
                    'presentationOk': None, 'preserved': 0, 'retired': 0, 'kept': 0,
                    'skipped': []}

        new_incremental = 0 if mode == 'full' else prev_incremental + 1
        gen = ss.write_generation(
            channel, sections,
            source={'lastMessageId': last_id, 'messageCount': len(messages),
                    'incrementalCount': new_incremental},
            mode=mode, model=model_name, root=root)
        meta = preserve_meta or {'preserved': [], 'retired': [], 'kept': [], 'skipped': []}
        log_fn(f'{channel}: generated ok, provider={provider}, mode={mode}, '
                f'attempts={attempts}, genRev={gen["genRev"]}, '
                f'збережено={len(meta["preserved"])}, відставлено={len(meta["retired"])}, '
                f'перенесено посиланням={len(meta["kept"])}')
        return {'doc': ss.compose(channel, root), 'generated': True, 'ok': True,
                'mode': mode, 'attempts': attempts, 'error': None,
                'presentationOk': presentation_ok,
                'preserved': len(meta['preserved']), 'retired': len(meta['retired']),
                'kept': len(meta['kept']), 'skipped': meta['skipped']}


def _read_channel_messages(channel_dir):
    """Картки каналу в хронологічному порядку: `index.json` + по одному `NNNN.json` на
    картку. Той самий контракт, яким пише `runner.append_message` (docstring runner.py,
    розділ «Storage contract»). Відсутній чи битий індекс читається як порожній канал,
    так само, як `summary_store.read_doc` читає відсутнє саммарі порожнім документом."""
    idx_path = os.path.join(channel_dir, 'index.json')
    try:
        with open(idx_path, encoding='utf-8') as f:
            items = json.load(f)
    except Exception:
        return []
    if not isinstance(items, list):
        return []
    out = []
    for it in sorted(items, key=lambda i: i.get('id', 0)):
        fname = it.get('file')
        widgets = []
        if fname:
            try:
                with open(os.path.join(channel_dir, fname), encoding='utf-8') as f:
                    widgets = json.load(f)
            except Exception:
                widgets = []
        out.append({'id': it.get('id'), 'from': it.get('from') or '', 'widgets': widgets})
    return out


if __name__ == '__main__':
    import sys
    if len(sys.argv) < 2:
        sys.stderr.write('usage: summary_generate.py <channel>\n')
        sys.exit(1)
    result = ensure_summary(sys.argv[1])
    print(json.dumps(result, ensure_ascii=False, indent=2))
