#!/usr/bin/env python3
"""helper_store: ЄДИНИЙ письменник, що створює помічника з нуля.

Спека: specs/helper-create-any-model/spec.md (К1, К3, К4, К8, К9).

ЧОМУ ЦЕ ОКРЕМИЙ МОДУЛЬ, А НЕ ТІЛО ЕНДПОІНТА. Створити помічника це ЧОТИРИ записи в
чотири різні місця (джерело, встановлена копія, реєстр персон, `.gitignore`), і
будь-яка модель, роблячи це руками, стабільно робила частину з них і рапортувала
успіх. Замір 2026-09-12: Antigravity зробив один запис із чотирьох (та ще й у теку
`.agents/skills/`, яку не читає ніхто), Claude зробив два з чотирьох. Обидва сказали
«готово». Поки це чотири окремі дії, «частково створений помічник» лишається
нормальним станом системи, і ловити його нема кому.

Тому тут одна функція `create()`, для якої «частково» неможливе за побудовою: кожен
крок реєструє свій відкіт, і на будь-якому винятку вже зроблене знімається у
зворотному порядку (К4). Виклик або дає повністю живого помічника, або не лишає по
собі нічого.

ЧОМУ ВАЛІДАЦІЯ ІМЕНІ ТАКА ЖОРСТКА. Імʼя приходить від МОДЕЛІ і стає шляхом на диску.
`../../.ssh`, `/etc/passwd`, `a/b` це не гіпотетичні атаки, а звичайна галюцинація
генератора назв. `forbidden` у `mcp/capabilities.json` забороняє моделі довільний
запис файлів, і ця функція не має права стати обхідним шляхом: єдиний спосіб
лишитись вузькою дією це біла рамка імені плюс перевірка, що підсумковий шлях
справді лежить усередині цільової теки.

ЧОМУ ПИШЕТЬСЯ РІВНО SKILL.md. Помічник у цьому проєкті це інструкції ПЛЮС, іноді,
враппери-скрипти, які запускають команди. Скрипт, покладений моделлю, автозапускався
б, тобто «створення помічника» перетворилось би на «виконання довільного коду».
Тому тіло помічника тут це завжди один markdown-файл і нічого більше; враппери
додає людина руками, окремим комітом.

ЧОМУ ПРИВАТНИЙ ЗА ЗАМОВЧУВАННЯМ. Правило власника (2026-09-12, дослівно: «усі
помічники мають бути персональними вони не мають бути доступні ще комусь»):
`shared-knowledge` це спільне репо, тому створений помічник не має світитись навіть
як untracked. Обидві теки йдуть у `.gitignore` САМИМ ендпоінтом, а не памʼяттю
моделі, бо памʼять моделі це не механізм.
"""
import json
import os
import re
import shutil

# Біла рамка імені. Мала латиниця, цифри, дефіси; починається з літери, не
# закінчується дефісом, 3-40 символів. Саме таку форму мають усі 39 наявних
# помічників, тому нове імʼя не вибивається з уже сформованої конвенції.
NAME_RE = re.compile(r'^[a-z][a-z0-9-]{1,38}[a-z0-9]$')

# Максимуми не для краси: SKILL.md читається в контекст моделі на кожен хід, де
# помічник згадано, тому «тіло на 200 КБ» це тихий податок на кожну відповідь.
MAX_TITLE = 60
MAX_DESC = 400
MAX_BODY = 20000

_GITIGNORE_MARK = '# Приватні помічники, створені з чату (helper_store)'


class HelperError(Exception):
    """Погані аргументи або конфлікт стану. Це 400, а не 500: майже кожна відмова
    тут означає «модель покликала неправильно», і 500 навчив би її повторювати той
    самий виклик, чекаючи іншого результату."""


def validate_name(name):
    """Імʼя -> нормалізоване імʼя, або HelperError із причиною, яку можна показати.

    Причина формулюється для ЛЮДИНИ і одразу містить наступну дію: модель читає цей
    текст і має з нього зрозуміти, що саме виправити, без другого раунду вгадувань."""
    if not isinstance(name, str) or not name.strip():
        raise HelperError('Імʼя помічника порожнє. Дай коротке імʼя малою латиницею, '
                          'наприклад meal-planner.')
    n = name.strip()
    if n != name.strip().lower():
        n = n.lower()
    if not NAME_RE.match(n):
        raise HelperError(
            f'Імʼя «{name}» не годиться для теки на диску. Треба 3-40 символів малої '
            'латиниці, цифр і дефісів, починатись з літери, не закінчуватись дефісом. '
            'Наприклад meal-planner.')
    return n


def _safe_join(base, name):
    """Шлях усередині base, або HelperError. Друга лінія після NAME_RE: рамка імені
    вже відкидає `..` і `/`, але перевірка кінцевого шляху лишається, бо саме вона
    не залежить від того, чи хтось колись послабить регулярку."""
    target = os.path.abspath(os.path.join(base, name))
    if os.path.commonpath([os.path.abspath(base), target]) != os.path.abspath(base):
        raise HelperError(f'Шлях помічника «{name}» виходить за межі дозволеної теки.')
    return target


def skill_md(name, title, description, body):
    """Тіло SKILL.md з фронтматером, який РЕАЛЬНО читають поверхні.

    `name` і `description` не косметика: `_skills_from_disk` і `_helpers_local_cards`
    у server.py беруть підпис картки саме з цих двох полів, тому фронтматер без них
    дав би помічника з іменем теки замість назви."""
    desc = ' '.join((description or '').split())
    head = ['---', f'name: {name}', f'description: {desc}', '---', '']
    head.append(f'# {title or name}')
    head.append('')
    head.append((body or '').strip())
    head.append('')
    return '\n'.join(head)


def _gitignore_lines(name):
    return [f'helpers/{name}/', f'.claude/skills/{name}/']


def _append_gitignore(path, name):
    """Обидві теки в `.gitignore`. Повертає рядки, які ДОДАЛИ (для відкоту).

    Ідемпотентно: рядок, який уже є, не дублюється. Це важливо не для чистоти файлу,
    а тому що повторний виклик після часткового збою не має плодити сміття."""
    try:
        with open(path, encoding='utf-8') as f:
            cur = f.read()
    except FileNotFoundError:
        cur = ''
    want = [ln for ln in _gitignore_lines(name) if ln not in cur.splitlines()]
    if not want:
        return []
    chunk = ''
    if cur and not cur.endswith('\n'):
        chunk += '\n'
    if _GITIGNORE_MARK not in cur:
        chunk += '\n' + _GITIGNORE_MARK + '\n'
    chunk += '\n'.join(want) + '\n'
    with open(path, 'a', encoding='utf-8') as f:
        f.write(chunk)
    return want


def _remove_gitignore(path, lines):
    """Відкіт записів у `.gitignore`: знімаємо РІВНО ті рядки, які самі додали."""
    if not lines:
        return
    try:
        with open(path, encoding='utf-8') as f:
            kept = [ln for ln in f.read().splitlines() if ln not in lines]
    except FileNotFoundError:
        return
    with open(path, 'w', encoding='utf-8') as f:
        f.write('\n'.join(kept) + '\n')


def read_state(state_path):
    try:
        with open(state_path, encoding='utf-8') as f:
            d = json.load(f)
        return d if isinstance(d, dict) else {}
    except Exception:
        return {}


def _save_state(state_path, state):
    tmp = state_path + '.tmp'
    with open(tmp, 'w', encoding='utf-8') as f:
        json.dump(state, f, ensure_ascii=False, indent=1)
    os.replace(tmp, state_path)


def persona_entry(name, title, description, cat='productivity', icon='bot',
                  avatar_params=None, role_text=None):
    """Запис персони у форму, яку вже читає `_personas_custom` у server.py.

    id = імʼя помічника, а не `custom-N`. Так навмисне: запис персони і тека скіла
    описують ОДНУ сутність, і спільний id це єдине, що не дає їм розʼїхатись при
    перевірці видимості. Наявні помічники в `personas-catalog.json` (grok, telegram,
    planner, browser) використовують саме таку форму id, тому це не нова конвенція."""
    return {
        'id': name,
        'cat': cat,
        'icon': icon,
        'name': title or name,
        'oneliner': ' '.join((description or '').split())[:110],
        'custom': True,
        # Нуль вмінь. Той самий висновок, що у майстра створення помічника:
        # автопідбір вмінь одного разу приписав ментору по продуктивності 31 чужий
        # інструмент, тому вміння лишаються справою людини.
        'capabilities': [],
        'roleText': (role_text or '').strip()[:4000],
        'avatarParams': avatar_params or {},
        'avatarSeed': name,
        # Слід походження: перевірка видимості і майбутнє прибирання мають
        # розрізняти «зробила модель» і «людина вписала руками».
        'createdBy': 'helper_create',
    }


def create(name, title, description, body, *, repo_root, install_root, state_path,
           gitignore_path=None, cat='productivity', icon='bot', avatar_params=None,
           private=True, _fail_at=None):
    """Створити помічника ОДНІЄЮ атомарною операцією. Повертає dict із результатом.

    Кроки: SKILL.md у `helpers/ІМʼЯ/`, копія в `install_root/ІМʼЯ/`, рядки в
    `.gitignore`, запис персони в `personas-state.json`. Будь-який виняток відкочує
    вже зроблене у зворотному порядку і летить далі.

    `_fail_at` існує ЛИШЕ для тесту відкоту (К4): відкіт це код, який у нормальному
    житті не виконується жодного разу, а отже без штучного збою лишився б непокритим,
    і зламався б саме тоді, коли вперше знадобиться.
    """
    n = validate_name(name)
    title = (title or n)[:MAX_TITLE]
    description = ' '.join((description or '').split())[:MAX_DESC]
    body = (body or '').strip()[:MAX_BODY]
    if len(description) < 4:
        raise HelperError('Опиши одним реченням, що цей помічник робить: без опису '
                          'його картка буде порожньою.')
    if len(body) < 20:
        raise HelperError('Тіло помічника заважке порожнє. Напиши інструкції: що він '
                          'робить, коли його кличуть, чого НЕ робить.')

    src_dir = _safe_join(os.path.join(repo_root, 'helpers'), n)
    dst_dir = _safe_join(install_root, n)
    if gitignore_path is None:
        gitignore_path = os.path.join(repo_root, '.gitignore')

    state = read_state(state_path)
    custom = state.get('_custom') if isinstance(state.get('_custom'), list) else []

    # Дубль ловиться ДО першого запису, по всіх трьох місцях одразу. Перевіряти по
    # одному означало б лишити по собі половину помічника з іменем, яке вже зайняте.
    if os.path.exists(src_dir) or os.path.exists(dst_dir):
        raise HelperError(f'Помічник «{n}» уже існує на диску. Візьми інше імʼя або '
                          'онови наявного.')
    if any(p.get('id') == n for p in custom):
        raise HelperError(f'Персона «{n}» уже зареєстрована. Візьми інше імʼя.')

    undo = []
    try:
        os.makedirs(src_dir, exist_ok=False)
        undo.append(lambda: shutil.rmtree(src_dir, ignore_errors=True))
        with open(os.path.join(src_dir, 'SKILL.md'), 'w', encoding='utf-8') as f:
            f.write(skill_md(n, title, description, body))
        if _fail_at == 'install':
            raise RuntimeError('штучний збій на встановленні')

        os.makedirs(dst_dir, exist_ok=False)
        undo.append(lambda: shutil.rmtree(dst_dir, ignore_errors=True))
        shutil.copy2(os.path.join(src_dir, 'SKILL.md'),
                     os.path.join(dst_dir, 'SKILL.md'))
        if _fail_at == 'gitignore':
            raise RuntimeError('штучний збій на gitignore')

        added = _append_gitignore(gitignore_path, n) if private else []
        if added:
            undo.append(lambda: _remove_gitignore(gitignore_path, added))
        if _fail_at == 'persona':
            raise RuntimeError('штучний збій на реєстрації персони')

        p = persona_entry(n, title, description, cat=cat, icon=icon,
                          avatar_params=avatar_params, role_text=body)
        custom = list(custom) + [p]
        state['_custom'] = custom
        team = state.get('_team') if isinstance(state.get('_team'), list) else []
        if n not in team:
            team = list(team) + [n]
        state['_team'] = team
        _save_state(state_path, state)
    except Exception:
        for fn in reversed(undo):
            try:
                fn()
            except Exception:
                pass
        raise

    return {
        'name': n,
        'title': title,
        'description': description,
        'source': os.path.relpath(src_dir, repo_root),
        'installed': os.path.relpath(dst_dir, repo_root) if dst_dir.startswith(
            os.path.abspath(repo_root)) else dst_dir,
        'private': bool(private),
        'persona': p,
    }


def verify(name, *, repo_root, install_root, state_path):
    """Фактичний стан помічника на диску і в реєстрі. Нічого не змінює.

    Це і є той доказ, без якого не можна рапортувати успіх (К9). Ключове слово тут
    «фактичний»: функція ЧИТАЄ поверхні заново, а не переказує те, що повернув
    попередній запис. Саме підміна факту переказом тричі за два дні давала
    «помічника додано», якого не існувало."""
    try:
        n = validate_name(name)
    except HelperError:
        return {'name': name, 'valid': False, 'source': False, 'installed': False,
                'persona': False, 'visible': False}
    state = read_state(state_path)
    custom = state.get('_custom') if isinstance(state.get('_custom'), list) else []
    team = state.get('_team') if isinstance(state.get('_team'), list) else []
    src = os.path.isfile(os.path.join(repo_root, 'helpers', n, 'SKILL.md'))
    inst = os.path.isfile(os.path.join(install_root, n, 'SKILL.md'))
    pers = any(p.get('id') == n for p in custom)
    return {
        'name': n,
        'valid': True,
        'source': src,
        'installed': inst,
        'persona': pers,
        'inTeam': n in team,
        # visible = людина справді побачить помічника: тека скіла дає картку в
        # магазині, запис персони дає картку в ростері. Без будь-чого з двох це
        # «створено наполовину», тобто рівно той дефект, від якого ми йдемо.
        'visible': bool(inst and pers),
    }
