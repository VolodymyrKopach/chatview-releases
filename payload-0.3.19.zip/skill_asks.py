"""Що скіл ПРОСИТЬ: ознаки, витягнуті з його файлів, а не з опису автора.

Навіщо це окремо від skill_scan. Сканер відповідає на питання «що страшного
знайшли у файлах, які вже приїхали в карантин», тобто працює ПІСЛЯ рішення піти
за скілом і має повний доступ до диска. Тут питання інше і задається РАНІШЕ: у
магазині 7436 карток, і людина мусить бачити на самій картці, чого ця штука
просить, ще до того як натисне «Встановити». Тому вхід у цього модуля не тека, а
текст скіла, і відповідь не «severity», а чотири факти:

    читає файли · пише файли · запускає команди · ходить у мережу (куди саме)

ЩО ЦЕ НЕ Є. Це не антивірус і не вердикт. Регулярка не розуміє наміру, її обходить
будь-яка обфускація, і вона цілком може назвати `pip install` командою там, де
автор просто показав, як поставити бібліотеку. Це нормально і це СВІДОМО: ми
показуємо ФАКТИ з файлів разом із доказом (файл, рядок, сам рядок), а рішення
лишається за людиною. Тому в цьому модулі ніде не буде слів «безпечно»,
«перевірено» чи «чисто»: ми цього не гарантуємо і не маємо права натякати.

ЧОМУ МІТКА РИЗИКУ ЛИШЕ НА КОМАНДАХ І МЕРЕЖІ. Попередження, яке стоїть на кожній
картці, читати перестають на третій. Читання і запис файлів це те, що робить
майже кожен скіл (він для цього й існує), а от «запусти команду» і «сходи ось
туди» це рівно ті два, після яких «ой, я не подивився» вже не відкотиш.

ЗВІДКИ БЕРЕТЬСЯ ВМІСТ. У каталозі 7436 записів і у ВСІХ 7436 url веде на один
файл (/blob/…/SKILL.md), тому «прочитати скіл» це один HTTP-запит на 2-70 КБ, а
не клон репозиторію. Заміряно 2026-08-07: 12 файлів у 8 потоків = 1.06 с. Наші
власні скіли лежать текою на диску і читаються без мережі взагалі.

КЕШ ОБОВʼЯЗКОВИЙ і його ключ це `hash` запису каталогу (відбиток вмісту SKILL.md
на момент збору). Змінився вміст у GitHub — збирач принесе інший hash — кеш сам
протухне. Без кешу кожен показ списку означав би вісім походів у мережу, а
гортання магазину перетворилось би на DDoS самих себе.
"""

import os
import re
import json
import time
import threading
import concurrent.futures as _fu

import entities

# DIR це тека КОДУ, і для читання нашого ж каталогу (CLI внизу файлу) вона правильна.
DIR = os.path.dirname(os.path.abspath(__file__))
# А кеш це ЗАПИС, і місце йому в домі даних. `clean_guard` уже описує його як
# `skills-library/asks-cache.json` під домом, тобто решта системи давно вважає, що
# він там і лежить; не погоджувався з цим один цей рядок. У пакованій збірці через
# нього виникали ДВІ копії: жива поруч із кодом (payload/) і мертва в домі, застигла
# на даті останнього оновлення (specs/user-data-architecture, К2).
CACHE_PATH = os.path.join(entities.data_root(), 'skills-library', 'asks-cache.json')

FETCH_TIMEOUT = 10.0        # секунд на один файл
LIST_DEADLINE = 6.0         # секунд на аналіз ЦІЛОГО списку, разом з мережею
WORKERS = 8                 # паралельних завантажень
MAX_BYTES = 512 * 1024      # більший файл не читаємо: це вже не інструкція
MAX_EVIDENCE = 8            # доказів на ознаку в картці
MAX_DOMAINS = 12
SNIPPET = 160
CACHE_MAX = 4000            # записів у кеші на диску
UA = 'logopsis-skill-asks'

# Порядок НЕ алфавітний, а за вагою наслідків: перше, що людина мусить побачити,
# це «запустить команди», а не «прочитає файл». Фронт бере перші три рядки над
# кнопкою, тому порядок тут це і є пріоритет показу.
FEATURES = ('runs', 'network', 'writes', 'reads')

LABEL = {
    'runs': 'просить запуск команд',
    'network': 'ходить у мережу',
    'writes': 'пише файли',
    'reads': 'читає файли',
}

# Мітку підвищеного ризику дають рівно ці дві ознаки (К3 спеки).
RISK_FEATURES = ('runs', 'network')


# ── правила ────────────────────────────────────────────────────────────────
# (ознака, людська назва правила, регулярка). Назва правила показується як
# доказ поруч із рядком файлу, тому вона мусить читатись як «ось що я побачив».
RULES = [
    # запуск команд
    ('runs', 'subprocess', r'\bsubprocess\b'),
    ('runs', 'os.system', r'\bos\.system\s*\('),
    ('runs', 'child_process', r'child_process'),
    ('runs', 'execSync', r'\bexec(Sync|File|FileSync)?\s*\('),
    ('runs', 'spawn', r'\bspawn(Sync)?\s*\('),
    ('runs', 'sh -c', r'\bsh\s+-c\b'),
    ('runs', 'bash', r'(?<![\w/-])bash(?![\w-])'),
    ('runs', 'shebang', r'^#!.*\b(bash|sh|zsh|python3?)\b'),
    ('runs', 'інструмент Bash', r'\bBash\s+(tool|інструмент)\b|`Bash`'),
    ('runs', 'npm install', r'\bnpm\s+(i|install|add|run|ci)\b'),
    ('runs', 'pip install', r'\bpip3?\s+install\b'),
    ('runs', 'brew install', r'\bbrew\s+install\b'),
    ('runs', 'uv/uvx', r'\buvx?\s+(run|pip|tool)\b'),
    ('runs', 'docker', r'\bdocker\s+(run|build|compose|exec)\b'),
    ('runs', 'git', r'(?<![\w-])git\s+(clone|checkout|pull|push|commit)\b'),
    ('runs', 'make', r'^\s*make\s+[\w:-]+\s*$'),
    # мережа
    ('network', 'curl', r'(?<![\w/-])curl(?![\w-])'),
    ('network', 'wget', r'(?<![\w/-])wget(?![\w-])'),
    ('network', 'fetch(', r'\bfetch\s*\('),
    ('network', 'requests.', r'\brequests\.(get|post|put|patch|delete|head|Session|request)\b'),
    ('network', 'urllib', r'\burllib\b|\burlopen\s*\('),
    ('network', 'httpx/aiohttp', r'\b(httpx|aiohttp)\b'),
    ('network', 'axios', r'\baxios\b'),
    ('network', 'http.client', r'\bhttp\.client\b|\bHttpClient\b'),
    ('network', 'WebFetch', r'\bWeb(Fetch|Search)\b'),
    ('network', 'gh api', r'\bgh\s+api\b'),
    ('network', 'HTTP-виклик', r'\b(GET|POST|PUT|PATCH|DELETE)\s+https?://'),
    # Хост виду api.чогось це вже не посилання на документацію, а адреса, за
    # якою щось викликають. Свідомо ВУЗЬКО: ширше правило («слово API поруч із
    # будь-яким URL») зараховувало в мережу список посилань «Documentation:
    # https://…», тобто мітку ризику отримував би кожен README з лінками.
    ('network', 'адреса API', r'\bapi[.-][a-z0-9.-]+\.[a-z]{2,}'),
    ('network', 'base_url/endpoint', r'\b(endpoint|base_?url|BASE_URL|apiUrl|api_url)\b[^\n]{0,30}https?://'),
    # Зовнішній MCP-сервер це не «згадка про мережу», а вимога підключити чужий
    # сервіс, через який поїде вся робота скіла. У каталозі таких сотні (одні
    # лише скіли Composio ходять через rube.app), і без цього правила вони
    # виглядали б як скіли, що взагалі нікуди не звертаються.
    ('network', 'MCP-сервер', r'\bmcp\b[^\n]{0,60}https?://|https?://[^\s)"\'`]*\bmcp\b'),
    # запис файлів
    ('writes', 'open(w)', r'\bopen\s*\([^)]*[\'"][wax]'),
    ('writes', 'write_text', r'\bwrite_(text|bytes)\s*\('),
    ('writes', 'writeFile', r'\bwrite(File|FileSync)\s*\(|\bfs\.write'),
    ('writes', 'json.dump', r'\bjson\.dump\s*\(|\bjson\.dump\b'),
    ('writes', 'mkdir', r'\bmkdirs?\b|\bmakedirs\s*\('),
    ('writes', 'редирект у файл', r'>>?\s*[\w./~$-]+\.(md|json|txt|csv|ya?ml|py|js|ts|sh|html)\b'),
    ('writes', 'touch', r'\btouch\s+[\w./~$-]+'),
    ('writes', 'інструмент Write/Edit', r'\b(Write|Edit)\s+(tool|інструмент)\b|`(Write|Edit)`'),
    ('writes', 'зберегти у файл', r'\bsave\b[^\n]{0,30}\b(to|into)\b[^\n]{0,20}\bfile\b'),
    # читання файлів
    ('reads', 'open(', r'\bopen\s*\([\'"]'),
    ('reads', 'read_text', r'\bread_(text|bytes)\s*\(|\bPath\s*\([^)]*\)\.read'),
    ('reads', 'readFile', r'\bread(File|FileSync)\s*\(|\bfs\.read'),
    ('reads', 'cat', r'(?:^|[|;&]\s*|\$\s+)cat\s+[\w./~$*-]+'),
    ('reads', 'os.walk/glob', r'\bos\.walk\s*\(|\bglob\.glob\s*\(|\blistdir\s*\('),
    ('reads', 'json.load', r'\bjson\.load\s*\('),
    ('reads', 'pandas.read_', r'\bpd\.read_\w+\s*\(|\bpandas\.read_\w+\s*\('),
    ('reads', 'інструмент Read/Glob/Grep', r'\b(Read|Glob|Grep)\s+(tool|інструмент)\b|`(Read|Glob|Grep)`'),
    ('reads', 'файл поруч зі скілом', r'\b(open|read|див\.|see)\b[^\n]{0,30}`[\w./-]+\.(md|json|ya?ml|csv|txt)`'),
]

_COMPILED = [(feat, label, re.compile(rx)) for feat, label, rx in RULES]

# Вето: правило спрацювало, але той самий рядок доводить, що це не воно.
# `with open("out.pdf", "wb")` це ЗАПИС, і зарахувати його ще й у читання
# означає намалювати людині ознаку, якої в рядку нема. Один рядок може чесно
# дати дві ознаки, але не тоді, коли друга прямо суперечить першій.
_SUPPRESS = {
    ('reads', 'open('): re.compile(r'\bopen\s*\([^)]*[\'"][wax]'),
}

# Огорожа блоку коду. Мова огорожі важлива: рядок усередині ```bash це КОМАНДА,
# яку скіл просить виконати, навіть якщо в ньому нема жодного слова з правил.
_FENCE_OPEN = re.compile(r'^\s*[`~]{3,}\s*([A-Za-z0-9+_-]*)\s*$')
_SHELL_LANGS = {'bash', 'sh', 'shell', 'zsh', 'console', 'shellsession', 'terminal'}
# Рядок у шел-блоці, який НЕ команда: коментар, порожньо, продовження виводу.
_NOT_A_CMD = re.compile(r'^\s*($|#|//|\$\s*$|[<>|]{2})')

# Оголошення інструментів у frontmatter. Це не «опис автора», а машинна заява
# скіла про те, що він проситиме, і вона точніша за будь-яку регулярку по прозі.
_FM_TOOLS = re.compile(r'^\s*(allowed-tools|tools|allowed_tools)\s*:\s*(.+)$', re.I)
_TOOL_FEATURE = {
    'bash': 'runs', 'shell': 'runs', 'execute': 'runs',
    'webfetch': 'network', 'websearch': 'network', 'fetch': 'network',
    'write': 'writes', 'edit': 'writes', 'multiedit': 'writes', 'notebookedit': 'writes',
    'read': 'reads', 'glob': 'reads', 'grep': 'reads', 'notebookread': 'reads',
}

# ── домени ─────────────────────────────────────────────────────────────────
_URL_RE = re.compile(r'https?://([A-Za-z0-9][A-Za-z0-9.\-]*\.[A-Za-z]{2,})')
_BARE_RE = re.compile(r'(?<![\w.@/-])((?:[a-z0-9][a-z0-9-]*\.)+[a-z]{2,})(?![\w-])')
# Голий хост без схеми беремо ЛИШЕ з відомим доменом верхнього рівня. Без цього
# `urllib.parse` і `os.path` їхали в перелік адрес як домени, тобто картка
# називала модуль Python місцем, куди підуть дані. Хибний домен гірший за
# відсутній: відсутній чесно каже «визначити не вдалось», а хибний бреше.
_BARE_TLD = {
    'com', 'net', 'org', 'io', 'ai', 'dev', 'co', 'app', 'cloud', 'tech',
    'xyz', 'me', 'tv', 'gov', 'edu', 'info', 'biz', 'us', 'uk', 'eu', 'de',
    'fr', 'es', 'it', 'nl', 'pl', 'ua', 'ru', 'cn', 'jp', 'in', 'br', 'ca',
    'au', 'ch', 'se', 'no', 'fi', 'cz', 'tools', 'run', 'page', 'link',
}
# Хвости, які виглядають як домен, але є іменем файлу або версією пакета.
_NOT_TLD = {
    'md', 'json', 'txt', 'csv', 'py', 'js', 'ts', 'tsx', 'jsx', 'mjs', 'cjs',
    'sh', 'yml', 'yaml', 'toml', 'ini', 'cfg', 'lock', 'log', 'png', 'jpg',
    'jpeg', 'gif', 'svg', 'pdf', 'zip', 'gz', 'html', 'css', 'xml', 'env',
    'sql', 'rb', 'go', 'rs', 'java', 'php', 'lua', 'exe', 'bin', 'so', 'db',
    'example', 'local', 'test', 'spec', 'min', 'map', 'tmp', 'bak', 'new',
}
# Локальна адреса це ПОВНОЦІННА відповідь на питання «куди»: точка з крапкою в
# ній не потрібна, тому загальна регулярка URL її не бачить, і без окремого
# рядка скіл, який стукає у власний localhost, отримав би чесне, але зайве
# «адреси визначити не вдалось».
_LOCAL_RE = re.compile(r'https?://(localhost|127\.0\.0\.1|0\.0\.0\.0)(?::\d+)?')

# Плейсхолдери документації. Це НЕ адреса, куди щось піде, а «підстав своє»,
# тому в перелік доменів воно потрапити не може. Мовчати про мережу через це
# теж не можна: такий скіл їде в гілку «адреси визначити не вдалось».
_PLACEHOLDER = re.compile(r'^(example|your|my|some|foo|bar)\b'
                          r'|\.(example|invalid|test)$')


def _hosts(line):
    """Домени з ОДНОГО рядка. Спершу повні URL, і лише якщо їх нема, голі хости:
    у рядку `curl api.github.com/…` адреса є, а схеми нема."""
    out = []
    for h in _URL_RE.findall(line) + _LOCAL_RE.findall(line):
        h = h.rstrip('.').lower()
        if h and h not in out:
            out.append(h)
    if out:
        return out
    for h in _BARE_RE.findall(line):
        h = h.rstrip('.').lower()
        tld = h.rsplit('.', 1)[-1]
        if tld in _NOT_TLD or tld not in _BARE_TLD:
            continue
        if h not in out:
            out.append(h)
    return out


def _real_domains(hosts):
    """Прибрати плейсхолдери. Вони не брехня і не адреса: `https://your-api.com`
    у прикладі означає «сюди підставиш своє», тому в перелік доменів воно йти не
    може, але й мовчати про мережу через нього не можна (див. domainsUnknown)."""
    return [h for h in hosts if not _PLACEHOLDER.search(h)]


# ── аналіз тексту ──────────────────────────────────────────────────────────
def analyze_files(files):
    """files: [(шлях, текст)] -> обʼєкт ознак.

    Один прохід по рядках, бо файли скіла це кілограми тексту, а не гігабайти,
    і другий прохід тут нічого не спростив би."""
    hits = {f: [] for f in FEATURES}
    domains = []
    net_lines = 0          # скільки рядків із мережевим викликом ми бачили
    net_with_host = 0      # і скільки з них назвали адресу
    scanned = 0
    total_bytes = 0

    for path, text in files:
        if not text:
            continue
        scanned += 1
        total_bytes += len(text)
        lines = text.splitlines()
        fence_lang = None
        in_fm = False
        for i, raw_line in enumerate(lines, 1):
            line = raw_line[:4000]
            m = _FENCE_OPEN.match(line)
            if m:
                lang = (m.group(1) or '').lower()
                fence_lang = None if fence_lang is not None else lang
                continue
            # frontmatter: перші три рядки файлу і рівно до наступного ---
            if i == 1 and line.strip() == '---':
                in_fm = True
                continue
            if in_fm:
                if line.strip() == '---':
                    in_fm = False
                else:
                    fm = _FM_TOOLS.match(line)
                    if fm:
                        for word in re.split(r'[,\s\[\]]+', fm.group(2).lower()):
                            feat = _TOOL_FEATURE.get(word.strip('`"\'()'))
                            if feat:
                                _add(hits[feat], path, i, 'оголошено в allowed-tools', line)
                    continue

            in_shell = fence_lang in _SHELL_LANGS
            if in_shell and not _NOT_A_CMD.match(line) and line.strip():
                _add(hits['runs'], path, i, 'команда в блоці ```' + (fence_lang or 'bash'), line)

            for feat, label, rx in _COMPILED:
                if not rx.search(line):
                    continue
                veto = _SUPPRESS.get((feat, label))
                if veto is not None and veto.search(line):
                    continue
                _add(hits[feat], path, i, label, line)
                if feat == 'network':
                    net_lines += 1
                    found = _real_domains(_hosts(line))
                    if not found and i < len(lines):
                        # `curl \` з адресою на наступному рядку: продовження
                        # команди це той самий виклик, а не новий факт.
                        if line.rstrip().endswith('\\'):
                            found = _real_domains(_hosts(lines[i]))
                    if found:
                        net_with_host += 1
                        for h in found:
                            if h not in domains and len(domains) < MAX_DOMAINS:
                                domains.append(h)

    feats = {f: bool(hits[f]) for f in FEATURES}
    # Мережа є, а жоден виклик не назвав адреси: адреса збирається в рантаймі.
    # Мовчати про це не можна, бо порожній перелік читається як «нікуди не йде».
    domains_unknown = bool(feats['network'] and not domains)
    out = dict(feats)
    out.update({
        'ok': True,
        'domains': domains,
        'domainsUnknown': domains_unknown,
        # Частина викликів названа, частина ні: перелік неповний, і про це теж
        # чесніше сказати, ніж видати три відомі адреси за весь список.
        'domainsPartial': bool(domains and net_with_host < net_lines),
        'risk': any(feats[f] for f in RISK_FEATURES),
        'evidence': _flatten(hits),
        'analyzedFiles': scanned,
        'bytes': total_bytes,
        'heuristic': True,
    })
    out['lines'] = _lines(out)
    out['riskReason'] = _risk_reason(out)
    return out


def _add(bucket, path, line_no, rule, text):
    """Один доказ. Те саме правило в тому самому файлі показуємо ОДИН раз:
    десять `curl` у README це не десять фактів, а один факт і дев'ять шумів."""
    key = (path, rule)
    if any(e['_k'] == key for e in bucket):
        return
    if len(bucket) >= MAX_EVIDENCE:
        return
    bucket.append({'_k': key, 'file': path, 'line': line_no,
                   'rule': rule, 'snippet': text.strip()[:SNIPPET]})


def _flatten(hits):
    out = []
    for feat in FEATURES:
        for e in hits[feat]:
            out.append({'feature': feat, 'file': e['file'], 'line': e['line'],
                        'rule': e['rule'], 'snippet': e['snippet']})
    return out


def _lines(a):
    """Людські рядки для картки. Формулювання навмисно нейтральні: «просить
    запуск команд», а не «небезпечний». Ми називаємо дію, а не даємо оцінку."""
    out = []
    for feat in FEATURES:
        if not a.get(feat):
            continue
        if feat != 'network':
            out.append(LABEL[feat])
            continue
        if a.get('domains'):
            shown = ', '.join(a['domains'][:3])
            more = len(a['domains']) - 3
            if more > 0:
                shown += ' і ще %d' % more
            if a.get('domainsPartial'):
                shown += ' (не всі адреси вдалось визначити)'
            out.append('%s: %s' % (LABEL[feat], shown))
        else:
            out.append('%s: адреси визначити не вдалось' % LABEL[feat])
    return out


def _risk_reason(a):
    named = [LABEL[f] for f in RISK_FEATURES if a.get(f)]
    return ' і '.join(named) if named else ''


def analyze_text(text, path='SKILL.md'):
    return analyze_files([(path, text)])


def empty(reason):
    """Відповідь, коли вмісту нема. Ознаки НЕ вигадуються і не вважаються
    відсутніми: «не змогли прочитати» це окремий стан, а не «нічого не просить»."""
    return {'ok': False, 'unknown': True, 'reason': reason, 'lines': [],
            'evidence': [], 'domains': [], 'risk': False, 'heuristic': True}


def nothing_found_note():
    """Що написати, коли прочитали і не знайшли ЖОДНОЇ ознаки. Свідомо без слів
    «безпечно» і «чисто»: текстовий пошук цього не доводить."""
    return ('Ознак роботи з файлами, командами чи мережею у тексті не знайдено. '
            'Це не перевірка безпеки: ми лише читали текст.')


# ── читання з диска ────────────────────────────────────────────────────────
def read_dir(root, max_files=40):
    """[(відносний шлях, текст)] з теки скіла. Бінарники і завеликі пропускаємо:
    ознаки живуть у тексті, а не в png."""
    import skill_scan as _sc
    out = []
    for dp, dirs, fs in os.walk(root):
        dirs[:] = [d for d in dirs if d not in ('.git', 'node_modules', '__pycache__')]
        for name in sorted(fs):
            if len(out) >= max_files:
                return out
            full = os.path.join(dp, name)
            if _sc._classify(full, name):
                continue
            try:
                with open(full, encoding='utf-8', errors='replace') as f:
                    out.append((os.path.relpath(full, root), f.read(MAX_BYTES)))
            except Exception:
                continue
    return out


# ── читання з мережі ───────────────────────────────────────────────────────
def raw_url(url):
    """-> (сира адреса, чи це лише головний файл) або (None, False).

    github.com/O/R/blob/B/P    -> raw.githubusercontent.com/O/R/B/P (весь скіл).
    github.com/O/R/tree/B/DIR  -> той самий шлях + /SKILL.md.

    Друга гілка навмисна і чесно позначена. Тека це кілька файлів, і прочитати
    їх усі можна лише sparse-checkout, тобто клоном на кілька секунд. Для картки
    в списку це неприйнятно, тому беремо головний файл одним запитом і КАЖЕМО,
    що прочитали лише його: неповний, але названий обсяг чесніший за повний, але
    недосяжний. Повну теку читає карантин, коли людина натисне «Встановити»."""
    if not url:
        return None, False
    if '/blob/' in url:
        return url.replace('https://github.com/',
                           'https://raw.githubusercontent.com/', 1
                           ).replace('/blob/', '/', 1), False
    if '/tree/' in url:
        base = url.replace('https://github.com/',
                           'https://raw.githubusercontent.com/', 1
                           ).replace('/tree/', '/', 1).rstrip('/')
        return base + '/SKILL.md', True
    return None, False


def fetch_text(url, timeout=FETCH_TIMEOUT):
    """-> (текст, чи це лише головний файл теки). Кидає виняток нагору: викликач
    вирішує, чи це привід написати «не вдалось прочитати», чи привід мовчати."""
    import urllib.request
    raw, partial = raw_url(url)
    if not raw:
        raise ValueError('не github-адреса файлу або теки')
    req = urllib.request.Request(raw, headers={'User-Agent': UA})
    with urllib.request.urlopen(req, timeout=timeout) as r:
        return r.read(MAX_BYTES).decode('utf-8', 'replace'), partial


# ── кеш ────────────────────────────────────────────────────────────────────
_CACHE = None
_CACHE_LOCK = threading.Lock()
_CACHE_DIRTY = False


def _load_cache():
    global _CACHE
    if _CACHE is not None:
        return _CACHE
    with _CACHE_LOCK:
        if _CACHE is None:
            try:
                with open(CACHE_PATH, encoding='utf-8') as f:
                    data = json.load(f)
                _CACHE = data.get('items') if isinstance(data.get('items'), dict) else {}
            except Exception:
                _CACHE = {}
    return _CACHE


def save_cache():
    """Скидання на диск робиться ПАЧКОЮ після аналізу списку, а не на кожен
    запис: інакше один показ магазину це вісім переписувань файлу."""
    global _CACHE_DIRTY
    with _CACHE_LOCK:
        if not _CACHE_DIRTY or _CACHE is None:
            return
        items = _CACHE
        if len(items) > CACHE_MAX:
            keep = sorted(items.items(), key=lambda kv: -(kv[1].get('ts') or 0))[:CACHE_MAX]
            items = dict(keep)
            _CACHE.clear()
            _CACHE.update(items)
        try:
            os.makedirs(os.path.dirname(CACHE_PATH), exist_ok=True)
            tmp = CACHE_PATH + '.tmp'
            with open(tmp, 'w', encoding='utf-8') as f:
                json.dump({'v': 1, 'items': items}, f, ensure_ascii=False,
                          separators=(',', ':'))
            os.replace(tmp, CACHE_PATH)
            _CACHE_DIRTY = False
        except Exception:
            pass


def cache_key(rec):
    """Відбиток ВМІСТУ, а не часу. Для зовнішнього запису це `hash` каталогу
    (sha1 по SKILL.md на момент збору), для нашої теки це mtime+розмір файлів.
    Ключ по часу протухав би щодня без причини, ключ по id не протухав би ніколи."""
    h = rec.get('hash')
    if h:
        return 'h:' + str(h)
    p = rec.get('_dir')
    if p and os.path.isdir(p):
        st = []
        for dp, dirs, fs in os.walk(p):
            dirs[:] = [d for d in dirs if d not in ('.git', 'node_modules', '__pycache__')]
            for n in sorted(fs)[:40]:
                try:
                    s = os.stat(os.path.join(dp, n))
                    st.append('%s:%d:%d' % (n, s.st_size, int(s.st_mtime)))
                except OSError:
                    pass
        # sha1, а НЕ вбудований hash(): він рандомізований на кожен процес, тому
        # дисковий кеш протухав би на кожному рестарті сервера без причини.
        import hashlib
        return 'd:' + hashlib.sha1('|'.join(st).encode('utf-8')).hexdigest()[:16]
    return 'u:' + str(rec.get('url') or rec.get('id') or '')


def cached(skill_id, key):
    hit = _load_cache().get(skill_id)
    if isinstance(hit, dict) and hit.get('k') == key and isinstance(hit.get('a'), dict):
        return hit['a']
    return None


def remember(skill_id, key, asks):
    global _CACHE_DIRTY
    c = _load_cache()
    with _CACHE_LOCK:
        c[skill_id] = {'k': key, 'a': asks, 'ts': int(time.time())}
        _CACHE_DIRTY = True


# ── публічний вхід ─────────────────────────────────────────────────────────
def analyze_record(rec, allow_fetch=True, timeout=FETCH_TIMEOUT):
    """Ознаки для ОДНОГО запису каталогу. Кеш прозорий: попадання = миттєво.

    rec розуміє три джерела вмісту, у порядку довіри:
      _dir  — тека на диску (карантин або наш бандл): читаємо все;
      _text — вже прочитаний текст (карантин уже в руках викликача);
      url   — /blob/ у GitHub: один запит по сирому файлу."""
    sid = rec.get('id') or ''
    key = cache_key(rec)
    hit = cached(sid, key) if sid else None
    if hit is not None:
        out = dict(hit)
        out['cached'] = True
        return out

    files = None
    partial = False
    if rec.get('_text') is not None:
        files = [(rec.get('_path') or 'SKILL.md', rec['_text'])]
    elif rec.get('_dir') and os.path.isdir(rec['_dir']):
        files = read_dir(rec['_dir'])
    elif rec.get('url') and allow_fetch:
        try:
            text, partial = fetch_text(rec['url'], timeout=timeout)
            files = [('SKILL.md', text)]
        except Exception as e:
            return empty('не вдалось прочитати вміст скіла: %s' % str(e)[:80])
    if files is None:
        return empty('вміст скіла ще не прочитано')
    if not files:
        return empty('у скіла нема жодного текстового файлу')

    asks = analyze_files(files)
    asks['cached'] = False
    if partial:
        # Не мовчазна неповнота: у скіла-теки ми прочитали лише головний файл, і
        # людина мусить знати, що поруч можуть лежати ще файли, яких ми не бачили.
        asks['partial'] = True
        asks['scope'] = 'прочитано лише головний файл SKILL.md, у теці можуть бути ще файли'
    if sid:
        remember(sid, key, asks)
    return asks


def analyze_many(recs, allow_fetch=True, deadline=LIST_DEADLINE):
    """{id: ознаки} для списку. Кешовані віддаються миттєво, решта тягнеться
    паралельно під СПІЛЬНИМ дедлайном.

    Дедлайн тут не оптимізація, а контракт: магазин не має права висіти через
    те, що GitHub сьогодні думає. Хто не встиг, той приїжджає як «ще не
    прочитано», і це чесний стан, а не порожні ознаки."""
    out = {}
    todo = []
    for r in recs:
        sid = r.get('id')
        if not sid:
            continue
        hit = cached(sid, cache_key(r))
        if hit is not None:
            out[sid] = dict(hit, cached=True)
        else:
            todo.append(r)
    if not todo:
        return out
    t0 = time.time()
    with _fu.ThreadPoolExecutor(max_workers=min(WORKERS, len(todo))) as ex:
        futs = {ex.submit(analyze_record, r, allow_fetch,
                          max(1.0, deadline - 0.5)): r for r in todo}
        for fut in _fu.as_completed(futs, timeout=None):
            r = futs[fut]
            try:
                out[r['id']] = fut.result()
            except Exception as e:
                out[r['id']] = empty('аналіз не завершився: %s' % str(e)[:80])
            if time.time() - t0 > deadline:
                break
        for fut, r in futs.items():
            if r['id'] not in out:
                fut.cancel()
                out[r['id']] = empty('вміст скіла ще не прочитано')
    save_cache()
    return out


# ── CLI: замір ─────────────────────────────────────────────────────────────
if __name__ == '__main__':
    import sys
    import argparse
    ap = argparse.ArgumentParser(description='Аналіз «що просить скіл» + замір')
    ap.add_argument('--bench', type=int, default=0, help='скільки скілів прогнати')
    ap.add_argument('--offset', type=int, default=0)
    ap.add_argument('--cold', action='store_true', help='спершу викинути їх з кешу')
    ap.add_argument('--id', help='розібрати один скіл за id')
    a = ap.parse_args()

    LIB = os.path.join(DIR, 'skills-library')
    with open(os.path.join(LIB, 'remote-catalog.json'), encoding='utf-8') as f:
        SK = json.load(f)['skills']

    if a.id:
        rec = next((r for r in SK if r['id'] == a.id), None)
        if not rec:
            print('нема такого id')
            sys.exit(1)
        print(json.dumps(analyze_record(rec), ensure_ascii=False, indent=1))
        save_cache()
        sys.exit(0)

    n = a.bench or 50
    batch = SK[a.offset:a.offset + n]
    if a.cold:
        c = _load_cache()
        for r in batch:
            c.pop(r['id'], None)
        globals()['_CACHE_DIRTY'] = True
        save_cache()
    t0 = time.time()
    res = analyze_many(batch, deadline=60.0)
    cold = time.time() - t0
    t1 = time.time()
    res2 = analyze_many(batch, deadline=60.0)
    warm = time.time() - t1
    risky = sum(1 for v in res.values() if v.get('risk'))
    unknown = sum(1 for v in res.values() if not v.get('ok'))
    print(json.dumps({
        'skills': len(batch),
        'coldSeconds': round(cold, 2),
        'warmSeconds': round(warm, 3),
        'perSkillColdMs': round(1000 * cold / max(1, len(batch)), 1),
        'perSkillWarmMs': round(1000 * warm / max(1, len(batch)), 2),
        'risk': risky, 'unreadable': unknown,
        'allCachedOnSecondRun': all(v.get('cached') for v in res2.values()),
    }, ensure_ascii=False))
