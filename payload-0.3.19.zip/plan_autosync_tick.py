#!/usr/bin/env python3
"""plan_autosync_tick.py — server-side, harness-independent detector for the `commit`
plan closing condition (specs/plan-autosync-server/spec.md, subtask C1, критерії К1, К2, К9).

WHY THIS MODULE EXISTS
-----------------------
plan-commit-close.cjs (specs/plan-autosync-signals/spec.md, B3) already closes a step
carrying `closeOn: {type:"commit", match:"..."}` the moment a matching commit lands —
but only inside a Claude Code harness turn, because it is wired as a PostToolUse hook
and the harness resolves those through `CLAUDE_PROJECT_DIR`. Checked personally:
that env var is never mentioned in agent_worker.py, jobs.py or server.py, so none of
the eighteen hooks in .claude/settings.json ever resolve in a detached agent's own
process — and most commits in this repo are made by exactly such an agent
(scripts/agent-run.cjs). The step never closes; the feature looks broken even though
its code is correct.

The fix is not to make the harness reach detached agents (spec.md non-goals: forcing
`CLAUDE_PROJECT_DIR` there would arm all eighteen hooks, gates included, with effects
nobody has audited). The fix is to stop depending on the harness for this ONE signal:
watch the repository from the one process that is always running regardless of who or
what made the commit — the server itself.

SCOPE. C1 built the `commit` closing condition (one cheap HEAD check, read history only
on a real move, one swallowed exception around the whole pass). C4 adds two more
conditions to the SAME tick, per plan.md ("Обидва перевіряються в тому самому
серверному тіку, що й коміт"):
  * `push` — a step's branch became byte-identical to its remote-tracking ref, not
    merely "the remote exists" (spec.md risk section, К6: a stranger's push to the
    same branch must never falsely close our step). An empty `match` means "whatever
    branch is currently checked out", per spec.md's own wording for this type.
  * `spec-closed` — a spec.md file's `Статус:` header reads `закрита`, read with the
    exact same rule as `.claude/skills/spec/spec.cjs`'s `statusOf()` (one header line,
    verbatim, one of three words) so the whole repo has one status format, not two.
Both live entirely in this file, not in plan_autopatch.py's `_CLOSE_TYPES`: that
frozenset's `_close_condition()` rejects a blank `match` outright, which is correct for
`commit`/`tests` but wrong for `push` (blank is a real, documented meaning there) — so
this module scans steps for these two types itself instead of stretching a rule that
exists for a different reason. Both share C1's cost discipline: if no step anywhere
carries that `closeOn.type`, the check makes ZERO external calls — no git subprocess
for `push`, no file read for `spec-closed` (see
test_no_push_or_spec_steps_makes_zero_extra_external_calls).

WHICH CHANNELS. A commit is one fact for the whole repository; a plan lives in exactly
one channel, and nothing ties a commit to a channel by identity. Guessing that link
from timing or authorship is explicitly forbidden (spec.md, risk section) — a commit
made while the user has channel A open could easily be about channel B's task. So this
module checks EVERY channel whose plan.json exists at all, and lets
`plan_autopatch.find_steps_by_close_condition` do the real, precise filtering
(closeOn.type == "commit", step active, match is a substring of the message). The
plan.json existence check is only a cheap pre-filter — it avoids a `read_plan()` +
`collect_steps()` per channel per commit message for the (common) channels that have
no plan file at all — never a re-implementation of the closeOn semantics, which stay
entirely inside plan_autopatch.py.

WRITE PATH. Exactly `plan_autopatch.mark_step`, never a second implementation — see
that module's own docstring for why (shape-preserving merge, frozen `done`, the
`source: "auto-patch"` marker). This module never touches plan_store directly.

К9 (never break the server). `Watcher.tick()` catches everything: a bad git binary, a
malformed plan.json, an exception from plan_autopatch — all logged, none propagated.
The daemon thread in `start_background_loop` calls `tick()` in an unconditional loop,
so one bad tick never stops the next one from happening.

G5 (specs/plan-safety-gates/spec.md, К7) — reconciliation, not just detection. Every
pass above this line only ever catches an event it was RUNNING to see: `_tick_commits`
diffs forward from its own in-memory baseline, `_tick_push`/`_tick_spec_closed` (C4)
already re-check live truth every tick with no baseline at all. The one structural gap:
a `commit`-conditioned step whose matching commit already landed BEFORE this Watcher's
very first tick — server restart, or a step added to the plan after the commit already
happened — never gets picked up by `_tick_commits`, because its first-tick rule is
"record the baseline, close nothing" (by design, mirrors plan-commit-close.cjs). Below,
`_tick_reconcile_commits` closes that gap by checking "is `match` ALREADY somewhere in
the full commit history right now", independent of any baseline. `push` and
`spec-closed` need no equivalent pass — they were built stateless from the start. `tests`
is deliberately NOT reconciled: a test run leaves no trace in the repo or the plan once
it finishes, so there is nothing left to inspect after the fact (spec.md's own risk
section calls this out; a false "already ran" guess is worse than staying open).
"""
import os
import re
import subprocess
import sys
import threading
import time

import plan_autopatch as pa
import plan_staleness as pst
import plan_store as ps

# The two C4 closing-condition types. See plan_autopatch.py's `closeOn` comment block
# for the full format doc — these two live here (not in that module's `_CLOSE_TYPES`)
# for the reason spelled out in this file's own module docstring above.
CLOSE_TYPE_PUSH = 'push'
CLOSE_TYPE_SPEC_CLOSED = 'spec-closed'

# The exact three states .claude/skills/spec/spec.cjs's `statusOf()` accepts; only the
# third one closes a `spec-closed` step. Duplicated as a value (not imported — spec.cjs
# is JS, this is Python, there is no shared module to import from) but the FORMAT it
# is read against (`_SPEC_STATUS_RE` below) is a byte-for-byte port of that function's
# own regex, so the two stay honest with each other even without a shared import.
SPEC_STATE_CLOSED = 'закрита'

_SPEC_STATUS_RE = re.compile(r'^Статус:[ \t]*(.*)$', re.MULTILINE)


def _default_read_spec_status(path):
    """Raw value of the `Статус:` header line in the spec.md at `path`, or None when
    the file is unreadable (missing, permission error, ...) or has no such header —
    both are "unknown status", never treated as "закрита"."""
    try:
        with open(path, encoding='utf-8') as f:
            text = f.read()
    except OSError:
        return None
    m = _SPEC_STATUS_RE.search(text)
    if not m:
        return None
    return m.group(1).strip()

# TICK_INTERVAL_SECONDS — the balance called out in spec.md's risk section: too often
# and the tick is a repeating git-fork-per-N-seconds cost that grows with every server
# that ever runs this file; too rare and a step a human is watching stays open longer
# than it has to. `git rev-parse HEAD` is a single cheap fork+exec (a few ms), so once
# every 20s is a couple of git calls a minute for the WHOLE server (not per channel,
# not per step) — noise-level CPU/disk cost — while still landing well inside the same
# "feels immediate" window already established for live progress in this project
# (feedback_live_progress_polling: ~15s cadence for background progress updates).
TICK_INTERVAL_SECONDS = 20.0

# GIT_TIMEOUT_SECONDS — bounds a single git call so a wedged git process (locked index,
# a hung network credential helper on a misconfigured remote, ...) cannot pin the tick
# thread forever; generous enough that a normal `rev-parse`/`log` on this repo's size
# never legitimately hits it.
GIT_TIMEOUT_SECONDS = 5.0

# STALE_RECALC_INTERVAL_SECONDS — plan_staleness.py exists but nothing ever called it
# (specs/plan-autosync-server/spec.md, subtask C2/E2): К3/К4/К5 were dead on a live
# server despite green unit tests on the module itself. Staleness is a function of TIME
# passing, not of a commit landing, so it cannot live inside the K2-gated branch above
# (that branch returns immediately whenever HEAD has not moved, which is most ticks) —
# it has to run on every `tick()` call, independent of git entirely. But it must not run
# on the commit tick's own 20s cadence either: the threshold it is checking against
# (plan_staleness.STALE_THRESHOLD_SECONDS, 48h) is three orders of magnitude larger, so
# reading + potentially rewriting every channel's plan.json every 20s would buy nothing
# but disk churn for a mark that is allowed to lag by minutes without anyone noticing.
# Five minutes keeps the mark feeling live while cutting the recompute rate ~15x
# relative to the commit tick.
STALE_RECALC_INTERVAL_SECONDS = 300.0

# RECONCILE_INTERVAL_SECONDS — gates `_tick_reconcile_commits` (G5, К7) for the same
# reason STALE_RECALC_INTERVAL_SECONDS gates staleness above: unlike `_tick_commits`'s
# single bounded `git log from..to`, reconciliation has no baseline to bound the range
# with, so it is one `git log` over the repo's WHOLE history — real cost that grows with
# the repo, not appropriate for the 20s commit-tick cadence. And the latency budget is
# different too: a step whose condition has quietly been true for a while does not need
# to close within 20s, a few minutes of lag is unnoticeable to whoever is looking at the
# plan. Reuses staleness's own number rather than inventing a third unrelated constant.
RECONCILE_INTERVAL_SECONDS = 300.0


def _default_log(message):
    try:
        sys.stderr.write(str(message) + '\n')
    except Exception:
        pass  # a logging failure must never be the reason a tick "throws" (К9)


def _default_run_git(args, cwd):
    """Real `git <args>` run in `cwd`. Returns stdout on success, None on ANY failure:
    missing binary, `cwd` not a git repo, a timeout, or a non-zero exit. Deliberately as
    forgiving as plan-commit-close.cjs's own `currentHead` (git-hooks/plan-commit-close.cjs) —
    "no git available" and "git found nothing" are the same "nothing to watch here" for
    this module, not a reason to log noise on every tick. This matters in practice: the
    packaged desktop build's REPO_ROOT is not a git checkout at all (server.py's
    `_repo_root` docstring), so this path is the normal, permanent state there."""
    try:
        result = subprocess.run(
            ['git'] + list(args), cwd=cwd, capture_output=True, text=True,
            timeout=GIT_TIMEOUT_SECONDS)
    except (OSError, subprocess.TimeoutExpired):
        return None
    if result.returncode != 0:
        return None
    return result.stdout


class Watcher:
    """Holds the one piece of state this whole feature needs: the HEAD sha seen on the
    previous tick. Unlike plan-commit-close.cjs (a fresh process per hook invocation,
    hence its on-disk state file), this class lives inside the one long-running server
    process that calls `tick()` repeatedly — an in-memory attribute is the "previous
    check" K2 talks about, nothing needs to survive a restart because a restarted
    server simply re-establishes its baseline on its first tick (see `_tick_unsafe`).

    Every collaborator is injectable so tests can fake git and the plan_autopatch calls
    without touching a real repo or real channels — the constructor's defaults are the
    only place production behavior is wired in.
    """

    def __init__(self, repo_root, channels_root=None, run_git=None, find_steps=None,
                 mark_step=None, log=None, run_staleness=None, stale_interval=None,
                 clock=None, read_spec_status=None, reconcile_interval=None):
        self.repo_root = repo_root
        self.channels_root = channels_root
        self._run_git = run_git or _default_run_git
        self._find_steps = find_steps or pa.find_steps_by_close_condition
        self._mark_step = mark_step or pa.mark_step
        self._log = log or _default_log
        # C4 collaborator: injectable for the same reason `_run_git` is — tests fake a
        # spec.md's status instead of writing real files for every case.
        self._read_spec_status = read_spec_status or _default_read_spec_status
        self._last_head = None
        # Staleness collaborators (E2). Injectable for the same reason `_run_git` is:
        # tests fake the write path and the clock instead of waiting on a real 48h
        # threshold or a real 300s interval.
        self._run_staleness = run_staleness or pst.run_channel
        self._stale_interval = (STALE_RECALC_INTERVAL_SECONDS if stale_interval is None
                                 else stale_interval)
        self._clock = clock or time.time
        self._last_stale_recalc = None
        # G5 (К7) collaborator: injectable for the same reason `_stale_interval` is —
        # tests force it to 0 to check "runs on this tick" or leave it real to check
        # "the second tick right after was skipped".
        self._reconcile_interval = (RECONCILE_INTERVAL_SECONDS if reconcile_interval is None
                                     else reconcile_interval)
        self._last_reconcile = None

    def tick(self):
        """One check-and-close pass. NEVER raises (К9): whatever goes wrong inside is
        logged here and swallowed, so the daemon loop in `start_background_loop` (and,
        by extension, the server it runs inside) is unaffected and the next tick still
        happens on schedule."""
        try:
            self._tick_unsafe()
        except Exception as e:
            self._log('plan_autosync_tick: tick failed: %s' % e)

    def _tick_unsafe(self):
        self._tick_commits()
        self._tick_reconcile_commits()
        self._tick_push()
        self._tick_spec_closed()
        self._tick_staleness()

    def _tick_staleness(self):
        """Recompute `stale` for every channel with a plan, gated by its own interval
        (STALE_RECALC_INTERVAL_SECONDS) so this never runs on the commit tick's 20s
        cadence. Runs unconditionally otherwise — deliberately NOT nested inside the K2
        HEAD-unchanged early return above, since staleness has nothing to do with git.
        Each channel is wrapped in its own try/except (К9, same shape as
        `_close_for_message` below): one channel's bad plan.json must not stop the rest
        of this pass, and any failure must never escape to `tick()`'s caller."""
        now = self._clock()
        last = self._last_stale_recalc
        if last is not None and (now - last) < self._stale_interval:
            return
        self._last_stale_recalc = now
        for channel in self._channels_with_a_plan():
            try:
                self._run_staleness(channel, root=self.channels_root, now=now)
            except Exception as e:
                self._log('plan_autosync_tick: staleness(%s) failed: %s' % (channel, e))

    def _tick_commits(self):
        head = self._run_git(['rev-parse', 'HEAD'], self.repo_root)
        head = (head or '').strip() or None
        if not head:
            return  # not a git repo, or git unavailable: nothing to watch

        prev = self._last_head
        if prev == head:
            return  # К2: HEAD did not move since the previous tick -> stop right here,
                     # `git log` (reading commit history) is never invoked in this case.

        if prev is None:
            # First tick ever for this Watcher: there is no "previous HEAD" to diff
            # against, so there is no well-defined set of "new" commits either. Record
            # the current HEAD as the baseline and close nothing — mirrors
            # plan-commit-close.cjs's own first-run rule. A commit that lands the very
            # next moment is a real move against THIS baseline and gets processed
            # normally on the following tick.
            self._last_head = head
            return

        for message in self._new_commit_messages(prev, head):
            self._close_for_message(message)
        self._last_head = head

    def _new_commit_messages(self, from_sha, to_sha):
        """Full commit message body of every commit strictly after `from_sha`, up to
        and including `to_sha`, oldest first. `%x00` between entries (not a newline,
        which a multi-line commit body already contains) is what makes splitting on a
        real message boundary possible at all."""
        out = self._run_git(
            ['log', '--reverse', '--format=%B%x00', '%s..%s' % (from_sha, to_sha)],
            self.repo_root)
        if out is None:
            return []
        return [m.strip() for m in out.split('\x00') if m.strip()]

    def _close_for_message(self, message):
        for channel in self._channels_with_a_plan():
            try:
                steps = self._find_steps(channel, pa.CLOSE_TYPE_COMMIT, message,
                                          root=self.channels_root)
            except Exception as e:
                self._log('plan_autosync_tick: find_steps(%s) failed: %s' % (channel, e))
                continue
            for step in steps:
                step_id = step.get('id') if isinstance(step, dict) else None
                if not step_id:
                    continue  # find_steps_by_close_condition already excludes these;
                              # kept here too so a fake test double cannot violate it
                try:
                    self._mark_step(channel, step_id, ps.DONE, root=self.channels_root)
                except Exception as e:
                    self._log('plan_autosync_tick: mark_step(%s, %s) failed: %s'
                               % (channel, step_id, e))

    def _channels_with_a_plan(self):
        root = self.channels_root if self.channels_root is not None else ps.channels_dir()
        try:
            names = os.listdir(root)
        except OSError:
            return []
        return sorted(
            name for name in names
            if os.path.isfile(os.path.join(root, name, 'plan.json')))

    def _tick_reconcile_commits(self):
        """G5, К7: close every ACTIVE `commit`-conditioned step whose `match` is ALREADY
        a substring of some commit message somewhere in the repo's current full history —
        the one case `_tick_commits` above structurally cannot catch, because it only
        ever diffs forward from its own in-memory baseline (see that method's own "first
        tick records the baseline, closes nothing" comment). A commit that landed before
        this Watcher's very first tick — a server restart, or a step whose `closeOn` was
        added to the plan only after the matching commit already happened — would
        otherwise stay open forever even though its condition is already true right now.

        Gated by its own rarer interval (RECONCILE_INTERVAL_SECONDS), same shape as
        `_tick_staleness`'s own gate: `self._last_reconcile is None` on the very first
        tick, so this always runs once before the interval starts being respected —
        exactly what "closes on the first pass" requires. The candidate scan runs BEFORE
        the clock/interval check (unlike staleness, which has no cheap pre-filter to run
        first): when there is nothing waiting on a commit condition, this returns without
        ever touching `self._clock()` — so a caller injecting a finite clock sequence
        (as the staleness tests above do) never sees an extra, unrelated consumption from
        this pass on a plan with no commit-conditioned steps at all."""
        candidates = self._active_steps_with_close_type(pa.CLOSE_TYPE_COMMIT)
        if not candidates:
            return  # zero cost, including zero clock() calls: nothing to gate an interval for

        now = self._clock()
        last = self._last_reconcile
        if last is not None and (now - last) < self._reconcile_interval:
            return
        self._last_reconcile = now

        history = self._all_commit_messages()
        if not history:
            return
        for channel, step, match in candidates:
            if not match:
                continue
            try:
                if any(match in message for message in history):
                    self._mark_step(channel, step['id'], ps.DONE, root=self.channels_root)
            except Exception as e:
                self._log('plan_autosync_tick: reconcile-commit(%s, %s) failed: %s'
                           % (channel, step.get('id'), e))

    def _all_commit_messages(self):
        """Full commit message body of EVERY commit reachable from the current HEAD of
        `self.repo_root`, in no particular order — same `%x00`-delimited shape as
        `_new_commit_messages` above, but with no `from..to` range, since reconciliation
        has no baseline to diff against by design. `None`/empty output (no git, not a
        repo, empty history) is "nothing to check against", never an error here."""
        out = self._run_git(['log', '--format=%B%x00'], self.repo_root)
        if out is None:
            return []
        return [m.strip() for m in out.split('\x00') if m.strip()]

    def _active_steps_with_close_type(self, close_type):
        """(channel, step, match) for every ACTIVE step (has an `id`, not `done`) whose
        `closeOn.type` equals `close_type` — the C4 sibling of `find_steps_by_close_
        condition`, kept OUTSIDE plan_autopatch.py because `push`'s blank-match rule
        does not fit that module's own `_close_condition()` (see this file's module
        docstring). Reading every channel's plan.json here is the one unavoidable local
        cost of even knowing whether there is anything to check; it is deliberately NOT
        gated behind the K2 HEAD-changed check above, since push/spec status have
        nothing to do with git history. What IS gated is everything downstream of this
        list: an empty result means the caller does zero subprocess calls / file reads."""
        out = []
        for channel in self._channels_with_a_plan():
            try:
                plan = ps.read_plan(channel, self.channels_root)
            except Exception as e:
                self._log('plan_autosync_tick: read_plan(%s) failed: %s' % (channel, e))
                continue
            for step in ps.collect_steps(plan):
                if not isinstance(step, dict):
                    continue
                if not str(step.get('id') or '').strip():
                    continue
                if str(step.get('state') or '').strip().lower() == ps.DONE:
                    continue
                close = step.get(pa.CLOSE_KEY)
                if not isinstance(close, dict):
                    continue
                if str(close.get('type') or '').strip().lower() != close_type:
                    continue
                out.append((channel, step, str(close.get('match') or '').strip()))
        return out

    def _tick_push(self):
        """К6: close every ACTIVE `push`-conditioned step whose branch is currently
        byte-identical to its remote-tracking ref. Stateless by design (unlike the
        commit path) — there is no "new since last tick" for a sync check, only "is it
        synced right now", so every tick re-checks live and needs no baseline."""
        candidates = self._active_steps_with_close_type(CLOSE_TYPE_PUSH)
        if not candidates:
            return  # the whole point of the prefilter: zero git calls when nothing to check
        for channel, step, match in candidates:
            try:
                branch = match or self._current_branch()
                if branch and self._is_branch_synced(branch):
                    self._mark_step(channel, step['id'], ps.DONE, root=self.channels_root)
            except Exception as e:
                self._log('plan_autosync_tick: push-check(%s, %s) failed: %s'
                           % (channel, step.get('id'), e))

    def _current_branch(self):
        """Short name of the branch currently checked out in `self.repo_root`, or None
        for a detached HEAD / no HEAD at all — both cases have no branch to compare."""
        out = self._run_git(['rev-parse', '--abbrev-ref', 'HEAD'], self.repo_root)
        name = (out or '').strip()
        return name if name and name != 'HEAD' else None

    def _is_branch_synced(self, branch):
        """True exactly when `branch`'s local sha equals its remote-tracking ref's sha
        — not "the remote ref exists", which a stranger's push to the same branch would
        also satisfy (spec.md risk section, К6). No configured upstream, or either
        rev-parse failing for any other reason, is "not synced", never an error."""
        local = (self._run_git(['rev-parse', branch], self.repo_root) or '').strip()
        remote = (self._run_git(['rev-parse', '%s@{upstream}' % branch], self.repo_root)
                  or '').strip()
        return bool(local) and bool(remote) and local == remote

    def _tick_spec_closed(self):
        """К7: close every ACTIVE `spec-closed`-conditioned step whose referenced
        spec.md currently has `Статус: закрита`. Same zero-cost-when-empty shape as
        `_tick_push`."""
        candidates = self._active_steps_with_close_type(CLOSE_TYPE_SPEC_CLOSED)
        if not candidates:
            return
        for channel, step, match in candidates:
            if not match:
                continue  # blank ознака has no defined meaning here (unlike `push`) —
                          # same "malformed condition = no condition" rule as commit/tests
            try:
                if self._read_spec_status(self._resolve_spec_md(match)) == SPEC_STATE_CLOSED:
                    self._mark_step(channel, step['id'], ps.DONE, root=self.channels_root)
            except Exception as e:
                self._log('plan_autosync_tick: spec-check(%s, %s) failed: %s'
                           % (channel, step.get('id'), e))

    def _resolve_spec_md(self, match):
        """Absolute path to the spec.md `match` points at. `match` is either a bare
        slug (`plan-autosync-server`), a directory path (`specs/plan-autosync-server`)
        or the file itself (`specs/plan-autosync-server/spec.md`) — spec.md's own
        wording for this ознака is "шлях або слаг", so both forms are accepted rather
        than picking one and silently failing on the other."""
        rel = match.strip().strip('/')
        if not rel.endswith('.md'):
            if '/' not in rel:
                rel = os.path.join('specs', rel)
            rel = os.path.join(rel, 'spec.md')
        return os.path.join(self.repo_root, rel)


def start_background_loop(repo_root, channels_root=None, interval=None, log=None):
    """Spawn the daemon thread that ticks forever — the "мінімальне підключення" to
    server.py's lifecycle plan.md asks for. Mirrors the periodic-loop pattern already
    used in server.py (`_canvas_backup_loop`, `_start_periodic_update_check`):
    fire-and-forget, `daemon=True` so it never blocks process shutdown, no return value
    the caller needs to act on. server.py calls this exactly once at startup and never
    touches this module again."""
    watcher = Watcher(repo_root, channels_root=channels_root, log=log)
    step = TICK_INTERVAL_SECONDS if interval is None else interval

    def _loop():
        while True:
            watcher.tick()
            time.sleep(step)

    thread = threading.Thread(target=_loop, daemon=True, name='plan-autosync-tick')
    thread.start()
    return thread
