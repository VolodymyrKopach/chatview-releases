#!/usr/bin/env python3
"""Емодзі в растрову картинку, самими лише засобами Python.

Спека: specs/gadget-pwa/spec.md, розділ 6.4. Сабтаск S2.
Тест: tools/viz/chat/tests/unit/test_gadget_pwa.py

ЧОМУ ЦЕ ВЗАГАЛІ ДОВОДИТЬСЯ ПИСАТИ. Іконка гаджета це емодзі: заміряно, у всіх наявних
гаджетів так. Браузер для встановлення вимагає растрові іконки конкретних розмірів, і
рядок «☀️» йому не іконка. Просити людину намалювати png для апки, яку вона щойно
попросила одним реченням, безглуздо, тож картинку малює сервер.

ЗВІДКИ БЕРЕТЬСЯ ПІКСЕЛЬ. У macOS системний шрифт Apple Color Emoji несе ГОТОВІ png
всередині себе (таблиця `sbix`, страйки до 160 пікселів). Тобто рендерити нічого не
треба: треба знайти потрібний гліф і дістати з файлу вже намальовану картинку. Це і
робить цей модуль, без сторонніх бібліотек, бо паковану збірку ми возимо на самій
стандартній бібліотеці.

ЧЕСНА МЕЖА. Windows везе Segoe UI Emoji, а це векторний кольоровий шрифт (COLR/CPAL) без
вбудованих png. Свого растеризатора векторних гліфів тут нема і не буде: це окрема
задача розміром з цю всю. Там `rgba_for` віддає None, а той, хто кличе, малює кольорову
плитку без гліфа. Апка лишається встановлюваною і відрізнюваною, але без емодзі. Це
записано вголос, а не сховано, щоб ніхто не вирішив, що на Windows «щось зламалось».
"""
import os
import struct
import sys
import zlib

# ДЗЕРКАЛЕННЯ ІМЕН ЗМІННИХ СЕРЕДОВИЩА (CHATVIEW_* <-> LOGOPSIS_*). Стоїть вище за
# будь-яке читання середовища у цьому файлі: у власника лишились запущені служби,
# launchd-агенти і .command-файли зі старими іменами, і вони мусять і далі працювати.
# Контракт і причини: brand_env.py.
import brand_env  # noqa: F401

# Шрифти з ВБУДОВАНИМИ растрами. Порядок = порядок проби. Носій має бути sbix, інакше
# ми його не читаємо, і чесніше не вдавати, що шрифт знайдено.
FONT_CANDIDATES = (
    '/System/Library/Fonts/Apple Color Emoji.ttc',
    '/System/Library/Fonts/Apple Color Emoji.ttf',
    '/Library/Fonts/Apple Color Emoji.ttc',
)

# Невидимі кодові точки, які не мають власного гліфа: селектори накреслення і зʼєднувач.
_SKIP_CODEPOINTS = {0xFE0E, 0xFE0F, 0x200D}

_font_cache = {'checked': False, 'path': None, 'meta': None}


# ── розбір sfnt ───────────────────────────────────────────────────────────────

def _read_tables(fh):
    """Каталог таблиць шрифту -> {tag: (offset, length)}. Розуміє і .ttc, і .ttf."""
    fh.seek(0)
    tag = fh.read(4)
    base = 0
    if tag == b'ttcf':
        _ver, num = struct.unpack('>II', fh.read(8))
        if not num:
            return None
        offsets = struct.unpack('>%dI' % num, fh.read(4 * num))
        base = offsets[0]
    fh.seek(base)
    head = fh.read(12)
    if len(head) < 12:
        return None
    num_tables = struct.unpack('>H', head[4:6])[0]
    tables = {}
    for _ in range(num_tables):
        rec = fh.read(16)
        if len(rec) < 16:
            break
        t, _cs, off, ln = struct.unpack('>4sIII', rec)
        tables[t.decode('latin1')] = (off, ln)
    return tables


def _cmap_subtable(fh, tables):
    """Зміщення підтаблиці cmap формату 12 або 4, або None."""
    if 'cmap' not in tables:
        return None
    coff = tables['cmap'][0]
    fh.seek(coff)
    head = fh.read(4)
    if len(head) < 4:
        return None
    n = struct.unpack('>H', head[2:4])[0]
    subs = []
    for _ in range(n):
        rec = fh.read(8)
        if len(rec) < 8:
            break
        pid, eid, off = struct.unpack('>HHI', rec)
        subs.append((pid, eid, coff + off))
    best = None
    for pid, eid, off in subs:
        fh.seek(off)
        fmt = struct.unpack('>H', fh.read(2))[0]
        if fmt == 12:
            return (12, off)
        if fmt == 4 and best is None:
            best = (4, off)
    return best


def _lookup_glyph(fh, sub, cp):
    fmt, off = sub
    if fmt == 12:
        fh.seek(off + 12)
        ngroups = struct.unpack('>I', fh.read(4))[0]
        data = fh.read(12 * ngroups)
        lo, hi = 0, ngroups - 1
        while lo <= hi:
            mid = (lo + hi) // 2
            start, end, gid = struct.unpack_from('>III', data, mid * 12)
            if cp < start:
                hi = mid - 1
            elif cp > end:
                lo = mid + 1
            else:
                return gid + (cp - start)
        return 0
    # формат 4: лише BMP
    if cp > 0xFFFF:
        return 0
    fh.seek(off)
    _fmt, length, _lang = struct.unpack('>HHH', fh.read(6))
    seg2 = struct.unpack('>H', fh.read(2))[0]
    seg = seg2 // 2
    fh.read(6)
    ends = struct.unpack('>%dH' % seg, fh.read(2 * seg))
    fh.read(2)
    starts = struct.unpack('>%dH' % seg, fh.read(2 * seg))
    deltas = struct.unpack('>%dh' % seg, fh.read(2 * seg))
    range_off_pos = fh.tell()
    range_offs = struct.unpack('>%dH' % seg, fh.read(2 * seg))
    for i in range(seg):
        if cp <= ends[i] and cp >= starts[i]:
            if range_offs[i] == 0:
                return (cp + deltas[i]) & 0xFFFF
            pos = range_off_pos + i * 2 + range_offs[i] + (cp - starts[i]) * 2
            fh.seek(pos)
            gid = struct.unpack('>H', fh.read(2))[0]
            return (gid + deltas[i]) & 0xFFFF if gid else 0
    return 0


def _font_meta(path):
    """Усе, що треба для витягання гліфа. None коли шрифт нам не по зубах."""
    try:
        with open(path, 'rb') as fh:
            tables = _read_tables(fh)
            if not tables or 'sbix' not in tables or 'maxp' not in tables:
                return None
            sub = _cmap_subtable(fh, tables)
            if not sub:
                return None
            fh.seek(tables['maxp'][0])
            num_glyphs = struct.unpack('>H', fh.read(6)[4:6])[0]
            soff = tables['sbix'][0]
            fh.seek(soff)
            _ver, _flags, num_strikes = struct.unpack('>HHI', fh.read(8))
            strike_offsets = struct.unpack('>%dI' % num_strikes,
                                           fh.read(4 * num_strikes))
            strikes = []
            for so in strike_offsets:
                fh.seek(soff + so)
                ppem, _ppi = struct.unpack('>HH', fh.read(4))
                strikes.append((ppem, soff + so))
            strikes.sort()
            return {'path': path, 'cmap': sub, 'numGlyphs': num_glyphs,
                    'strikes': strikes}
    except Exception:
        return None


def font_path():
    """Шлях до придатного шрифту емодзі, або None. Придатний = ми вміємо його читати."""
    if _font_cache['checked']:
        return _font_cache['path']
    _font_cache['checked'] = True
    candidates = []
    env = os.environ.get('LOGOPSIS_EMOJI_FONT')
    if env:
        candidates.append(env)
    candidates.extend(FONT_CANDIDATES)
    for path in candidates:
        if not path or not os.path.exists(path):
            continue
        meta = _font_meta(path)
        if meta:
            _font_cache['path'] = path
            _font_cache['meta'] = meta
            return path
    return None


def _meta():
    font_path()
    return _font_cache['meta']


# ── png: розбір і збирання ────────────────────────────────────────────────────

def decode_png(blob):
    """PNG -> (ширина, висота, bytearray RGBA). Кидає ValueError на те, чого не вміє.

    Свій декодер тут не з любові до велосипедів: у стандартній бібліотеці розбору PNG
    нема взагалі, а Pillow в паковану збірку не їде."""
    if blob[:8] != b'\x89PNG\r\n\x1a\n':
        raise ValueError('не png')
    pos = 8
    w = h = depth = ctype = None
    interlace = 0
    idat = bytearray()
    palette = b''
    trns = b''
    while pos + 8 <= len(blob):
        ln = struct.unpack('>I', blob[pos:pos + 4])[0]
        kind = blob[pos + 4:pos + 8]
        data = blob[pos + 8:pos + 8 + ln]
        pos += 12 + ln
        if kind == b'IHDR':
            w, h, depth, ctype, _c, _f, interlace = struct.unpack('>IIBBBBB', data)
        elif kind == b'PLTE':
            palette = data
        elif kind == b'tRNS':
            trns = data
        elif kind == b'IDAT':
            idat += data
        elif kind == b'IEND':
            break
    if depth != 8 or interlace:
        raise ValueError('підтримується лише 8 біт без черезрядковості')
    channels = {0: 1, 2: 3, 3: 1, 4: 2, 6: 4}.get(ctype)
    if not channels:
        raise ValueError('невідомий тип кольору')
    raw = zlib.decompress(bytes(idat))
    stride = w * channels
    out = bytearray(w * h * 4)
    prev = bytearray(stride)
    p = 0
    for y in range(h):
        ftype = raw[p]
        p += 1
        line = bytearray(raw[p:p + stride])
        p += stride
        if ftype:
            for i in range(stride):
                a = line[i - channels] if i >= channels else 0
                b = prev[i]
                c = prev[i - channels] if i >= channels else 0
                x = line[i]
                if ftype == 1:
                    line[i] = (x + a) & 0xFF
                elif ftype == 2:
                    line[i] = (x + b) & 0xFF
                elif ftype == 3:
                    line[i] = (x + ((a + b) >> 1)) & 0xFF
                elif ftype == 4:
                    pa = abs(b - c)
                    pb = abs(a - c)
                    pc = abs(a + b - 2 * c)
                    pred = a if (pa <= pb and pa <= pc) else (b if pb <= pc else c)
                    line[i] = (x + pred) & 0xFF
        prev = line
        base = y * w * 4
        for x in range(w):
            o = base + x * 4
            if ctype == 6:
                s = x * 4
                out[o:o + 4] = line[s:s + 4]
            elif ctype == 2:
                s = x * 3
                out[o:o + 3] = line[s:s + 3]
                out[o + 3] = 255
            elif ctype == 0:
                v = line[x]
                out[o] = out[o + 1] = out[o + 2] = v
                out[o + 3] = 255
            elif ctype == 4:
                s = x * 2
                v = line[s]
                out[o] = out[o + 1] = out[o + 2] = v
                out[o + 3] = line[s + 1]
            else:                                   # палітра
                idx = line[x]
                out[o:o + 3] = palette[idx * 3:idx * 3 + 3] or b'\x00\x00\x00'
                out[o + 3] = trns[idx] if idx < len(trns) else 255
    return w, h, out


def _chunk(kind, data):
    return (struct.pack('>I', len(data)) + kind + data
            + struct.pack('>I', zlib.crc32(kind + data) & 0xFFFFFFFF))


def encode_png(w, h, pixels, alpha=False):
    """(RGBA або RGB) -> PNG. Фільтр 0: іконки маленькі, стиснення вистачає."""
    channels = 4 if alpha else 3
    raw = bytearray()
    stride = w * 4
    for y in range(h):
        raw.append(0)
        row = pixels[y * stride:(y + 1) * stride]
        if alpha:
            raw += row
        else:
            for x in range(w):
                raw += row[x * 4:x * 4 + 3]
    ihdr = struct.pack('>IIBBBBB', w, h, 8, 6 if alpha else 2, 0, 0, 0)
    return (b'\x89PNG\r\n\x1a\n' + _chunk(b'IHDR', ihdr)
            + _chunk(b'IDAT', zlib.compress(bytes(raw), 9))
            + _chunk(b'IEND', b''))


def scale_rgba(w, h, pix, nw, nh):
    """Білінійне масштабування з попередньо помноженою альфою.

    Множення на альфу тут не прикраса: без нього по контуру емодзі, де альфа падає в
    нуль, у змішування підмішується колір повністю прозорих пікселів, і навколо гліфа
    зʼявляється темна облямівка."""
    src = bytearray(len(pix))
    for i in range(0, len(pix), 4):
        a = pix[i + 3]
        src[i] = pix[i] * a // 255
        src[i + 1] = pix[i + 1] * a // 255
        src[i + 2] = pix[i + 2] * a // 255
        src[i + 3] = a
    out = bytearray(nw * nh * 4)
    for y in range(nh):
        fy = (y + 0.5) * h / nh - 0.5
        y0 = int(fy) if fy >= 0 else 0
        y1 = min(y0 + 1, h - 1)
        wy = fy - y0
        if wy < 0:
            wy = 0.0
        for x in range(nw):
            fx = (x + 0.5) * w / nw - 0.5
            x0 = int(fx) if fx >= 0 else 0
            x1 = min(x0 + 1, w - 1)
            wx = fx - x0
            if wx < 0:
                wx = 0.0
            i00 = (y0 * w + x0) * 4
            i01 = (y0 * w + x1) * 4
            i10 = (y1 * w + x0) * 4
            i11 = (y1 * w + x1) * 4
            o = (y * nw + x) * 4
            for c in range(4):
                top = src[i00 + c] + (src[i01 + c] - src[i00 + c]) * wx
                bot = src[i10 + c] + (src[i11 + c] - src[i10 + c]) * wx
                out[o + c] = int(top + (bot - top) * wy + 0.5)
    for i in range(0, len(out), 4):          # назад у звичайну альфу
        a = out[i + 3]
        if a:
            out[i] = min(255, out[i] * 255 // a)
            out[i + 1] = min(255, out[i + 1] * 255 // a)
            out[i + 2] = min(255, out[i + 2] * 255 // a)
    return out


# ── головне ───────────────────────────────────────────────────────────────────

def _codepoints(emoji):
    """Кодові точки, з яких варто пробувати гліф. Селектори і зʼєднувач пропускаємо.

    Складені емодзі (сімʼя, професії) збираються правилами `morx` зі складників, а
    правил ми не читаємо. Тому для них береться перший складник: краще людина, ніж
    порожній квадрат."""
    return [ord(ch) for ch in emoji if ord(ch) not in _SKIP_CODEPOINTS]


def png_bytes_for(emoji, min_ppem=0):
    """Сирий png гліфа зі шрифту, як його намалював Apple. None коли не знайшли."""
    meta = _meta()
    if not meta or not emoji:
        return None
    try:
        with open(meta['path'], 'rb') as fh:
            gid = 0
            for cp in _codepoints(emoji):
                gid = _lookup_glyph(fh, meta['cmap'], cp)
                if gid:
                    break
            if not gid:
                return None
            strikes = meta['strikes']
            chosen = None
            for ppem, off in strikes:
                if ppem >= min_ppem:
                    chosen = (ppem, off)
                    break
            if chosen is None:
                chosen = strikes[-1]
            _ppem, soff = chosen
            fh.seek(soff + 4)
            offsets = fh.read(4 * (meta['numGlyphs'] + 1))
            start, end = struct.unpack_from('>II', offsets, gid * 4)
            if end <= start or end - start < 9:
                return None                      # у цьому страйку гліфа нема
            fh.seek(soff + start)
            blob = fh.read(end - start)
            gtype = blob[4:8]
            if gtype != b'png ':
                return None
            return blob[8:]
    except Exception:
        return None


def rgba_for(emoji, size):
    """Емодзі як квадрат size x size у RGBA. None коли намалювати нічим."""
    blob = png_bytes_for(emoji, min_ppem=size)
    if not blob:
        return None
    try:
        w, h, pix = decode_png(blob)
    except Exception:
        return None
    if (w, h) != (size, size):
        pix = scale_rgba(w, h, pix, size, size)
    return size, size, bytes(pix)
