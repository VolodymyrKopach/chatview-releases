# -*- coding: utf-8 -*-
"""Вибір моделі для АГЕНТА: основна і запасна на ДРУГОМУ двигуні.

Спека: `specs/agent-model-fallback/spec.md`, сабтаск S1. Дослівні слова замовника:
«ми запасну ставимо тільки в випадку, якщо в юзера є два двіжка. Якщо в нього не
підключені два двіжка, то ми ставимо один. І в випадку, якщо то не буде підключено, ми
ставимо інший».

Тобто запасна це НЕ друга улюблена модель, а страховка на випадок мертвого двигуна.
Звідси єдине правило, з якого випливає решта: запасна завжди сидить на іншому двигуні,
ніж основна. Пара з одного двигуна нічого не страхує, бо падають обидві разом.

Модуль свідомо порожній на побічні ефекти: нуль мережі, нуль підпроцесів, нуль читання
файлів. Готовність двигунів і список моделей Antigravity приходять АРГУМЕНТАМИ, бо їх
уже рахує сервер, і другої відповіді про той самий факт бути не має: дві незалежні
перевірки розходяться тихо (`specs/engine-availability`).

Три речі, які тут легко зробити неправильно, і тому вони описані словами.

1. Стан двигуна це ТРЬОХСТАН `yes | no | unknown`. `unknown` це ВІДСУТНІСТЬ відповіді
   (проба взяла лок або не вклалась у таймаут), а не «двигуна нема». Перемикаємось на
   запасну лише на визначеному `no`: інакше вибір людини блимав би разом з пробою.
2. Мапу «рівень -> модель Antigravity» тут заводити ЗАБОРОНЕНО. Вона вже жила у двох
   копіях і протухла мовчки 2026-08-12 (див. шапку `agy_models.py`). Єдине джерело:
   `agy_models.resolve_tier`.
3. Повний id моделі Клода тут НЕ рахується, у відповіді стоїть `id: None`. Це межа
   власності, а не забудькуватість: повні id (opus-5, fable-5) пінить
   `runner._resolve_model_args`, і другий власник цього знання гарантовано розійдеться
   з першим. Кличучий бере звідси `tier` і віддає його в наявний резолвер.

Коди причин (`reason`) це КОДИ, а не текст для людини: текст малює інтерфейс своєю
мовою, а бек кирилиці в собі не тримає взагалі.
    engine-down  двигун основної відповів визначеним «нема», поїхали на іншому;
    no-engine    їхати нема на чому, жоден двигун не готовий;
    no-fallback  запасну було задано, але вона не поїде (не та готовність або той самий
                 двигун), і краще сказати це вголос, ніж мовчки її загубити.
"""
import agy_models

# Двигунів рівно два і третього не буде (не-ціль спеки). Порядок сталий, бо з нього
# будується список у редакторі: вибір не сміє стрибати між двома відповідями сервера.
ENGINES = ('claude', 'antigravity')

# Рівні беремо з єдиного джерела, а не переписуємо: дубль розійшовся б на першому ж
# новому рівні.
TIERS = agy_models.MODEL_TIERS

# Значення готовності, які взагалі щось означають. Усе інше (порожнє, чуже слово,
# відсутній ключ) читається як «ще не знаємо», бо вигадувати відмову за двигун гірше,
# ніж почекати відповіді.
_STATES = ('yes', 'no', 'unknown')


def _word(value):
    """Людський ввід у машинне слово. Не рядок означає «нічого не сказано»."""
    return value.strip().lower() if isinstance(value, str) else ''


def _state(engines, engine):
    """Готовність одного двигуна, завжди один із трьох станів.

    Свідомо НЕ падає на 'no' за замовчуванням: 'no' це дозвіл перемкнути модель людини,
    і видавати його за мовчання проби заборонено."""
    got = _word(engines.get(engine)) if isinstance(engines, dict) else ''
    return got if got in _STATES else 'unknown'


def _other(engine):
    """Той самий «інший двигун», про який каже замовник. Двигунів два, тому інший один."""
    return ENGINES[0] if engine == ENGINES[1] else ENGINES[1]


def _tier_id(engine, tier, agy_ids):
    """Конкретний id моделі під рівень, або None.

    Для Antigravity відповідь дає ТІЛЬКИ `agy_models`. Для Клода id свідомо не існує,
    див. пункт 3 у шапці модуля."""
    if engine != 'antigravity':
        return None
    return agy_models.resolve_tier(tier, agy_ids).get('id')


def _with_id(choice, agy_ids):
    return dict(choice, id=_tier_id(choice['engine'], choice['tier'], agy_ids))


def normalize(choice):
    """Довільне сміття -> {'engine','tier'} або None.

    Тут немає жодного «підлікуємо і поїдемо»: невідомий двигун чи невідомий рівень це
    None, а лікує його НАСТУПНА ланка ланцюга дефолтів у resolve(). Якби замість None
    тихо підставлявся дефолт, вибір людини і поломка виглядали б однаково."""
    if not isinstance(choice, dict):
        return None
    engine = _word(choice.get('engine'))
    tier = _word(choice.get('tier'))
    if engine not in ENGINES or tier not in TIERS:
        return None
    return {'engine': engine, 'tier': tier}


def validate_pair(primary, fallback):
    """Чи можна ЗБЕРЕГТИ таку пару. -> (ok, reason|None), reason це код.

    Запасна необовʼязкова: порожнє значення означає «страховки не треба», і це не
    помилка. Але якщо вона є, її двигун мусить відрізнятись від двигуна основної,
    інакше вона не страхує нічого (К4 спеки)."""
    got = normalize(primary)
    if got is None:
        return (False, 'bad-primary')
    if not fallback:
        return (True, None)
    spare = normalize(fallback)
    if spare is None:
        return (False, 'bad-fallback')
    if spare['engine'] == got['engine']:
        return (False, 'same-engine')
    return (True, None)


def options(engines, agy_ids=()):
    """Що інтерфейс має право показати в редакторі вибору.

    Показуємо рівні рівно тих двигунів, що готові на ЦІЙ машині: назвати непідключений
    двигун у виборі означає запропонувати те, що не поїде (К3 спеки). `unknown` у список
    не потрапляє з тієї ж причини, з якої не перемикає модель: відповіді ще нема.

    `canFallback` True лише коли готові ОБИДВА двигуни, бо запасна за визначенням живе
    на другому. Це той самий критерій, за яким рядок «Двигун» ховається в Налаштуваннях,
    коли двигун один."""
    ready = [e for e in ENGINES if _state(engines, e) == 'yes']
    tiers = {}
    for engine in ready:
        tiers[engine] = [{'tier': t,
                          'label': agy_models.TIER_LABELS.get(t),
                          'id': _tier_id(engine, t, agy_ids)} for t in TIERS]
    return {'engines': ready, 'canFallback': len(ready) == len(ENGINES), 'tiers': tiers}


def _chain(key, *links):
    """Перша ланка, яка дала здорове значення. Бита ланка не кидає, а пропускається."""
    for link in links:
        if not isinstance(link, dict):
            continue
        got = normalize(link.get(key))
        if got:
            return got
    return None


def resolve(agent_choice, account_defaults, engines, agy_ids=(), global_default='sonnet'):
    """Що реально поїде на ЦЬОМУ спавні.

    Ланцюг той самий, що й у моделі каналу: вибір агента -> дефолт акаунта -> глобальний
    дефолт (К9). Порожня чи бита ланка лікується наступною, ніколи винятком: агент, який
    не стартував через друкарську помилку в збереженому стані, це найгірший із можливих
    наслідків цієї фічі.

    `usable: False` означає «їхати нема на чому»: кличучий показує НАЯВНУ картку
    вичерпаного ліміту і не вигадує третьої моделі (К8)."""
    fallback_tier = _word(global_default)
    if fallback_tier not in TIERS:
        fallback_tier = 'sonnet'

    primary = _chain('primary', agent_choice, account_defaults) \
        or {'engine': ENGINES[0], 'tier': fallback_tier}

    # Запасна йде тим самим ланцюгом: рядок «Запасна» в Налаштуваннях це дефолт акаунта,
    # і він мусить діяти на агента, який своєї запасної не має.
    configured = _chain('fallback', agent_choice, account_defaults)
    spare = configured
    if spare and spare['engine'] == primary['engine']:
        # Пара з одного двигуна могла приїхати зі старого стану або з чужого запису:
        # validate_pair її не пропустить, а тут вона просто не вважається страховкою.
        spare = None

    primary_state = _state(engines, primary['engine'])
    both_ready = all(_state(engines, e) == 'yes' for e in ENGINES)
    switched = False
    usable = True
    reason = None

    if primary_state == 'no':
        # Двигун основної відповів визначеним «нема». Тільки тут ми чіпаємо чужий вибір.
        alt = None
        if spare and _state(engines, spare['engine']) == 'yes':
            alt = dict(spare)
        else:
            # «І в випадку, якщо то не буде підключено, ми ставимо інший»: запасної не
            # зберігали, але другий двигун живий, тому їдемо тим самим РІВНЕМ на ньому.
            other = _other(primary['engine'])
            if _state(engines, other) == 'yes':
                alt = {'engine': other, 'tier': primary['tier']}
        if alt:
            primary = alt
            switched = True
            reason = 'engine-down'
        else:
            usable = False
            reason = 'no-engine'
        # Після підміни другої страховки не лишається: двигун, з якого ми поїхали, і є
        # той самий мертвий двигун. Обіцяти повернення на нього нечесно.
        spare = None
    elif spare is not None and not both_ready:
        # Запасна жива лише тоді, коли живі ОБИДВА двигуни (дзеркало canFallback).
        # Обіцяти непрацюючий запасний шлях гірше, ніж не обіцяти нічого.
        spare = None

    if reason is None and configured and spare is None:
        # Запасну задавали, а поїде вона не буде. Мовчки губити це не можна: людина
        # думатиме, що страховка стоїть, поки одного разу не впреться в ліміт.
        reason = 'no-fallback'

    return {
        'primary': _with_id(primary, agy_ids),
        'fallback': _with_id(spare, agy_ids) if spare else None,
        'switched': switched,
        'reason': reason,
        'usable': usable,
    }
