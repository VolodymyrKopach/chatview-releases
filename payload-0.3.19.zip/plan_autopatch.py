#!/usr/bin/env python3
"""plan_autopatch.py — mark ONE plan step, by explicit id, without a model turn.

WHY THIS MODULE EXISTS (specs/plan-autosync/spec.md, subtask A1)
------------------------------------------------------------------
Every write to channels/<id>/plan.json today is INITIATED BY THE MODEL: either it
declares a ```plan``` block in its own reply (runner.py: persist_plan_declaration), or
an agent/tool calls the `POST /api/plan-update` endpoint on the model's behalf. Nothing
in the system can flip a step's state on its own when e.g. a detached agent finishes —
the plan only ever catches up if the model happens to mention it. This module is that
missing "no model in the loop" writer: given a step id, a state and an optional reason,
it marks that ONE step, or does nothing at all.

plan_store.write_plan / plan_store.merge_plan remain the ONLY writer and the ONLY merge
implementation in the project (per the task: a second merge implementation must not
exist). This module never touches plan.json directly — it reads the current plan with
plan_store.read_plan, decides what to send, and hands a MINIMAL snapshot to
plan_store.write_plan, which does the actual merge/write.

THE TRAP THIS GUARDS AGAINST
-----------------------------
plan_store.merge_plan interprets an ABSENT phase title as "this phase is gone": a
snapshot shaped `{"steps": [...]}` sent against a plan that is actually built from
`phases` collapses every phase into one flat list (plan_store.py:237-245 `_target_bucket`,
and the steps/phases switch at plan_store.py:318-324). So before building anything, this
module reads the stored plan and REPRODUCES its shape: if the plan uses `phases`, the
snapshot lists every phase title with an empty `steps` list except the one phase that
holds the touched step. Untouched steps are never mentioned by the snapshot at all, so
plan_store's own survivor rule (plan_store.py:303-309) is what keeps them exactly where
they were — this module does not re-implement that, it just doesn't get in its way.

WHY MATCHING IS BY EXPLICIT `id` ONLY
--------------------------------------
plan_store.step_aliases falls back to normalized text when a step has no id, because
that is the right behavior for a model re-declaring a step it is looking at. It is the
WRONG behavior here: an automatic patch is triggered by a caller (an agent's lifecycle,
a job) that only ever knows the id it was given, and matching a foreign step by a text
coincidence would silently patch the wrong thing. So when the linked step has no `id` on
it, `mark_step` treats that exactly like "no such step" (K3) — a decision documented as
a known limit in the spec ("модель і далі не ставить ідентифікатор ... автосинхрон не
має за що зачепитись"), not a bug to paper over here.

SOURCE MARKER
-------------
Every step this module touches gets `"source": "auto-patch"` (AUTO_SOURCE below). A step
written by the model through the normal ```plan``` block or `/api/plan-update` never
carries this key — that is the whole point: it lets a UI or a human tell "the system did
this" apart from "the model said this", without inventing a second timestamp field or
duplicating `doneAt`.
"""
import os
import sys
import time

import plan_store as ps

AUTO_SOURCE = 'auto-patch'


def _is_phased(plan):
    """True when the stored plan actually uses the `phases` shape. Mirrors
    plan_store._buckets: an empty `phases` list does not count, the plan is flat then
    too (plan_store.py:225-234)."""
    phases = plan.get('phases') if isinstance(plan, dict) else None
    return isinstance(phases, list) and bool(phases)


def _phase_titles(plan):
    """Title of every phase, index-aligned with plan['phases'] (None for a malformed
    non-dict entry), so a phase_index found by _find_step always points at the right
    slot here too."""
    return [ph.get('title') if isinstance(ph, dict) else None for ph in plan['phases']]


def _find_step(plan, step_id):
    """(phase_index, step) for the step carrying this exact `id`; phase_index is None
    for a flat plan. (None, None) when no step in the plan has this id at all."""
    if not isinstance(plan, dict):
        return None, None
    if _is_phased(plan):
        for i, ph in enumerate(plan['phases']):
            if not isinstance(ph, dict):
                continue
            for st in (ph.get('steps') or []):
                if isinstance(st, dict) and str(st.get('id') or '').strip() == step_id:
                    return i, st
        return None, None
    for st in (plan.get('steps') or []):
        if isinstance(st, dict) and str(st.get('id') or '').strip() == step_id:
            return None, st
    return None, None


def mark_step(channel, step_id, state, note=None, root=None):
    """Mark the plan step whose `id` equals `step_id` with `state` (and `note` when
    given), tagged with the `source: 'auto-patch'` marker — no model turn involved.

    Returns True when a step was actually patched, False for either legitimate no-op:
    no step in the channel's plan carries this id (K3), or it does but is already
    `done` and therefore frozen (K5). Both leave the stored plan untouched — `root`
    aside, this function never calls plan_store.write_plan in either case, so an
    unknown channel gets no file at all rather than an empty one.

    Propagates whatever plan_store.write_plan raises (e.g. an unwritable target): this
    module has no opinion on how a caller should survive that, callers decide."""
    step_id = str(step_id or '').strip()
    if not step_id:
        return False

    plan = ps.read_plan(channel, root)
    phase_index, step = _find_step(plan, step_id)
    if step is None:
        return False
    if str(step.get('state') or '').strip().lower() == ps.DONE:
        return False

    patch = {'id': step_id, 'state': state, 'source': AUTO_SOURCE}
    if note is not None:
        patch['note'] = note

    if phase_index is not None:
        titles = _phase_titles(plan)
        snapshot = {'phases': [
            {'title': t, 'steps': [patch] if i == phase_index else []}
            for i, t in enumerate(titles)]}
    else:
        snapshot = {'steps': [patch]}

    ps.write_plan(channel, snapshot, root)
    return True


# ═══════════════════════════════════════════════════════════════════════════════════
# ITERATION 2 (specs/plan-autosync-signals/spec.md, subtask B1) — CLI entry point and
# the explicit closing condition. Everything above this line is iteration 1 and is
# untouched; every test in test_plan_autopatch.py still exercises exactly that code.
# ═══════════════════════════════════════════════════════════════════════════════════

# CLOSING CONDITION FORMAT (grep for `closeOn` — this is the one place it is defined)
# -------------------------------------------------------------------------------------
# A step may carry an explicit `closeOn` object saying WHAT closes it automatically:
#   "closeOn": {"type": "commit",      "match": "B1 plan_autopatch"}
#   "closeOn": {"type": "tests",       "match": "test_plan_autopatch.py"}
#   "closeOn": {"type": "push",        "match": "main"}
#   "closeOn": {"type": "spec-closed", "match": "plan-autosync-server"}
# Four types exist: CLOSE_TYPE_COMMIT / CLOSE_TYPE_TESTS (this module) and `push` /
# `spec-closed` (specs/plan-autosync-server/spec.md, subtask C4 — the two live in
# plan_autosync_tick.py, not here, see that module's docstring for why). `match` is a
# plain substring for `commit` (looked up inside the new commit's message) and `tests`
# (inside the test-run command) — the direction is always "is match IN the caller's
# text", never the reverse, a step's own wording is irrelevant. For `push`, `match` is
# a branch name, or the CURRENTLY CHECKED OUT branch when blank — the one type where a
# blank ознака has a defined meaning rather than being "no condition". For
# `spec-closed`, `match` is a spec slug or path (`plan-autosync-server` or
# `specs/plan-autosync-server/spec.md`), read against that spec's own `Статус:` header.
# Deliberately flat and two-field ("тип плюс ознака" per the task) rather than a richer
# schema, because the OTHER thing that has to produce this field is a model filling in
# a ```plan``` block (B6 wires this into runner.py's prompt contract) — the simpler the
# shape, the more reliably that generation is correct. Field name `match` (not the more
# obvious `signal`) is chosen to stay byte-identical with the B6 prompt-contract subtask
# (tests/unit/test_plan_close_condition_contract.py), which fixed this exact name first
# and is what the model actually reads: a mismatch here would make the whole feature a
# silent no-op, two subtasks agreeing on everything except the one key that connects them.
#
# A step with no `closeOn` at all, or a malformed one (unknown type / blank match where
# blank has no defined meaning / not an object), has NO closing condition — never
# treated as "close on anything". This is what makes K5
# (specs/plan-autosync-signals/spec.md) hold: automatic closure never happens on a
# coincidental text match, only on an explicit, well-formed declaration.
CLOSE_KEY = 'closeOn'
CLOSE_TYPE_COMMIT = 'commit'
CLOSE_TYPE_TESTS = 'tests'
_CLOSE_TYPES = frozenset((CLOSE_TYPE_COMMIT, CLOSE_TYPE_TESTS))


def _close_condition(step):
    """(type, match) declared by step['closeOn'], or None when the step has no closing
    condition at all — absent key, non-dict value, unknown type, or blank match are all
    exactly the same "no condition", never a reason to guess at intent."""
    if not isinstance(step, dict):
        return None
    close = step.get(CLOSE_KEY)
    if not isinstance(close, dict):
        return None
    ctype = str(close.get('type') or '').strip().lower()
    match = str(close.get('match') or '').strip()
    if ctype not in _CLOSE_TYPES or not match:
        return None
    return ctype, match


def find_steps_by_close_condition(channel, close_type, text, root=None):
    """Every ACTIVE step of `channel`'s plan whose `closeOn.type` == `close_type` and
    whose `match` is a substring of `text` (a commit message for CLOSE_TYPE_COMMIT, a
    test-run command for CLOSE_TYPE_TESTS) — the lookup a B3/B4-style hook runs to find
    which step(s) a git commit or a test run just closed, before calling mark_step(...,
    step['id'], ...) on each hit.

    Two things this NEVER returns, both load-bearing for K5
    (specs/plan-autosync-signals/spec.md): a step with no explicit `closeOn` (or a
    malformed one), no matter how closely its own text happens to resemble `text`; and a
    step already `done` — frozen history is not up for automatic re-closing here either.
    Also skips a matching step that has no `id`: mark_step (iteration 1) only ever acts
    by explicit id, so a step this function can find but a caller could never actually
    close is not a useful result — same "no id, no automatic anything" rule iteration 1
    already applies, extended to this lookup.

    Read-only: does not call plan_store.write_plan, cannot raise on a missing channel
    (ps.read_plan already returns {} for one)."""
    close_type = str(close_type or '').strip().lower()
    if close_type not in _CLOSE_TYPES:
        return []
    text = text or ''
    plan = ps.read_plan(channel, root)
    out = []
    for step in ps.collect_steps(plan):
        if not isinstance(step, dict):
            continue
        if not str(step.get('id') or '').strip():
            continue
        if str(step.get('state') or '').strip().lower() == ps.DONE:
            continue
        cond = _close_condition(step)
        if cond is None:
            continue
        ctype, match = cond
        if ctype != close_type or match not in text:
            continue
        out.append(step)
    return out


# EPHEMERAL STEP MARKER FORMAT (specs/plan-safety-gates/spec.md, subtask G4, criterion
# К6) — the OTHER format a step can carry, documented here next to `closeOn` so a reader
# checking "what can a step declare" has one place to look, not five. The key is read
# (and the removal logic lives) entirely OUTSIDE this module, in agent_worker.py's
# `_try_plan_ephemeral_cleanup` — the same split G5 already uses for `push`/`spec-closed`
# in plan_autosync_tick.py (see that module's own docstring): a shape whose meaning is
# specific to its one enable point does not belong inside `_CLOSE_TYPES`, it is only
# DOCUMENTED here.
#   "ephemeral": {"type": "agent", "agent": "<agentId>"}
# Meaning: this step is scaffolding for agent <agentId>'s own run, not a deliverable in
# its own right, and is dropped the moment that agent's run ends — done, error, stopped
# or truncated alike, since what the marker promises is the run being OVER, not the run
# having SUCCEEDED.
#
# WHY "an agent finishes" and not "a periodic tick" or "an explicit action" (plan.md
# names all three as candidates, G4 requires picking one and justifying it in code): the
# concrete failure this iteration fixes (spec.md §1) is the model and DETACHED AGENTS
# leaving DEMO/ПЕРЕВІРКА steps behind after proving a feature works. An agent's own
# completion is the one boundary that is already instrumented for exactly this purpose
# (agent_worker.py's `run()` calls `_try_plan_autopatch` in an unconditional `finally` on
# every terminal path already, so hanging one more cheap pass off the same event costs
# nothing new) and is unambiguous to a person reading the code: "this step goes away when
# THIS named agent is done" needs no clock, no extra manual step, and no cross-file
# coordination with the periodic tick that a parallel subtask (G5) already owns. A step
# the model creates directly, with no agent backing it, has no such boundary available
# without reaching into a different subtask's file (the periodic tick, the turn-start
# hook, a brand-new Stop-hook) — out of scope for this iteration ON PURPOSE, not silently
# swallowed.
#
# A step with no `ephemeral` key, or a malformed one (not an object, unknown `type`,
# blank `agent`), has NO ephemeral marker — never treated as ephemeral by guessing from
# its own wording (a "ДЕМО" prefix proves nothing on its own; spec.md's own hard
# requirement). And exactly like `closeOn`, a marker on a step with no `id` can never be
# acted on automatically: matching happens by explicit id only, same as `mark_step`
# above already requires — a foreign step must never be dropped by a wording coincidence.

# DONE-STEP REMOVAL — the one deliberate exception to "done is indestructible", and why
# it is a SEPARATE function rather than a new state `mark_step` accepts (work/plan-
# autosync/c6/DEFEKTY.md, Д2; specs/plan-safety-gates/spec.md, К6)
# -------------------------------------------------------------------------------------
# Д2 found that a successfully-closed ephemeral step could never be dropped: the caller
# (agent_worker._try_plan_ephemeral_cleanup) always went through mark_step(..., DROPPED),
# and mark_step refuses outright to even ATTEMPT a write once a step is `done` (K5
# above). Even if that early-return were removed, it would change nothing: write_plan
# hands the patch to plan_store.merge_plan, and merge_plan's own frozen-done rule keeps
# EVERY already-done stored step exactly as it was, for ANY shape of incoming snapshot,
# `dropped` included — it does not consult the new step's declared state at all before
# deciding to preserve the old one. That rule is correct and is left completely alone:
# a done step is real, load-bearing history (proof of finished work, the numerator the
# G2 truth gate counts against), and it must stay indestructible for every step that is
# not explicitly marked otherwise. The paradox Д2 names is exactly that a demo which
# happened to finish gets treated as if it were that kind of history, purely because
# `done` cannot tell "real work" from "scaffolding that closed before cleanup ran".
#
# So dropping a KNOWN-ephemeral done step cannot go through write_plan/merge_plan at
# all — no patch shape reaches that outcome — and needs a genuinely separate operation,
# not a weakened freeze rule. `drop_ephemeral_done_step` below is that operation. It
# is deliberately NOT a second merge implementation: it does not reconcile a snapshot
# against history, resolve origins, or match by anything other than the exact `id` the
# caller already resolved with certainty from the CURRENT stored plan. All it does is
# re-read that same plan, drop the one step whose id matches, and write the rest back
# byte-for-byte through the same atomic-write primitive plan_store.write_plan itself
# uses (`plan_store._write_json_atomic`) — so there is still exactly one way JSON ever
# lands on disk here, just not exactly one way a plan is DECIDED, which is the thing
# the "no second merge" rule actually protects.
#
# Safety is entirely the CALLER's job, same as `mark_step`'s id-only matching already
# trusts the caller for every other kind of patch: this function has no idea what
# `ephemeral` means (that stays owned by agent_worker.py, next to the marker format
# comment above) and will remove ANY step by this id, done or not. It must only ever be
# called once a caller has independently verified an explicit, well-formed `ephemeral`
# marker naming the agent that just finished — never on a bare id.
#
# Known, disclosed trade-off: this bypasses whatever write-ordering protection
# plan_store.py's writers give each other (a separate, still-open concern, Д3 in the
# same defect list) for the narrow window between this function's own read and write.
# That window is no wider than write_plan's own read-then-write gap already is, so this
# does not introduce a new category of risk, only one more caller inside an existing,
# already-documented one — out of scope to close here.


def drop_ephemeral_done_step(channel, step_id, root=None):
    """Remove the plan step whose `id` equals `step_id`, EVEN when it is `done` — see
    the block comment above for why this cannot be `mark_step` plus a new state.

    Returns True when a step with this id existed and was removed; False for the same
    kind of no-op `mark_step` has for an unknown id (K3): no step in the plan carries
    this id, or the channel has no plan at all. Both leave the stored plan untouched —
    an unknown channel gets no file at all rather than an empty one, same as mark_step."""
    step_id = str(step_id or '').strip()
    if not step_id:
        return False

    plan = ps.read_plan(channel, root)
    phase_index, step = _find_step(plan, step_id)
    if step is None:
        return False

    def _without(steps):
        return [st for st in (steps or [])
                if not (isinstance(st, dict) and str(st.get('id') or '').strip() == step_id)]

    if phase_index is not None:
        plan['phases'][phase_index]['steps'] = _without(plan['phases'][phase_index].get('steps'))
    else:
        plan['steps'] = _without(plan.get('steps'))

    plan['updated'] = time.strftime('%Y-%m-%d %H:%M')
    root = root or ps.channels_dir()
    ps._write_json_atomic(os.path.join(root, channel, 'plan.json'), plan)
    return True


# CLI ENTRY POINT
# -------------------------------------------------------------------------------------
# Why this exists: a hook that reacts to a git commit or a test run runs as node
# (PostToolUse hooks in this project are .cjs). Without a CLI here, that hook would have
# to either shell out to a throwaway one-off Python snippet duplicating mark_step's
# read-reshape-minimal-snapshot dance, or grow its OWN write path — exactly the "second
# implementation" the spec calls out as a known way constants/logic drift apart in this
# repo (specs/plan-autosync-signals/spec.md, risk section, K8). This function is the
# entire fix: node calls `python3 plan_autopatch.py <channel> <step_id> <state> [note]`,
# every write still goes through mark_step -> plan_store.write_plan, one writer, same as
# every other caller.
EXIT_OK = 0
EXIT_ERROR = 1
EXIT_NOOP = 2


def main(argv=None, root=None):
    """CLI: `plan_autopatch.py <channel> <step_id> <state> [note]`.

    `root` is a parameter, not a flag: production callers never pass it (mark_step then
    resolves the real channels dir the same way plan_store.py's own CLI does, via
    LOGOPSIS_HOME), tests point it at a tmp dir exactly like every other test in this
    module already does.

    Exit code is a deliberate three-way split, never conflated into a single non-zero
    "not ok": EXIT_OK the step existed and got patched; EXIT_NOOP no step in the plan
    matches this id, or it does but is frozen `done` — a legitimate no-op, not a failure;
    EXIT_ERROR something raised (unwritable target, broken plan.json, ...). Output is one
    short machine-readable line: `ok <channel> <step_id> <state>` / `noop <channel>
    <step_id>` on stdout, `plan_autopatch: <message>` on stderr for the error case.
    """
    argv = list(sys.argv[1:] if argv is None else argv)
    if len(argv) < 3:
        sys.stderr.write('usage: plan_autopatch.py <channel> <step_id> <state> [note]\n')
        return EXIT_ERROR
    channel, step_id, state = argv[0], argv[1], argv[2]
    note = ' '.join(argv[3:]) if len(argv) > 3 else None

    try:
        changed = mark_step(channel, step_id, state, note=note, root=root)
    except Exception as e:
        sys.stderr.write('plan_autopatch: %s\n' % e)
        return EXIT_ERROR

    if not changed:
        sys.stdout.write('noop %s %s\n' % (channel, step_id))
        return EXIT_NOOP
    sys.stdout.write('ok %s %s %s\n' % (channel, step_id, state))
    return EXIT_OK


if __name__ == '__main__':
    sys.exit(main())
