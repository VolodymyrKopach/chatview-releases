#!/usr/bin/env node

// Дзеркалення імен змінних середовища (CHATVIEW_* <-> LOGOPSIS_*) під час ребренду.
// Мусить стояти вище за перше читання process.env у цьому файлі: у власника
// лишились запущені служби і аліаси зі старими іменами. Контракт: brand-env.cjs.
require("./brand-env.cjs")
// agent-run.cjs — spawn a DETACHED background agent through Logopsis's engine.
//
// THE BRIDGE (owner decision, 2026-07-13). Fixes the long-standing "agents die on the next
// message / I never see «Тарас закінчив»" gripe. The harness Agent tool runs a
// subagent INSIDE my turn (the runner's `claude -p` process); when that turn ends
// (a new message = a new turn), the subagent dies and was never really visible.
//
// This helper instead POSTs to the Logopsis server's /api/agent-spawn, which runs
// the task in agent_worker.py in its OWN process group + session. That agent:
//   • survives a new message, an Esc on the main turn, and a Logopsis restart,
//   • shows live in the «Процеси» panel AND the global bubble над інпутом,
//   • posts its result as a card to the owning channel on done (auto).
//
// So: LONG / background work → this helper (detached). Quick inline reads that
// finish within my turn → the normal Agent tool is fine.
//
// Usage:
//   node scripts/agent-run.cjs --channel <id> --label "<name>" --task "<self-contained task>" \
//        [--model opus|sonnet|haiku] [--effort low|medium|high|xhigh|max] [--port 5555] \
//        [--touches path1,path2] [--task-file <file>] [--agent <slug>]
//   echo "<task>" | node scripts/agent-run.cjs --channel <id> --label "<name>" --task -
//
// --agent <slug>  необов'язковий слаг персони ('taras-cto', тобто ім'я файлу в
//                  .claude/agents/ без .md). Мозок агента (specs/agent-model-fallback,
//                  К5/К9/К10): з цим слагом агент спавниться на моделі, збереженій за
//                  персоною (або дефолтом акаунта), і з запасною на другому двигуні,
//                  якщо основний недоступний. Нема прапорця -> нуль змін (К10). Слаг
//                  невідомий -> сервер відмовляє з причиною, місток НЕ вигадує другу
//                  перевірку тут, щоб не розійтись із сервером у тому, що вважати
//                  валідним агентом.
//
// The task MUST be self-contained: a detached agent does NOT see this conversation,
// so pass all needed context in --task (same discipline as delegating to Taras).
//
// Output (stdout): a single line.
//   ok <agentId>                         → spawned; watch it in «Процеси»/bubble.
//   queued <jobId>                       → зона зайнята, поставлено ВАРТОВОГО; він сам
//                                          підніме агента, щойно зона звільниться.
//   err <reason>                         → NOT spawned. If the server is down, fall
//                                          back to the normal Agent tool and say so.
// Exit code: 0 on spawn AND on queue (робота запланована і видима), 1 on any failure.
//
// ─────────────────────────────────────────────────────────────────────────────
// ЗОНИ ФАЙЛІВ: --touches (specs/agent-zone-declaration)
//
// ПРИВІД. 12.09.2026 два незалежні напрямки роботи правили tools/viz/chat/server.py
// одночасно. Коміт 6e6b97b3 поклав в індекс версію, СТАРШУ за HEAD~1, і тихо зніс 92
// рядки, додані комітом b5672036 сорок хвилин раніше. Відкат da42b6b6 називає механізм
// словами автора: між записом і `git add` на диску опинилась копія файлу, зроблена ДО
// обох правок. Побачили це ВИПАДКОВО, бо автор загубив там свій власний коментар.
// Взаємного виключення в містку не було взагалі: `--task` каже, ЩО робити, і ніде не
// сказано, яких файлів це торкнеться.
//
// --touches це заявка агента на шматок диска. Приймаємо:
//   • файли і ТЕКИ (тека = весь піддерев, бо перетин рахується по сегментах шляху);
//   • кому в одному прапорці (`--touches a,b`) і повтор прапорця;
//   • абсолютний шлях усередині репо (нормалізуємо до репо-відносного, бо агентам
//     абсолютні шляхи в промптах дають постійно, а на сервері мусить лежати ОДИН
//     канонічний запис про файл, інакше два записи про той самий файл не перетнуться).
// Відхиляємо ДО мережі: глоби, `..`, порожній елемент, шлях поза репо. Глоби це
// свідома не-ціль: розкрити глоб по диску означає зафіксувати зону на файлах, які
// існують ЗАРАЗ, і випустити з неї файл, створений через хвилину.
//
// НЕ передали --touches: усе рівно як до цієї роботи. Зони нема, перевірки нема, і
// навіть жодного нового рядка в stderr. Усі наявні викликачі саме такі, і нагадування
// в stderr зламало б їм контракт «мовчки, коли все добре».
//
// ЗОНА ЗАЙНЯТА -> ВАРТОВИЙ, А НЕ ВІДМОВА (рішення власника). Відмова повертає рішення
// оркестраторові, а оркестратор це рівно та ланка, що вже один раз забула: того дня
// він поставив вартового на один із трьох паралельних спавнів і забув на двох інших.
// Тому місток сам ставить `scripts/watch.cjs` з ДЕКЛАРАТИВНОЮ умовою на
// /api/zones?conflicts=… і сам піднімає агента, коли зона звільниться.
//
// ЧОМУ ЦЕ НЕ МОЖЕ ЗАКЛИНИТИ. Взаємне блокування вимагає hold-and-wait: тримати одне і
// чекати друге. Тут зона забирається ЦІЛКОМ і рівно в момент спавну, а вартовий у
// черзі НЕ тримає нічого, тому циклу нема з чого скластись. Єдина форма, де
// hold-and-wait зʼявляється, це спавн ЗСЕРЕДИНИ агента, який сам уже тримає зону: там
// ми відмовляємо замість черги (LOGOPSIS_DETACHED_AGENT=1 нижче). Відмова агентові не
// суперечить рішенню власника: її читає машина, яка може вирішити сама, а не людина,
// яка вже забула. Усе інше обмежене таймаутом вартового і падає `failed` з назвою
// власника зони, а не висить тихо.
//
// СУСІД, А НЕ ДУБЛІКАТ. agent-batch.cjs робить ту саму фігуру (не вліз -> файл стану ->
// вартовий -> повторна спроба) для ІНШОГО тригера: стелі каналу. Спільного шматка тут
// свідомо нема, бо спільного стану тут нема: в нього умова «вільний слот», у нас
// «вільний шлях», і єдине, що мусить бути одне, це шлях спавну і реєстр, а вони й так
// одні. Пачка отримує зони безплатно: кожен її елемент іде через цей файл.

const http = require('http');
const fs = require('fs');
const os = require('os');
const path = require('path');
const { spawnSync } = require('child_process');

// Корінь репо від ЦЬОГО файлу: tools/viz/chat -> tools/viz -> tools -> repo.
const REPO = path.resolve(__dirname, '..', '..', '..');
// Вартовий живе в репо (scripts/), у паковану апку він не їде. Нема його -> черги нема,
// і ми кажемо це вголос замість того, щоб мовчки спавнити попри конфлікт.
const WATCH = path.join(REPO, 'scripts', 'watch.cjs');
// Відкладена задача лягає у tmp, а не в репо: у пакованій збірці дерево payload буває
// read-only, а tmp є завжди. Той самий вибір, що в QUEUE_DIR сусіднього agent-batch.cjs.
const QUEUE_DIR = path.join(os.tmpdir(), 'logopsis-agent-zones');
const QUEUE_KEEP_MS = 7 * 24 * 3600 * 1000;
// Скільки разів поспіль дозволяємо переставати в чергу. Кожна повторна постановка
// вимагає, щоб хтось РЕАЛЬНО забрав зону в нас з-під носа, тому ланцюг і без стелі
// обмежений числом претендентів. Стеля тут як у сусіда (agent-batch.cjs MAX_ATTEMPTS):
// вічний ланцюг вартових став би своїм власним інцидентом.
const MAX_ZONE_ATTEMPTS = 5;
// Стеля очікування зони. 7200с, як у черги за слотом у agent-batch.cjs: агент цілком
// законно може працювати пів години, і коротка стеля вбивала б чергу на живій роботі.
const ZONE_WAIT_TIMEOUT_S = 7200;

function parseArgs(argv) {
  const a = { port: process.env.LOGOPSIS_PORT || '5555', channelArg: '', touchesRaw: [] };
  for (let i = 0; i < argv.length; i++) {
    const k = argv[i];
    const v = argv[i + 1];
    if (k === '--channel') { a.channelArg = v; i++; }
    else if (k === '--label') { a.label = v; i++; }
    else if (k === '--task') { a.task = v; i++; }
    else if (k === '--model') { a.model = v; i++; }
    // Глибина міркування агента (рішення власника, 2026-08-03). Без цього detached-агент їхав
    // на дефолті сесії, і вимога «найсильніший рівень зусиль» тихо злітала.
    else if (k === '--effort') { a.effort = v; i++; }
    else if (k === '--port') { a.port = v; i++; }
    // Мозок агента (specs/agent-model-fallback): слаг персони, за яким сервер сам
    // резолвить модель + запасну. Валідація слага ЦІЛКОМ на сервері (_agent_hat) —
    // тут лише передача рядка далі, дублювати перевірку означало б два джерела
    // правди про те, які агенти взагалі існують.
    else if (k === '--agent') { a.agent = v; i++; }
    // Зона агента. Повторюваний прапорець І кома в одному значенні: оркестратор пише
    // кому, а машина (вартовий, пачка) любить повтор. Приймаємо обидві форми, бо
    // відмовити за форму списку означало б відмовити за косметику.
    else if (k === '--touches') { if (v !== undefined) a.touchesRaw.push(v); i++; }
    // Задача з ФАЙЛУ. Не косметика: watch.cjs запускає дію зі stdin='ignore', тобто
    // відкладену задачу фізично нема як передати через `--task -`, а в argv довгий
    // промпт ламається на лапках, переносах і `$`. Без цього прапорця черга зон
    // неможлива взагалі.
    else if (k === '--task-file') { a.taskFile = v; i++; }
    // Службовий: номер спроби постановки в чергу. Ставить собі сам місток, коли
    // переставляє задачу в чергу вдруге.
    else if (k === '--zone-attempt') { a.zoneAttempt = Number(v) || 1; i++; }
  }
  // `--task -` reads the task from stdin (avoids shell-escaping a long prompt).
  if (a.task === '-') {
    try { a.task = fs.readFileSync(0, 'utf8').trim(); } catch { a.task = ''; }
  }
  if (!a.task && a.taskFile) {
    try { a.task = fs.readFileSync(a.taskFile, 'utf8').trim(); } catch { a.task = ''; }
  }
  return a;
}

function fail(reason) {
  process.stdout.write('err ' + reason + '\n');
  process.exit(1);
}

const EFFORTS = ['low', 'medium', 'high', 'xhigh', 'max'];

/** Ідентифікатор каналу, яким його не можна пускати ні в шлях, ні в мережу. */
const badChannel = (c) => !c || c.includes('..') || /[/\\]/.test(c);

/**
 * ВЛАСНИК АГЕНТА (specs/agent-owner-channel). Канал ходу СИЛЬНІШИЙ за аргумент.
 *
 * Привід: агента замовили у чаті `chat-167`, а місток покликали з `--channel main`.
 * Далі все відпрацювало рівно за проєктом і саме тому виглядало як зникнення роботи:
 * смужка фонової роботи фільтрує строго по каналу, тож чат-замовник агента не показав;
 * картка результату лягла власнику, тобто в `main`; у «Процесах» агент був, бо там є
 * секція чужої роботи. Одна описка в аргументі відрізала агента від чату, де на нього
 * чекали, і жодна ланка про це не сказала.
 *
 * Тому підміна, а не відмова: відмова лишила б роботу незробленою і вимагала б ручного
 * перезапуску, а підміна ставить агента туди, де його видно, і КАЖЕ про це в stderr.
 * Поза чатом (`LOGOPSIS_CHANNEL` порожній або битий) правило не вмикається взагалі, і
 * явний `--channel` лишається єдиним джерелом, як було.
 */
function resolveChannel(asked, bound) {
  const want = String(asked || '').trim();
  const turn = String(bound || '').trim();
  if (turn && !badChannel(turn) && want && want !== turn) {
    return { channel: turn,
             warn: `channel forced to ${turn} (asked ${want}): агент належить чату, `
                 + 'з якого його запустили, інакше його не видно ні в смужці, ні у звіті' };
  }
  if (turn && !badChannel(turn)) return { channel: turn, warn: '' };
  return { channel: want, warn: '' };
}

/**
 * Один заявлений шлях -> канонічний репо-відносний, або причина відмови.
 *
 * Сервер приймає ТІЛЬКИ репо-відносні шляхи, і нормалізація абсолютних живе саме тут,
 * бо корінь репо знає місток, а не сервер (у пакованій збірці DIR сервера це взагалі
 * інша тека). Якби два викликачі назвали той самий файл по-різному, вони б не
 * перетнулись, і зона стала б декорацією.
 */
function normTouch(raw) {
  let s = String(raw == null ? '' : raw).trim().replace(/\\/g, '/');
  if (!s) return { err: 'порожній шлях у --touches' };
  if (/[*?[\]]/.test(s)) {
    return { err: `глоб у --touches не підтримується: ${s} (передай теку замість маски)` };
  }
  const winAbs = /^[A-Za-z]:[\\/]/.test(s);
  if (path.isAbsolute(s) || winAbs) {
    const rel = path.relative(REPO, path.resolve(s)).split(path.sep).join('/');
    if (!rel || rel.startsWith('..')) return { err: `шлях поза репо: ${s}` };
    s = rel;
  }
  while (s.startsWith('./')) s = s.slice(2);
  s = s.replace(/\/+$/, '');
  if (!s) return { err: 'порожній шлях у --touches' };
  if (s.split('/').includes('..')) return { err: `.. у шляху --touches: ${s}` };
  return { path: s };
}

/** Усі заявлені шляхи -> {paths} або {err}. Перша ж помилка спиняє запуск. */
function parseTouches(rawList) {
  const paths = [];
  for (const chunk of rawList || []) {
    for (const piece of String(chunk == null ? '' : chunk).split(',')) {
      if (!piece.trim()) continue;
      const r = normTouch(piece);
      if (r.err) return { err: r.err };
      if (!paths.includes(r.path)) paths.push(r.path);
    }
  }
  return { paths };
}

/** Відкласти задачу на диск для вартового. Прибирає за собою старе, щоб tmp не ріс. */
function stashTask(task) {
  fs.mkdirSync(QUEUE_DIR, { recursive: true });
  const now = Date.now();
  try {
    for (const n of fs.readdirSync(QUEUE_DIR)) {
      const f = path.join(QUEUE_DIR, n);
      if (now - fs.statSync(f).mtimeMs > QUEUE_KEEP_MS) fs.unlinkSync(f);
    }
  } catch { /* прибирання не критичне */ }
  const name = `${process.pid}-${process.hrtime.bigint()}.task.md`;
  const file = path.join(QUEUE_DIR, name);
  fs.writeFileSync(file, task, 'utf8');
  return file;
}

/**
 * Поставити задачу у ВИДИМУ чергу на звільнення зони.
 *
 * Умова декларативна (--until-url + --until-json + --until-count), а не shell: перетин
 * шляхів рахує сервер (?conflicts=), тому вартовому лишається порівняти ДОВЖИНУ вибірки
 * з нулем. Саме тому умова працює і на Windows, де нема ні test, ні grep, ні wc.
 */
function queueOnZone(args, conflicts) {
  if (!fs.existsSync(WATCH)) {
    return { ok: false, reason: `не знайшов ${WATCH}, підніми агента вручну пізніше` };
  }
  const attempt = Number(args.zoneAttempt || 1);
  if (attempt > MAX_ZONE_ATTEMPTS) {
    return { ok: false, reason: `зона не звільнилась за ${MAX_ZONE_ATTEMPTS} спроб` };
  }
  let taskFile = args.taskFile;
  if (!taskFile || !fs.existsSync(taskFile)) {
    try { taskFile = stashTask(args.task); } catch (e) {
      return { ok: false, reason: 'не зміг відкласти задачу: ' + (e && e.message) };
    }
  }
  const c = conflicts[0] || {};
  const zone = args.touches.join(',');
  const url = `http://127.0.0.1:${Number(args.port) || 5555}/api/zones`
            + `?conflicts=${encodeURIComponent(zone)}`;
  const action = [process.execPath, __filename,
                  '--channel', args.channel, '--label', args.label || 'Агент',
                  '--port', String(args.port), '--touches', zone,
                  '--task-file', taskFile, '--zone-attempt', String(attempt + 1)];
  if (args.model) action.push('--model', args.model);
  if (args.effort) action.push('--effort', args.effort);
  if (args.agent) action.push('--agent', args.agent);
  const who = c.label || 'агент';
  const flags = [WATCH, '--channel', args.channel,
                 '--label', `Черга зони: ${args.label || 'Агент'}`,
                 '--why', `по звільненню ${c.path || zone} піднімає агента «${args.label || 'Агент'}»`,
                 '--waiting', `зона ${c.path || zone} (тримає «${who}» у ${c.channel || '?'})`,
                 '--until-url', url, '--until-json', 'conflicts[]', '--until-count', '==0',
                 '--every', '15', '--timeout', String(ZONE_WAIT_TIMEOUT_S),
                 '--port', String(args.port),
                 '--', ...action];
  const r = spawnSync(process.execPath, flags, { encoding: 'utf8', env: process.env });
  const jobId = (r.stdout || '').trim().split('\n').pop();
  if (!jobId) {
    return { ok: false, reason: 'вартовий не зареєструвався: '
                              + ((r.stderr || '').trim() || 'watch.cjs мовчить') };
  }
  return { ok: true, jobId, taskFile };
}

const a = parseArgs(process.argv.slice(2));
const owner = resolveChannel(a.channelArg, process.env.LOGOPSIS_CHANNEL);
a.channel = owner.channel;
if (!a.channel) fail('no --channel (pass the owning Logopsis channel id)');
if (badChannel(a.channel)) fail('bad --channel ' + a.channel + ' (no slashes, no ..)');
if (owner.warn) process.stderr.write('warn ' + owner.warn + '\n');
if (!a.task) fail('empty --task (a detached agent needs a self-contained task)');
if (a.effort && !EFFORTS.includes(a.effort)) {
  fail('bad --effort ' + a.effort + ' (expected ' + EFFORTS.join('|') + ')');
}
// Помилку ПОСТАНОВКИ видно одразу, до мережі: інакше вона приїхала б як 500 з сервера,
// або, гірше, як тихий спавн БЕЗ зони, і замовник вважав би файл захищеним.
const zoneParsed = parseTouches(a.touchesRaw);
if (zoneParsed.err) fail('bad --touches: ' + zoneParsed.err);
a.touches = zoneParsed.paths;

const payload = JSON.stringify({
  channel: a.channel,
  label: a.label || 'Агент',
  task: a.task,
  ...(a.model ? { model: a.model } : {}),
  ...(a.effort ? { effort: a.effort } : {}),
  // Ключа НЕМА, коли зону не заявляли: старий сервер і старі викликачі бачать рівно той
  // самий payload, що до цієї роботи.
  ...(a.touches.length ? { touches: a.touches } : {}),
  // Ключа НЕМА без --agent: К10 спеки agent-model-fallback, типовий виклик без слага
  // лишається байт у байт таким, яким його бачив сервер до цієї правки.
  ...(a.agent ? { agent: a.agent } : {}),
});

/**
 * Зона зайнята. Дві різні відповіді, і різниця тут принципова.
 *
 * З головної сесії -> ВАРТОВИЙ. Відмова повернула б рішення оркестраторові, а саме він
 * того дня поставив вартового на один спавн з трьох і забув на двох інших.
 *
 * Зсередини detached-агента -> ВІДМОВА. Той, хто вже тримає зону, не має права стати в
 * чергу за власною зоною: це єдина форма hold-and-wait у цій схемі, тобто єдиний спосіб
 * отримати справжнє взаємне блокування. Відмову тут читає машина, яка може вирішити
 * сама, а не людина, яка вже забула, тому рішення власника цим не порушується.
 */
function onZoneConflict(j) {
  const msg = j.message || 'зона зайнята';
  if (String(process.env.LOGOPSIS_DETACHED_AGENT || '') === '1') {
    process.stderr.write('zone: зсередини агента в чергу не стаємо (ризик взаємного '
                       + 'блокування). Або дочекайся звільнення, або заяви інші шляхи.\n');
    fail('zone-conflict: ' + msg);
  }
  const q = queueOnZone(a, j.conflicts || []);
  if (!q.ok) fail('zone-conflict: ' + msg + '; черги нема: ' + q.reason);
  process.stdout.write('queued ' + q.jobId + '\n');
  process.stderr.write(`zone: ${msg}. Поставив вартового ${q.jobId}, він підніме агента `
                     + 'сам. Видно у «Процеси» і в /api/jobs?all=1\n');
  process.exit(0);
}

const req = http.request({
  host: '127.0.0.1',
  port: Number(a.port) || 5555,
  path: '/api/agent-spawn',
  method: 'POST',
  headers: { 'Content-Type': 'application/json',
             'Content-Length': Buffer.byteLength(payload) },
  timeout: 8000,
}, (res) => {
  let buf = '';
  res.on('data', (d) => { buf += d; });
  res.on('end', () => {
    let j = {};
    try { j = JSON.parse(buf); } catch {}
    if (res.statusCode === 200 && j.ok && j.agentId) {
      // Агент справді поїхав -> відкладену задачу можна прибрати. Тільки СВІЙ файл із
      // черги: якщо --task-file дала людина, він не наш і ми його не чіпаємо.
      if (a.taskFile && path.dirname(path.resolve(a.taskFile)) === QUEUE_DIR) {
        try { fs.unlinkSync(a.taskFile); } catch { /* прибирання не критичне */ }
      }
      process.stdout.write('ok ' + j.agentId + '\n');
      process.exit(0);
    }
    // Зона зайнята: не помилка, а черга. Гілка стоїть ПЕРЕД загальною відмовою, бо
    // інакше конфлікт виглядав би як звичайний `err` і робота б просто не сталась.
    if (res.statusCode === 200 && j.ok === false && j.error === 'zone-conflict') {
      onZoneConflict(j);
      return;
    }
    // 200 {ok:false} is the "cap reached" / soft-refusal path — surface its reason.
    fail(j.error || ('server said ' + res.statusCode + ' ' + buf.slice(0, 200)));
  });
});

req.on('timeout', () => { req.destroy(); fail('server timeout on :' + a.port); });
req.on('error', (e) => {
  const down = e && (e.code === 'ECONNREFUSED' || e.code === 'ECONNRESET');
  fail((down ? 'Logopsis server not running on :' + a.port
             : String(e && e.message || e)) + ' — fall back to the normal Agent tool');
});

req.write(payload);
req.end();
