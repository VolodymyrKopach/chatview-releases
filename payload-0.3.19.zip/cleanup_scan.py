#!/usr/bin/env python3
"""Інтелектуальна чистка списку чатів: картка каналу, правила і захисти.

specs/smart-chat-cleanup, сабтаски S1 і S2.

ЧОМУ ДВА ШАРИ, А НЕ ОДИН ВИКЛИК МОДЕЛІ. Очевидне сміття впізнається ПРАВИЛОМ, а не
інтелектом: порожній канал це `len(index) == 0`, і кликати заради цього Sonnet означало б
платити за відповідь, яку дає одна перевірка. Тому тут живе шар, який працює миттєво,
безкоштовно і без мережі, а моделі дістається лише те, чого правилом не вирішити: чи
тема закрилась, чи це пауза; чи два канали про одне; чи лежить усередині рішення, яке
варто дістати перед архівом.

Побічний ефект цього поділу цінніший за економію: фіча ПРАЦЮЄ, коли модель недоступна.
Впав `claude`, немає ключа, скінчився ліміт — список кандидатів усе одно є.

ЩО ЦЕЙ МОДУЛЬ НЕ РОБИТЬ. Він нічого не архівує і не видаляє: тільки читає і повертає
пропозицію. Дія лишається за людиною і йде наявним `/api/channel-hide`.

ПРО ЗАХИСТИ (S2). Це не «ще одне правило», а протилежний за характером шар: він нічого
не пропонує, він ЗАБОРОНЯЄ. Ціна помилки тут найвища в усій фічі, бо пропозиція зачепити
канал, у якому просто зараз іде робота, коштує людині втраченої роботи. Тому захищений
канал не потрапляє НІ в кандидати, ні в картки, з яких збирається запит до моделі:
інакше модель запропонує його сама, і захист виявиться косметикою.
"""
import json
import os
import re
import time

# Скільки символів промпту людини їде в картку. Один багатослівний промпт не має права
# зʼїсти бюджет запиту на весь список.
SNIPPET_CHARS = 220
# Стеля «куцої історії» для правила про імʼя за замовчуванням.
SHORT_HISTORY = 5
# Скільки днів тиші треба, щоб куций канал перестав вважатись просто новим.
FRESH_DAYS = 3
# Імена, яких людина ніколи не давала: їх ставить сам застосунок.
_DEFAULT_NAME = re.compile(r'^(новий чат|new chat|code\s+\d{1,2}[:.]\d{2}|chat-\d+|cc-[0-9a-f]+)\s*$', re.I)
_MSG_FILE = re.compile(r'^\d{4}\.json$')


# ── читання диска ────────────────────────────────────────────────────────────

def _read_json(path, default=None):
    """Відсутній або битий файл це СТАН, а не аварія: канал міг ніколи не жити."""
    try:
        with open(path, encoding='utf-8') as fh:
            return json.load(fh)
    except (OSError, ValueError):
        return default


def channels_dir(root):
    return os.path.join(root, 'channels')


def registry(root):
    """Реєстр каналів. Історично файл буває і списком, і обгорткою з ключем channels."""
    raw = _read_json(os.path.join(channels_dir(root), 'index.json'), [])
    if isinstance(raw, dict):
        raw = raw.get('channels') or []
    return [c for c in raw if isinstance(c, dict) and c.get('id')]


def _first_text(widgets):
    """Текст бульбашки = перший текстовий віджет. Решта типів для картки не потрібна."""
    for w in widgets or []:
        if isinstance(w, dict) and w.get('type') == 'text' and (w.get('text') or '').strip():
            return w['text'].strip()
    return ''


def _snippet(text):
    text = ' '.join((text or '').split())
    return text[:SNIPPET_CHARS]


def _idle_days(iso):
    """Скільки днів тиші. Рахуємо від ОСТАННЬОГО повідомлення, а не від mtime теки:
    тека оновлюється службовими записами (план, сесія, usage) і показувала б активність
    там, де людина нічого не писала місяцями."""
    if not iso:
        return None
    for fmt in ('%Y-%m-%dT%H:%M:%S.%f%z', '%Y-%m-%dT%H:%M:%S%z', '%Y-%m-%dT%H:%M:%S'):
        try:
            t = time.strptime(iso, fmt)
            break
        except ValueError:
            continue
    else:
        return None
    try:
        stamp = time.mktime(t[:9])
    except (OverflowError, ValueError):
        return None
    return max(0, int((time.time() - stamp) // 86400))


# ── S1: картка каналу ────────────────────────────────────────────────────────

def channel_card(root, entry):
    """Усе, з чого модель зможе судити про канал, і НІЧОГО понад це.

    У картку їдуть метадані плюс ПЕРШИЙ і ОСТАННІЙ промпт людини. Тіла відповідей не
    беремо взагалі: вони найбільші за обсягом і найчутливіші за вмістом, а для питання
    «чи ця тема закрита» нічого не додають.
    """
    cid = entry.get('id')
    d = os.path.join(channels_dir(root), cid)
    idx = _read_json(os.path.join(d, 'index.json'), []) or []
    if not isinstance(idx, list):
        idx = []
    mine = [m for m in idx if isinstance(m, dict) and m.get('from') == 'Я']

    def text_of(meta):
        if not meta or not meta.get('file'):
            return ''
        return _snippet(_first_text(_read_json(os.path.join(d, meta['file']), [])))

    plan = _read_json(os.path.join(d, 'plan.json'), {}) or {}
    last_iso = ''
    for m in reversed(idx):
        if isinstance(m, dict) and m.get('iso'):
            last_iso = m['iso']
            break
    return {
        'id': cid,
        'label': entry.get('label') or '',
        'messages': len([m for m in idx if isinstance(m, dict)]),
        'mine': len(mine),
        'idle_days': _idle_days(last_iso),
        'first_user': text_of(mine[0] if mine else None),
        'last_user': text_of(mine[-1] if mine else None),
        'goal': (plan.get('goal') or '') if isinstance(plan, dict) else '',
    }


# ── S2: захисти ──────────────────────────────────────────────────────────────

def _has_queue(d):
    qd = os.path.join(d, 'queue')
    try:
        return any(f.endswith('.json') for f in os.listdir(qd))
    except OSError:
        return False


def _has_agent(d):
    """Файл агентів існує майже завжди; значення має НЕПОРОЖНІЙ вміст."""
    raw = _read_json(os.path.join(d, 'agents'), None)
    if isinstance(raw, list):
        return bool(raw)
    if isinstance(raw, dict):
        return bool(raw.get('agents') or raw)
    try:
        return bool(open(os.path.join(d, 'agents'), encoding='utf-8').read().strip())
    except OSError:
        return False


def protection(root, entry, open_ids=()):
    """Причина, з якої канал недоторканний, або None.

    Порядок перевірок від найдешевшої до найдорожчої, і він же порядок пріоритету в
    звіті: людина має бачити НАЙВАГОМІШУ причину, а не першу-ліпшу.
    """
    cid = entry.get('id')
    if entry.get('pinned'):
        return 'pinned'
    if entry.get('appId'):
        return 'app'
    if cid in set(open_ids or ()):
        # Які колонки відкриті, знає лише клієнт: у сервера даних про розкладку немає.
        # Мовчазне «сервер не бачить, отже можна» було б рівно тією помилкою, яка чіпає
        # те, на що людина зараз дивиться.
        return 'open'
    d = os.path.join(channels_dir(root), cid)
    if os.path.exists(os.path.join(d, 'busy')):
        return 'busy'
    if _has_queue(d):
        return 'queue'
    if _has_agent(d):
        return 'agent'
    return None


# ── S1: детерміновані правила ────────────────────────────────────────────────

def _rule(card):
    """Правило, за яким канал є очевидним сміттям, або None.

    Тут навмисно НЕМА правила про тишу. Довга тиша сама по собі нічого не доводить:
    тема могла закритись, а могла бути на паузі, і відрізнити ці два стани по числу днів
    неможливо. Це питання до моделі, а не до правила.
    """
    if card['messages'] == 0:
        return 'empty', 'жодного повідомлення: чат створили і не почали'
    if card['messages'] <= 2 and (card['idle_days'] is None or card['idle_days'] >= FRESH_DAYS):
        # Тиша тут не ознака сміття, а запобіжник проти протилежної помилки: два
        # повідомлення в каналі, якому два дні, означають «тема почалась щойно», а не
        # «тема не почалась». Спіймано живим прогоном на справжніх каналах.
        return 'tiny', 'одне-два повідомлення і давно без руху: разове питання'
    if _DEFAULT_NAME.match((card['label'] or '').strip()) and card['messages'] <= SHORT_HISTORY:
        return 'unnamed', 'назва за замовчуванням і куца історія: тему так і не назвали'
    return None


def scan(root, open_ids=(), entries=None):
    """Один прохід списком: картки, кандидати правил і перелік захищених.

    Архів (`hidden`) не розглядається взагалі: пропонувати прибрати вже прибране
    безглуздо, а разом з тим це найбільша частина реєстру, тож пропуск ще й найдешевший.

    `entries` дозволяє віддати ГОТОВИЙ реєстр замість читання одного файла. Це не зручність,
    а вимога правильності: канали живуть у двох файлах (`index.json` закомічений плюс
    `index.local.json`, gitignored overlay сесійних `cc-*`), і зливає їх сервер. Читаючи
    лише перший, чистка не бачила б рівно ті вкладки, які найчастіше і є сміттям.
    """
    cards, candidates, protected = [], [], []
    for entry in (registry(root) if entries is None else entries):
        if not isinstance(entry, dict) or not entry.get('id'):
            continue
        if entry.get('hidden'):
            continue
        why = protection(root, entry, open_ids)
        if why:
            protected.append({'id': entry.get('id'), 'label': entry.get('label') or '',
                              'reason': why})
            continue
        card = channel_card(root, entry)
        cards.append(card)
        hit = _rule(card)
        if hit:
            candidates.append(dict(card, rule=hit[0], reason=hit[1]))
    return {'cards': cards, 'candidates': candidates, 'protected': protected}


# ── S3: шар моделі ───────────────────────────────────────────────────────────
#
# Модель отримує те, чого правило не вирішує: чи тема закрилась, чи це пауза; чи два
# канали про одне; чи лежить усередині рішення, яке варто дістати перед архівом.
#
# ОДИН запит на весь список, а не запит на канал. Шістдесят викликів це хвилини
# очікування і гроші на вітер, а картки чудово складаються в одну таблицю.
#
# Модель ТІЛЬКИ пропонує. Її пропозиції приходять НЕпозначеними галочкою (на відміну від
# детермінованих кандидатів, де помилитись нема в чому), і жодна з них не виконується
# без окремого кліку людини.

MODEL = 'sonnet'          # стеля, названа власником прямо; вище не піднімаємось
MODEL_TIMEOUT = 170
# Скільки карток іде в ОДИН запит. Межа виведена заміром на живих каналах, а не з голови:
# 12 карток це 89 секунд, 24 це 82, а 46 не вкладаються у таймаут узагалі. Дух рішення
# «не запит на канал» лишається: сорок шість каналів це два виклики, а не сорок шість.
BATCH = 24

_PROMPT_HEAD = (
    'Ти чистиш список чатів у застосунку. Нижче таблиця каналів: кожен рядок це один '
    'чат з його назвою, кількістю повідомлень, днями тиші, ціллю плану та першим і '
    'останнім промптом людини.\n\n'
    'Назви ті канали, які людині СПОКІЙНО можна прибрати в архів. Ознаки: тема явно '
    'закрита; разова довідка; канал дублює інший за темою; експеримент або проба. НЕ '
    'пропонуй канал лише за те, що він давно без руху: пауза в роботі виглядає так само, '
    'як закрита тема, і помилитись тут дорожче, ніж пропустити.\n\n'
    'Відповідай ЛИШЕ компактним JSON-масивом, без прози і без фенсу. Кожен елемент: '
    '{"id": "id каналу з таблиці", "reason": "@REASON@"}. Якщо прибирати нема чого, '
    'віддай [].\n\n'
)

# Мова причини архівації (Д8). Джерело тут ІНТЕРФЕЙС, а не зміст розмов.
#
# Поле `reason` не залишається в моделі: воно їде в `suggested` і друкується рядком
# під назвою каналу в діалозі чистки, поруч із рамкою самого діалогу, яка мовний
# вибір уже поважає (картка провалу в server._cleanup_worker ходить через `_bt`).
# Тобто це підпис ІНТЕРФЕЙСУ, і людина з англійським застосунком бачила тут
# кирилицю серед англійського екрана.
#
# ЧЕСНО ПРО МЕЖУ: сусідні рядки того ж екрана українською ЛИШАЮТЬСЯ. Причини
# детермінованого шару (`_rule`) і тексти провалів (`_HUMAN`, `_human_error`), а
# також запасне `модель радить прибрати` нижче, це окремі місця, яких ця задача не
# називала, і вони свідомо не чіпані. Тобто екран стане двомовним не повністю, і
# доробити його треба буде окремо.
#
# Це протилежний вибір до зведення і підсумку стиснення, і свідомо: ті два тексти
# КОНДЕНСУЮТЬ наявні повідомлення і мусять лишатись мовою розмови, а цей текст
# СУДИТЬ про канал і звертається до людини. Мова змісту тут дала б список, у якому
# кожен рядок іншою мовою, залежно від того, якою мовою колись велась та розмова.
#
# Мовним роблять рівно одне речення, а не весь промпт. Решта тексту це критерії
# відбору, які модель виконує, а не показує, і другий переклад коштував би подвійного
# супроводу без жодного нового факту для людини. Що модель СПРАВДІ слухається такого
# застереження всередині українського промпту, перевірено живим прогоном (той самий
# прийом, що і в COMPACT_SUMMARY_PROMPT).
_REASON_SPEC = {
    'uk': 'одне коротке речення українською, чому його можна прибрати',
    'en': 'one short sentence IN ENGLISH, why it can be archived. This prompt is '
          'written in Ukrainian, that is not the language of your answer: the '
          '"reason" values must be English',
}


def build_prompt(cards, lang=None):
    """Один запит на весь список. Картка йде рядком, а не JSON-обʼєктом: так вона
    коштує помітно менше токенів при тій самій читабельності для моделі.

    `lang` без значення означає мову застосунку ЗАРАЗ: у чистки нема ходу в черзі,
    з яким вона могла б розійтись у часі, тому це не спрощення, а точна поведінка
    (той самий випадок, що описаний у docstring `runner._bt`). Лінивий імпорт
    runner, бо на рівні модуля його тут нема, і ім'я `runner` у `suggest` зайняте
    викликачем моделі."""
    import runner as _runner
    if lang is None:
        lang = _runner.current_lang(None)
    head = _PROMPT_HEAD.replace('@REASON@', _runner._lang_text(_REASON_SPEC, lang))
    lines = []
    for c in cards:
        idle = 'ніколи' if c['idle_days'] is None else '%d дн' % c['idle_days']
        parts = ['id=%s' % c['id'], 'назва=%s' % (c['label'] or '?'),
                 'повідомлень=%d' % c['messages'], 'тиша=%s' % idle]
        if c.get('goal'):
            parts.append('ціль=%s' % c['goal'])
        if c.get('first_user'):
            parts.append('перший промпт=%s' % c['first_user'])
        if c.get('last_user') and c['last_user'] != c.get('first_user'):
            parts.append('останній промпт=%s' % c['last_user'])
        lines.append(' | '.join(parts))
    return head + '\n'.join(lines)


def _extract_json_array(text):
    """Витягти масив з відповіді. Модель регулярно обгортає його поясненням або фенсом,
    і втрачати через це всю відповідь було б марнотратством. Але ремонт тут НЕ робимо:
    зіпсований JSON це чесний провал, а не привід вгадувати наміри."""
    if not text:
        return None
    body = text.strip()
    m = re.search(r'\[.*\]', body, re.S)
    if not m:
        return None
    try:
        arr = json.loads(m.group(0))
    except ValueError:
        return None
    return arr if isinstance(arr, list) else None


# Людські причини провалу. У людину ніколи не летить код помилки: «exit-1» не каже їй
# нічого, а мовчазний провал ще гірший, бо виглядає як «нема що прибирати».
_HUMAN = {
    'no-claude': 'Не знайшов claude на цій машині, тому глибше за правила не дивився.',
    'timeout': 'Дослідження тривало надто довго, і я його спинив.',
    'parse': 'Модель відповіла не тим форматом, тому пропозицій від неї немає.',
}


def _human_error(code):
    if code in _HUMAN:
        return _HUMAN[code]
    if str(code).startswith('exit-'):
        return 'Дослідження завершилось помилкою, показую лише те, що знайшли правила.'
    return 'Дослідження не вдалось, показую лише те, що знайшли правила.'


def _claude_runner(prompt, timeout=MODEL_TIMEOUT):
    """Реальний виклик. Той самий патерн, що вже вживається в server.py для Sentry і
    ClickUp: свій таймаут, вихід тільки JSON, жодних інструментів (тут вони не потрібні,
    бо всі дані вже в промпті)."""
    import subprocess
    binp = _claude_bin()
    if not binp:
        return None, 'no-claude'
    try:
        p = subprocess.run([binp, '-p', prompt, '--model', MODEL,
                            '--allowedTools', '', '--output-format', 'json'],
                           capture_output=True, text=True, timeout=timeout)
    except subprocess.TimeoutExpired:
        return None, 'timeout'
    except Exception as e:                                    # noqa: BLE001
        return None, str(e)[:60]
    if p.returncode != 0:
        return None, 'exit-%s' % p.returncode
    try:
        env = json.loads(p.stdout)
        return (env.get('result', '') if isinstance(env, dict) else p.stdout), None
    except ValueError:
        return p.stdout, None


def _claude_bin():
    """Шлях до claude. Node і claude часто відсутні в PATH неінтерактивних процесів."""
    import shutil
    return shutil.which('claude') or ''


def suggest(root, runner=None, open_ids=(), cards=None):
    """Пропозиції моделі по каналах, яких не вирішило правило.

    Повертає {'suggested': [...], 'dropped': N, 'error': None|str}. Провал НІКОЛИ не
    підіймає виняток: шар моделі це надбудова, і його падіння не має права забирати з
    екрана те, що вже знайшли правила.

    Довгий список іде партіями. Партія, що впала, не забирає з собою вже отримані
    пропозиції: показуємо те, що є, і чесно називаємо, чому решти немає.
    """
    if cards is None:
        base = scan(root, open_ids)
        cards = [c for c in base['cards']
                 if c['id'] not in {x['id'] for x in base['candidates']}]
    if not cards:
        # Питати нема про що, і платити за порожній запит теж нема за що.
        return {'suggested': [], 'dropped': 0, 'error': None}

    run = runner or _claude_runner
    out, dropped, error = [], 0, None
    for start in range(0, len(cards), BATCH):
        part = cards[start:start + BATCH]
        text, err = run(build_prompt(part))
        if err:
            error = error or _human_error(err)
            continue
        arr = _extract_json_array(text)
        if arr is None:
            error = error or _human_error('parse')
            continue
        known = {c['id']: c for c in part}
        seen = {s['id'] for s in out}
        for item in arr:
            if not isinstance(item, dict):
                dropped += 1
                continue
            cid = str(item.get('id') or '')
            # Звіряємо з тим, що РЕАЛЬНО пішло в запит, а не з усім реєстром: так вигадане
            # id і будь-який захищений канал відпадають одним і тим самим рухом.
            if cid not in known or cid in seen:
                dropped += 1
                continue
            seen.add(cid)
            out.append(dict(known[cid],
                            reason=(item.get('reason') or '').strip() or 'модель радить прибрати',
                            source='model', checked=False))
    return {'suggested': out, 'dropped': dropped, 'error': error}


def scan_full(root, runner=None, open_ids=()):
    """Повний прохід: правила, захисти і, якщо є про що питати, шар моделі."""
    base = scan(root, open_ids)
    rest = [c for c in base['cards'] if c['id'] not in {x['id'] for x in base['candidates']}]
    got = suggest(root, runner=runner, open_ids=open_ids, cards=rest)
    for c in base['candidates']:
        # Детерміновані приходять ПОЗНАЧЕНИМИ: там помилитись нема в чому.
        c.setdefault('source', 'rule')
        c.setdefault('checked', True)
    return dict(base, suggested=got['suggested'], dropped=got['dropped'], error=got['error'])
