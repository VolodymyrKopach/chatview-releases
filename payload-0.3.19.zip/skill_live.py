"""Живий пошук скілів у GitHub (фаза 4 стору скілів).

ЩО ЦЕ. Запасний шлях, і тільки він. Локальний пошук іде по знімку каталогу, а
знімок за визначенням не знає про скіл, опублікований учора. Коли локальна видача
порожня, користувач бачив порожній екран і робив висновок «такого скіла не існує», хоча
насправді ми просто не встигли його зібрати. Цей модуль іде в GitHub НАЖИВО і
приносить щонайбільше три кандидати.

ЧОГО ЦЕ НЕ РОБИТЬ (не-цілі спеки, вшиті в код, а не в наміри):
  * не пише НІЧОГО в skills-library: знайдене живе у памʼяті процесу і вмирає
    разом з ним. Індекс наповнює тільки збирач за розкладом;
  * не віддає більше трьох кандидатів (LIMIT нижче це стеля, не типове значення);
  * не працює сам по собі: викликається лише за явним натисканням кнопки.

ЩО ПЕРЕВИКОРИСТАНО зі збирача фази 3 (harvest-skills.py) і чому саме це:
  license_of   — та сама семантика ліцензії («немає» проти «нестандартна»), інакше
                 сире і зібране казали б користувачу різними словами про одне й те саме;
  parse_md     — ті самі ворота якості: без YAML-frontmatter це не скіл, а нотатка;
  derive_category, slugify, now_iso — щоб id і категорія кандидата виглядали рівно
                 так, як у каталозі, і встановлений сирий скіл нічим не відрізнявся
                 від зібраного ПІСЛЯ того, як пройшов карантин.

ЧОМУ ТРАНСПОРТ ВЛАСНИЙ, а не gh_get зі збирача. gh_get на 403 засинає до вікна
скидання ліміту (до 65 секунд на спробу, три спроби). Для нічного збирача це
правильно, для кнопки в інтерфейсі це три хвилини мовчазного спінера. Тут запит
мусить або відповісти, або чесно сказати «не вийшло», тому дедлайн один на весь
пошук, а помилка класифікується одразу.

ЧОМУ ДВА ЗАПИТИ ПОШУКУ, а не один. Заміряно на живому API 2026-08-06:
  «linkedin skill topic:claude-skills»  -> 41 репозиторій, у топі рівно те, що
      треба (linkedin-post-writing-skill, linkedin-skills);
  «fail deploy topic:claude-skills»     -> 0, тема просто не проставлена;
  «fail deploy skill in:name,description» -> 15, перший railway-deploy-skill.
Тобто тема дає точність там, де вона є, а запасна форма ловить решту. Синтаксис
«(topic:a OR topic:b)» GitHub у пошуку репозиторіїв не розуміє: перевірено, обидва
такі запити повернули total_count 0, тому теми в одному запиті не обʼєднати.
Свідомо НЕ додаємо in:readme: з ним у видачу приїжджають awesome-списки на 500к
зірок, які згадують усе на світі і не містять жодного скіла.
"""
import os
import re
import time
import json
import threading
import importlib.util
import urllib.error
import urllib.parse
import urllib.request

DIR = os.path.dirname(os.path.abspath(__file__))

LIMIT = 3                  # стеля кандидатів: це рятівний круг, а не другий каталог
PROBE_LIMIT = 6            # скільки репозиторіїв перевіряємо на наявність SKILL.md
DEADLINE = 16.0            # секунд на весь пошук, разом із мережею
CACHE_TTL = 600            # відповідь на той самий запит 10 хвилин з памʼяті
TREE_TTL = 3600            # дерево файлів репозиторію годину
REGISTRY_TTL = 7200        # скільки кандидат лишається встановлюваним
TOPIC = 'claude-skills'    # найлюдніша тема екосистеми (заміряно, див. докстрінг)
UA = 'logopsis-live-search'

_HS = None
_HS_LOCK = threading.Lock()
_TOKEN = ['', 0.0]         # (значення, коли перевіряли): env_token ходить у мережу
TOKEN_TTL = 1800


def _hs():
    """Збирач фази 3 як модуль. Ім'я файлу з дефісом, тому importlib, а не import.
    Ліниво: без живого пошуку модуль не потрібен, а він тягне git і мережу."""
    global _HS
    with _HS_LOCK:
        if _HS is None:
            spec = importlib.util.spec_from_file_location(
                'harvest_skills', os.path.join(DIR, 'harvest-skills.py'))
            mod = importlib.util.module_from_spec(spec)
            spec.loader.exec_module(mod)
            _HS = mod
    return _HS


# ── памʼять процесу (НЕ індекс) ────────────────────────────────────────────
_CACHE = {}                # запит -> (ts, payload)
_TREES = {}                # repo -> (ts, [шляхи])
_REG = {}                  # id -> (ts, запис)
_LOCK = threading.Lock()


def _prune(store, ttl):
    now = time.time()
    for k in [k for k, (ts, _v) in store.items() if now - ts > ttl]:
        store.pop(k, None)


def remember(records):
    """Покласти кандидатів у памʼять, щоб карантин потім знайшов їх за id.

    Це НЕ індекс: словник у процесі, нічого на диску, TTL дві години. Без цього
    кроку встановлення сирого кандидата впало б у «unknown helper», бо в
    skills-library його нема і не буде."""
    with _LOCK:
        _prune(_REG, REGISTRY_TTL)
        for r in records:
            if r.get('id'):
                _REG[r['id']] = (time.time(), r)


def recall(skill_id):
    """Запис за id, якщо він ще живий. Повертає None, і це нормально: протух
    кандидат означає «пошукай наново», а не «встановлюй наосліп»."""
    with _LOCK:
        _prune(_REG, REGISTRY_TTL)
        hit = _REG.get(skill_id)
    return dict(hit[1]) if hit else None


# ── запит до GitHub ────────────────────────────────────────────────────────
def _get(url, token='', timeout=12.0):
    headers = {'Accept': 'application/vnd.github+json', 'User-Agent': UA}
    if token:
        headers['Authorization'] = f'Bearer {token}'
    req = urllib.request.Request(url, headers=headers)
    with urllib.request.urlopen(req, timeout=timeout) as r:
        return json.loads(r.read().decode('utf-8'))


def humane(exc):
    """(причина, речення для людини). Ліміт і відсутня мережа це РІЗНІ поради,
    тому й тексти різні: у першому випадку треба почекати, у другому перевірити
    інтернет. І там, і там окремо кажемо, що локальна видача лишилась на місці,
    бо саме це питання виникає першим."""
    tail = ' Локальні результати лишились на місці.'
    if isinstance(exc, urllib.error.HTTPError):
        if exc.code in (403, 429):
            return ('rate-limit',
                    'GitHub вичерпав ліміт запитів для цієї машини. '
                    'Спробуй за кілька хвилин.' + tail)
        if exc.code == 422:
            return ('bad-query',
                    'GitHub не зрозумів запит. Спробуй іншими словами.' + tail)
        if exc.code in (401,):
            return ('auth',
                    'GitHub не прийняв токен з .env. Пошук пішов без ключа, '
                    'ліміт менший.' + tail)
        return ('http', f'GitHub відповів помилкою {exc.code}.' + tail)
    if isinstance(exc, urllib.error.URLError):
        return ('offline',
                'Не достукався до GitHub: схоже, нема мережі.' + tail)
    if isinstance(exc, TimeoutError) or 'timed out' in str(exc).lower():
        return ('timeout',
                'GitHub не відповів вчасно.' + tail)
    return ('error', f'Живий пошук не вийшов: {str(exc)[:120]}.' + tail)


def terms(query):
    """Український запит -> англійські слова для GitHub.

    Користувач пише «у мене впав деплой», а GitHub такого не знає. Словник UA→EN уже
    живе в локальному пошуку, і тут він ЧИТАЄТЬСЯ (skill_search не змінюється):
    одне англійське слово на кожне українське, максимум три, бо пошук по
    репозиторіях складає слова через І, і пʼять синонімів дають нуль."""
    import skill_search as _sks
    pairs = _sks.expand(_sks.tok(query or ''))
    picked, seen = [], set()
    for term, _w, src in pairs:
        if src in seen:
            continue                       # одне слово на кожне джерело
        if not re.match(r'^[a-z0-9][a-z0-9.+#-]*$', term):
            continue                       # кирилиця в GitHub не шукається
        seen.add(src)
        picked.append(term)
    if not picked:                          # запит без латиниці і без словника
        picked = [w for w in re.findall(r'[a-zA-Z0-9]{3,}', query or '')][:3]
    return picked[:3]


def _search_repos(q, token, timeout):
    url = ('https://api.github.com/search/repositories?q='
           + urllib.parse.quote(q) + '&per_page=15')
    data = _get(url, token=token, timeout=timeout)
    return data.get('items') or []


def _skill_md_path(repo, branch, token, timeout):
    """Шлях до SKILL.md у репозиторії або None. Це ЖОРСТКИЙ фільтр зі спеки:
    нема SKILL.md, нема кандидата, скільки б зірок не було.

    Спершу пробуємо корінь через raw.githubusercontent: він безлімітний, а
    «один скіл = один репозиторій» це найчастіший випадок. Дерево файлів
    питаємо лише коли в корені порожньо, бо воно вже їсть основний ліміт
    (60 запитів на годину без токена)."""
    now = time.time()
    with _LOCK:
        _prune(_TREES, TREE_TTL)
        hit = _TREES.get(repo)
    if hit:
        return hit[1]

    found = None
    raw = f'https://raw.githubusercontent.com/{repo}/HEAD/SKILL.md'
    try:
        req = urllib.request.Request(raw, headers={'User-Agent': UA})
        with urllib.request.urlopen(req, timeout=min(6.0, timeout)) as r:
            if r.status == 200 and len(r.read(200)) > 60:
                found = 'SKILL.md'
    except Exception:
        pass

    if found is None:
        url = (f'https://api.github.com/repos/{repo}/git/trees/'
               f'{urllib.parse.quote(branch)}?recursive=1')
        data = _get(url, token=token, timeout=timeout)
        paths = [n.get('path') for n in (data.get('tree') or [])
                 if n.get('type') == 'blob'
                 and str(n.get('path', '')).lower().endswith('skill.md')]
        # найближчий до кореня: у монорепо з сотнею скілів беремо той, що
        # лежить найвище, інакше кандидат представлений випадковим із сотні
        paths.sort(key=lambda p: (p.count('/'), len(p)))
        found = paths[0] if paths else None

    with _LOCK:
        _TREES[repo] = (now, found)
    return found


def cached_token():
    """Токен з .env, перевірений живим запитом і закешований на пів години.

    Кеш тут не про швидкість, а про поведінку: env_token() СТУКАЄ в /rate_limit
    на кожен виклик і друкує попередження, коли токен протух. Без кешу кожне
    натискання кнопки коштувало б зайвий запит до GitHub з того самого ліміту,
    який ми й економимо, плюс рядок у лог сервера."""
    if time.time() - _TOKEN[1] < TOKEN_TTL:
        return _TOKEN[0]
    try:
        val = _hs().env_token() or ''
    except Exception:
        val = ''
    _TOKEN[0], _TOKEN[1] = val, time.time()
    return val


def _fetch_raw(repo, branch, path, timeout=8.0):
    url = (f'https://raw.githubusercontent.com/{repo}/'
           f'{urllib.parse.quote(branch)}/{urllib.parse.quote(path)}')
    req = urllib.request.Request(url, headers={'User-Agent': UA})
    with urllib.request.urlopen(req, timeout=timeout) as r:
        return r.read(200000).decode('utf-8', 'replace')


def _record(item, path, text, id_taken=None):
    """Кандидат у формі запису каталогу. level='raw' це не косметика: рівно за
    ним фронт малює окрему секцію, а карантин лишається обовʼязковим."""
    hs = _hs()
    repo = item.get('full_name') or ''
    owner = repo.split('/')[0]
    branch = item.get('default_branch') or 'main'
    name = desc = ''
    tags = []
    if text:
        # BOM зустрічається в реальних SKILL.md і ламає розпізнавання
        # frontmatter (перевірка йде по startswith('---')). Заміряно на
        # dungnotnull/organic-honey-forest-beekeeping-agent-skill: без цього
        # рядка кандидат приїхав з назвою «Air-gap / offline run (no API key
        # needed):», підчепленою з випадкового заголовка всередині файлу.
        name, desc, tags, had_fm = hs.parse_md(text.lstrip('﻿'))
        if not had_fm:
            # Без frontmatter це або чернетка, або документація. Виловлювати
            # назву з першого-ліпшого заголовка означає показати користувачу випадковий
            # рядок як імʼя скіла, тому краще чесні дані репозиторію.
            name = desc = ''
    if not name:
        name = (repo.split('/')[-1] or 'skill').replace('-', ' ')
    if not desc:
        desc = (item.get('description') or '').strip()[:300]
    stem = os.path.basename(os.path.dirname(path)) or repo.split('/')[-1]
    if stem.lower() in ('', '.', 'skill'):
        stem = repo.split('/')[-1]
    sid = hs.slugify(f'{owner}-{stem}')
    if id_taken and id_taken(sid):
        # id зайнятий записом каталогу: інакше встановлення поїхало б у ЧУЖИЙ,
        # уже зібраний скіл з тим самим іменем, і людина поставила б не те, що бачила
        sid = hs.slugify(f'{sid}-live')
    sub = os.path.dirname(path)
    url = (f'https://github.com/{repo}/tree/{branch}/{sub}' if sub
           else f'https://github.com/{repo}/blob/{branch}/SKILL.md')
    return {
        'id': sid,
        'name': name[:80],
        'description': desc,
        'category': hs.derive_category(path, tags, name, desc,
                                       item.get('topics') or []),
        'tags': tags,
        'source': repo,
        'license': hs.license_of(item),
        'install': 'manual-git',
        'url': url,
        'badge': 'yellow',
        'icon': '🧩',
        'stars': item.get('stargazers_count') or 0,
        'updated': (item.get('pushed_at') or '')[:10],
        'path': path,
        # ── прапорці чесності ──
        'live': True,        # прийшов з мережі просто зараз
        'scanned': False,    # збирач його не бачив, ніхто його не читав
        'level': 'raw',      # «сире»: окрема секція у фронті
        'hasCode': False,    # невідомо до скану, і невідоме не називаємо «нема коду»
    }


def public(rec):
    """Форма для фронта. Свідомо вужча за запис: шлях і сирі теги фронту не
    потрібні, а от джерело, зірки й дата потрібні, бо саме за ними людина вирішує,
    чи взагалі відкривати цього кандидата."""
    return {
        'id': rec.get('id'),
        'name': rec.get('name'),
        'description': rec.get('description'),
        'icon': rec.get('icon'),
        'category': rec.get('category'),
        'source': rec.get('source'),
        'url': rec.get('url'),
        'stars': rec.get('stars') or 0,
        'updated': rec.get('updated'),
        'license': rec.get('license'),
        'level': 'raw',
        'live': True,
        'scanned': False,
    }


def search(query, limit=LIMIT, token=None, id_taken=None, deadline=DEADLINE):
    """Живий пошук. Ніколи не кидає: гірший сценарій це ok:false з причиною.

    -> {ok, query, githubQuery, results:[public], cached, authenticated,
        probed, seconds} або {ok:false, reason, error, results:[]}"""
    q = (query or '').strip()
    limit = max(1, min(LIMIT, int(limit or LIMIT)))
    if not q:
        return {'ok': True, 'query': '', 'results': [], 'cached': False,
                'note': 'порожній запит'}

    ckey = f'{q}|{limit}'
    with _LOCK:
        _prune(_CACHE, CACHE_TTL)
        hit = _CACHE.get(ckey)
    if hit:
        out = dict(hit[1])
        out['cached'] = True
        remember([r for r in out.pop('_records', [])] or [])
        return out

    t0 = time.time()
    if token is None:
        token = cached_token()
    words = terms(q)
    gq = ' '.join(words)
    if not gq:
        # Заміряно на живому :5555: «керувати вуликом» не має ні латиниці, ні
        # запису в словнику, тому запит вироджувався в «topic:claude-skills» без
        # жодного слова і GitHub чесно віддавав найзірковіші репозиторії
        # екосистеми. Три випадкові плагіни, подані як відповідь на питання про
        # вулики, це рівно той шум, від якого захищає спека, і мовчазна брехня
        # гірша за чесне «не зрозумів».
        # Мова картки (Д9). Це відмова, яку читає ЛЮДИНА, тому мова тут інтерфейсу,
        # тим самим правилом, що й решта карток беку: `_bt` без каналу означає мову
        # застосунку зараз, бо у стору скілів нема ходу в черзі, з яким він міг би
        # розійтись у часі. Лінивий імпорт runner, бо на рівні модуля його тут нема
        # (той самий прийом, що в agent_room і server._bt).
        import runner as _runner
        return {'ok': False, 'query': q, 'githubQuery': '', 'reason': 'no-terms',
                'error': _runner._bt({
                    'uk': 'Не зміг перекласти цей запит для GitHub. Спробуй '
                          'кількома словами англійською, наприклад «beekeeping».',
                    'en': 'Could not turn this query into something GitHub '
                          'understands. Try a couple of words in English, for '
                          'example "beekeeping".',
                }),
                'results': []}

    def left():
        return deadline - (time.time() - t0)

    # 1. тема екосистеми (точно), 2. запасна форма (широко). Другий запит лише
    # якщо перший не набрав кандидатів: пошук GitHub без токена це 10 запитів
    # на хвилину, і палити їх парами на кожен клік не можна.
    # Три форми запиту від найточнішої до найширшої. Наступна йде В ХІД ЛИШЕ
    # тоді, коли попередня не дала жодного репозиторію: кожен захід це запит з
    # ліміту 10 на хвилину без токена.
    #
    # Третя форма зʼявилась після заміру на живому API: «homebrewing beer recipe
    # skill in:name,description» це І чотирьох слів у назві чи описі, і GitHub
    # чесно віддав нуль, хоча скіли про пиво там є. Тому останній захід лишає
    # ОДНЕ, найперше слово запиту: краще ширше і з фільтром SKILL.md, ніж нічого.
    queries = [f'{gq} topic:{TOPIC}'.strip(), f'{gq} skill in:name,description'.strip()]
    if len(words) > 1:
        queries.append(f'{words[0]} skill in:name,description')
    items, seen_repos, err = [], set(), None
    for gh_q in queries:
        if left() < 4:
            break
        try:
            for it in _search_repos(gh_q, token, timeout=min(10.0, left())):
                full = it.get('full_name')
                if not full or full in seen_repos:
                    continue
                if it.get('archived') or it.get('disabled'):
                    continue
                seen_repos.add(full)
                items.append(it)
        except Exception as e:
            err = e
            continue
        if items:
            break

    if not items and err is not None:
        reason, msg = humane(err)
        return {'ok': False, 'query': q, 'githubQuery': gq, 'reason': reason,
                'error': msg, 'results': [],
                'seconds': round(time.time() - t0, 2)}

    verified, probed = [], 0
    for it in items[:PROBE_LIMIT]:
        if left() < 3:
            break
        probed += 1
        repo = it.get('full_name')
        branch = it.get('default_branch') or 'main'
        try:
            path = _skill_md_path(repo, branch, token, timeout=min(8.0, left()))
        except Exception as e:
            err = e
            continue
        if not path:
            continue
        try:
            text = _fetch_raw(repo, branch, path, timeout=min(8.0, left()))
        except Exception:
            text = ''
        verified.append((it, path, text))

    # Сортування за зірками серед ПЕРЕВІРЕНИХ (жорсткий фільтр SKILL.md уже
    # відсік шум). Порядок саме такий, як у спеці: фільтр по файлу, потім зірки.
    verified.sort(key=lambda v: -(v[0].get('stargazers_count') or 0))
    records = [_record(it, path, text, id_taken=id_taken)
               for (it, path, text) in verified[:limit]]
    remember(records)

    out = {'ok': True, 'query': q, 'githubQuery': gq,
           'results': [public(r) for r in records],
           'cached': False, 'authenticated': bool(token),
           'probed': probed, 'candidates': len(items),
           'seconds': round(time.time() - t0, 2)}
    if not records and err is not None:
        # нічого не знайшли І дорогою була помилка: причина важливіша за «нема»
        reason, msg = humane(err)
        out.update({'ok': False, 'reason': reason, 'error': msg})
        return out
    with _LOCK:
        _CACHE[ckey] = (time.time(), dict(out, _records=records))
    return out
