#!/usr/bin/env node
/**
 * agent-bridge-router.cjs. PreToolUse hook на ВСІ спавн-інструменти харнесу.
 *
 * ОДНЕ ПРАВИЛО: харнесного способу породити роботу або дочекатись її в цьому
 * проєкті НЕ ІСНУЄ. Кожен такий виклик безумовно відхиляється і перенаправляється
 * у наш реєстр: місток (agent-run.cjs, agent-batch.cjs) або вартовий (watch.cjs).
 * Винятків нема.
 *
 * ЧОМУ СПИСОК, А НЕ ДВА ІМЕНІ (рішення власника, 2026-08-12). Хук народився на Task|Agent і рівно
 * стільки й знав. 2026-08-11 сесія запустила глибокий пошук через Workflow: чотири
 * паралельні агенти плюс фаза перевірки джерел, усе всередині ходу, повз реєстр, повз
 * панель «Процеси». Формально правило не порушене (Agent tool ніхто не кликав), а
 * фактично сталось рівно те, від чого хук ставили: робота, якої власник не бачить і не
 * може спинити. Дірка не в правилі, а в тому, що інструментів породження в харнесі
 * більше одного. Тому тут ТАБЛИЦЯ імен, і кожне ім'я має власну заміну в тексті
 * відмови: заборона без готової команди просто зробить роботу гіршою.
 *
 * ДВА СПИСКИ МУСЯТЬ ЗБІГАТИСЬ. matcher у .claude/settings.json вирішує, чи хук взагалі
 * покличуть, а SPAWN_TOOLS тут вирішує, чи він відхилить. Розійшлись = тиха дірка
 * (саме так і жив Workflow: у matcher його додали раніше, ніж сюди). Збіжність
 * прибита тестом tests/unit/test_agent_bridge_router.mjs.
 *
 * НАВІЩО. Харнес крутить субагента ВСЕРЕДИНІ поточного ходу (claude -p).
 * Коли процес Claude Code завершується, субагент помирає разом з ним:
 * нуль коду, нуль комітів, нуль звіту. Інциденти: chat-46, Publisher
 * 2026-08-02, і рецидив 2026-08-03 (два дослідницькі Opus вбито, робота
 * втрачена). У ТІЙ САМІЙ розмові агент через місток пережив кілька ходів
 * і доробив до коміту f9bca64. Різниця лобова.
 *
 * ЧОМУ БЕЗУМОВНО, А НЕ ПО ЕВРИСТИЦІ. Попередник (agent-detach-gate.cjs,
 * видалений комітом 06b7199) міряв «довгу» задачу порогом символів плюс
 * будівельними тригерами. Саме евристика і дала збій: дослідницька задача
 * без будівельних дієслів проходила повз гейт і вмирала. Плюс поруч жила
 * друга, суперечлива вимога прозою («Agent tool вільно й за дефолтом»), і
 * модель поплила на неї. Тому тут нуль евристик, нуль регулярок, нуль
 * порогів: одна перевірка імені інструмента і deny.
 *
 * ПОБІЧНИЙ ЕФЕКТ ВІД НУЛЯ РЕГУЛЯРОК. У JS `\w` це рівно [A-Za-z0-9_], тому
 * `\b` перед кириличною літерою НЕ є межею слова, і всі україномовні тригери
 * попередника були мертві. Якщо колись сюди все ж додаватимуть матчинг
 * українських слів: тільки lookbehind (?<![а-яіїєґА-ЯІЇЄҐ]), ніколи не `\b`.
 *
 * КОНТРАКТ ХУКА (звірено з https://code.claude.com/docs/en/hooks, 2026-08-03):
 *   stdin : { session_id, cwd, hook_event_name:"PreToolUse", tool_name, tool_input }
 *   блок  : exit 0 + stdout
 *           {"hookSpecificOutput":{"hookEventName":"PreToolUse",
 *             "permissionDecision":"deny","permissionDecisionReason":"..."}}
 *   пропуск: exit 0 + ПОРОЖНІЙ stdout.
 *   permissionDecision приймає allow|deny|ask|defer. Ми віддаємо РІВНО "deny":
 *   він іде В МОДЕЛЬ системним нагадуванням і НЕ показує власнику модалку. "ask"
 *   не використовуємо ніде: саме він і був би спливаючим вікном.
 *   permissionDecision:"allow" не виводимо НІКОЛИ: то обхід дозволів користувача.
 *
 * FAIL-OPEN. Будь-яка внутрішня помилка = тихий пропуск (exit 0, порожній
 * stdout). Краще пропустити виклик, ніж заблокувати роботу назовсім.
 *
 * ЕСКЕЙП (один, для людини, не для моделі):
 *   <repoRoot>/.claude/gates-off   файл-маркер, глушить усі гейти репо.
 *
 * Крос-платформа: чистий node, без .sh, без хардкод-шляхів.
 */
'use strict';

const fs = require('fs');
const path = require('path');

// Дзеркалення імен змінних середовища (CHATVIEW_* <-> LOGOPSIS_*) під час ребренду.
// Мусить стояти вище за перше читання process.env у цьому файлі: у власника
// лишились запущені служби і аліаси зі старими іменами. Контракт: brand-env.cjs.
require("../brand-env.cjs")

/**
 * ТАБЛИЦЯ: ім'я інструмента харнесу -> вид заміни, яку друкуємо в тексті відмови.
 *
 *   agent  Task/Agent: одне й те саме делегування, Task у Claude Code, Agent у SDK.
 *          TaskCreate/RemoteTrigger: та сама суть (породити роботу) іншими дверима.
 *   batch  Workflow: пачка агентів плюс фази. Замінюється agent-batch.cjs + watch.cjs.
 *   watch  ScheduleWakeup/Monitor: «дочекатись і зробити». Це і є вартовий.
 *   cron   CronCreate: заміни один-в-один нема, і текст це чесно каже.
 *   talk   SendMessage: detached-агент харнесних повідомлень не читає взагалі.
 */
const SPAWN_TOOLS = {
  Task: 'agent',
  Agent: 'agent',
  TaskCreate: 'agent',
  RemoteTrigger: 'agent',
  Workflow: 'batch',
  ScheduleWakeup: 'watch',
  Monitor: 'watch',
  CronCreate: 'cron',
  SendMessage: 'talk',
};

/** Джерело правди для matcher у settings.json. Тест звіряє обидва напрямки. */
const DENIED_TOOLS = Object.keys(SPAWN_TOOLS);

// ── утиліти ─────────────────────────────────────────────────────────────────

/**
 * Корінь репо. CLAUDE_PROJECT_DIR ставить сам харнес; фолбек рахує глибину
 * від цього файлу (tools/viz/chat/hooks/ = чотири рівні вгору).
 */
function repoRoot() {
  if (process.env.CLAUDE_PROJECT_DIR) return process.env.CLAUDE_PROJECT_DIR;
  return path.resolve(__dirname, '..', '..', '..', '..');
}

function logPath() {
  if (process.env.GATES_LOG) return process.env.GATES_LOG;
  return path.join(repoRoot(), '.claude', 'gates.jsonl');
}

/** Лічильник рішень. Сам ніколи не кидає. */
function record(entry) {
  try {
    const p = logPath();
    fs.mkdirSync(path.dirname(p), { recursive: true });
    fs.appendFileSync(p, JSON.stringify(Object.assign({
      ts: new Date().toISOString(),
      gate: 'agent-bridge-router',
    }, entry)) + '\n');
  } catch { /* лічильник не сміє ламати гейт */ }
}

// ── текст заборони ──────────────────────────────────────────────────────────

/**
 * Готова інструкція ДЛЯ МОДЕЛІ (не для людини). Її задача: щоб модель не гадала,
 * а просто перевикликала Bash з правильною командою.
 *
 * Префікс nvm обовʼязковий: node НЕ в PATH у цих сесіях, і без нього місток
 * падає з `command not found: node` та виглядає зламаним.
 *
 * @param {string} channel  id каналу-власника, якщо його видно з оточення
 * @param {string} label    людська назва агента для панелі «Процеси»
 */
/**
 * Де лежить місток і на якому порту сервер. Дві реальності, один хук (рішення власника, 2026-08-05).
 *
 * У РЕПО: канонічна команда з CLAUDE.md і памʼяті це `node scripts/agent-run.cjs`,
 * і міняти її не можна, тому коли форвардер на місці, друкуємо рівно її.
 * У ПАКОВАНІЙ АПЦІ репо нема взагалі: там реалізація лежить сусідньою текою від
 * цього хука (payload/agent-run.cjs поруч із payload/hooks/), тому друкуємо
 * абсолютний шлях до сусіда. Порт у пакованій апці авто-підбирається, тож 5555
 * там неправильний; беремо живий з оточення.
 *
 * @param {object} env оточення (process.env або підробка в тестах)
 * @param {string} [platform] process.platform або підробка в тестах
 */
function bridge(env, platform) {
  const e = env || {};
  const port = String(e.LOGOPSIS_PORT || e.VIZ_CHAT_PORT || '5555');
  const win = isWin(platform);
  /**
   * Репо-відносний шлях, якщо форвардер на місці; інакше сусід біля цього хука.
   * На Windows шлях ЗАВЖДИ абсолютний і в лапках: там немає гарантії, що модель
   * стоїть у корені репо (PowerShell стартує де завгодно), а пробіли в шляху
   * (`C:\Users\...\WebStorm Projects\`) без лапок ріжуть команду навпіл.
   */
  const resolve = (name) => {
    const repoCmd = path.join(repoRoot(), 'scripts', name);
    const sibling = path.resolve(__dirname, '..', name);
    let abs = repoCmd;
    try {
      if (!fs.existsSync(repoCmd) && fs.existsSync(sibling)) {
        return win ? '"' + sibling + '"' : JSON.stringify(sibling);
      }
    } catch { /* fail-open: лишається репо-шлях */ }
    return win ? '"' + abs + '"' : 'scripts/' + name;
  };
  return {
    cmd: resolve('agent-run.cjs'),
    batch: resolve('agent-batch.cjs'),
    watch: resolve('watch.cjs'),
    port,
    win,
  };
}

/** Спільна шапка команди на POSIX: без nvm-префікса буде `command not found: node`. */
const NVM = 'export NVM_DIR="$HOME/.nvm" && source "$NVM_DIR/nvm.sh" && nvm use 20 >/dev/null && \\';

/**
 * ДВІ ОС, ДВА ЗРАЗКИ КОМАНДИ (аудит specs/windows-parity/audit-process.md, BLOCK 7).
 *
 * Хук не радить, а ДИКТУЄ: харнесний Agent він блокує, тож єдиний дозволений шлях це
 * та команда, яку він друкує. Поки зразок був один, він був bash-only (`export NVM_DIR`,
 * `source nvm.sh`, heredoc `<<'TASK'`), і на Windows це синтаксична помилка в обох
 * шелах. Тобто фонових агентів на Windows не завести взагалі, причому провал виглядає
 * як «місток зламався», а не «команда не для цієї ОС». Самі `agent-run.cjs`,
 * `agent-batch.cjs` і `watch.cjs` портативні; ламалась рівно ця обгортка.
 *
 * Windows-форма трьома рішеннями:
 *   1. НУЛЬ nvm. Там node ставиться інсталятором і лежить у PATH; nvm.sh не існує.
 *   2. Довгий текст їде через ФАЙЛ, а не heredoc: `Get-Content -Raw -Encoding UTF8`
 *      у трубу. Побічний виграш той самий, заради якого heredoc і брали на маку:
 *      кирилиця і лапки не проходять через argv, де їх псує кодова сторінка консолі
 *      (речовий доказ у .claude/settings.json:118, PowerShell віддав «?????????»).
 *   3. Одна команда = ОДИН рядок. У PowerShell перенос це не `\`, а `` ` ``, і саме
 *      на цьому модель спотикається найчастіше. Довгий рядок негарний, зате копіюється
 *      без правок.
 */
function isWin(platform) { return String(platform || process.platform) === 'win32'; }

/** Windows: як подати довгий текст у stdin без heredoc. Два кроки, обидва явні. */
function winStdin(file, what) {
  return [
    'Крок 1. Постановку поклади у ФАЙЛ ' + file + ' (Write tool), кодування UTF-8.',
    '        Heredoc-а в PowerShell нема, а кирилиця і лапки в argv псуються кодовою',
    '        сторінкою консолі. Всередині: ' + what,
    'Крок 2. Спавн однією командою (текст їде у stdin з файлу):',
  ];
}

/** Windows: труба з файлу в stdin процесу. */
function winPipe(file) { return 'Get-Content -Raw -Encoding UTF8 ' + file + ' | '; }

/**
 * Хвіст, спільний для всіх видів відмови. Головне тут не мораль, а два факти:
 * заборонений СПОСІБ, а не кількість роботи; і робота, якої нема в реєстрі,
 * для людини не існує взагалі.
 */
function tail(port) {
  return [
    '',
    'Дозволу на це НЕ питати: агентів і фонової роботи можна вільно і паралельно,',
    'скільки треба. Обмежений тільки СПОСІБ запуску, а не кількість.',
    'Перевірка, що вийшло: GET http://127.0.0.1:' + port + '/api/jobs?all=1 і панель «Процеси».',
    'Немає там рядка = покликано неправильно, і людина цієї роботи не бачить.',
  ];
}

/** Гейт спеки на містку (S2). Без цього прапорця команда впаде ще до спавну. */
const SPEC = '--no-spec "<чому без спеки>"';
const SPEC_NOTE = 'Замість --no-spec можна --spec specs/<slug>/spec.md, але БЕЗ жодного з них'
                + ' місток нічого не спавнить (гейт S2).';

function buildReason(channel, label, env, tool, platform) {
  const ch = channel || '<id активного каналу>';
  const lb = label || 'Агент';
  const b = bridge(env, platform);
  const TASK_BODY = '<вся постановка: контекст, файли, контракт, критерій готовності, вимога доказу>';
  const how = b.win
    ? [
      'Спосіб запустити агента РІВНО ОДИН: detached-місток. Зроби це Bash-викликом',
      '(на Windows це PowerShell, тому ні heredoc, ні nvm-префікса тут нема):',
      '',
    ].concat(winStdin('work\\agent-task.md', TASK_BODY), [
      '',
      '  ' + winPipe('work\\agent-task.md') + 'node ' + b.cmd + ' --channel ' + ch
        + ' --label "' + lb + '" --model opus ' + SPEC + ' --task -',
      '',
      SPEC_NOTE,
      'Постановку передавай ЧЕРЕЗ STDIN (файл у трубу), НЕ через --task "...": довгий',
      'промпт в аргументі ламається на лапках і переносах, а кирилицю в argv псує',
      'кодова сторінка консолі. Якщо мітка в панелі приїхала кракозябрами: chcp 65001.',
      'Весь контекст клади у файл: detached-агент НЕ бачить цей діалог.',
      '',
    ])
    : [
      'Спосіб запустити агента РІВНО ОДИН: detached-місток. Зроби це Bash-викликом.',
      'node НЕ в PATH, тому префікс nvm обовʼязковий:',
      '',
      '  ' + NVM,
      '  node ' + b.cmd + ' --channel ' + ch + ' \\',
      '       --label "' + lb + '" --model opus ' + SPEC + ' --task - <<\'TASK\'',
      '  ' + TASK_BODY,
      '  TASK',
      '',
      SPEC_NOTE,
      'Задачу передавай ЧЕРЕЗ STDIN heredoc, НЕ через --task "...": довгий промпт',
      'в аргументі ламається на лапках, переносах і $.',
      'Весь контекст клади всередину TASK: detached-агент НЕ бачить цей діалог.',
      '',
    ];
  return [
    'СТОП. Харнесний ' + (tool || 'Agent/Task') + ' у цьому проєкті ВИМКНЕНО хуком.',
    '',
    'Харнес крутить субагента ВСЕРЕДИНІ поточного ходу (claude -p). Коли процес',
    'Claude Code завершується, агент помирає разом з ним: нуль коду, нуль комітів,',
    'нуль звіту. Так уже втрачено роботу тричі (chat-46, Publisher 2026-08-02,',
    'два Opus 2026-08-03).',
    '',
  ].concat(how, [
    'Відповідь одним рядком: "ok <agentId>" = живий, "err <причина>" = не стартував.',
    'Агента видно наживо в панелі «Процеси» і в GET http://127.0.0.1:' + b.port + '/api/agents.',
    'На done агент сам постить картку-звіт у канал-власник, тобі чекати не треба.',
    'Треба кілька агентів одразу: не повторюй цю команду N разів, візьми agent-batch.cjs.',
  ], tail(b.port)).join('\n');
}

/**
 * Workflow. Найгірший вид втрати роботи: помирає не один агент, а весь оркестрований
 * прогін, і саме тоді, коли його найважче повторити. Заміна мусить дати те, ЗАРАДИ
 * чого до Workflow тягнуться: пачку одним викликом і фази.
 */
function buildWorkflowReason(channel, label, env, tool, platform) {
  const ch = channel || '<id активного каналу>';
  const b = bridge(env, platform);
  const JSON_BODY = [
    '[',
    '  {"label":"Сергій: ринок","model":"opus","task":"<повна постановка 1>"},',
    '  {"label":"Ігор: цифри","model":"opus","task":"<повна постановка 2>"}',
    ']',
  ];
  const batch = b.win
    ? winStdin('work\\agent-batch.json', 'масив задач, по обʼєкту на агента:')
      .concat(JSON_BODY.map((l) => '          ' + l), [
        '',
        '  ' + winPipe('work\\agent-batch.json') + 'node ' + b.batch + ' --channel ' + ch
          + ' ' + SPEC + ' --tasks -',
      ])
    : [
      '  ' + NVM,
      '  node ' + b.batch + ' --channel ' + ch + ' ' + SPEC + ' --tasks - <<\'JSON\'',
    ].concat(JSON_BODY.map((l) => '  ' + l), ['  JSON']);
  const phase = b.win
    ? [
      '  node ' + b.watch + ' --channel ' + ch + ' --label "Фаза 2: перевірка джерел"'
        + ' --why "по завершенню фази 1 піднімає перевірку джерел"'
        + ' --waiting "кінець фази 1" --until-url "http://127.0.0.1:' + b.port
        + '/api/agents?channel=' + ch + '" --until-json "items[state=running]"'
        + ' --until-count "==0" --every 20 --timeout 3600 -- node ' + b.cmd
        + ' --channel ' + ch + ' --label "Фаза 2" ' + SPEC + ' --task "<постановка фази 2>"',
      '',
      'Умова тут ДЕКЛАРАТИВНА (--until-url/--until-json/--until-count), бо shell-виразу',
      'на Windows нема з чого зібрати: ні test, ні grep, ні wc.',
    ]
    : [
      '  node ' + b.watch + ' --channel ' + ch + ' --label "Фаза 2: перевірка джерел" \\',
      '       --why "по завершенню фази 1 піднімає перевірку джерел" \\',
      '       --waiting "кінець фази 1" --until \'<shell-умова, код 0 = дочекались>\' \\',
      '       --every 20 --timeout 3600 -- node ' + b.cmd + ' --channel ' + ch + ' \\',
      '       --label "Фаза 2" ' + SPEC + ' --task "<постановка фази 2>"',
    ];
  return [
    'СТОП. ' + (tool || 'Workflow') + ' у цьому проєкті ВИМКНЕНО хуком.',
    '',
    'Workflow крутить УСІХ своїх агентів усередині поточного ходу. Кінець ходу вбиває',
    'весь прогін одразу, а не одного агента: ні коду, ні звіту, ні сліду в реєстрі.',
    'Поки він іде, людина не бачить ні скільки агентів працює, ні на чому вони стоять,',
    'ні кнопки Стоп. Саме це і сталось 2026-08-11 з глибоким пошуком на 4 агенти.',
    '',
    'ПАЧКА АГЕНТІВ ОДНІЄЮ КОМАНДОЮ (те саме, що фан-аут у Workflow):',
    '',
  ].concat(batch, [
    '',
    'Кожен елемент піднімається СВОЇМ процесом і має свій рядок у «Процесах».',
    'Cap каналу лишається: зайві не гинуть, а стають у видиму чергу і заїжджають',
    'самі, щойно звільниться слот.',
    '',
    'ФАЗА ПІСЛЯ ФАЗИ (те саме, що послідовні стадії у Workflow) це вартовий:',
    '',
  ], phase, ['', SPEC_NOTE], tail(b.port)).join('\n');
}

/** ScheduleWakeup / Monitor. «Дочекатись і зробити» у нас зветься вартовим. */
function buildWatchReason(channel, label, env, tool, platform) {
  const ch = channel || '<id активного каналу>';
  const b = bridge(env, platform);
  // Умова очікування це єдине місце, де дві ОС розходяться не косметично: shell-вираз
  // з test/grep/wc на Windows не з чого зібрати, тому там друкуємо декларативну форму,
  // яку вартовий перевіряє сам (--until-url + --until-json + --until-count).
  const how = b.win
    ? [
      '  node ' + b.watch + ' --channel ' + ch + ' --label "Вартовий: <що чекаємо>"'
        + ' --why "<що станеться, коли дочекаємось>" --waiting "<чого чекаємо>"'
        + ' --until-url "http://127.0.0.1:' + b.port + '/api/agents?channel=' + ch + '"'
        + ' --until-json "items[state=running]" --until-count "<4"'
        + ' --every 20 --timeout 3600 --log work\\watch.log -- <команда-дія>',
      '',
      'Умова ДЕКЛАРАТИВНА: --until-url це локальний GET, --until-json вибирає значення',
      'з відповіді, --until-count порівнює їх кількість (<4, ==0, >=1). Shell-вираз',
      '--until на Windows не бери: ні test, ні grep, ні wc там не існує.',
      '',
    ]
    : [
      '  ' + NVM,
      '  node ' + b.watch + ' --channel ' + ch + ' --label "Вартовий: <що чекаємо>" \\',
      '       --why "<що станеться, коли дочекаємось>" --waiting "<чого чекаємо>" \\',
      '       --until \'<shell-умова, код виходу 0 = дочекались>\' \\',
      '       --every 20 --timeout 3600 --log work/watch.log -- <команда-дія>',
      '',
    ];
  return [
    'СТОП. ' + (tool || 'ScheduleWakeup/Monitor') + ' у цьому проєкті ВИМКНЕНО хуком.',
    '',
    'Очікування, прив\'язане до ходу, помирає разом з ходом, і по собі не лишає нічого:',
    'ні рядка, ні причини, ні сліду, що робота взагалі планувалась. Плюс людина не бачить',
    'ГОЛОВНОГО: чого саме чекають і скільки вже. Обидві дірки закриває вартовий.',
    '',
  ].concat(how, [
    'Друкує jobId. Вартовий живе у власній сесії: переживає новий меседж, Esc і',
    'рестарт Logopsis. У смужці над інпутом видно, ЧОГО він чекає і скільки вже,',
    'є кнопка Стоп, а кінець завжди чесний (done/failed/gone, ніколи вічний running).',
    'Дією може бути будь-що, у тому числі місток: -- node ' + b.cmd + ' ... ' + SPEC + ' --task "..."',
    '',
    'Треба просто зробити видимою довгу команду без очікування: node scripts/job.cjs.',
  ], tail(b.port)).join('\n');
}

/**
 * CronCreate. Тут чесна відмова, а не підміна: свого планувальника в репо НЕМА, і
 * вдавати, що є, гірше за відмову. Разове відкладення закриває вартовий, регулярний
 * розклад це рішення людини (її машина, її launchd), а не мій самозапуск.
 */
function buildCronReason(channel, label, env, tool, platform) {
  const ch = channel || '<id активного каналу>';
  const b = bridge(env, platform);
  // Сама умова тут уже портативна (node -e, а не shell-утиліти), ламався лише перенос
  // рядків: у PowerShell «\» в кінці рядка це не продовження, а обрізана команда.
  const delayed = b.win
    ? [
      '  node ' + b.watch + ' --channel ' + ch + ' --label "Відкладено: <що>"'
        + ' --waiting "<час> за годинником" --why "<що зробить>"'
        + ' --until \'node -e "process.exit(Date.now()>=<мітка-в-мс>?0:1)"\''
        + ' --every 60 --timeout 3600 -- <команда-дія>',
    ]
    : [
      '  node ' + b.watch + ' --channel ' + ch + ' --label "Відкладено: <що>" \\',
      '       --waiting "<час> за годинником" --why "<що зробить>" \\',
      '       --until \'node -e "process.exit(Date.now()>=<мітка-в-мс>?0:1)"\' \\',
      '       --every 60 --timeout 3600 -- <команда-дія>',
    ];
  return [
    'СТОП. ' + (tool || 'CronCreate') + ' у цьому проєкті ВИМКНЕНО хуком.',
    '',
    'Заміни один-в-один НЕМА: власного планувальника в репо не існує. Харнесний',
    'розклад для нас гірший за його відсутність: він живе поза реєстром, тому людина не',
    'бачить ні що заплановано, ні коли, ні як це спинити, а спрацювати воно може тоді,',
    'коли ніхто не дивиться. Тому не заводимо, а робимо одне з двох.',
    '',
    'РАЗОВА ВІДКЛАДЕНА ДІЯ: вартовий з умовою за часом (node-умова, бо крос-платформно).',
    '',
  ].concat(delayed, [
    '',
    'СПРАВДІ ПЕРІОДИЧНА ЗАДАЧА: це рішення людини, а не моє. Опиши одним рядком, що і як',
    'часто треба крутити, і спитай, чи заводимо (launchd на його машині або свій',
    'планувальник у реєстрі). Мовчки повз реєстр не заводимо нічого.',
  ], tail(b.port)).join('\n');
}

/** SendMessage. Слати нема куди: detached-агент не читає харнесних повідомлень. */
function buildTalkReason(channel, label, env, tool, platform) {
  const ch = channel || '<id активного каналу>';
  const b = bridge(env, platform);
  // curl на Windows є (curl.exe з Windows 10), але в PowerShell саме `curl` це псевдонім
  // на Invoke-WebRequest з іншим CLI. Тому там кличемо явно curl.exe і одним рядком.
  const look = b.win
    ? '  curl.exe -s "http://127.0.0.1:' + b.port + '/api/agents?channel=' + ch + '"'
    : '  curl -s "http://127.0.0.1:' + b.port + '/api/agents?channel=' + ch + '"';
  const restart = b.win
    ? [
      '  curl.exe -s -X POST http://127.0.0.1:' + b.port + '/api/agent-stop'
        + ' -H "Content-Type: application/json"'
        + ' -d \'{"channel":"' + ch + '","agentId":"<id>"}\'',
      '  node ' + b.cmd + ' --channel ' + ch + ' --label "<мітка>" ' + SPEC + ' --task -',
    ]
    : [
      '  curl -s -X POST http://127.0.0.1:' + b.port + '/api/agent-stop \\',
      '       -H "Content-Type: application/json" \\',
      '       -d \'{"channel":"' + ch + '","agentId":"<id>"}\'',
      '  node ' + b.cmd + ' --channel ' + ch + ' --label "<мітка>" ' + SPEC + ' --task -',
    ];
  return [
    'СТОП. ' + (tool || 'SendMessage') + ' у цьому проєкті ВИМКНЕНО хуком.',
    '',
    'Наші агенти detached: кожен живе у ВЛАСНІЙ сесії і харнесних повідомлень не читає',
    'взагалі, тому такий виклик у кращому разі йде в порожнечу, а в гіршому створює',
    'ілюзію, що домовленість передана. Спілкування з агентом іде через його КАНАЛ, і',
    'воно видиме людині, на відміну від приватного каналу харнесу.',
    '',
    'Подивитись, на чому агент стоїть (нічого не шлючи):',
    look,
    '',
    'Звіт приїде САМ карткою в канал-власник на done: чекати і смикати не треба.',
    '',
    'Постановка виявилась неправильною: агента спиняють і піднімають нового з',
    'виправленою задачею, бо на пів-дорозі його не перевчиш.',
  ].concat(restart, [
    '',
    'Сказати щось самій людині: звичайна відповідь у канал, а не інструмент.',
  ], tail(b.port)).join('\n');
}

const BUILDERS = {
  agent: buildReason,
  batch: buildWorkflowReason,
  watch: buildWatchReason,
  cron: buildCronReason,
  talk: buildTalkReason,
};

/**
 * Диспетчер: ім'я інструмента -> готовий текст відмови. Без евристик, по таблиці.
 * platform необовʼязковий: рантайм його не передає (беремо process.platform), тест
 * передає, щоб довести обидві ОС на одній машині.
 */
function reasonFor(tool, channel, label, env, platform) {
  const build = BUILDERS[SPAWN_TOOLS[tool]] || buildReason;
  return build(channel, label, env, tool, platform);
}

// ── ядро: рішення ───────────────────────────────────────────────────────────

const skip = (why) => ({ decision: 'skip', why, reason: '' });
const deny = (why, reason) => ({ decision: 'deny', why, reason });

/**
 * Чиста функція рішення. Жодного I/O: усе з диска приходить аргументами.
 *
 * @param {object} o
 * @param {string} o.toolName    tool_name зі stdin
 * @param {object} o.toolInput   tool_input зі stdin
 * @param {object} o.env         оточення (process.env або підробка в тестах)
 * @param {boolean} [o.gatesOff] чи існує .claude/gates-off
 * @returns {{decision:'deny'|'skip', why:string, reason:string}}
 */
function evaluate(o) {
  const opts = o || {};
  const env = opts.env || {};
  const ti = (opts.toolInput && typeof opts.toolInput === 'object') ? opts.toolInput : {};

  // Ескейп для людини. Найперше і без жодної роботи.
  if (opts.gatesOff) return skip('file-off');

  // Єдина перевірка. Не наш інструмент = не наша справа.
  if (!Object.prototype.hasOwnProperty.call(SPAWN_TOOLS, opts.toolName)) {
    return skip('tool-out-of-scope');
  }

  // Мітка для панелі: беремо те, що дав виклик, у порядку від найлюдянішого.
  const label = String(ti.description || ti.label || ti.subagent_type || ti.name || '').trim();
  return deny('harness-agent-disabled',
              reasonFor(opts.toolName, String(env.LOGOPSIS_CHANNEL || ''), label, env));
}

// ── main ────────────────────────────────────────────────────────────────────

function main() {
  let input = {};
  try { input = JSON.parse(fs.readFileSync(0, 'utf8')); } catch { input = {}; }
  if (!input || typeof input !== 'object') input = {};

  const toolName = input.tool_name;
  const toolInput = (input.tool_input && typeof input.tool_input === 'object')
    ? input.tool_input : {};

  let gatesOff = false;
  try { gatesOff = fs.existsSync(path.join(repoRoot(), '.claude', 'gates-off')); } catch { /* fail-open */ }

  const res = evaluate({ toolName, toolInput, env: process.env, gatesOff });

  record({
    decision: res.decision,
    why: res.why,
    tool: String(toolName || ''),
    agent: String(toolInput.subagent_type || ''),
    chars: String(toolInput.prompt || '').length,
    session_id: String(input.session_id || ''),
  });

  if (res.decision === 'deny') {
    process.stdout.write(JSON.stringify({
      hookSpecificOutput: {
        hookEventName: 'PreToolUse',
        permissionDecision: 'deny',
        permissionDecisionReason: res.reason,
      },
    }));
  }
  return 0;
}

module.exports = { evaluate, buildReason, reasonFor, main, SPAWN_TOOLS, DENIED_TOOLS };

// Запускаємось як хук тільки коли нас викликали напряму: з тестів файл require-иться.
if (require.main === module) {
  let code = 0;
  try { code = main(); } catch { code = 0; }   // FAIL-OPEN, завжди
  process.exit(code);
}
