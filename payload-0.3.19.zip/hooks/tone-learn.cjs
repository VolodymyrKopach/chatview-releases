#!/usr/bin/env node
/**
 * Stop hook — TONE + CHIPS self-learning.
 *
 * Сусід REFLECT-петлі (learn-capture.cjs), не заміна їй. Той хук ловить ПРАВИЛА
 * («я ж казав», «запамʼятай») і робить з них памʼять. Цей ловить ГОЛОС: як саме
 * людина будує фразу, якими словами лається, чим погоджується і чим заперечує, і
 * які формулювання чіпів він реально тисне, а які ігнорує.
 *
 * Два профілі, обидва це ДАНІ (числа плюс дослівні цитати), не проза:
 *   work/profile-tone.json   — як він говорить
 *   work/profile-chips.json  — його слова для швидких кнопок
 * runner.py читає їх і вставляє компактну секцію в системний промпт.
 *
 * СИГНАЛ ПО ЧІПАХ. Клік по чіпу фронт шле як звичайне повідомлення користувача,
 * тобто натиснутий чіп НЕВІДРІЗНИМИЙ від набраного тексту. Єдиний спосіб його
 * побачити це звірка з чіпами попереднього меседжа асистента: точний збіг з
 * `prompt` чіпа = натиснуто, будь-що інше = чіпи проігноровано, а написане
 * руками стає кандидатом у майбутні формулювання. Фронт для цього чіпати не
 * треба, сигнал уже лежить в історії каналу.
 *
 * Інкрементальність. Профіль тримає курсор на кожен канал (скільки записів
 * index.json уже враховано), тому звичайний хід обробляє 1-2 нових повідомлення.
 * Перша зустріч з каналом добирає хвіст історії (BACKFILL), не весь архів.
 *
 * Як кожен хук тут: НІКОЛИ не кидає, завжди exit 0, мовчить. Зламаний хук не сміє
 * блокувати хід, тому все у try/catch, читання з лімітом розміру, запис атомарний.
 */
const fs = require('fs');
const path = require('path');
// Другий зріз навчання (spec chips-rebuild, К5). Дослівний зріз лишається як був: він
// працює для мертвих РЯДКІВ. Категорія додається поруч, бо промахи живуть на ній.
const chipIntent = require('./chip-intent.cjs');

// Дзеркалення імен змінних середовища (CHATVIEW_* <-> LOGOPSIS_*) під час ребренду.
// Мусить стояти вище за перше читання process.env у цьому файлі: у власника
// лишились запущені служби і аліаси зі старими іменами. Контракт: brand-env.cjs.
require("../brand-env.cjs")

// ---- де що лежить ----------------------------------------------------------
const CHAT_DIR = path.resolve(__dirname, '..');
const REPO_ROOT = path.resolve(CHAT_DIR, '..', '..', '..');
// LOGOPSIS_TONE_DIR існує рівно заради тестів та ізольованих домів: профіль це
// глобальний артефакт репозиторію, а не каналу, тому за замовчуванням work/.
const WORK_DIR = process.env.LOGOPSIS_TONE_DIR || path.join(REPO_ROOT, 'work');
const TONE_PATH = path.join(WORK_DIR, 'profile-tone.json');
const CHIPS_PATH = path.join(WORK_DIR, 'profile-chips.json');

// ---- ліміти (хук мусить коштувати десятки мілісекунд) ----------------------
const BACKFILL = 800;              // скільки записів індексу брати на першій зустрічі
const MAX_INDEX_BYTES = 8 * 1024 * 1024;
const MAX_MSG_BYTES = 256 * 1024;
const MAX_MSG_CHARS = 4000;        // довші повідомлення ріжемо: це вставлений лог, не мова
const KEEP_WORDS = 300;            // скільки ключів лишати у частотних мапах після обрізки
const KEEP_PHRASES = 150;
const KEEP_QUOTES = 60;
const IGNORE_STREAK_BLACKLIST = 3; // симетрично до детектора помічників
// Скільки разів категорію треба показати, перш ніж називати її живою чи мертвою.
// Один ігнор це не вирок темі: на малій вибірці профіль накаже не пропонувати те,
// що просто ще не встигли показати.
const MIN_INTENT_SAMPLE = 8;

const USER_FROM = 'Я';             // так підписані повідомлення людини в index.json
const ASSISTANT_FROM = 'Claude';   // картки detached-агентів мають свій from і сюди не лізуть

// ---- лексика ---------------------------------------------------------------
// Матюки. Матчимо ПРЕФІКСОМ цілого слова, а не includes: 'сука' префіксом не чіпляє
// «сукупність», тоді як includes чіпляв би. Список свідомо вузький і суто обсценний:
// «дебіл» чи «ідіот» це образа, а не підсилення, і в лічильнику тону їм не місце.
const PROFANITY = [
  'бля', 'блят', 'блядь', 'блін',
  'хуй', 'хуя', 'хує', 'хуе', 'хуї', 'хуйн', 'хуев', 'хуёв', 'хуйов', 'нахуй', 'нахер',
  'похуй', 'пофіг', 'хрін', 'хер',
  'пизд', 'пізд', 'піздец', 'пиздец',
  'єб', 'їб', 'еб', 'заєб', 'заеб', 'заїб', 'наєб', 'наїб', 'виїб', 'єбан', 'ебан', 'їбан',
  'сука', 'суки', 'суці', 'сучар',
  'гандон', 'мудак', 'мудил', 'довбо',
  'fuck', 'shit', 'damn',
];

// Службові слова української/російської. Потрібні, щоб «топ-15 характерних слів»
// не виродився в «і, не, що, в, я» (це топ будь-якого тексту будь-якої людини).
const STOPWORDS = new Set(`
і й та а але або чи що щоб як коли де куди бо тому якщо хоч хоча же ж то це цей ця ці цього цьому
я ти він вона воно ми ви вони мене тебе його її нас вас їх мені тобі йому їй нам вам їм мій твій
свій себе собі сам сама самі наш ваш який яка яке які котрий
в у на з із зі до від для про за над під при по без через між серед біля після перед крім
не ні ані нема немає є був була було були буде будуть бути
щось хтось якийсь якісь такий така таке такі так теж також ще вже тільки лише навіть саме
можна треба має мають маємо мати може можу можеш можемо можуть
дуже більш менш весь вся все всі усе усі кожен інший інша інше інші
там тут туди сюди тоді потім зараз завжди ніколи знову
один два три раз рази
и в на с не что это как для по то же бы или их его она они мы вы
the a an is are was were be to of in on for and or it that this with as at from
`.trim().split(/\s+/));

// ---- дрібні утиліти --------------------------------------------------------
function readJson(p, maxBytes) {
  try {
    const st = fs.statSync(p);
    if (maxBytes && st.size > maxBytes) return null;
    return JSON.parse(fs.readFileSync(p, 'utf8'));
  } catch { return null; }
}

// tmp + rename: половина записаного профілю гірша за відсутній профіль, бо
// runner.py прочитає її мовчки і вставить у промпт огризок.
function writeJsonAtomic(p, obj) {
  try {
    fs.mkdirSync(path.dirname(p), { recursive: true });
    const tmp = p + '.tmp';
    fs.writeFileSync(tmp, JSON.stringify(obj, null, 2));
    fs.renameSync(tmp, p);
    return true;
  } catch { return false; }
}

const bump = (map, key, by = 1) => { if (key) map[key] = (map[key] || 0) + by; };

// Обрізка частотної мапи до топ-N. Лічильники кумулятивні, тому хвіст втрачається
// назавжди, і це свідомо: профіль має лишатись компактним вічно.
function prune(map, keep) {
  const keys = Object.keys(map);
  if (keys.length <= keep) return map;
  const out = {};
  for (const [k, v] of keys.map(k => [k, map[k]]).sort((a, b) => b[1] - a[1]).slice(0, keep)) out[k] = v;
  return out;
}

const topList = (map, n) => Object.entries(map || {})
  .sort((a, b) => b[1] - a[1] || a[0].localeCompare(b[0]))
  .slice(0, n)
  .map(([w, count]) => ({ w, n: count }));

const words = (s) => s.toLowerCase().match(/[\p{L}\p{N}][\p{L}\p{N}'’ʼ-]*/gu) || [];

// Профіль зберігає ДОСЛІВНІ цитати, а людина регулярно вставляє в чат що завгодно.
// Один ключ, який він колись кинув у повідомленні, інакше осів би у профілі назавжди
// І ЩОХОДУ ЇХАВ БИ В СИСТЕМНИЙ ПРОМПТ. Цитата з підозрою на секрет просто не береться:
// втратити один зразок голосу дешевше, ніж возити ключ у кожному запиті.
const SECRETISH = /sk-|ghp_|github_pat|xai-|AIza|Bearer\s|api[_-]?key|secret|passwo?rd|token\s*[=:]|[A-Za-z0-9_-]{32,}/i;
const looksSecret = (s) => SECRETISH.test(String(s || ''));
const isProfane = (w) => PROFANITY.some(r => w.startsWith(r));
// Ключ для звірки чіпа з набраним текстом. Регістр, пунктуація в кінці і подвійні
// пробіли не мають робити з натиснутого чіпа «написане руками».
const norm = (s) => String(s || '').toLowerCase().replace(/\s+/g, ' ').replace(/[.!?…,;:]+$/, '').trim();

// ---- порожні профілі -------------------------------------------------------
function emptyTone() {
  return {
    v: 1, updated: null, cursors: {},
    totals: { messages: 0, words: 0, sentences: 0, profanity: 0, lowercase: 0, questions: 0, exclam: 0 },
    freq: { words: {}, bigrams: {}, openers: {}, profanity: {}, agree: {}, refuse: {}, quotes: {} },
  };
}
function emptyChips() {
  return {
    v: 1, updated: null, cursors: {}, pending: {},
    totals: { offered: 0, clicked: 0, ignored: 0 },
    clicked: {}, ignored: {}, typed: {}, streak: {}, blacklist: [],
    intents: chipIntent.emptyCounts(),
  };
}

// Профіль, що вже лежить на машині, писався ДО появи другого зрізу. Добудовуємо поле
// на місці замість того, щоб визнати такий файл зіпсованим: інакше перша ж правка
// стерла б накопичену історію дослівних формулювань.
function ensureIntents(chips) {
  const base = chipIntent.emptyCounts();
  const have = chips.intents && typeof chips.intents === 'object' ? chips.intents : {};
  for (const id of Object.keys(base)) {
    const row = have[id];
    if (row && typeof row === 'object') {
      for (const k of ['offered', 'clicked', 'ignored', 'typed']) {
        const v = Number(row[k]);
        if (Number.isFinite(v) && v > 0) base[id][k] = v;
      }
    }
  }
  chips.intents = base;
  return chips;
}

// ---- читання історії каналу ------------------------------------------------
function channelIndex(channelsDir, channel) {
  const idx = readJson(path.join(channelsDir, channel, 'index.json'), MAX_INDEX_BYTES);
  return Array.isArray(idx) ? idx : null;
}

function widgetsOf(channelsDir, channel, file) {
  if (!file || /[\\/]|\.\./.test(file)) return [];
  const w = readJson(path.join(channelsDir, channel, file), MAX_MSG_BYTES);
  if (Array.isArray(w)) return w;
  return w && typeof w === 'object' ? [w] : [];
}

// Текст користувача це ТІЛЬКИ віджети text. `reply` це цитата моєї ж відповіді,
// а `attachments` це файли: обидва не його мова і зіпсували б статистику.
function userTexts(widgets) {
  return widgets
    .filter(x => x && x.type === 'text' && typeof x.text === 'string')
    .map(x => x.text.slice(0, MAX_MSG_CHARS))
    .filter(Boolean);
}

function chipsOf(widgets) {
  const out = [];
  for (const w of widgets) {
    if (!w || w.type !== 'suggestions' || !Array.isArray(w.chips)) continue;
    for (const c of w.chips) {
      const prompt = c && (c.prompt || c.label);
      if (typeof prompt === 'string' && prompt.trim()) {
        out.push({ label: String(c.label || prompt).slice(0, 120), prompt: prompt.slice(0, 300) });
      }
    }
  }
  return out;
}

// ---- ТОН: розбір одного повідомлення --------------------------------------
const AGREE_RE = /^(ок|окей|добре|супер|топ|го|давай|дяк|дякую|збс|норм|класно|чудово|ідеально|прекрасно|ага|угу|так|\+|yes|ok|nice)(?=$|[\s,.!?…])/iu;
const REFUSE_RE = /^(ні|нє|не|стоп|стій|погано|фігня|херня|нахуй|хватить|досить|нема|немає|нєа|no|stop)(?=$|[\s,.!?…])/iu;

function learnTone(tone, texts) {
  for (const raw of texts) {
    const text = raw.replace(/\s+/g, ' ').trim();
    if (!text) continue;
    const ws = words(text);
    if (!ws.length) continue;

    tone.totals.messages += 1;
    tone.totals.words += ws.length;
    // Людина майже не ставить крапок, тому речення це шматок між термінаторами АБО
    // ціле повідомлення. Без цього середня довжина речення = довжині повідомлення.
    const sentences = raw.split(/[.!?…]+|\n+/).map(s => s.trim()).filter(Boolean);
    tone.totals.sentences += Math.max(1, sentences.length);
    // Саме ПЕРША літера, а не «все повідомлення з малої»: у нього повно Logopsis,
    // V2, SDK, тому «все з малої» давало 0.19 і брехало про звичку не капіталізувати.
    const first = text.match(/\p{L}/u);
    if (first && first[0] === first[0].toLowerCase()) tone.totals.lowercase += 1;
    if (/\?/.test(text)) tone.totals.questions += 1;
    if (/!/.test(text)) tone.totals.exclam += 1;

    // Повідомлення з підозрою на секрет дає ЧИСЛА і нічого більше: ані слова, ані
    // біграми, ані цитати. Токенізатор інакше зберіг би сам ключ окремим «словом».
    const safe = !looksSecret(text);

    for (const w of ws) {
      if (isProfane(w)) { tone.totals.profanity += 1; bump(tone.freq.profanity, w); }
      if (safe && w.length >= 2 && !STOPWORDS.has(w) && !/^\d+$/.test(w)) bump(tone.freq.words, w);
    }
    if (!safe) continue;
    // Звороти: біграми, де хоча б одне слово не службове. «таким чином», «давай далі».
    for (let i = 0; i + 1 < ws.length; i++) {
      if (STOPWORDS.has(ws[i]) && STOPWORDS.has(ws[i + 1])) continue;
      if (ws[i].length < 2 || ws[i + 1].length < 2) continue;
      bump(tone.freq.bigrams, ws[i] + ' ' + ws[i + 1]);
    }
    // Як звертається: перші два слова повідомлення.
    bump(tone.freq.openers, ws.slice(0, 2).join(' '));

    // Згода і відмова це ФОРМУЛА, а не ціле повідомлення. Ключем беремо перші три
    // слова: «го далі», «не працює», «ні, юзаєм». Ціле повідомлення тут дало б
    // список унікальних рядків по одному разу кожен, тобто нуль сигналу про звичку.
    const formula = ws.slice(0, 2).join(' ');
    // Цитати тримаємо КОРОТКІ, і без «[скрін ...]»: то підпис вкладення, не його мова.
    const short = text.length <= 90 && !text.startsWith('[') ? text : null;
    if (AGREE_RE.test(text)) bump(tone.freq.agree, formula);
    else if (REFUSE_RE.test(text)) bump(tone.freq.refuse, formula);
    else if (short && ws.length >= 2) bump(tone.freq.quotes, short);
  }
}

// ---- ЧІПИ: розбір одного повідомлення користувача --------------------------
function learnChips(chips, channel, texts) {
  const pending = Array.isArray(chips.pending[channel]) ? chips.pending[channel] : [];
  if (!pending.length) return;
  chips.pending[channel] = [];

  const typed = norm(texts.join(' '));
  if (!typed) return;

  const hit = pending.find(c => norm(c.prompt) === typed);
  const intents = ensureIntents(chips).intents;
  for (const c of pending) {
    const key = c.prompt;
    // Категорія рахується на КОЖЕН показаний чіп, а не лише на натиснутий: без
    // знаменника «скільки разів пропонували» відсоток влучності по темі неможливий.
    const cat = intents[chipIntent.classify(key)];
    cat.offered += 1;
    if (hit && c.prompt === hit.prompt) {
      bump(chips.clicked, key);
      chips.totals.clicked += 1;
      chips.streak[key] = 0;                                   // серія обірвана
      chips.blacklist = chips.blacklist.filter(p => p !== key); // натиснув, отже живий
      cat.clicked += 1;
    } else {
      bump(chips.ignored, key);
      chips.totals.ignored += 1;
      chips.streak[key] = (chips.streak[key] || 0) + 1;
      cat.ignored += 1;
      if (chips.streak[key] >= IGNORE_STREAK_BLACKLIST && !chips.blacklist.includes(key)) {
        chips.blacklist.push(key);
      }
    }
  }
  // Написав руками замість чіпа: саме це формулювання і треба пропонувати далі.
  // Довгі постановки задач відсіюємо, чіп це коротка команда, а не ТЗ.
  const candidate = texts.join(' ').replace(/\s+/g, ' ').trim().slice(0, 90);
  if (!hit && typed.length <= 90 && !looksSecret(candidate)) bump(chips.typed, candidate);
  // К6: набране руками це не лише рядок, а НАМІР. Довгі ТЗ сюди не йдуть з тієї ж
  // причини, що і в дослівний зріз: це постановка задачі, а не кандидат у кнопку.
  if (!hit && typed.length <= 90) intents[chipIntent.classify(candidate)].typed += 1;
}

// ---- один прохід по каналу -------------------------------------------------
function scanChannel(channelsDir, channel, tone, chips, opts = {}) {
  const idx = channelIndex(channelsDir, channel);
  if (!idx) return { scanned: 0 };

  const backfill = opts.backfill == null ? BACKFILL : opts.backfill;
  let cursor = Number(tone.cursors[channel]);
  if (!Number.isFinite(cursor) || cursor < 0 || cursor > idx.length) {
    // Немає курсора або історію підрізали: беремо хвіст, не весь архів.
    cursor = Math.max(0, idx.length - backfill);
  }
  if (cursor >= idx.length) return { scanned: 0 };

  for (let i = cursor; i < idx.length; i++) {
    const m = idx[i];
    if (!m || typeof m !== 'object') continue;
    const from = String(m.from || '');
    if (from === USER_FROM) {
      const texts = userTexts(widgetsOf(channelsDir, channel, m.file));
      if (texts.length) { learnTone(tone, texts); learnChips(chips, channel, texts); }
    } else if (from === ASSISTANT_FROM) {
      // Тільки справжня відповідь асистента переставляє «останні запропоновані
      // чіпи». Картки detached-агентів мають власний from і сюди не потрапляють,
      // інакше вони б скидали чіпи, яких людина ще навіть не бачила.
      const offered = chipsOf(widgetsOf(channelsDir, channel, m.file));
      chips.pending[channel] = offered;
      if (offered.length) chips.totals.offered += offered.length;
    }
  }

  tone.cursors[channel] = idx.length;
  chips.cursors[channel] = idx.length;
  return { scanned: idx.length - cursor };
}

// ---- витяжка по категоріях: що живе, що мертве ----------------------------
// Поріг відносний, а не константа. «Мертва» означає ВДВІЧІ гірша за середню влучність
// самої людини, а не гірша за якесь абстрактне число: середня повзе з місяцями, і
// прибитий поріг з часом почав би оголошувати мертвим усе підряд. Категорія, показана
// менше MIN_INTENT_SAMPLE разів, не оголошується ні живою, ні мертвою: на такій
// вибірці різниця між 0 і 1 натисканням це шум, а не сигнал.
function intentTop(chips) {
  const rows = [];
  let offered = 0, clicked = 0;
  for (const [id, c] of Object.entries((chips && chips.intents) || {})) {
    const o = Number(c && c.offered) || 0;
    const k = Number(c && c.clicked) || 0;
    offered += o; clicked += k;
    if (o > 0) rows.push({ id, label: chipIntent.labelOf(id), offered: o, clicked: k, typed: Number(c.typed) || 0 });
  }
  const avg = offered ? (clicked / offered) * 100 : 0;
  const deadBelow = Math.max(avg / 2, 1);
  for (const r of rows) r.rate = Math.round((r.clicked / r.offered) * 100);
  const sized = rows.filter(r => r.offered >= MIN_INTENT_SAMPLE);
  const bySize = (a, b) => b.rate - a.rate || b.offered - a.offered;
  return {
    live: sized.filter(r => r.rate >= deadBelow).sort(bySize),
    dead: sized.filter(r => r.rate < deadBelow).sort((a, b) => b.offered - a.offered),
    // Що він набирає РУКАМИ: категорії, куди він іде замість наших чіпів.
    typed: rows.filter(r => r.typed > 0).sort((a, b) => b.typed - a.typed)
      .map(r => ({ id: r.id, label: r.label, typed: r.typed })).slice(0, 4),
  };
}

// ---- фініш: обрізка + похідні числа ---------------------------------------
function finalize(tone, chips) {
  tone.freq.words = prune(tone.freq.words, KEEP_WORDS);
  tone.freq.bigrams = prune(tone.freq.bigrams, KEEP_PHRASES);
  tone.freq.openers = prune(tone.freq.openers, KEEP_PHRASES);
  tone.freq.profanity = prune(tone.freq.profanity, 40);
  tone.freq.agree = prune(tone.freq.agree, KEEP_QUOTES);
  tone.freq.refuse = prune(tone.freq.refuse, KEEP_QUOTES);
  tone.freq.quotes = prune(tone.freq.quotes, KEEP_QUOTES);

  const t = tone.totals;
  const r = (x, d = 1) => Number.isFinite(x) ? Number(x.toFixed(d)) : 0;
  tone.stats = {
    messages: t.messages,
    avgSentenceWords: t.sentences ? r(t.words / t.sentences) : 0,
    avgMessageWords: t.messages ? r(t.words / t.messages) : 0,
    profanityPer100Words: t.words ? r((t.profanity / t.words) * 100, 2) : 0,
    lowercaseShare: t.messages ? r(t.lowercase / t.messages, 2) : 0,
    questionShare: t.messages ? r(t.questions / t.messages, 2) : 0,
    exclamShare: t.messages ? r(t.exclam / t.messages, 2) : 0,
  };
  // Витяжка, яку читає runner.py. Дані плюс дослівні цитати, жодної прози.
  tone.top = {
    words: topList(tone.freq.words, 15),
    phrases: topList(tone.freq.bigrams, 10),
    openers: topList(tone.freq.openers, 10),
    profanity: topList(tone.freq.profanity, 8),
    agree: topList(tone.freq.agree, 8),
    refuse: topList(tone.freq.refuse, 8),
    quotes: topList(tone.freq.quotes, 8),
  };

  chips.clicked = prune(chips.clicked, KEEP_QUOTES);
  chips.ignored = prune(chips.ignored, KEEP_QUOTES);
  chips.typed = prune(chips.typed, KEEP_QUOTES);
  chips.streak = prune(chips.streak, KEEP_QUOTES * 2);
  chips.blacklist = chips.blacklist.slice(-KEEP_QUOTES);
  // У промпт іде тільки те, що годиться ПІДПИСОМ чіпа. Довгі постановки задач він
  // теж тисне, але вчити модель писати на кнопці абзац це протилежне до цілі, тому
  // у витяжку беремо коротке. Прибираємо ще плейсхолдери скрінів на кшталт «[скрін ...]».
  const usable = (m) => {
    const out = {};
    for (const [k, v] of Object.entries(m || {})) {
      const s = k.trim();
      if (s.length < 2 || s.length > 70) continue;
      if (s.startsWith('[')) continue;
      out[k] = v;
    }
    return out;
  };
  chips.top = {
    clicked: topList(usable(chips.clicked), 8),
    typed: topList(usable(chips.typed), 8),
    ignored: topList(chips.ignored, 8),
    blacklist: chips.blacklist.slice(-6),
    intents: intentTop(chips),
  };

  const now = new Date().toISOString();
  tone.updated = now;
  chips.updated = now;
}

// ---- публічний прогін ------------------------------------------------------
function learn({ channelsDir, channels, tonePath = TONE_PATH, chipsPath = CHIPS_PATH, backfill }) {
  const tone = readJson(tonePath) || emptyTone();
  const chips = readJson(chipsPath) || emptyChips();
  // Профіль старої версії або зіпсований вручну: починаємо з чистого, а не падаємо.
  const tp = tone && tone.v === 1 && tone.totals && tone.freq ? tone : emptyTone();
  const cp = ensureIntents(chips && chips.v === 1 && chips.totals && chips.pending ? chips : emptyChips());

  let scanned = 0;
  for (const ch of channels) {
    if (!ch || /[\\/]|\.\./.test(ch)) continue;
    try { scanned += scanChannel(channelsDir, ch, tp, cp, { backfill }).scanned; } catch {}
  }
  finalize(tp, cp);
  writeJsonAtomic(tonePath, tp);
  writeJsonAtomic(chipsPath, cp);
  return { scanned, tone: tp, chips: cp };
}

// ---- запуск як хук ---------------------------------------------------------
function main() {
  let input = {};
  try { input = JSON.parse(fs.readFileSync(0, 'utf8')); } catch {}
  const sessionId = input && input.session_id ? String(input.session_id) : '';

  let channel = null;
  try { channel = require('./_emit.cjs').channelFor(sessionId); } catch {}
  if (!channel) return;

  let channelsDir = path.join(CHAT_DIR, 'channels');
  try { channelsDir = require('./plan-state.cjs').CHANNELS_DIR || channelsDir; } catch {}

  const t0 = Date.now();
  const res = learn({ channelsDir, channels: [channel] });

  try {
    require('./_emit.cjs').emit(channel, {
      kind: 'hook', name: 'ToneLearn', phase: 'fire',
      detail: res.scanned ? `${res.scanned} нов. у профілі тону (${Date.now() - t0} мс)` : 'без змін',
    });
  } catch {}
}

if (require.main === module) {
  try { main(); } catch {}
  process.exit(0);
}

module.exports = {
  learn, scanChannel, learnTone, learnChips, finalize,
  emptyTone, emptyChips, chipsOf, userTexts, norm, isProfane, topList,
  ensureIntents, intentTop, classifyIntent: chipIntent.classify,
  TONE_PATH, CHIPS_PATH, IGNORE_STREAK_BLACKLIST, MIN_INTENT_SAMPLE,
};
