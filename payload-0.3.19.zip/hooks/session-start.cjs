#!/usr/bin/env node
// SessionStart hook (cross-platform: Mac + Windows).
// Goal: every NEW native Claude Code session gets its own fresh Chat View channel,
// so parallel terminals never write into each other's tab. Old channels are left
// untouched (the user archives them manually).
//
// Mechanism:
//   - stdin JSON = { session_id, source, cwd, transcript_path }.
//   - Mapping channels/.cc-sessions.json: { "<session_id>": "<channelId>" }.
//   - resume / compact of an already-mapped session => reuse, do nothing.
//   - otherwise RESERVE a unique channel id into .cc-sessions.json only. We do NOT
//     mkdir the dir, do NOT register it in index.local.json, do NOT write owner-session.
//     The channel materializes LAZILY when real content is first written
//     (render-message.cjs / set-plan.cjs register it then). This stops empty
//     "Code HH:MM" tabs from spawning for every session / subagent that never
//     produces a card.
//
// Registered from .claude/settings.json with a portable ${CLAUDE_PROJECT_DIR} path.
// MUST never throw / never exit non-zero (would interfere with session start).

const fs = require('fs');
const path = require('path');

// Дзеркалення імен змінних середовища (CHATVIEW_* <-> LOGOPSIS_*) під час ребренду.
// Мусить стояти вище за перше читання process.env у цьому файлі: у власника
// лишились запущені служби і аліаси зі старими іменами. Контракт: brand-env.cjs.
require("../brand-env.cjs")

try {
  // The runner spawns headless `claude -p` turns to SERVE an existing channel.
  // Those are NOT new interactive tabs — if we reserve a channel for them, every
  // rotated/forked session id mints a phantom cc-* tab and the reply lands there
  // ("writing in one chat spawns a new chat"). The runner marks them via env.
  if (process.env.LOGOPSIS_RUNNER) process.exit(0);

  const CHAT_DIR = path.resolve(__dirname, '..');         // tools/viz/chat
  const CHANNELS_DIR = path.join(CHAT_DIR, 'channels');
  // Committed, curated registry of the user's real tabs. Read-only here.
  const REG_PATH = path.join(CHANNELS_DIR, 'index.json');
  // Machine-local overlay (gitignored): auto cc-* session channels live HERE so
  // they never pollute the shared repo or cause cross-machine merge conflicts.
  const LOCAL_REG_PATH = path.join(CHANNELS_DIR, 'index.local.json');
  const MAP_PATH = path.join(CHANNELS_DIR, '.cc-sessions.json');

  let input = {};
  try { input = JSON.parse(fs.readFileSync(0, 'utf8')); } catch {}

  const sessionId = input && input.session_id ? String(input.session_id) : '';
  const source = input && input.source ? String(input.source) : '';
  if (!sessionId) process.exit(0);

  // Load mapping.
  let map = {};
  try { map = JSON.parse(fs.readFileSync(MAP_PATH, 'utf8')) || {}; } catch {}

  // resume / compact of a session we already bound => reuse, nothing to do.
  if ((source === 'resume' || source === 'compact') && map[sessionId]) {
    process.exit(0);
  }
  // A compaction CONTINUES an existing conversation under a fresh session id; it
  // is never a brand-new tab. Even if this post-compact id is unknown, do NOT
  // mint a new channel — the UserPromptSubmit binding falls back to the
  // most-recently-active tab (the one the user is in). This stops mid-conversation
  // compaction from spawning a phantom tab.
  if (source === 'compact') process.exit(0);
  // Even for a plain "startup" of an already-known session, do not double-create.
  if (map[sessionId]) process.exit(0);

  // Load committed registry + local overlay (read-only here: nothing is appended
  // at session start any more — registration is lazy, done on first content write).
  let reg = [];
  try { reg = JSON.parse(fs.readFileSync(REG_PATH, 'utf8')) || []; } catch {}
  let localReg = [];
  try { localReg = JSON.parse(fs.readFileSync(LOCAL_REG_PATH, 'utf8')) || []; } catch {}
  if (!Array.isArray(localReg)) localReg = [];

  // Build a unique channel id: cc- + first 6 sanitized chars of session_id.
  // Uniqueness is checked against the committed reg, the local overlay, any
  // existing dir AND already-reserved mapping VALUES — so two not-yet-materialized
  // reservations (e.g. parallel sessions with colliding slugs) cannot collide.
  const slug = sessionId.toLowerCase().replace(/[^a-z0-9]/g, '').slice(0, 6) || 'sess';
  const reservedIds = new Set(Object.values(map).filter(Boolean));
  let cid = 'cc-' + slug;
  let n = 2;
  const exists = (id) =>
    reg.some(c => c && c.id === id) ||
    localReg.some(c => c && c.id === id) ||
    reservedIds.has(id) ||
    fs.existsSync(path.join(CHANNELS_DIR, id));
  while (exists(cid)) { cid = 'cc-' + slug + '-' + n; n += 1; }

  // RESERVE ONLY: record the session -> channel mapping. No mkdir, no overlay
  // registration, no owner-session/session-id files. The channel is created and
  // registered lazily by render-message.cjs / set-plan.cjs on the first real write.
  map[sessionId] = cid;
  try { fs.writeFileSync(MAP_PATH, JSON.stringify(map, null, 2)); } catch {}
} catch {
  // never throw
}

process.exit(0);
