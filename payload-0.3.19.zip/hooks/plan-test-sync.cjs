#!/usr/bin/env node
/**
 * plan-test-sync.cjs — Stop hook (specs/plan-autosync-signals/spec.md, підзадача B4).
 *
 * Друга ітерація автосинхрону плану: крок закривається сам не лише коли модель про
 * нього згадала, а й фактом зеленого прогону тестів. Крок, що явно оголосив
 * `"closeOn": {"type": "tests", "match": "..."}` (B1, plan_autopatch.py — не
 * чіпається), закривається в `done` щойно в цьому ході знайдено прогін тест-раннера,
 * чия команда містить цю ознаку і чий вивід чистий; той самий крок переходить у
 * `blocked` з короткою причиною, якщо вивід несе сигнатуру провалу.
 *
 * ЩО ЦЕЙ ФАЙЛ НЕ РОБИТЬ (К8): він не знає, що таке "команда тест-раннера" чи
 * "сигнатура провалу" — ці два питання вже вирішені й перевірені в бою всередині
 * proof-gate.cjs (B2 зробив їх `module.exports`), і цей хук лише IMPORT-ить звідти
 * `isTestRunCommand` / `isFailureText`. Друга копія цих патернів у цьому репозиторії
 * вже двічі розходилась з оригіналом (spec.md, розділ ризиків) — тому тут її немає,
 * а тест test_plan_test_sync.mjs (кейс 7) прицільно доводить її відсутність.
 *
 * МЕХАНІКА (дзеркалить те, як гейт доказів ходить транскриптом, лише мета інша):
 * читаємо .jsonl з хвоста, шукаємо ОСТАННІЙ Bash tool_use, чия команда розпізнається
 * як прогін тест-раннера, і весь текст (tool_result/асистент), що йде після нього до
 * кінця транскрипту. Команда звіряється з `closeOn.match` активних кроків каналу
 * (через `plan_autopatch.find_steps_by_close_condition`, вже написана й перевірена
 * в B1 — тут не переізобретається), вивід — на сигнатуру провалу.
 *
 * ЗАПИС іде рівно через CLI `plan_autopatch.py` (B1): `mark_step` сам ставить
 * `source: "auto-patch"`, той самий маркер, яким перша ітерація вже позначає крок,
 * закритий за агентом (agent_worker.py: _try_plan_autopatch). Другого писача плану
 * тут немає.
 *
 * КАНАЛ визначається через plan-state.cjs: `boundChannel(sessionId)` (той самий
 * спосіб, яким уже користуються plan-ping.cjs і subagent-done.cjs). Немає
 * прив'язаного каналу — хук мовчки виходить, план ніде не чіпається.
 *
 * FAIL-OPEN (К9): усе виконання загорнуте так, що будь-який виняток — зламаний
 * транскрипт, відсутній python, неписьменна тека плану — логується у власний jsonl
 * (PLAN_TEST_SYNC_LOG або <repo>/.claude/plan-test-sync.jsonl) і ковтається. Хук
 * ЗАВЖДИ виходить кодом 0 і ніколи нічого не пише в stdout (це не блокуючий гейт,
 * а тихий сайд-ефект, як subagent-done.cjs).
 */
'use strict';

const fs = require('fs');
const path = require('path');
const { spawnSync } = require('child_process');

const CHAT_DIR = path.resolve(__dirname, '..');                     // tools/viz/chat
const REPO_ROOT = path.resolve(CHAT_DIR, '..', '..', '..');
const PLAN_AUTOPATCH = path.join(CHAT_DIR, 'plan_autopatch.py');
const PY_CANDIDATES = ['python3', 'python', 'py'];

const MAX_TAIL_BYTES = 4 * 1024 * 1024;

function logPath() {
  return process.env.PLAN_TEST_SYNC_LOG || path.join(REPO_ROOT, '.claude', 'plan-test-sync.jsonl');
}

/** Лічильник/леджер помилок. Сам ніколи не кидає (К9 не сміє залежати від нього). */
function logEvent(entry) {
  try {
    const p = logPath();
    fs.mkdirSync(path.dirname(p), { recursive: true });
    const line = JSON.stringify(Object.assign({ ts: new Date().toISOString(), hook: 'plan-test-sync' }, entry));
    fs.appendFileSync(p, line + '\n');
  } catch { /* лог не сміє ламати хук */ }
}

// ── читання транскрипту (хвіст, як у proof-gate.cjs — генеричний І/O, не патерн) ──

function readTranscriptLines(file) {
  const st = fs.statSync(file);
  const size = st.size;
  const start = Math.max(0, size - MAX_TAIL_BYTES);
  const len = size - start;
  const fd = fs.openSync(file, 'r');
  let text;
  try {
    const buf = Buffer.allocUnsafe(len);
    fs.readSync(fd, buf, 0, len, start);
    text = buf.toString('utf8');
    if (start > 0) {
      const nl = text.indexOf('\n');           // перший рядок міг бути обрізаний посередині
      text = nl >= 0 ? text.slice(nl + 1) : '';
    }
  } finally {
    try { fs.closeSync(fd); } catch { /* ignore */ }
  }
  return text.split('\n');
}

/** Текст будь-якого результату (tool_result або текст асистента) у рядку транскрипту. */
function extractResultText(o) {
  const content = o && o.message && o.message.content;
  if (typeof content === 'string') return content;
  if (!Array.isArray(content)) return '';
  let out = '';
  for (const b of content) {
    if (!b) continue;
    if (b.type === 'tool_result') {
      if (typeof b.content === 'string') out += b.content + '\n';
      else if (Array.isArray(b.content)) {
        for (const c of b.content) if (c && typeof c.text === 'string') out += c.text + '\n';
      }
    } else if (b.type === 'text' && typeof b.text === 'string') {
      out += b.text + '\n';
    }
  }
  return out;
}

/**
 * Останній Bash tool_use у транскрипті, чия команда `isTestRunCommand` (імпортована з
 * proof-gate.cjs), плюс увесь текст після нього до кінця транскрипту. `{found:false}`,
 * коли в транскрипті взагалі немає прогону тестів.
 */
function findLastTestRun(transcriptPath, isTestRunCommand) {
  const lines = readTranscriptLines(transcriptPath);

  let lastIdx = -1;
  let lastCommand = '';
  for (let i = 0; i < lines.length; i++) {
    const raw = lines[i];
    if (!raw || raw.indexOf('"tool_use"') === -1) continue;
    let o;
    try { o = JSON.parse(raw); } catch { continue; }
    const content = o && o.message && o.message.content;
    if (!Array.isArray(content)) continue;
    for (const b of content) {
      if (b && b.type === 'tool_use' && b.name === 'Bash' && isTestRunCommand(b.input && b.input.command)) {
        lastIdx = i;
        lastCommand = String((b.input && b.input.command) || '');
      }
    }
  }
  if (lastIdx < 0) return { found: false, command: '', outputText: '' };

  let outputText = '';
  for (let i = lastIdx + 1; i < lines.length; i++) {
    const raw = lines[i];
    if (!raw) continue;
    let o;
    try { o = JSON.parse(raw); } catch { continue; }
    outputText += extractResultText(o);
  }
  return { found: true, command: lastCommand, outputText };
}

// ── місток до plan_autopatch.py (єдиний писач; сам файл не чіпається) ───────────

function runPython(args) {
  for (const bin of PY_CANDIDATES) {
    const finalArgs = bin === 'py' ? ['-3', ...args] : args;
    const r = spawnSync(bin, finalArgs, { encoding: 'utf8', env: process.env });
    if (r.error && r.error.code === 'ENOENT') continue;    // немає такого інтерпретатора — пробуємо наступний
    return r;
  }
  return { error: new Error('no python interpreter found (tried: ' + PY_CANDIDATES.join(', ') + ')') };
}

/** Активні кроки каналу, чий `closeOn.type == 'tests'` і `match` є підрядком
 *  `command`. Читає-only, іде через уже написану й перевірену
 *  `plan_autopatch.find_steps_by_close_condition` (B1) — не переізобретається тут. */
function findClosingSteps(channel, command) {
  const code = [
    'import json, sys',
    `sys.path.insert(0, ${JSON.stringify(CHAT_DIR)})`,
    'import plan_autopatch as pa',
    'steps = pa.find_steps_by_close_condition(sys.argv[1], "tests", sys.argv[2])',
    'sys.stdout.write(json.dumps([s.get("id") for s in steps]))',
  ].join('\n');

  const r = runPython(['-c', code, channel, command]);
  if (r.error) throw r.error;
  if (r.status !== 0) {
    throw new Error('plan_autopatch find failed (exit ' + r.status + '): ' + String(r.stderr || '').slice(0, 300));
  }
  const out = String(r.stdout || '').trim();
  return out ? JSON.parse(out) : [];
}

/** Позначає ОДИН крок через CLI-вхід plan_autopatch.py (B1). EXIT_NOOP (2) — теж не
 *  помилка (крок зник/уже done між find і mark), лише EXIT_ERROR (1) кидає. */
function markStep(channel, stepId, state, note) {
  const args = [PLAN_AUTOPATCH, channel, stepId, state];
  if (note) args.push(note);
  const r = runPython(args);
  if (r.error) throw r.error;
  if (r.status !== 0 && r.status !== 2) {
    throw new Error('plan_autopatch mark_step failed (exit ' + r.status + '): ' + String(r.stderr || '').slice(0, 300));
  }
  return r.status;
}

const FAILURE_NOTE = 'Тести впали, перевір вивід останнього прогону.';

// ── main ────────────────────────────────────────────────────────────────────────

function main() {
  let input = {};
  try { input = JSON.parse(fs.readFileSync(0, 'utf8')); } catch { input = {}; }

  const sessionId = input && input.session_id ? String(input.session_id) : '';
  const transcriptPath = input && input.transcript_path;
  if (!transcriptPath || !fs.existsSync(transcriptPath)) return;

  let planState;
  try { planState = require('./plan-state.cjs'); } catch { return; }
  const channel = planState.boundChannel(sessionId);
  if (!channel) return;

  const { isTestRunCommand, isFailureText } = require('./proof-gate.cjs');

  const run = findLastTestRun(transcriptPath, isTestRunCommand);
  if (!run.found) return;                                   // у транскрипті взагалі немає прогону тестів

  let stepIds;
  try {
    stepIds = findClosingSteps(channel, run.command);
  } catch (e) {
    logEvent({ decision: 'error', why: 'find-failed', channel, message: String((e && e.message) || e).slice(0, 300), session_id: sessionId });
    return;
  }
  if (!stepIds.length) return;                              // жоден активний крок не чекає саме на цю команду

  const failed = isFailureText(run.outputText);
  for (const stepId of stepIds) {
    try {
      markStep(channel, stepId, failed ? 'blocked' : 'done', failed ? FAILURE_NOTE : null);
      logEvent({ decision: failed ? 'blocked' : 'done', channel, stepId, session_id: sessionId });
    } catch (e) {
      logEvent({ decision: 'error', why: 'mark-step-failed', channel, stepId, message: String((e && e.message) || e).slice(0, 300), session_id: sessionId });
    }
  }
}

module.exports = { findLastTestRun, findClosingSteps, markStep, extractResultText, readTranscriptLines };

if (require.main === module) {
  try { main(); } catch (e) {
    logEvent({ decision: 'error', why: 'hook-crashed', message: String((e && e.message) || e).slice(0, 300) });
  }
  process.exit(0);
}
