#!/usr/bin/env node
/**
 * proof-gate.cjs — Stop hook. Блокує рапорт «готово» без доказу + S3 TDD-шар.
 *
 * Правило власника (глобальний CLAUDE.md): «готово без доказу означає не готово».
 * Прозою модель виконує його ймовірнісно і забуває під кінець довгої сесії.
 * Хуком воно спрацьовує детерміновано. Determinism over hope.
 *
 * ЩО РОБИТЬ (шар 1, БЛОКУЮЧИЙ, як і раніше): читає транскрипт сесії з хвоста,
 * знаходить ОСТАННІЙ Edit/Write прод-файлу (тільки код, вузький скоуп нижче) і
 * перевіряє, чи зʼявився після нього хоч один артефакт-доказ (тест / запуск /
 * curl / компіляція / скрін). Немає доказу → блок з КОРИСНИМ повідомленням.
 *
 * ЩО РОБИТЬ (шар 2, S3 TDD-гейт, specs/spec-first-sdlc/spec.md, НЕ БЛОКУЄ):
 * коли шар 1 знайшов доказ (пройшов), питає СТРОГІШЕ — чи цей доказ показує, що
 * тест був ЧЕРВОНИМ ДО правки, а не просто «щось запустили після». Нема такого
 * доказу → попередження (stdout БЕЗ поля "decision", тому Stop не блокується) +
 * рядок у work/tdd-skips.json. Виняток: чисто візуальна правка, доказом якої
 * вважається скрін ДО і скрін ПІСЛЯ (обидва прочитані Read) — тоді шар 2 мовчить,
 * але все одно пише рядок у леджер з поясненням, це не вгадується, а фіксується
 * фактом наявності обох скрінів.
 *
 * ФОРМАТ ДОКАЗУ ЧЕРВОНОГО ТЕСТУ (єдине місце опису, дотримуємось скрізь нижче):
 *   1. Bash tool_use з командою тест-раннера (TEST_RUN_PATTERNS: npm test,
 *      node --test, run-tests.cjs, pytest, playwright, jest, vitest) —
 *   2. СТРОГО ДО останньої правки прод-файлу (лінійно раніше у транскрипті) —
 *   3. і подальший вивід (tool_result або текст асистента одразу після) містить
 *      сигнатуру провалу (FAILURE_PATTERNS: FAIL/FAILED, AssertionError, not ok,
 *      ✗/✘/✕, "N failing", exit code > 0).
 *   Назва тесту витягується найкращим зусиллям (extractTestName) лише для
 *   людського тексту попередження/леджера, на саме рішення pass/warn не впливає.
 *
 * ВИНЯТОК (ВІЗУАЛЬНА ПРАВКА): якщо є хоч один Read .png/.jpg/... ДО останньої
 * правки і хоч один ПІСЛЯ — вважається довід «скрін до / скрін після» закритим.
 * Це навмисно жорсткий, детермінований критерій (наявність обох артефактів),
 * а не здогадка моделі про те, «візуальна це правка чи ні».
 *
 * КОНТРАКТ ХУКА (звірено з https://code.claude.com/docs/en/hooks, 2026-07-29):
 *   stdin  : { session_id, transcript_path, cwd, hook_event_name:"Stop",
 *              stop_hook_active, last_assistant_message, ... }
 *   вихід  : «JSON output is only processed on exit 0».
 *            Блок (шар 1) = exit 0 + stdout {"decision":"block","reason":"..."}.
 *            Попередження (шар 2) = exit 0 + stdout {"systemMessage":"..."} БЕЗ
 *            поля "decision" — за офіційним прикладом Stop-виводу systemMessage
 *            це окреме, не-блокуюче поле контексту, тому Stop не затримується.
 *            Свідомо НЕ використовуємо exit 2 для жодного з двох шарів (теж
 *            блокує, stderr йде моделі): при JSON-варіанті будь-який неочікуваний
 *            ненульовий код = «non-blocking error», аварія хука фізично не
 *            здатна нічого заблокувати.
 *   loop   : stop_hook_active === true означає «хук уже блокував» → миттєвий пропуск.
 *
 * ГОЛОВНА ВИМОГА: FAIL-OPEN, для ОБОХ шарів. Будь-яка внутрішня помилка, брак
 * файлу, битий JSON, перевищення бюджету часу = ТИХИЙ ПРОПУСК (exit 0, порожній
 * stdout). Хук, що ламається, не сміє паралізувати роботу.
 *
 * ЕСКЕЙПИ (без редагування конфігу, діють на ОБИДВА шари одразу):
 *   PROOF_GATE=off            повністю вимикає
 *   маркер skip-proof у квадратних дужках у повідомленні КОРИСТУВАЧА
 *
 * ЛІЧИЛЬНИК: кожне рішення дописується рядком у .claude/gates.jsonl (обидва шари).
 * ЛЕДЖЕР ШАРУ 2: work/tdd-skips.json — {when,label,files,reason} на кожен пропуск
 * TDD-доказу (і візуальний виняток, і справжню прогалину), симетрично до
 * work/spec-skips.json з S2 (scripts/agent-run.cjs). Мета та сама: наприкінці
 * тижня видно, скільки разів ішли без червоного тесту і чому.
 *
 * Крос-платформа: чистий node, без .sh, без шел-глобів, без хардкод-шляхів.
 */
'use strict';

const fs = require('fs');
const path = require('path');

// ── СКОУП: що вважається прод-файлом ────────────────────────────────────────
// Живе у спільному _scope.cjs, бо той самий скоуп судить edit-gate.cjs.
// Дві копії констант розʼїжджаються, і гейти починають судити різні множини.
const { repoRoot, norm, toRel, isProdFile } = require('./_scope.cjs');

// Дзеркалення імен змінних середовища (CHATVIEW_* <-> LOGOPSIS_*) під час ребренду.
// Мусить стояти вище за перше читання process.env у цьому файлі: у власника
// лишились запущені служби і аліаси зі старими іменами. Контракт: brand-env.cjs.
require("../brand-env.cjs")

// ── ШАР 1: ЩО ВВАЖАЄТЬСЯ ДОКАЗОМ (будь-яким, не обовʼязково тестом) ─────────
// Bash-команда, яка щось РЕАЛЬНО перевіряє. Свідомо поблажливо: краще
// пропустити сумнівне, ніж тероризувати кожен тан.
const EVIDENCE_CMD_PATTERNS = [
  /\bnpm\s+(run\s+)?test\b/i,      // npm test
  /\bnode\s+--test\b/i,            // node --test
  /run-tests\.cjs/i,               // наш раннер
  /\bpytest\b/i,
  /\bplaywright\b/i,
  /\bjest\b/i,
  /\bvitest\b/i,
  /\bcurl\b/i,                     // жива перевірка HTTP
  /\bwget\b/i,
  /http_code|status_code|\bHTTP\/[12]/i,
  /\bnode\s+-e\b/i,                // швидка перевірка логіки/компіляції
  /\bnode\s+--check\b/i,
  /py_compile/i,
  /\btsc\b/i,
  /\beslint\b/i,
  /\bruff\b/i,
  /\bnpm\s+run\s+build\b/i,
];

// Read такого файлу = на скрін реально дивились.
const IMAGE_EXTS = ['.png', '.jpg', '.jpeg', '.webp', '.gif'];

// ── ШАР 2 (S3): справжній тест-раннер, вужче за EVIDENCE_CMD_PATTERNS.
// curl/eslint/tsc/build НЕ рахуються за «тест» у сенсі TDD, тому список окремий.
const TEST_RUN_PATTERNS = [
  /\bnpm\s+(run\s+)?test\b/i,
  /\bnode\s+--test\b/i,
  /run-tests\.cjs/i,
  /\bpytest\b/i,
  /\bplaywright\b/i,
  /\bjest\b/i,
  /\bvitest\b/i,
];

// Сигнатура провалу у виводі тесту. Поблажливо навмисно, той самий принцип,
// АЛЕ без голого /failing/: «0 failing» це ЗЕЛЕНИЙ прогін, а не провал, тому
// рахуємо лише «N failing» з N>=1.
const FAILURE_PATTERNS = [
  /\bFAIL(ED|URE)?\b/,
  /✗|✘|✕/,
  /AssertionError/,
  /\bnot ok\b/i,
  /\bexit code\s*[1-9]/i,
  /\b[1-9]\d*\s+failing\b/i,
];

// Найкраще зусилля витягти назву тесту з виводу провалу — тільки для тексту
// попередження/леджера, на рішення pass/warn не впливає.
const TEST_NAME_HINT_PATTERNS = [
  /FAIL\s+(\S+)/,
  /not ok\s+\d+\s*-\s*(.+)/i,
  /[✗✘✕]\s*(.+)/,
  /(test_[\w./-]+\.\w+)/,
  /([\w./-]+\.test\.\w+)/,
];

// ── БЮДЖЕТИ (транскрипт буває на десятки МБ) ────────────────────────────────
const TIME_BUDGET_MS = 2000;   // перевищив → пропуск
const MAX_TAIL_BYTES = 4 * 1024 * 1024;
const MAX_LINES = 20000;

// Маркер зібрано конкатенацією НАВМИСНО: інакше літерал потрапляє у транскрипт
// разом із вихідником цього файлу і гейт сам себе назавжди вимикає.
const SKIP_MARKER = '[skip' + '-proof]';

// ── утиліти ─────────────────────────────────────────────────────────────────

function logPath() {
  if (process.env.PROOF_GATE_LOG) return process.env.PROOF_GATE_LOG;
  return path.join(repoRoot(), '.claude', 'gates.jsonl');
}

/** work/tdd-skips.json, з тестовим оверрайдом (як PROOF_GATE_LOG). */
function tddLedgerPath() {
  if (process.env.PROOF_GATE_TDD_LEDGER) return process.env.PROOF_GATE_TDD_LEDGER;
  return path.join(repoRoot(), 'work', 'tdd-skips.json');
}

/** Лічильник. Сам ніколи не кидає. */
function record(entry) {
  try {
    const p = logPath();
    fs.mkdirSync(path.dirname(p), { recursive: true });
    const line = JSON.stringify(Object.assign({
      ts: new Date().toISOString(),
      gate: 'proof-gate',
    }, entry, process.env.PROOF_GATE_TAG ? { tag: process.env.PROOF_GATE_TAG } : null));
    fs.appendFileSync(p, line + '\n');
  } catch { /* лічильник не сміє ламати гейт */ }
}

/** Дописує {when,label,files,reason} у work/tdd-skips.json. Best-effort, як
 *  spec-skips.json з S2: журнал видимості, не критичний стан, битий/відсутній
 *  леджер тихо перезаводиться з нуля. */
function appendTddSkipLedger({ label, files, reason }) {
  try {
    const p = tddLedgerPath();
    let entries = [];
    try {
      const raw = JSON.parse(fs.readFileSync(p, 'utf8'));
      if (Array.isArray(raw)) entries = raw;
    } catch { entries = []; }
    entries.push({
      when: new Date().toISOString(),
      label: label || '',
      files: (files || []).slice(0, 20),
      reason,
    });
    fs.mkdirSync(path.dirname(p), { recursive: true });
    fs.writeFileSync(p, JSON.stringify(entries, null, 2) + '\n');
  } catch { /* леджер не сміє ламати гейт */ }
}

function isEvidenceCommand(cmd) {
  const c = String(cmd || '');
  if (!c) return false;
  return EVIDENCE_CMD_PATTERNS.some((re) => re.test(c));
}

function isTestRunCommand(cmd) {
  const c = String(cmd || '');
  if (!c) return false;
  return TEST_RUN_PATTERNS.some((re) => re.test(c));
}

function isFailureText(text) {
  const t = String(text || '');
  if (!t) return false;
  return FAILURE_PATTERNS.some((re) => re.test(t));
}

function extractTestName(text) {
  const t = String(text || '');
  for (const re of TEST_NAME_HINT_PATTERNS) {
    const m = re.exec(t);
    if (m && m[1]) return m[1].trim().slice(0, 120);
  }
  return '(назва не розпізнана, дивись вивід)';
}

/** Текст будь-якого результату (tool_result або текст асистента) у рядку
 *  транскрипту — для пошуку сигнатури провалу після тест-команди. */
function extractResultText(o) {
  const content = o && o.message && o.message.content;
  if (typeof content === 'string') return content;
  if (!Array.isArray(content)) return '';
  let out = '';
  for (const b of content) {
    if (!b) continue;
    if (b.type === 'tool_result') {
      if (typeof b.content === 'string') out += b.content + '\n';
      else if (Array.isArray(b.content)) {
        for (const c of b.content) if (c && typeof c.text === 'string') out += c.text + '\n';
      }
    } else if (b.type === 'text' && typeof b.text === 'string') {
      out += b.text + '\n';
    }
  }
  return out;
}

function isImageRead(input) {
  const f = norm(input && input.file_path).toLowerCase();
  if (!f) return false;
  return IMAGE_EXTS.some((e) => f.endsWith(e));
}

/** Хвіст файлу як текст. Кидає — ловиться вище (fail-open). */
function readTail(file) {
  const st = fs.statSync(file);
  const size = st.size;
  const start = Math.max(0, size - MAX_TAIL_BYTES);
  const len = size - start;
  const fd = fs.openSync(file, 'r');
  try {
    const buf = Buffer.allocUnsafe(len);
    fs.readSync(fd, buf, 0, len, start);
    let text = buf.toString('utf8');
    if (start > 0) {
      const nl = text.indexOf('\n');           // перший рядок обрізаний посередині
      text = nl >= 0 ? text.slice(nl + 1) : '';
    }
    return text;
  } finally {
    try { fs.closeSync(fd); } catch { /* ignore */ }
  }
}

/** Текст справжнього промпту користувача (не tool_result, не meta). */
function userText(o) {
  if (!o || o.type !== 'user') return '';
  if (o.toolUseResult) return '';              // це результат інструмента, не людини
  if (o.isMeta) return '';
  const c = o.message && o.message.content;
  if (typeof c === 'string') return c;
  if (Array.isArray(c)) {
    let out = '';
    for (const b of c) {
      if (b && b.type === 'tool_result') return '';
      if (b && b.type === 'text' && typeof b.text === 'string') out += b.text + '\n';
    }
    return out;
  }
  return '';
}

/** Мітка задачі для попередження/леджера. Найкраще зусилля, не критично, якщо
 *  порожньо — просто менш інформативний текст, гейт не ламається. */
function resolveLabel(firstUserPromptText) {
  const ch = String(process.env.CHATVIEW_CHANNEL || '').trim();
  const first = String(firstUserPromptText || '').trim().split('\n')[0].slice(0, 80);
  if (ch && first) return `${ch}: ${first}`;
  return first || ch || '(без назви)';
}

// ── ШАР 2: пошук доказу ЧЕРВОНОГО тесту ДО останньої правки ─────────────────
/**
 * Скан [from, editIdx) у пошуку: Bash tool_use з тест-командою (TEST_RUN_PATTERNS),
 * а ПІСЛЯ нього (лінійно, до наступної правки) — виводу з сигнатурою провалу.
 * Перше знайдене пасує — цього досить, TDD не вимагає, щоб ЦЕЙ САМИЙ прогін був
 * останнім перед правкою, лише щоб тест БУВ червоним колись до неї.
 */
function findRedProofBeforeEdit(lines, from, editIdx, deadline) {
  let pendingCmdIdx = -1;
  for (let i = from; i < editIdx; i++) {
    if ((i & 255) === 0 && Date.now() > deadline) throw new Error('time budget');
    const raw = lines[i];
    if (!raw || raw.length < 2) continue;
    const maybeTool = raw.indexOf('"tool_use"') !== -1;
    const maybeUser = raw.indexOf('"type":"user"') !== -1 || raw.indexOf('"type": "user"') !== -1;
    if (!maybeTool && !maybeUser) continue;

    let o;
    try { o = JSON.parse(raw); } catch { continue; }

    const content = o && o.message && o.message.content;
    if (Array.isArray(content)) {
      for (const b of content) {
        if (b && b.type === 'tool_use' && b.name === 'Bash' && isTestRunCommand(b.input && b.input.command)) {
          pendingCmdIdx = i;
        }
      }
    }

    if (pendingCmdIdx !== -1 && i >= pendingCmdIdx) {
      const text = extractResultText(o);
      if (text && isFailureText(text)) {
        return { found: true, testName: extractTestName(text) };
      }
    }
  }
  return { found: false, testName: '' };
}

/** true = є хоч один Read зображення в діапазоні [start, end). */
function hasImageReadInRange(lines, start, end, deadline) {
  for (let i = start; i < end; i++) {
    if ((i & 255) === 0 && Date.now() > deadline) throw new Error('time budget');
    const raw = lines[i];
    if (!raw || raw.indexOf('"tool_use"') === -1) continue;
    let o;
    try { o = JSON.parse(raw); } catch { continue; }
    const content = o && o.message && o.message.content;
    if (!Array.isArray(content)) continue;
    for (const b of content) {
      if (b && b.type === 'tool_use' && b.name === 'Read' && isImageRead(b.input || {})) return true;
    }
  }
  return false;
}

/**
 * Вердикт шару 2 для вже підтвердженої прод-правки з доказом (шар 1 = pass).
 * @returns {{status:'red-proof'|'visual-exception'|'missing', testName:string}}
 */
function judgeTdd(lines, from, lastEditIdx, deadline) {
  const red = findRedProofBeforeEdit(lines, from, lastEditIdx, deadline);
  if (red.found) return { status: 'red-proof', testName: red.testName };

  const before = hasImageReadInRange(lines, from, lastEditIdx, deadline);
  const after = before && hasImageReadInRange(lines, lastEditIdx + 1, lines.length, deadline);
  if (before && after) return { status: 'visual-exception', testName: '' };

  return { status: 'missing', testName: '' };
}

// ── ядро (шар 1) ──────────────────────────────────────────────────────────

/**
 * @returns {{decision:'block'|'pass'|'skip', reason:string, files:string[],
 *            sig:string, tdd:?{status,testName}, firstUserPromptText:string}}
 */
function analyze(transcriptPath, cwd, deadline) {
  const text = readTail(transcriptPath);
  const lines = text.split('\n');
  const from = Math.max(0, lines.length - MAX_LINES);

  let lastEditIdx = -1;
  let lastEditSig = '';
  const editedFiles = [];        // прод-файли, торкнуті у вікні (унікальні)
  let lastEvidenceIdx = -1;
  let lastUserPromptIdx = -1;
  let firstUserPromptText = '';
  let skipMarker = false;

  for (let i = from; i < lines.length; i++) {
    if ((i & 255) === 0 && Date.now() > deadline) throw new Error('time budget');
    const raw = lines[i];
    if (!raw || raw.length < 2) continue;

    // Дешевий пре-фільтр: парсимо лише те, що взагалі може мати значення.
    const maybeTool = raw.indexOf('"tool_use"') !== -1;
    const maybeUser = raw.indexOf('"type":"user"') !== -1 || raw.indexOf('"type": "user"') !== -1;
    if (!maybeTool && !maybeUser) continue;

    let o;
    try { o = JSON.parse(raw); } catch { continue; }

    if (maybeUser) {
      const t = userText(o);
      if (t) {
        lastUserPromptIdx = i;
        if (!firstUserPromptText) firstUserPromptText = t;
        if (t.includes(SKIP_MARKER)) skipMarker = true;
      }
    }

    const content = o && o.message && o.message.content;
    if (!Array.isArray(content)) continue;

    for (const b of content) {
      if (!b || b.type !== 'tool_use') continue;
      const name = b.name;
      const input = b.input || {};

      if (name === 'Edit' || name === 'Write' || name === 'NotebookEdit' || name === 'MultiEdit') {
        if (isProdFile(input.file_path || input.notebook_path, cwd)) {
          lastEditIdx = i;
          lastEditSig = String(o.uuid || '') + '|' + norm(input.file_path || input.notebook_path);
          const rel = toRel(input.file_path || input.notebook_path, cwd);
          if (!editedFiles.includes(rel)) editedFiles.push(rel);
        }
        continue;
      }

      if (name === 'Bash' || name === 'BashOutput') {
        if (isEvidenceCommand(input.command)) lastEvidenceIdx = i;
        continue;
      }

      if (name === 'Read' && isImageRead(input)) {
        lastEvidenceIdx = i;
      }
    }
  }

  if (skipMarker) {
    return { decision: 'skip', reason: 'skip-marker-in-user-message', files: [], sig: '', tdd: null, firstUserPromptText };
  }
  if (lastEditIdx < 0) {
    return { decision: 'pass', reason: 'no-prod-edits', files: [], sig: '', tdd: null, firstUserPromptText };
  }

  // Людина взяла кермо після правки: гейт не нагадує про минулий хід (обидва шари).
  if (lastUserPromptIdx > lastEditIdx) {
    return { decision: 'pass', reason: 'user-prompt-after-edit', files: editedFiles, sig: lastEditSig, tdd: null, firstUserPromptText };
  }

  if (lastEvidenceIdx > lastEditIdx) {
    const tdd = judgeTdd(lines, from, lastEditIdx, deadline);
    return { decision: 'pass', reason: 'evidence-after-edit', files: editedFiles, sig: lastEditSig, tdd, firstUserPromptText };
  }

  // Другий прохід тільки тепер: чи запускали САМЕ те, що змінили.
  const bases = editedFiles.map((f) => path.posix.basename(norm(f))).filter(Boolean);
  for (let i = lastEditIdx + 1; i < lines.length; i++) {
    if ((i & 255) === 0 && Date.now() > deadline) throw new Error('time budget');
    const raw = lines[i];
    if (!raw || raw.indexOf('"tool_use"') === -1) continue;
    let o;
    try { o = JSON.parse(raw); } catch { continue; }
    const content = o && o.message && o.message.content;
    if (!Array.isArray(content)) continue;
    for (const b of content) {
      if (!b || b.type !== 'tool_use' || b.name !== 'Bash') continue;
      const cmd = String((b.input && b.input.command) || '');
      if (bases.some((base) => base && cmd.includes(base))) {
        const tdd = judgeTdd(lines, from, lastEditIdx, deadline);
        return { decision: 'pass', reason: 'ran-edited-file', files: editedFiles, sig: lastEditSig, tdd, firstUserPromptText };
      }
    }
  }

  return { decision: 'block', reason: 'no-evidence-after-edit', files: editedFiles, sig: lastEditSig, tdd: null, firstUserPromptText };
}

/** Другий пояс проти циклу: та сама правка не блокує/не попереджає двічі.
 *  @param {string[]} decisions рішення з gates.jsonl, будь-яке з яких рахується. */
function alreadyDecided(sessionId, sig, decisions) {
  try {
    if (!sig) return false;
    const p = logPath();
    if (!fs.existsSync(p)) return false;
    const st = fs.statSync(p);
    const start = Math.max(0, st.size - 256 * 1024);
    const fd = fs.openSync(p, 'r');
    let text = '';
    try {
      const buf = Buffer.allocUnsafe(st.size - start);
      fs.readSync(fd, buf, 0, st.size - start, start);
      text = buf.toString('utf8');
    } finally { try { fs.closeSync(fd); } catch { /* ignore */ } }
    for (const line of text.split('\n')) {
      if (!line) continue;
      let o;
      try { o = JSON.parse(line); } catch { continue; }
      if (o.gate === 'proof-gate' && decisions.includes(o.decision) &&
          o.session_id === sessionId && o.sig === sig) return true;
    }
  } catch { /* fail-open */ }
  return false;
}

function buildReason(files) {
  const list = files.length
    ? files.slice(0, 8).map((f) => '  - ' + f).join('\n')
    : '  - (список не відновився)';
  return [
    'СТОП, гейт доказу (proof-gate).',
    '',
    'У цій сесії ти правив код, а після останньої правки немає ЖОДНОГО артефакта,',
    'який показує, що воно працює. Правило власника: «готово» без доказу означає не готово.',
    '',
    'Змінено без перевірки:',
    list,
    '',
    'Закрий гейт тим, що релевантно (одного достатньо):',
    '  1. прогони тести: npm test (або node --test на конкретний файл, або pytest)',
    '  2. запусти те, що змінив, і покажи вивід: node <файл>, curl на ендпоінт, node -e перевірка',
    '  3. якщо це UI: зроби скрін і РЕАЛЬНО подивись на нього (Read .png)',
    '',
    'Якщо доказ тут справді зайвий, постав PROOF_GATE=off або попроси власника сказати це словами.',
  ].join('\n');
}

/** Текст попередження шару 2 (TDD). НЕ блокує — у stdout нема "decision". */
function buildTddWarnReason(files, label) {
  const list = files.length
    ? files.slice(0, 8).map((f) => '  - ' + f).join('\n')
    : '  - (список не відновився)';
  return [
    'УВАГА, гейт TDD-доказу (proof-gate, шар 2, S3). НЕ блокую, лише фіксую пропуск.',
    '',
    `Задача: ${label}`,
    '',
    'Торкнуті файли без доказу, що тест БУВ ЧЕРВОНИМ до правки:',
    list,
    '',
    'Бракує ОДНОГО з двох:',
    '  1. доказ RED-до-фіксу: запусти тест-раннер (npm test / pytest / ...) ДО',
    '     наступної правки і покажи, що конкретний тест падає (FAIL/AssertionError)',
    '  2. якщо це чисто візуальна CSS/текстова правка: скрін ДО і скрін ПІСЛЯ (Read обох)',
    '',
    'Записано у work/tdd-skips.json для видимості. Це попередження, не блок.',
  ].join('\n');
}

// ── main ────────────────────────────────────────────────────────────────────

/** Обробка шару 2 для вже пройденого шаром 1 pass-результату. Повертає рядок
 *  для stdout (попередження) або null (тиша: red-proof / вже враховано / n/a). */
function handleTdd(res, sessionId) {
  if (!res.tdd) return null;                    // цей шлях TDD не судить

  if (res.tdd.status === 'red-proof') {
    record({ decision: 'tdd-ok', why: 'red-proof-before-edit', touched: res.files.length, sig: res.sig, session_id: sessionId });
    return null;
  }

  if (alreadyDecided(sessionId, res.sig, ['tdd-warn', 'tdd-skip'])) {
    record({ decision: 'skip', why: 'tdd-already-logged-once', touched: res.files.length, session_id: sessionId });
    return null;
  }

  const label = resolveLabel(res.firstUserPromptText);

  if (res.tdd.status === 'visual-exception') {
    appendTddSkipLedger({ label, files: res.files, reason: 'візуальна правка: скрін до і після (виняток S3)' });
    record({ decision: 'tdd-skip', why: 'visual-exception', touched: res.files.length, files: res.files.slice(0, 8), sig: res.sig, session_id: sessionId });
    return null;
  }

  // 'missing'
  appendTddSkipLedger({ label, files: res.files, reason: 'доказу червоного тесту до правки немає' });
  record({ decision: 'tdd-warn', why: 'no-red-proof', touched: res.files.length, files: res.files.slice(0, 8), sig: res.sig, session_id: sessionId });
  return JSON.stringify({ systemMessage: buildTddWarnReason(res.files, label) });
}

function main() {
  const deadline = Date.now() + TIME_BUDGET_MS;

  let input = {};
  try { input = JSON.parse(fs.readFileSync(0, 'utf8')); } catch { input = {}; }

  const sessionId = String((input && input.session_id) || '');

  // 1. ANTI-LOOP. Найперше і без жодної роботи.
  if (input && input.stop_hook_active === true) {
    record({ decision: 'skip', why: 'stop_hook_active', touched: 0, session_id: sessionId });
    return 0;
  }

  // 2. ЕСКЕЙП через оточення. Вимикає ОБИДВА шари.
  const off = String(process.env.PROOF_GATE || '').toLowerCase();
  if (off === 'off' || off === '0' || off === 'false') {
    record({ decision: 'skip', why: 'env-off', touched: 0, session_id: sessionId });
    return 0;
  }

  const transcriptPath = input && input.transcript_path;
  if (!transcriptPath || !fs.existsSync(transcriptPath)) {
    record({ decision: 'error', why: 'no-transcript', touched: 0, session_id: sessionId });
    return 0;                                   // fail-open
  }

  let res;
  try {
    res = analyze(transcriptPath, (input && input.cwd) || repoRoot(), deadline);
  } catch (e) {
    record({ decision: 'error', why: String((e && e.message) || e).slice(0, 200), touched: 0, session_id: sessionId });
    return 0;                                   // fail-open
  }

  if (res.decision === 'skip') {
    record({ decision: 'skip', why: res.reason, touched: res.files.length, session_id: sessionId });
    return 0;
  }

  if (res.decision === 'pass') {
    record({ decision: 'pass', why: res.reason, touched: res.files.length, session_id: sessionId });
    const warn = handleTdd(res, sessionId);
    if (warn) process.stdout.write(warn);
    return 0;
  }

  if (alreadyDecided(sessionId, res.sig, ['block'])) {
    record({ decision: 'skip', why: 'already-blocked-once', touched: res.files.length, session_id: sessionId });
    return 0;
  }

  record({
    decision: 'block',
    why: res.reason,
    touched: res.files.length,
    files: res.files.slice(0, 8),
    sig: res.sig,
    session_id: sessionId,
  });
  process.stdout.write(JSON.stringify({ decision: 'block', reason: buildReason(res.files) }));
  return 0;
}

module.exports = {
  TEST_RUN_PATTERNS,
  FAILURE_PATTERNS,
  isTestRunCommand,
  isFailureText,
};

// Запускаємось як хук тільки коли нас викликали напряму: з інших модулів файл
// require-иться заради патернів/функцій вище, без побічного читання stdin.
if (require.main === module) {
  let code = 0;
  try {
    code = main();
  } catch {
    code = 0;                                   // FAIL-OPEN, завжди
  }
  process.exit(code);
}
