#!/usr/bin/env node
// UserPromptSubmit hook (cross-platform: Mac + Windows).
// Four jobs, injected as context on EVERY prompt:
//   1. PLAN TRACKING (rule #1): keep the Chat View plan sidebar in sync with reality.
//      Deterministically surfaces the active channel's plan snapshot + STALE flag.
//   2. OPEN ORDERED STEPS, NAMED (specs/plan-safety-gates/spec.md, К5): the snapshot
//      above is a count ("40/54"), and a count alone let the model report "усе
//      готово" about the LAST step while four ordered steps still sat open (the
//      спека's own incident). Naming the actual open steps here closes that gap.
//   3. Chat View first: all answers go to the channel as cards, not the terminal.
//   4. SESSION BINDING: if this Claude Code session has its own channel (created by
//      session-start.cjs), pin ALL output to that channel + relay its deep link.
//      Falls back to the mtime heuristic for sessions with no binding.
//
// Registered from .claude/settings.json with a portable ${CLAUDE_PROJECT_DIR} path.
// Must never throw / never exit non-zero — that would block prompt submission.

const fs = require('fs');
const path = require('path');

// ── G3: поіменний перелік відкритих ЗАМОВЛЕНИХ кроків (specs/plan-safety-gates, К5) ──
// Читаємо вже ЗБЕРЕЖЕНИЙ plan.json напряму (той самий файл, який інспектує
// plan-state.cjs через CHANNELS_DIR, не чіпаючи сам цей модуль і не дублюючи його
// публічний контракт). Origin-правило копіює plan_store.py (_stored_origin, К2
// розділу «ORDERED VS PROPOSED»): власний прапорець кроку, якщо він визнаний
// ('ordered'/'proposed'), інакше — ordered за замовчуванням, бо крок уже лежить у
// ЗБЕРЕЖЕНОМУ плані. Пропозиції (origin: proposed) у перелік не йдуть: вони не
// зобовʼязання, і їхня присутність роздула б контекст тим самим шумом, яким уже
// хворіє голе число done/total.
const MAX_OPEN_STEPS_LISTED = 10; // досить, щоб побачити весь типовий відкритий
  // хвіст одним екраном без другого прокручування; більше кроків — рахуємо і
  // чесно кажемо скільки ще лишилось поза переліком (вимога 2), не мовчимо.
const MAX_STEP_TEXT_LEN = 90; // один рядок без переносів, що самі й зʼїдять контекст.

function truncateStepText(text) {
  const s = String(text || '').trim();
  if (s.length <= MAX_STEP_TEXT_LEN) return s;
  return s.slice(0, MAX_STEP_TEXT_LEN - 1).trimEnd() + '…';
}

// Той самий default, що plan_store.py:_stored_origin — крок без власного прапорця,
// що вже сидить у ЗБЕРЕЖЕНОМУ плані, читається як ordered (інакше план, записаний
// до появи цього поля, миттю втратив би весь прогрес).
function stepOrigin(step) {
  const raw = step && typeof step === 'object' ? step.origin : null;
  const v = raw ? String(raw).trim().toLowerCase() : '';
  return v === 'ordered' || v === 'proposed' ? v : 'ordered';
}

// Той самий розбір фаз/кроків, що inspectActivePlan у plan-state.cjs (не чіпаємо
// сам модуль, тому мінімальна копія цього єдиного рядка тут).
function planSteps(plan) {
  if (!plan) return [];
  if (Array.isArray(plan.phases)) return plan.phases.flatMap((p) => (p && p.steps) || []);
  return Array.isArray(plan.steps) ? plan.steps : [];
}

function openOrderedSteps(plan) {
  return planSteps(plan).filter((s) => s && s.state !== 'done' && stepOrigin(s) === 'ordered');
}

// Будує текстовий блок «поіменний перелік», або null коли немає що показувати
// (нема плану / канал ще не матеріалізований / немає відкритих замовлених кроків /
// файл плану нечитабельний). Ніколи не кидає.
function buildOpenStepsBlock(channelsDir, planInfo) {
  if (!planInfo || planInfo.noPlan || !planInfo.id) return null;
  let plan = null;
  try {
    plan = JSON.parse(fs.readFileSync(path.join(channelsDir, planInfo.id, 'plan.json'), 'utf8'));
  } catch {
    return null;
  }
  const open = openOrderedSteps(plan);
  if (!open.length) return null;
  const shown = open.slice(0, MAX_OPEN_STEPS_LISTED);
  const rest = open.length - shown.length;
  const lines = [
    `━━ OPEN ORDERED STEPS in "${planInfo.label}" (named, not a count — plan-safety-gates К5) ━━`,
    `${open.length} відкритих ЗАМОВЛЕНИХ кроків (не done, origin ≠ proposed). Перед словом "готово" звір саме з ними:`,
    ...shown.map((s, i) => `  ${i + 1}. ${truncateStepText(s && s.text)}`),
  ];
  if (rest > 0) {
    lines.push(`  …і ще ${rest} поза цим переліком (ліміт ${MAX_OPEN_STEPS_LISTED}; повний список — у plan.json каналу).`);
  }
  return lines.join('\n');
}

function main() {

// stdin JSON carries { session_id, ... } on UserPromptSubmit.
let input = {};
try { input = JSON.parse(fs.readFileSync(0, 'utf8')); } catch {}
const sessionId = input && input.session_id ? String(input.session_id) : '';

// Deterministic detection of an EXPLICIT "add/update the plan" ask in THIS prompt, so
// the reminder can SHOUT a mandatory directive (owner decision 2026-06-29: the agent kept ignoring
// "додай в план" / not using the per-channel plan at all). Matches UA + EN verb stems
// next to план/plan in either order.
const userPrompt = input && input.prompt ? String(input.prompt) : '';
const PLAN_ADD_RE = /(дода|занес|запиш|внес|онов|постав|track|add|put|append|update|log)[^.\n]{0,18}(план|plan)|(план|plan)[^.\n]{0,18}(дода|занес|запиш|внес|онов|постав|track|add|put|append|update|log)/i;
const explicitPlanAdd = PLAN_ADD_RE.test(userPrompt);

let mod = null;
try { mod = require('./plan-state.cjs'); } catch {}

// Is this channel MATERIALIZED yet? (dir exists AND it is in the merged registry,
// i.e. it has had real content written + been registered by render-message/set-plan).
// A reserved-but-empty channel has no tab to show a dot on, so we must NOT create
// an orphan dir just to drop a cc-busy marker into it.
function isMaterialized(cid) {
  if (!cid) return false;
  try { if (!fs.existsSync(path.join(mod.CHANNELS_DIR, cid))) return false; } catch { return false; }
  for (const name of ['index.json', 'index.local.json']) {
    try {
      const reg = JSON.parse(fs.readFileSync(path.join(mod.CHANNELS_DIR, name), 'utf8'));
      if (Array.isArray(reg) && reg.some(x => x && x.id === cid)) return true;
    } catch {}
  }
  return false;
}

// Resolve the channel bound (reserved) to THIS session, if any. The binding is
// injected unconditionally so Claude writes there (which lazily materializes it),
// but the cc-busy dot marker is only written once the channel actually exists.
let boundId = null, boundLabel = '';
if (mod) {
  try { boundId = mod.boundChannel(sessionId); } catch {}
  if (boundId) {
    for (const name of ['index.json', 'index.local.json']) {
      try {
        const reg = JSON.parse(fs.readFileSync(path.join(mod.CHANNELS_DIR, name), 'utf8'));
        const c = (reg || []).find(x => x && x.id === boundId);
        if (c && c.label) { boundLabel = c.label; break; }
      } catch {}
    }
    if (!boundLabel) boundLabel = boundId;
    // Mark this channel as WORKING (yellow dot) for the tab indicator ONLY if it is
    // already materialized. Cleared by session-stop.cjs (which writes cc-done).
    if (isMaterialized(boundId)) {
      try {
        const chDir = path.join(mod.CHANNELS_DIR, boundId);
        fs.writeFileSync(path.join(chDir, 'cc-busy'), new Date().toISOString());
        // entering a new turn clears any stale "done" so the dot is yellow, not green
        try { fs.unlinkSync(path.join(chDir, 'cc-done')); } catch {}
      } catch {}
    }
  }
}

let planInfo = null;
try {
  // Pass session_id so the bound channel (if any) wins over the mtime heuristic.
  planInfo = mod.inspectActivePlan(sessionId);
} catch {}
let snapshot = 'Active plan: (не вдалось прочитати).';
try { snapshot = mod.snapshotLine(planInfo); } catch {}

const blocks = [];

// ── RUNTIME SELF-REPORT (owner decision 2026-07-31) ───────────────────────────────────
// The harness states WHICH model a session runs on, but never its reasoning
// effort, so "який у тебе зараз effort?" was always a guess. The live CLI
// process does carry it in CLAUDE_EFFORT; runner.py strips that var before
// spawning a child engine, so whatever we read here is THIS session's own
// value, never a leaked parent one. Inject it verbatim so the answer is read,
// not inferred from the model name.
const liveEffort = String(process.env.CLAUDE_EFFORT || '').trim();
if (liveEffort) {
  blocks.push([
    "━━ RUNTIME (verified fact, do NOT guess) ━━",
    `Reasoning effort of THIS session: ${liveEffort}  (source: env CLAUDE_EFFORT).`,
    "Asked about your effort / thinking depth → report exactly this value. Never guess it, never derive it from the model name.",
  ].join("\n"));
}

if (boundId) {
  blocks.push([
    "━━ SESSION BINDING: write ALL cards to YOUR channel ━━",
    `THIS Claude Code session is bound to channel ${boundId} ("${boundLabel}").`,
    `Write EVERY card here: CHANNEL=${boundId} (e.g. node tools/viz/chat/render-message.cjs <file.json> 'Claude' '<tag>' ${boundId}).`,
    `Plan updates too: node tools/viz/chat/set-plan.cjs ${boundId} plan.json.`,
    `Direct link to this tab (relay it to the user when relevant): http://localhost:5555/#${boundId}`,
    "Do NOT write into another session's tab. Parallel terminals each own a different channel.",
  ].join("\n"));
}

const planCh = boundId || '<channel>';

// LOUD, deterministic directive when THIS prompt explicitly asks to touch the plan.
// First block so it is impossible to miss.
if (explicitPlanAdd) {
  blocks.push([
    "🚨🚨 USER EXPLICITLY ASKED TO TOUCH THE PLAN THIS TURN. MANDATORY, NO EXCEPTIONS. 🚨🚨",
    `Create or update channels/${planCh}/plan.json NOW, BEFORE you finish this turn. This is a direct instruction: do not skip it, do not defer it, do not "do it later".`,
    "Add/update the exact step(s) the user referred to with the full shape { text, state, goal, substeps, result }, then reconcile the rest of the plan.",
    `Write it: node tools/viz/chat/set-plan.cjs ${planCh} plan.json  (or write channels/${planCh}/plan.json directly). Not updating the plan this turn is a RULE VIOLATION.`,
  ].join("\n"));
}

blocks.push([
  "━━ PLAN TRACKING — RULE #1 (HARD): every Logopsis channel HAS its own plan, USING IT IS NOT OPTIONAL ━━",
  snapshot,
  "BLACK & WHITE for EVERY agent, no matter the task: the channel you work in owns a plan at channels/<channel>/plan.json.",
  "You MUST create or update that plan, THIS TURN before finishing, whenever EITHER holds:",
  "  (a) EXPLICIT: the user asks in ANY words (додай в план / онови план / постав у план / запиши в план / track this / add to plan / put in the plan). Explicit ask = ALWAYS do it, even for a single item.",
  "  (b) PROACTIVE: you recognize the work is 3+ steps OR multi-stage. Create the plan WITHOUT being asked. If you saw steps and did not write them, that is a RULE VIOLATION.",
  "Skip ONLY a pure 1-2 step Q&A with no follow-on steps.",
  "Each turn also reconcile reality: finished steps to done, the in-flight one to progress, new asks become added steps, stuck to blocked (+note).",
  "MANDATORY step shape (self-explanatory after context compaction): { text, state:done|progress|pending|blocked, goal: 'навіщо', substeps: ['дії'], result: 'очікуваний результат', note? }.",
  `Update via: node tools/viz/chat/set-plan.cjs ${planCh} plan.json  (portable; or write channels/${planCh}/plan.json directly). UI repolls every 2s.`,
].join("\n"));

// G3: назви, а не лише рахуй (specs/plan-safety-gates, К5). Null, коли нема що
// показувати (нема плану / нема відкритих замовлених кроків / файл нечитабельний).
try {
  const openStepsBlock = buildOpenStepsBlock(mod.CHANNELS_DIR, planInfo);
  if (openStepsBlock) blocks.push(openStepsBlock);
} catch {}

blocks.push([
  "━━ CHAT VIEW FIRST (all answers are cards, not terminal text) ━━",
  boundId
    ? `1. This session owns channel ${boundId}. Write there (the binding block above wins over topic-tab matching).`
    : "1. Read tools/viz/chat/channels/index.json. Write to the EXISTING topic tab that matches this conversation; never spawn a date/timestamp channel if a topic tab fits.",
  "2. Post the user's message verbatim as a 'Я' bubble, then your answer as a 'Claude' card. Each exchange = 2+ entries.",
  "3. ALL substantive answers go to the Chat View as cards — including short/trivial ones. The terminal gets at most ONE short pointer line at the END (e.g. 'дивись вкладку X'), never duplicated card content.",
  "4. Post a card PORTABLY: node tools/viz/chat/render-message.cjs <file.json> 'Claude' '<tag>' <channel>  — it writes the next NNNN.json AND updates the channel index.json (the UI lists messages from index.json, so a raw file write alone would be invisible). Works on Mac + Windows. Never edit an already-sent file.",
  "If unsure where to write → Chat View card.",
].join("\n"));

// Emit a «Процеси»-panel event so this hook stops being invisible (owner decision 2026-07-08).
try {
  const { emit, channelFor } = require('./_emit.cjs');
  const ch = boundId || channelFor(sessionId);
  emit(ch, { kind: 'hook', name: 'UserPromptSubmit', phase: 'fire',
    detail: explicitPlanAdd ? 'явний запит на план'
          : (String(snapshot).includes('STALE') ? 'план STALE — нагадав'
          : 'контекст + план вставлено') });
} catch {}

process.stdout.write(blocks.join("\n\n") + "\n");

}

// Запускаємось як хук тільки коли нас викликали напряму: require() ззовні (тести)
// бере лише чисті G3-хелпери нижче, без побічного читання stdin/запису stdout.
if (require.main === module) main();

module.exports = {
  MAX_OPEN_STEPS_LISTED,
  MAX_STEP_TEXT_LEN,
  truncateStepText,
  stepOrigin,
  planSteps,
  openOrderedSteps,
  buildOpenStepsBlock,
};
