#!/usr/bin/env node
/**
 * skill-gate.cjs. PreToolUse hook на Skill.
 *
 * ОДНЕ ПРАВИЛО: у чаті з КАПЕЛЮХОМ агента доступні рівно ті помічники, які
 * оголошені в його файлі полем `skills:`. Решта каталогу .claude/skills/ для
 * цього чату не існує.
 *
 * НАВІЩО. Критерій приймання К7 спеки specs/agent-in-chat: «ТАМ ДЕ агент
 * доданий СИСТЕМА МУСИТЬ дати йому рівно ті вміння, які оголошені в його файлі,
 * і не давати решти каталогу». Без цього ментор по вигорянню тримає в руках
 * браузер, платіжку і відеорендер, бо рантайм без явного звуження видає ВЕСЬ
 * набір. Це рівно той баг, який власник спіймав на картці Ленгольд (коміт 5b4e338
 * полагодив ВИГЛЯД картки, а руки лишились повні).
 *
 * ЧОМУ ХУК, А НЕ --disallowedTools. Прапорець вміє імена інструментів, а не
 * окремі скіли всередині одного Skill. Тому:
 *   - персона БЕЗ оголошених skills:  -> runner.channel_disallowed_tools()
 *     викидає весь інструмент Skill, і сюди виклик просто не доходить;
 *   - персона з ЧАСТКОВИМ списком     -> вибірковий allow робить цей хук.
 * Дві половини одного правила, навмисно в різних місцях: перша дешевша і
 * жорсткіша, друга єдина можлива.
 *
 * NO-OP ЗА МЕЖАМИ ЧАТУ. Хук нічого не робить, поки в оточенні нема
 * LOGOPSIS_CHANNEL (його ставить runner._child_env лише ходам, що обслуговують
 * канал). Тобто термінальна сесія людини і фонові агенти містка не зачеплені:
 * там капелюха нема за побудовою.
 *
 * КОНТРАКТ ХУКА (той самий, що в agent-bridge-router.cjs):
 *   stdin : { session_id, cwd, hook_event_name:"PreToolUse", tool_name, tool_input }
 *   блок  : exit 0 + stdout
 *           {"hookSpecificOutput":{"hookEventName":"PreToolUse",
 *             "permissionDecision":"deny","permissionDecisionReason":"..."}}
 *   пропуск: exit 0 + ПОРОЖНІЙ stdout.
 *   Віддаємо РІВНО "deny": він іде В МОДЕЛЬ системним нагадуванням і НЕ показує
 *   людині модалку. "ask" не використовуємо ніде: саме він і був би спливаючим
 *   вікном. "allow" не виводимо НІКОЛИ: то обхід дозволів користувача.
 *
 * FAIL-OPEN. Будь-яка невизначеність (не розібрали імʼя скіла, не прочитали
 * файл агента, зламаний JSON) = тихий пропуск. Краще пропустити виклик, ніж
 * заблокувати роботу назовсім.
 *
 * ЕСКЕЙП (один, для людини, не для моделі):
 *   <repoRoot>/.claude/gates-off   файл-маркер, глушить усі гейти репо.
 *
 * Крос-платформа: чистий node, без .sh, без хардкод-шляхів.
 */
'use strict';

const fs = require('fs');
const path = require('path');

// Дзеркалення імен змінних середовища (CHATVIEW_* <-> LOGOPSIS_*) під час ребренду.
// Мусить стояти вище за перше читання process.env у цьому файлі: у власника
// лишились запущені служби і аліаси зі старими іменами. Контракт: brand-env.cjs.
require("../brand-env.cjs")

/**
 * Корінь репо. CLAUDE_PROJECT_DIR ставить сам харнес; фолбек рахує глибину
 * від цього файлу (tools/viz/chat/hooks/ = чотири рівні вгору).
 */
function repoRoot(env) {
  const e = env || process.env;
  if (e.CLAUDE_PROJECT_DIR) return e.CLAUDE_PROJECT_DIR;
  return path.resolve(__dirname, '..', '..', '..', '..');
}

/**
 * Тека даних чату. У пакованій апці репо нема, і канали лежать у LOGOPSIS_HOME
 * (рівно та сама розвилка, що в runner.DIR), інакше поруч із цим хуком.
 */
function chatHome(env) {
  const e = env || process.env;
  if (e.LOGOPSIS_HOME) return e.LOGOPSIS_HOME;
  return path.resolve(__dirname, '..');
}

/** Слаг капелюха каналу, або '' коли капелюха нема / канал не заданий. */
function channelAgentSlug(env) {
  const e = env || process.env;
  const ch = e.LOGOPSIS_CHANNEL;
  if (!ch || ch.includes('/') || ch.includes('\\') || ch.includes('..')) return '';
  try {
    const s = fs.readFileSync(path.join(chatHome(e), 'channels', ch, 'agent'), 'utf8').trim();
    if (!s || s.includes('/') || s.includes('\\') || s.includes('..')) return '';
    return s;
  } catch { return ''; }
}

/**
 * Оголошені помічники агента: поле `skills:` у фронтматері .claude/agents/<slug>.md.
 * Повертає null, коли файл не читається (fail-open), і [] коли поля просто нема.
 * Та сама форма розбору, що в server._agent_skills і runner.channel_agent.
 */
function declaredSkills(slug, env) {
  let text;
  try {
    text = fs.readFileSync(path.join(repoRoot(env), '.claude', 'agents', slug + '.md'), 'utf8');
  } catch { return null; }
  if (!text.startsWith('---')) return [];
  const end = text.slice(3).indexOf('\n---');
  if (end === -1) return [];
  let raw = '';
  for (const line of text.slice(3, 3 + end).split('\n')) {
    if (!line.trim() || line[0] === ' ' || line[0] === '\t') continue;
    const i = line.indexOf(':');
    if (i === -1) continue;
    if (line.slice(0, i).trim() !== 'skills') continue;
    raw = line.slice(i + 1).trim();
    break;
  }
  if (raw.startsWith('[') && raw.endsWith(']')) raw = raw.slice(1, -1);
  return raw.split(',').map((s) => s.trim().replace(/^["']|["']$/g, '').trim()).filter(Boolean);
}

/**
 * Імʼя скіла з tool_input. Форма інпуту може відрізнятись між версіями CLI, тому
 * пробуємо кілька відомих ключів і НЕ вгадуємо далі: не знайшли рядка — повертаємо
 * '' і пропускаємо виклик, бо здогадка тут коштувала б заблокованого помічника.
 * Плагінний префікс (`plugin:skill`) зрізаємо: дозвіл видається по імені скіла.
 */
function skillName(input) {
  if (!input || typeof input !== 'object') return '';
  for (const k of ['skill', 'name', 'skill_name', 'skillName', 'command']) {
    const v = input[k];
    if (typeof v === 'string' && v.trim()) {
      const s = v.trim().split(':').pop().trim();
      // Аргументи скіла їдуть окремим полем, але слеш-форма («/spec new …») теж
      // трапляється: беремо перше слово і знімаємо провідний слеш.
      return s.replace(/^\//, '').split(/\s+/)[0];
    }
  }
  return '';
}

function gatesOff(env) {
  try { return fs.existsSync(path.join(repoRoot(env), '.claude', 'gates-off')); } catch { return false; }
}

/**
 * Рішення по одному виклику. Чиста функція (усе оточення і payload параметрами),
 * щоб тест не мусив піднімати процес: повертає рядок причини для deny або null
 * на пропуск.
 */
function decide(payload, env) {
  if (gatesOff(env)) return null;
  if (!payload || payload.tool_name !== 'Skill') return null;
  const slug = channelAgentSlug(env);
  if (!slug) return null;                       // чат без капелюха: не наша справа
  const allow = declaredSkills(slug, env);
  if (allow === null) return null;              // не прочитали агента: fail-open
  const want = skillName(payload.tool_input);
  if (!want) return null;                       // не розібрали імʼя: fail-open
  if (allow.some((a) => a.split(':').pop() === want)) return null;
  return allow.length
    ? `У цьому чаті ти ${slug}, і тобі доступні лише помічники: ${allow.join(', ')}. `
      + `Помічник «${want}» не оголошений у твоєму файлі, тому недоступний тут. `
      + `Зроби це самотужки або скажи, що не вмієш.`
    : `У цьому чаті ти ${slug}, і помічників у твоєму файлі не оголошено жодного. `
      + `Помічник «${want}» недоступний. Відповідай самотужки.`;
}

function emit(reason) {
  if (!reason) return;
  process.stdout.write(JSON.stringify({
    hookSpecificOutput: {
      hookEventName: 'PreToolUse',
      permissionDecision: 'deny',
      permissionDecisionReason: reason,
    },
  }));
}

function main() {
  let raw = '';
  process.stdin.setEncoding('utf8');
  process.stdin.on('data', (c) => { raw += c; });
  process.stdin.on('end', () => {
    let reason = null;
    try { reason = decide(JSON.parse(raw || '{}'), process.env); } catch { reason = null; }
    emit(reason);
    process.exit(0);
  });
}

if (require.main === module) main();

module.exports = { decide, skillName, declaredSkills, channelAgentSlug };
