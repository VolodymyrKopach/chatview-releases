'use strict';
/**
 * _scope.cjs. Спільний скоуп файлів для гейтів (proof-gate, edit-gate).
 *
 * НАВІЩО ОКРЕМИЙ МОДУЛЬ: обидва гейти мусять однаково відповідати на питання
 * «це прод-код?» і «це тест?». Дві копії констант розʼїжджаються за тиждень,
 * і гейти починають судити різні множини файлів. Один модуль, одна правда.
 *
 * Винесено з proof-gate.cjs БЕЗ зміни семантики: константи і функції переїхали
 * байт-в-байт. Модуль лежить у тій самій теці (tools/viz/chat/hooks/), тож
 * фолбек repoRoot() рахує ту саму глибину, що й раніше.
 *
 * Крос-платформа: чистий node, без .sh, без шел-глобів, без хардкод-шляхів.
 */

const path = require('path');

// Дзеркалення імен змінних середовища (CHATVIEW_* <-> LOGOPSIS_*) під час ребренду.
// Мусить стояти вище за перше читання process.env у цьому файлі: у власника
// лишились запущені служби і аліаси зі старими іменами. Контракт: brand-env.cjs.
require("../brand-env.cjs")

// ── СКОУП: що вважається прод-файлом ────────────────────────────────────────
// Тільки код. Правити цей список тут, він навмисно плаский і явний.
const PROD_EXTS = ['.py', '.cjs', '.mjs', '.js', '.ts', '.tsx', '.jsx', '.html'];

// Розширення, що НІКОЛИ не вимагають доказу (навіть якби потрапили вище).
const EXCLUDED_EXTS = ['.md', '.txt', '.srt', '.json', '.csv', '.yml', '.yaml'];

// Теки знань і артефактів: правка тексту в них не потребує прогону.
// Матчиться як сегмент шляху (репо-відносного, з фолбеком на абсолютний).
//
// ТУТ ЛИШЕ РОДОВІ ІМЕНА. Раніше в списку сиділи ще дві теки, названі іменами живих
// людей, тобто конфігурація ОДНІЄЇ робочої копії, вшита в код гейта: у чужій
// установці таких тек не існує взагалі, а власник не мав як назвати свої, крім як
// правкою цього файлу. Особисті теки тепер приходять змінною оточення, а механізм
// лишився той самий: перший сегмент шляху збігся зі списком означає «доказу не треба».
const EXCLUDED_TOP_DIRS_BUILTIN = [
  'research', 'decisions', 'deliverables', 'memory',
  'contacts', 'projects', 'processes',
];

// Особисті теки знань ЦІЄЇ копії репозиторію, через кому.
// Приклад: LOGOPSIS_SCOPE_DIRS="anna,bohdan".
const SCOPE_DIRS_ENV = 'LOGOPSIS_SCOPE_DIRS';

function extraTopDirs(env) {
  const raw = String(((env || process.env)[SCOPE_DIRS_ENV]) || '');
  return raw.split(',').map((s) => s.trim().toLowerCase()).filter(Boolean);
}

const EXCLUDED_TOP_DIRS = EXCLUDED_TOP_DIRS_BUILTIN.concat(extraTopDirs());

// Інфраструктурний і рантайм-мотлох: ніколи не наш прод-код.
// Матчиться на ТЕКИ шляху (не на імʼя файлу: _emit.cjs це живий код).
const EXCLUDED_ANY_SEGMENTS = [
  'node_modules', 'dist', 'build', 'out', '__pycache__', '.git', 'work',
  'channels', 'worktrees', '.agentwork', 'voice-cache', 'venv', 'site-packages',
];

// Теки-варіації білд-виводу і скретчу: _v2-dist, dist-electron, .next, _tmp_edit.
const EXCLUDED_DIR_PATTERNS = [
  /(^|[-_.])dist([-_.]|$)/,
  /(^|[-_.])build([-_.]|$)/,
  /^_/,        // скретч-теки репо: _tmp_edit, _previews, _responsive
  /^\./,       // приховані: .next, .venv, .claude
];

// Самі тести доказу не вимагають (вони і є доказ).
const TEST_PATH_MARKERS = ['/tests/', '/test/'];
const TEST_NAME_RE = /^test_|\.test\.|_test\./;

// Конвенція імен тестів. Джерело правди: scripts/run-tests.cjs
//   MJS_RE = /^(test_.*\.mjs|.*\.test\.mjs)$/
//   PY_RE  = /^(test_.*\.py|.*_test\.py)$/
// Тут вона зведена в один патерн на базове імʼя файлу.
const TEST_FILE_NAME_RE = /^(test_.*\.(mjs|py)|.*\.test\.mjs|.*_test\.py)$/;

// ── утиліти ─────────────────────────────────────────────────────────────────

function repoRoot() {
  if (process.env.CLAUDE_PROJECT_DIR) return process.env.CLAUDE_PROJECT_DIR;
  return path.resolve(__dirname, '..', '..', '..', '..');
}

function norm(p) {
  return String(p || '').replace(/\\/g, '/');
}

/** Репо-відносний шлях, якщо файл під cwd або під коренем репо; інакше абсолютний. */
function toRel(filePath, cwd) {
  const f = norm(filePath);
  if (!f) return '';
  for (const base of [cwd, repoRoot()]) {
    const c = norm(base).replace(/\/+$/, '');
    if (c && f.toLowerCase().startsWith(c.toLowerCase() + '/')) return f.slice(c.length + 1);
  }
  return f;
}

/** true = правка цього файлу вимагає доказу. */
function isProdFile(filePath, cwd) {
  const rel = toRel(filePath, cwd);
  if (!rel) return false;
  const lower = rel.toLowerCase();
  const ext = path.posix.extname(lower);
  const base = path.posix.basename(lower);

  if (EXCLUDED_EXTS.includes(ext)) return false;
  if (!PROD_EXTS.includes(ext)) return false;

  const segs = lower.split('/').filter(Boolean);
  if (EXCLUDED_TOP_DIRS.includes(segs[0])) return false;
  const dirSegs = segs.slice(0, -1);            // імʼя файлу тут не судимо
  for (const s of dirSegs) {
    if (EXCLUDED_ANY_SEGMENTS.includes(s)) return false;
    if (EXCLUDED_DIR_PATTERNS.some((re) => re.test(s))) return false;
  }

  const padded = '/' + lower + '/';
  for (const m of TEST_PATH_MARKERS) if (padded.includes(m)) return false;
  if (TEST_NAME_RE.test(base)) return false;

  return true;
}

/**
 * true = це тест-файл.
 *
 * Ширше за isProdFile-виняток навмисно: сюди потрапляє і файл за конвенцією імен
 * (test_x.mjs, x.test.mjs, x_test.py), і будь-що всередині теки tests/ чи test/.
 * Друга половина потрібна, бо хелпери й фікстури поруч із тестами теж не можна
 * тихо послаблювати.
 */
function isTestFile(filePath, cwd) {
  const rel = toRel(filePath, cwd);
  if (!rel) return false;
  const lower = rel.toLowerCase();
  const base = path.posix.basename(lower);

  if (TEST_FILE_NAME_RE.test(base)) return true;

  const segs = lower.split('/').filter(Boolean);
  const dirSegs = segs.slice(0, -1);            // тека tests/, не файл на імʼя tests
  return dirSegs.includes('tests') || dirSegs.includes('test');
}

module.exports = {
  PROD_EXTS,
  EXCLUDED_EXTS,
  EXCLUDED_TOP_DIRS_BUILTIN,
  EXCLUDED_TOP_DIRS,
  SCOPE_DIRS_ENV,
  extraTopDirs,
  EXCLUDED_ANY_SEGMENTS,
  EXCLUDED_DIR_PATTERNS,
  TEST_PATH_MARKERS,
  TEST_NAME_RE,
  TEST_FILE_NAME_RE,
  repoRoot,
  norm,
  toRel,
  isProdFile,
  isTestFile,
};
