#!/usr/bin/env node
/**
 * truth-gate.cjs — Stop hook. Гейт правди (specs/plan-safety-gates/spec.md, G2).
 *
 * ПРИВІД. У цій же розмові прозвучало «готово» чотири рази поспіль, а в плані
 * каналу лишались відкриті ЗАМОВЛЕНІ кроки. Ніщо в системі цього не помітило,
 * бо ніхто не звіряв те, що модель КАЖЕ, з тим, що в плані ЛЕЖИТЬ. Власник:
 * «ти розумієш, що це юзера водить в оману?». proof-gate.cjs вже довів, що
 * прохання можна перетворити на гейт у цьому коді — тут той самий патерн,
 * застосований до розбіжності слова і плану, а не слова і доказу.
 *
 * ЛОГІКА: якщо відповідь стверджує завершеність роботи (розпізнає G1,
 * _completion-claim.cjs, як є, без власних евристик поверх) І в плані
 * активного каналу лишились відкриті ЗАМОВЛЕНІ кроки (origin ordered, не
 * proposed) — Stop блокується, а в поясненні кроки названі поіменно (К2).
 *
 * НАЙВАЖЛИВІША МЕЖА (спека, головний ризик): гейт карає НЕ за відкриті кроки,
 * а за твердження, що їх немає. Чесний «зроблено це, лишилось те» проходить
 * вільно (К4), бо PARTIAL/NEGATION-патерни G1 перевіряються першими і
 * перекривають навіть сусіднє «все готово». Пропозиції (origin: proposed)
 * НІКОЛИ не блокують: вони не зобовʼязання.
 *
 * ЯК ЗНАХОДИМО АКТИВНИЙ КАНАЛ І ЙОГО ВІДКРИТІ КРОКИ: через plan-state.cjs
 * (inspectActivePlan, той самий спосіб, що й інші хуки) і chat-view-reminder.cjs
 * (buildOpenStepsBlock — вже написана й протестована G3-функція, що читає
 * plan.json, фільтрує origin=ordered/state!=done і форматує поіменний перелік
 * з лімітом і чесним «і ще N»). Обидва лише REQUIRE-яться, жоден не
 * редагується (межа сабтаска): чиста композиція вже готових цеглинок.
 *
 * ЧОМУ decide() — ОКРЕМА ЧИСТА ФУНКЦІЯ, А НЕ ЛОГІКА ВСЕРЕДИНІ main(): щоб
 * юніти могли підставити tmp channelsDir і рукописний planInfo, не чіпаючи
 * ЖИВУ tools/viz/chat/channels — той самий прийом, що вже застосований у
 * chat-view-reminder.cjs (buildOpenStepsBlock навмисно приймає channelsDir
 * параметром, CHANNELS_DIR у plan-state.cjs НЕ перемикається через env).
 *
 * ЗАПОБІЖНИК (К8, spec.md розділ 4 «головний ризик»): виняток УСЕРЕДИНІ
 * decide() — ловиться в самій decide() і повертає 'pass'. Виняток із виклику
 * planState.inspectActivePlan(sessionId) (він читає диск і теоретично може
 * впасти на кутовому випадку, який ця задача не чіпає й не лагодить) —
 * ловиться окремо в main(). Плюс третій, найзовнішній пояс на самому виклику
 * main(), як і в proof-gate.cjs. Гейт, що ламається, не сміє паралізувати
 * роботу назавжди: пропуск ходу завжди дешевший за вічний блок.
 *
 * КОНТРАКТ ХУКА (той самий, що proof-gate.cjs і promise-gate.cjs):
 *   stdin  : { session_id, transcript_path, hook_event_name:"Stop",
 *              stop_hook_active, last_assistant_message, ... }
 *   вихід  : блок = exit 0 + stdout {"decision":"block","reason":"..."}.
 *            пропуск = exit 0 + порожній stdout.
 *   loop   : stop_hook_active === true → миттєвий пропуск (Stop уже блокував).
 *
 * ЕСКЕЙП: TRUTH_GATE=off повністю вимикає хук — той самий кілл-свіч, що
 * PROOF_GATE=off / PROMISE_GATE=off у сусідніх Stop-хуках цього ж файлу подій.
 *
 * ЛІЧИЛЬНИК: .claude/gates.jsonl, тег gate:"truth-gate" — той самий файл, що
 * proof-gate і promise-gate, щоб наприкінці тижня рахунок гейтів був в одному місці.
 *
 * Крос-платформа: чистий node, без .sh, без шел-глобів, без хардкод-шляхів.
 */
'use strict';

const fs = require('fs');
const path = require('path');

const { claimsCompletion } = require('./_completion-claim.cjs');
const planState = require('./plan-state.cjs');
const { buildOpenStepsBlock } = require('./chat-view-reminder.cjs');

function logPath() {
  if (process.env.TRUTH_GATE_LOG) return process.env.TRUTH_GATE_LOG;
  const { repoRoot } = require('./_scope.cjs');
  return path.join(repoRoot(), '.claude', 'gates.jsonl');
}

/** Лічильник. Сам ніколи не кидає (той самий принцип, що у proof-gate.cjs). */
function record(entry) {
  try {
    const p = logPath();
    fs.mkdirSync(path.dirname(p), { recursive: true });
    const line = JSON.stringify(Object.assign({ ts: new Date().toISOString(), gate: 'truth-gate' }, entry));
    fs.appendFileSync(p, line + '\n');
  } catch { /* лічильник не сміє ламати гейт */ }
}

/** Останнє повідомлення асистента: напряму зі stdin, інакше з хвоста транскрипту.
 *  Той самий прийом, що promise-gate.cjs:assistantText, свідомо не імпортований
 *  звідти (require() sibling-Stop-хука виконав би його побічний stdin-читач). */
function assistantText(input) {
  const direct = input && input.last_assistant_message;
  if (typeof direct === 'string' && direct.trim()) return direct;
  const tp = input && input.transcript_path;
  if (!tp) return '';
  let lines = [];
  try {
    lines = fs.readFileSync(tp, 'utf8').split('\n').filter(Boolean);
  } catch {
    return '';
  }
  for (let i = lines.length - 1; i >= 0 && i > lines.length - 60; i -= 1) {
    let row = null;
    try { row = JSON.parse(lines[i]); } catch { continue; }
    const msg = row && row.message;
    if (!msg || msg.role !== 'assistant') continue;
    const content = Array.isArray(msg.content) ? msg.content : [];
    const text = content.filter((c) => c && c.type === 'text').map((c) => c.text).join('\n');
    if (text.trim()) return text;
  }
  return '';
}

function buildReason(openBlock) {
  return [
    'СТОП, гейт правди (truth-gate).',
    '',
    'У відповіді звучить твердження про завершеність роботи, а в плані активного',
    'каналу лишились відкриті ЗАМОВЛЕНІ кроки (origin ordered, не done). Гейт карає',
    'не за відкриті кроки, а за твердження, що їх немає (specs/plan-safety-gates/spec.md, К1).',
    '',
    openBlock,
    '',
    'Два законні виходи, обидва без обману:',
    '  1. переформулюй відповідь чесно — "зроблено це, лишилось те" гейт пропускає вільно;',
    '  2. якщо кроки справді закриті, онови план ПЕРЕД тим як звітувати про завершеність.',
  ].join('\n');
}

/**
 * Чиста функція рішення: текст відповіді + де шукати план → блок чи пропуск.
 * Жодного читання stdin, жодного запису stdout — саме тому вона тестується
 * напряму з tmp channelsDir і рукописним planInfo, без live tools/viz/chat/channels.
 *
 * @param {string} text текст відповіді асистента
 * @param {string} channelsDir тека каналів (у проді — planState.CHANNELS_DIR)
 * @param {?object} planInfo знімок активного плану (форма inspectActivePlan) або null
 * @returns {{decision:'block'|'pass', reason?:string, why?:string, error?:string}}
 */
function decide(text, channelsDir, planInfo) {
  if (!text || !text.trim()) return { decision: 'pass', why: 'no-text' };
  try {
    if (!claimsCompletion(text)) return { decision: 'pass', why: 'no-completion-claim' };
    if (!planInfo || planInfo.noPlan) return { decision: 'pass', why: 'no-plan' };

    const openBlock = buildOpenStepsBlock(channelsDir, planInfo);
    if (!openBlock) return { decision: 'pass', why: 'no-open-ordered-steps' };

    return { decision: 'block', reason: buildReason(openBlock) };
  } catch (e) {
    // ЗАПОБІЖНИК (К8): будь-яка внутрішня помилка тут = пропуск, ніколи блок.
    return { decision: 'pass', why: 'error', error: String((e && e.message) || e).slice(0, 200) };
  }
}

function main() {
  let input = {};
  try { input = JSON.parse(fs.readFileSync(0, 'utf8')); } catch { input = {}; }

  // 1. АНТИ-ЦИКЛ. Найперше і без жодної роботи.
  if (input && input.stop_hook_active === true) {
    record({ decision: 'skip', why: 'stop_hook_active' });
    return 0;
  }

  // 2. ЕСКЕЙП через оточення.
  const off = String(process.env.TRUTH_GATE || '').toLowerCase();
  if (off === 'off' || off === '0' || off === 'false') {
    record({ decision: 'skip', why: 'env-off' });
    return 0;
  }

  const text = assistantText(input);
  const sessionId = input && input.session_id ? String(input.session_id) : '';

  // Активний канал і його план: окремий пояс запобіжника (К8), бо
  // inspectActivePlan читає диск (живий тека каналів) поза decide().
  let planInfo = null;
  try {
    planInfo = planState.inspectActivePlan(sessionId);
  } catch (e) {
    record({
      decision: 'error',
      why: 'inspect-active-plan-threw: ' + String((e && e.message) || e).slice(0, 200),
      session_id: sessionId,
    });
    return 0; // fail-open (К8): запобіжник не блокує роботу назавжди
  }

  const result = decide(text, planState.CHANNELS_DIR, planInfo);

  if (result.decision === 'block') {
    record({ decision: 'block', channel: (planInfo && planInfo.id) || '', session_id: sessionId });
    process.stdout.write(JSON.stringify({ decision: 'block', reason: result.reason }));
    return 0;
  }

  record(Object.assign(
    { decision: result.why === 'error' ? 'error' : 'pass', why: result.why, session_id: sessionId },
    result.error ? { error: result.error } : null,
  ));
  return 0;
}

module.exports = { decide, buildReason, assistantText };

// Запускаємось як хук тільки коли нас викликали напряму: require() ззовні
// (тести) бере лише чисті функції вище, без побічного читання stdin/stdout.
if (require.main === module) {
  let code = 0;
  try {
    code = main();
  } catch {
    code = 0; // FAIL-OPEN, найзовнішній пояс, як у proof-gate.cjs
  }
  process.exit(code);
}
