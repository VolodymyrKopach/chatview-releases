#!/usr/bin/env node
// plan-commit-close.cjs — PostToolUse hook (specs/plan-autosync-signals/spec.md, B3).
// Closes a plan step's `closeOn: {type:"commit", match:"..."}` condition when a
// commit whose message actually contains `match` really lands in git history.
//
// ARCHITECTURE (already decided, do not re-derive): the signal is the FACT that
// HEAD moved, never the text of the command that ran. A `git commit -m "..."`
// invocation can be executed and still fail to produce a commit (nothing staged,
// a pre-commit hook rejects it, ...) — trusting the command text would close a
// step that never actually happened, which is exactly the lie this feature exists
// to prevent (spec.md risk section). So this hook never inspects tool_input at
// all beyond `cwd`/`session_id`: it asks git directly whether HEAD is different
// from what it saw last time, and only then reads what actually landed.
//
// K7 (cheap by construction): `git rev-parse HEAD` is the ONLY git call made when
// nothing changed since the last invocation. `git log` (reading commit messages)
// runs ONLY once HEAD is observed to differ from the persisted baseline.
//
// STATE: like plan-ping.cjs's action counter, the last-seen HEAD is kept in a
// per-repo file under os.tmpdir() (keyed by a hash of `cwd`), never in the repo
// and never in a channel. On the very first invocation for a given cwd there is
// no "last time" to compare against, so this hook does the safe thing: it just
// records the current HEAD as the baseline and closes nothing. Nothing is lost —
// the very next tool call after a real new commit will see HEAD differ from that
// baseline and process it normally.
//
// PLAN ACCESS: this hook is node, plan_autopatch.py is python, and it is NOT to
// be edited (spec.md B3 scope). Its public `find_steps_by_close_condition` is the
// ONE place the `closeOn` format is decided (plan_autopatch.py:137-158) — this
// file calls it via a `python3 -c` one-liner instead of re-declaring the format
// in JS, and marks a hit through the module's own CLI entry point
// (`plan_autopatch.py <channel> <step_id> <state>`), so every write still goes
// through mark_step -> plan_store.write_plan exactly like every other caller.
//
// K9: every step of "did HEAD change -> read commits -> find matches -> mark" is
// wrapped so a failure anywhere (git missing, python missing, a step id typo, an
// unwritable plan) is logged and swallowed. This hook must never block the tool
// result it rides on and must never throw past its own process boundary.

'use strict';

const fs = require('fs');
const os = require('os');
const path = require('path');
const crypto = require('crypto');
const { execFileSync } = require('child_process');

const CHAT_DIR = path.resolve(__dirname, '..');            // tools/viz/chat
const PLAN_AUTOPATCH_PY = path.join(CHAT_DIR, 'plan_autopatch.py');
const CLOSE_TYPE_COMMIT = 'commit';

const GIT_TIMEOUT_MS = 800;
const PY_TIMEOUT_MS = 5000;
const NUL = String.fromCharCode(0);   // commit messages never contain it, unlike whitespace

// ── stdin / state file (mirrors plan-ping.cjs) ──────────────────────────────

function readInput() {
  try { return JSON.parse(fs.readFileSync(0, 'utf8')); } catch { return {}; }
}

function stateFilePath(cwd) {
  const key = crypto.createHash('md5').update(String(cwd || '')).digest('hex').slice(0, 10);
  return path.join(os.tmpdir(), `cv-plan-commit-close-${key}.json`);
}

function loadState(stateFile) {
  try { return JSON.parse(fs.readFileSync(stateFile, 'utf8')); } catch { return {}; }
}

function saveState(stateFile, state) {
  try { fs.writeFileSync(stateFile, JSON.stringify(state)); } catch { /* best-effort */ }
}

// ── git (the one thing that MUST be cheap when HEAD did not move) ──────────

function defaultGit(args, cwd) {
  return execFileSync('git', args, {
    cwd, encoding: 'utf8', timeout: GIT_TIMEOUT_MS, stdio: ['ignore', 'pipe', 'ignore'],
  });
}

function currentHead(git, cwd) {
  try { return String(git(['rev-parse', 'HEAD'], cwd)).trim() || null; } catch { return null; }
}

// Commit messages strictly after `fromSha`, up to and including `toSha`, oldest
// first. Falls back to just `toSha`'s own message when the range itself cannot
// be resolved (unknown/rewritten `fromSha`) — never throws.
function newCommitMessages(git, cwd, fromSha, toSha) {
  if (fromSha) {
    try {
      const out = git(['log', '--reverse', '--format=%B%x00', `${fromSha}..${toSha}`], cwd);
      const msgs = String(out).split(NUL).map((s) => s.trim()).filter(Boolean);
      if (msgs.length) return msgs;
    } catch { /* fromSha unusable (rewritten history, unknown ref, ...) */ }
  }
  try {
    const out = git(['log', '-1', '--format=%B', toSha], cwd);
    const msg = String(out).trim();
    return msg ? [msg] : [];
  } catch { return []; }
}

// ── plan_autopatch bridge (python) — used exactly as documented, never edited ─

const FIND_SCRIPT = [
  'import sys, json',
  `sys.path.insert(0, ${JSON.stringify(CHAT_DIR)})`,
  'import plan_autopatch as pa',
  'found = pa.find_steps_by_close_condition(sys.argv[1], sys.argv[2], sys.argv[3])',
  'print(json.dumps([s["id"] for s in found]))',
].join('\n');

function defaultFindSteps(channel, closeType, text) {
  const out = execFileSync('python3', ['-c', FIND_SCRIPT, channel, closeType, text], {
    cwd: CHAT_DIR, encoding: 'utf8', timeout: PY_TIMEOUT_MS,
  });
  const parsed = JSON.parse(out);
  return Array.isArray(parsed) ? parsed : [];
}

function defaultMarkStep(channel, stepId, state) {
  execFileSync('python3', [PLAN_AUTOPATCH_PY, channel, stepId, state], {
    cwd: CHAT_DIR, encoding: 'utf8', timeout: PY_TIMEOUT_MS,
  });
}

// ── logging (K9: a swallowed exception must still leave a trace) ───────────

function logError(channel, detail) {
  try {
    const { emit } = require('./_emit.cjs');
    if (channel) {
      emit(channel, { kind: 'hook', name: 'plan-commit-close', phase: 'error', detail: String(detail).slice(0, 300) });
      return;
    }
  } catch { /* fall through to stderr */ }
  try { process.stderr.write(`plan-commit-close: ${detail}\n`); } catch { /* nothing left to do */ }
}

// ── core, injectable for tests ──────────────────────────────────────────────

/**
 * Runs one check-and-close pass. Never throws: every externally-fallible step
 * (git, python) is caught individually so one bad commit message or one bad
 * step id cannot stop the rest of a batch from being processed (K9).
 */
function run({
  cwd,
  channel,
  git = defaultGit,
  findSteps = defaultFindSteps,
  markStep = defaultMarkStep,
  stateFile = stateFilePath(cwd),
} = {}) {
  if (!channel) return;

  const head = currentHead(git, cwd);
  if (!head) return;                     // not a git repo (or git unavailable): nothing to do

  const state = loadState(stateFile);
  const prevHead = state.head || null;

  if (prevHead === head) return;         // K7: unchanged HEAD -> stop here, no git log at all

  // No baseline yet (first-ever run for this cwd): establish it, close nothing.
  // The next real commit will be seen as a change against THIS baseline.
  if (!prevHead) {
    saveState(stateFile, { head });
    return;
  }

  let messages = [];
  try {
    messages = newCommitMessages(git, cwd, prevHead, head);
  } catch (e) {
    logError(channel, `git log failed: ${(e && e.message) || e}`);
    messages = [];
  }

  for (const message of messages) {
    let stepIds = [];
    try {
      stepIds = findSteps(channel, CLOSE_TYPE_COMMIT, message);
    } catch (e) {
      logError(channel, `find_steps_by_close_condition failed: ${(e && e.message) || e}`);
      continue;
    }
    for (const stepId of stepIds) {
      try {
        markStep(channel, stepId, 'done');
      } catch (e) {
        logError(channel, `mark_step(${stepId}) failed: ${(e && e.message) || e}`);
      }
    }
  }

  saveState(stateFile, { head });
}

// ── CLI entry point ──────────────────────────────────────────────────────────

function main() {
  const input = readInput();
  const sessionId = input && input.session_id ? String(input.session_id) : '';
  const cwd = (input && input.cwd) || process.cwd();

  let channel = null;
  try { channel = require('./plan-state.cjs').boundChannel(sessionId); } catch { /* no binding */ }

  try {
    run({ cwd, channel });
  } catch (e) {
    logError(channel, `unexpected: ${(e && e.message) || e}`);
  }
}

if (require.main === module) {
  try { main(); } catch { /* K9: never throw past the hook's own process */ }
  process.exit(0);
}

module.exports = { run, currentHead, newCommitMessages, stateFilePath, defaultGit, defaultFindSteps, defaultMarkStep };
