#!/usr/bin/env node
/**
 * PreToolUse permission gate (Phase B of "Logopsis as single front-end").
 *
 * Injected per-warm-spawn via:  claude --settings '{"hooks":{"PreToolUse":[{
 *   "matcher":"Bash|Edit|Write|MultiEdit|NotebookEdit|mcp__.*",
 *   "hooks":[{"type":"command","command":"node <this>","timeout":3600}]}]}}'
 *
 * Flow: read the tool call on stdin -> if already allowed for this session,
 * return allow instantly -> else POST a permission request to the chat server,
 * which surfaces an Allow/Deny card in the channel, and POLL until the human
 * decides (or a long timeout). Emit the PreToolUse allow/deny JSON.
 *
 * Channel + server port come from env set by the warm spawn:
 *   CHAT_PERM_CHANNEL, CHAT_PERM_PORT (default 5555).
 * Contract verified against Claude Code v2.1+: output
 *   {"hookSpecificOutput":{"hookEventName":"PreToolUse","permissionDecision":
 *    "allow"|"deny","permissionDecisionReason":"..."}}  exit 0.
 * FAIL-OPEN: on any internal error we allow (never wedge the assistant); the
 * gate is a convenience/safety layer, not a hard sandbox.
 *
 * ВИНЯТОК З FAIL-OPEN: НЕЗВОРОТНА ДІЯ (К8 спеки specs/no-terminal-for-user).
 * `_irreversible.cjs` каже, чи дію можна відкотити. Незворотна (видалення,
 * права адміністратора, публікація назовні, знесення пакета, зміни поза текою
 * застосунку) вимагає ОКРЕМОГО підтвердження, відмінного від звичайного
 * дозволу: її не покриває ні авто-дозвіл каналу, ні «дозволити для сесії», і
 * після звичайного дозволу зʼявляється друга картка, де сказано, що відкотити
 * не вийде. На цій гілці все, що зазвичай дає allow (сервер недоступний,
 * таймаут, помилка класифікатора), дає DENY. Це навмисно протилежно решті
 * файла: зайве питання коштує людині кліку, пропущене видалення коштує файлів.
 */
const fs = require('fs');
const path = require('path');
const http = require('http');
const crypto = require('crypto');

function out(decision, reason, updatedInput) {
  const hso = { hookEventName: 'PreToolUse', permissionDecision: decision };
  if (reason) hso.permissionDecisionReason = reason;
  if (updatedInput) hso.updatedInput = updatedInput;
  process.stdout.write(JSON.stringify({ hookSpecificOutput: hso }));
  process.exit(0);
}

function readStdin() {
  try { return fs.readFileSync(0, 'utf8'); } catch (_) { return ''; }
}

function req(method, urlPath, body) {
  return new Promise((resolve) => {
    const data = body ? Buffer.from(JSON.stringify(body)) : null;
    const r = http.request({
      host: '127.0.0.1', port: PORT, path: urlPath, method,
      headers: data ? { 'Content-Type': 'application/json', 'Content-Length': data.length } : {},
      timeout: 8000,
    }, (res) => {
      let b = ''; res.on('data', (d) => b += d);
      res.on('end', () => { try { resolve(JSON.parse(b || '{}')); } catch (_) { resolve({}); } });
    });
    r.on('error', () => resolve(null));
    r.on('timeout', () => { r.destroy(); resolve(null); });
    if (data) r.write(data);
    r.end();
  });
}

const PORT = parseInt(process.env.CHAT_PERM_PORT || '5555', 10);
const CHANNEL = process.env.CHAT_PERM_CHANNEL || '';
const CHANNELS_DIR = path.resolve(__dirname, '..', 'channels');
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

// ── К8: незворотне ──────────────────────────────────────────────────────────
// Модуль вантажимо в try: якщо його нема або він зламаний, класифікатор мовчки
// не зникає, а ВСЕ стає незворотним (див. failsafe нижче). Дірка «класифікатор
// відвалився -> гейт знову пропускає видалення» саме так і виглядала б.
let IRREV = null;
try { IRREV = require('./_irreversible.cjs'); } catch (_) { IRREV = null; }

// Виставляється одразу після класифікації і потрібен аварійному catch у кінці
// файла: він мусить знати, fail-open зараз доречний чи fail-closed.
let IRREVERSIBLE_CALL = false;

const failsafe = (match) => ({
  irreversible: true, known: false, match,
  reason: 'Застосунок не зміг перевірити, чи цю дію можна відкотити, тому питає окремо.',
});

function classifyCall(ev) {
  if (!IRREV || typeof IRREV.classify !== 'function') return failsafe('класифікатор недоступний');
  try {
    const v = IRREV.classify({ tool_name: ev.tool_name, tool_input: ev.tool_input }, process.env);
    if (!v || typeof v.irreversible !== 'boolean') return failsafe('порожній вердикт');
    return v;
  } catch (_) {
    return failsafe('виняток у класифікаторі');
  }
}

// Журнал тихих дій (S2 спеки specs/quiet-permissions). Пишемо РІВНО перед тим,
// як віддати тихий allow на дію, яка раніше зупинила б людину питанням. Виклик у
// try, бо жодна проблема журналу не сміє коштувати зупиненого ходу.
function journal(ev, verdict) {
  try {
    if (!verdict || !verdict.journal) return;
    require('./_actions.cjs').record(CHANNEL, verdict.journal, {
      tool: ev.tool_name || '',
      raw: describeCall(ev),
    });
  } catch (_) { /* слід загубився, хід живий */ }
}

// Що саме людина побачить у картці підтвердження (команда або шлях).
function describeCall(ev) {
  try {
    if (IRREV && typeof IRREV.describe === 'function') return IRREV.describe(ev);
  } catch (_) { /* нижче фолбек */ }
  const i = ev.tool_input || {};
  return String(i.command || i.file_path || i.notebook_path || ev.tool_name || '');
}

/** Show one card and wait for the human. Returns 'allow'|'session'|'deny' or
 *  null when nobody answered (server down / timeout). The CALLER decides what
 *  null means: fail-open for an ordinary call, fail-closed for an irreversible one. */
async function ask(payload, logLabel) {
  const requestId = crypto.randomBytes(8).toString('hex');
  const posted = await req('POST', '/api/perm-request', Object.assign({
    channel: CHANNEL, requestId,
  }, payload));
  if (!posted || posted.ok !== true) return null;

  // «Процеси» panel: a real approval card was surfaced (the interesting case; the
  // auto-allow fast path never logs, so no flood). Owner decision 2026-07-08.
  try { require('./_emit.cjs').emit(CHANNEL, { kind: 'hook', name: 'PreToolUse (дозвіл)', phase: 'fire', detail: logLabel }); } catch {}

  // Poll for the human decision. Long budget (hook timeout is 3600s); we cap our
  // own poll a touch under that.
  const deadline = Date.now() + 3300 * 1000;
  while (Date.now() < deadline) {
    await sleep(700);
    const st = await req('GET', `/api/perm-status?requestId=${requestId}`, null);
    if (!st) continue;
    const dec = st.decision;
    if (!dec || dec === 'pending') continue;
    if (dec === 'deny') return 'deny';
    if (dec === 'session') return 'session';
    return 'allow';                       // 'allow' (once) or anything affirmative
  }
  return null;
}

(async () => {
  let ev = {};
  try { ev = JSON.parse(readStdin() || '{}'); } catch (_) { ev = {}; }
  const tool = ev.tool_name || '';
  const input = ev.tool_input || {};

  // К8. Рахуємо ПЕРШИМ ділом: від цього залежить, чи взагалі діють швидкі шляхи нижче.
  const verdict = classifyCall(ev);
  const irreversible = verdict.irreversible === true;
  IRREVERSIBLE_CALL = irreversible;   // щоб і аварійний catch унизу знав, чим ризикує

  // No channel context (shouldn't happen on a warm spawn) -> fail open.
  // Для незворотного навпаки: нема каналу = нема де показати підтвердження,
  // а мовчки видаляти файли лише тому, що інтерфейсу не видно, не можна.
  if (!CHANNEL) {
    if (irreversible) out('deny', `Незворотна дія без підтвердження. ${verdict.reason}`);
    out('allow', 'no channel context');
  }

  // Session allow-list: tools the user already approved "for session".
  // Незворотне сюди не потрапляє НІКОЛИ: «дозволено для сесії» це звичайний
  // дозвіл, а К8 вимагає окремого, тому один клік не сміє відкривати шлях усім
  // наступним видаленням.
  const allowPath = path.join(CHANNELS_DIR, CHANNEL, 'perm-allow.json');
  let sessionAllowed = false;
  try {
    if (fs.existsSync(allowPath)) {
      const allowed = JSON.parse(fs.readFileSync(allowPath, 'utf8'));
      sessionAllowed = Array.isArray(allowed) && allowed.includes(tool);
    }
  } catch (_) { /* ignore */ }
  if (sessionAllowed && !irreversible) { journal(ev, verdict); out('allow', 'allowed for session'); }

  // Per-channel auto-approve. DEFAULT ON: Logopsis should behave like the Claude
  // Code extension (the owner set bypass there) = 0 prompts. Gated review is OPT-IN:
  // only when channels/<id>/perm-auto is explicitly 0/false/no/off do we surface
  // the approval card. Absent file or truthy => allow instantly (no card, no poll).
  // Null-safe: any error -> allow (consistent with the fail-open gate philosophy).
  // Незворотне цей швидкий шлях не покриває: інакше К8 був би недосяжним, бо за
  // замовчуванням авто-дозвіл пропускає геть усе.
  let autoOk = false;
  let autoReason = 'auto-approve (default-on)';
  try {
    const autoPath = path.join(CHANNELS_DIR, CHANNEL, 'perm-auto');
    let gate = false;
    if (fs.existsSync(autoPath)) {
      const v = fs.readFileSync(autoPath, 'utf8').trim().toLowerCase();
      gate = ['0', 'false', 'no', 'off'].includes(v);
    }
    autoOk = !gate;
  } catch (_) { autoOk = true; autoReason = 'auto-approve (default-on, fail-open)'; }
  if (autoOk && !irreversible) { journal(ev, verdict); out('allow', autoReason); }

  // ── Незворотна дія: окреме підтвердження ─────────────────────────────────
  if (irreversible) {
    // Звичайний дозвіл (перша картка) потрібен лише там, де канал взагалі питає.
    // Там, де він уже сказав «не питай на звичайні дії», ми не мучимо людину
    // зайвим кліком, а показуємо рівно одну картку, якої не було раніше:
    // підтвердження незворотності.
    if (!(sessionAllowed || autoOk)) {
      const first = await ask({
        tool, input, toolUseId: ev.tool_use_id || '', irreversible: true, stage: 'normal',
      }, `запит дозволу: ${tool}`);
      if (first !== 'allow' && first !== 'session') {
        out('deny', first === 'deny'
          ? 'Відхилено користувачем у Logopsis'
          : `Незворотна дія без підтвердження. ${verdict.reason}`);
      }
      // Навіть 'session' тут НЕ пишемо в perm-allow.json: див. коментар вище.
    }

    const second = await ask({
      tool: 'Незворотна дія',
      input: {
        'що станеться': verdict.reason,
        'відкотити': 'Не вийде. Це окреме підтвердження, а не звичайний дозвіл.',
        'команда': describeCall(ev),
      },
      toolUseId: ev.tool_use_id || '',
      irreversible: true,
      stage: 'confirm',
      realTool: tool,
      realInput: input,
      match: verdict.match || '',
      known: verdict.known === true,
    }, `підтвердження незворотної дії: ${tool}`);

    if (second === 'allow' || second === 'session') {
      out('allow', 'незворотна дія підтверджена окремо');
    }
    out('deny', second === 'deny'
      ? 'Незворотну дію скасовано користувачем. Скажи людською мовою, чого тепер не буде, і запропонуй крок без неї.'
      : `Незворотна дія не підтверджена окремо, тому не виконана. ${verdict.reason}`);
  }

  // ── Звичайна дія: як було ────────────────────────────────────────────────
  const dec = await ask({
    tool, input, toolUseId: ev.tool_use_id || '', irreversible: false, stage: 'normal',
  }, `запит дозволу: ${tool}`);
  // Server unreachable / nobody answered -> fail open so the assistant is never stuck.
  if (dec === null) { journal(ev, verdict); out('allow', 'gate unavailable or timed out (fail-open)'); }
  if (dec === 'deny') out('deny', 'Відхилено користувачем у Logopsis');
  if (dec === 'session') {
    try {
      let cur = [];
      if (fs.existsSync(allowPath)) cur = JSON.parse(fs.readFileSync(allowPath, 'utf8')) || [];
      if (!Array.isArray(cur)) cur = [];
      if (!cur.includes(tool)) cur.push(tool);
      fs.writeFileSync(allowPath, JSON.stringify(cur));
    } catch (_) { /* ignore */ }
    journal(ev, verdict);
    out('allow', 'allowed for session');
  }
  journal(ev, verdict);
  out('allow', 'allowed once');
})().catch(() => {
  // Аварійний вихід. Для звичайної дії fail-open, для незворотної fail-closed:
  // помилка в гейті не сміє оберталась мовчазним видаленням у людини.
  if (IRREVERSIBLE_CALL) out('deny', 'Незворотна дія не підтверджена окремо через збій гейта.');
  out('allow', 'gate error (fail-open)');
});
