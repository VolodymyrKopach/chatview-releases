#!/usr/bin/env node
// SubagentStop hook (owner decision 2026-07-13). When a Task sub-agent finishes, drop a
// SILENT completion signal into the owning channel's «Процеси» timeline so the
// panel button pulses and there is ALWAYS a visible "a sub-agent just finished"
// cue — even for a sub-agent that finishes around a turn boundary, which the
// runner's own stream-parse can miss once the main `claude -p` has exited.
//
// Deliberately NOT a chat card: the detached engine (agent_worker.py) already
// posts a result card on done, and turn-bound sub-agents are summarized in my
// reply. A card here would double up / spam. So this is panel-only.
//
// stdin JSON = { session_id, ... } (the PARENT session). MUST never throw / never
// exit non-zero: a SubagentStop hook that throws would surface as an agent error.
// Registered from .claude/settings.json with a portable ${CLAUDE_PROJECT_DIR} path.

const fs = require('fs');

try {
  let input = {};
  try { input = JSON.parse(fs.readFileSync(0, 'utf8')); } catch {}
  const sessionId = input && input.session_id ? String(input.session_id) : '';
  if (!sessionId) process.exit(0);

  let plan = null;
  try { plan = require('./plan-state.cjs'); } catch {}
  if (!plan) process.exit(0);

  const channel = plan.boundChannel(sessionId);
  if (!channel) process.exit(0);

  // Best-effort human label: the harness may hand us a subagent type / name.
  const name = (input.subagent_type || input.agent_type || input.name || 'саб-агент')
    .toString().slice(0, 60);

  try {
    require('./_emit.cjs').emit(channel, {
      kind: 'agent', name, phase: 'done', detail: 'саб-агент завершив',
    });
  } catch {}
} catch {
  // never throw
}

process.exit(0);
