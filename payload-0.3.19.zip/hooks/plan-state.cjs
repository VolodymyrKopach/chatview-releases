// Shared plan-state inspector for the Chat View hooks (cross-platform).
// Finds the most-recently-active channel (proxy for the tab the user is in) and
// reports its plan snapshot + whether it looks STALE (real activity happened
// after the plan was last written). Used by both chat-view-reminder.cjs
// (UserPromptSubmit) and plan-ping.cjs (PostToolUse).

const fs = require('fs');
const path = require('path');

// Дзеркалення імен змінних середовища (CHATVIEW_* <-> LOGOPSIS_*) під час ребренду.
// Мусить стояти вище за перше читання process.env у цьому файлі: у власника
// лишились запущені служби і аліаси зі старими іменами. Контракт: brand-env.cjs.
require("../brand-env.cjs")

const CHAT_DIR = path.resolve(__dirname, '..');          // tools/viz/chat
const CHANNELS_DIR = path.join(CHAT_DIR, 'channels');
const STALE_MS = 60 * 1000;                              // activity newer than plan by >60s = stale

function safeStatMtime(p) {
  try { return fs.statSync(p).mtimeMs; } catch { return 0; }
}

// Resolve the channel RESERVED for a Claude Code session (set by session-start.cjs),
// falling back to null if there is no mapping for this session. The reservation is
// authoritative even before the channel dir exists (lazy creation): the reminder
// must still be able to tell Claude where to write so the first card materializes
// the right channel.
function boundChannel(sessionId) {
  // Runner-served headless turn: the runner pins the exact channel it is serving
  // via env. This wins over the session-id map (whose rotated/forked ids would
  // otherwise miss and let the engine bind to / mint the wrong channel).
  if (process.env.LOGOPSIS_CHANNEL) return process.env.LOGOPSIS_CHANNEL;
  if (!sessionId) return null;
  try {
    const map = JSON.parse(fs.readFileSync(path.join(CHANNELS_DIR, '.cc-sessions.json'), 'utf8'));
    const cid = map && map[sessionId];
    if (cid) return cid;
  } catch {}
  return null;
}

// When a sessionId is given AND it maps to a bound channel, that wins over the
// mtime heuristic (the session knows exactly which tab is its own). Otherwise we
// fall back to "newest-mtime channel dir" as before.
function inspectActivePlan(sessionId) {
  // Merge committed registry + machine-local cc-* overlay so auto session
  // channel labels resolve (committed wins on id collision).
  let list = [];
  for (const name of ['index.json', 'index.local.json']) {
    try {
      const part = JSON.parse(fs.readFileSync(path.join(CHANNELS_DIR, name), 'utf8'));
      if (Array.isArray(part)) list = list.concat(part);
    } catch {}
  }
  const labelOf = {};
  for (const c of list) if (c && c.id) labelOf[c.id] = c.label || c.id;

  let dirs = [];
  try { dirs = fs.readdirSync(CHANNELS_DIR, { withFileTypes: true }).filter(d => d.isDirectory()).map(d => d.name); } catch {}

  // The bound (reserved) channel wins even if its dir does not exist yet — the
  // session knows exactly which tab is its own. A not-yet-materialized bound
  // channel is reported as a brand-new NO-PLAN channel (no crash).
  let active = boundChannel(sessionId);
  if (!active) {
    if (!dirs.length) return null;
    // Active channel = channel dir with the newest mtime (new card => dir mtime bumps).
    let activeMtime = 0;
    for (const id of dirs) {
      const m = safeStatMtime(path.join(CHANNELS_DIR, id));
      if (m > activeMtime) { activeMtime = m; active = id; }
    }
  }
  if (!active) return null;

  // Bound channel reserved but not materialized yet: no dir, no plan, no messages.
  if (!dirs.includes(active)) {
    return {
      id: active,
      label: labelOf[active] || active,
      goal: '', updated: '(нема)', planMtime: 0,
      done: 0, total: 0, thin: 0, noPlan: true, stale: false,
    };
  }

  const chDir = path.join(CHANNELS_DIR, active);
  const planPath = path.join(chDir, 'plan.json');
  const planMtime = safeStatMtime(planPath);

  // Newest message file mtime in the active channel (NNNN.json), ignoring plan/meta.
  let newestMsg = 0;
  try {
    for (const f of fs.readdirSync(chDir)) {
      if (!/^\d+\.json$/.test(f)) continue;
      const m = safeStatMtime(path.join(chDir, f));
      if (m > newestMsg) newestMsg = m;
    }
  } catch {}

  let plan = null;
  try { plan = JSON.parse(fs.readFileSync(planPath, 'utf8')); } catch {}

  const steps = plan
    ? (Array.isArray(plan.phases) ? plan.phases.flatMap(p => p.steps || []) : (plan.steps || []))
    : [];
  const done = steps.filter(s => s && s.state === 'done').length;
  const total = steps.length;
  const openSteps = total - done;
  // How many steps still lack the mandatory goal + result (the owner's detailed-structure rule).
  const thin = steps.filter(s => s && !(s.goal && s.result)).length;

  const noPlan = !plan || total === 0;
  const stale = noPlan
    ? newestMsg > 0
    : (newestMsg > planMtime + STALE_MS && openSteps > 0);

  return {
    id: active,
    label: labelOf[active] || active,
    goal: plan && plan.goal ? plan.goal : '',
    updated: plan && plan.updated ? plan.updated : '(нема)',
    planMtime,
    done, total, thin, noPlan, stale,
  };
}

// One-line snapshot string for injecting into reminders.
function snapshotLine(p) {
  if (!p) return 'Active plan: (не вдалось прочитати канали).';
  if (p.noPlan) return `Active channel: ${p.label} (#${p.id}) — NO PLAN YET.`;
  const flags = [];
  if (p.stale) flags.push('⚠️ STALE (activity after last plan write)');
  if (p.thin > 0) flags.push(`⚠️ ${p.thin}/${p.total} steps missing goal+expected-result`);
  return `Active channel: ${p.label} (#${p.id}) — ${p.done}/${p.total} done, updated ${p.updated}.`
    + (flags.length ? '  ' + flags.join(' · ') : '');
}

module.exports = { inspectActivePlan, snapshotLine, boundChannel, CHAT_DIR, CHANNELS_DIR };
