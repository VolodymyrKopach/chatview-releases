#!/usr/bin/env python3
"""plan_store.py — THE single writer of channels/<id>/plan.json.

WHY THIS MODULE EXISTS (owner decision, 2026-08-04)
--------------------------------------------------
The plan sidebar was declarative already: the assistant emits a ```plan``` block,
runner.py strips it and persists it. The persisting half shelled out to
`set-plan.cjs`, and that broke the packaged desktop app in two independent ways at
once:

  1. `set-plan.cjs` was never in the payload manifest, so Logopsis.app simply had no
     such file. `subprocess.run` failed, the caller was best-effort, and the plan
     vanished without a single visible symptom. The owner: «кажу в чаті додай план, воно
     не додає».
  2. Even shipped, it wrote to `<dir-of-the-script>/channels/...`. In the desktop the
     script would sit inside the read-only bundle while the DATA lives in
     LOGOPSIS_HOME, so the plan would have landed beside the app instead of in the
     user's home.

Both are gone here: the write is plain Python, in-process (no node, no subprocess, no
file to forget in a manifest), and the target dir is derived from the SAME environment
rule server.py and runner.py use, so the plan always lands in the active data home.

SINGLE WRITER. This module is the only code that creates plan.json. `set-plan.cjs`
and `set-plan.sh` are now thin argument-forwarding wrappers over `main()` here, kept
only so the documented CLI keeps working; neither owns any plan logic anymore.

APPEND, NEVER OVERWRITE (owner decision, 2026-08-06)
---------------------------------------------------
The writer used to REPLACE plan.json with whatever snapshot arrived. That made "the
plan" a picture of the present, so a turn that declared six current steps silently
deleted twenty finished ones, and there was nothing to roll back to. The owner: «це ж
історія, це як з комітами: ми просто йдемо поверх».

So a snapshot is now MERGED into the stored plan:
  * a step is matched by its explicit `id`, else by its normalized `text`;
  * a `done` step is INDESTRUCTIBLE: it cannot be removed, reverted to pending/progress
    or reworded. A snapshot that omits it leaves it exactly where it was;
  * steps that are not done are updated when the snapshot mentions them and kept when
    it does not;
  * the ONLY way to remove a mistaken step is an explicit `"state": "dropped"`, and it
    works on non-done steps only;
  * `goal` (and the other top-level fields) update freely: they describe the present,
    not the history;
  * order is active first, finished history below in the order it was finished, and
    every step gets a `doneAt` stamp the moment it turns done, so the tail reads as a
    feed of events.

ORDERED VS PROPOSED (owner decision, 2026-09-06)
------------------------------------------------
Every step the model put in a plan used to become a full commitment the instant it was
written, counted in progress like the human had actually asked for it. The owner: «або це
прям прямо було сказано, або він точно розуміє сильний намір. Всі інші випадки план не
єбашим з ніхуя». There was no notion of where a step came from, so a guess and a direct
order were indistinguishable — model discipline alone cannot hold that line, it needs a
structural default.

So every step now carries `origin`, one of `ORDERED` / `PROPOSED`:
  * a step declared WITHOUT `origin` in a brand-new snapshot is `PROPOSED` — the
    default is inverted on purpose, so an unproven step is a suggestion, never a
    commitment (spec K1);
  * a step already sitting in the stored plan without `origin` (every plan written
    before this feature existed) is read as `ORDERED`, or those plans would lose all
    their progress the moment this code ships (spec K7);
  * a step can inherit `ORDERED` from a parent via an explicit `inheritOrderedFrom:
    <parent id>` — never by nesting or position, that would smuggle the guess back in.
    The parent must itself resolve to `ORDERED` (its own flag, or the stored-default
    above); a missing parent or a proposed one leaves the child `PROPOSED`;
  * a `done` step is already frozen solid by the merge above and this changes nothing
    about that: `origin` is skipped along with every other field, so a step cannot be
    relabeled after the fact by re-declaring it (spec K6).
Proof that an `ORDERED` claim is real (matching it against what the human actually
said) is a separate module by design (plan_order_proof.py) — this file only owns the
flag and its defaults, not the verification logic.

PROOF WIRED IN AT THE WRITE (owner decision, 2026-09-07, D6/E1)
---------------------------------------------------------------
plan_order_proof.py was correct in isolation from the day it was written (D2, 17 of
its own green tests) but nothing ever called it — a live run of D6 found a step
declared `"origin":"ordered"` with an INVENTED quote sailing through as ordered,
counted in progress, because `resolve_step_origin` was orphaned (see
work/plan-autosync/d6/k2-defect.md). `write_plan` is the one place all five writers
of plan.json funnel through (this CLI, plan_autopatch.py, plan_staleness.py,
runner.py's ```plan``` block, server.py's /api/plan-update), so it is the one place
that can enforce this without five call sites drifting out of sync — a mistake this
repo already made twice. So write_plan now runs every RAW step of the INCOMING
snapshot through `plan_order_proof.resolve_step_origin` before merge_plan ever sees
it (`_resolve_declared_origins`, spec K2): only a step THIS snapshot itself marks
`origin: ordered` gets checked, an already-stored ordered step re-declared without
that flag is left for merge's own stored-default/inheritance rules exactly as before.
A broken check (missing module, any exception) never fails the write — it downgrades
that one step to PROPOSED and the write proceeds (spec K9).

write_plan's OWN returned counter also switched from counting every step to counting
ONLY ordered ones (mirrors server.py's `_ordered_progress` — spec K3), because the
old "count everything" return value disagreed with the sidebar badge on the exact
same plan (the CLI would print "40/50" next to a badge reading "40/49"). Steps
already sitting in the stored plan are not re-read against the channel's messages —
that check ran once, when they first arrived; this only widens what merge already
does to the shape merge already produces.

ONLY THE FIRST DECLARATION IS CHECKED, AND INHERITANCE IS TRUSTED (owner decision,
2026-09-07, live run C6, work/plan-autosync/c6/DEFEKTY.md Д1)
------------------------------------------------------------------------------------
The paragraph above undersold its own claim. plan_staleness.run_channel reads the
WHOLE stored plan and pipes it straight back through write_plan every time it
touches staleness bookkeeping (every ~5 minutes once the autosync tick is live) —
so EVERY already-`ordered` step arrives back at `_resolve_declared_origins` with an
explicit `"origin":"ordered"` again, indistinguishable at that point from a model
declaring it for the first time. The old code re-ran the quote check on all of them,
every time. A step's orderProof only has to scroll past `plan_order_proof`'s
MESSAGE_WINDOW, or the channel's message file to move/vanish, for an already-approved
step to demote mid-flight with no one having done anything wrong. Measured on
chat-281: 15 stored ordered steps, and the very next scheduled rewrite would have
demoted all 15 — the ones already `done` survived only because merge's own freezing
protects them, so the entire loss lands on exactly the steps still counting toward
progress.

`_resolve_declared_origins` now takes the OLD stored plan (read once by write_plan
before either this function or merge_plan touch it) and skips the quote check when
either is true for a step this snapshot marks `origin: ordered`:
  * it already matches a stored step (active or done, same alias rules merge_plan
    itself uses) whose effective origin was already ORDERED — not a first
    declaration, so re-reading the channel's messages for it again is pointless and
    actively harmful once the original quote is out of window;
  * it names `inheritOrderedFrom` to a parent that itself resolves to ORDERED (via
    the SAME `_resolve_origins` merge_plan already uses to seed inheritance — no
    second implementation of that rule) — inheritance was always meant to skip the
    proof requirement, but a step that had already been resolved once and stored
    with its `origin` materialized to "ordered" would carry that literal flag on the
    next full resend and get treated as a fresh, unproven claim with no quote of its
    own to check.
Neither escape hatch weakens the core rule: a step declaring `origin: ordered` for
the FIRST time (no matching stored step, no ordered parent) still needs a real quote
and still demotes on a fabricated one — that is this feature's entire reason to
exist, and this fix only narrows WHEN the check runs, never what it decides.
"""
import json
import os
import re
import sys
import time

# Назва вкладки береться з ТОГО САМОГО модуля, що і в server.py
# (specs/chat-tab-label-detector, К8). Доти тут стояла власна копія обрізки, і канал,
# народжений планом, діставав назву-обрізок навіть після того, як детектор у сервері
# навчили читати зміст. sys.path тому, що цей модуль запускають і як CLI
# (`python3 plan_store.py …` через set-plan.cjs), де теки поруч у шляху ще нема.
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import tab_label  # noqa: E402

# ДЗЕРКАЛЕННЯ ІМЕН ЗМІННИХ СЕРЕДОВИЩА (CHATVIEW_* <-> LOGOPSIS_*): цей модуль
# читає домівку сам і його запускають окремо, тому шим потрібен і тут. Див. brand_env.py.
import brand_env  # noqa: E402,F401

# Same rule as server.py / runner.py: the desktop sets LOGOPSIS_HOME to the writable
# data home, dev/live runs out of the repo dir. Read lazily (not frozen at import) so
# a test can point it somewhere else.
def base_dir():
    return os.environ.get('LOGOPSIS_HOME') or os.path.dirname(os.path.abspath(__file__))


def channels_dir():
    return os.path.join(base_dir(), 'channels')


# Keyword -> emoji for auto-iconing a fresh chat from its plan goal. First match wins,
# so this is ordered most specific to most generic. Mirrors render-message.cjs, which
# is why a plan-first channel and a message-first channel get the same lively icon.
ICON_RULES = (
    (r'гро[шж]|оплат|комунал|payment|підписк|білінг|invoice|рахунок', '💰'),
    (r'баг|fix|фікс|помилк|bug|debug|зламал|crash|exception', '🛠'),
    (r'код|code|деплой|deploy|рефактор|refactor|api\b|docker|сервер|backend', '💻'),
    (r'дизайн|design|\bui\b|\bux\b|макет|figma|mockup|wireframe', '🎨'),
    (r'відео|reels|рілс|кліп|video|youtube|монтаж', '🎬'),
    (r'маркетинг|реклам|\bads?\b|кампан|campaign|воронк|funnel', '📣'),
    (r'аналітик|метрик|\bsql\b|дашборд|analytics|metric|dashboard|конверс', '📊'),
    (r'іде[яї]|брейншторм|brainstorm|гіпотез', '💡'),
    (r'чат[- ]?в|logopsis|chat[- ]?view|інтерфейс|widget|віджет', '🪟'),
    (r'контент|пост\b|статт|copy|копірайт|article', '✍️'),
    (r'дослід|research|конкурент|competitor|ресерч', '🔬'),
    (r'план|roadmap|стратег|strategy|спрінт|sprint', '🗺️'),
    (r'лист\b|email|розсилк|drip|newsletter|імейл', '📨'),
)


def _plain(raw):
    """Free text -> one clean line: strip tags, collapse whitespace."""
    return re.sub(r'\s+', ' ', re.sub(r'<[^>]*>', ' ', '' if raw is None else str(raw))).strip()


def snippet_label(raw, max_len=tab_label.MAX_LEN):
    """Ціль плану -> назва вкладки ЗА ЗМІСТОМ. Делегат у спільний `tab_label`.

    Тут була власна обрізка на 32 символи: зняти теги, стиснути пробіли, різати по
    межі слова. Вона не розуміла ані markdown-лінка, ані голої адреси, тож ціль плану
    на кшталт `[звіт.html](file:///…) розібрати` давала вкладку `[звіт.html](file:///…`.
    Тепер правила спільні з server.py, включно з довжиною (36, не 32), інакше два
    канали з однаковою темою діставали різної довжини напис."""
    return tab_label.snippet_label(raw, max_len=max_len)


def derive_icon(text):
    """Topical emoji for free text. '🆕' (fresh chat) when nothing matches, never the
    dull gray '💬'."""
    s = _plain(text)
    if not s:
        return '🆕'
    for pattern, emoji in ICON_RULES:
        if re.search(pattern, s, re.IGNORECASE):
            return emoji
    return '🆕'


def code_time_label():
    """The old hardcoded 'Code HH:MM' tab name, now only a safety net."""
    return time.strftime('Code %H:%M')


def _write_json_atomic(path, obj):
    """Write then rename, so the 2s poller never reads a half-written file.

    The temp name is unique per call (pid + a monotonic tiebreaker), not the fixed
    `<path>.tmp` it used to be (Д3, work/plan-autosync/c6/DEFEKTY.md): two writers
    sharing one temp path can truncate each other's half-written file before either
    gets to rename it, and the loser's `os.replace` then blows up because the temp
    file it opened has already been renamed away by the winner — reproduced live by
    spawning concurrent writers (test_two_concurrent_processes_writing_the_same_plan
    _both_survive): `[Errno 2] ... plan.json.tmp -> plan.json`."""
    tmp = '%s.tmp.%d.%d' % (path, os.getpid(), time.monotonic_ns())
    with open(tmp, 'w', encoding='utf-8') as f:
        json.dump(obj, f, ensure_ascii=False, indent=2)
    os.replace(tmp, path)


# ---- Cross-process mutex on channels/<id>/.plan.mutex (Д3) ----
# plan_store.py had no flock/fcntl/threading.Lock anywhere: write_plan's read of the
# stored plan, its merge, and its write were a critical section with zero mutual
# exclusion between WRITERS (the atomic rename above only protects a READER from a
# half-written file). Same idiom already proven for the identical problem one layer
# up the stack — append-mutex.cjs / server.py._append_mutex_acquire — ported here
# rather than reinvented: exclusive file CREATION (O_CREAT|O_EXCL) as the lock,
# stale-file reclaim so a crashed holder cannot wedge a channel's plan forever, and
# best-effort past the deadline (losing the plan is worse than losing the lock).
_PLAN_MUTEX_RETRY_S = 0.02      # poll cadence while spinning for the mutex
_PLAN_MUTEX_MAX_WAIT_S = 3.0    # best-effort: write anyway past this, mutex or not
_PLAN_MUTEX_STALE_S = 10.0      # a lock file older than this belongs to a dead writer


def _plan_mutex_acquire(ch_dir, max_wait_s=None, stale_s=None, retry_s=None):
    """Take channels/<id>/.plan.mutex. Returns True iff THIS call created (and thus
    holds) it; False when the deadline passed with a live holder still there —
    best-effort, the caller writes regardless (see module note above)."""
    max_wait_s = _PLAN_MUTEX_MAX_WAIT_S if max_wait_s is None else max_wait_s
    stale_s = _PLAN_MUTEX_STALE_S if stale_s is None else stale_s
    retry_s = _PLAN_MUTEX_RETRY_S if retry_s is None else retry_s
    lock_path = os.path.join(ch_dir, '.plan.mutex')
    deadline = time.monotonic() + max_wait_s
    while time.monotonic() < deadline:
        try:
            fd = os.open(lock_path, os.O_CREAT | os.O_EXCL | os.O_WRONLY)
            try:
                os.write(fd, json.dumps({'pid': os.getpid(), 'at': time.time()}).encode('utf-8'))
            finally:
                os.close(fd)
            return True
        except FileExistsError:
            try:
                if time.time() - os.path.getmtime(lock_path) > stale_s:
                    os.unlink(lock_path)
                    continue
            except OSError:
                pass  # already gone, or the real holder is releasing right now
            time.sleep(retry_s)
    return False


def _plan_mutex_release(ch_dir):
    try:
        os.unlink(os.path.join(ch_dir, '.plan.mutex'))
    except OSError:
        pass


def _in_registry(path, cid):
    try:
        with open(path, encoding='utf-8') as f:
            reg = json.load(f)
        return isinstance(reg, list) and any(
            isinstance(x, dict) and x.get('id') == cid for x in reg)
    except Exception:
        return False


def valid_channel_id(cid):
    """True when `cid` may name a channel directory. Same guard as server.py's
    /api/message-post ("bad channel"), stated as a REJECT list on purpose: live ids share
    no prefix or shape (main, page, chat-91, cc-64487d, gluschenko-lviv), so any pattern
    strict enough to be a whitelist would also refuse real channels."""
    s = '' if cid is None else str(cid)
    if not s or s.startswith('.') or '..' in s:
        return False
    if '/' in s or '\\' in s:
        return False
    return not any(ch == '\0' or ord(ch) < 32 for ch in s)


def ensure_registered(ch_dir_root, cid, goal):
    """Lazy channel registration (mirror of render-message.cjs): a plan is content too,
    so writing one materializes the tab when the channel is in neither registry. A cc-*
    channel derives its label from the plan goal, else falls back to 'Code HH:MM'."""
    if not valid_channel_id(cid):
        # Was `if not cid: return`, which let a PATH through as an id: a heredoc mishap
        # once passed '/proc/self/fd/0' and this function dutifully created a dead tab.
        # Still silent to the caller (a tab must never fail a plan), but no longer
        # invisible: the operator sees what actually arrived.
        sys.stderr.write('plan_store: refusing to register a channel with a bad id: %r\n' % (cid,))
        return
    reg_path = os.path.join(ch_dir_root, 'index.json')
    local_path = os.path.join(ch_dir_root, 'index.local.json')
    if _in_registry(reg_path, cid) or _in_registry(local_path, cid):
        return
    try:
        with open(local_path, encoding='utf-8') as f:
            local_reg = json.load(f)
    except Exception:
        local_reg = []
    if not isinstance(local_reg, list):
        local_reg = []
    if any(isinstance(x, dict) and x.get('id') == cid for x in local_reg):
        return
    label, icon = cid, '🆕'
    if cid.startswith('cc-'):
        label = snippet_label(goal) or code_time_label()
        icon = derive_icon(goal)
    # `autoNamed` це не косметика, а дозвіл (specs/chat-tab-label-detector, К9). Назву
    # тут ставить машина, і LLM-називальник у server.py перезаписує лише назву дефолтну
    # АБО позначену цим прапорцем. Без нього автоматична назва виглядала для намера
    # ручною, тобто застигала назавжди, і поганий підпис ніхто вже не чинив. Ручне
    # перейменування прапорець знімає (/api/channel-rename), тож підпис людини цілий.
    local_reg.append({'id': cid, 'label': label, 'icon': icon, 'twoway': False,
                      'cc': True, 'autoNamed': True})
    _write_json_atomic(local_path, local_reg)


def collect_steps(plan):
    """Every step of a plan, flat or phased."""
    phases = plan.get('phases')
    if isinstance(phases, list):
        out = []
        for ph in phases:
            if isinstance(ph, dict):
                out.extend(ph.get('steps') or [])
        return out
    return plan.get('steps') or []


DONE = 'done'
DROPPED = 'dropped'
ORDERED = 'ordered'
PROPOSED = 'proposed'


def _state(step):
    """Lowercased state of a step, '' when absent (which the UI reads as pending)."""
    raw = step.get('state') if isinstance(step, dict) else None
    return str(raw).strip().lower() if raw else ''


def step_aliases(step):
    """Every handle a step can be recognized by, most specific first: its explicit `id`,
    then its normalized text (lowercased, whitespace collapsed).

    Both, not one of them, because the two sides use different handles: a caller that
    assigns ids matches by id, while the assistant re-declares steps by wording. Text
    normalization means a reflowed line is still the same step. A step with neither has
    no identity at all: it can only be appended, never matched."""
    if not isinstance(step, dict):
        return []
    out = []
    sid = step.get('id')
    if sid is not None and str(sid).strip():
        out.append('id:' + str(sid).strip())
    text = re.sub(r'\s+', ' ', str(step.get('text') or '')).strip().lower()
    if text:
        out.append('text:' + text)
    return out


def _index(index, step):
    """Register a step under all its handles. First writer of a handle wins, so a
    duplicated wording never lets a later step hijack an earlier one's identity."""
    for alias in step_aliases(step):
        index.setdefault(alias, step)


def _lookup(index, step):
    """The stored step this snapshot step refers to, or None."""
    for alias in step_aliases(step):
        if alias in index:
            return index[alias]
    return None


def _own_origin(step):
    """The `origin` a step declares for itself, normalized, or None when absent or
    not one of the two recognized values (a typo must not silently pass as ordered)."""
    val = step.get('origin') if isinstance(step, dict) else None
    val = str(val).strip().lower() if val else ''
    return val if val in (ORDERED, PROPOSED) else None


def _stored_origin(step):
    """The effective origin of a step already sitting in the stored plan: its own
    flag if it has one, else ORDERED — a plan written before this feature existed
    must not lose progress the moment this code ships (spec K7)."""
    return _own_origin(step) or ORDERED


def _origin_parent_id(step):
    """The id a step names to inherit ORDERED from, or None. Explicit only: nesting
    or adjacency never implies a parent."""
    pid = step.get('inheritOrderedFrom') if isinstance(step, dict) else None
    pid = str(pid).strip() if pid else ''
    return pid or None


def _resolve_origins(new_buckets, old_active_idx, old_done_idx):
    """id -> effective origin, for resolving `inheritOrderedFrom` references.

    Seeded from the stored plan (done steps first, so a done id's frozen origin can
    never be overridden by an unrelated re-declaration of the same id), then overlaid
    by explicit `origin` declarations made in THIS snapshot — so a parent that is
    declared and marked ordered in the very same turn as its children can back their
    inheritance without a prior write. A step with no explicit `origin` of its own
    never registers here, even if it will end up ORDERED by inheritance or by being
    an existing stored step: only an explicit or already-frozen ORDERED can be lent
    to someone else, borrowed status is not transitive within one snapshot."""
    by_id, frozen = {}, set()
    for alias, st in old_done_idx.items():
        if alias.startswith('id:'):
            sid = alias[3:]
            by_id[sid] = _stored_origin(st)
            frozen.add(sid)
    for alias, st in old_active_idx.items():
        if alias.startswith('id:'):
            sid = alias[3:]
            by_id.setdefault(sid, _stored_origin(st))
    for _title, steps in new_buckets:
        for st in steps:
            sid = st.get('id')
            sid = str(sid).strip() if sid is not None else ''
            own = _own_origin(st)
            if sid and sid not in frozen and own:
                by_id[sid] = own
    return by_id


def _new_step_origin(st, prev, origin_by_id):
    """The origin a snapshot step resolves to: its own explicit flag first, then
    inheritance from an explicitly named ordered parent, then the stored step it
    matches (already-ordered by default, spec K7), and only a brand-new step with
    none of those becomes the inverted default, PROPOSED (spec K1)."""
    own = _own_origin(st)
    if own:
        return own
    parent_id = _origin_parent_id(st)
    if parent_id:
        return ORDERED if origin_by_id.get(parent_id) == ORDERED else PROPOSED
    if prev is not None:
        return _stored_origin(prev)
    return PROPOSED


def _buckets(plan):
    """Plan -> [(phase_title_or_None, [steps])]. A flat plan is one unnamed bucket, so
    merging is written once and works on both shapes."""
    phases = plan.get('phases') if isinstance(plan, dict) else None
    if isinstance(phases, list) and phases:
        out = []
        for ph in phases:
            if isinstance(ph, dict):
                out.append((ph.get('title'), [s for s in (ph.get('steps') or []) if isinstance(s, dict)]))
        if out:
            return out
    steps = plan.get('steps') if isinstance(plan, dict) else None
    return [(None, [s for s in (steps or []) if isinstance(s, dict)])]


def _target_bucket(old_title, old_index, new_titles):
    """Where a surviving old step lands when the snapshot reshaped the phases: same
    title if it is still there, else the same position, else the last bucket. History
    never falls off the edge just because a phase was renamed away."""
    if old_title is not None and old_title in new_titles:
        return new_titles.index(old_title)
    if 0 <= old_index < len(new_titles):
        return old_index
    return len(new_titles) - 1


def merge_plan(old, new, stamp=None):
    """Merge a snapshot into the stored plan. Pure function, no I/O.

    Everything the module docstring promises lives here: done is indestructible, the
    snapshot owns the active part, `dropped` removes only non-done steps, and the
    output is ordered active-then-history."""
    if not isinstance(new, dict):
        raise ValueError('plan must be a JSON object')
    old = old if isinstance(old, dict) else {}
    stamp = stamp or time.strftime('%Y-%m-%d %H:%M')

    old_buckets = _buckets(old)
    new_buckets = _buckets(new)
    new_titles = [t for t, _ in new_buckets]
    slots = [{'new_active': [], 'survivors': [], 'old_done': [], 'new_done': []}
             for _ in new_buckets]

    # Index the stored steps once. `done` and active are kept apart because they obey
    # opposite rules: one is frozen, the other is the snapshot's to rewrite.
    old_done_idx, old_active_idx = {}, {}
    for _title, steps in old_buckets:
        for st in steps:
            _index(old_done_idx if _state(st) == DONE else old_active_idx, st)

    # Origin resolution needs every id in play (stored + this snapshot) before any
    # step is merged, since a child can name a parent declared later in the same
    # snapshot or one that already lives in storage.
    origin_by_id = _resolve_origins(new_buckets, old_active_idx, old_done_idx)

    # Consumption is tracked by object identity, not by handle: a stored step matched
    # by its text must not resurface just because it also carries an id.
    claimed = set()

    for bi, (_title, steps) in enumerate(new_buckets):
        for st in steps:
            state = _state(st)
            if _lookup(old_done_idx, st) is not None:
                continue                      # frozen: no edit, no revert, no drop
            prev = _lookup(old_active_idx, st)
            if prev is not None:
                claimed.add(id(prev))
            if state == DROPPED:
                continue                      # a no-op when nothing matched
            # Field-wise, not wholesale: the snapshot wins on every field it DECLARES
            # (send "note": "" to clear one) and the stored value survives on the rest.
            # Otherwise the usual one-liner `{"text": X, "state": "done"}` would strip
            # goal/substeps/result at the exact moment the step becomes frozen, and the
            # history would be a list of bare titles.
            step = dict(prev) if prev else {}
            step.update(st)
            step['origin'] = _new_step_origin(st, prev, origin_by_id)
            if state == DONE:
                # setdefault, not assignment: a caller replaying a real completion time
                # keeps it. Stamped once, then frozen with the step itself.
                step.setdefault('doneAt', stamp)
                slots[bi]['new_done'].append(step)
            else:
                slots[bi]['new_active'].append(step)

    # Stored steps the snapshot did not mention. Walked in stored order, so finished
    # history keeps the sequence it was finished in.
    for bi, (title, steps) in enumerate(old_buckets):
        target = _target_bucket(title, bi, new_titles)
        for st in steps:
            if _state(st) == DONE:
                slots[target]['old_done'].append(st)
            elif id(st) not in claimed:
                slots[target]['survivors'].append(st)

    merged_buckets = [s['new_active'] + s['survivors'] + s['old_done'] + s['new_done']
                      for s in slots]

    # Top-level fields describe the present, so the snapshot wins; a field the snapshot
    # omits keeps its stored value (a partial declaration must not erase the goal).
    out = {k: v for k, v in old.items() if k not in ('steps', 'phases')}
    out.update({k: v for k, v in new.items() if k not in ('steps', 'phases')})
    if any(t is not None for t in new_titles) or len(new_buckets) > 1:
        out.pop('steps', None)
        out['phases'] = [{'title': t, 'steps': merged_buckets[i]}
                         for i, t in enumerate(new_titles)]
    else:
        out.pop('phases', None)               # or collect_steps would read stale phases
        out['steps'] = merged_buckets[0]
    return out


def _step_is_proposed(step):
    """Mirrors server.py's `_step_is_proposed` (spec K3): only an explicit
    'proposed' excludes a step from progress; a missing or garbled flag defaults to
    ordered — the same fallback `_stored_origin` uses above, so a plan written
    before this feature existed does not silently lose progress here either (K7)."""
    return str(step.get('origin') or '').strip().lower() == PROPOSED


def _ordered_progress(steps):
    """(done, total) counting ONLY ordered steps — the same rule server.py's
    `_ordered_progress` applies to the sidebar badge (spec K3), so write_plan's own
    return value never disagrees with what the badge shows for the same plan (the
    D6 report: CLI printed "40/50" next to a badge reading "40/49")."""
    ordered = [s for s in steps if isinstance(s, dict) and not _step_is_proposed(s)]
    total = len(ordered)
    done = sum(1 for s in ordered if s.get('state') == DONE)
    return done, total


def _resolve_declared_origins(plan, old_plan, channel, root):
    """Run every RAW step of an incoming snapshot through plan_order_proof's proof
    check, BEFORE merge_plan ever sees it (spec K2, subtask D6/E1 — see the module
    docstring's "PROOF WIRED IN AT THE WRITE" section for why this lives here).

    Deliberately narrow, now in TWO ways (Д1, see the module docstring's "ONLY THE
    FIRST DECLARATION IS CHECKED" section for the live incident that forced this):
      1. a step only gets checked when THIS snapshot itself declares `origin:
         ordered` on it (plan_order_proof.resolve_step_origin already no-ops on
         anything else) — a step re-declared WITHOUT an origin is left untouched
         here, decided later by merge_plan's own stored-default/inheritance rules;
      2. even when it DOES declare `origin: ordered`, the check is skipped (the step
         passes through as ordered, unchecked) when either escape hatch fires:
         already matches a stored step (`old_plan`, active or done) whose effective
         origin was already ORDERED, or names `inheritOrderedFrom` to a parent that
         itself resolves to ORDERED via `_resolve_origins` — the exact function
         merge_plan itself uses to seed inheritance, not a second copy of that rule.
    Neither hatch fires for a step making a genuinely first, unmatched, non-inherited
    `ordered` claim: that one still goes through the real check and still demotes on
    a fabricated quote.

    Never lets a broken check block the write (K9): a missing plan_order_proof
    module, or any exception raised while checking one step, downgrades that step to
    PROPOSED rather than propagating — losing a step is worse than mislabeling it,
    the same principle `resolve_step_origin` itself is built on one layer down."""
    if not isinstance(plan, dict):
        return plan
    try:
        import plan_order_proof as _pop
    except Exception:
        return plan

    old_buckets = _buckets(old_plan) if isinstance(old_plan, dict) else [(None, [])]
    old_done_idx, old_active_idx = {}, {}
    for _title, steps in old_buckets:
        for st in steps:
            _index(old_done_idx if _state(st) == DONE else old_active_idx, st)

    new_buckets = _buckets(plan)
    origin_by_id = _resolve_origins(new_buckets, old_active_idx, old_done_idx)

    def _already_ordered(step):
        prev = _lookup(old_active_idx, step)
        if prev is None:
            prev = _lookup(old_done_idx, step)
        return prev is not None and _stored_origin(prev) == ORDERED

    def _resolve(step):
        if not isinstance(step, dict):
            return step
        if step.get('origin') == ORDERED:
            if _already_ordered(step):
                return step                        # not a first declaration
            parent_id = _origin_parent_id(step)
            if parent_id and origin_by_id.get(parent_id) == ORDERED:
                return step                         # trusted via inheritance
        try:
            return _pop.resolve_step_origin(step, channel, root)
        except Exception:
            downgraded = dict(step)
            downgraded['origin'] = PROPOSED
            return downgraded

    phases = plan.get('phases')
    if isinstance(phases, list):
        new_phases = []
        for ph in phases:
            if isinstance(ph, dict) and isinstance(ph.get('steps'), list):
                ph = dict(ph)
                ph['steps'] = [_resolve(s) for s in ph['steps']]
            new_phases.append(ph)
        plan = dict(plan)
        plan['phases'] = new_phases
        return plan

    steps = plan.get('steps')
    if isinstance(steps, list):
        plan = dict(plan)
        plan['steps'] = [_resolve(s) for s in steps]
    return plan


def read_plan(channel, root=None):
    """The stored plan of a channel, or {} when there is none / it is unreadable."""
    path = os.path.join(root or channels_dir(), channel, 'plan.json')
    try:
        with open(path, encoding='utf-8') as f:
            plan = json.load(f)
        return plan if isinstance(plan, dict) else {}
    except Exception:
        return {}


def write_plan(channel, plan, root=None):
    """MERGE a plan snapshot into <channels>/<channel>/plan.json. Returns (done,
    total), counting ORDERED steps only — same rule as the sidebar badge (spec K3).

    `plan` is the parsed dict; `root` overrides the channels dir (tests only). Before
    the merge, every step this snapshot itself declares `origin: ordered` on is run
    through plan_order_proof's check UNLESS it is not a first declaration (spec K2,
    see module docstring "PROOF WIRED IN AT THE WRITE" and "ONLY THE FIRST
    DECLARATION IS CHECKED"); a step whose proof does not hold, or whose check blows
    up, survives as PROPOSED rather than being lost (spec K9). Stamps `updated` so
    the sidebar can show staleness, writes atomically, then lazily registers the tab.
    Raises on a genuinely unwritable target: callers that must not fail a turn over a
    plan (runner.py) catch it themselves.

    The read, the origin resolution, the merge and the write all happen under
    channels/<id>/.plan.mutex (Д3 — see the module docstring's mutex section): two
    writers racing this same critical section used to let whichever wrote last
    silently erase the other's update. Best-effort, same as the mutex it mirrors —
    a writer that cannot acquire it within the deadline still writes.

    It MERGES rather than replaces (see the module docstring): the snapshot is the
    current picture, the file is the history, and history is not the snapshot's to
    delete."""
    if not isinstance(plan, dict):
        raise ValueError('plan must be a JSON object')
    # BEFORE makedirs, not inside ensure_registered: a bad id used to be caught (if at
    # all) only at registration time, by which point os.makedirs had already grown a
    # nested channels/proc/self/fd/0/ tree from a path passed as an id.
    if not valid_channel_id(channel):
        raise ValueError('bad channel id: %r' % (channel,))
    root = root or channels_dir()
    ch_dir = os.path.join(root, channel)
    os.makedirs(ch_dir, exist_ok=True)
    held = _plan_mutex_acquire(ch_dir)
    try:
        old_plan = read_plan(channel, root)
        resolved = _resolve_declared_origins(plan, old_plan, channel, root)
        merged = merge_plan(old_plan, resolved)
        merged['updated'] = time.strftime('%Y-%m-%d %H:%M')
        _write_json_atomic(os.path.join(ch_dir, 'plan.json'), merged)
    finally:
        if held:
            _plan_mutex_release(ch_dir)
    try:
        ensure_registered(root, channel, merged.get('goal'))
    except Exception:
        pass          # a tab that fails to auto-name must never lose the plan itself
    return _ordered_progress(collect_steps(merged))


def main(argv=None):
    """CLI kept compatible with the old set-plan.cjs / set-plan.sh:
        plan_store.py <channel> plan.json     |  echo '{...}' | plan_store.py <channel>
    A token that is an existing file is the source; any other token is the channel."""
    args = list(sys.argv[1:] if argv is None else argv)
    channel = os.environ.get('CHANNEL') or None
    source = None
    for a in args:
        if a == '-':
            continue
        if source is None and os.path.isfile(a):
            source = a
            continue
        channel = a
    channel = channel or 'main'

    raw = open(source, encoding='utf-8').read() if source else sys.stdin.read()
    if not raw.strip():
        sys.stderr.write('plan_store: no plan JSON provided (file or stdin).\n')
        return 1
    try:
        plan = json.loads(raw)
    except Exception as e:
        sys.stderr.write('plan_store: invalid JSON — %s\n' % e)
        return 1
    try:
        done, total = write_plan(channel, plan)
    except Exception as e:
        sys.stderr.write('plan_store: %s\n' % e)
        return 1
    # Report the MERGED goal, not the snapshot's: a partial snapshot legitimately omits
    # it, and echoing an empty line there reads like the goal was just erased.
    goal = read_plan(channel).get('goal') or ''
    print('[%s] plan: %s — %d/%d done' % (channel, goal, done, total))
    return 0


if __name__ == '__main__':
    sys.exit(main())
