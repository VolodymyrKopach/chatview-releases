"""Skill Store harvester.

Збирає каталог зовнішніх скілів/агентів у skills-library/remote-catalog.json.
Не чіпає index.json і UI, тому безпечно ганяти повторно. Збагачення тегами
(kind/hasCode/professions) робить enrich-catalog.py наступним кроком.

ЩО ЗМІНИЛА ФАЗА 3 і чому.
  1. ДЖЕРЕЛА. Було чотири курованих репозиторії, з них davila7 давав 1173 з 1552
     записів, тобто 75 відсотків каталогу приїжджало з ОДНОГО місця. Вибірка з
     одного агрегатора це не каталог, а дзеркало чужих смаків. Тепер до курованих
     додається ЖИВЕ ВИЯВЛЕННЯ через пошук GitHub за темами (claude-skill,
     claude-code-skill, ...), і частка найбільшого джерела рахується та друкується
     у звіті кожного запуску.
  2. ЛІЦЕНЗІЯ. Було 'see-repo' у всіх 1552 записів, тобто поле існувало, але не
     несло інформації, а картка безпеки показувала цю заглушку користувачу як факт. Тепер
     ліцензія береться з GitHub (search-відповідь уже містить license.spdx_id,
     курованим репозиторіям добираємо через /repos). Нема ліцензії в репозиторії:
     пишемо 'немає', а не заглушку.
  3. КАТЕГОРІЯ. Було 'remote' у всіх, тобто фасета була мертва. Тепер виводиться
     з ШЛЯХУ в репозиторії (агрегатори розкладають скіли по теках і це найсильніший
     сигнал), далі з тем репозиторію, далі з назви та опису.
  4. ДЕДУП по ХЕШУ ВМІСТУ SKILL.md, а не по назві. Агрегатори копіюють один одного
     дослівно; дедуп по назві при цьому і зайве зливав (різні скіли з назвою
     'code-reviewer'), і потрібне лишав (той самий файл під двома назвами).
  5. `updated` у каталозі і в КОЖНОМУ записі: без цього не було відповіді на
     питання «а коли це збиралось».

Запуск: python3 harvest-skills.py [--limit-repos N] [--no-discover]
Планово: node scripts/catalog-refresh.cjs (харвест + збагачення + ембединги).
"""
import os
import re
import json
import time
import shutil
import hashlib
import tempfile
import argparse
import datetime
import subprocess
import urllib.error
import urllib.parse
import urllib.request
import concurrent.futures as futures

DIR = os.path.dirname(os.path.abspath(__file__))
OUT = os.path.join(DIR, 'skills-library', 'remote-catalog.json')
SOURCES_OUT = os.path.join(DIR, 'skills-library', 'sources.json')
REPO_ROOT = os.path.abspath(os.path.join(DIR, '..', '..', '..'))

# Куровані джерела: перевірені руками, беруться завжди, незалежно від того, чи
# віддав щось пошук. include = префікси шляхів, які варто збирати.
CURATED = [
    {'repo': 'anthropics/skills', 'branch': 'main',
     'include': ['skills/']},
    {'repo': 'wshobson/agents', 'branch': 'main',
     'include': ['plugins/']},
    {'repo': 'davila7/claude-code-templates', 'branch': 'main',
     'include': ['cli-tool/components/agents/', 'cli-tool/components/skills/']},
    {'repo': 'VoltAgent/awesome-claude-code-subagents', 'branch': 'main',
     'include': ['categories/']},
    # awesome-списки: те саме ремесло, інші укладачі, тому інший зріз ринку
    {'repo': 'VoltAgent/awesome-agent-skills', 'branch': 'main', 'include': []},
    {'repo': 'sickn33/agentic-awesome-skills', 'branch': 'main', 'include': []},
    {'repo': 'hesreallyhim/awesome-claude-code', 'branch': 'main', 'include': []},
    {'repo': 'travis-burmaster/awesome-claude-skills', 'branch': 'main', 'include': []},
]

# Теми GitHub, за якими шукаємо нові джерела. Пошук по темах, а не по коду, бо
# code search вимагає токена, а токен у нас протух (див. звіт): пошук по
# репозиторіях працює без ключа і вже містить і зірки, і ліцензію.
TOPICS = [
    'claude-skill', 'claude-skills', 'claude-code-skill', 'claude-code-skills',
    'claude-code-agents', 'claude-code-subagents', 'agent-skills',
]
DISCOVER_PAGES = 2          # сторінок по 100 на тему
# Стеля на кількість ВИЯВЛЕНИХ джерел (беруться найзірковіші). Теми віддають
# близько 900 репозиторіїв, і спокуса взяти всі велика, але ціна прямо в
# швидкості пошуку: злиття векторів у skill_search.py це чистий Python, тобто
# O(розмір каталогу) на КОЖЕН запит. Стеля тримає каталог у розмірі, де пошук
# лишається миттєвим, а хвіст із двома зірками все одно не дає нових скілів,
# бо це переважно копії тих самих файлів (дедуп зливає близько 40 відсотків).
DISCOVER_LIMIT = 40
DISCOVER_MIN_STARS = 3      # нижче цього це чернетка, а не джерело
DISCOVER_MAX_KB = 120000    # 120 МБ: більше це моноріпо, клон якого не окупається
CLONE_WORKERS = 6           # вище GitHub починає відбивати паралельні клони

SKIP_DIRS = ('references/', 'examples/', 'node_modules/', '.github/', 'tests/',
             'test/', 'vendor/', 'dist/', 'build/', 'docs/api/')
SKIP_NAMES = ('readme.md', 'contributing.md', 'license.md', 'changelog.md',
              'code_of_conduct.md', 'security.md', 'index.md', 'todo.md',
              'roadmap.md', 'notes.md')
# Теки, у яких у чужих репозиторіях реально лежать скіли й агенти. Для виявлених
# джерел include порожній, тому фільтр робить саме цей список плюс ім'я SKILL.md.
SKILL_DIRS = ('skills/', 'agents/', 'subagents/', 'commands/', 'categories/',
              'plugins/', '.claude/')


# ── категорії ──────────────────────────────────────────────────────────────
# (ключ, емодзі, підпис, ключові слова). Порядок має значення: перше влучання
# виграє, тому вузьке стоїть вище за широке.
CATEGORIES = [
    ('meta',        '🧠', 'Мета та агенти',
     ['claude-code', 'subagent', 'sub-agent', 'agent-orchestr', 'orchestrat',
      'mcp', 'prompt-engineer', 'prompt engineer', 'skill-creat', 'skill creat',
      'hooks', 'slash-command', 'slash command', 'context-manage', 'meta-agent',
      'agent-framework', 'multi-agent', 'plugin-develop']),
    ('security',    '🔒', 'Безпека',
     ['security', 'pentest', 'penetration', 'vulnerab', 'exploit', 'owasp',
      'threat', 'cryptograph', 'appsec', 'secrets-scan', 'incident-response',
      'quality-security']),
    ('testing',     '🧪', 'Тестування',
     ['test', 'qa', 'e2e', 'unit-test', 'playwright', 'cypress', 'jest',
      'coverage', 'tdd', 'debugger', 'debugging']),
    ('devops',      '🛠', 'DevOps та інфра',
     ['devops', 'docker', 'kubernetes', 'k8s', 'terraform', 'ansible', 'ci-cd',
      'ci/cd', 'pipeline', 'deploy', 'infrastructure', 'cloud', 'aws', 'azure',
      'gcp', 'sre', 'observab', 'monitoring', 'incident', 'platform-engineer',
      'network', 'linux', 'shell', 'bash']),
    ('data-ai',     '🤖', 'Дані та AI',
     ['machine-learning', 'machine learning', 'deep-learning', 'llm', ' ai ',
      'ai-', 'rag', 'embedding', 'vector-db', 'data-engineer', 'data engineer',
      'etl', 'pipeline-data', 'nlp', 'computer-vision', 'mlops', 'model-train',
      'data-science', 'data science', 'database', 'sql', 'postgres', 'mongo']),
    ('design',      '🎨', 'Дизайн та UX',
     ['design', 'ui-', 'ux-', 'ui/ux', 'figma', 'css', 'tailwind', 'animation',
      'accessib', 'typograph', 'brand', 'wireframe', 'prototyp', 'creative',
      'illustrat', 'icon', 'color']),
    ('content',     '✍️', 'Контент і письмо',
     ['writing', 'writer', 'copywrit', 'blog', 'documentation', 'docs',
      'technical-writ', 'editor', 'proofread', 'video', 'podcast', 'script',
      'storytell', 'newsletter', 'translation', 'transcri']),
    ('marketing',   '📣', 'Маркетинг',
     ['marketing', 'growth', 'seo', 'ads', 'advertis', 'campaign', 'funnel',
      'social-media', 'social media', 'email-market', 'lead-gen', 'outreach',
      'landing']),
    ('business',    '💼', 'Бізнес і продукт',
     ['business', 'product-manage', 'product manage', 'startup', 'strategy',
      'pricing', 'sales', 'finance', 'revenue', 'okr', 'roadmap', 'backlog',
      'stakeholder', 'monetiz', 'legal', 'contract', 'compliance']),
    ('research',    '🔬', 'Ресерч та аналітика',
     ['research', 'analysis', 'analytic', 'competitor', 'market-', 'survey',
      'benchmark', 'due-diligence', 'fact-check', 'metrics', 'dashboard',
      'reporting', 'statistic', 'experiment', 'ab-test', 'a/b']),
    ('productivity', '📋', 'Продуктивність',
     ['productiv', 'note-taking', 'notes', 'pdf', 'docx', 'xlsx', 'pptx',
      'spreadsheet', 'calendar', 'email-', 'task-manage', 'project-manage',
      'planning', 'workflow', 'automation', 'scraper', 'obsidian', 'notion']),
    ('specialized', '🏛', 'Спеціалізоване',
     ['medical', 'health', 'clinical', 'education', 'teaching', 'tutor',
      'course', 'game-develop', 'game develop', 'gamedev', 'blockchain', 'web3',
      'crypto', 'iot', 'embedded', 'robotics', 'bioinform', 'geospatial',
      'trading', 'accounting', 'hr-', 'recruit']),
    ('development', '💻', 'Розробка',
     ['backend', 'frontend', 'fullstack', 'api', 'react', 'vue', 'angular',
      'svelte', 'next.js', 'nextjs', 'node', 'python', 'javascript',
      'typescript', 'golang', 'rust', 'java', 'kotlin', 'swift', 'php', 'ruby',
      'c++', 'c#', 'dotnet', 'mobile', 'ios', 'android', 'flutter', 'code-review',
      'refactor', 'architect', 'microservice', 'graphql', 'websocket', 'compiler',
      'developer', 'engineer', 'programming', 'coding', 'git']),
]
CATEGORY_LABELS = {k: (e, l) for (k, e, l, _kw) in CATEGORIES}
CATEGORY_LABELS['other'] = ('🧩', 'Інше')   # запасне відро теж мусить мати підпис

# Теми репозиторію, які НЕ несуть категорії. Кожен другий репозиторій має тему
# claude-code, і на першому прогоні це затягнуло 2027 записів у «мета» просто
# тому, що вони лежать у репозиторії про Claude Code. Тема про походження, а не
# про ремесло скіла, тому такі теми з класифікації прибираємо.
STOP_TOPICS = {
    'claude', 'claude-code', 'claude-ai', 'claude-skill', 'claude-skills',
    'claude-code-skill', 'claude-code-skills', 'claude-code-agents',
    'claude-code-subagents', 'claude-3', 'claude-4', 'anthropic', 'ai', 'llm',
    'agent', 'agents', 'agentic', 'agent-skills', 'skill', 'skills',
    'subagent', 'subagents', 'awesome', 'awesome-list', 'plugin', 'plugins',
    'automation', 'productivity', 'developer-tools', 'cli', 'tools', 'ai-agents',
    'ai-tools', 'prompt', 'prompts', 'llm-agent', 'openai', 'gpt',
}


def slugify(s):
    s = re.sub(r'[^a-z0-9]+', '-', (s or '').lower()).strip('-')
    return s or 'skill'


def now_iso():
    return datetime.datetime.now(datetime.timezone.utc).replace(
        microsecond=0).isoformat().replace('+00:00', 'Z')


# ── GitHub API ─────────────────────────────────────────────────────────────
def env_token():
    """Токен із .env репозиторію. Скриптам читати .env можна: заборона на ключі
    у коді стосується ЗАСТОСУНКУ (там строгий BYOK), а не тулінгу.

    Токен перевіряється живим запитом, бо мовчазний 401 виглядає точно як
    порожній каталог, і саме на цьому можна згаяти годину."""
    tok = ''
    p = os.path.join(REPO_ROOT, '.env')
    try:
        with open(p, encoding='utf-8') as f:
            for line in f:
                m = re.match(r'\s*(GITHUB_TOKEN|GITHUB_PAT|GH_TOKEN)\s*=\s*(.+)',
                             line)
                if m and not tok:
                    tok = m.group(2).strip().strip('"\'')
    except Exception:
        return ''
    if not tok:
        return ''
    try:
        gh_get('https://api.github.com/rate_limit', token=tok)
        return tok
    except Exception as e:
        print(f'  ! токен GITHUB з .env не приймається ({e}); '
              f'працюю без ключа (пошук 10 запитів/хв)')
        return ''


_LAST_SEARCH = [0.0]


def gh_get(url, token='', tries=3):
    headers = {'Accept': 'application/vnd.github+json',
               'User-Agent': 'logopsis-skill-harvester'}
    if token:
        headers['Authorization'] = f'Bearer {token}'
    last = None
    for attempt in range(tries):
        req = urllib.request.Request(url, headers=headers)
        try:
            with urllib.request.urlopen(req, timeout=40) as r:
                return json.loads(r.read().decode('utf-8'))
        except urllib.error.HTTPError as e:
            last = e
            if e.code in (403, 429):
                # ліміт: чекаємо до вікна скидання, але не довше хвилини за спробу
                reset = e.headers.get('X-RateLimit-Reset')
                wait = 20.0
                if reset:
                    try:
                        wait = max(2.0, min(65.0, float(reset) - time.time() + 2))
                    except Exception:
                        pass
                time.sleep(wait)
                continue
            raise
        except Exception as e:
            last = e
            time.sleep(2 + attempt * 3)
    raise last if last else RuntimeError('gh_get failed')


def gh_search_repos(query, token='', page=1, per_page=100):
    """Пошук репозиторіїв з ручним темпом. Без ключа GitHub дає 10 запитів на
    хвилину, тому між запитами тримаємо паузу самі: інакше половина тем приїде
    порожньою і каталог мовчки поменшає."""
    gap = 2.5 if token else 7.0
    delta = time.time() - _LAST_SEARCH[0]
    if delta < gap:
        time.sleep(gap - delta)
    _LAST_SEARCH[0] = time.time()
    url = ('https://api.github.com/search/repositories?q='
           + urllib.parse.quote(query)
           + f'&sort=stars&order=desc&per_page={per_page}&page={page}')
    return gh_get(url, token=token)


def license_of(item):
    """SPDX-ліцензія з відповіді GitHub. 'NOASSERTION' означає, що GitHub файл
    бачить, але розпізнати не може: для користувача це не менш важливо, ніж чесне
    «немає», тому не змішуємо їх в одне."""
    lic = item.get('license')
    if isinstance(lic, dict):
        sid = (lic.get('spdx_id') or '').strip()
        if sid and sid != 'NOASSERTION':
            return sid
        if sid == 'NOASSERTION':
            return 'нестандартна'
    return 'немає'


def discover_repos(token='', pages=DISCOVER_PAGES, cap=None):
    """Виявити джерела через пошук за темами. -> [spec] з зірками й ліцензією."""
    found = {}
    for topic in TOPICS:
        got = 0
        for page in range(1, pages + 1):
            try:
                d = gh_search_repos(f'topic:{topic}', token=token, page=page)
            except Exception as e:
                print(f'  ! пошук теми {topic} стор.{page}: {e}')
                break
            items = d.get('items') or []
            if not items:
                break
            for it in items:
                full = it.get('full_name')
                if not full or full in found:
                    continue
                if (it.get('stargazers_count') or 0) < DISCOVER_MIN_STARS:
                    continue
                if (it.get('size') or 0) > DISCOVER_MAX_KB:
                    continue
                if it.get('archived') or it.get('disabled'):
                    continue
                found[full] = {
                    'repo': full,
                    'branch': it.get('default_branch') or 'main',
                    'stars': it.get('stargazers_count') or 0,
                    'license': license_of(it),
                    'topics': it.get('topics') or [],
                    'include': [],
                    'discovered': topic,
                }
                got += 1
            if len(items) < 100:
                break
        print(f'  тема {topic}: +{got} репозиторіїв (разом {len(found)})')
    out = sorted(found.values(), key=lambda s: -s['stars'])
    return out[:cap] if cap else out


def fill_curated_meta(specs, token=''):
    """Зірки, ліцензія і теми курованих репозиторіїв з /repos. Це core-ліміт
    (60/год без ключа), а курованих одиниці, тож вкладаємось із запасом."""
    for sp in specs:
        try:
            d = gh_get(f'https://api.github.com/repos/{sp["repo"]}', token=token)
            sp['stars'] = d.get('stargazers_count') or sp.get('stars') or 0
            sp['license'] = license_of(d)
            sp['topics'] = d.get('topics') or []
            sp['branch'] = d.get('default_branch') or sp.get('branch') or 'main'
        except Exception as e:
            print(f'  ! мета {sp["repo"]}: {e}')
            sp.setdefault('stars', 0)
            sp.setdefault('license', 'немає')
            sp.setdefault('topics', [])
    return specs


# ── розбір markdown ────────────────────────────────────────────────────────
def parse_md(text):
    """-> (name, description, tags, had_frontmatter). Справжні скіли й агенти
    мають YAML-frontmatter, а доки, специфікації й нотатки ні, тому had_fm це
    ворота якості, які відсікають шум."""
    name = desc = ''
    tags = []
    had_fm = False
    if text.startswith('---'):
        end = text.find('\n---', 3)
        if end != -1:
            had_fm = True
            fm = text[3:end]
            lines = fm.splitlines()
            i = 0
            while i < len(lines):
                line = lines[i]
                mn = re.match(r'\s*name\s*:\s*(.+)', line)
                if mn and not name:
                    name = mn.group(1).strip().strip('"\'')
                mtg = re.match(r'\s*(?:tags|keywords|topics)\s*:\s*(.*)', line)
                if mtg and not tags:
                    val = mtg.group(1).strip()
                    if val.startswith('['):
                        tags = [t.strip().strip('"\'') for t in
                                val.strip('[]').split(',') if t.strip()]
                    elif val:
                        tags = [t.strip() for t in val.split(',') if t.strip()]
                    else:
                        j = i + 1
                        while j < len(lines) and re.match(r'\s*-\s+', lines[j]):
                            tags.append(re.sub(r'\s*-\s+', '', lines[j]).strip()
                                        .strip('"\''))
                            j += 1
                mdsc = re.match(r'\s*description\s*:\s*(.*)', line)
                if mdsc and not desc:
                    val = mdsc.group(1).strip().strip('"\'')
                    if val in ('|', '|-', '|+', '>', '>-', '>+', ''):
                        block, j = [], i + 1
                        while j < len(lines) and (lines[j].startswith('  ')
                                                  or not lines[j].strip()):
                            block.append(lines[j].strip())
                            j += 1
                        desc = ' '.join(b for b in block if b)
                    else:
                        desc = val
                i += 1
            text = text[end + 4:]
    if not name:
        m = re.search(r'^#\s+(.+)', text, re.M)
        if m:
            name = m.group(1).strip()
    if not desc:
        for line in text.splitlines():
            t = line.strip()
            if t and not t.startswith('#') and not t.startswith('---'):
                desc = t
                break
    desc = re.sub(r'\s+', ' ', desc).strip()[:300]
    tags = [t[:32] for t in tags if t][:12]
    return name.strip(), desc, tags, had_fm


def content_hash(text):
    """Відбиток ВМІСТУ скіла для дедупу. Нормалізуємо пробіли й регістр, бо
    агрегатори переносять файл з іншими відступами й іншим переносом рядків, а
    це той самий скіл. Frontmatter лишаємо в розрахунку: він частина скіла."""
    norm = re.sub(r'\s+', ' ', (text or '')).strip().lower()
    return hashlib.sha1(norm.encode('utf-8')).hexdigest()[:20]


def derive_category(rel_path, tags, name, desc, repo_topics):
    """Категорія з сигналів за спаданням довіри: шлях у репозиторії, власні теги
    скіла, назва з описом, і тільки в останню чергу теми репозиторію.

    Шлях перший тому, що агрегатори САМІ розклали скіли по теках
    (cli-tool/components/skills/creative-design/..., categories/04-quality-security/...),
    і це класифікація, зроблена людиною, яка тримала файл у руках.

    Теми репозиторію ОСТАННІ, і це виправлення першого прогону. Тема описує
    РЕПОЗИТОРІЙ, а не скіл, тому коли вона стояла нарівні з тегами, весь
    агрегатор їхав в одну категорію одним махом: 1019 скілів з одного репо
    отримали «мета» рівно тому, що репозиторій про агентів. Це та сама «одна
    категорія на всіх», від якої ми тут і йдемо, просто під іншою назвою."""
    path_txt = ' ' + re.sub(r'[^a-z0-9]+', ' ',
                            (rel_path or '').lower()).strip() + ' '
    tag_txt = ' ' + ' '.join(str(t).lower() for t in (tags or [])) + ' '
    text_txt = ' ' + f'{name} {desc}'.lower() + ' '
    topic_txt = ' ' + ' '.join(str(t).lower() for t in (repo_topics or [])
                               if str(t).lower() not in STOP_TOPICS) + ' '
    for source in (path_txt, tag_txt, text_txt, topic_txt):
        for key, _e, _l, kws in CATEGORIES:
            if any(kw in source for kw in kws):
                return key
    return 'other'


# ── збір одного репозиторію ────────────────────────────────────────────────
def wanted(rel, include):
    low = rel.lower()
    if any(sd in low for sd in SKIP_DIRS):
        return False
    if include:
        return any(rel.startswith(inc) for inc in include)
    # виявлені джерела: або файл зветься SKILL.md, або лежить у профільній теці
    if os.path.basename(low) == 'skill.md':
        return True
    return any(sd in low for sd in SKILL_DIRS)


def harvest_repo(spec, tmp):
    repo = spec['repo']
    owner = repo.split('/')[0]
    branch = spec.get('branch') or 'main'
    stars = spec.get('stars') or 0
    lic = spec.get('license') or 'немає'
    topics = spec.get('topics') or []
    rd = os.path.join(tmp, slugify(repo))
    # Клон з повтором. Паралельні клони GitHub іноді відбиває, і на першому
    # прогоні через це мовчки випало чотири джерела, тобто каталог між двома
    # запусками того самого коду відрізнявся на 600 записів. Повтор робить
    # результат відтворюваним, а причину відмови лишаємо ХВОСТОМ stderr: git
    # пише там суть, а на початку в нього лише «Cloning into…».
    err = ''
    for attempt in range(3):
        if attempt:
            time.sleep(2 + attempt * 3)
            shutil.rmtree(rd, ignore_errors=True)
        try:
            subprocess.run(['git', 'clone', '--depth', '1', '-b', branch,
                            f'https://github.com/{repo}.git', rd],
                           check=True, capture_output=True, timeout=300)
            err = ''
            break
        except subprocess.CalledProcessError as e:
            err = ('clone failed: '
                   + (e.stderr or b'').decode('utf-8', 'replace').strip()[-140:])
        except subprocess.TimeoutExpired:
            err = 'clone timeout'
        except Exception as e:
            err = f'clone error: {e}'
    if err:
        return repo, [], err

    out = []
    stamp = now_iso()
    for dp, dirs, files in os.walk(rd):
        dirs[:] = [d for d in dirs if d != '.git']
        rel_dir = os.path.relpath(dp, rd).replace('\\', '/')
        if rel_dir == '.':
            rel_dir = ''
        for fn in files:
            if not fn.endswith('.md'):
                continue
            if fn.lower() in SKIP_NAMES:
                continue
            rel = (rel_dir + '/' + fn).lstrip('/')
            if not wanted(rel, spec.get('include') or []):
                continue
            try:
                text = open(os.path.join(dp, fn), encoding='utf-8',
                            errors='replace').read()
            except Exception:
                continue
            if len(text) < 60:
                continue
            name, desc, tags, had_fm = parse_md(text)
            if not had_fm or not name or not desc:
                continue  # ворота якості: без frontmatter це не скіл
            stem = os.path.splitext(fn)[0]
            if stem.lower() == 'skill':
                stem = os.path.basename(dp)
            out.append({
                'id': slugify(f'{owner}-{stem}'),
                'name': name[:80],
                'description': desc,
                'category': derive_category(rel, tags, name, desc, topics),
                'tags': tags,
                'source': repo,
                'license': lic,
                'install': 'manual-git',
                'url': f'https://github.com/{repo}/blob/{branch}/{rel}',
                'badge': 'yellow',
                'icon': '🧩',
                'stars': stars,
                'path': rel,
                'hash': content_hash(text),
                'updated': stamp,
            })
    return repo, out, None


# ── дедуп ──────────────────────────────────────────────────────────────────
def dedupe(entries):
    """Злити однаковий ВМІСТ. Переможець це запис із найзірковішого джерела;
    решта не зникає безслідно, а лишається списком `alsoIn`, бо «цей скіл лежить
    ще у трьох агрегаторах» це сигнал довіри, а не сміття."""
    by_hash = {}
    order = sorted(entries, key=lambda e: (-(e.get('stars') or 0),
                                           e.get('source') or '',
                                           e.get('path') or ''))
    merged = 0
    for e in order:
        h = e.get('hash')
        cur = by_hash.get(h)
        if cur is None:
            e['alsoIn'] = []
            by_hash[h] = e
            continue
        merged += 1
        src = e.get('source')
        if src and src != cur.get('source') and src not in cur['alsoIn']:
            cur['alsoIn'].append(src)
    kept = list(by_hash.values())

    # id мають бути унікальні і СТАБІЛЬНІ між запусками, інакше кеш ембедингів
    # вважає перейменований запис новим і платимо за нього ще раз. Порядок вище
    # детермінований, тому й суфікси лягають однаково.
    seen = {}
    for e in sorted(kept, key=lambda x: (-(x.get('stars') or 0),
                                         x.get('source') or '',
                                         x.get('path') or '')):
        base = e['id']
        if base not in seen:
            seen[base] = 1
            continue
        repo_short = slugify(e['source'].split('/')[-1])
        cand = slugify(f'{base}-{repo_short}')
        if cand in seen:
            cand = f'{base}-{e["hash"][:6]}'
        e['id'] = cand
        seen[cand] = 1
    return kept, merged


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--no-discover', action='store_true',
                    help='тільки куровані джерела (швидко, без мережі на пошук)')
    ap.add_argument('--limit-repos', type=int, default=DISCOVER_LIMIT,
                    help='стеля на кількість ВИЯВЛЕНИХ репозиторіїв '
                         f'(типово {DISCOVER_LIMIT}, 0 = без стелі)')
    ap.add_argument('--pages', type=int, default=DISCOVER_PAGES)
    ap.add_argument('--reuse-sources', action='store_true',
                    help='взяти список джерел з sources.json минулого запуску '
                         '(без пошуку: не палить ліміт 10 запитів/хв)')
    args = ap.parse_args()

    t0 = time.time()
    token = env_token()
    print(f'GitHub: {"з токеном" if token else "без токена (пошук 10/хв)"}')

    if args.reuse_sources and os.path.exists(SOURCES_OUT):
        prev = json.load(open(SOURCES_OUT, encoding='utf-8'))
        specs = [s for s in (prev.get('repos') or []) if s.get('repo')]
        print(f'джерела з минулого запуску ({prev.get("updated")}): {len(specs)}')
    else:
        specs = [dict(s) for s in CURATED]
        print('мета курованих джерел…')
        fill_curated_meta(specs, token=token)
        curated_names = {s['repo'] for s in specs}
        if not args.no_discover:
            print('виявлення джерел за темами…')
            disc = discover_repos(token=token, pages=args.pages,
                                  cap=args.limit_repos or None)
            specs += [s for s in disc if s['repo'] not in curated_names]
    print(f'джерел до клонування: {len(specs)}')

    tmp = tempfile.mkdtemp(prefix='harvest-')
    all_skills = []
    per_repo = {}
    failed = []
    try:
        with futures.ThreadPoolExecutor(max_workers=CLONE_WORKERS) as ex:
            jobs = {ex.submit(harvest_repo, sp, tmp): sp for sp in specs}
            done_n = 0
            for fut in futures.as_completed(jobs):
                done_n += 1
                repo, items, err = fut.result()
                if err:
                    failed.append({'repo': repo, 'error': err})
                if items:
                    all_skills.extend(items)
                    per_repo[repo] = len(items)
                if done_n % 25 == 0 or done_n == len(specs):
                    print(f'  клоновано {done_n}/{len(specs)}, '
                          f'зібрано {len(all_skills)}')
    finally:
        shutil.rmtree(tmp, ignore_errors=True)

    deduped, merged = dedupe(all_skills)
    deduped.sort(key=lambda x: (-(x.get('stars') or 0), x['name'].lower()))

    stamp = now_iso()
    by_src = {}
    for s in deduped:
        by_src[s['source']] = by_src.get(s['source'], 0) + 1
    top_src, top_n = ('', 0)
    if by_src:
        top_src, top_n = max(by_src.items(), key=lambda kv: kv[1])
    by_cat = {}
    for s in deduped:
        by_cat[s['category']] = by_cat.get(s['category'], 0) + 1
    real_lic = sum(1 for s in deduped
                   if s.get('license') not in ('немає', 'see-repo', None, ''))

    payload = {
        'version': 2,
        'kind': 'remote-catalog',
        'count': len(deduped),
        'updated': stamp,
        'harvest': {
            'seconds': round(time.time() - t0, 1),
            'reposTried': len(specs),
            'reposWithSkills': len(per_repo),
            'reposFailed': len(failed),
            'harvestedRaw': len(all_skills),
            'dupesMerged': merged,
            'topSource': top_src,
            'topSourceShare': round(100.0 * top_n / max(1, len(deduped)), 1),
            'withRealLicense': real_lic,
            'authenticated': bool(token),
        },
        'sources': [{'repo': r, 'skills': n,
                     'stars': next((s.get('stars') or 0) for s in specs
                                   if s['repo'] == r)}
                    for r, n in sorted(by_src.items(), key=lambda kv: -kv[1])],
        'categoriesIndex': [
            {'key': k, 'emoji': CATEGORY_LABELS.get(k, ('🧩', k))[0],
             'label': CATEGORY_LABELS.get(k, ('🧩', k))[1], 'count': n}
            for k, n in sorted(by_cat.items(), key=lambda kv: -kv[1])],
        'skills': deduped,
    }
    tmpf = OUT + '.tmp'
    with open(tmpf, 'w', encoding='utf-8') as f:
        json.dump(payload, f, ensure_ascii=False, indent=1)
    os.replace(tmpf, OUT)

    with open(SOURCES_OUT, 'w', encoding='utf-8') as f:
        json.dump({'updated': stamp, 'tried': len(specs),
                   'failed': failed[:80],
                   # повний спек, а не звіт: --reuse-sources читає рівно цей файл
                   'repos': [{'repo': s['repo'], 'stars': s.get('stars') or 0,
                              'license': s.get('license') or 'немає',
                              'branch': s.get('branch') or 'main',
                              'topics': s.get('topics') or [],
                              'include': s.get('include') or [],
                              'skills': per_repo.get(s['repo'], 0),
                              'discovered': s.get('discovered', 'curated')}
                             for s in sorted(specs, key=lambda x: -(x.get('stars') or 0))]},
                  f, ensure_ascii=False, indent=1)

    print(f'\nзібрано сирих: {len(all_skills)} | після дедупу: {len(deduped)} '
          f'| злито дублів: {merged}')
    print(f'джерел з результатом: {len(per_repo)} | не клонувались: {len(failed)}')
    print(f'найбільше джерело: {top_src} = {top_n} '
          f'({payload["harvest"]["topSourceShare"]}%)')
    print(f'з реальною ліцензією: {real_lic}/{len(deduped)}')
    print('категорії: ' + ', '.join(f'{k}={n}' for k, n in
                                    sorted(by_cat.items(), key=lambda kv: -kv[1])))
    print(f'час: {payload["harvest"]["seconds"]}с | записано: {OUT}')


if __name__ == '__main__':
    main()
