#!/usr/bin/env python3
"""Каталог доступного до встановлення як КЕШ у `<дім>/library/`, а не як бандл.

ЩО ЦЕ І ЧОМУ (specs/user-owned-entities, розділ 6.3). `skills-library` це дві
різні за природою речі в одній теці. Перша це ПРОДУКТ-МІНІМУМ: наш власний перелік
помічників (`index.json`), каталог персон, сценарій онбордингу і тіла семи наших
помічників, разом близько 264 КБ. Без них панель Помічників не порожня, а мертва:
`server.py:1633` відкриває `index.json` без запасного шляху. Друга це КАТАЛОГ
ДОСТУПНОГО, тобто врожай `harvest-skills.py` з GitHub (`remote-catalog.json`,
5.6 МБ, близько 7400 чужих скілів). Це не двигун і не шаблон, а знімок чужого
світу на дату збору, і саме тому йому не місце в артефакті:

  1. він протухає без нас. Скіл, опублікований завтра, не існує для людини, яка
     поставила апку сьогодні, доки ми не випустимо нову збірку;
  2. він у двадцять два рази важчий за все, заради чого лежить поруч;
  3. він принципово не є частиною застосунку. Апка везе двигун, вміст знаходить.

Тому в бандлі лишається ПРОДУКТ-МІНІМУМ, а каталог доступного тягнеться з мережі
на вимогу і живе в `<дім>/library/` під тим самим іменем.

ЧОМУ ОКРЕМА ТЕКА `library/`, А НЕ ПОРУЧ У `skills-library/`. Тека `skills-library`
у домі це ДЗЕРКАЛО бандла: `entry.seed_readonly_assets` копіює її при кожному
запуску з `dirs_exist_ok=True`, тобто перетирає. Кеш, покладений туди, живе рівно
до наступного оновлення, і зникає він мовчки. `library/` не засівається ніким, і
це єдина причина, чому вона окрема (розкладка кореня зі спеки, розділ 6.1).

ПОРЯДОК ДЖЕРЕЛ, і він важливий для К6:
  1. `<lib_dir>/remote-catalog.json`, якщо він є. У дев-репо і в особистій збірці
     власника файл лежить на місці, тому для них НЕ МІНЯЄТЬСЯ НІЧОГО: жодного
     походу в мережу, жодної нової затримки, каталог як був;
  2. `<дім>/library/remote-catalog.json`, тобто вже завантажений кеш;
  3. завантаження з мережі у фоні.

ЧОМУ ФОНОМ, А НЕ ПРЯМО В ЗАПИТІ. `skill_search.corpus()` кличеться з обробника
`/api/helpers`, тобто в HTTP-потоці. Синхронне завантаження 5.6 МБ на повільній
мережі означає екран, який не відповідає невідомо скільки. Тому перше звернення
ЗАПУСКАЄ завантаження і одразу повертає порожній каталог із причиною «тягнемо», а
наступне вже бачить файл. Блокуючий режим лишається для CLI і тестів, де саме він
і потрібен.

ЧОМУ ПРИЧИНА ЗАПИСУЄТЬСЯ НА ДИСК (`status.json`). Мовчазна деградація це названий
ризик спеки: сутність не підтягнулась, і людина бачить порожньо без пояснення.
Стан лежить файлом поруч із кешем, тому його бачить і наступний процес, і людина,
яка відкрила теку. Тексти тут МІНІМАЛЬНІ навмисно: подача порожніх станів це
окрема робота, і цей модуль постачає їй факт, а не оформлення.

АДРЕСА ДЖЕРЕЛА НЕ ВПИСАНА СЮДИ РЯДКОМ. Вона виводиться з адреси каналу оновлень
(`chatview_updater.LEGACY_UPDATE_URL`), тобто з того самого місця, звідки апка вже
законно бере оновлення. Це не економія рядка: канал це КОНФІГУРАЦІЯ збірки, а не
константа коду, тому другий рядок з тією самою адресою тут означав би друге місце,
яке треба памʼятати перенастроїти. Канал не налаштований = каталог не тягнеться, і
`catalog_url()` каже це чесним None замість запиту в нікуди.
"""
import io
import os
import json
import time
import threading
import urllib.error
import urllib.request

#: Тека кешу під коренем даних. Рівно та, що в розкладці спеки (розділ 6.1).
CACHE_DIR_NAME = 'library'
#: Імʼя файлу каталогу лишається тим самим, що в `skills-library`: так один і той
#: самий читач (`skill_search.Catalog`) працює з обома місцями без розгалуження.
CATALOG_NAME = 'remote-catalog.json'
STATUS_NAME = 'status.json'

#: Скільки кеш вважається свіжим. Тиждень, бо збирач каталогу і сам ходить приблизно
#: раз на добу, а перезавантажувати 5.6 МБ частіше означає платити трафіком за
#: записи, які майже не змінились.
TTL = 7 * 24 * 3600
#: Скільки не повторювати спробу після невдачі. Без цього кожне відкриття панелі
#: на машині без мережі ставило б новий похід у мережу, тобто спінер назавжди.
RETRY_AFTER = 15 * 60
TIMEOUT = 25.0
#: Стеля розміру. Каталог 5.6 МБ, тож 64 МБ це «щось пішло не так» (перенаправлення
#: на сторінку входу, підмінений хост), а не великий каталог.
MAX_BYTES = 64 * 1024 * 1024
UA = 'logopsis-library-cache'

#: Ті самі імена, що й у станах: рядок їде в API і в UI, тому він частина контракту.
S_BUNDLED = 'bundled'      # каталог лежить поруч (дев-репо, особиста збірка)
S_CACHED = 'cached'        # завантажений раніше, лежить у <дім>/library
S_FETCHING = 'fetching'    # тягнемо просто зараз
S_OFFLINE = 'offline'      # мережі немає
S_REFUSED = 'refused'      # джерело відповіло помилкою
S_BROKEN = 'broken'        # завантажилось, але це не каталог
S_DISABLED = 'disabled'    # вимкнено середовищем

#: Мінімальні тексти. Одне речення причини плюс одна дія. Оформлення порожніх
#: станів робиться окремо і поверх цього, тому тут нема ні розмітки, ні порад.
REASON = {
    S_FETCHING: 'Каталог помічників завантажується.',
    S_OFFLINE: 'Каталог помічників не завантажено: немає звʼязку з мережею.',
    S_REFUSED: 'Каталог помічників не завантажено: джерело відповіло помилкою.',
    S_BROKEN: 'Каталог помічників завантажився пошкодженим.',
    S_DISABLED: 'Завантаження каталогу вимкнено налаштуванням.',
}

_lock = threading.Lock()
_inflight = set()


# ── шляхи ───────────────────────────────────────────────────────────────────

def home_dir(env=None):
    """Корінь даних користувача. Та сама формула, що й `server.py:36`."""
    env = os.environ if env is None else env
    return env.get('LOGOPSIS_HOME') or os.path.dirname(os.path.abspath(__file__))


def cache_dir(home=None, env=None):
    return os.path.join(home or home_dir(env), CACHE_DIR_NAME)


def cached_catalog(home=None, env=None):
    return os.path.join(cache_dir(home, env), CATALOG_NAME)


def status_path(home=None, env=None):
    return os.path.join(cache_dir(home, env), STATUS_NAME)


def catalog_url(env=None):
    """Звідки тягнемо. -> адреса або None, якщо завантаження вимкнено.

    `LOGOPSIS_CATALOG_URL` це і перемикач для дев/стейджа, і єдиний спосіб зробити
    тест на завантаження без походу в справжній інтернет. Значення `0`/`off` вимикає
    завантаження зовсім: машина в закритому контурі мусить мати спосіб сказати
    «не ходи», інакше вона щоразу платить таймаутом за відповідь, яку вже знає."""
    env = os.environ if env is None else env
    override = (env.get('LOGOPSIS_CATALOG_URL') or '').strip()
    if override:
        return None if override.lower() in ('0', 'off', 'no', 'false') else override
    try:
        from chatview_updater import LEGACY_UPDATE_URL as base
    except Exception:
        return None
    # Порожня адреса означає, що канал релізів не налаштований узагалі. Тоді тут теж
    # нема звідки тягнути: без цієї перевірки `''.rsplit` дав би шлях '/catalog/…',
    # тобто запит у нікуди, який виглядав би як зламана мережа.
    if not base:
        return None
    return base.rsplit('/', 1)[0] + '/catalog/' + CATALOG_NAME


# ── стан ────────────────────────────────────────────────────────────────────

def _read_status(home=None, env=None):
    try:
        with io.open(status_path(home, env), encoding='utf-8') as fh:
            data = json.load(fh)
        return data if isinstance(data, dict) else {}
    except Exception:
        return {}


def _write_status(data, home=None, env=None):
    """Стан на диск. Кращий-зусиль: невдача запису стану не сміє валити читання
    каталогу, бо це підказка про проблему, а не сама робота."""
    try:
        d = cache_dir(home, env)
        os.makedirs(d, exist_ok=True)
        tmp = status_path(home, env) + '.tmp'
        with io.open(tmp, 'w', encoding='utf-8') as fh:
            json.dump(data, fh, ensure_ascii=False, indent=1)
        os.replace(tmp, status_path(home, env))
    except OSError:
        pass
    return data


def _state(state, **extra):
    out = {'state': state, 'ok': state in (S_BUNDLED, S_CACHED),
           'reason': REASON.get(state, ''), 'at': int(time.time())}
    out.update(extra)
    return out


def status(lib_dir=None, home=None, env=None):
    """Що зараз із каталогом. -> {state, ok, reason, path, url, bytes, at}

    Читається і без жодного попереднього звернення, тому придатне для екрана, який
    малюється ДО першого пошуку."""
    local = _local_catalog(lib_dir, home, env)
    if local:
        st = S_BUNDLED if (lib_dir and local.startswith(os.path.join(lib_dir, ''))
                           or local == os.path.join(lib_dir or '', CATALOG_NAME)) \
            else S_CACHED
        try:
            size = os.path.getsize(local)
        except OSError:
            size = 0
        return _state(st, path=local, bytes=size, url=catalog_url(env))
    saved = _read_status(home, env)
    if saved.get('state'):
        saved.setdefault('path', None)
        saved.setdefault('reason', REASON.get(saved['state'], ''))
        saved['ok'] = False
        return saved
    return _state(S_FETCHING if catalog_url(env) else S_DISABLED,
                  path=None, url=catalog_url(env))


# ── саме завантаження ───────────────────────────────────────────────────────

def _local_catalog(lib_dir=None, home=None, env=None):
    """Наявний каталог: спершу поруч із продуктом-мінімумом, потім у кеші."""
    if lib_dir:
        p = os.path.join(lib_dir, CATALOG_NAME)
        if os.path.isfile(p) and os.path.getsize(p) > 0:
            return p
    p = cached_catalog(home, env)
    if os.path.isfile(p) and os.path.getsize(p) > 0:
        return p
    return None


def _stale(path):
    try:
        return (time.time() - os.path.getmtime(path)) > TTL
    except OSError:
        return True


def _classify(exc):
    """Виняток мережі -> стан. Класифікуємо ОДРАЗУ, бо через пів години вже ніхто
    не відрізнить «немає інтернету» від «нас не пустили»."""
    if isinstance(exc, urllib.error.HTTPError):
        return S_REFUSED, 'джерело відповіло %s' % exc.code
    if isinstance(exc, urllib.error.URLError):
        return S_OFFLINE, str(getattr(exc, 'reason', exc))[:120]
    return S_OFFLINE, str(exc)[:120]


def fetch_now(home=None, env=None, url=None, timeout=TIMEOUT):
    """Завантажити каталог СИНХРОННО. -> (шлях або None, стан).

    Ніколи не кидає: гірший сценарій це записаний стан із причиною. Пише атомарно
    (`.tmp` + `os.replace`), тому обірваний посеред завантаження файл не стає
    «наполовину каталогом», який потім тихо парситься в порожнечу."""
    url = url or catalog_url(env)
    if not url:
        return None, _write_status(_state(S_DISABLED, path=None), home, env)
    dst = cached_catalog(home, env)
    tmp = dst + '.tmp'
    try:
        os.makedirs(cache_dir(home, env), exist_ok=True)
        req = urllib.request.Request(url, headers={'User-Agent': UA,
                                                   'Accept': 'application/json'})
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            got = 0
            with io.open(tmp, 'wb') as fh:
                while True:
                    chunk = resp.read(256 * 1024)
                    if not chunk:
                        break
                    got += len(chunk)
                    if got > MAX_BYTES:
                        raise ValueError('відповідь більша за %d байтів' % MAX_BYTES)
                    fh.write(chunk)
    except Exception as e:
        _rm(tmp)
        state, detail = _classify(e)
        return None, _write_status(
            _state(state, path=None, url=url, detail=detail,
                   retryAfter=int(time.time()) + RETRY_AFTER), home, env)
    # Перевіряємо ВМІСТ, а не лише код відповіді. Проксі гостьового Wi-Fi віддає
    # HTML-сторінку входу з кодом 200, і без цієї перевірки вона лягла б на диск як
    # каталог, а панель показала б нуль скілів без жодної причини.
    try:
        with io.open(tmp, encoding='utf-8') as fh:
            data = json.load(fh)
        if not isinstance(data, dict) or not isinstance(data.get('skills'), list):
            raise ValueError('у відповіді немає списку skills')
    except Exception as e:
        _rm(tmp)
        return None, _write_status(
            _state(S_BROKEN, path=None, url=url, detail=str(e)[:120],
                   retryAfter=int(time.time()) + RETRY_AFTER), home, env)
    os.replace(tmp, dst)
    return dst, _write_status(
        _state(S_CACHED, path=dst, url=url, bytes=os.path.getsize(dst),
               skills=len(data.get('skills') or [])), home, env)


def _rm(path):
    try:
        os.remove(path)
    except OSError:
        pass


def _should_retry(home=None, env=None):
    """Чи минуло вікно тиші після невдалої спроби."""
    saved = _read_status(home, env)
    return time.time() >= float(saved.get('retryAfter') or 0)


def _fetch_in_background(home, env):
    key = cached_catalog(home, env)
    with _lock:
        if key in _inflight:
            return
        _inflight.add(key)
    _write_status(_state(S_FETCHING, path=None, url=catalog_url(env)), home, env)

    def run():
        try:
            fetch_now(home=home, env=env)
        finally:
            with _lock:
                _inflight.discard(key)

    t = threading.Thread(target=run, name='library-catalog-fetch', daemon=True)
    t.start()
    return t


def ensure_catalog(lib_dir=None, home=None, env=None, blocking=False):
    """Шлях до каталогу доступного, або None з записаною причиною.

    Це ЄДИНА точка входу для читачів каталогу. Викликається на кожне звернення до
    магазину помічників і мусить бути дешевою: коли файл на місці і свіжий, уся
    робота це один `os.path.isfile`."""
    local = _local_catalog(lib_dir, home, env)
    if local:
        # Протухлий кеш віддається ЯК Є і оновлюється у фоні. Показати вчорашній
        # каталог краще, ніж показати порожньо і попросити зачекати: людина прийшла
        # шукати скіл, а не дивитись на спінер.
        if local == cached_catalog(home, env) and _stale(local) \
                and _should_retry(home, env):
            _fetch_in_background(home, env)
        return local
    if not catalog_url(env):
        _write_status(_state(S_DISABLED, path=None), home, env)
        return None
    if blocking:
        path, _ = fetch_now(home=home, env=env)
        return path
    if _should_retry(home, env):
        _fetch_in_background(home, env)
    return None


# ── CLI: щоб живий прогін був відтворюваним, а не «повірте на слово» ────────
if __name__ == '__main__':
    import sys
    import argparse
    ap = argparse.ArgumentParser(description='Кеш каталогу доступного помічників')
    ap.add_argument('--ensure', action='store_true',
                    help='завантажити зараз (синхронно) і надрукувати стан')
    ap.add_argument('--status', action='store_true', help='лише стан')
    ap.add_argument('--lib', default=None, help='тека продукту-мінімуму')
    a = ap.parse_args()
    if a.ensure:
        ensure_catalog(lib_dir=a.lib, blocking=True)
    print(json.dumps(status(lib_dir=a.lib), ensure_ascii=False, indent=1))
    sys.exit(0 if status(lib_dir=a.lib).get('ok') else 1)
