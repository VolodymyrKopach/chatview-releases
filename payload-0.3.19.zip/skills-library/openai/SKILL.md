---
name: openai
description: "Помічник OpenAI: викликає OpenAI (GPT-5 через curl) і РОБИТЬ ОЗВУЧКИ. Скіли: ask (швидка відповідь GPT-5), thinking (reasoning o4-mini), search (веб-пошук), озвучити (TTS через OpenAI Nova → mp3). ВСІ голосові/озвучки робимо через цей помічник. Використовуй коли користувач каже «озвуч», «зроби голосове», «скажи голосом», «озвучити», «запитай OpenAI», «GPT подумай», «use GPT»."
---

# OpenAI 🟢 — помічник виклику GPT + озвучки

Обгортка над `scripts/openai.sh` (чат, curl, ключ з `.env` OPENAI_API_KEY) та над `/api/voice` (TTS). ВСІ озвучки в проєкті йдуть через скіл `озвучити`.

## Скіли

### Текстові — `ask.sh <mode> "<prompt>" ["<system>"]`
| Режим | Модель | Для чого |
|-------|--------|----------|
| `ask` | gpt-5 | швидка розумна відповідь |
| `thinking` | o4-mini | reasoning, глибше |
| `search` | gpt-5-search-api | відповідь із веб-пошуком |

### Голос — `say.sh "<текст>" [voice] [model]`  (скіл «озвучити»)
Робить mp3 через OpenAI TTS і повертає URL `/voice-cache/<hash>.mp3`. Дефолт: voice `nova`, model `tts-1` ([[feedback_tts_default_model]]).

```bash
.claude/skills/openai/say.sh "Текст розмовний, без markdown і без довгих тире." nova tts-1
```

**Правила озвучки (HARD, [[feedback_voice_in_ear]]):**
- Двигун OpenAI за замовчуванням (Lesya лише fallback).
- НІКОЛИ не програвати аудіо самому. Готовий mp3 віддаю у Logopsis як audio-widget, користувач сам тисне play.
- Текст для TTS: розмовний, без markdown/булітів, без преамбул, без довгих тире.

## Філософія
Кожен помічник = зовнішня здатність, загорнута в скіли; кличемо помічника, не сирий скрипт. [[project_pomichnyky_first_philosophy]]. Пара до [[gemini]].
