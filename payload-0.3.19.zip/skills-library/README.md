# Skills Library — курований каталог Skill Store

Це **контент-фундамент** Skill Store (Фаза 0). Тут лежать готові, перевірені Claude-скіли, які користувач Logopsis може поставити в один клік (Фаза 1).

## Структура

```
skills-library/
  index.json                 ← маніфест каталогу (single source of truth для Store UI)
  <category>/<skill>/SKILL.md ← сам скіл (frontmatter name+description + інструкції)
```

## Маніфест `index.json`

```jsonc
{
  "categories": [{ "id", "name", "icon" }],
  "skills": [{
    "id":          "унікальний slug",
    "name":        "людська назва (укр)",
    "category":    "id категорії",
    "description": "коли і навіщо юзати (укр)",
    "tags":        ["..."],
    "source":      "звідки скіл (shared-knowledge / автор / репо)",
    "license":     "MIT / ...",
    "icon":        "емодзі",
    "path":        "category/skill",
    "bundled":     true,   // опц: повний бандл лежить деінде
    "note":        "..."   // опц
  }]
}
```

## Як додати скіл у каталог

1. Створити `<category>/<skill>/SKILL.md` з YAML-frontmatter (`name`, `description` — коли вмикати).
2. Додати запис у `index.json` → `skills[]`.
3. Зовнішні скіли (MIT з GitHub): зберегти `LICENSE` поруч + атрибуцію в `source`. Курувати й протестувати перед додаванням, не лити сирцем.

## Install (Фаза 1, ще не реалізовано)

`POST /api/skills/install {id}` копіює `<category>/<skill>/` → `.claude/skills/<name>/`. Стан = наявність папки. Деталі — `projects/chatview/skill-store-plan.md`.

## Поточний каталог

| Скіл | Категорія | Що робить |
|------|-----------|-----------|
| idea-validator | Стратегія | вирок GO/PIVOT/KILL по ідеї |
| atomic-essay | Тексти | сира думка → пост X/LinkedIn з хуком |
| cold-email | Тексти | короткий B2B cold-email що отримує відповідь |
| competitor-scan | Ресерч | швидкий скан конкурентів + де твій геп |
| meeting-to-actions | Продуктивність | нотатки → рішення + action-items |
| video-presentation | Презентації | слайди → озвучене MP4 (bundled) |
