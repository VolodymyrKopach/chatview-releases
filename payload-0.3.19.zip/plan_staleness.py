#!/usr/bin/env python3
"""plan_staleness.py — mark a plan step `stale` when it sat open too long untouched.

WHY THIS MODULE EXISTS (specs/plan-autosync-server/spec.md, subtask C2)
------------------------------------------------------------------------
Live data from channel `chat-281`: thirty-five steps, thirteen still open, and ten of
those thirteen were actually FINISHED work — they just never carried an agent id or a
closing condition, so nothing in the system could see they were done. This module does
not try to guess and auto-close them (that would be exactly the wrong kind of guess).
It does the one honest thing available: make the neglect VISIBLE. A step can now be
flagged `stale` so a human glancing at the plan sidebar sees "this has not moved in a
long time" instead of discovering it weeks later by rereading the whole plan.

`stale` (bool) is the ONLY field a reader outside this module should look at — it is
what the frontend (a later subtask, C3) will render. Two more fields, `staleSince` and
`staleFingerprint`, are private bookkeeping this module needs across separate calls
(the server has no long-lived in-memory state between ticks) and must not be
interpreted by anything else.

WHY 48 HOURS (STALE_THRESHOLD_SECONDS)
----------------------------------------
Real work on an open step tends to touch at least one of its fields (text, note,
substeps, state) at least once within a work day — that is what "working on it" means
in this project's plan-sidebar workflow. Two full days with zero field change is
already well outside that rhythm, yet short enough that a single evening off, or one
day away from a step while other work happens, never trips it. It also comfortably
survives a normal weekend gap without being alarmist about it: an occasional Friday
evening -> Monday morning flag is an acceptable false positive next to the alternative
this module replaces, which was steps sitting invisible for WEEKS (the chat-281 case).

HOW STALENESS IS MEASURED (К3, risk section of the spec)
-----------------------------------------------------------
Per-step, never plan-wide. The threshold is measured against the time since THIS
step's own tracked fields last actually changed, not the plan's age or any other
step's activity — otherwise a human actively iterating on one step would watch every
OTHER step turn stale purely from the passage of time, which would be pure noise
(spec risk section, specs/plan-autosync-server/spec.md).

HOW A REAL CHANGE IS DETECTED (К5)
-------------------------------------
Every field on the step except this module's own three bookkeeping keys is hashed
(`_fingerprint`). When that hash differs from the one recorded the last time this
module looked at the step, the step's anchor (`staleSince`) resets to `now` and `stale`
clears. When the hash is unchanged — including a caller re-declaring the exact same
step through an ENTIRELY DIFFERENT write path (e.g. the model resending an unchanged
```plan``` block, or plan_autopatch touching a different step) — the anchor is left
alone. This is what makes K5 hold: a plan write that does not touch this step's fields
never lifts an existing `stale` mark, whether that write goes through this module or
not.

A step is only ever examined by `_fingerprint`/anchor bookkeeping while it is in an
OPEN state (`OPEN_STATES` below). `done` is the frozen state plan_store.py enforces
(and this module must never contest that): a done step is left completely untouched,
byte-for-byte, no bookkeeping keys added, ever. `blocked` (paused on purpose) is
likewise excluded — the spec names exactly progress/pending as eligible, and a step
someone deliberately paused is not neglect.

A KNOWN, ACCEPTED EDGE CASE THIS MODULE CANNOT CLOSE
-------------------------------------------------------
plan_store.merge_plan field-merges an active step's stored fields onto whatever a new
write declares for it (`step = dict(prev); step.update(st)`), which is exactly right
for goal/substeps/result surviving a minimal patch — but it also means a `stale: true`
set by THIS module while a step was open can ride along into that step's `done` record
if some OTHER, unrelated write closes it right after (e.g. plan_autopatch.mark_step's
minimal `{"id": ..., "state": "done"}` patch never mentions `stale`, so it never clears
it). Once written as `done` the step is frozen (plan_store.py, `old_done_idx`
short-circuit) — no future write, from this module or anyone else, can ever edit it
again. Fixing this at the root would mean changing plan_store.merge_plan's freeze rule,
which is explicitly out of scope here (specs/plan-autosync-server/plan.md, C2 межа).
The mitigation lives on the READING side instead: use `is_effectively_stale(step)`,
never a bare `step.get('stale')`, when the state might be anything other than what you
just checked yourself — it ANDs the flag with the state check so a done step never
reads as stale no matter what a stray leftover key says.
"""
import hashlib
import json
import time

import plan_store as ps

# Two work days with zero field change on an OPEN step. See module docstring for the
# full rationale; kept as one named constant so the value is never duplicated or
# guessed at a second time somewhere else in the codebase.
STALE_THRESHOLD_SECONDS = 48 * 60 * 60

STALE_KEY = 'stale'
_ANCHOR_KEY = 'staleSince'          # epoch seconds: when this step's fields last really changed
_FINGERPRINT_KEY = 'staleFingerprint'
_BOOKKEEPING_KEYS = (STALE_KEY, _ANCHOR_KEY, _FINGERPRINT_KEY)

# Exactly what К3 names: progress and pending. '' mirrors plan_store._state()'s own
# convention that a blank/absent state reads as pending. `done` and `blocked` (and any
# other custom state) are deliberately excluded.
OPEN_STATES = frozenset(('pending', 'progress', ''))


def _state(step):
    """Lowercased state of a step, '' when absent. Mirrors plan_store._state()'s
    one-line contract exactly; duplicated rather than imported since that name is a
    private (`_`-prefixed) helper of a module this subtask must not modify or lean on."""
    raw = step.get('state') if isinstance(step, dict) else None
    return str(raw).strip().lower() if raw else ''


def _fingerprint(step):
    """Stable hash of everything about a step EXCEPT this module's own bookkeeping
    keys. Comparing this across calls is how a "real change to the step" (К5) is told
    apart from "the step was merely re-sent unchanged"."""
    tracked = {k: v for k, v in step.items() if k not in _BOOKKEEPING_KEYS}
    blob = json.dumps(tracked, sort_keys=True, ensure_ascii=False, default=str)
    return hashlib.sha256(blob.encode('utf-8')).hexdigest()


def _refresh_step(step, now):
    """Mutate one OPEN step's bookkeeping + `stale` flag in place. Returns True iff
    anything on the step actually changed, so callers can skip a needless disk write
    when a whole pass over the plan touched nothing."""
    changed = False
    fp = _fingerprint(step)
    if step.get(_FINGERPRINT_KEY) != fp:
        # First sighting of this exact content: anchor to now. Covers both "a real
        # edit just happened" and "this module has never looked at this step before" —
        # the latter must NOT retroactively count as ancient just because the step
        # itself is old; there is no reliable step-creation timestamp to measure from.
        step[_FINGERPRINT_KEY] = fp
        step[_ANCHOR_KEY] = now
        changed = True
    is_stale = (now - step[_ANCHOR_KEY]) >= STALE_THRESHOLD_SECONDS
    # `STALE_KEY not in step` catches the very first time this step is ever seen: a
    # fresh `stale: False` still needs writing once so a reader never has to treat a
    # missing key and an explicit False differently.
    if STALE_KEY not in step or bool(step.get(STALE_KEY)) != is_stale:
        step[STALE_KEY] = is_stale
        changed = True
    return changed


def apply_staleness(plan, now=None):
    """Recompute `stale` for every open step of an in-memory plan dict (flat or
    phased), mutating step dicts IN PLACE — `plan_store.collect_steps` hands back the
    actual nested step objects, not copies, so callers can just pass the plan back
    through `plan_store.write_plan` afterward if anything changed. Returns `plan` for
    convenience/chaining. Safe on `{}`, a plan with no `steps`/`phases`, or one with no
    open steps at all — there is simply nothing to iterate."""
    now = time.time() if now is None else now
    if not isinstance(plan, dict):
        return plan
    for step in ps.collect_steps(plan):
        if not isinstance(step, dict):
            continue
        if _state(step) not in OPEN_STATES:
            continue                      # done / blocked / anything else: untouched
        _refresh_step(step, now)
    return plan


def is_effectively_stale(step):
    """The one check a reader should use instead of a bare `step.get('stale')` — see
    the module docstring's "known, accepted edge case" section for why a raw flag is
    not always trustworthy on its own."""
    return bool(isinstance(step, dict) and step.get(STALE_KEY) and _state(step) in OPEN_STATES)


def run_channel(channel, root=None, now=None):
    """Read `channel`'s stored plan, recompute staleness, and persist it through
    plan_store.write_plan (the project's one writer) if — and only if — anything
    actually changed. Returns the (possibly mutated) plan dict.

    An unknown or planless channel round-trips through plan_store.read_plan as `{}`,
    apply_staleness is a no-op on that, and this function then skips the write
    entirely — same "no plan, no file conjured from thin air" contract plan_autopatch
    already keeps for an unknown channel."""
    plan = ps.read_plan(channel, root)
    if not ps.collect_steps(plan):
        return plan
    before = [dict(s) for s in ps.collect_steps(plan) if isinstance(s, dict)]
    apply_staleness(plan, now=now)
    after = [s for s in ps.collect_steps(plan) if isinstance(s, dict)]
    if before != after:
        ps.write_plan(channel, plan, root)
    return plan
