#!/usr/bin/env python3
"""Транспорт до телефона: один POST у власний ntfy і жодного рішення.

Спека: `specs/turn-done-notifications/spec.md` (шар 3, критерій К11).
Рішення про самохост: `decisions/2026-09-19-push-na-telefon-ntfy-samohost.md`.
Конфіг сервера, який це приймає: `tools/viz/chat/ntfy/server.yml`.

МЕЖІ. Тут НЕ вирішується, чи дзвонити (це `attention_policy`), і НЕ вирішується,
який буде текст (це драбина в `attention.py`). Сюди приїжджає готова картка
`{title, body, channel, tags, priority}` і їде в мережу. Одна причина
змінюватись: як саме ми стукаємо в ntfy.

НУЛЬ ЗАЛЕЖНОСТЕЙ. Паковану збірку везе PyInstaller, тому тут лише stdlib:
`urllib.request` і `json`. Ніякого `requests`, ніякого клієнта ntfy.

ЧОМУ JSON, А НЕ ЗАГОЛОВКИ. ntfy приймає і `POST /<topic>` із заголовками
`Title`/`Click`, і `POST /` з JSON-тілом. Беремо друге, бо назви каналів у нас
українські, а заголовки HTTP це latin-1: «Сповіщення про хід» у заголовку
приїхало б покаліченим або взагалі не пролізло б крізь `urllib`. JSON-тіло
їде в UTF-8 і доносить кирилицю дослівно. Поля ті самі: `title`, `message`,
`click`, `tags`, `priority`.

ВІДМОВОСТІЙКІСТЬ, головна вимога цього модуля. Сервера ntfy на машині може не
бути взагалі (його ще не встановили). `send` НІКОЛИ не кидає винятків і НІКОЛИ
не чекає довго: невдача це звичайний результат `{ok: False, reason: ...}` з
людською причиною. Хід користувача не може зламатись через те, що сповіщення
не полетіло, і не має права на ньому чекати.
"""
import json
import os
import urllib.error
import urllib.request

# Дві адреси нижче це ЄДИНЕ, що залежить від конкретної машини, тому обидві
# мають шов через оточення. Шов не ручка для власника (у налаштуваннях його
# нема і не буде), а страховка двох випадків: тест НЕ сміє послати справжній
# пуш на телефон, а ts.net-адресу тайлнету не можна вшивати в код.

#: Локальна адреса ntfy з `ntfy/server.yml` (`listen-http: 127.0.0.1:2586`).
#: Назовні його віддає `tailscale serve`, але публікуємо ми завжди в петлю.
NTFY_BASE = os.environ.get('LOGOPSIS_NTFY_URL') or 'http://127.0.0.1:2586'
NTFY_TOPIC = 'logopsis-turns'

#: Адреса, яку кладемо в `Click`. Тик по банеру на телефоні веде саме сюди, і
#: з телефона це мусить бути ts.net-адреса, а не петля цієї машини.
APP_BASE = os.environ.get('LOGOPSIS_PUBLIC_URL') or 'http://127.0.0.1:5555'

#: Стеля очікування. Ntfy стоїть у петлі, тому здорова відповідь це міліcекунди;
#: три секунди це запас на завантажену машину, а не на мережу.
TIMEOUT_SEC = 3.0

#: Ntfy-пріоритети: 3 звичайний, 4 високий (пробиває режим «не турбувати» м'якше).
PRIORITY_NORMAL = 3
PRIORITY_URGENT = 4


class NtfyPublisher:
    """Один POST у топік. Нічого більше цей клас не вміє і не повинен."""

    def __init__(self, base=NTFY_BASE, topic=NTFY_TOPIC, app_base=APP_BASE,
                 timeout=TIMEOUT_SEC, opener=None):
        self._base = (base or NTFY_BASE).rstrip('/')
        self._topic = topic or NTFY_TOPIC
        self._app = (app_base or APP_BASE).rstrip('/')
        self._timeout = float(timeout or TIMEOUT_SEC)
        self._opener = opener or urllib.request.urlopen

    # -- складання -------------------------------------------------------
    def click_url(self, channel):
        """Адреса каналу. Порожній канал (зведення без одного адресата) веде
        просто в застосунок, а не в биту адресу."""
        channel = str(channel or '').strip()
        return '%s/#%s' % (self._app, channel) if channel else self._app

    def payload(self, note):
        """Картка -> тіло запиту. Рівно ті поля, які ntfy вміє читати."""
        body = {
            'topic': self._topic,
            'title': str(note.get('title') or ''),
            'message': str(note.get('body') or ''),
            'click': self.click_url(note.get('channel')),
        }
        tags = [str(t) for t in (note.get('tags') or []) if t]
        if tags:
            body['tags'] = tags
        priority = note.get('priority')
        if priority:
            body['priority'] = int(priority)
        return body

    # -- відправка -------------------------------------------------------
    def send(self, note):
        """Повертає `{ok, status, reason}` і НІКОЛИ не кидає винятку.

        Причина відмови пишеться людською мовою і одразу називає винного:
        «ntfy не піднятий» це інша робота для власника, ніж «ntfy відповів 403»,
        і сховати їх за спільним «не вдалося» означає зробити лог даремним."""
        try:
            data = json.dumps(self.payload(note), ensure_ascii=False).encode('utf-8')
            request = urllib.request.Request(
                self._base + '/', data=data, method='POST',
                headers={'Content-Type': 'application/json; charset=utf-8'})
            with self._opener(request, timeout=self._timeout) as response:
                status = int(getattr(response, 'status', None) or response.getcode())
            if 200 <= status < 300:
                return {'ok': True, 'status': status, 'reason': ''}
            return {'ok': False, 'status': status,
                    'reason': 'ntfy відповів %d' % status}
        except urllib.error.HTTPError as e:
            return {'ok': False, 'status': int(e.code),
                    'reason': 'ntfy відповів %d' % e.code}
        except urllib.error.URLError as e:
            return {'ok': False, 'status': None, 'reason': self._why(e.reason)}
        except Exception as e:                       # таймаут, DNS, битий JSON
            return {'ok': False, 'status': None, 'reason': self._why(e)}

    def _why(self, error):
        """Людська причина замість трейсу. Найчастіший випадок тут рівно один:
        ntfy на машині ще не встановлений і на порту ніхто не слухає."""
        if isinstance(error, ConnectionRefusedError):
            return 'сервер ntfy не піднятий на %s, пуш пропущено' % self._base
        if isinstance(error, TimeoutError) or 'timed out' in str(error).lower():
            return 'ntfy не відповів за %.1f с' % self._timeout
        return 'ntfy недоступний: %s' % (error,)
