#!/usr/bin/env python3
"""Реєстр уваги: що сталось у каналі і чи є кому це показувати.

Спека: `specs/turn-done-notifications/spec.md` (шар 1, критерії К1-К4).

НАВІЩО ОКРЕМИЙ МОДУЛЬ. Хід завершується мовчки: жива смужка над інпутом показує
роботу тільки поки на неї дивляться, а завершення виглядає як зникнення рядка.
Власник дізнається про готову відповідь лише повернувшись очима у вкладку, тобто
платить перемиканням за кожну перевірку «а чи вже». Тут лежить джерело правди,
з якого фронт (а згодом банер і телефон) дізнається про це без перемикання.

МЕЖІ (розділ 6 спеки, дослівна вимога власника про SOLID). Цей файл НЕ знає ні
про HTTP, ні про раннер. Він знає рівно дві речі: події і присутність.

  * `server.py` це ТРАНСПОРТ: розбір параметрів, виклик `Attention.poll`,
    серіалізація. Жодного рішення там не приймається.
  * `runner.py` це ДЖЕРЕЛО: рівно один виклик `emit_turn` з `clear_pid`.
    Жодної логіки сповіщень там не лишається.
  * цей модуль це ПОЛІТИКА: коли подія народжується, який у неї текст, чи жива
    вкладка.

Усередині три незалежні частини плюс два адаптери:

  1. `AttentionRegistry`: стан, тобто журнал подій, лічильник ревізій `rev`,
     очікування на умовній змінній.
  2. драбина тексту (`body_from_widgets`, `clamp_words`): ЧИСТІ функції, на
     вхід список віджетів, на вихід `body` і `bodySource`. Жодного читання з
     диска, тому її можна перевірити без файлової системи і без каналу.
  3. `Presence`: памʼять присутності власника, тобто коли жива вкладка озвалась
     востаннє і який канал у ній відкритий.
  Адаптери: `ChannelCards` (тонке читання картки з диска) і `TurnEvents`
  (склейка трьох частин у подію ходу).

ШАР 3 (телефон і тиша, критерії К11-К14) доклався сюди трьома речами і НЕ
розмазав рішення по файлу:

  * приватна драбина пуша (`safe_line`, `push_note`, `merged_note`,
    `digest_note`): теж ЧИСТІ функції поруч зі звичайною драбиною, бо питання
    «який буде текст» одне й те саме, просто для іншого адресата;
  * `read_notification_settings`: одне читання `user-settings.json` замість
    констант, розсипаних по коду;
  * `AttentionDispatch`: сторож, що зшиває журнал, політику і транспорт.
  Саму політику тиші тримає `attention_policy` (чисті рішення, нуль
  вводу-виводу), доставку тримає `attention_push` (один POST у ntfy, нуль
  рішень). Обидва про цей файл не знають нічого.

Час і корінь дому приходять АРГУМЕНТАМИ, а не беруться з глобалів: тест не має
залежати ні від годинника машини, ні від реального диска.

ДВА ПРОЦЕСИ, А НЕ ОДИН. Подію кладе `runner.py`, віддає `server.py`, і це різні
процеси. Тому журнал живе на диску (`<дім>/attention-events.json`), а умовна
змінна лишається тим, чим вона є в будильнику гаджетів (`server.py`,
`_GADGET_BUS`): ПРИСКОРЮВАЧЕМ для тих, хто емітить у тому самому процесі.
Чесний сторож тут це такт з `os.stat()`: 0.05 с дає реакцію в межах К4
(«швидше за 200 мс») із запасом на завантажену машину, і коштує двадцять
стат-викликів на секунду на вкладку. Другого механізму немає і не треба.

ВИДИ ПОДІЙ ЦЕ ДАНІ. Новий вид додається рядком у `TURN_KINDS`, а не гілкою `if`
у трьох місцях. Так само поправка стану по картці, що реально лягла в стрічку,
живе таблицею `TAG_OUTCOME`, а не каскадом.
"""
import io                     # noqa: F401  (точка підміни для тесту «без диска»)
import json
import os
import re
import sys
import threading
import time
import uuid

# Шар 3 (телефон і тиша). Залежність СУВОРО однобічна: цей файл знає обидва
# модулі, вони про нього не знають нічого. `attention_policy` це чисті рішення
# без вводу-виводу, `attention_push` це один POST у ntfy без жодних рішень.
import attention_policy as policy
import attention_push

# ── 0. Види подій: таблиці, а не каскад if ──────────────────────────────────

#: підсумок ходу -> `kind` події. Новий вид = новий рядок, нуль правок деінде.
TURN_KINDS = {
    'done': 'turn-done',
    'failed': 'turn-failed',
    'gone': 'turn-gone',
    'stopped': 'turn-stopped',
}

#: підсумки, які має право виправити картка, що реально лягла в стрічку.
#: Порожня відповідь виходить з ходу БЕЗ `err` (тобто «done»), а в стрічку лягає
#: карткою помилки: без цієї поправки подія називала б провал успіхом.
CORRECTABLE_OUTCOMES = frozenset({'done'})

#: тег картки -> справжній підсумок ходу.
TAG_OUTCOME = {'error': 'failed'}

DEFAULT_OUTCOME = 'done'

# ── 1. Драбина тексту: ЧИСТІ функції ────────────────────────────────────────

#: стеля рядка `body` (К3) і стеля заголовка сповіщення (К9, «до 40 символів»).
BODY_LIMIT = 120
TITLE_LIMIT = 40
ELLIPSIS = '…'

#: остання сходинка драбини: картка є, слів у ній нема.
COUNT_FORMS = ('картка', 'картки', 'карток')
COUNT_TEMPLATE = 'Готово, {n} {word}'

_MD_LINK = re.compile(r'\[([^\]]*)\]\([^)]*\)')
_MD_MARKS = re.compile(r'(\*\*|__|[`*_~])')
_LEADING = re.compile(r'^\s*(?:[#>\-+*]\s*|\d+[.)]\s+)')
_SPACES = re.compile(r'\s+')
_SENTENCE = re.compile(r'^(.+?[.!?…])(?:\s|$)', re.DOTALL)


def plain_text(value):
    """Рядок без розмітки: підпис у банері читає людина, а не парсер."""
    if not isinstance(value, str):
        return ''
    out = _MD_LINK.sub(r'\1', value)
    out = _LEADING.sub('', out)
    out = _MD_MARKS.sub('', out)
    return _SPACES.sub(' ', out).strip()


def first_sentence(value):
    """Перше речення рядка. Нема крапки: весь перший абзац."""
    text = plain_text(value)
    if not text:
        return ''
    hit = _SENTENCE.match(text)
    return (hit.group(1) if hit else text).strip()


def plural(n, forms=COUNT_FORMS):
    """Українська форма числівника: 1 картка, 2 картки, 5 карток."""
    n = abs(int(n))
    if n % 10 == 1 and n % 100 != 11:
        return forms[0]
    if 2 <= n % 10 <= 4 and not 12 <= n % 100 <= 14:
        return forms[1]
    return forms[2]


def clamp_words(text, limit=BODY_LIMIT, ellipsis=ELLIPSIS):
    """К3: рядок довший за стелю ріжеться ПО МЕЖІ СЛОВА і дістає трикрапку.

    Різати по символу дешевше, але тоді сповіщення показує огризок слова, і
    рядок, заради якого вся ця робота й затіяна, читається як помилка. Довжина
    результату разом з трикрапкою не перевищує стелю."""
    text = (text or '').strip()
    if len(text) <= limit:
        return text
    cut = text[:max(0, limit - len(ellipsis))]
    head, sep, _tail = cut.rpartition(' ')
    head = (head if sep else cut).rstrip(' \t\n.,;:!?–—-')
    return (head or cut.rstrip()) + ellipsis


def _rung_conclusion(widgets):
    """Найвища сходинка: вирок відповіді. За стандартом подачі він ОСТАННІЙ,
    тому і беремо останній, а не перший-ліпший."""
    for w in reversed(widgets):
        if w.get('type') == 'conclusion':
            got = first_sentence(w.get('text'))
            if got:
                return got
    return ''


def _rung_header(widgets):
    for w in widgets:
        if w.get('type') == 'header':
            got = plain_text(w.get('title'))
            if got:
                return got
    return ''


def _rung_text(widgets):
    for w in widgets:
        if w.get('type') == 'text':
            got = first_sentence(w.get('text'))
            if got:
                return got
    return ''


def _rung_count(widgets):
    """Картка є, слів у ній нема (одна картинка, одна таблиця). Це НЕ те саме,
    що картки нема зовсім, і сповіщення мусить розрізняти ці два випадки."""
    n = len(widgets)
    return COUNT_TEMPLATE.format(n=n, word=plural(n)) if n else ''


#: драбина К2 як ДАНІ: перша сходинка, що дала текст, виграє і дає `bodySource`.
BODY_LADDER = (
    ('conclusion', _rung_conclusion),
    ('header', _rung_header),
    ('text', _rung_text),
    ('count', _rung_count),
)

NO_BODY_SOURCE = 'none'


def body_from_widgets(widgets, limit=BODY_LIMIT, ladder=BODY_LADDER):
    """К2: `body` і `bodySource` зі списку віджетів. Диска тут нема НІДЕ.

    `bodySource` не косметика: `conclusion` є приблизно в половині карток, і
    без цього поля неможливо відрізнити «драбина спрацювала» від «драбина
    мовчки з'їхала на дно»."""
    items = [w for w in (widgets or []) if isinstance(w, dict)]
    for source, rung in ladder:
        got = rung(items)
        if got:
            return clamp_words(got, limit), source
    return '', NO_BODY_SOURCE


# ── 1b. Приватність пуша: що саме має право виїхати з цієї машини ───────────
#
# Жорстке правило власника: у тіло пуша йде ТІЛЬКИ назва каналу і рядок
# висновку. Ніколи код, шляхи файлів, ключі, цифри клієнтів. Правило не про
# сором, а про те, куди це їде: тіло лежить у кеші ntfy, світиться на
# заблокованому екрані телефона і переживає нас у скріншотах.
#
# Чому чистка, а не довіра до драбини. Драбина бере ПЕРШЕ РЕЧЕННЯ віджета
# `conclusion`, а вирок технічної відповіді залюбки містить і шлях, і виклик
# функції. Довіряти тут авторові картки означає покластись на те, що жодна
# майбутня відповідь не покладе в вирок ключ. Дешевше вирізати.
#
# Метод це БІЛИЙ СПИСОК, а не чорний. Чорний список ловить те, про що ми вже
# подумали; білий пропускає лише те, що схоже на людську фразу, і все інше
# ріже за замовчуванням. Токен, у якому є символ поза набором людської прози,
# не розбирається далі, а замінюється на трикрапку.

#: Стеля рядка в пуші і стеля рядка на канал у злитому сповіщенні.
PUSH_BODY_LIMIT = 120
PUSH_LINE_LIMIT = 80
REDACTED = '…'

#: Символи, яких у людській фразі не буває, зате з них складаються шляхи
#: (`/`, `\`), пошта (`@`), код (`_`, `{}`, `[]`, `<>`, `=`) і змінні оточення.
#: Дужки `()`, лапки і апостроф лишаються дозволеними: без них не написати
#: «зʼявився» і «(див. нижче)».
_FORBIDDEN_CHAR = re.compile(r'[\\/@#$^&*_=+|~<>\[\]{}`]')

#: Виклик функції цілком: `run_turn(channel, outcome)`. Ріжеться до розбору на
#: токени, бо інакше від нього лишається хвіст «outcome).». Пробіл перед дужкою
#: НЕ дозволений навмисне: інакше під це правило потрапляє звичайна проза
#: «новий таб (див. нижче)», і сповіщення втрачає пів фрази замість коду.
_CALL = re.compile(r'[\w.]+\([^()]{0,120}\)')

#: Номер картки або телефон, записані групами через пробіл чи дефіс.
_CARD = re.compile(r'\b\d[\d \-]{10,20}\d\b')

#: Цифри клієнтів: ід, телефон, номер замовлення. Чотири цифри лишаємо, бо це
#: рік і кількість карток, а не чиїсь дані.
_LONG_DIGITS = re.compile(r'\d{5,}')

#: Імʼя файлу без теки (`server.py`) це теж шлях, просто короткий.
_FILE_EXT = re.compile(
    r'\.(?:py|js|cjs|mjs|ts|tsx|jsx|json|md|sh|ps1|bat|html|css|scss|yml|yaml'
    r'|txt|png|jpg|jpeg|svg|gif|mp4|wav|mp3|log|db|sqlite|env|toml|ini|cfg'
    r'|sql|go|rs|java|kt|rb|php|c|h|cpp|zip|pdf|csv|xlsx)\b', re.I)

_HAS_LETTER = re.compile(r'[^\W\d_]', re.UNICODE)
_HAS_DIGIT = re.compile(r'\d')

#: Ключі виглядають як довгий непроговорюваний токен з букв І цифр
#: (`sk-ABC123DEF456`). Дванадцять символів це поріг, за яким українське слово
#: з цифрою всередині практично не зустрічається.
OPAQUE_LEN = 12

_TRIM = ' \t.,;:!?()«»"\'’…-'
_PUNCT_SPACE = re.compile(r'\s+([,.;:!?])')
_MULTI_MARK = re.compile(r'(?:…[\s,;:]*){2,}')


def _token_is_human(token):
    """Чи схожий токен на слово, яке писала людина для людини."""
    if _FORBIDDEN_CHAR.search(token):
        return False
    if _LONG_DIGITS.search(token) or _FILE_EXT.search(token):
        return False
    core = token.strip(_TRIM)
    if (len(core) >= OPAQUE_LEN
            and _HAS_LETTER.search(core) and _HAS_DIGIT.search(core)):
        return False
    return True


def safe_line(text, limit=PUSH_BODY_LIMIT):
    """Рядок висновку, очищений до того, що не соромно показати на телефоні.

    Порожній результат це чесна відповідь: у вирок поклали самий код, і після
    чистки від нього не лишилось фрази. Тоді сповіщення візьме нейтральний
    рядок стану, а не огризки."""
    line = plain_text(text)
    if not line:
        return ''
    line = _CARD.sub(REDACTED, _CALL.sub(REDACTED, line))
    line = ' '.join(t if _token_is_human(t) else REDACTED for t in line.split())
    line = _MULTI_MARK.sub('… ', line)
    line = _PUNCT_SPACE.sub(r'\1', line)
    line = _SPACES.sub(' ', line).strip(' ,;:')
    return clamp_words(line, limit) if line.strip(' …') else ''


# ── 1c. Картка сповіщення: одна подія, пачка, ранкове зведення ─────────────

#: Форми для заголовків «Доробили N каналів» (К14).
CHANNEL_FORMS = ('канал', 'канали', 'каналів')
MERGED_TITLE = 'Доробили {n} {word}'
#: Ранкове зведення (К12). Окремий заголовок, бо приходить воно не по гарячих
#: слідах, і плутати його з живою пачкою не можна.
DIGEST_TITLE = 'За ніч доробили {n} {word}'

#: Рядок стану, коли від висновку після чистки нічого не лишилось.
NEUTRAL_BODY = {
    'turn-done': 'Готово.',
    'turn-failed': 'Хід упав.',
    'turn-gone': 'Хід загубився.',
    'needs-permission': 'Чекає дозволу.',
}
NEUTRAL_FALLBACK = 'Готово.'

#: Значок у банері на телефоні (словник ntfy, див. `ntfy/server.yml`).
KIND_TAG = {
    'turn-done': 'white_check_mark',
    'turn-failed': 'x',
    'turn-gone': 'hourglass',
    'needs-permission': 'lock',
}
DEFAULT_TAG = 'bell'
MERGED_TAG = 'bell'


def _push_title(event):
    """Заголовок це людська назва вкладки. Сирий id не каже власнику нічого."""
    got = event.get('title') or plain_text(event.get('label')) or event.get('channel')
    return clamp_words(str(got or ''), TITLE_LIMIT)


def _push_body(event, limit=PUSH_BODY_LIMIT):
    kind = event.get('kind') or ''
    return (safe_line(event.get('body'), limit)
            or NEUTRAL_BODY.get(kind, NEUTRAL_FALLBACK))


def _priority(kind):
    return (attention_push.PRIORITY_URGENT if policy.traits_for(kind).urgent
            else attention_push.PRIORITY_NORMAL)


def push_note(event):
    """Одна подія -> картка для транспорту. Назва каналу і один рядок, і все."""
    kind = event.get('kind') or ''
    return {'title': _push_title(event), 'body': _push_body(event),
            'channel': event.get('channel') or '',
            'tags': [KIND_TAG.get(kind, DEFAULT_TAG)],
            'priority': _priority(kind), 'events': 1}


#: Скільки рядків на канал поміщаємо в одне сповіщення. Ціль не краса, а те,
#: що банер на телефоні все одно показує кілька перших рядків, а ntfy має стелю
#: довжини повідомлення. Ніч на двадцяти каналах інакше давала б пуш, який не
#: читається і має шанс просто не пройти.
MAX_NOTE_LINES = 8
MORE_TEMPLATE = 'і ще {n} {word}'


def _group_lines(groups):
    lines = ['%s: %s' % (_push_title(e), _push_body(e, PUSH_LINE_LIMIT))
             for _channel, e in groups[:MAX_NOTE_LINES]]
    rest = len(groups) - len(lines)
    if rest > 0:
        lines.append(MORE_TEMPLATE.format(n=rest, word=plural(rest, CHANNEL_FORMS)))
    return lines


def _many_note(groups, template, tag=MERGED_TAG):
    """Спільна форма пачки і зведення: заголовок з числом, рядок на канал.

    Тик по банеру веде в ПЕРШИЙ канал пачки: один банер має рівно одну адресу,
    а вибір із трьох це вже екран, якого на заблокованому телефоні нема."""
    n = len(groups)
    return {'title': template.format(n=n, word=plural(n, CHANNEL_FORMS)),
            'body': '\n'.join(_group_lines(groups)),
            'channel': groups[0][0] if groups else '',
            'tags': [tag], 'priority': attention_push.PRIORITY_NORMAL,
            'events': n}


def merged_note(groups):
    """К14: кілька фінішів у вікні 20 секунд -> одне сповіщення."""
    return _many_note(groups, MERGED_TITLE)


def digest_note(groups):
    """К12: успішні ходи, зібрані за тихі години -> одне ранкове зведення."""
    return _many_note(groups, DIGEST_TITLE)


def note_for(groups):
    """Групи каналів -> рівно одна картка.

    Один канал це звичайне сповіщення, а не пачка з одного рядка: заголовок
    «Доробили 1 канал» ховав би саме те, що власнику й треба, тобто назву
    вкладки."""
    if not groups:
        return None
    return push_note(groups[0][1]) if len(groups) == 1 else merged_note(groups)


# ── 2. Реєстр подій: стан, rev, очікування ──────────────────────────────────

#: такт сторожа. Подію кладе ЧУЖИЙ процес, тому будильник на умовній змінній
#: його не зшиває і чесна реакція вимірюється саме тактом (К4: < 200 мс).
#: 0.05 с, а не 0.1, бо стеля критерію мусить мати запас на завантажену машину:
#: під повним прогоном тестів 0.1 давав затримку впритул до 200 мс. Ціна такту
#: це двадцять `os.stat()` на секунду на ОДНЕ зʼєднання, тобто одиниці
#: мікросекунд процесора; спить воно на умовній змінній і не крутить цикл.
TICK = 0.05
#: скільки подій тримаємо в журналі. Вкладка, що проспала більше, все одно
#: синхронізується наново, а нескінченний файл ніхто не читає.
KEEP_EVENTS = 60
#: стеля очікування довгого запиту (К4). Довше за неї зʼєднання не тримаємо
#: ніколи: потік сервера коштує, а вікон буває кілька.
WAIT_CEILING = 25.0


def _atomic_write_json(path, payload):
    os.makedirs(os.path.dirname(path), exist_ok=True)
    tmp = '%s.%d.tmp' % (path, os.getpid())
    with open(tmp, 'w', encoding='utf-8') as f:
        json.dump(payload, f, ensure_ascii=False)
    os.replace(tmp, path)


def _read_json(path, fallback=None):
    """Читання, що переживає підміну файлу під собою.

    На Windows `os.replace` під відкритим читачем може дати помилку, а на
    будь-якій системі можна застати нульовий проміжний стан. Одна повторна
    спроба коштує міліcекунду і знімає обидва випадки."""
    for attempt in (0, 1):
        try:
            with open(path, encoding='utf-8') as f:
                return json.load(f)
        except FileNotFoundError:
            return fallback
        except (OSError, ValueError):
            if attempt:
                return fallback
            time.sleep(0.01)
    return fallback


class AttentionRegistry:
    """Журнал подій уваги: додати, віддати хвіст, поспати до наступної.

    Одна причина змінюватись: як зберігається і як доставляється ПОДІЯ. Що в
    події написано, вирішує не цей клас."""

    def __init__(self, path, keep=KEEP_EVENTS, clock=time.time, tick=TICK,
                 bus=None):
        self._path = path
        self._keep = keep
        self._clock = clock
        self._tick = tick
        self._bus = bus or threading.Condition()
        self._write_lock = threading.Lock()
        self._cache = ((0, 0), 0, [])          # (відбиток, rev, події)

    # -- диск -------------------------------------------------------------
    def _stamp(self):
        """Відбиток журналу: (mtime_ns, розмір). Розмір не для краси: на грубій
        гранулярності часу два швидкі записи лягають у ту саму мітку."""
        try:
            st = os.stat(self._path)
            return (st.st_mtime_ns, st.st_size)
        except (OSError, ValueError):
            return (0, 0)

    def _load(self, force=False):
        stamp = self._stamp()
        if not force and stamp == self._cache[0]:
            return self._cache
        raw = _read_json(self._path, {}) or {}
        events = [e for e in (raw.get('events') or []) if isinstance(e, dict)]
        rev = int(raw.get('rev') or 0)
        self._cache = (stamp, rev, events)
        return self._cache

    # -- запис ------------------------------------------------------------
    def publish(self, fields):
        """Покласти подію в журнал і підняти `rev`. Повертає готову подію."""
        with self._write_lock:
            _stamp, rev, events = self._load(force=True)
            rev += 1
            event = dict(fields)
            event['rev'] = rev
            event.setdefault('eventId', 'att-%s' % uuid.uuid4().hex[:12])
            events = (events + [event])[-self._keep:]
            _atomic_write_json(self._path, {'rev': rev, 'events': events})
            self._cache = (self._stamp(), rev, events)
        # Дзвонити ПІСЛЯ запису: підписник, розбуджений цим рядком, одразу піде
        # читати журнал і мусить застати там уже нові байти.
        with self._bus:
            self._bus.notify_all()
        return event

    # -- читання ----------------------------------------------------------
    def snapshot(self, since):
        """Хвіст журналу новіший за `since`.

        `since < 0` це ЗНАЙОМСТВО: вкладка дізнається поточний `rev` і НЕ
        отримує історії, інакше свіжо відкрите вікно вивалило б тости про ходи,
        які завершились годину тому. `since` більший за поточний `rev` означає
        розʼїзд (сервер перезапустився, журнал обнулився): теж без історії, але
        з чесним прапорцем, щоб клієнт переприсвоїв собі базу."""
        _stamp, rev, events = self._load()
        if since is None or since < 0:
            return {'rev': rev, 'events': [], 'baseline': True}
        if since > rev:
            return {'rev': rev, 'events': [], 'desync': True}
        return {'rev': rev,
                'events': [e for e in events if int(e.get('rev') or 0) > since]}

    def wait(self, since, timeout):
        """Спати до появи події новішої за `since` або до кінця `timeout`."""
        if since is None or since < 0:
            return self._load()[1]
        deadline = self._clock() + max(0.0, float(timeout or 0))
        while True:
            rev = self._load()[1]
            if rev != since:
                return rev
            left = deadline - self._clock()
            if left <= 0:
                return rev
            with self._bus:
                self._bus.wait(min(self._tick, left))


# ── 3. Памʼять присутності ──────────────────────────────────────────────────

#: не частіше цього пишемо файл присутності, якщо нічого не змінилось.
PRESENCE_WRITE_EVERY = 1.0


class Presence:
    """Коли жива вкладка озвалась востаннє і який канал у ній відкритий.

    Одна причина змінюватись: як ми дізнаємось про ПРИСУТНІСТЬ. Саме цей стан
    відрізняє «власник дивиться в інший канал» (тост) від «власника нема біля
    компʼютера взагалі» (телефон, шар 3), тому він лежить на диску: питати про
    нього буде не лише той процес, що його записав."""

    def __init__(self, path, clock=time.time, write_every=PRESENCE_WRITE_EVERY):
        self._path = path
        self._clock = clock
        self._write_every = write_every
        self._last = None
        self._lock = threading.Lock()

    def touch(self, channel='', focus=False):
        """Жива вкладка щойно озвалась. Повертає записаний стан."""
        now = self._clock()
        state = {'seenAt': round(now, 3), 'channel': str(channel or ''),
                 'focus': bool(focus)}
        with self._lock:
            prev = self._last
            same = (prev and prev['channel'] == state['channel']
                    and prev['focus'] == state['focus']
                    and now - prev['seenAt'] < self._write_every)
            self._last = state
            if same:
                # Полінг стукає часто, а диск від цього не стає розумнішим:
                # поки канал і фокус ті самі, свіжої правди у файлі не більше,
                # ніж у памʼяті.
                return state
            try:
                _atomic_write_json(self._path, state)
            except OSError:
                pass
        return state

    def read(self):
        """Стан присутності разом з віком: `ageSec` це і є відповідь на
        питання «а чи є кому дивитись»."""
        state = self._last or _read_json(self._path, None) or {}
        seen = float(state.get('seenAt') or 0)
        return {'seenAt': seen,
                'channel': str(state.get('channel') or ''),
                'focus': bool(state.get('focus')),
                'ageSec': round(max(0.0, self._clock() - seen), 3) if seen else None}


# ── адаптер диска: картки каналу ────────────────────────────────────────────

#: скільки чекаємо на картку, яка ще не лягла в стрічку (див. `TurnEvents`).
SETTLE_SEC = 10.0
SETTLE_STEP = 0.05


class ChannelCards:
    """Тонке читання стрічки каналу. Рівно стільки диска, скільки треба.

    Драбина тексту сюди НЕ заглядає: вона отримує готовий список віджетів. Це
    єдина причина, з якої цей клас існує окремо, і єдина причина, з якої його
    можна підмінити в тесті подвійником."""

    REGISTRIES = ('index.json', 'index.local.json')

    def __init__(self, channels_dir, clock=time.time, sleep=time.sleep):
        self._dir = channels_dir
        self._clock = clock
        self._sleep = sleep

    def _index_path(self, channel):
        return os.path.join(self._dir, channel, 'index.json')

    def stamp(self, channel):
        try:
            st = os.stat(self._index_path(channel))
            return (st.st_mtime_ns, st.st_size)
        except (OSError, ValueError):
            return (0, 0)

    def newest(self, channel):
        """Останній запис стрічки або None."""
        rows = _read_json(self._index_path(channel), [])
        rows = [r for r in (rows or []) if isinstance(r, dict)]
        return rows[-1] if rows else None

    def widgets(self, channel, entry):
        """Віджети картки. Файл картки це просто масив віджетів."""
        name = (entry or {}).get('file')
        if not name or '/' in name or '\\' in name or '..' in name:
            return []
        data = _read_json(os.path.join(self._dir, channel, name), [])
        return [w for w in (data or []) if isinstance(w, dict)]

    def wait_for_new(self, channel, before, ceiling=SETTLE_SEC,
                     step=SETTLE_STEP):
        """Дочекатись картки, якої на момент `before` ще не було.

        Повертає новий запис стрічки або None, якщо за стелю він так і не
        зʼявився (зупинений хід без жодного тексту, хід, що віддав лише план)."""
        deadline = self._clock() + max(0.0, float(ceiling or 0))
        while True:
            if self.stamp(channel) != before:
                return self.newest(channel)
            if self._clock() >= deadline:
                return None
            self._sleep(step)

    def label(self, channel):
        """Людська назва вкладки. Сирий id у сповіщенні не каже нічого."""
        for name in self.REGISTRIES:
            for row in (_read_json(os.path.join(self._dir, name), []) or []):
                if isinstance(row, dict) and row.get('id') == channel:
                    got = plain_text(row.get('label'))
                    if got:
                        return got
        return channel


# ── джерело подій ходу: склейка трьох частин ────────────────────────────────

def _daemon(fn):
    """Стандартний планувальник: короткий демон-потік, що вмирає сам."""
    t = threading.Thread(target=fn, daemon=True, name='attention-settle')
    t.start()
    return t


class TurnEvents:
    """З підсумку ходу робить подію реєстру.

    ЧОМУ ВОНО ВІДКЛАДЕНЕ. Раннер віддає pid (`clear_pid`) РАНІШЕ, ніж його
    відповідь опиняється в стрічці: між цими двома митями ще рахується якір
    відповіді, знімається жива панель, пишеться вартість ходу, збираються
    віджети і, коли ввімкнена автоозвучка, синтезується голос. Прочитати
    «останню картку каналу» в момент `clear_pid` означало б прочитати ПОПЕРЕДНЮ
    картку і розіслати сповіщення з чужим текстом. Тому подія народжується не
    миттєво, а щойно картка ляже на диск: емісія лишається одним рядком у
    раннері, а вся затримка живе тут, де її видно і де її перевіряє тест."""

    def __init__(self, registry, cards, clock=time.time, spawn=_daemon,
                 settle=SETTLE_SEC, limit=BODY_LIMIT):
        self._registry = registry
        self._cards = cards
        self._clock = clock
        self._spawn = spawn
        self._settle = settle
        self._limit = limit

    @staticmethod
    def resolve_outcome(outcome, entry):
        """Підсумок, скоригований карткою, яка реально лягла в стрічку."""
        if outcome not in CORRECTABLE_OUTCOMES:
            return outcome
        return TAG_OUTCOME.get((entry or {}).get('tag'), outcome)

    def emit(self, channel, outcome, started_at=None, ended_at=None):
        before = self._cards.stamp(channel)

        def settle():
            entry = self._cards.wait_for_new(channel, before, self._settle)
            widgets = self._cards.widgets(channel, entry) if entry else []
            body, source = body_from_widgets(widgets, self._limit)
            kind = TURN_KINDS.get(self.resolve_outcome(outcome, entry))
            if not kind:
                kind = TURN_KINDS[DEFAULT_OUTCOME]
            label = self._cards.label(channel)
            ended = float(ended_at if ended_at is not None else self._clock())
            started = float(started_at) if started_at is not None else ended
            return self._registry.publish({
                'kind': kind,
                'channel': channel,
                'label': label,
                'title': clamp_words(label, TITLE_LIMIT),
                'body': body,
                'bodySource': source,
                'durationSec': max(0, int(round(ended - started))),
                'endedAt': round(ended, 3),
            })

        return self._spawn(settle)


# ── 4. Налаштування сповіщень: одне читання, один переклад ─────────────────

SETTINGS_FILE = 'user-settings.json'
SETTINGS_BLOCK = 'notifications'


def read_notification_settings(home, block=SETTINGS_BLOCK):
    """Блок `notifications` з `user-settings.json` -> `policy.Settings`.

    Читання винесене в ОДНУ функцію свідомо. Пороги, розсипані константами по
    коду, живуть рівно до першого «а зроби тихі години з опівночі»: тоді їх
    шукають по файлах і одну обовʼязково пропускають. Тут же джерело одне, і
    його видно.

    Файлу нема або блок відсутній: беремо дефолти (тихі години увімкнені з
    23:00 до 08:00). Тому фіча однаково поводиться і на свіжій машині, і після
    того, як налаштування перезапише той, хто про цей блок не знає."""
    raw = _read_json(os.path.join(home, SETTINGS_FILE), {}) or {}
    return policy.settings_from_raw(raw.get(block) if isinstance(raw, dict) else None)


# ── 5. Сторож сповіщень: склеювання, стелі, ранкове зведення ───────────────

def _stderr(message):
    """Лог за замовчуванням. Тихий провал сповіщення гірший за гучний."""
    try:
        sys.stderr.write(message + '\n')
        sys.stderr.flush()
    except Exception:
        pass


#: Скільки сторож спить між оглядами журналу. Це ж і точність, з якою
#: закривається вікно склеювання і спрацьовує ранкове зведення.
DISPATCH_WAIT = 2.0
#: Скільки останніх карток і відмов тримаємо для діагностики.
KEEP_SENT = 20


class SignalLedger:
    """Памʼять сторожа: коли ми дзвонили і що чекає своєї черги.

    Стан ЖИВЕ В ПАМʼЯТІ процесу сервера, на диск не їде, і це свідомо. Стеля
    частоти це обмежувач, а не факт: пережити перезапуск їй нема чого, бо
    перезапуск і так означає, що останню хвилину ніхто нічого не слав. Ціна
    рішення чесна і одна: перезапуск посеред ночі губить зібране до нього
    ранкове зведення. Самі події при цьому не губляться ніде, вони лежать у
    журналі на диску і далі світяться крапкою на табі."""

    def __init__(self):
        self.channel_sent = {}      # канал -> коли з нього ВІДПРАВИЛИ сигнал
        self.signals = []           # мітки відправлених сигналів за годину
        self.pending = []           # події у вікні склеювання (К14)
        self.pending_since = None
        self.digest = []            # відкладене тихими годинами (К12)


class AttentionDispatch:
    """Між журналом подій і телефоном. Рішення питає, доставку замовляє.

    Одна причина змінюватись: ЯК зшиті між собою політика, стан і транспорт.
    Що вважати шумом, вирішує `attention_policy`; як воно летить, вирішує
    `attention_push`; який буде текст, вирішує драбина вище в цьому файлі.

    Живе в процесі СЕРВЕРА, а не раннера. Подію кладе раннер, і покласти її він
    може, коли сервер зайнятий; тому сторож не чекає виклику, а сам читає
    журнал з диска тим самим `wait`, яким його читає вкладка. Раннер від цього
    не залежить ніяк: хід завершується і йде далі, навіть якщо телефон, ntfy і
    мережа лежать усі разом."""

    def __init__(self, registry, presence, settings, sender,
                 clock=time.time, log=_stderr):
        self._registry = registry
        self._presence = presence
        self._settings = settings          # callable: -> policy.Settings
        self._sender = sender
        self._clock = clock
        self._log = log
        self._ledger = SignalLedger()
        self._thread = None
        self.sent = []                     # останні картки з міткою доставки
        self.dropped = []                  # останні придушення з причиною
        self.last_push = None

    @property
    def ledger(self):
        return self._ledger

    # -- вхід: одна подія ------------------------------------------------
    def offer(self, event, now=None):
        """Подія з журналу -> вирок. Нічого не відправляє: відправляє `tick`.

        Розділення навмисне: К14 вимагає зачекати 20 секунд, чи не доробить
        сусідній канал, а «зачекати» всередині прийому події означало б або
        заснути з подією в руках, або завести другий планувальник."""
        now = self._clock() if now is None else now
        verdict = policy.classify(event, self._presence.read(),
                                  self._settings(), now)
        if verdict.surface == policy.DIGEST:
            self._ledger.digest.append(event)
            return verdict
        if verdict.surface != policy.SIGNAL:
            return self._drop(event, verdict.reason)
        channel = str(event.get('channel') or '')
        if not policy.channel_cooled(self._ledger.channel_sent.get(channel), now):
            return self._drop(event, 'channel-cooldown')
        if not self._ledger.pending:
            self._ledger.pending_since = now
        self._ledger.pending.append(event)
        return policy.Verdict(policy.HOLD, 'coalescing')

    # -- такт: що дозріло ------------------------------------------------
    def tick(self, now=None):
        """Закрити вікно склеювання і відпустити ранкове зведення."""
        now = self._clock() if now is None else now
        out = []
        if self._ledger.pending and policy.coalesce_due(self._ledger.pending_since, now):
            out.append(self._flush_pending(now))
        # Зведення відпускаємо РІВНО тоді, коли тиша скінчилась. Окремого
        # будильника на 08:00 нема свідомо: межу вікна і так знає політика, а
        # другий годинник розʼїхався б з нею на першій же зміні налаштувань.
        if self._ledger.digest and not policy.in_quiet_hours(now, self._settings()):
            out.append(self._flush_digest(now))
        return [r for r in out if r]

    def _flush_pending(self, now):
        events, self._ledger.pending = self._ledger.pending, []
        self._ledger.pending_since = None
        groups = policy.merge_groups(events)
        if not groups:
            return None
        self._ledger.signals = policy.prune_signals(self._ledger.signals, now)
        if not policy.hourly_room(self._ledger.signals, now):
            # К13: сигнал придушено, подія лишається в журналі, тобто крапкою
            # на табі і рядком у панелі «Процеси». Втрачається дзвінок, а не
            # факт.
            for event in events:
                self._drop(event, 'hourly-ceiling')
            return None
        return self._send(note_for(groups),
                          [channel for channel, _e in groups], now)

    def _flush_digest(self, now):
        events, self._ledger.digest = self._ledger.digest, []
        groups = policy.merge_groups(events)
        if not groups:
            return None
        # Стеля години зведення не стосується: воно приходить раз за ніч і саме
        # по собі є засобом від шуму, а не його джерелом.
        self._ledger.signals = policy.prune_signals(self._ledger.signals, now)
        return self._send(digest_note(groups),
                          [channel for channel, _e in groups], now)

    # -- вихід: доставка -------------------------------------------------
    def _send(self, note, channels, now):
        """Віддати картку транспорту і ЗАПАМʼЯТАТИ, чим це скінчилось.

        Стелю рахуємо незалежно від успіху доставки: обмежувач міряє, як часто
        ми турбуємо власника, а не як часто ntfy погоджується. Інакше лежачий
        ntfy перетворював би кожну подію на нову спробу і стеля не діяла б саме
        тоді, коли подій найбільше."""
        result = self._sender.send(note)
        record = dict(note, delivered=bool(result.get('ok')),
                      reason=result.get('reason') or '', at=round(now, 3))
        self.sent = (self.sent + [record])[-KEEP_SENT:]
        self.last_push = record
        self._ledger.signals = policy.prune_signals(self._ledger.signals, now) + [now]
        for channel in channels:
            self._ledger.channel_sent[channel] = now
        if not record['delivered']:
            self._log('[attention] пуш не пішов («%s»): %s'
                      % (note.get('title') or '', record['reason']))
        return record

    def _drop(self, event, reason):
        self.dropped = (self.dropped + [(event.get('eventId'), reason)])[-KEEP_SENT:]
        return policy.Verdict(policy.DROP, reason)

    # -- життя в сервері -------------------------------------------------
    def start(self):
        """Підняти сторожа один раз. Другий виклик нічого не робить."""
        if self._thread is None:
            self._thread = threading.Thread(target=self._loop, daemon=True,
                                            name='attention-dispatch')
            self._thread.start()
        return self._thread

    def _loop(self):
        # Починаємо з поточного `rev`, а не з нуля: інакше свіжопіднятий сервер
        # вистрелив би пачкою пушів про ходи, які завершились учора.
        since = int(self._registry.snapshot(-1).get('rev') or 0)
        while True:
            try:
                self._registry.wait(since, DISPATCH_WAIT)
                snapshot = self._registry.snapshot(since)
                for event in snapshot.get('events') or []:
                    self.offer(event)
                since = int(snapshot.get('rev') or since)
                self.tick()
            except Exception as e:
                self._log('[attention] сторож сповіщень спіткнувся: %s' % e)
                time.sleep(1.0)


# ── фасад: те, що бачать server.py і runner.py ──────────────────────────────

class Attention:
    """Один дім, один реєстр, одна присутність.

    Це склейка, а не ще один шар логіки: кожен метод тут це рівно один вхід для
    транспорту (`poll`) і рівно один для джерела (`emit_turn`)."""

    #: Стан лежить ДВОМА файлами в корені дому, а не в окремій теці, і це не
    #: недбалість. Дім у розробці це сам репозиторій, і `.gitignore` уже накриває
    #: корінь правилом `tools/viz/chat/*.json` (там само живуть `telemetry.json`,
    #: `runner-heartbeat.json`, `keys.json`). Тека `attention/` під те правило не
    #: підпадає, тобто рантайм-стан ліз би в `git status` кожному, хто відкриє
    #: репозиторій, і рано чи пізно поїхав би в коміт.
    EVENTS_FILE = 'attention-events.json'
    PRESENCE_FILE = 'attention-presence.json'

    def __init__(self, home, clock=time.time, spawn=_daemon,
                 settle=SETTLE_SEC, tick=TICK, cards=None,
                 sender=None, settings=None, log=_stderr):
        self.registry = AttentionRegistry(os.path.join(home, self.EVENTS_FILE),
                                          clock=clock, tick=tick)
        self.presence = Presence(os.path.join(home, self.PRESENCE_FILE), clock=clock)
        self.cards = cards if cards is not None else ChannelCards(
            os.path.join(home, 'channels'), clock=clock)
        self.turns = TurnEvents(self.registry, self.cards, clock=clock,
                                spawn=spawn, settle=settle)
        # Шар 3. Транспорт і налаштування приходять аргументами саме тут, тобто
        # в ОДНІЙ точці збірки: тест підмінює їх подвійниками, а живий сервер
        # отримує ntfy і `user-settings.json`. Конструктор транспорту в мережу
        # не ходить, тому раннеру, який теж будує цей фасад, він нічого не
        # коштує.
        self.dispatch = AttentionDispatch(
            self.registry, self.presence,
            settings if settings is not None else (
                lambda: read_notification_settings(home)),
            sender if sender is not None else attention_push.NtfyPublisher(),
            clock=clock, log=log)

    def start_dispatch(self):
        """ЄДИНИЙ вхід для сервера: підняти сторожа сповіщень (К11-К14)."""
        return self.dispatch.start()

    def emit_turn(self, channel, outcome, started_at=None, ended_at=None):
        """ЄДИНИЙ вхід для раннера: хід у каналі завершився ось так (К1)."""
        return self.turns.emit(channel, outcome, started_at=started_at,
                               ended_at=ended_at)

    def poll(self, since=-1, wait=0.0, focus=False, channel=''):
        """ЄДИНИЙ вхід для маршруту `/api/attention` (К4).

        Той самий запит робить ДВІ речі, і це не економія, а вимога: вкладка,
        яка слухає події, за визначенням жива, тому окремий пінг присутності
        був би другим джерелом правди про одне й те саме."""
        wait = min(max(float(wait or 0), 0.0), WAIT_CEILING)
        self.presence.touch(channel=channel, focus=focus)
        self.registry.wait(since, wait)
        out = self.registry.snapshot(since)
        out['ok'] = True
        out['presence'] = self.presence.read()
        return out


_DEFAULTS = {}
_DEFAULTS_LOCK = threading.Lock()


def default(home):
    """Спільний примірник на дім. Сервер і раннер це різні процеси, тому тут
    кешується не спільний стан, а спільна ТОЧКА ВХОДУ всередині процесу."""
    key = os.path.abspath(home)
    with _DEFAULTS_LOCK:
        got = _DEFAULTS.get(key)
        if got is None:
            got = Attention(key)
            _DEFAULTS[key] = got
        return got
