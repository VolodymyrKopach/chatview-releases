#!/usr/bin/env python3
"""Політика тиші: чи взагалі дзвонити, чи зараз, чи потім одним рядком.

Спека: `specs/turn-done-notifications/spec.md` (шар 3, критерії К11-К14).

НАВІЩО ОКРЕМИЙ ФАЙЛ. Сповіщення помирає не від того, що воно не прийшло, а від
того, що його стало забагато: власник вимикає канал назавжди, і назад його не
вмикають. Тому питання «дзвонити чи ні» дорожче за питання «як дзвонити», і
воно винесене в окремий модуль, де його видно цілком і де його можна проганяти
тестом без сервера, без диска і без телефона.

МЕЖІ (розділ 6 спеки, дослівна вимога власника про SOLID). Тут НЕМА жодного
вводу-виводу: ні файлів, ні мережі, ні читання глобального годинника. Модуль не
імпортує ні `attention`, ні `attention_push`, тому залежність однобічна:

    attention.py  ->  attention_policy.py   (рішення, цей файл)
    attention.py  ->  attention_push.py     (доставка)

Час приходить АРГУМЕНТОМ `now` (секунди епохи). Без цього правила тест на тихі
години неможливий у принципі: він або чекав би 23:00, або підмінював системний
годинник. Локальна доба рахується через `time.localtime(now)`, тобто з того
самого `now`, а не з поточної миті.

Присутність теж приходить аргументом і читається з поля `seenAt` (сира мітка
часу), а не з готового `ageSec`: вік, порахований чужим годинником, зробив би
рішення залежним від того, хто його порахував.
"""
import time
from collections import namedtuple

# ── пороги, на яких стоять критерії ─────────────────────────────────────────

#: К11. Стільки сервер не бачив запиту живої вкладки означає, що людини нема за
#: компʼютером, і подія має право їхати на телефон.
AWAY_SEC = 90.0

#: Рішення власника від 19.09.2026 номер 1: поріг тиші одна хвилина. Хід,
#: коротший за це, не сповіщає НІКОЛИ і жодним каналом.
MIN_DURATION_SEC = 60

#: К13. Один сигнал на канал за хвилину і шість сигналів за годину сумарно.
CHANNEL_COOLDOWN_SEC = 60.0
HOURLY_CEILING = 6
HOUR_SEC = 3600.0

#: К14. Вікно, у якому кілька фінішів зливаються в одне сповіщення.
COALESCE_SEC = 20.0

# ── вид події це ДАНІ, а не каскад if ───────────────────────────────────────

#: notify: чи цей вид взагалі має право дзвонити;
#: urgent: чи проходить крізь тихі години (К12);
#: timed:  чи діє на нього поріг хвилини (у події без тривалості його нема).
KindTraits = namedtuple('KindTraits', 'notify urgent timed')

KIND_TRAITS = {
    'turn-done': KindTraits(notify=True, urgent=False, timed=True),
    'turn-failed': KindTraits(notify=True, urgent=True, timed=True),
    'turn-gone': KindTraits(notify=True, urgent=True, timed=True),
    # Зупинив власною рукою: не-ціль зі спеки, сповіщення не буде ніколи.
    'turn-stopped': KindTraits(notify=False, urgent=False, timed=True),
    # Питання про дозвіл: тривалості не має і крізь тихі години проходить (К12).
    'needs-permission': KindTraits(notify=True, urgent=True, timed=False),
}

#: Невідомий вид поводиться як звичайний успіх: дзвонить, але тихі години його
#: тримають. Новий вид з іншою поведінкою додає РЯДОК у таблицю вище, і жодна
#: гілка нижче від цього не змінюється.
UNKNOWN_TRAITS = KIND_TRAITS['turn-done']


def traits_for(kind):
    return KIND_TRAITS.get(kind or '', UNKNOWN_TRAITS)


# ── налаштування: мінімум ручок, максимум дефолтів ──────────────────────────

QuietHours = namedtuple('QuietHours', 'enabled start end')
Settings = namedtuple('Settings', 'quiet')

#: Рішення власника номер 3: тихі години УВІМКНЕНІ за замовчуванням. Межі це
#: хвилини доби, бо порівнювати хвилини дешевше і чесніше, ніж рядки.
DEFAULT_QUIET = QuietHours(enabled=True, start=23 * 60, end=8 * 60)
DEFAULTS = Settings(quiet=DEFAULT_QUIET)


def hhmm_minutes(value, fallback):
    """«23:00» -> 1380. Сміття повертає `fallback`, а не виняток: налаштування
    редагує людина руками, і одруківка не має гасити сповіщення назавжди."""
    try:
        hh, _sep, mm = str(value).strip().partition(':')
        got = int(hh) * 60 + int(mm or 0)
    except (TypeError, ValueError):
        return fallback
    return got if 0 <= got < 24 * 60 else fallback


def settings_from_raw(raw):
    """Блок `notifications` з `user-settings.json` -> `Settings`.

    Блоку нема, він битий або в ньому лише частина ключів: беремо дефолти. Саме
    тому фіча однаково працює і на машині, де файл ще не чіпали."""
    block = raw.get('quietHours') if isinstance(raw, dict) else None
    if not isinstance(block, dict):
        return DEFAULTS
    enabled = block.get('enabled')
    return Settings(quiet=QuietHours(
        enabled=DEFAULT_QUIET.enabled if enabled is None else bool(enabled),
        start=hhmm_minutes(block.get('from'), DEFAULT_QUIET.start),
        end=hhmm_minutes(block.get('to'), DEFAULT_QUIET.end)))


# ── тихі години ─────────────────────────────────────────────────────────────

def minutes_of_day(now, localtime=time.localtime):
    """Хвилина доби за годинником МАШИНИ для переданого `now`."""
    got = localtime(now)
    return got.tm_hour * 60 + got.tm_min


def in_quiet_hours(now, settings=DEFAULTS, localtime=time.localtime):
    """К12. Вікно з 23:00 до 08:00 перевалює через північ, тому воно не
    відрізок, а обʼєднання двох. Межі включно зліва і виключно справа: 23:00 це
    вже тиша, 08:00 це вже ранок."""
    quiet = settings.quiet
    if not quiet.enabled or quiet.start == quiet.end:
        return False
    minute = minutes_of_day(now, localtime)
    if quiet.start < quiet.end:
        return quiet.start <= minute < quiet.end
    return minute >= quiet.start or minute < quiet.end


# ── присутність ─────────────────────────────────────────────────────────────

def owner_away(presence, now, away=AWAY_SEC):
    """К11. Живої вкладки не було довше порога, тобто людини нема за компʼютером.

    Вкладки не бачили НІКОДИ (порожній `seenAt`) це теж «нема»: свіжо піднятий
    сервер без жодного відкритого вікна не має права мовчати."""
    seen = 0.0
    try:
        seen = float((presence or {}).get('seenAt') or 0)
    except (TypeError, ValueError):
        seen = 0.0
    if seen <= 0:
        return True
    return (now - seen) > away


# ── вирок на одну подію ─────────────────────────────────────────────────────

SIGNAL = 'signal'      # дзвонити (далі ще стелі і склеювання)
DIGEST = 'digest'      # відкласти у ранкове зведення
HOLD = 'hold'          # чекає закриття вікна склеювання
DROP = 'drop'          # не дзвонити; подія лишається крапкою на табі

Verdict = namedtuple('Verdict', 'surface reason')


def classify(event, presence, settings, now):
    """Подія плюс присутність плюс налаштування плюс час -> вирок. І все.

    Порядок воріт не випадковий і читається згори вниз як пріоритет:
    спершу питаємо, чи цей вид взагалі дзвонить, потім чи хід був достатньо
    довгим, і лише тоді дивимось на людину і на годинник. Дешеве і безумовне
    відсіюється першим, щоб у журналі причин не було «тихі години» там, де
    насправді спрацював поріг хвилини."""
    traits = traits_for(event.get('kind'))
    if not traits.notify:
        return Verdict(DROP, 'kind-silent')
    if traits.timed:
        try:
            duration = int(event.get('durationSec') or 0)
        except (TypeError, ValueError):
            duration = 0
        if duration < MIN_DURATION_SEC:
            return Verdict(DROP, 'too-short')
    if not owner_away(presence, now):
        return Verdict(DROP, 'owner-present')
    if in_quiet_hours(now, settings) and not traits.urgent:
        return Verdict(DIGEST, 'quiet-hours')
    return Verdict(SIGNAL, 'away')


# ── стелі і склеювання: арифметика без стану ────────────────────────────────

def channel_cooled(last_sent, now, cooldown=CHANNEL_COOLDOWN_SEC):
    """К13, перша половина: з цього каналу сигнал за останню хвилину вже йшов."""
    if last_sent is None:
        return True
    return (now - float(last_sent)) >= cooldown


def prune_signals(times, now, window=HOUR_SEC):
    """Мітки сигналів, що ще лежать у вікні години."""
    return [t for t in (times or []) if (now - t) < window]


def hourly_room(times, now, ceiling=HOURLY_CEILING, window=HOUR_SEC):
    """К13, друга половина: чи лишилось місце під сигнал у цій годині."""
    return len(prune_signals(times, now, window)) < ceiling


def coalesce_due(since, now, window=COALESCE_SEC):
    """К14: вікно склеювання закрилось, час відправляти одним пакетом."""
    return since is not None and (now - float(since)) >= window


def merge_groups(events):
    """К14: один рядок на КАНАЛ, а не на подію.

    Порядок беремо за першою появою каналу (так читається хронологія), а вміст
    за останньою подією каналу (свіжіший висновок правдивіший). Шість карток
    однієї відповіді це одна подія, а три відповіді одного каналу це один
    рядок: інакше заголовок «Доробили N каналів» брехав би числом."""
    order, latest = [], {}
    for event in events or []:
        channel = str((event or {}).get('channel') or '')
        if channel not in latest:
            order.append(channel)
        latest[channel] = event
    return [(channel, latest[channel]) for channel in order]
