#!/usr/bin/env python3
"""worksheet_store.py — THE single writer of channels/<id>/worksheet.json.

WHAT THIS IS (owner decision, chat-268, 2026-08-31)
-----------------------------------------
The chat feed is a JOURNAL: attempts, second thoughts, corrections. The worksheet is
the CLEAN COPY of the same session: only what survived. The owner's words: «коли твоя
задача вирішити питання, у чаті багато води, і треба лізти по кожному меседжу»; the
worksheet is where the answer is put once so nobody scrolls for it again.

Two design decisions come straight out of that debate and are enforced HERE, in the
data layer, not by asking the model nicely:

1. A BLOCK HOLDS WIDGETS, NOT MARKDOWN. The passive Markdown notepad that every
   consumer AI ships was explicitly rejected: it pushes copy-paste and reformatting
   back onto the person. Our blocks carry the same widget arrays the chat feed already
   renders (widgets/registry.tsx), so a verdict stays a verdict and a table stays a
   table when it moves from the feed to the sheet.

2. THERE IS NO WHOLE-DOCUMENT WRITE. The debate ranked three history strategies and
   killed "global overwrite" outright: a stage-15 conclusion must not erase the
   stage-5 one. So this module exposes append / update / archive / reorder / retitle
   and NOTHING that replaces `blocks` wholesale. An agent cannot flatten the sheet even by
   mistake, because the operation does not exist.

HISTORY IS KEPT TWICE OVER
--------------------------
  * `update` never edits in place: the previous content is pushed onto the block's
    own `history` (newest first, capped at HISTORY_MAX) with the reason for the change.
    That is the "локальне версіонування" arm of the debate, and it is what makes
    "етап 2, етап 3, етап 4 дослідження" legible instead of destructive.
  * `archive` does not shred: the block, with its history, moves to `archived` (capped
    at ARCHIVE_MAX). Removal by an agent is one word in a tool call; making it
    recoverable costs a few KB and buys back a session's work. The harness has no tool
    with a deletion word in its NAME either (tests/integration/test_mcp_registry.py),
    and that rule is upstream of this one: nothing here should read as a shredder.

Sizing is bounded on purpose: a per-block history and an archive that grow forever
would turn a hot polled file into a slow one, and this file sits on the SSE path.
"""
import json
import os
import re
import sys
import time

import summary_store

# ДЗЕРКАЛЕННЯ ІМЕН ЗМІННИХ СЕРЕДОВИЩА (CHATVIEW_* <-> LOGOPSIS_*). Стоїть вище за
# будь-яке читання середовища у цьому файлі: у власника лишились запущені служби,
# launchd-агенти і .command-файли зі старими іменами, і вони мусять і далі працювати.
# Контракт і причини: brand_env.py.
import brand_env  # noqa: F401

# Same rule as server.py / runner.py / plan_store.py: the desktop sets LOGOPSIS_HOME to
# the writable data home, dev/live runs out of the repo dir. Read lazily (not frozen at
# import) so a test can point it somewhere else.
def base_dir():
    return os.environ.get('LOGOPSIS_HOME') or os.path.dirname(os.path.abspath(__file__))


def channels_dir():
    return os.path.join(base_dir(), 'channels')


FILENAME = 'worksheet.json'

#: Versions kept per block. Ten covers "how did this conclusion evolve" without letting
#: one heavily-refined block dominate the file the poller reads.
HISTORY_MAX = 10
#: Archived blocks kept for recovery. Same reasoning, one order of magnitude smaller.
ARCHIVE_MAX = 20
#: Blocks per sheet. A sheet is a clean copy, not an archive; past this the person is
#: better served by a second sheet than by an endless scroll.
BLOCKS_MAX = 200


class WorksheetError(ValueError):
    """Bad operation or bad payload. Carries a message meant for the caller to READ:
    both the HTTP layer and the MCP tool surface it verbatim, and a vague one there
    means the agent retries the same wrong call."""


def _now():
    return time.strftime('%Y-%m-%d %H:%M')


def _write_json_atomic(path, obj):
    """Write then rename, so the poller (and SSE mtime watch) never sees a half file."""
    tmp = path + '.tmp'
    with open(tmp, 'w', encoding='utf-8') as f:
        json.dump(obj, f, ensure_ascii=False, indent=2)
    os.replace(tmp, path)


def empty_doc():
    """Shape of a sheet nobody has written to yet. Returned instead of 404 everywhere,
    so the UI has one shape to render and never a null branch."""
    return {'title': '', 'blocks': [], 'archived': [], 'rev': 0, 'updated': '', 'created': ''}


def path_for(channel, root=None):
    if not channel or '/' in channel or '\\' in channel or '..' in channel:
        raise WorksheetError('bad channel')
    return os.path.join(root or channels_dir(), channel, FILENAME)


def read_doc(channel, root=None):
    """The stored sheet, or an empty one. Never raises on a missing/corrupt file: a
    broken sheet must not take the chat down with it."""
    try:
        with open(path_for(channel, root), encoding='utf-8') as f:
            doc = json.load(f)
    except WorksheetError:
        raise
    except Exception:
        return empty_doc()
    if not isinstance(doc, dict):
        return empty_doc()
    # Start from the empty shape so a file written by an older version still comes back
    # with every field the UI reads; then let the stored values win.
    base = empty_doc()
    base.update(doc)
    if not isinstance(base.get('blocks'), list):
        base['blocks'] = []
    if not isinstance(base.get('archived'), list):
        base['archived'] = []
    return base


def _save(channel, doc, root=None):
    doc['rev'] = int(doc.get('rev') or 0) + 1
    doc['updated'] = _now()
    if not doc.get('created'):
        doc['created'] = doc['updated']
    p = path_for(channel, root)
    os.makedirs(os.path.dirname(p), exist_ok=True)
    _write_json_atomic(p, doc)
    return doc


# ── Block helpers ────────────────────────────────────────────────────────────

_SLUG_STRIP = re.compile(r'[^a-z0-9]+')


def _next_id(doc):
    """Sequential, human-readable, and collision-proof against the archive too: reusing
    an id that still sits in `archived` would make a later restore ambiguous."""
    taken = {str(b.get('id')) for b in doc.get('blocks', []) if isinstance(b, dict)}
    taken |= {str(b.get('id')) for b in doc.get('archived', []) if isinstance(b, dict)}
    n = len(taken) + 1
    while 'b%d' % n in taken:
        n += 1
    return 'b%d' % n


#: Д4 (summary-races spec). Same order of magnitude as summary_store.MAX_FREE_HTML_CHARS
#: (6000): a worksheet block sits on the same hot polling path (SSE mtime watch), so an
#: unbounded text field is the same class of defect there and here, just a different file.
MAX_WIDGET_FIELD_CHARS = 6000

#: The widget field names that carry free text across the 45 registry types (registry.tsx).
#: Not every type uses every key; checking whichever of these IS present is enough to close
#: the hole without hard-coding a schema per widget type.
_TEXT_FIELDS = ('title', 'subtitle', 'text', 'body', 'label', 'value', 'caption', 'note',
                'name', 'role')

#: STRIP/WORKSHEET vocabulary. Frozen COPY of the type -> component dispatch table in
#: logopsis/src/widgets/registry.tsx (REGISTRY_TYPES), because pulling TypeScript into
#: python is not an option. The docstring above `_clean_widgets` already promised that an
#: unknown type is rejected here, before it hits disk — it just never actually checked
#: this set, only that `type` was a non-empty string, so anything typo'd or borrowed from
#: the wrong vocabulary sailed straight onto the sheet and showed up as the very
#: UnknownWidget box the check was meant to prevent.
#:
#: Drift is caught by tests/unit/test_worksheet_registry_parity.py, which parses the real
#: registry.tsx and fails by name the moment the two sets disagree — same technique as
#: tests/unit/test_widget_registry_parity.py (runner.py's own copy) and
#: tests/unit/test_summary_vocab_parity.py (summary_store's CONTAINERS/LEAVES).
KNOWN_WIDGET_TYPES = {
    'verdict', 'heatmap', 'funnel', 'journey-map', 'timeline', 'quote-wall', 'stat-grid',
    'comparison-matrix', 'quadrant', 'flywheel', 'decision', 'callout', 'table', 'key-values',
    'badge-row', 'checklist', 'progress', 'code-block', 'accordion', 'bar-chart', 'line-chart',
    'pie-chart', 'header', 'text', 'conclusion', 'buttons', 'sources', 'reasoning', 'divider',
    'image', 'gallery', 'audio', 'video', 'file', 'attachments', 'suggestions', 'form',
    'phone-mockup', 'lean-canvas', 'prose', 'reply', 'ask', 'diff', 'skill-proposal',
    'voice-summary',
}

#: Types that DO exist, but in the OTHER vocabulary: summary_store.py's CONTAINERS | LEAVES
#: (logopsis/src/summary/nodes.tsx), the closed dictionary for the SUMMARY DOCUMENT, not
#: for the strip/worksheet. The two parted ways on purpose (chat-268 vs specs/chat-summary:
#: two different renderers, two different write paths) — confusing them is the single most
#: common way a type ends up here wrong, so it earns a message that says so explicitly
#: instead of the generic "unknown type" one. A hint names the closest strip equivalent
#: where one is obvious; where the summary type is a container with no strip counterpart
#: (sheet/section/columns/grid/card) there is nothing to suggest, and the message says that
#: too rather than guessing.
_SUMMARY_TYPE_HINT = {
    'note': 'callout',
    'quote': 'quote-wall',
    'kpi-strip': 'stat-grid',
    'fact-list': 'key-values (пари мітка/значення) або checklist (список станів)',
    'doc-header': 'header',
    'journey': 'journey-map',
    'media': 'image, gallery, audio або video, залежно від типу файлу',
}


def _check_widget_field_size(wtype, key, val, index):
    """Д4. `_clean_widgets` checked that a widget has a `type` string and nothing else:
    no type check and no length ceiling on its text fields, unlike the machine content of
    the same shape of field in summary_store (`_check_slot` for type, `MAX_FREE_HTML_CHARS`
    for length). A block sits on the same hot polling path summary does, so an oversized or
    wrongly-shaped field there is the identical defect, just unfixed here until now."""
    if isinstance(val, str):
        length = len(val)
    elif isinstance(val, list) and all(isinstance(x, str) for x in val):
        length = sum(len(x) for x in val)
    else:
        raise WorksheetError(
            'widgets[%d] ("%s"), field "%s": expected a string or an array of strings, '
            'got %s' % (index, wtype, key, type(val).__name__))
    if length > MAX_WIDGET_FIELD_CHARS:
        raise WorksheetError(
            'widgets[%d] ("%s"), field "%s": %d chars, ceiling %d'
            % (index, wtype, key, length, MAX_WIDGET_FIELD_CHARS))


def _check_widget_type(t, index):
    """The check the docstring above already promised: an unknown type is refused HERE,
    before it reaches disk, instead of surviving as an UnknownWidget box the sheet's
    owner would read as our bug. Two distinct rejections, because they are fixed two
    different ways: a type that belongs to the SUMMARY DOCUMENT vocabulary (a different
    renderer, logopsis/src/summary/nodes.tsx) needs a rename to its strip equivalent; a
    type that exists nowhere needs the caller to pick a real one."""
    if t in KNOWN_WIDGET_TYPES:
        return
    if t in summary_store.KNOWN_TYPES:
        hint = _SUMMARY_TYPE_HINT.get(t)
        raise WorksheetError(
            'widgets[%d]: type "%s" належить словнику ДОКУМЕНТА-САММАРІ '
            '(summary_store.py, logopsis/src/summary/nodes.tsx), а не стрічки/аркуша '
            '(logopsis/src/widgets/registry.tsx). Це ДВА РІЗНІ словники з різним '
            'рендерером: тип, який пасує саммарі, тут не намалюється.%s'
            % (index, t, (' Рівноцінний тип тут: %s.' % hint) if hint else
               ' Прямого відповідника серед типів стрічки нема.'))
    raise WorksheetError(
        'widgets[%d]: невідомий тип "%s". Нема ні серед типів стрічки/аркуша, ні серед '
        'типів документа-саммарі. Відомі типи стрічки: %s'
        % (index, t, ', '.join(sorted(KNOWN_WIDGET_TYPES))))


def _clean_widgets(widgets):
    """Widgets must be a non-empty list of typed objects, and each type must be one the
    strip/worksheet renderer actually knows (KNOWN_WIDGET_TYPES). Validated here rather
    than at render time: a block that renders as UnknownWidget looks like OUR bug to the
    person looking at the sheet, and by then the bad payload is already persisted."""
    if not isinstance(widgets, list) or not widgets:
        raise WorksheetError('widgets must be a non-empty array of widget objects')
    out = []
    for i, w in enumerate(widgets):
        if not isinstance(w, dict):
            raise WorksheetError('widgets[%d] must be an object' % i)
        t = w.get('type')
        if not isinstance(t, str) or not t.strip():
            raise WorksheetError('widgets[%d] has no "type"' % i)
        _check_widget_type(t, i)
        for key in _TEXT_FIELDS:
            if key in w and w[key] is not None:
                _check_widget_field_size(t, key, w[key], i)
        out.append(w)
    return out


def find_block(doc, block_id):
    for b in doc.get('blocks', []):
        if isinstance(b, dict) and str(b.get('id')) == str(block_id):
            return b
    return None


def _require_block(doc, block_id):
    b = find_block(doc, block_id)
    if b is None:
        known = ', '.join(str(x.get('id')) for x in doc.get('blocks', []) if isinstance(x, dict))
        raise WorksheetError(
            'no block "%s" on this worksheet. Existing blocks: %s'
            % (block_id, known or '(none)'))
    return b


# ── Operations ───────────────────────────────────────────────────────────────

def append_block(channel, title, widgets, source=None, root=None):
    """Add a block at the END of the sheet. This is the "модульне додавання" arm of the
    debate and the DEFAULT way a new research stage lands: stage 5 stays above, stage 15
    goes below, and the chronology of the work reads top to bottom."""
    doc = read_doc(channel, root)
    if len(doc['blocks']) >= BLOCKS_MAX:
        raise WorksheetError(
            'worksheet is full (%d blocks). Update an existing block, or start a new '
            'chat for the next topic.' % BLOCKS_MAX)
    block = {
        'id': _next_id(doc),
        'title': str(title or '').strip(),
        'widgets': _clean_widgets(widgets),
        'created': _now(),
        'updated': _now(),
        'rev': 1,
        'history': [],
    }
    if source:
        block['source'] = source
    doc['blocks'].append(block)
    _save(channel, doc, root)
    return block


class WorksheetConflict(WorksheetError):
    """`base_rev` did not match: somebody wrote to this block since the caller read it.

    Its own class, not a plain WorksheetError, because the HTTP layer answers it with 409
    rather than 400. A conflict is not a malformed call: the request was perfectly valid a
    second ago, and the UI must be able to tell those two apart to show the right thing
    ("you typed something wrong" versus "the agent got here first")."""

    def __init__(self, message, current_rev=None):
        super().__init__(message)
        self.current_rev = current_rev


def update_block(channel, block_id, title=None, widgets=None, reason=None, root=None,
                 base_rev=None):
    """Replace a block's content, PUSHING the old content onto its history.

    `title=None` / `widgets=None` mean "leave as is" — a caller fixing only the heading
    must not have to resend the whole payload, because resending is exactly where a
    truncated copy silently replaces the good one.

    `base_rev` is OPTIMISTIC CONCURRENCY, and it is optional on purpose (chat-268: «з
    урахуванням того що агент пише туди паралельно»). Pass the rev you were looking at
    when you started typing and the write is refused if anything landed in between; omit
    it and the write proceeds unconditionally.

    The asymmetry is deliberate, not laziness. A PERSON edits a concrete rendering they
    have on screen, so a mid-air collision means their text was written against a version
    that no longer exists — refusing is the only honest answer. An AGENT authors new
    content and has no version on screen to defend, so demanding base_rev from it would
    produce constant failures that mean nothing to anyone. What protects the person from
    the agent is not this check but the history: an overwritten hand edit is still the
    previous version of the block, one click away. The guarantee here was never "nobody
    overwrites anybody", it is "nothing disappears"."""
    if title is None and widgets is None:
        raise WorksheetError('nothing to update: pass "title", "widgets", or both')
    doc = read_doc(channel, root)
    b = _require_block(doc, block_id)
    if base_rev is not None:
        try:
            want = int(base_rev)
        except (TypeError, ValueError):
            raise WorksheetError('base_rev must be a number (the rev you started from)')
        have = int(b.get('rev') or 1)
        if want != have:
            raise WorksheetConflict(
                'block "%s" moved on while you were editing: you started from v%d, it is '
                'now v%d. Nothing was overwritten. Re-read the block and re-apply your '
                'change.' % (block_id, want, have), current_rev=have)
    # Snapshot BEFORE mutating, and keep the reason next to it: a version list without
    # "why" is a diff nobody can read six messages later.
    snapshot = {
        'at': b.get('updated') or b.get('created') or _now(),
        'rev': int(b.get('rev') or 1),
        'title': b.get('title', ''),
        'widgets': b.get('widgets', []),
    }
    if reason:
        snapshot['reason'] = str(reason).strip()
    hist = b.get('history') if isinstance(b.get('history'), list) else []
    b['history'] = ([snapshot] + hist)[:HISTORY_MAX]
    if title is not None:
        b['title'] = str(title).strip()
    if widgets is not None:
        b['widgets'] = _clean_widgets(widgets)
    b['rev'] = int(b.get('rev') or 1) + 1
    b['updated'] = _now()
    _save(channel, doc, root)
    return b


def archive_block(channel, block_id, root=None):
    """Move a block (with its history) to `archived`. Not a shred: see module docstring."""
    doc = read_doc(channel, root)
    b = _require_block(doc, block_id)
    doc['blocks'] = [x for x in doc['blocks'] if x is not b]
    b['archivedAt'] = _now()
    doc['archived'] = ([b] + [x for x in doc.get('archived', []) if isinstance(x, dict)])[:ARCHIVE_MAX]
    _save(channel, doc, root)
    return b


def restore_block(channel, block_id, root=None):
    """Bring an archived block back to the end of the sheet."""
    doc = read_doc(channel, root)
    hit = None
    for x in doc.get('archived', []):
        if isinstance(x, dict) and str(x.get('id')) == str(block_id):
            hit = x
            break
    if hit is None:
        raise WorksheetError('no archived block "%s" on this worksheet' % block_id)
    doc['archived'] = [x for x in doc['archived'] if x is not hit]
    hit.pop('archivedAt', None)
    hit['updated'] = _now()
    doc['blocks'].append(hit)
    _save(channel, doc, root)
    return hit


def reorder_blocks(channel, ids, root=None):
    """Reorder by an explicit id list. Ids the caller omits keep their relative order at
    the END, so a partial list ("pin these two to the top") is a legal, safe call rather
    than a way to lose everything left out."""
    if not isinstance(ids, list) or not ids:
        raise WorksheetError('ids must be a non-empty array of block ids')
    doc = read_doc(channel, root)
    by_id = {str(b.get('id')): b for b in doc['blocks'] if isinstance(b, dict)}
    unknown = [str(i) for i in ids if str(i) not in by_id]
    if unknown:
        raise WorksheetError('unknown block ids: %s' % ', '.join(unknown))
    picked = [by_id[str(i)] for i in dict.fromkeys(str(i) for i in ids)]
    rest = [b for b in doc['blocks'] if b not in picked]
    doc['blocks'] = picked + rest
    _save(channel, doc, root)
    return doc['blocks']


def set_title(channel, title, root=None):
    """Name the sheet. Top-level fields describe the present, so they update freely —
    the same split plan_store draws between `goal` and the step history."""
    doc = read_doc(channel, root)
    doc['title'] = str(title or '').strip()
    _save(channel, doc, root)
    return doc


def summary(channel, root=None):
    """Compact {blocks, rev, title} for a channel, for callers that only need the badge
    (tab strip, project-state) and must not pay for parsing the whole sheet."""
    doc = read_doc(channel, root)
    return {
        'title': doc.get('title') or '',
        'blocks': len(doc.get('blocks') or []),
        'rev': int(doc.get('rev') or 0),
        'updated': doc.get('updated') or '',
    }


# ── One entry point for the HTTP layer ───────────────────────────────────────

def apply_op(channel, op, body, root=None):
    """Dispatch a named operation. The HTTP handler stays a thin shell around this so
    the SAME validation runs for the endpoint, the MCP tool and the CLI — three callers,
    one set of rules, no drift."""
    op = (op or '').strip()
    if op == 'append':
        block = append_block(channel, body.get('title'), body.get('widgets'),
                             body.get('source'), root)
        return {'block': block}
    if op == 'update':
        block = update_block(channel, body.get('id'), body.get('title'),
                             body.get('widgets'), body.get('reason'), root,
                             base_rev=body.get('baseRev'))
        return {'block': block}
    if op == 'archive':
        return {'block': archive_block(channel, body.get('id'), root)}
    if op == 'restore':
        return {'block': restore_block(channel, body.get('id'), root)}
    if op == 'reorder':
        return {'blocks': reorder_blocks(channel, body.get('ids'), root)}
    if op == 'title':
        return {'doc': set_title(channel, body.get('title'), root)}
    raise WorksheetError(
        'unknown op "%s". Known: append, update, archive, restore, reorder, title.' % op)


def main(argv=None):
    """CLI for smoke tests and scripts:
        worksheet_store.py <channel> <op> payload.json
        echo '{...}' | worksheet_store.py <channel> <op>
        worksheet_store.py <channel> get
    """
    args = list(sys.argv[1:] if argv is None else argv)
    if not args:
        sys.stderr.write('worksheet_store: usage: <channel> <op> [payload.json]\n')
        return 1
    channel = args[0]
    op = args[1] if len(args) > 1 else 'get'
    if op == 'get':
        print(json.dumps(read_doc(channel), ensure_ascii=False, indent=2))
        return 0
    src = args[2] if len(args) > 2 else None
    raw = open(src, encoding='utf-8').read() if src else sys.stdin.read()
    try:
        body = json.loads(raw) if raw.strip() else {}
    except Exception as e:
        sys.stderr.write('worksheet_store: invalid JSON — %s\n' % e)
        return 1
    try:
        out = apply_op(channel, op, body)
    except WorksheetError as e:
        sys.stderr.write('worksheet_store: %s\n' % e)
        return 1
    print(json.dumps(out, ensure_ascii=False, indent=2))
    return 0


if __name__ == '__main__':
    sys.exit(main())
