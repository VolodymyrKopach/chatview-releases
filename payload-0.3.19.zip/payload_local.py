#!/usr/bin/env python3
"""ЗГЕНЕРОВАНО. Руками не редагувати: правку зітре наступна ж збірка.

    python3 desktop/gen_payload_local.py --write

Що це. НАШІ власні модулі, які складають пейлоуд: усе, до чого можна дійти по графу
імпортів від точок входу (server.py, runner.py, agent_worker.py, chatview_updater.py,
harvest-skills.py), включно з вкладеними імпортами на будь-якій глибині.

chatview_updater.py імпортує цей кортеж одним рядком і складає з нього PAYLOAD_FILES.
Список зібрано з коду, а не з памʼяті людини, рівно тому, що ручна версія за тиждень
тричі відправила в люди збірку без модуля, який апка імпортує. Поруч з кожним рядком
стоять файли, звідки модуль досяжний. Джерело правди: desktop/gen_payload_local.py.
"""

LOCAL_MODULES = (
    'agent_room.py',           # runner.py (на рівні модуля) (+1)
    'agent_worker.py',         # ТОЧКА ВХОДУ (причина в ROOTS, desktop/gen_payload_local.py)
    'agy_models.py',           # model_choice.py (на рівні модуля) (+2)
    'attention.py',            # runner.py (вкладений) (+1)
    'attention_policy.py',     # attention.py (на рівні модуля)
    'attention_push.py',       # attention.py (на рівні модуля)
    'auth_store.py',           # cloud_sync.py (на рівні модуля) (+1)
    'batch_claim.py',          # batch_publish.py (на рівні модуля)
    'batch_detect.py',         # batch_publish.py (на рівні модуля)
    'batch_publish.py',        # agent_worker.py (на рівні модуля)
    'batch_summary.py',        # batch_publish.py (на рівні модуля)
    'brand_env.py',            # agent_worker.py (на рівні модуля) (+12)
    'chatview_onboarding.py',  # server.py (вкладений)
    'chatview_platform.py',    # chatview_onboarding.py (вкладений) (+3)
    'chatview_updater.py',     # ТОЧКА ВХОДУ (причина в ROOTS, desktop/gen_payload_local.py) (+2)
    'claude_models.py',        # runner.py (на рівні модуля) (+1)
    'cleanup_scan.py',         # server.py (вкладений)
    'cloud_sync.py',           # server.py (на рівні модуля)
    'emoji_raster.py',         # gadget_pwa.py (на рівні модуля)
    'entities.py',             # cloud_sync.py (вкладений) (+6)
    'export_policy.py',        # memory_store.py (на рівні модуля) (+2)
    'gadget_pwa.py',           # server.py (вкладений)
    'harvest-skills.py',       # ТОЧКА ВХОДУ (причина в ROOTS, desktop/gen_payload_local.py)
    'helper_store.py',         # server.py (вкладений)
    'home_migrate.py',         # home_spread.py (на рівні модуля) (+1)
    'home_spread.py',          # cloud_sync.py (на рівні модуля) (+3)
    'jobs.py',                 # agent_worker.py (на рівні модуля) (+3)
    'library_cache.py',        # skill_search.py (вкладений)
    'media_normalize.py',      # runner.py (на рівні модуля) (+2)
    'memory_learn.py',         # runner.py (вкладений)
    'memory_store.py',         # memory_learn.py (на рівні модуля) (+2)
    'model_choice.py',         # server.py (вкладений)
    'onboarding_store.py',     # server.py (на рівні модуля)
    'payload_local.py',        # згенерований список їде разом з кодом
    'plan_autopatch.py',       # agent_worker.py (на рівні модуля) (+1)
    'plan_autosync_tick.py',   # server.py (на рівні модуля)
    'plan_order_proof.py',     # plan_store.py (вкладений)
    'plan_staleness.py',       # plan_autosync_tick.py (на рівні модуля)
    'plan_store.py',           # agent_worker.py (на рівні модуля) (+6)
    'project_state.py',        # runner.py (вкладений) (+1)
    'rules_store.py',          # runner.py (на рівні модуля) (+1)
    'runner.py',               # ТОЧКА ВХОДУ (причина в ROOTS, desktop/gen_payload_local.py) (+6)
    'runner_pulse.py',         # runner.py (на рівні модуля) (+1)
    'server.py',               # ТОЧКА ВХОДУ (причина в ROOTS, desktop/gen_payload_local.py)
    'skill_asks.py',           # server.py (на рівні модуля)
    'skill_live.py',           # server.py (на рівні модуля)
    'skill_scan.py',           # server.py (на рівні модуля) (+1)
    'skill_search.py',         # server.py (на рівні модуля) (+1)
    'specs_board.py',          # server.py (вкладений)
    'stt_install.py',          # server.py (на рівні модуля)
    'summary_generate.py',     # server.py (вкладений)
    'summary_sanitize.py',     # summary_store.py (на рівні модуля)
    'summary_store.py',        # server.py (вкладений) (+2)
    'system_lang.py',          # server.py (на рівні модуля)
    'tab_label.py',            # plan_store.py (на рівні модуля) (+1)
    'telemetry.py',            # chatview_onboarding.py (на рівні модуля) (+2)
    'tls_trust.py',            # runner.py (на рівні модуля) (+1)
    'transfer.py',             # server.py (на рівні модуля)
    'usage_api.py',            # server.py (вкладений)
    'widget_dialects.py',      # runner.py (на рівні модуля)
    'worksheet_store.py',      # server.py (вкладений)
)

#: Скільки модулів їде пейлоудом. Явне число ловить обрізаний або порожній
#: список: якби генератор колись віддав нуль рядків, апка поїхала б без коду
#: і зрозуміли б це вже в людини. Тут це помітно в диффі одним рядком.
LOCAL_MODULE_COUNT = 61
