#!/usr/bin/env python3
"""Гаджет як встановлювана апка: веб-маніфест, іконки, посилання в самій сторінці.

Спека: specs/gadget-pwa/spec.md, критерії К3 і К7. Сабтаск S2.
Тест: tools/viz/chat/tests/unit/test_gadget_pwa.py
      tools/viz/chat/tests/integration/test_gadget_pwa_wire.py

ЩО ТУТ ВІДБУВАЄТЬСЯ. Гаджет уже має все, чого хоче браузер, але в наших словах: назва та
емодзі лежать у `apps/<id>/manifest.json`, сторінка живе на `/apps/<id>/view.html`, стан
на сервері. Бракує лише перекладу на мову браузера. Цей модуль і є той переклад:

  * `web_manifest`  наш manifest.json -> веб-маніфест з областю дії рівно `/apps/<id>/`;
  * `icon_png`      емодзі -> растрова іконка потрібного розміру;
  * `inject_head`   вставляє посилання на маніфест у видачу сторінки гаджета.

ЧОМУ ВСТАВКА, А НЕ ПРАВКА СТОРІНОК. Маніфест підхоплюється лише тоді, коли сторінка на
нього посилається. Гаджетів на машині пʼятнадцять, писані вони моделлю в різний час, і
правка кожного руками означала б, що наступний гаджет знову народиться невстановлюваним.
Вставка при видачі робить встановлюваними ВСІ, включно з тими, яких ще нема.

ЧОМУ ОБЛАСТЬ ДІЇ САМЕ ШЛЯХ ГАДЖЕТА. Це та сама межа, по якій уже розділені дані
(`apps/<id>/state.json`). Одна апка = один гаджет = один шлях, тож дві встановлені апки
не можуть ні переплутатись, ні відкрити одна одну.
"""
import hashlib
import json
import re
import urllib.parse

import emoji_raster

# Розміри, які ми віддаємо. 192 і 512 це те, чого просить браузер для встановлення,
# 180 це іконка домашнього екрана в Safari. Довільні розміри свідомо не малюємо: інакше
# будь-хто ззовні міг би замовити нам тисячу різних растрів.
ICON_SIZES = (180, 192, 512)
_ROUTE_RE = re.compile(
    r'^/apps/(?P<gid>[^/]+)/(?:(?P<manifest>manifest\.webmanifest)'
    r'|icon-(?P<size>\d+)\.png|(?P<view>view\.html)|(?P<sw>sw\.js))$')

# Готові растри тримаємо в памʼяті: малювання коштує помітно, а запит на іконку
# повторюється щоразу, коли операційна система вирішує перемалювати док.
_icon_cache = {}
_ICON_CACHE_MAX = 96

# Частка плитки, яку займає сам емодзі. 0.62 обрано так, щоб гліф лишався всередині
# безпечної зони маскованих іконок (операційна система може обрізати кути до кола).
_GLYPH_RATIO = 0.62


def _safe_gid(gid):
    """Той самий припуск, що й у server.py._gadget_dir: ідентифікатор це імʼя теки."""
    if not gid or '/' in gid or '\\' in gid or '..' in gid or '%' in gid:
        return None
    return gid


def route(path_only):
    """Розібрати шлях запиту. -> {'kind','gid','size'} або None.

    Чотири види: 'manifest', 'icon', 'view', 'sw'. Усе інше не наше, хай віддає статика."""
    m = _ROUTE_RE.match(path_only or '')
    if not m:
        return None
    gid = _safe_gid(m.group('gid'))
    if not gid:
        return None
    if m.group('manifest'):
        return {'kind': 'manifest', 'gid': gid, 'size': None}
    if m.group('sw'):
        return {'kind': 'sw', 'gid': gid, 'size': None}
    if m.group('view'):
        return {'kind': 'view', 'gid': gid, 'size': None}
    size = int(m.group('size'))
    if size not in ICON_SIZES:
        return None
    return {'kind': 'icon', 'gid': gid, 'size': size}


# ── кольори ───────────────────────────────────────────────────────────────────

def _hsl_to_rgb(h, s, ll):
    def f(n):
        k = (n + h / 30.0) % 12
        a = s * min(ll, 1 - ll)
        return ll - a * max(-1, min(k - 3, min(9 - k, 1)))
    return tuple(int(round(255 * f(n))) for n in (0, 8, 4))


# Підкладки беремо не з суцільного кола, а з СІТКИ: 12 тонів через 30 градусів на 3
# насиченості. Заміряно на реальних гаджетах: вільний відтінок з хешу дав 356, 3 і 5
# градусів у трьох апок підряд, тобто три однакові рожеві плитки в доці. Сітка робить
# сусідні значення хеша ВІДМІННИМИ на око, а не на градус.
_TILE_HUES = 12
_TILE_TINTS = ((0.55, 0.90), (0.38, 0.84), (0.70, 0.94))


def tile_color(gid, icon=''):
    """Колір підкладки іконки. Виводиться з ідентифікатора, тому сталий і різний.

    Різний він не для краси: коли на машині нема шрифту з растрами, підкладка це все, що
    відрізняє дві апки в доці одна від одної."""
    seed = hashlib.md5(('%s|%s' % (gid, icon)).encode('utf-8')).hexdigest()
    hue = (int(seed[0:2], 16) % _TILE_HUES) * (360 // _TILE_HUES)
    sat, light = _TILE_TINTS[int(seed[2:4], 16) % len(_TILE_TINTS)]
    r, g, b = _hsl_to_rgb(hue, sat, light)
    return '#%02x%02x%02x' % (r, g, b)


def _rgb(hex_color):
    hex_color = hex_color.lstrip('#')
    return tuple(int(hex_color[i:i + 2], 16) for i in (0, 2, 4))


# ── іконка ────────────────────────────────────────────────────────────────────

def icon_png(gid, gmanifest, size):
    """Растрова іконка гаджета: емодзі на кольоровій плитці. Завжди повертає png."""
    if size not in ICON_SIZES:
        size = 192
    icon = (gmanifest or {}).get('icon') or ''
    color = tile_color(gid, icon)
    key = (icon, color, size)
    hit = _icon_cache.get(key)
    if hit is not None:
        return hit
    blob = _draw_icon(icon, color, size)
    if len(_icon_cache) >= _ICON_CACHE_MAX:
        _icon_cache.clear()
    _icon_cache[key] = blob
    return blob


def _draw_icon(icon, color, size):
    r, g, b = _rgb(color)
    pix = bytearray(bytes((r, g, b, 255)) * (size * size))
    inner = int(size * _GLYPH_RATIO) // 2 * 2
    glyph = emoji_raster.rgba_for(icon, inner) if icon else None
    if glyph:
        _, _, gpix = glyph
        off = (size - inner) // 2
        for y in range(inner):
            row = (y + off) * size * 4
            src = y * inner * 4
            for x in range(inner):
                a = gpix[src + x * 4 + 3]
                if not a:
                    continue
                o = row + (x + off) * 4
                if a == 255:
                    pix[o:o + 3] = gpix[src + x * 4:src + x * 4 + 3]
                else:
                    inv = 255 - a
                    for c in range(3):
                        pix[o + c] = (gpix[src + x * 4 + c] * a + pix[o + c] * inv) // 255
    return emoji_raster.encode_png(size, size, pix, alpha=False)


# ── веб-маніфест ──────────────────────────────────────────────────────────────

def _paths(gid):
    q = urllib.parse.quote(gid)
    return {
        'scope': '/apps/%s/' % q,
        'start': '/apps/%s/view.html' % q,
        'manifest': '/apps/%s/manifest.webmanifest' % q,
        'icon': lambda s: '/apps/%s/icon-%d.png' % (q, s),
    }


def web_manifest(gid, gmanifest):
    """Веб-маніфест ОДНОГО гаджета. Читається з його manifest.json у мить запиту.

    Саме «у мить запиту» і закриває К7: перейменували гаджет, наступний запит уже несе
    нову назву, перевстановлювати апку не треба."""
    gm = gmanifest or {}
    p = _paths(gid)
    name = (gm.get('name') or gid or 'Гаджет').strip()
    icon = gm.get('icon') or ''
    color = tile_color(gid, icon)
    return {
        # `id` тримає тотожність апки окремо від адреси старту: назва може мінятись,
        # апка лишається тією самою і не встановлюється вдруге.
        'id': p['scope'],
        'name': name,
        'short_name': name[:30],
        'description': (gm.get('description') or '').strip()[:300],
        'lang': 'uk',
        'dir': 'ltr',
        'start_url': p['start'],
        'scope': p['scope'],
        'display': 'standalone',
        'orientation': 'any',
        'background_color': '#ffffff',
        'theme_color': color,
        'icons': [
            {'src': p['icon'](192), 'sizes': '192x192', 'type': 'image/png',
             'purpose': 'any maskable'},
            {'src': p['icon'](512), 'sizes': '512x512', 'type': 'image/png',
             'purpose': 'any maskable'},
        ],
    }


def manifest_etag(gmanifest):
    """Мітка версії видачі. Міняється рівно тоді, коли міняється видиме людині."""
    gm = gmanifest or {}
    seed = '|'.join(str(gm.get(k) or '') for k in ('name', 'icon', 'description'))
    return 'W/"%s"' % hashlib.md5(seed.encode('utf-8')).hexdigest()[:16]


def manifest_bytes(gid, gmanifest):
    return json.dumps(web_manifest(gid, gmanifest), ensure_ascii=False,
                      indent=2).encode('utf-8')


# ── service worker ────────────────────────────────────────────────────────────
#
# Воркер потрібен не заради швидкості: без обробника `fetch` браузер узагалі не пропонує
# встановити сторінку апкою, тобто без нього кнопка встановлення нікуди не веде.
#
# Дві межі, і обидві тут не з обережності, а з заміру наслідку.
#
# ОБОЛОНКА ЗАВЖДИ З ВЕРСІЄЮ. Версія це хеш САМОЇ сторінки гаджета. Перезібрали гаджет,
# сторінка змінилась, змінився хеш, змінились байти воркера, і браузер бачить нового
# воркера. Без цього перезбірка була б невидимою, а виглядало б це як «модель нічого не
# зробила», тобто помилка воркера маскується під чужий баг.
#
# ДАНІ НІКОЛИ. Стан гаджета лежить на сервері, і саме тому вбудована рамка і встановлена
# апка бачать одне й те саме. Досить закешувати одну відповідь з даними, і у вікні
# зʼявиться вчорашній стан, а людина вирішить, що зламалась синхронізація. Тому воркер
# бере на себе РІВНО одну адресу, сторінку цього гаджета, а все інше пропускає в мережу
# незайманим (не «кешує обережно», а не торкається взагалі).
#
# І сторінку він теж бере спершу з мережі, а кеш тримає як запас на випадок, коли сервера
# нема. Ціна цього на localhost це одиниці мілісекунд, а виграш у тому, що перше ж
# перезавантаження показує НОВУ оболонку, а не наступне після нього.

SW_CACHE_PREFIX = 'gadget-shell'


def shell_version(view_html):
    """Версія оболонки = хеш сторінки гаджета. Змінилась сторінка, змінилась версія."""
    if isinstance(view_html, str):
        view_html = view_html.encode('utf-8')
    return hashlib.md5(view_html or b'').hexdigest()[:12]


def sw_cache_name(gid, version):
    return '%s:%s:%s' % (SW_CACHE_PREFIX, gid, version)


def sw_etag(version):
    return 'W/"sw-%s"' % version


_SW_TEMPLATE = '''\
/* Service worker гаджета «%(gid)s». Складений сервером, у теці гаджета його нема.
   Спека: specs/gadget-pwa/spec.md (S3). Область дії рівно %(scope)s.
   Оболонка кешується під версією %(version)s, усе решта йде в мережу незайманим. */
const GID = "%(gid)s";
const SCOPE = "%(scope)s";
const SHELL = "%(shell)s";
const VERSION = "%(version)s";
const CACHE = "%(cache)s";

self.addEventListener("install", (e) => {
  e.waitUntil((async () => {
    try {
      const c = await caches.open(CACHE);
      await c.add(new Request(SHELL, { cache: "reload" }));
    } catch (err) {
      // Не змогли скласти оболонку зараз, покладемо її першим же відкриттям вікна.
    }
    await self.skipWaiting();
  })());
});

// Прибрати СВОЇ старі версії. Кеші сусідніх гаджетів не наші, їх не чіпаємо.
async function sweep() {
  const mine = "%(prefix)s:" + GID + ":";
  for (const name of await caches.keys()) {
    if (name.indexOf(mine) === 0 && name !== CACHE) await caches.delete(name);
  }
}

self.addEventListener("activate", (e) => {
  e.waitUntil((async () => {
    await sweep();
    await self.clients.claim();
  })());
});

self.addEventListener("fetch", (e) => {
  const req = e.request;
  if (req.method !== "GET") return;
  let url;
  try {
    url = new URL(req.url);
  } catch (err) {
    return;
  }
  // Єдина адреса, яку воркер бере на себе. Усе інше, включно зі станом гаджета і
  // зверненнями до сервера, проходить повз нього прямо в мережу.
  if (url.origin !== self.location.origin || url.pathname !== SHELL) return;
  e.respondWith(shell(req));
});

let sweptOnFetch = false;

async function shell(req) {
  // Друге прибирання, і воно не зайве. Заміряно (proof-gadget-pwa/s3-cache-zamir.txt):
  // після перезбірки гаджета старий кеш лишався жити поруч з новим. Причина в тому, що
  // навігацію, яка вже пішла в СТАРОГО воркера, він дообслуговує і кладе копію в свій
  // кеш ПІСЛЯ того, як новий воркер той кеш прибрав. Перший же запит, який дійшов сюди,
  // означає, що старий воркер більше нічого не обслуговує, тому прибирати можна начисто.
  if (!sweptOnFetch) {
    sweptOnFetch = true;
    sweep().catch(() => {});
  }
  // Ключ кешу без запиту: інакше кожен ?ts= клав би в кеш ще одну копію тієї ж сторінки.
  const key = new Request(SHELL);
  try {
    const fresh = await fetch(req);
    if (fresh && fresh.ok) {
      const copy = fresh.clone();
      const c = await caches.open(CACHE);
      await c.put(key, copy);
    }
    return fresh;
  } catch (err) {
    const c = await caches.open(CACHE);
    const kept = await c.match(key);
    if (kept) return kept;
    throw err;
  }
}
'''


def sw_js(gid, version):
    """Джерело воркера ОДНОГО гаджета. Різні гаджети = різні байти = різні реєстрації."""
    p = _paths(gid)
    return _SW_TEMPLATE % {
        'gid': gid.replace('"', ''),
        'scope': p['scope'],
        'shell': p['start'],
        'version': version,
        'cache': sw_cache_name(gid, version),
        'prefix': SW_CACHE_PREFIX,
    }


# ── вставка в сторінку гаджета ────────────────────────────────────────────────

_HEAD_RE = re.compile(r'<head[^>]*>', re.I)


def head_block(gid, gmanifest=None):
    q = urllib.parse.quote(gid)
    name = ((gmanifest or {}).get('name') or gid).replace('"', '&quot;')
    return (
        '\n<!-- gadget-pwa: додано сервером, у самому view.html цього нема -->\n'
        '<link rel="manifest" href="/apps/%s/manifest.webmanifest">\n'
        '<link rel="icon" type="image/png" sizes="192x192" href="/apps/%s/icon-192.png">\n'
        '<link rel="apple-touch-icon" href="/apps/%s/icon-180.png">\n'
        '<meta name="mobile-web-app-capable" content="yes">\n'
        '<meta name="apple-mobile-web-app-capable" content="yes">\n'
        '<meta name="apple-mobile-web-app-status-bar-style" content="default">\n'
        '<meta name="apple-mobile-web-app-title" content="%s">\n'
        '%s' % (q, q, q, name, boot_script(gid))
    )


def boot_script(gid):
    """Скрипт, який сервер додає у видачу сторінки гаджета. Робить три речі.

    ПЕРШЕ: реєструє воркера. Живе це тут, а не у `view.html`, з тієї самої причини, що й
    посилання на маніфест: гаджетів пʼятнадцять, писані вони в різний час, і наступний
    народиться так само невстановлюваним, якщо цього рядка не буде в САМІЙ ВИДАЧІ.

    ДРУГЕ: коли сторінку відкрито з `?pwa=install`, ловить подію встановлення і показує
    рідне вікно браузера, а наслідок переказує тому, хто це вікно відкрив. Так працює
    кнопка в рамці Logopsis: у неї самої події не буде ніколи, бо гаджет там в iframe, а
    подія приходить лише у верхнє вікно.

    ТРЕТЄ: встановлена апка позначає себе сама. Дізнатись ззовні, чи апку встановлено,
    браузер не дає, тому єдиний чесний свідок це саме вікно апки: воно бачить свій
    display-mode і лишає позначку в сховищі того самого походження, з якого її потім
    читає Logopsis."""
    q = urllib.parse.quote(gid)
    j = json.dumps(gid, ensure_ascii=False)
    return (
        '<script>\n'
        '(function(){\n'
        '  var GID = %s;\n'
        '  if ("serviceWorker" in navigator) {\n'
        '    navigator.serviceWorker.register("/apps/%s/sw.js", {scope: "/apps/%s/"})\n'
        '      .catch(function(e){ console.warn("[gadget-pwa] воркер не став:", e); });\n'
        '  }\n'
        '  function mark(){ try { localStorage.setItem("gadget-pwa-installed:" + GID,'
        ' "1"); } catch (e) {} }\n'
        '  try { if (matchMedia("(display-mode: standalone)").matches) mark(); }'
        ' catch (e) {}\n'
        '  var want = /[?&]pwa=install(&|$)/.test(location.search);\n'
        '  var told = false, prompted = false;\n'
        '  function tell(state){\n'
        '    if (told || !window.opener) return;\n'
        '    told = true;\n'
        '    try { window.opener.postMessage({gadgetPwa: {id: GID, state: state}},'
        ' location.origin); } catch (e) {}\n'
        '  }\n'
        '  window.addEventListener("beforeinstallprompt", function(e){\n'
        '    e.preventDefault();\n'
        '    if (!want || prompted) return;\n'
        '    prompted = true;\n'
        '    told = false;\n'
        '    Promise.resolve(e.prompt()).then(function(){ return e.userChoice; })\n'
        '      .then(function(c){ tell(c && c.outcome === "accepted" ? "installed"'
        ' : "dismissed"); })\n'
        '      .catch(function(){ tell("no-event"); });\n'
        '  });\n'
        '  window.addEventListener("appinstalled", function(){ mark(); tell("installed");'
        ' });\n'
        # Браузер уміє встановлювати, але події не дав: апка вже стоїть, або сторінка не
        # пройшла критерій. Мовчання тут читалось би як зламана кнопка, тому кажемо прямо.
        #
        # Вісім секунд, а не чотири. Заміряно на холодному профілі: там воркер стає в ту
        # саму мить, що й відкривається вікно, і подія приходила пізніше за чотири
        # секунди. Ціна помилки несиметрична: зарано сказати «не вийшло» означає збрехати
        # людині, у якої все працює, тому чекаємо довше. І `told` знімається, коли подія
        # таки прийшла, щоб пізня подія перебила ранній висновок.
        '  if (want) setTimeout(function(){ if (!prompted) tell("no-event"); }, 8000);\n'
        '})();\n'
        '</script>\n' % (j, q, q)
    )


# ── кліренс під склом оболонки ────────────────────────────────────────────────
#
# Спека: specs/gadget-glass-headroom/spec.md (G2: К1, К2, К3, К7, К8, К10).
#
# ЩО ЦЕ. Гаджет у колонці Logopsis накритий двома ярусами скла оболонки, і його верхня
# смуга лежить під ними. Число «скільки скла над вмістом» знає рівно один учасник: та
# оболонка, яка це скло малює. Вона рахує його з реальної геометрії і передає гаджету
# двома каналами: стартове значення в адресі (`?glass=`), подальші зміни повідомленням
# `{glassTop}` тим самим каналом, яким уже ходить тема.
#
# ЧОМУ ЦЕ ВСТАВЛЯЄ СЕРВЕР, А НЕ ПИШЕ АВТОР ГАДЖЕТА. Та сама причина, що й у маніфеста
# вище, лише дорожча: доти компенсацію писав КОЖЕН гаджет сам, і всі вони прив'язали її
# до власної ширини (`@media (max-width:767px){body{padding-top: ... 52px}}`). Ширина
# вікна гаджета не знає нічого про скло, тому у вузькій колонці виходило 52px зайвих, а в
# широкій 14px там, де скла 108px. Правило в голові КОЖНОЇ видачі робить кліренс
# властивістю самої платформи: новий гаджет отримує його без жодного рядка в себе (К10).
#
# ХТО САМЕ ОТРИМУЄ ВІДСТУП. За замовчуванням гортається сторінка, тому відступ лягає на
# КОРІНЬ документа і складається з власним відступом `body` (К8: додає, а не замінює).
# Гаджет із власним внутрішнім скролером називає його атрибутом `data-glass-scroll`, і
# тоді кліренс переїжджає туди РОЗПІРКОЮ перед першим елементом, а корінь лишається
# чистим (К7). Власний відступ скролера при цьому не чіпається взагалі.
#
# ЧОМУ СТИЛЬ ІДЕ В КІНЕЦЬ ГОЛОВИ, А НЕ НА ПОЧАТОК. Специфічність `[data-glass-scroll]`
# і `.col-body` однакова, тож спір вирішує порядок. Блок на початку голови програв би
# власним стилям гаджета мовчки, а тихий програш тут читався б як «механізм не працює».
# `:root` (0,1,0) при цьому б'є `*{padding:0}` (0,0,0) у будь-якому порядку, тому корінь
# у безпеці навіть у гаджетів зі скиданням через зірочку (karkas, notes-gallery).

_HEAD_END_RE = re.compile(r'</head\s*>', re.I)

GLASS_MARK = 'data-glass-scroll'
GLASS_VAR = '--cv-glass-top'


def glass_block():
    """Єдине правило верхнього кліренсу. Одне на всі гаджети, включно з майбутніми."""
    return (
        '\n<!-- gadget-glass-headroom: додано сервером, у самому view.html цього нема -->\n'
        '<style>\n'
        '  :root{--cv-glass-top:0px}\n'
        '  /* Типовий випадок: гортається сторінка. Відступ на КОРЕНІ складається з\n'
        '     власним відступом body, тому вміст не притискається до скла впритул. */\n'
        '  :root{padding-top:var(--cv-glass-top,0px)}\n'
        '  /* Гаджет назвав свій скролер: корінь лишається чистим, інакше вийшов би\n'
        '     подвійний відступ. */\n'
        '  :root:has([' + GLASS_MARK + ']){padding-top:0}\n'
        '  /* Кліренс для поміченого скролера це РОЗПІРКА першим елементом, а не його\n'
        '     власний відступ. Відступом зробити не вийде: наше правило перебиває правило\n'
        '     гаджета, тому прочитати з розкладки, скільки відступу було ВЛАСНОГО, вже\n'
        '     нічим, і спроба скласти суму давала подвоєння (заміряно: 224 замість 120,\n'
        '     work/gadget-glass-headroom/rest/k7-k10-log.txt). Розпірка не чіпає власний\n'
        '     відступ узагалі, а заразом гортається разом із вмістом, тобто вміст їде під\n'
        '     скло рівно так само, як у гаджета зі звичайною сторінкою. */\n'
        '  [' + GLASS_MARK + ']::before{content:"";display:block;flex:0 0 auto;'
        'height:var(--cv-glass-top,0px)}\n'
        '</style>\n'
        '<script>\n'
        '(function(){\n'
        '  var root = document.documentElement;\n'
        '  function set(px){\n'
        '    var n = Math.round(Number(px));\n'
        '    if (!isFinite(n) || n < 0) n = 0;\n'
        '    root.style.setProperty("--cv-glass-top", n + "px");\n'
        '  }\n'
        '  // Стартове значення з адреси: перший кадр мусить малюватись уже правильним.\n'
        '  var m = /[?&]glass=(\\d+)/.exec(location.search);\n'
        '  set(m ? m[1] : 0);\n'
        '  // Живі зміни (колонка <-> повний екран, зміна розкладки). Перезавантажувати\n'
        '  // кадр заради відступу не можна: це губить стан гаджета.\n'
        '  window.addEventListener("message", function(e){\n'
        '    if (!e.data || typeof e.data.glassTop !== "number") return;\n'
        '    set(e.data.glassTop);\n'
        '  });\n'
        '})();\n'
        '</script>\n'
    )


def inject_head(html, gid, gmanifest=None):
    """Додати посилання на маніфест у видачу сторінки гаджета.

    Ідемпотентно: сторінка, у якій посилання вже є (наприклад гаджет колись його собі
    пропише), лишається як була. Сторінка без `<head>` теж не губиться."""
    if not html or 'manifest.webmanifest' in html:
        return html
    block = head_block(gid, gmanifest)
    m = _HEAD_RE.search(html)
    out = html[:m.end()] + block + html[m.end():] if m else block + html
    return inject_glass(out)


def inject_glass(html):
    """Додати правило кліренсу в КІНЕЦЬ голови сторінки гаджета.

    Саме в кінець, а не поруч із маніфестом: спір зі стилями самого гаджета вирішує
    порядок, і блок на початку голови програв би їм мовчки. Ідемпотентно.

    ОЗНАКА «ВЖЕ ВСТАВЛЕНО» ЦЕ ЗМІННА, А НЕ АТРИБУТ. Спершу тут стояло `GLASS_MARK in html`,
    і воно мовчки вимикало ввесь механізм рівно для тих сторінок, заради яких атрибут і
    заведено: гаджет із внутрішнім скролером ПИШЕ `data-glass-scroll` у своїй розмітці,
    тому сторінка «вже містила маркер» ще до вставки. Спіймано заміром на пробному
    гаджеті (work/gadget-glass-headroom/rest/k7-k10-log.txt: скролер лишився з власними
    8px замість 8 плюс кліренс). Назва змінної в сторінці гаджета не зустрічається
    ніколи, бо оголошує її саме цей блок."""
    if not html or GLASS_VAR in html:
        return html
    block = glass_block()
    m = _HEAD_END_RE.search(html)
    if m:
        return html[:m.start()] + block + html[m.start():]
    return block + html
