#!/usr/bin/env python3
"""Хмарний синк Логопсісу (specs/logopsis-cloud-sync-sharing/spec.md, S2-S4).

ЩО ЦЕ. Диск лишається головним (local-first, розділ 6.1 спеки): усі писарі
(render-message.cjs, set-plan.cjs, хуки, агенти) і далі пишуть файли як писали.
Цей модуль ПОРУЧ дзеркалить три корені (chat-канали, стан гаджетів, дані канви) у
Supabase Storage bucket `homes` + реєстр `public.items`, від імені залогіненого
користувача (anon-ключ + його access-токен, тобто через RLS, БЕЗ service_role —
той самий контракт, що auth_store.py вже тримає для сесії).

ОДИН ФОНОВИЙ ТІК робить і push (локальне -> хмара), і pull (хмара -> локальне) за той
самий прохід, мірруючи `plan_autosync_tick.start_background_loop`: даемон-потік,
`tick()` ловить УСЕ і ніколи не кидає далі (К7 — синк не має права покласти сервер чи
завадити роботі з диска, коли мережі чи логіну нема).

БІЛИЙ СПИСОК, НЕ ЧОРНИЙ (спека, розділ 6.3 і ризики). `is_syncable_file` починається
з дозволених текстових розширень і стелі розміру; `keys.json`, `session.json`,
`.env*` виключені явним іменем НЕЗАЛЕЖНО від того, де вони лежать — навіть якщо
корінь синку колись розшириться, ці імена не поїдуть.

КОНФЛІКТИ (К8). Маніфест (`cloud-sync-state.json`, поруч із session.json під
LOGOPSIS_HOME, той самий gitignore-патерн `tools/viz/chat/*.json`) памʼятає хеш
кожного вже відданого в хмару файлу. На pull: якщо локальний вміст відрізняється від
хмарного І локальний хеш НЕ дорівнює тому, що ми самі востаннє відправили — це
справжній конфлікт (обидві машини змінили одне й те саме між синками), і програшна
версія лишається поруч як `<файл>.conflict-<epoch>`, а не зникає. Чат-файли повідомлень
(`NNNN.json`) це окремий, суворіший випадок: вони append-only (ризики спеки,
«чати тільки дописуються»), тому колізія номера НЕ перетирає, а перенумеровує вхідний
файл на перший вільний номер.
"""

import hashlib
import json
import os
import re
import sys
import threading
import time
from urllib.parse import quote

import requests

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import auth_store  # noqa: E402
import home_spread  # noqa: E402

# ─────────────────────────── конфіг ───────────────────────────

# Anon-ключ ПУБЛІЧНИЙ за задумом (config.ts у chatview: «доступ ріже RLS, а не
# секретність цього рядка»), тому дефолт хардкоджений тут так само, як
# LOCAL_SUPABASE_URL хардкоджений у фронті. Оточення (тести, локальний supabase
# start) перебиває обома змінними.
SUPABASE_URL = (os.environ.get('SUPABASE_URL') or 'https://dovtsykwjdjowmbhfhma.supabase.co').rstrip('/')
SUPABASE_ANON_KEY = os.environ.get('SUPABASE_ANON_KEY') or (
    'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImRvdnRzeWt3'
    'amRqb3dtYmhmaG1hIiwicm9sZSI6ImFub24iLCJpYXQiOjE3ODg4ODgxNzMsImV4cCI6MjEwNDQ2NDE3M30'
    '.35OXIgarMJIxdLdxMSfpwXgmPbseUEeAnQ69Qj5D8Fo'
)
BUCKET = 'homes'

TICK_INTERVAL_SECONDS = 20
# Файл мусить лишатись незмінним стільки секунд, перш ніж push його забирає: інакше
# синк ловить файл ПІД ЧАС запису (writer ще не дописав JSON) і вантажить биту половину.
DEBOUNCE_SECONDS = 3
HTTP_TIMEOUT = 20

# Білий список (спека 6.3): текстові розширення, до порогу розміру.
TEXT_EXTENSIONS = {'.json', '.jsonl', '.md', '.txt', '.html', '.htm', '.csv', '.yaml', '.yml'}
MAX_SYNC_BYTES = 2 * 1024 * 1024

# Секрети — заборонені за ІМЕНЕМ, незалежно від розширення чи кореня (ризики спеки:
# «синк підхопить секрети», тест на це — tests/unit/test_cloud_sync.py).
_DENY_BASENAMES = {'keys.json', 'session.json', 'user-settings.json'}


def _is_secret_or_denied(basename):
    if basename in _DENY_BASENAMES:
        return True
    if basename.startswith('.env'):
        return True
    return False


def _sync_exclusion_reason(path):
    """Чому ЦЕЙ файл НЕ їде в хмару, або None якщо їде. Секрет — заборона іменем,
    навмисно НЕ потрапляє в манфіест заглушок (К3): друга машина не мусить навіть
    дізнатись, що такий файл існував. Медіа/поріг розміру — навпаки, це рівно той
    випадок, де К3 вимагає ПОМІТНУ заглушку на місці файлу, тому причина
    записується і їде в манфіест `.cloud-sync-excluded.json` цієї речі."""
    base = os.path.basename(path)
    if _is_secret_or_denied(base):
        return 'secret'
    ext = os.path.splitext(base)[1].lower()
    if ext not in TEXT_EXTENSIONS:
        return 'media-type'
    try:
        size = os.path.getsize(path)
    except OSError:
        return 'missing'
    if size > MAX_SYNC_BYTES:
        return 'too-large'
    return None


def is_syncable_file(path):
    """Чи пускаємо ЦЕЙ файл у хмару. Білий список спершу, заборона іменем — завжди
    останнім і безумовним словом, навіть якщо колись розширять список розширень."""
    return _sync_exclusion_reason(path) is None


# Манфіест виключень (К3): «на іншій машині МУСИТЬ показати ... заглушку». Файл,
# заголовок якого це non-текст/понад поріг, лишається на диску власника як є;
# поруч з item пишеться список того, що НЕ приїхало, і друга машина по ньому кладе
# заглушку-сайдкар (НІКОЛИ не в саме імʼя оригіналу — інакше застосунок спробував
# би відкрити відео-файл, у якому насправді лежить JSON).
EXCLUDED_MANIFEST_NAME = '.cloud-sync-excluded.json'
PLACEHOLDER_SUFFIX = '.cloud-placeholder.json'


_MIME_BY_EXT = {
    '.json': 'application/json', '.jsonl': 'application/x-ndjson', '.md': 'text/markdown',
    '.txt': 'text/plain', '.html': 'text/html', '.htm': 'text/html', '.csv': 'text/csv',
    '.yaml': 'application/yaml', '.yml': 'application/yaml',
}


def _content_type(path):
    return _MIME_BY_EXT.get(os.path.splitext(path)[1].lower(), 'application/octet-stream')


def _sha1_file(path):
    h = hashlib.sha1()
    with open(path, 'rb') as f:
        for chunk in iter(lambda: f.read(1 << 16), b''):
            h.update(chunk)
    return h.hexdigest()


def _sha1_bytes(data):
    return hashlib.sha1(data).hexdigest()


# ─────────────────────────── ідентифікація коренів (специфіка Logopsis) ───────────────
# Ідентична розвилка дев-репо/пакована збірка, що вже тримає home_spread.py: у пакованій
# збірці `home` це LOGOPSIS_HOME, у дев-репо `home` це tools/viz/chat, і корені рахуються
# від нього. Модуль сам нічого не вигадує, лише читає ці функції.

def _chat_root(home):
    return os.path.join(home, 'channels')


def _gadget_root(home):
    return home_spread.gadget_state_root(home=home)


def _canvas_root(home):
    return home_spread.canvas_root(home=home)


# Канва: єдиний спільний tldraw-документ (`canvas-state.json`, 2.2 МБ), НЕ по файлу на
# сторінку — усі сторінки лежать в ОДНОМУ store всередині нього (заміряно 2026-09-23:
# 24 сторінки, 1443 shape в одному JSON). `canvas-tombstones.json` (журнал видалень)
# їде поруч тим самим item_id, бо це той самий машинно-локальний стан. РЕШТА
# `tools/canvas-cmd/data/*.json` (858 файлів) уже ЖИВЕ в git (перевірено:
# `git check-ignore` каже НІ на випадковий файл з цієї теки), тобто вже подорожує між
# машинами через репозиторій — синкати її вдруге тут значило б дублювати чужий канал
# доставки без потреби.
CANVAS_ITEM_ID = 'main'
_CANVAS_FILES = ('canvas-state.json', 'canvas-tombstones.json')

_CHAT_ROOT_ITEM_ID = '_root'   # channels/index.json — реєстр, не окремий чат
_CHAT_ROOT_FILES = ('index.json',)

_MSG_FILE_RE = re.compile(r'^(\d{4,})\.json$')


def _discover_items(home):
    """(kind, item_id, item_root) для кожної речі, яку МОЖЕ мати сенс синкати.

    Директорія-кандидат, що починається з `_`/`.`, пропускається: це службові теки
    (`_media` — 1260 МБ медіа, яке й так відсіє білий список розширень, але прохід
    по 30k файлів заради нуля результату шкодить часу першого заливу)."""
    out = []
    chat_root = _chat_root(home)
    if os.path.isdir(chat_root):
        if os.path.isfile(os.path.join(chat_root, 'index.json')):
            out.append(('chat', _CHAT_ROOT_ITEM_ID, chat_root))
        for name in sorted(os.listdir(chat_root)):
            if name.startswith('_') or name.startswith('.'):
                continue
            full = os.path.join(chat_root, name)
            if os.path.isdir(full):
                out.append(('chat', name, full))
    gadget_root = _gadget_root(home)
    if os.path.isdir(gadget_root):
        for name in sorted(os.listdir(gadget_root)):
            if name.startswith('_') or name.startswith('.'):
                continue
            full = os.path.join(gadget_root, name)
            if os.path.isdir(full):
                out.append(('gadget', name, full))
    canvas_root = _canvas_root(home)
    if os.path.isdir(canvas_root) and any(
            os.path.isfile(os.path.join(canvas_root, f)) for f in _CANVAS_FILES):
        out.append(('canvas', CANVAS_ITEM_ID, canvas_root))
    return out


def _item_root(home, kind, item_id):
    if kind == 'chat':
        return _chat_root(home) if item_id == _CHAT_ROOT_ITEM_ID else os.path.join(_chat_root(home), item_id)
    if kind == 'gadget':
        return os.path.join(_gadget_root(home), item_id)
    if kind == 'canvas':
        return _canvas_root(home)
    raise ValueError('невідомий kind: %r' % (kind,))


def _gadget_code_dir(home, item_id):
    """Тека КОДУ гаджета (`apps/<id>/manifest.json`, `view.html`, ...), окремо від
    стану (`apps/_state/<id>/`, це `_item_root`/`_gadget_root`). Розділ 7 спеки:
    «гаджет їде разом з кодом», інакше отримувач має стан без чим його відкрити."""
    import entities
    return entities.path_for('gadget', item_id, home=home)


def _walk_prefixed(root, prefix):
    if not os.path.isdir(root):
        return
    for dirpath, dirnames, filenames in os.walk(root):
        dirnames[:] = [d for d in dirnames if not d.startswith('.')]
        for fn in filenames:
            full = os.path.join(dirpath, fn)
            rel = os.path.relpath(full, root).replace(os.sep, '/')
            yield prefix + rel, full


def _iter_item_files(kind, item_id, item_root, home=None):
    """(relpath, fullpath) кандидатів усередині ОДНІЄЇ речі. Не фільтрує білим
    списком — це робить викликач (`is_syncable_file`), тут лише «де шукати».

    Гаджет — єдиний kind з ДВОМА фізичними коренями (код + стан): relpath несе
    префікс `code/`/`state/`, щоб push/pull знали, куди саме писати на диску."""
    if kind == 'chat' and item_id == _CHAT_ROOT_ITEM_ID:
        for name in _CHAT_ROOT_FILES:
            p = os.path.join(item_root, name)
            if os.path.isfile(p):
                yield name, p
        return
    if kind == 'canvas':
        for name in _CANVAS_FILES:
            p = os.path.join(item_root, name)
            if os.path.isfile(p):
                yield name, p
        return
    if kind == 'gadget':
        if home is not None:
            yield from _walk_prefixed(_gadget_code_dir(home, item_id), 'code/')
        yield from _walk_prefixed(item_root, 'state/')
        return
    yield from _walk_prefixed(item_root, '')


# ─────────────────────────── маніфест (resumable, ризик спеки) ───────────────────────────

def _manifest_path(home):
    # `tools/viz/chat/*.json` — уже широке правило .gitignore (те саме, що ховає
    # session.json поруч), нового рядка не треба.
    return os.path.join(home, 'cloud-sync-state.json')


def _load_manifest(home, owner_id):
    path = _manifest_path(home)
    try:
        with open(path, encoding='utf-8') as f:
            data = json.load(f)
    except Exception:
        data = {}
    if not isinstance(data, dict) or data.get('owner_id') != owner_id:
        # Зміна власника на цій машині (інший логін) або перший запуск: чистий старт,
        # а не змішування чужих хешів під однією текою.
        data = {'owner_id': owner_id, 'uploaded': {}, 'items': {}}
    data.setdefault('uploaded', {})
    data.setdefault('items', {})
    return data


def _save_manifest(home, manifest):
    path = _manifest_path(home)
    tmp = '%s.%d.%d.tmp' % (path, os.getpid(), threading.get_ident())
    try:
        with open(tmp, 'w', encoding='utf-8') as f:
            json.dump(manifest, f, ensure_ascii=False, indent=2)
            f.flush()
            os.fsync(f.fileno())
        os.replace(tmp, path)
    except Exception:
        try:
            os.remove(tmp)
        except Exception:
            pass
        raise


# ─────────────────────────── токен (переживає протухання, К7) ───────────────────────────

def get_valid_token(home, log=None):
    """(access_token, user_id) поточної сесії, оновлений якщо протух. (None, None),
    якщо не залогінений АБО мережі нема — обидва випадки це «пропустити цей тік», а
    не виняток: К7 забороняє синку валити щось через відсутність мережі/логіну."""
    session = auth_store.read_session(home)
    if not session:
        return None, None
    exp = session.get('expires_at')
    now = time.time()
    if exp and (exp - now) > 60:
        return session['access_token'], session['user_id']
    try:
        r = requests.post(
            SUPABASE_URL + '/auth/v1/token', params={'grant_type': 'refresh_token'},
            json={'refresh_token': session['refresh_token']},
            headers={'apikey': SUPABASE_ANON_KEY}, timeout=HTTP_TIMEOUT)
        r.raise_for_status()
        data = r.json()
        new_session = {
            'user_id': (data.get('user') or {}).get('id') or session['user_id'],
            'email': (data.get('user') or {}).get('email'),
            'access_token': data['access_token'],
            'refresh_token': data['refresh_token'],
            'expires_at': int(now) + int(data.get('expires_in') or 3600),
            'saved_at': int(now * 1000),
        }
        # Записуємо назад у ТОЙ САМИЙ session.json, який читає фронт: інакше наступний
        # рефреш фронта прийде зі старим (уже використаним, ротованим) refresh_token
        # і Supabase його відхилить — живий вхід зламав би саме цей фоновий синк.
        auth_store.write_session(home, new_session)
        return new_session['access_token'], new_session['user_id']
    except Exception as e:
        if log:
            log('cloud_sync: token refresh failed (offline?): %s' % e)
        return None, None


def _headers(token):
    return {'apikey': SUPABASE_ANON_KEY, 'Authorization': 'Bearer ' + token}


# ─────────────────────────── Storage HTTP ───────────────────────────

def _object_url(path):
    return '%s/storage/v1/object/%s/%s' % (SUPABASE_URL, BUCKET, quote(path, safe='/'))


def upload_bytes(token, path, data, content_type='application/octet-stream', log=None):
    try:
        r = requests.post(
            _object_url(path), data=data,
            headers={**_headers(token), 'Content-Type': content_type, 'x-upsert': 'true'},
            timeout=HTTP_TIMEOUT)
        if r.status_code >= 300:
            if log:
                log('cloud_sync: upload %s -> HTTP %s %s' % (path, r.status_code, r.text[:200]))
            return False
        return True
    except Exception as e:
        if log:
            log('cloud_sync: upload %s failed: %s' % (path, e))
        return False


def upload_object(token, path, local_file, log=None):
    try:
        with open(local_file, 'rb') as f:
            data = f.read()
    except Exception as e:
        if log:
            log('cloud_sync: read %s failed: %s' % (local_file, e))
        return False
    return upload_bytes(token, path, data, _content_type(local_file), log=log)


DOWNLOAD_STALE_RETRY_DELAYS = (0.5, 1, 2, 3)


def _strong_etag(etag):
    """Storage інколи віддає GET через компресію -> `W/"hash"` (слабкий валідатор,
    HTTP/1.1 §2.3.3), тоді як лістинг завжди тримає СИЛЬНИЙ `"hash"` тієї самої
    метаданої. Live-тест зловив хибне «застарілий etag» саме на цьому: байти
    насправді свіжі, розбігався лише префікс представлення."""
    if etag and etag.startswith('W/'):
        return etag[2:]
    return etag


def download_object(token, path, expected_etag=None, log=None):
    """GET обʼєкта. `expected_etag` (з `list_objects_recursive`, авторитетне джерело —
    воно читає з таблиці метаданих і в живому тесті завжди свіже) вмикає ретрай:
    живим тестом К8 підтверджено, що GET-ендпоінт Storage інколи повертає ЗАСТАРІЛИЙ
    байт-вміст одразу після `x-upsert`-перезапису того самого шляху (окрема від
    `Cache-Control: no-cache`, тобто не клієнтський кеш — розбіжність реплік на боці
    Supabase), а без цієї перевірки pull_once сприймав старий вміст за «свіжий
    remote» і хибно ховав щойно зроблену локальну правку в конфліктну копію.

    Вичерпані ретраї -> None, НЕ застарілий вміст: пул тоді просто пропускає файл
    цим тіком (`if content is None: continue`), а наступний фоновий тік (20с) чи
    ручний pull дожене його, коли розбіжність реплік на боці Supabase мине. Віддати
    відомо застарілі байти як «свіже remote» гірше, ніж почекати ще один тік."""
    try:
        r = None
        for attempt, delay in enumerate((0,) + DOWNLOAD_STALE_RETRY_DELAYS):
            if delay:
                time.sleep(delay)
            r = requests.get(_object_url(path), headers=_headers(token), timeout=HTTP_TIMEOUT)
            if r.status_code >= 300:
                if log:
                    log('cloud_sync: download %s -> HTTP %s' % (path, r.status_code))
                return None
            if not expected_etag or _strong_etag(r.headers.get('etag')) == _strong_etag(expected_etag):
                return r.content
            if log:
                log('cloud_sync: download %s -> застарілий etag (спроба %d), повторюю' % (path, attempt + 1))
        if log:
            log('cloud_sync: download %s -> etag лишився застарілим, пропускаю цей тік' % path)
        return None
    except Exception as e:
        if log:
            log('cloud_sync: download %s failed: %s' % (path, e))
        return None


def list_objects_recursive(token, prefix, log=None, _depth=0):
    """Файли (не «теки») під `prefix`, рекурсивно. Storage `list` віддає лише один
    рівень (папка = запис без `id`), тому теки обходимо самі; глибина обмежена (6) —
    захист від випадкового циклу, реальна вкладеність тут 1-2 рівні."""
    if _depth > 6:
        return []
    out = []
    offset = 0
    limit = 100
    while True:
        try:
            r = requests.post(
                '%s/storage/v1/object/list/%s' % (SUPABASE_URL, BUCKET),
                json={'prefix': prefix, 'limit': limit, 'offset': offset,
                      'sortBy': {'column': 'name', 'order': 'asc'}},
                headers={**_headers(token), 'Content-Type': 'application/json'},
                timeout=HTTP_TIMEOUT)
            r.raise_for_status()
            page = r.json()
        except Exception as e:
            if log:
                log('cloud_sync: list %s failed: %s' % (prefix, e))
            return out
        if not page:
            break
        for entry in page:
            name = entry.get('name')
            if not name:
                continue
            full = prefix.rstrip('/') + '/' + name
            if entry.get('id') is None and entry.get('metadata') is None:
                out.extend(list_objects_recursive(token, full, log=log, _depth=_depth + 1))
            else:
                out.append({'path': full, 'updated_at': entry.get('updated_at'),
                             'size': (entry.get('metadata') or {}).get('size'),
                             'etag': (entry.get('metadata') or {}).get('eTag')})
        if len(page) < limit:
            break
        offset += limit
    return out


# ─────────────────────────── items (PostgREST) ───────────────────────────

def upsert_item(token, owner_id, kind, item_id, title=None, log=None):
    """`title` НЕ кладеться в payload, коли не заданий (фоновий push_once кличе цю
    функцію на КОЖЕН тік без title заради простого «бампнути updated_at») — інакше
    PostgREST переписав би людську назву назад на голий item_id за 20 секунд після
    share_item (живою UI-перевіркою впіймано саме це: назва зникала сама собою)."""
    row = {'owner_id': owner_id, 'kind': kind, 'item_id': item_id, 'updated_at': _iso_now()}
    if title:
        row['title'] = title
    try:
        r = requests.post(
            SUPABASE_URL + '/rest/v1/items',
            params={'on_conflict': 'owner_id,kind,item_id'},
            json=[row],
            headers={**_headers(token), 'Content-Type': 'application/json',
                     'Prefer': 'resolution=merge-duplicates,return=minimal'},
            timeout=HTTP_TIMEOUT)
        if r.status_code >= 300:
            if log:
                log('cloud_sync: upsert item %s/%s -> HTTP %s %s' % (kind, item_id, r.status_code, r.text[:200]))
            return False
        return True
    except Exception as e:
        if log:
            log('cloud_sync: upsert item %s/%s failed: %s' % (kind, item_id, e))
        return False


def list_my_items(token, log=None):
    """Рядки items, видимі МЕНІ (RLS: свої + розшарені мені), без розпублікованих
    (`deleted_at`) — розділ 7 спеки: тамбстоун не тягнемо назад на диск."""
    try:
        r = requests.get(SUPABASE_URL + '/rest/v1/items',
                          params={'select': '*', 'deleted_at': 'is.null'},
                          headers=_headers(token), timeout=HTTP_TIMEOUT)
        r.raise_for_status()
        return r.json()
    except Exception as e:
        if log:
            log('cloud_sync: list items failed: %s' % e)
        return []


def list_published_owned_items(token, owner_id, log=None):
    """Речі, які Я вже опублікував(-ла) (маю живий рядок items, не тамбстоун).
    Розділ 7 спеки — це і є вибірка для push: рядок items тут зʼявляється ЛИШЕ
    через `share_item` (перше «Поділитись»), тому приватна річ без жодного
    натискання цієї кнопки сюди ніколи не потрапляє (К0)."""
    try:
        r = requests.get(
            SUPABASE_URL + '/rest/v1/items',
            params={'owner_id': 'eq.%s' % owner_id, 'deleted_at': 'is.null', 'select': '*'},
            headers=_headers(token), timeout=HTTP_TIMEOUT)
        r.raise_for_status()
        return r.json()
    except Exception as e:
        if log:
            log('cloud_sync: list published items failed: %s' % e)
        return []


def _get_item_row(token, owner_id, kind, item_id, log=None):
    try:
        r = requests.get(
            SUPABASE_URL + '/rest/v1/items',
            params={'owner_id': 'eq.%s' % owner_id, 'kind': 'eq.%s' % kind,
                    'item_id': 'eq.%s' % item_id, 'select': '*'},
            headers=_headers(token), timeout=HTTP_TIMEOUT)
        r.raise_for_status()
        rows = r.json()
        return rows[0] if rows else None
    except Exception as e:
        if log:
            log('cloud_sync: get item row failed: %s' % e)
        return None


def _iso_now():
    # Мілісекундна точність, НЕ секундна (`.000Z` фіксовано нулем був баг, знайдений
    # живим тестом К8: два upsert_item в межах ТІЄЇ САМОЇ секунди давали ОДНАКОВИЙ
    # `items.updated_at`, і pull_once бачив «updated_at не змінився» -> мовчки
    # пропускав справжню зміну, доки годинник не перейде на наступну секунду).
    from datetime import datetime, timezone
    return datetime.now(timezone.utc).strftime('%Y-%m-%dT%H:%M:%S.%f')[:-3] + 'Z'


# ─────────────────────────── шеринг (розділ 7 спеки: «Поділитись» публікує) ───────────────

def share_item(token, owner_id, kind, item_id, grantee_email, role, home=None, log=None, title=None):
    """«Поділитись»: перше натискання ПУБЛІКУЄ річ — заводить рядок items (якщо
    його ще нема) і рядок shares, і одразу штовхає пуш САМЕ цієї речі окремим
    потоком (не чекаючи фонового тіка до 20с). Далі річ живе в звичайному
    фоновому синку (К1), бо вона тепер є у `list_published_owned_items`.

    `title` (людська назва чату/гаджета з UI) їде в items.title — К5 читає його
    назад через RPC `shared_with_me`, а на приймачі саме він стає лейблом
    новоствореного локального рядка (`_register_local_index`), бо `item_id`
    (внутрішній id) нічого не каже людині."""
    grantee_email = (grantee_email or '').strip().lower()
    if not grantee_email or role not in ('view', 'edit'):
        return False
    if not upsert_item(token, owner_id, kind, item_id, title=title, log=log):
        return False
    row = _get_item_row(token, owner_id, kind, item_id, log=log)
    if not row:
        return False
    try:
        r = requests.post(
            SUPABASE_URL + '/rest/v1/shares',
            params={'on_conflict': 'item_id,grantee_email'},
            json=[{'item_id': row['id'], 'grantee_email': grantee_email, 'role': role}],
            headers={**_headers(token), 'Content-Type': 'application/json',
                     'Prefer': 'resolution=merge-duplicates,return=minimal'},
            timeout=HTTP_TIMEOUT)
        if r.status_code >= 300:
            if log:
                log('cloud_sync: share %s/%s -> %s HTTP %s %s' % (
                    kind, item_id, grantee_email, r.status_code, r.text[:200]))
            return False
    except Exception as e:
        if log:
            log('cloud_sync: share failed: %s' % e)
        return False
    if home:
        threading.Thread(
            target=push_once,
            kwargs={'home': home, 'token': token, 'owner_id': owner_id, 'log': log,
                    'published': [{'kind': kind, 'item_id': item_id}]},
            daemon=True, name='cloud-sync-share-push').start()
    return True


def list_shares(token, owner_id, kind, item_id, log=None):
    row = _get_item_row(token, owner_id, kind, item_id, log=log)
    if not row:
        return []
    try:
        r = requests.get(SUPABASE_URL + '/rest/v1/shares',
                          params={'item_id': 'eq.%s' % row['id'], 'select': '*'},
                          headers=_headers(token), timeout=HTTP_TIMEOUT)
        r.raise_for_status()
        return r.json()
    except Exception as e:
        if log:
            log('cloud_sync: list shares failed: %s' % e)
        return []


def list_shared_with_me(token, owner_id, log=None):
    """Речі, розшарені МЕНІ, разом з email власника (К5: позначка «від <власник>»).
    `auth.users` недоступна напряму через PostgREST, тому RPC `shared_with_me`
    (SECURITY DEFINER, міграція 20260923150000) читає лише те, що й так проходить
    RLS «розшарено мені» — owner_id тут лишається аргументом заради сумісності
    викликачів (server.py), сам фільтр «не моє» вже робить сам RPC на боці бази."""
    del owner_id  # фільтрація «не моє» тепер у самому RPC (auth.email() на боці бази)
    try:
        r = requests.post(SUPABASE_URL + '/rest/v1/rpc/shared_with_me', json={},
                           headers={**_headers(token), 'Content-Type': 'application/json'},
                           timeout=HTTP_TIMEOUT)
        r.raise_for_status()
        return r.json()
    except Exception as e:
        if log:
            log('cloud_sync: list shared-with-me failed: %s' % e)
        return []


def revoke_share(token, owner_id, kind, item_id, grantee_email, log=None):
    """Забрати доступ. Коли це був ОСТАННІЙ рядок shares цієї речі — розпублікувати
    (розділ 7 спеки): прибрати обʼєкти зі Storage і позначити items.deleted_at.
    Локальний оригінал власника на диску НЕ чіпається (лише хмара)."""
    grantee_email = (grantee_email or '').strip().lower()
    row = _get_item_row(token, owner_id, kind, item_id, log=log)
    if not row:
        return False
    try:
        r = requests.delete(
            SUPABASE_URL + '/rest/v1/shares',
            params={'item_id': 'eq.%s' % row['id'], 'grantee_email': 'eq.%s' % grantee_email},
            headers=_headers(token), timeout=HTTP_TIMEOUT)
        if r.status_code >= 300:
            if log:
                log('cloud_sync: revoke %s/%s -> HTTP %s' % (kind, item_id, r.status_code))
            return False
    except Exception as e:
        if log:
            log('cloud_sync: revoke failed: %s' % e)
        return False
    if not list_shares(token, owner_id, kind, item_id, log=log):
        _unpublish_item(token, owner_id, row['id'], kind, item_id, log=log)
    return True


def _unpublish_item(token, owner_id, items_row_id, kind, item_id, log=None):
    prefix = '%s/%s/%s' % (owner_id, kind, item_id)
    objects = list_objects_recursive(token, prefix, log=log)
    paths = [o['path'] for o in objects]
    if paths:
        try:
            requests.delete(SUPABASE_URL + '/storage/v1/object/' + BUCKET,
                             json={'prefixes': paths}, headers=_headers(token), timeout=HTTP_TIMEOUT)
        except Exception as e:
            if log:
                log('cloud_sync: unpublish storage delete failed: %s' % e)
    try:
        requests.patch(
            SUPABASE_URL + '/rest/v1/items', params={'id': 'eq.%s' % items_row_id},
            json={'deleted_at': _iso_now()},
            headers={**_headers(token), 'Content-Type': 'application/json', 'Prefer': 'return=minimal'},
            timeout=HTTP_TIMEOUT)
    except Exception as e:
        if log:
            log('cloud_sync: unpublish items patch failed: %s' % e)


# ─────────────────────────── push (локальне -> хмара) ───────────────────────────

def push_once(home, token, owner_id, log=None, stats=None, published=None):
    """Пуш ЛИШЕ речей, уже опублікованих через «Поділитись» (розділ 7 спеки, К0):
    приватне без рядка `items` синку не бачить і на диск хмари не їде. Вибірка —
    `list_published_owned_items` (живий запит), або підставлена напряму викликачем
    (`share_item` для миттєвого штовху ОДНІЄЇ речі; тести — без мережі)."""
    stats = stats if stats is not None else {'files': 0, 'bytes': 0, 'items': 0}
    manifest = _load_manifest(home, owner_id)
    now = time.time()
    rows = published if published is not None else list_published_owned_items(token, owner_id, log=log)
    for row in rows:
        kind, item_id = row.get('kind'), row.get('item_id')
        item_root = _item_root(home, kind, item_id)
        ikey = '%s/%s' % (kind, item_id)
        touched = False
        excluded = {}
        for relpath, full in _iter_item_files(kind, item_id, item_root, home=home):
            reason = _sync_exclusion_reason(full)
            if reason in ('secret', 'missing'):
                continue
            if reason is not None:
                try:
                    excluded[relpath] = {'reason': reason, 'size': os.path.getsize(full)}
                except OSError:
                    pass
                continue
            try:
                st = os.stat(full)
            except OSError:
                continue
            key = '%s/%s' % (ikey, relpath)
            cached = manifest['uploaded'].get(key)
            if cached and cached.get('mtime') == st.st_mtime and cached.get('size') == st.st_size:
                continue
            if (now - st.st_mtime) < DEBOUNCE_SECONDS:
                continue  # щойно змінився: дати писарю дописати, спробувати наступний тік
            h = _sha1_file(full)
            if cached and cached.get('hash') == h:
                manifest['uploaded'][key] = {**cached, 'mtime': st.st_mtime, 'size': st.st_size}
                continue
            obj_path = '%s/%s/%s/%s' % (owner_id, kind, item_id, relpath)
            if upload_object(token, obj_path, full, log=log):
                manifest['uploaded'][key] = {'hash': h, 'size': st.st_size, 'mtime': st.st_mtime,
                                              'uploaded_at': now}
                touched = True
                stats['files'] += 1
                stats['bytes'] += st.st_size
        # К3: манфіест виключень оновлюємо лише на зміну складу (мовчазний но-оп,
        # доки нічого не з'явилось і не зникло — інакше кожен тік бив би мережу
        # заради того самого списку).
        prev_excluded = manifest['items'].get(ikey, {}).get('excluded') or {}
        if excluded != prev_excluded:
            excl_obj_path = '%s/%s/%s/%s' % (owner_id, kind, item_id, EXCLUDED_MANIFEST_NAME)
            payload = json.dumps(excluded, ensure_ascii=False, sort_keys=True).encode('utf-8')
            if upload_bytes(token, excl_obj_path, payload, 'application/json', log=log):
                manifest['items'].setdefault(ikey, {})['excluded'] = excluded
                touched = True
        if touched:
            if upsert_item(token, owner_id, kind, item_id, log=log):
                manifest['items'].setdefault(ikey, {})['pushed_at'] = now
                stats['items'] += 1
    _save_manifest(home, manifest)
    return stats


# ─────────────────────────── pull (хмара -> локальне) ───────────────────────────

def _next_free_message_number(dirpath):
    best = 0
    try:
        for name in os.listdir(dirpath):
            m = _MSG_FILE_RE.match(name)
            if m:
                best = max(best, int(m.group(1)))
    except OSError:
        pass
    width = max(4, len(str(best + 1)))
    return str(best + 1).zfill(width) + '.json'


def _write_bytes_atomic(path, data):
    os.makedirs(os.path.dirname(path), exist_ok=True)
    tmp = '%s.%d.%d.tmp' % (path, os.getpid(), threading.get_ident())
    with open(tmp, 'wb') as f:
        f.write(data)
        f.flush()
        os.fsync(f.fileno())
    os.replace(tmp, path)


def _apply_downloaded_file(kind, item_root, relpath, content, remote_updated_iso, manifest, key, log=None):
    """Один файл з хмари -> диск, із конфліктним розгалуженням (К8).

    Чат-повідомлення (NNNN.json) НІКОЛИ не перетираються: колізія номера
    перенумеровується на перший вільний слот (append-only, ризики спеки)."""
    local_path = os.path.join(item_root, relpath)
    remote_hash = _sha1_bytes(content)
    is_msg_file = kind == 'chat' and '/' not in relpath and _MSG_FILE_RE.match(relpath)

    if not os.path.exists(local_path):
        _write_bytes_atomic(local_path, content)
        manifest['uploaded'][key] = {'hash': remote_hash, 'size': len(content),
                                      'mtime': os.path.getmtime(local_path), 'uploaded_at': time.time()}
        return 'downloaded'

    local_hash = _sha1_file(local_path)
    if local_hash == remote_hash:
        return 'same'

    if is_msg_file:
        new_name = _next_free_message_number(item_root)
        _write_bytes_atomic(os.path.join(item_root, new_name), content)
        if log:
            log('cloud_sync: колізія номера %s -> перенумеровано в %s' % (relpath, new_name))
        return 'renumbered:' + new_name

    cached = manifest['uploaded'].get(key)
    ts = int(time.time())
    if cached and cached.get('hash') == local_hash:
        # Локальне не змінювалось відтоді, як МИ його востаннє відправили — хмара
        # просто новіша, безпечно перетерти без конфліктної копії.
        _write_bytes_atomic(local_path, content)
        manifest['uploaded'][key] = {'hash': remote_hash, 'size': len(content),
                                      'mtime': os.path.getmtime(local_path), 'uploaded_at': time.time()}
        return 'overwritten'

    # Справжній конфлікт: обидві сторони змінили незалежно. Пізніша стає основною.
    local_mtime = os.path.getmtime(local_path)
    remote_mtime = _parse_iso(remote_updated_iso) or time.time()
    if remote_mtime >= local_mtime:
        conflict_path = '%s.conflict-%d' % (local_path, ts)
        os.replace(local_path, conflict_path)
        _write_bytes_atomic(local_path, content)
        manifest['uploaded'][key] = {'hash': remote_hash, 'size': len(content),
                                      'mtime': os.path.getmtime(local_path), 'uploaded_at': time.time()}
        return 'conflict:remote-won'
    else:
        conflict_path = '%s.conflict-%d' % (local_path, ts)
        _write_bytes_atomic(conflict_path, content)
        return 'conflict:local-won'


def _parse_iso(s):
    if not s:
        return None
    try:
        s2 = s.replace('Z', '+00:00')
        if '.' in s2:
            head, rest = s2.split('.', 1)
            if '+' in rest:
                frac, tz = rest.split('+', 1)
                tz = '+' + tz
            else:
                frac, tz = rest, ''
            s2 = head + '.' + frac[:6].ljust(6, '0') + tz
        from datetime import datetime
        return datetime.fromisoformat(s2).timestamp()
    except Exception:
        return None


def _register_local_index(home, kind, item_id, title, log=None):
    """Синк кладе БАЙТИ речі на диск, але список у Launcher читає ОКРЕМИЙ реєстр
    (`channels/index.json`, `apps/index.json`) — самі файли в `channels/<id>/` там
    не з'являються автоматично. Без цього кроку живою UI-перевіркою впіймано рівно
    К2/К5: чат/гаджет реально підтягувався на диск, але в лаунчері отримувача
    списку не було взагалі, бо той читає index.json, а не сканує диск сам.
    Ідемпотентно: додає рядок, лише якщо його там ще нема, і ніколи не займає чужі."""
    label = title or item_id
    if kind == 'chat':
        idx_path = os.path.join(_chat_root(home), 'index.json')
        try:
            with open(idx_path, encoding='utf-8') as f:
                entries = json.load(f)
        except Exception:
            entries = []
        if not isinstance(entries, list):
            entries = []
        if any(isinstance(e, dict) and e.get('id') == item_id for e in entries):
            return
        entries.append({'id': item_id, 'label': label, 'icon': '💬'})
        try:
            _write_bytes_atomic(idx_path, json.dumps(entries, ensure_ascii=False, indent=2).encode('utf-8'))
        except Exception as e:
            if log:
                log('cloud_sync: register local chat index failed: %s' % e)
    elif kind == 'gadget':
        idx_path = os.path.join(home, 'apps', 'index.json')
        try:
            with open(idx_path, encoding='utf-8') as f:
                data = json.load(f)
        except Exception:
            data = {}
        if not isinstance(data, dict):
            data = {}
        gadgets = data.get('gadgets')
        if not isinstance(gadgets, list):
            gadgets = []
        if any(isinstance(g, dict) and g.get('id') == item_id for g in gadgets):
            return
        gadgets.append({'id': item_id, 'name': label})
        data['gadgets'] = gadgets
        try:
            _write_bytes_atomic(idx_path, json.dumps(data, ensure_ascii=False, indent=2).encode('utf-8'))
        except Exception as e:
            if log:
                log('cloud_sync: register local gadget index failed: %s' % e)
    # kind == 'canvas': єдиний спільний документ (CANVAS_ITEM_ID='main'), сторінки
    # всередині одного canvas-state.json -- окремого реєстру, який ще треба
    # поповнити записом, тут нема.


def pull_once(home, token, log=None, stats=None):
    stats = stats if stats is not None else {'files': 0, 'items': 0, 'conflicts': 0}
    rows = list_my_items(token, log=log)
    if not rows:
        return stats
    session = auth_store.read_session(home) or {}
    manifest = _load_manifest(home, session.get('user_id') or 'unknown')
    for row in rows:
        kind, item_id = row.get('kind'), row.get('item_id')
        owner_id = row.get('owner_id')
        cloud_updated = row.get('updated_at')
        ikey = '%s/%s' % (kind, item_id)
        if manifest['items'].get(ikey, {}).get('pulled_cloud_updated_at') == cloud_updated:
            continue
        item_root = _item_root(home, kind, item_id)
        os.makedirs(item_root, exist_ok=True)
        if item_id != _CHAT_ROOT_ITEM_ID:
            _register_local_index(home, kind, item_id, row.get('title'), log=log)
        code_root = None
        if kind == 'gadget':
            code_root = _gadget_code_dir(home, item_id)
            os.makedirs(code_root, exist_ok=True)
        prefix = '%s/%s/%s' % (owner_id, kind, item_id)
        objects = list_objects_recursive(token, prefix, log=log)
        any_download_failed = False
        for obj in objects:
            relpath = obj['path'][len(prefix):].lstrip('/')
            content = download_object(token, obj['path'], expected_etag=obj.get('etag'), log=log)
            if content is None:
                # Мережева помилка АБО etag лишився застарілим (download_object сама
                # ретраїть): якщо позначити цю річ «повністю підтягнутою» зараз, файл,
                # що не завантажився, застряг би НАЗАВЖДИ (updated_at не зміниться
                # знову без нової людської дії) -- пропускаємо, наступний тік спробує
                # РІВНО ЦЕЙ файл наново, бо pulled_cloud_updated_at нижче НЕ пишемо.
                any_download_failed = True
                continue
            fkey = '%s/%s' % (ikey, relpath)
            if relpath == EXCLUDED_MANIFEST_NAME:
                # Манфіест виключень (К3) сам не має code/state префікса — це
                # службовий файл РЕЧІ, а не її вмісту, лишається біля стану/item_root.
                target_root, sub_rel = item_root, relpath
            elif kind == 'gadget':
                # Гаджет має ДВА фізичні корені (код+стан, розділ 7 спеки) під
                # ОДНИМ items-рядком: relpath несе префікс, що вирішує, куди писати.
                if relpath.startswith('code/'):
                    target_root, sub_rel = code_root, relpath[len('code/'):]
                elif relpath.startswith('state/'):
                    target_root, sub_rel = item_root, relpath[len('state/'):]
                else:
                    continue  # незнайомий префікс: захисно пропускаємо, не гадаємо
            else:
                target_root, sub_rel = item_root, relpath
            outcome = _apply_downloaded_file(kind, target_root, sub_rel, content,
                                              obj.get('updated_at'), manifest, fkey, log=log)
            if outcome:
                stats['files'] += 1
            if outcome and outcome.startswith('conflict'):
                stats['conflicts'] += 1
        _apply_excluded_placeholders(kind, item_root, code_root, log=log)
        if not any_download_failed:
            manifest['items'].setdefault(ikey, {})['pulled_cloud_updated_at'] = cloud_updated
        stats['items'] += 1
    _save_manifest(home, manifest)
    return stats


def _apply_excluded_placeholders(kind, item_root, code_root, log=None):
    """К3: за щойно підтягнутим `.cloud-sync-excluded.json` кладе сайдкар-заглушку
    `<relpath>.cloud-placeholder.json` там, де реального файлу НЕМА (друга машина
    ніколи його й не отримувала — він медіа/понад поріг). Заглушка лягає ПОРУЧ з
    очікуваним шляхом, а не ЗАМІСТЬ нього: застосунок інакше спробував би
    відкрити відео-файл, у якому насправді текст."""
    manifest_path = os.path.join(item_root, EXCLUDED_MANIFEST_NAME)
    if not os.path.isfile(manifest_path):
        return
    try:
        with open(manifest_path, encoding='utf-8') as f:
            excluded = json.load(f)
    except Exception as e:
        if log:
            log('cloud_sync: read %s failed: %s' % (manifest_path, e))
        return
    if not isinstance(excluded, dict):
        return
    for relpath, info in excluded.items():
        if kind == 'gadget':
            if relpath.startswith('code/'):
                target_root, sub_rel = code_root, relpath[len('code/'):]
            elif relpath.startswith('state/'):
                target_root, sub_rel = item_root, relpath[len('state/'):]
            else:
                continue
        else:
            target_root, sub_rel = item_root, relpath
        real_path = os.path.join(target_root, sub_rel)
        if os.path.exists(real_path):
            continue  # файл таки є локально (та сама машина, або вже підтягнутий раніше)
        placeholder_path = real_path + PLACEHOLDER_SUFFIX
        if os.path.exists(placeholder_path):
            continue
        payload = json.dumps({
            'placeholder': True,
            'reason': (info or {}).get('reason'),
            'size': (info or {}).get('size'),
            'message_uk': 'файл лише на машині автора',
        }, ensure_ascii=False).encode('utf-8')
        try:
            _write_bytes_atomic(placeholder_path, payload)
        except Exception as e:
            if log:
                log('cloud_sync: placeholder write failed for %s: %s' % (real_path, e))


# ─────────────────────────── тік і фоновий цикл ───────────────────────────

def tick(home=None, log=None):
    """Один прохід: push, потім pull. Ловить УСЕ (К7): відсутність логіну чи мережі
    ніколи не має права зупинити застосунок чи навіть просто спливти у консоль
    незрозумілим трейсом."""
    home = home or os.environ.get('LOGOPSIS_HOME') or os.path.dirname(os.path.abspath(__file__))
    try:
        token, uid = get_valid_token(home, log=log)
        if not token or not uid:
            return {'skipped': 'not-logged-in-or-offline'}
        push_stats = push_once(home, token, uid, log=log)
        pull_stats = pull_once(home, token, log=log)
        return {'push': push_stats, 'pull': pull_stats}
    except Exception as e:
        if log:
            log('cloud_sync: tick failed: %s' % e)
        return {'error': str(e)}


def start_background_loop(home=None, interval=None, log=None):
    """Даемон-потік, той самий патерн, що `plan_autosync_tick.start_background_loop`:
    fire-and-forget, server.py кличе рівно раз при старті."""
    step = TICK_INTERVAL_SECONDS if interval is None else interval

    def _loop():
        while True:
            tick(home=home, log=log)
            time.sleep(step)

    thread = threading.Thread(target=_loop, daemon=True, name='cloud-sync-tick')
    thread.start()
    return thread


def trigger_pull_now(home=None, log=None):
    """Одноразовий негайний тік ПІСЛЯ логіну (К2: «коли користувач логіниться...»),
    а не чекати до 20с наступного фонового проходу. Свій потік, не блокує відповідь
    HTTP на /api/auth-session."""
    threading.Thread(target=tick, kwargs={'home': home, 'log': log},
                      daemon=True, name='cloud-sync-login-pull').start()
