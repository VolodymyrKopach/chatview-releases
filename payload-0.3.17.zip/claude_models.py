"""Каталог моделей Клода: тягнеться з CLI, а не пінається руками
(specs/claude-model-catalog-auto).

Чому модуль існує. Кожен реліз Anthropic (Opus 5 -> 5.5) вимагав правити версійний id
у трьох місцях: runner.py, engine_sdk.py і фронтова копія в chatview. 2026-09-23 вони
розійшлись: бекенд уже їхав на новій моделі, а поповер «Модель» показував стару.

Джерело правди: `ClaudeSDKClient.get_server_info()['models']`, той самий каталог, з якого
Claude Code будує меню `/model`. Автооновлення CLI приносить нову модель саме, ми лише
читаємо. Ручним знанням лишається тільки мапа «родина -> наше слово», і вона живе в UI.

ПАСТКА (К9): без `cli_path` SDK запускає СВІЙ вбудований CLI, чий каталог протух
(там «Opus 4.8»). Тому `fetch_models` відмовляється працювати без шляху, а раннер і
сервер передають runner.CLAUDE_BIN, той самий CLI, яким жене ходи.

Ціна одного отримання ~2 с і 0 токенів (модель не викликається, це лише ініціалізація
сесії). Щоб хід каналу її не платив, каталог лежить у кеші на диску (К2) і на гарячому
шляху читається без блокування: протухлий кеш оновлюється у фоні.
"""
import asyncio
import json
import os
import re
import threading
import time

FAMILIES = ('haiku', 'sonnet', 'opus', 'fable')
EFFORT_LEVELS = ('low', 'medium', 'high', 'xhigh', 'max')
CACHE_TTL = 6 * 3600
FETCH_TIMEOUT = 20

# Людська назва це початок description до ` with ` або ` · `: «Opus 5.5 with 1M context ·
# ...» -> «Opus 5.5». Приймаємо лише форму «Родина N[.N]», інакше назви нема зовсім:
# якщо Anthropic змінить формат, UI покаже наше слово без версії, а не сире сміття.
_NAME_RE = re.compile(r'^(Haiku|Sonnet|Opus|Fable) \d+(\.\d+)*$')
_SUFFIX_RE = re.compile(r'\[[^\]]*\]$')


def family_of(model_id):
    """Родина за id або аліасом. Той самий ключ, що в engine_sdk._model_family, але
    без дефолту: невідоме тут це None, а не sonnet."""
    m = _SUFFIX_RE.sub('', (model_id or '').lower())
    for fam in FAMILIES:
        if m == fam or ('claude-' + fam) in m:
            return fam
    return None


def display_name(description):
    """«Opus 5.5 with 1M context · Best for...» -> «Opus 5.5». None, якщо форма чужа."""
    head = re.split(r' with | · ', (description or '').strip(), maxsplit=1)[0].strip()
    return head if _NAME_RE.match(head) else None


def parse_catalog(models):
    """Сирий список `models` -> {родина: запис}. Службовий `default` і невідомі родини
    відкидаються; на родину береться перший рядок каталогу (так їх упорядковує CLI).

    `modelArg` це значення для --model: resolvedModel БЕЗ суфікса `[1m]`. Суфікс
    свідомо зрізаємо: 1M-бету вмикає наш власний код за родиною (engine_sdk), а
    `opus[1m]` як аліас не впізнає engine_sdk._model_family і тихо віддав би sonnet."""
    out = {}
    if not isinstance(models, list):
        return out
    for m in models:
        if not isinstance(m, dict) or m.get('value') == 'default':
            continue
        resolved = m.get('resolvedModel') or ''
        fam = family_of(resolved) or family_of(m.get('value'))
        if not fam or fam in out:
            continue
        arg = _SUFFIX_RE.sub('', resolved) if resolved.startswith('claude-') else fam
        levels = [lvl for lvl in (m.get('supportedEffortLevels') or []) if lvl in EFFORT_LEVELS]
        out[fam] = {
            'alias': fam,
            'value': m.get('value'),
            'resolvedModel': resolved or None,
            'modelArg': arg,
            'name': display_name(m.get('description')),
            'supportedEffortLevels': levels,
        }
    return out


def model_arg(model, families):
    """Що передати в --model. Повний id проходить як є; родина береться з каталогу;
    каталогу чи родини в ньому нема -> голий аліас (К6), CLI сам розгорне його."""
    if model in FAMILIES:
        entry = (families or {}).get(model)
        return entry['modelArg'] if entry else model
    return model


def efforts_for(fam, families, fallback):
    """Дозволені рівні зусиль: з каталогу (К7), ручна мапа лише коли каталогу нема."""
    entry = (families or {}).get(fam)
    if entry is not None:
        return list(entry['supportedEffortLevels'])
    return list(fallback.get(fam, EFFORT_LEVELS))


def cli_version(cli_path):
    """Відбиток версії CLI без його запуску. Інсталятор кладе `claude` симлінком на
    `.../versions/2.1.280`, тож версія це імʼя цілі. Інакше realpath+mtime+розмір: будь-яке
    оновлення бінарника все одно їх змінить. '' = бінарника нема."""
    try:
        real = os.path.realpath(cli_path)
        st = os.stat(real)
    except (OSError, TypeError, ValueError):
        return ''
    base = os.path.basename(real)
    if re.match(r'^\d+\.\d+\.\d+', base):
        return base
    return f'{real}@{int(st.st_mtime)}:{st.st_size}'


def fetch_models(cli_path, timeout=FETCH_TIMEOUT):
    """Сирий `models` з `get_server_info()`. ТІЛЬКИ з явним cli_path (К9).
    Синхронна обгортка: викликати поза подієвим циклом (фоновий потік або сервер)."""
    if not cli_path or not str(cli_path).strip():
        raise ValueError('claude model catalog needs cli_path (bundled SDK CLI is stale)')
    from claude_agent_sdk import ClaudeSDKClient, ClaudeAgentOptions

    async def _go():
        async with ClaudeSDKClient(options=ClaudeAgentOptions(cli_path=cli_path)) as c:
            info = await c.get_server_info() or {}
        return info.get('models') or []

    async def _bounded():
        return await asyncio.wait_for(_go(), timeout)

    return asyncio.run(_bounded())


class ClaudeCatalog:
    """Кеш каталогу: памʼять -> файл на диску -> CLI. Свіжий = та сама версія CLI і
    не старший за CACHE_TTL. Протухлий кеш тієї ж версії ще служить, поки фон тягне
    новий; кеш ІНШОЇ версії не служить (там міг бути вже неіснуючий id)."""

    def __init__(self, cli_path, cache_path, log=None, fetch=fetch_models,
                 clock=time.time, version_of=cli_version, ttl=CACHE_TTL):
        if not cli_path or not str(cli_path).strip():
            raise ValueError('ClaudeCatalog needs cli_path (К9)')
        self.cli_path = cli_path
        self.cache_path = cache_path
        self._log = log or (lambda *_: None)
        self._fetch = fetch
        self._clock = clock
        self._version_of = version_of
        self._ttl = ttl
        self._mem = None
        self._lock = threading.Lock()
        self._thread = None
        self._logged = set()

    # ── кеш ─────────────────────────────────────────────────────────────────
    def _read_disk(self):
        try:
            with open(self.cache_path, encoding='utf-8') as f:
                snap = json.load(f)
        except (OSError, ValueError):
            return None
        return snap if isinstance(snap, dict) and isinstance(snap.get('models'), list) else None

    def _write_disk(self, snap):
        tmp = f'{self.cache_path}.{os.getpid()}.tmp'
        try:
            with open(tmp, 'w', encoding='utf-8') as f:
                json.dump(snap, f, ensure_ascii=False, indent=1)
            os.replace(tmp, self.cache_path)
        except OSError as e:
            self._log_once(f'claude catalog: cache write failed: {e}')

    def _state(self, version):
        """(snap, fresh, usable) для поточної версії CLI. Диск перечитується, коли
        памʼять не свіжа: сусідній процес (сервер або раннер) міг уже оновити кеш."""
        snap = self._mem
        if not self._is_fresh(snap, version):
            disk = self._read_disk()
            if disk is not None:
                snap = self._mem = disk
        if not snap or snap.get('cliVersion') != version:
            return snap, False, False
        return snap, self._is_fresh(snap, version), True

    def _is_fresh(self, snap, version):
        if not snap or snap.get('cliVersion') != version:
            return False
        age = self._clock() - float(snap.get('fetchedAt') or 0)
        return 0 <= age < self._ttl

    def _log_once(self, msg):
        if msg not in self._logged:
            self._logged.add(msg)
            self._log(msg)

    # ── отримання ───────────────────────────────────────────────────────────
    def refresh(self):
        """Потягнути каталог з CLI і покласти в кеш. None при будь-якій помилці (К6)."""
        version = self._version_of(self.cli_path)
        if not version:
            self._log_once(f'claude catalog unavailable: CLI not found at {self.cli_path}')
            return None
        t0 = time.monotonic()
        try:
            models = self._fetch(self.cli_path, FETCH_TIMEOUT)
        except Exception as e:
            reason = f'{type(e).__name__}: {e}' if str(e) else type(e).__name__
            self._log_once(f'claude catalog unavailable ({reason}); using bare aliases')
            return None
        fams = parse_catalog(models)
        if not fams:
            self._log_once('claude catalog unavailable (no known families); using bare aliases')
            return None
        snap = {'cliVersion': version, 'fetchedAt': self._clock(), 'cliPath': self.cli_path,
                'models': models}
        with self._lock:
            self._mem = snap
        self._write_disk(snap)
        self._log(f'claude catalog fetched: cli {version}, '
                  + ', '.join(f"{f}={e['modelArg']}" for f, e in fams.items())
                  + f' ({time.monotonic() - t0:.1f}s)')
        return fams

    def _refresh_bg(self):
        with self._lock:
            if self._thread and self._thread.is_alive():
                return
            self._thread = threading.Thread(target=self.refresh, name='claude-catalog',
                                            daemon=True)
            self._thread.start()

    def wait_refresh(self, timeout=None):
        t = self._thread
        if t:
            t.join(timeout)

    def warm(self):
        """Старт процесу (К1): якщо кеш не свіжий, тягнемо у фоні, нікого не блокуючи."""
        _, fresh, _ = self._state(self._version_of(self.cli_path))
        if not fresh:
            self._refresh_bg()

    def snapshot_meta(self):
        snap = self._mem or {}
        return {'cliVersion': snap.get('cliVersion'), 'fetchedAt': snap.get('fetchedAt')}

    def get(self, block=False):
        """Каталог {родина: запис} або None. block=False ніколи не запускає CLI у
        поточному потоці: гарячий шлях ходу, та ще й усередині asyncio-циклу SDK."""
        version = self._version_of(self.cli_path)
        snap, fresh, usable = self._state(version)
        if fresh:
            return parse_catalog(snap['models'])
        if block:
            fams = self.refresh()
            if fams:
                return fams
        else:
            self._refresh_bg()
        return parse_catalog(snap['models']) if usable else None


_INSTANCES = {}
_INSTANCES_LOCK = threading.Lock()


def catalog_for(cli_path, cache_path, log=None):
    """Один обʼєкт на процес для пари (CLI, файл кешу)."""
    key = (cli_path, cache_path)
    with _INSTANCES_LOCK:
        inst = _INSTANCES.get(key)
        if inst is None:
            inst = _INSTANCES[key] = ClaudeCatalog(cli_path, cache_path, log=log)
        return inst
